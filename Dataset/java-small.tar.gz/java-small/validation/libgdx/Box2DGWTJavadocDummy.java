package com.badlogic.gdx.physics.box2d.gwt;

/** Needed to generate Javadoc for Maven artifact **/
public class Box2DGWTJavadocDummy {
}
