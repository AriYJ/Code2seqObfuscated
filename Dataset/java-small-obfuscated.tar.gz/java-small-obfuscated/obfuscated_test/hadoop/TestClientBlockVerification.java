public class TestClientBlockVerification {
    static BlockReaderTestUtil URFLDTQZOM = null;

    static final Path DWVEFBWWQP = new Path("/test.file");

    static final int EXPNSBWMRQ = 256;

    static LocatedBlock UKTPTXFGJC = null;

    static {
        ((org.apache.commons.logging.impl.Log4JLogger) (RemoteBlockReader2.LOG)).getLogger().setLevel(Level.ALL);
    }

    @BeforeClass
    public static void setupCluster() throws Exception {
        final int DNRGJGHSIS = 1;
        TestClientBlockVerification.URFLDTQZOM = new BlockReaderTestUtil(DNRGJGHSIS);
        TestClientBlockVerification.URFLDTQZOM.writeFile(TestClientBlockVerification.DWVEFBWWQP, TestClientBlockVerification.EXPNSBWMRQ);
        List<LocatedBlock> NUDNMOMWQZ = TestClientBlockVerification.URFLDTQZOM.getFileBlocks(TestClientBlockVerification.DWVEFBWWQP, TestClientBlockVerification.EXPNSBWMRQ);
        TestClientBlockVerification.UKTPTXFGJC = NUDNMOMWQZ.get(0);// Use the first block to test

    }

    /**
     * Verify that if we read an entire block, we send CHECKSUM_OK
     */
    @Test
    public void testBlockVerification() throws Exception {
        RemoteBlockReader2 AQKHIAMSGQ = ((RemoteBlockReader2) (spy(TestClientBlockVerification.URFLDTQZOM.getBlockReader(TestClientBlockVerification.UKTPTXFGJC, 0, TestClientBlockVerification.EXPNSBWMRQ * 1024))));
        TestClientBlockVerification.URFLDTQZOM.readAndCheckEOS(AQKHIAMSGQ, TestClientBlockVerification.EXPNSBWMRQ * 1024, true);
        verify(AQKHIAMSGQ).sendReadResult(Status.CHECKSUM_OK);
        AQKHIAMSGQ.close();
    }

    /**
     * Test that if we do an incomplete read, we don't call CHECKSUM_OK
     */
    @Test
    public void testIncompleteRead() throws Exception {
        RemoteBlockReader2 KYRVJIXEHE = ((RemoteBlockReader2) (spy(TestClientBlockVerification.URFLDTQZOM.getBlockReader(TestClientBlockVerification.UKTPTXFGJC, 0, TestClientBlockVerification.EXPNSBWMRQ * 1024))));
        TestClientBlockVerification.URFLDTQZOM.readAndCheckEOS(KYRVJIXEHE, (TestClientBlockVerification.EXPNSBWMRQ / 2) * 1024, false);
        // We asked the blockreader for the whole file, and only read
        // half of it, so no CHECKSUM_OK
        verify(KYRVJIXEHE, never()).sendReadResult(Status.CHECKSUM_OK);
        KYRVJIXEHE.close();
    }

    /**
     * Test that if we ask for a half block, and read it all, we *do*
     * send CHECKSUM_OK. The DN takes care of knowing whether it was
     * the whole block or not.
     */
    @Test
    public void testCompletePartialRead() throws Exception {
        // Ask for half the file
        RemoteBlockReader2 JDJXAXEOIV = ((RemoteBlockReader2) (spy(TestClientBlockVerification.URFLDTQZOM.getBlockReader(TestClientBlockVerification.UKTPTXFGJC, 0, (TestClientBlockVerification.EXPNSBWMRQ * 1024) / 2))));
        // And read half the file
        TestClientBlockVerification.URFLDTQZOM.readAndCheckEOS(JDJXAXEOIV, (TestClientBlockVerification.EXPNSBWMRQ * 1024) / 2, true);
        verify(JDJXAXEOIV).sendReadResult(Status.CHECKSUM_OK);
        JDJXAXEOIV.close();
    }

    /**
     * Test various unaligned reads to make sure that we properly
     * account even when we don't start or end on a checksum boundary
     */
    @Test
    public void testUnalignedReads() throws Exception {
        int[] ADKSJVYSLR = new int[]{ 0, 3, 129 };
        int[] FUKSRZNKMI = new int[]{ 30, 300, 512, 513, 1025 };
        for (int PRONDDRNNN : ADKSJVYSLR) {
            for (int JPRPPKQXCR : FUKSRZNKMI) {
                LOG.info(((("Testing startOffset = " + PRONDDRNNN) + " and ") + " len=") + JPRPPKQXCR);
                RemoteBlockReader2 ONKGKEOLSE = ((RemoteBlockReader2) (spy(TestClientBlockVerification.URFLDTQZOM.getBlockReader(TestClientBlockVerification.UKTPTXFGJC, PRONDDRNNN, JPRPPKQXCR))));
                TestClientBlockVerification.URFLDTQZOM.readAndCheckEOS(ONKGKEOLSE, JPRPPKQXCR, true);
                verify(ONKGKEOLSE).sendReadResult(Status.CHECKSUM_OK);
                ONKGKEOLSE.close();
            }
        }
    }

    @AfterClass
    public static void teardownCluster() throws Exception {
        TestClientBlockVerification.URFLDTQZOM.shutdown();
    }
}