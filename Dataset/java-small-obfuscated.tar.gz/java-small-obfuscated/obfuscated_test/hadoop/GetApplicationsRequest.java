/**
 * <p>The request from clients to get a report of Applications
 * in the cluster from the <code>ResourceManager</code>.</p>
 *
 * @see ApplicationClientProtocol#getApplications(GetApplicationsRequest)
 */
@Public
@Stable
public abstract class GetApplicationsRequest {
    @Public
    @Stable
    public static GetApplicationsRequest newInstance() {
        GetApplicationsRequest OGWWXSDFWN = Records.newRecord(GetApplicationsRequest.class);
        return OGWWXSDFWN;
    }

    /**
     * <p>
     * The request from clients to get a report of Applications matching the
     * giving application types in the cluster from the
     * <code>ResourceManager</code>.
     * </p>
     *
     * @see ApplicationClientProtocol#getApplications(GetApplicationsRequest)

    <p>Setting any of the parameters to null, would just disable that
    filter</p>
     * @param scope
     * 		{@link ApplicationsRequestScope} to filter by
     * @param users
     * 		list of users to filter by
     * @param queues
     * 		list of scheduler queues to filter by
     * @param applicationTypes
     * 		types of applications
     * @param applicationTags
     * 		application tags to filter by
     * @param applicationStates
     * 		application states to filter by
     * @param startRange
     * 		range of application start times to filter by
     * @param finishRange
     * 		range of application finish times to filter by
     * @param limit
     * 		number of applications to limit to
     * @return {@link GetApplicationsRequest} to be used with
    {@link ApplicationClientProtocol#getApplications(GetApplicationsRequest)}
     */
    @Public
    @Stable
    public static GetApplicationsRequest newInstance(ApplicationsRequestScope IUOBEVLCZW, Set<String> VXUQLYJOJP, Set<String> HOUTMNPDVX, Set<String> XIPZUDOHFQ, Set<String> PWAPHIIKBP, EnumSet<YarnApplicationState> JIQTGYRRUW, LongRange GPMGDGRLVO, LongRange BZFKTFYXBN, Long UFYSHKRTTC) {
        GetApplicationsRequest ENLOXSTWPI = Records.newRecord(GetApplicationsRequest.class);
        if (IUOBEVLCZW != null) {
            ENLOXSTWPI.setScope(IUOBEVLCZW);
        }
        ENLOXSTWPI.setUsers(VXUQLYJOJP);
        ENLOXSTWPI.setQueues(HOUTMNPDVX);
        ENLOXSTWPI.setApplicationTypes(XIPZUDOHFQ);
        ENLOXSTWPI.setApplicationTags(PWAPHIIKBP);
        ENLOXSTWPI.setApplicationStates(JIQTGYRRUW);
        if (GPMGDGRLVO != null) {
            ENLOXSTWPI.setStartRange(GPMGDGRLVO.getMinimumLong(), GPMGDGRLVO.getMaximumLong());
        }
        if (BZFKTFYXBN != null) {
            ENLOXSTWPI.setFinishRange(BZFKTFYXBN.getMinimumLong(), BZFKTFYXBN.getMaximumLong());
        }
        if (UFYSHKRTTC != null) {
            ENLOXSTWPI.setLimit(UFYSHKRTTC);
        }
        return ENLOXSTWPI;
    }

    /**
     * <p>
     * The request from clients to get a report of Applications matching the
     * giving application types in the cluster from the
     * <code>ResourceManager</code>.
     * </p>
     *
     * @param scope
     * 		{@link ApplicationsRequestScope} to filter by
     * @see ApplicationClientProtocol#getApplications(GetApplicationsRequest)
     */
    @Public
    @Stable
    public static GetApplicationsRequest newInstance(ApplicationsRequestScope HYLZBDJSQY) {
        GetApplicationsRequest JOIQKNXCSG = Records.newRecord(GetApplicationsRequest.class);
        JOIQKNXCSG.setScope(HYLZBDJSQY);
        return JOIQKNXCSG;
    }

    /**
     * <p>
     * The request from clients to get a report of Applications matching the
     * giving application types in the cluster from the
     * <code>ResourceManager</code>.
     * </p>
     *
     * @see ApplicationClientProtocol#getApplications(GetApplicationsRequest)
     */
    @Public
    @Stable
    public static GetApplicationsRequest newInstance(Set<String> ASNLTFNGFH) {
        GetApplicationsRequest NANRQZCRDD = Records.newRecord(GetApplicationsRequest.class);
        NANRQZCRDD.setApplicationTypes(ASNLTFNGFH);
        return NANRQZCRDD;
    }

    /**
     * <p>
     * The request from clients to get a report of Applications matching the
     * giving application states in the cluster from the
     * <code>ResourceManager</code>.
     * </p>
     *
     * @see ApplicationClientProtocol#getApplications(GetApplicationsRequest)
     */
    @Public
    @Stable
    public static GetApplicationsRequest newInstance(EnumSet<YarnApplicationState> VGRFYAIPNH) {
        GetApplicationsRequest MEEXXVUTHR = Records.newRecord(GetApplicationsRequest.class);
        MEEXXVUTHR.setApplicationStates(VGRFYAIPNH);
        return MEEXXVUTHR;
    }

    /**
     * <p>
     * The request from clients to get a report of Applications matching the
     * giving and application types and application types in the cluster from the
     * <code>ResourceManager</code>.
     * </p>
     *
     * @see ApplicationClientProtocol#getApplications(GetApplicationsRequest)
     */
    @Public
    @Stable
    public static GetApplicationsRequest newInstance(Set<String> GDRKBFRPNB, EnumSet<YarnApplicationState> KJBLMYDAIR) {
        GetApplicationsRequest XKVYPXLJUH = Records.newRecord(GetApplicationsRequest.class);
        XKVYPXLJUH.setApplicationTypes(GDRKBFRPNB);
        XKVYPXLJUH.setApplicationStates(KJBLMYDAIR);
        return XKVYPXLJUH;
    }

    /**
     * Get the application types to filter applications on
     *
     * @return Set of Application Types to filter on
     */
    @Public
    @Stable
    public abstract Set<String> getApplicationTypes();

    /**
     * Set the application types to filter applications on
     *
     * @param applicationTypes
     * 		A Set of Application Types to filter on.
     * 		If not defined, match all applications
     */
    @Private
    @Unstable
    public abstract void setApplicationTypes(Set<String> DHDMHQYWMP);

    /**
     * Get the application states to filter applications on
     *
     * @return Set of Application states to filter on
     */
    @Public
    @Stable
    public abstract EnumSet<YarnApplicationState> getApplicationStates();

    /**
     * Set the application states to filter applications on
     *
     * @param applicationStates
     * 		A Set of Application states to filter on.
     * 		If not defined, match all running applications
     */
    @Private
    @Unstable
    public abstract void setApplicationStates(EnumSet<YarnApplicationState> JIHQPQEWHO);

    /**
     * Set the application states to filter applications on
     *
     * @param applicationStates
     * 		all lower-case string representation of the
     * 		application states to filter on
     */
    @Private
    @Unstable
    public abstract void setApplicationStates(Set<String> OVFQFARLYN);

    /**
     * Get the users to filter applications on
     *
     * @return set of users to filter applications on
     */
    @Private
    @Unstable
    public abstract Set<String> getUsers();

    /**
     * Set the users to filter applications on
     *
     * @param users
     * 		set of users to filter applications on
     */
    @Private
    @Unstable
    public abstract void setUsers(Set<String> QHNMMWLBKL);

    /**
     * Get the queues to filter applications on
     *
     * @return set of queues to filter applications on
     */
    @Private
    @Unstable
    public abstract Set<String> getQueues();

    /**
     * Set the queue to filter applications on
     *
     * @param queue
     * 		user to filter applications on
     */
    @Private
    @Unstable
    public abstract void setQueues(Set<String> ACCGTMQWTO);

    /**
     * Get the limit on the number applications to return
     *
     * @return number of applications to limit to
     */
    @Private
    @Unstable
    public abstract long getLimit();

    /**
     * Limit the number applications to return
     *
     * @param limit
     * 		number of applications to limit to
     */
    @Private
    @Unstable
    public abstract void setLimit(long QHNBPUEQJU);

    /**
     * Get the range of start times to filter applications on
     *
     * @return {@link LongRange} of start times to filter applications on
     */
    @Private
    @Unstable
    public abstract LongRange getStartRange();

    /**
     * Set the range of start times to filter applications on
     *
     * @param range
     * 		
     */
    @Private
    @Unstable
    public abstract void setStartRange(LongRange GRRYRGGJWH);

    /**
     * Set the range of start times to filter applications on
     *
     * @param begin
     * 		beginning of the range
     * @param end
     * 		end of the range
     * @throws IllegalArgumentException
     * 		
     */
    @Private
    @Unstable
    public abstract void setStartRange(long WPARONBVFJ, long NQBCXGNAQQ) throws IllegalArgumentException;

    /**
     * Get the range of finish times to filter applications on
     *
     * @return {@link LongRange} of finish times to filter applications on
     */
    @Private
    @Unstable
    public abstract LongRange getFinishRange();

    /**
     * Set the range of finish times to filter applications on
     *
     * @param range
     * 		
     */
    @Private
    @Unstable
    public abstract void setFinishRange(LongRange QIILWLCSZH);

    /**
     * Set the range of finish times to filter applications on
     *
     * @param begin
     * 		beginning of the range
     * @param end
     * 		end of the range
     * @throws IllegalArgumentException
     * 		
     */
    @Private
    @Unstable
    public abstract void setFinishRange(long QNMPVCNKVE, long PJGEZRQRQH);

    /**
     * Get the tags to filter applications on
     *
     * @return list of tags to filter on
     */
    @Private
    @Unstable
    public abstract Set<String> getApplicationTags();

    /**
     * Set the list of tags to filter applications on
     *
     * @param tags
     * 		list of tags to filter on
     */
    @Private
    @Unstable
    public abstract void setApplicationTags(Set<String> OQRZONINQF);

    /**
     * Get the {@link ApplicationsRequestScope} of applications to be filtered.
     *
     * @return {@link ApplicationsRequestScope} of applications to return.
     */
    @Private
    @Unstable
    public abstract ApplicationsRequestScope getScope();

    /**
     * Set the {@link ApplicationsRequestScope} of applications to filter.
     *
     * @param scope
     * 		scope to use for filtering applications
     */
    @Private
    @Unstable
    public abstract void setScope(ApplicationsRequestScope VIGCKLMMAG);
}