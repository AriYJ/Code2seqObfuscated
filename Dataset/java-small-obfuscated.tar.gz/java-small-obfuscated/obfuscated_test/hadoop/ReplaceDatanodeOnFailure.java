/**
 * The setting of replace-datanode-on-failure feature.
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public enum ReplaceDatanodeOnFailure {

    /**
     * The feature is disabled in the entire site.
     */
    DISABLE,
    /**
     * Never add a new datanode.
     */
    NEVER,
    /**
     * DEFAULT policy:
     *   Let r be the replication number.
     *   Let n be the number of existing datanodes.
     *   Add a new datanode only if r >= 3 and either
     *   (1) floor(r/2) >= n; or
     *   (2) r > n and the block is hflushed/appended.
     */
    DEFAULT,
    /**
     * Always add a new datanode when an existing datanode is removed.
     */
    ALWAYS;
    /**
     * Check if the feature is enabled.
     */
    public void checkEnabled() {
        if (this == ReplaceDatanodeOnFailure.DISABLE) {
            throw new UnsupportedOperationException(("This feature is disabled.  Please refer to " + DFSConfigKeys.DFS_CLIENT_WRITE_REPLACE_DATANODE_ON_FAILURE_ENABLE_KEY) + " configuration property.");
        }
    }

    /**
     * Is the policy satisfied?
     */
    public boolean satisfy(final short PQFTTOLDXJ, final DatanodeInfo[] ZKSNGAONPU, final boolean WNPMVQRIJG, final boolean BYKFZHRCKF) {
        final int GAEYANKNNC = (ZKSNGAONPU == null) ? 0 : ZKSNGAONPU.length;
        if ((GAEYANKNNC == 0) || (GAEYANKNNC >= PQFTTOLDXJ)) {
            // don't need to add datanode for any policy.
            return false;
        } else
            if ((this == ReplaceDatanodeOnFailure.DISABLE) || (this == ReplaceDatanodeOnFailure.NEVER)) {
                return false;
            } else
                if (this == ReplaceDatanodeOnFailure.ALWAYS) {
                    return true;
                } else {
                    // DEFAULT
                    if (PQFTTOLDXJ < 3) {
                        return false;
                    } else {
                        if (GAEYANKNNC <= (PQFTTOLDXJ / 2)) {
                            return true;
                        } else {
                            return WNPMVQRIJG || BYKFZHRCKF;
                        }
                    }
                }


    }

    /**
     * Get the setting from configuration.
     */
    public static ReplaceDatanodeOnFailure get(final Configuration MDYBVTXYCB) {
        final boolean MWIGZSPFGB = MDYBVTXYCB.getBoolean(DFS_CLIENT_WRITE_REPLACE_DATANODE_ON_FAILURE_ENABLE_KEY, DFS_CLIENT_WRITE_REPLACE_DATANODE_ON_FAILURE_ENABLE_DEFAULT);
        if (!MWIGZSPFGB) {
            return ReplaceDatanodeOnFailure.DISABLE;
        }
        final String VCFIOISRRS = MDYBVTXYCB.get(DFS_CLIENT_WRITE_REPLACE_DATANODE_ON_FAILURE_POLICY_KEY, DFS_CLIENT_WRITE_REPLACE_DATANODE_ON_FAILURE_POLICY_DEFAULT);
        for (int LMENBOJIVB = 1; LMENBOJIVB < ReplaceDatanodeOnFailure.values().length; LMENBOJIVB++) {
            final ReplaceDatanodeOnFailure PBHNJDLIAP = ReplaceDatanodeOnFailure.values()[LMENBOJIVB];
            if (PBHNJDLIAP.name().equalsIgnoreCase(VCFIOISRRS)) {
                return PBHNJDLIAP;
            }
        }
        throw new org.apache.hadoop.HadoopIllegalArgumentException((("Illegal configuration value for " + DFSConfigKeys.DFS_CLIENT_WRITE_REPLACE_DATANODE_ON_FAILURE_POLICY_KEY) + ": ") + VCFIOISRRS);
    }

    /**
     * Write the setting to configuration.
     */
    public void write(final Configuration DQZTWTDVNS) {
        DQZTWTDVNS.setBoolean(DFS_CLIENT_WRITE_REPLACE_DATANODE_ON_FAILURE_ENABLE_KEY, this != ReplaceDatanodeOnFailure.DISABLE);
        DQZTWTDVNS.set(DFS_CLIENT_WRITE_REPLACE_DATANODE_ON_FAILURE_POLICY_KEY, name());
    }
}