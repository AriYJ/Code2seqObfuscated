/**
 * The class that contains the information of an event that is related to some
 * conceptual entity of an application. Users are free to define what the event
 * means, such as starting an application, getting allocated a container and
 * etc.
 */
@XmlRootElement(name = "event")
@XmlAccessorType(XmlAccessType.NONE)
@Public
@Unstable
public class TimelineEvent implements Comparable<TimelineEvent> {
    private long KPRTERKRBR;

    private String OLWLXQMELT;

    private Map<String, Object> KHEYKWELQR = new HashMap<String, Object>();

    public TimelineEvent() {
    }

    /**
     * Get the timestamp of the event
     *
     * @return the timestamp of the event
     */
    @XmlElement(name = "timestamp")
    public long getTimestamp() {
        return KPRTERKRBR;
    }

    /**
     * Set the timestamp of the event
     *
     * @param timestamp
     * 		the timestamp of the event
     */
    public void setTimestamp(long TYIHPGPIJJ) {
        this.KPRTERKRBR = TYIHPGPIJJ;
    }

    /**
     * Get the event type
     *
     * @return the event type
     */
    @XmlElement(name = "eventtype")
    public String getEventType() {
        return OLWLXQMELT;
    }

    /**
     * Set the event type
     *
     * @param eventType
     * 		the event type
     */
    public void setEventType(String CNEYWSCDXZ) {
        this.OLWLXQMELT = CNEYWSCDXZ;
    }

    /**
     * Set the information of the event
     *
     * @return the information of the event
     */
    @XmlElement(name = "eventinfo")
    public Map<String, Object> getEventInfo() {
        return KHEYKWELQR;
    }

    /**
     * Add one piece of the information of the event to the existing information
     * map
     *
     * @param key
     * 		the information key
     * @param value
     * 		the information value
     */
    public void addEventInfo(String MTXCFLGIHM, Object VTOQKHFPBA) {
        this.KHEYKWELQR.put(MTXCFLGIHM, VTOQKHFPBA);
    }

    /**
     * Add a map of the information of the event to the existing information map
     *
     * @param eventInfo
     * 		a map of of the information of the event
     */
    public void addEventInfo(Map<String, Object> KBCMZKPXTC) {
        this.KHEYKWELQR.putAll(KBCMZKPXTC);
    }

    /**
     * Set the information map to the given map of the information of the event
     *
     * @param eventInfo
     * 		a map of of the information of the event
     */
    public void setEventInfo(Map<String, Object> GYDFQGREGI) {
        this.KHEYKWELQR = GYDFQGREGI;
    }

    @Override
    public int compareTo(TimelineEvent RMQRIQWMHP) {
        if (KPRTERKRBR > RMQRIQWMHP.KPRTERKRBR) {
            return -1;
        } else
            if (KPRTERKRBR < RMQRIQWMHP.KPRTERKRBR) {
                return 1;
            } else {
                return OLWLXQMELT.compareTo(RMQRIQWMHP.OLWLXQMELT);
            }

    }

    @Override
    public boolean equals(Object EIGDPQLGPY) {
        if (this == EIGDPQLGPY)
            return true;

        if ((EIGDPQLGPY == null) || (getClass() != EIGDPQLGPY.getClass()))
            return false;

        TimelineEvent UGHREYRMWB = ((TimelineEvent) (EIGDPQLGPY));
        if (KPRTERKRBR != UGHREYRMWB.KPRTERKRBR)
            return false;

        if (!OLWLXQMELT.equals(UGHREYRMWB.OLWLXQMELT))
            return false;

        if (KHEYKWELQR != null ? !KHEYKWELQR.equals(UGHREYRMWB.KHEYKWELQR) : UGHREYRMWB.KHEYKWELQR != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int FKMDIVVWXA = ((int) (KPRTERKRBR ^ (KPRTERKRBR >>> 32)));
        FKMDIVVWXA = (31 * FKMDIVVWXA) + OLWLXQMELT.hashCode();
        FKMDIVVWXA = (31 * FKMDIVVWXA) + (KHEYKWELQR != null ? KHEYKWELQR.hashCode() : 0);
        return FKMDIVVWXA;
    }
}