/**
 * Signs strings and verifies signed strings using a SHA digest.
 */
public class Signer {
    private static final String VXBCUIXAMP = "&s=";

    private SignerSecretProvider ZNNHHFIILE;

    /**
     * Creates a Signer instance using the specified SignerSecretProvider.  The
     * SignerSecretProvider should already be initialized.
     *
     * @param secretProvider
     * 		The SignerSecretProvider to use
     */
    public Signer(SignerSecretProvider UMCJGTUNXB) {
        if (UMCJGTUNXB == null) {
            throw new IllegalArgumentException("secretProvider cannot be NULL");
        }
        this.ZNNHHFIILE = UMCJGTUNXB;
    }

    /**
     * Returns a signed string.
     * <p/>
     * The signature '&s=SIGNATURE' is appended at the end of the string.
     *
     * @param str
     * 		string to sign.
     * @return the signed string.
     */
    public synchronized String sign(String JPJRWRALXI) {
        if ((JPJRWRALXI == null) || (JPJRWRALXI.length() == 0)) {
            throw new IllegalArgumentException("NULL or empty string to sign");
        }
        byte[] PEGEALIQCF = ZNNHHFIILE.getCurrentSecret();
        String WVUCCDEASG = computeSignature(PEGEALIQCF, JPJRWRALXI);
        return (JPJRWRALXI + Signer.VXBCUIXAMP) + WVUCCDEASG;
    }

    /**
     * Verifies a signed string and extracts the original string.
     *
     * @param signedStr
     * 		the signed string to verify and extract.
     * @return the extracted original string.
     * @throws SignerException
     * 		thrown if the given string is not a signed string or if the signature is invalid.
     */
    public String verifyAndExtract(String PCNOJXDRNO) throws SignerException {
        int UBZNYAXCAP = PCNOJXDRNO.lastIndexOf(Signer.VXBCUIXAMP);
        if (UBZNYAXCAP == (-1)) {
            throw new SignerException("Invalid signed text: " + PCNOJXDRNO);
        }
        String IMXCJSOQNN = PCNOJXDRNO.substring(UBZNYAXCAP + Signer.VXBCUIXAMP.length());
        String AORJZRRDKA = PCNOJXDRNO.substring(0, UBZNYAXCAP);
        checkSignatures(AORJZRRDKA, IMXCJSOQNN);
        return AORJZRRDKA;
    }

    /**
     * Returns then signature of a string.
     *
     * @param secret
     * 		The secret to use
     * @param str
     * 		string to sign.
     * @return the signature for the string.
     */
    protected String computeSignature(byte[] XDTRMDKFKL, String WEJCUBFDFG) {
        try {
            MessageDigest GWBLLJEMEZ = MessageDigest.getInstance("SHA");
            GWBLLJEMEZ.update(WEJCUBFDFG.getBytes());
            GWBLLJEMEZ.update(XDTRMDKFKL);
            byte[] HSKHEWDAEU = GWBLLJEMEZ.digest();
            return new Base64(0).encodeToString(HSKHEWDAEU);
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException("It should not happen, " + ex.getMessage(), ex);
        }
    }

    protected void checkSignatures(String PAHHWWOKWC, String QGPJHGYAZM) throws SignerException {
        boolean OEMYWPVNCR = false;
        byte[][] QHYIKCMOGX = ZNNHHFIILE.getAllSecrets();
        for (int RNWUADHVIP = 0; RNWUADHVIP < QHYIKCMOGX.length; RNWUADHVIP++) {
            byte[] ICPUORJEMJ = QHYIKCMOGX[RNWUADHVIP];
            if (ICPUORJEMJ != null) {
                String TJDCTGJFYQ = computeSignature(ICPUORJEMJ, PAHHWWOKWC);
                if (QGPJHGYAZM.equals(TJDCTGJFYQ)) {
                    OEMYWPVNCR = true;
                    break;
                }
            }
        }
        if (!OEMYWPVNCR) {
            throw new SignerException("Invalid signature");
        }
    }
}