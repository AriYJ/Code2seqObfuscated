public class TestFileNameIndexUtils {
    private static final String FFBRGNNRUW = (((((((((((((("%s" + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + JobHistoryUtils.JOB_HISTORY_FILE_EXTENSION;

    private static final String FUFHLOSMOE = (((((((((((((((("%s" + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + JobHistoryUtils.JOB_HISTORY_FILE_EXTENSION;

    private static final String DJQBUEWKGF = (((((((((((((((((("%s" + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + FileNameIndexUtils.DELIMITER) + "%s") + JobHistoryUtils.JOB_HISTORY_FILE_EXTENSION;

    private static final String UZWGREIDOC = "job_1317928501754_0001";

    private static final String HJRUKGTYGN = "1317928742025";

    private static final String EDANRPQYNC = "username";

    private static final String LFLEOZNSAS = ("user" + FileNameIndexUtils.DELIMITER) + "name";

    private static final String FFYALRZGTV = ("user" + FileNameIndexUtils.DELIMITER_ESCAPE) + "name";

    private static final String CVPYAQGCHG = "mapreduce";

    private static final String LJNIXPRHOB = ("map" + FileNameIndexUtils.DELIMITER) + "reduce";

    private static final String EILPNNEFSN = ("map" + FileNameIndexUtils.DELIMITER_ESCAPE) + "reduce";

    private static final String NMZHBBQOOK = "1317928754958";

    private static final String CGYTDBEMGT = "1";

    private static final String KYAKHJGQOY = "1";

    private static final String AOUQTMQDLZ = "SUCCEEDED";

    private static final String KOEKBOWPQA = "default";

    private static final String JMCJXLLTTK = ("test" + FileNameIndexUtils.DELIMITER) + "queue";

    private static final String VZWRVFVOZN = ("test" + FileNameIndexUtils.DELIMITER_ESCAPE) + "queue";

    private static final String ORQLAAKBAT = "1317928742060";

    @Test
    public void testEncodingDecodingEquivalence() throws IOException {
        JobIndexInfo IXDLRLSYMG = new JobIndexInfo();
        JobID MRZYLAXKHZ = JobID.forName(TestFileNameIndexUtils.UZWGREIDOC);
        JobId FHWVIKHSLH = TypeConverter.toYarn(MRZYLAXKHZ);
        IXDLRLSYMG.setJobId(FHWVIKHSLH);
        IXDLRLSYMG.setSubmitTime(Long.parseLong(TestFileNameIndexUtils.HJRUKGTYGN));
        IXDLRLSYMG.setUser(TestFileNameIndexUtils.EDANRPQYNC);
        IXDLRLSYMG.setJobName(TestFileNameIndexUtils.CVPYAQGCHG);
        IXDLRLSYMG.setFinishTime(Long.parseLong(TestFileNameIndexUtils.NMZHBBQOOK));
        IXDLRLSYMG.setNumMaps(Integer.parseInt(TestFileNameIndexUtils.CGYTDBEMGT));
        IXDLRLSYMG.setNumReduces(Integer.parseInt(TestFileNameIndexUtils.KYAKHJGQOY));
        IXDLRLSYMG.setJobStatus(TestFileNameIndexUtils.AOUQTMQDLZ);
        IXDLRLSYMG.setQueueName(TestFileNameIndexUtils.KOEKBOWPQA);
        IXDLRLSYMG.setJobStartTime(Long.parseLong(TestFileNameIndexUtils.ORQLAAKBAT));
        String LPHXOUKKPC = FileNameIndexUtils.getDoneFileName(IXDLRLSYMG);
        JobIndexInfo BHHFCBCPBC = FileNameIndexUtils.getIndexInfo(LPHXOUKKPC);
        Assert.assertEquals("Job id different after encoding and decoding", IXDLRLSYMG.getJobId(), BHHFCBCPBC.getJobId());
        Assert.assertEquals("Submit time different after encoding and decoding", IXDLRLSYMG.getSubmitTime(), BHHFCBCPBC.getSubmitTime());
        Assert.assertEquals("User different after encoding and decoding", IXDLRLSYMG.getUser(), BHHFCBCPBC.getUser());
        Assert.assertEquals("Job name different after encoding and decoding", IXDLRLSYMG.getJobName(), BHHFCBCPBC.getJobName());
        Assert.assertEquals("Finish time different after encoding and decoding", IXDLRLSYMG.getFinishTime(), BHHFCBCPBC.getFinishTime());
        Assert.assertEquals("Num maps different after encoding and decoding", IXDLRLSYMG.getNumMaps(), BHHFCBCPBC.getNumMaps());
        Assert.assertEquals("Num reduces different after encoding and decoding", IXDLRLSYMG.getNumReduces(), BHHFCBCPBC.getNumReduces());
        Assert.assertEquals("Job status different after encoding and decoding", IXDLRLSYMG.getJobStatus(), BHHFCBCPBC.getJobStatus());
        Assert.assertEquals("Queue name different after encoding and decoding", IXDLRLSYMG.getQueueName(), BHHFCBCPBC.getQueueName());
        Assert.assertEquals("Job start time different after encoding and decoding", IXDLRLSYMG.getJobStartTime(), BHHFCBCPBC.getJobStartTime());
    }

    @Test
    public void testUserNamePercentEncoding() throws IOException {
        JobIndexInfo WMIYFMWZLN = new JobIndexInfo();
        JobID JPWXPJOGOP = JobID.forName(TestFileNameIndexUtils.UZWGREIDOC);
        JobId JOMXBXZQUD = TypeConverter.toYarn(JPWXPJOGOP);
        WMIYFMWZLN.setJobId(JOMXBXZQUD);
        WMIYFMWZLN.setSubmitTime(Long.parseLong(TestFileNameIndexUtils.HJRUKGTYGN));
        WMIYFMWZLN.setUser(TestFileNameIndexUtils.LFLEOZNSAS);
        WMIYFMWZLN.setJobName(TestFileNameIndexUtils.CVPYAQGCHG);
        WMIYFMWZLN.setFinishTime(Long.parseLong(TestFileNameIndexUtils.NMZHBBQOOK));
        WMIYFMWZLN.setNumMaps(Integer.parseInt(TestFileNameIndexUtils.CGYTDBEMGT));
        WMIYFMWZLN.setNumReduces(Integer.parseInt(TestFileNameIndexUtils.KYAKHJGQOY));
        WMIYFMWZLN.setJobStatus(TestFileNameIndexUtils.AOUQTMQDLZ);
        WMIYFMWZLN.setQueueName(TestFileNameIndexUtils.KOEKBOWPQA);
        WMIYFMWZLN.setJobStartTime(Long.parseLong(TestFileNameIndexUtils.ORQLAAKBAT));
        String SFANDOURYV = FileNameIndexUtils.getDoneFileName(WMIYFMWZLN);
        Assert.assertTrue("User name not encoded correctly into job history file", SFANDOURYV.contains(TestFileNameIndexUtils.FFYALRZGTV));
    }

    @Test
    public void testUserNamePercentDecoding() throws IOException {
        String THQNCDHMXJ = String.format(TestFileNameIndexUtils.DJQBUEWKGF, TestFileNameIndexUtils.UZWGREIDOC, TestFileNameIndexUtils.HJRUKGTYGN, TestFileNameIndexUtils.FFYALRZGTV, TestFileNameIndexUtils.CVPYAQGCHG, TestFileNameIndexUtils.NMZHBBQOOK, TestFileNameIndexUtils.CGYTDBEMGT, TestFileNameIndexUtils.KYAKHJGQOY, TestFileNameIndexUtils.AOUQTMQDLZ, TestFileNameIndexUtils.KOEKBOWPQA, TestFileNameIndexUtils.ORQLAAKBAT);
        JobIndexInfo TNIAYJOVDF = FileNameIndexUtils.getIndexInfo(THQNCDHMXJ);
        Assert.assertEquals("User name doesn't match", TestFileNameIndexUtils.LFLEOZNSAS, TNIAYJOVDF.getUser());
    }

    @Test
    public void testJobNamePercentEncoding() throws IOException {
        JobIndexInfo OFDADBHEGA = new JobIndexInfo();
        JobID HMLMMMDABX = JobID.forName(TestFileNameIndexUtils.UZWGREIDOC);
        JobId IHMWPZOBNW = TypeConverter.toYarn(HMLMMMDABX);
        OFDADBHEGA.setJobId(IHMWPZOBNW);
        OFDADBHEGA.setSubmitTime(Long.parseLong(TestFileNameIndexUtils.HJRUKGTYGN));
        OFDADBHEGA.setUser(TestFileNameIndexUtils.EDANRPQYNC);
        OFDADBHEGA.setJobName(TestFileNameIndexUtils.LJNIXPRHOB);
        OFDADBHEGA.setFinishTime(Long.parseLong(TestFileNameIndexUtils.NMZHBBQOOK));
        OFDADBHEGA.setNumMaps(Integer.parseInt(TestFileNameIndexUtils.CGYTDBEMGT));
        OFDADBHEGA.setNumReduces(Integer.parseInt(TestFileNameIndexUtils.KYAKHJGQOY));
        OFDADBHEGA.setJobStatus(TestFileNameIndexUtils.AOUQTMQDLZ);
        OFDADBHEGA.setQueueName(TestFileNameIndexUtils.KOEKBOWPQA);
        OFDADBHEGA.setJobStartTime(Long.parseLong(TestFileNameIndexUtils.ORQLAAKBAT));
        String BPBWJWTDZE = FileNameIndexUtils.getDoneFileName(OFDADBHEGA);
        Assert.assertTrue("Job name not encoded correctly into job history file", BPBWJWTDZE.contains(TestFileNameIndexUtils.EILPNNEFSN));
    }

    @Test
    public void testJobNamePercentDecoding() throws IOException {
        String JJXXFBWEEY = String.format(TestFileNameIndexUtils.DJQBUEWKGF, TestFileNameIndexUtils.UZWGREIDOC, TestFileNameIndexUtils.HJRUKGTYGN, TestFileNameIndexUtils.EDANRPQYNC, TestFileNameIndexUtils.EILPNNEFSN, TestFileNameIndexUtils.NMZHBBQOOK, TestFileNameIndexUtils.CGYTDBEMGT, TestFileNameIndexUtils.KYAKHJGQOY, TestFileNameIndexUtils.AOUQTMQDLZ, TestFileNameIndexUtils.KOEKBOWPQA, TestFileNameIndexUtils.ORQLAAKBAT);
        JobIndexInfo WTGFAYXXUV = FileNameIndexUtils.getIndexInfo(JJXXFBWEEY);
        Assert.assertEquals("Job name doesn't match", TestFileNameIndexUtils.LJNIXPRHOB, WTGFAYXXUV.getJobName());
    }

    @Test
    public void testQueueNamePercentEncoding() throws IOException {
        JobIndexInfo GNTVPZTACV = new JobIndexInfo();
        JobID YMCXONWVFP = JobID.forName(TestFileNameIndexUtils.UZWGREIDOC);
        JobId RSGVIGJJRI = TypeConverter.toYarn(YMCXONWVFP);
        GNTVPZTACV.setJobId(RSGVIGJJRI);
        GNTVPZTACV.setSubmitTime(Long.parseLong(TestFileNameIndexUtils.HJRUKGTYGN));
        GNTVPZTACV.setUser(TestFileNameIndexUtils.EDANRPQYNC);
        GNTVPZTACV.setJobName(TestFileNameIndexUtils.CVPYAQGCHG);
        GNTVPZTACV.setFinishTime(Long.parseLong(TestFileNameIndexUtils.NMZHBBQOOK));
        GNTVPZTACV.setNumMaps(Integer.parseInt(TestFileNameIndexUtils.CGYTDBEMGT));
        GNTVPZTACV.setNumReduces(Integer.parseInt(TestFileNameIndexUtils.KYAKHJGQOY));
        GNTVPZTACV.setJobStatus(TestFileNameIndexUtils.AOUQTMQDLZ);
        GNTVPZTACV.setQueueName(TestFileNameIndexUtils.JMCJXLLTTK);
        GNTVPZTACV.setJobStartTime(Long.parseLong(TestFileNameIndexUtils.ORQLAAKBAT));
        String SRZKKVMSJG = FileNameIndexUtils.getDoneFileName(GNTVPZTACV);
        Assert.assertTrue("Queue name not encoded correctly into job history file", SRZKKVMSJG.contains(TestFileNameIndexUtils.VZWRVFVOZN));
    }

    @Test
    public void testQueueNamePercentDecoding() throws IOException {
        String ANPRWOYJIX = String.format(TestFileNameIndexUtils.DJQBUEWKGF, TestFileNameIndexUtils.UZWGREIDOC, TestFileNameIndexUtils.HJRUKGTYGN, TestFileNameIndexUtils.EDANRPQYNC, TestFileNameIndexUtils.CVPYAQGCHG, TestFileNameIndexUtils.NMZHBBQOOK, TestFileNameIndexUtils.CGYTDBEMGT, TestFileNameIndexUtils.KYAKHJGQOY, TestFileNameIndexUtils.AOUQTMQDLZ, TestFileNameIndexUtils.VZWRVFVOZN, TestFileNameIndexUtils.ORQLAAKBAT);
        JobIndexInfo QORWXKRPZY = FileNameIndexUtils.getIndexInfo(ANPRWOYJIX);
        Assert.assertEquals("Queue name doesn't match", TestFileNameIndexUtils.JMCJXLLTTK, QORWXKRPZY.getQueueName());
    }

    @Test
    public void testJobStartTimeBackwardsCompatible() throws IOException {
        String ALSQFXAEWJ = String.format(TestFileNameIndexUtils.FUFHLOSMOE, TestFileNameIndexUtils.UZWGREIDOC, TestFileNameIndexUtils.HJRUKGTYGN, TestFileNameIndexUtils.EDANRPQYNC, TestFileNameIndexUtils.EILPNNEFSN, TestFileNameIndexUtils.NMZHBBQOOK, TestFileNameIndexUtils.CGYTDBEMGT, TestFileNameIndexUtils.KYAKHJGQOY, TestFileNameIndexUtils.AOUQTMQDLZ, TestFileNameIndexUtils.KOEKBOWPQA);
        JobIndexInfo XQIVQCJCKB = FileNameIndexUtils.getIndexInfo(ALSQFXAEWJ);
        Assert.assertEquals(XQIVQCJCKB.getJobStartTime(), XQIVQCJCKB.getSubmitTime());
    }

    @Test
    public void testJobHistoryFileNameBackwardsCompatible() throws IOException {
        JobID OZIVMQJSLE = JobID.forName(TestFileNameIndexUtils.UZWGREIDOC);
        JobId JGSYOLZTBL = TypeConverter.toYarn(OZIVMQJSLE);
        long MUKOBHPFZY = Long.parseLong(TestFileNameIndexUtils.HJRUKGTYGN);
        long NZIWUYGONV = Long.parseLong(TestFileNameIndexUtils.NMZHBBQOOK);
        int FLKMWLJRYV = Integer.parseInt(TestFileNameIndexUtils.CGYTDBEMGT);
        int AEBOXYVDOS = Integer.parseInt(TestFileNameIndexUtils.KYAKHJGQOY);
        String WCACSEHKSQ = String.format(TestFileNameIndexUtils.FFBRGNNRUW, TestFileNameIndexUtils.UZWGREIDOC, TestFileNameIndexUtils.HJRUKGTYGN, TestFileNameIndexUtils.EDANRPQYNC, TestFileNameIndexUtils.CVPYAQGCHG, TestFileNameIndexUtils.NMZHBBQOOK, TestFileNameIndexUtils.CGYTDBEMGT, TestFileNameIndexUtils.KYAKHJGQOY, TestFileNameIndexUtils.AOUQTMQDLZ);
        JobIndexInfo COARBNRLNZ = FileNameIndexUtils.getIndexInfo(WCACSEHKSQ);
        Assert.assertEquals("Job id incorrect after decoding old history file", JGSYOLZTBL, COARBNRLNZ.getJobId());
        Assert.assertEquals("Submit time incorrect after decoding old history file", MUKOBHPFZY, COARBNRLNZ.getSubmitTime());
        Assert.assertEquals("User incorrect after decoding old history file", TestFileNameIndexUtils.EDANRPQYNC, COARBNRLNZ.getUser());
        Assert.assertEquals("Job name incorrect after decoding old history file", TestFileNameIndexUtils.CVPYAQGCHG, COARBNRLNZ.getJobName());
        Assert.assertEquals("Finish time incorrect after decoding old history file", NZIWUYGONV, COARBNRLNZ.getFinishTime());
        Assert.assertEquals("Num maps incorrect after decoding old history file", FLKMWLJRYV, COARBNRLNZ.getNumMaps());
        Assert.assertEquals("Num reduces incorrect after decoding old history file", AEBOXYVDOS, COARBNRLNZ.getNumReduces());
        Assert.assertEquals("Job status incorrect after decoding old history file", TestFileNameIndexUtils.AOUQTMQDLZ, COARBNRLNZ.getJobStatus());
        Assert.assertNull("Queue name incorrect after decoding old history file", COARBNRLNZ.getQueueName());
    }
}