/**
 * Get a listing of all files in that match the file patterns.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
class Ls extends FsCommand {
    public static void registerCommands(CommandFactory MXYRDHHCXV) {
        MXYRDHHCXV.addClass(Ls.class, "-ls");
        MXYRDHHCXV.addClass(Ls.Lsr.class, "-lsr");
    }

    public static final String JWZZUEGISO = "ls";

    public static final String WWJSDULCNT = "[-d] [-h] [-R] [<path> ...]";

    public static final String ZSOYJRKJWK = "List the contents that match the specified file pattern. If " + (((((((("path is not specified, the contents of /user/<currentUser> " + "will be listed. Directory entries are of the form:\n") + "\tpermissions - userId groupId sizeOfDirectory(in bytes) modificationDate(yyyy-MM-dd HH:mm) directoryName\n\n") + "and file entries are of the form:\n") + "\tpermissions numberOfReplicas userId groupId sizeOfFile(in bytes) modificationDate(yyyy-MM-dd HH:mm) fileName\n") + "-d:  Directories are listed as plain files.\n") + "-h:  Formats the sizes of files in a human-readable fashion ") + "rather than a number of bytes.\n") + "-R:  Recursively list the contents of directories.");

    protected static final SimpleDateFormat UMRPDNQPRH = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    protected int ZUILOQCBMA = 3;

    protected int NCRZNCLKBE = 10;

    protected int AUPQGLRUID = 0;

    protected int XIRRRQFSHY = 0;

    protected String LOPLANLCCK;

    protected boolean LQWCTSMHTP;

    protected boolean PCMLWELHFD = false;

    protected String formatSize(long RYJTGYTQOL) {
        return PCMLWELHFD ? TraditionalBinaryPrefix.long2String(RYJTGYTQOL, "", 1) : String.valueOf(RYJTGYTQOL);
    }

    @Override
    protected void processOptions(LinkedList<String> NTNBGKPLNF) throws IOException {
        CommandFormat YADDFTCCHB = new CommandFormat(0, Integer.MAX_VALUE, "d", "h", "R");
        YADDFTCCHB.parse(NTNBGKPLNF);
        LQWCTSMHTP = !YADDFTCCHB.getOpt("d");
        setRecursive(YADDFTCCHB.getOpt("R") && LQWCTSMHTP);
        PCMLWELHFD = YADDFTCCHB.getOpt("h");
        if (NTNBGKPLNF.isEmpty())
            NTNBGKPLNF.add(CUR_DIR);

    }

    @Override
    protected void processPathArgument(PathData RSGTAQUVEH) throws IOException {
        // implicitly recurse once for cmdline directories
        if (LQWCTSMHTP && RSGTAQUVEH.stat.isDirectory()) {
            recursePath(RSGTAQUVEH);
        } else {
            super.processPathArgument(RSGTAQUVEH);
        }
    }

    @Override
    protected void processPaths(PathData LCZQJCVFTL, PathData... VKDATREEHR) throws IOException {
        if (((LCZQJCVFTL != null) && (!isRecursive())) && (VKDATREEHR.length != 0)) {
            out.println(("Found " + VKDATREEHR.length) + " items");
        }
        adjustColumnWidths(VKDATREEHR);
        super.processPaths(LCZQJCVFTL, VKDATREEHR);
    }

    @Override
    protected void processPath(PathData YZEVNBLTOK) throws IOException {
        FileStatus SOCFOMMJDQ = YZEVNBLTOK.stat;
        String YJZDEIHXLR = String.format(LOPLANLCCK, SOCFOMMJDQ.isDirectory() ? "d" : "-", SOCFOMMJDQ.getPermission() + (SOCFOMMJDQ.getPermission().getAclBit() ? "+" : " "), SOCFOMMJDQ.isFile() ? SOCFOMMJDQ.getReplication() : "-", SOCFOMMJDQ.getOwner(), SOCFOMMJDQ.getGroup(), formatSize(SOCFOMMJDQ.getLen()), Ls.UMRPDNQPRH.format(new Date(SOCFOMMJDQ.getModificationTime())), YZEVNBLTOK);
        out.println(YJZDEIHXLR);
    }

    /**
     * Compute column widths and rebuild the format string
     *
     * @param items
     * 		to find the max field width for each column
     */
    private void adjustColumnWidths(PathData[] YKNWWMLCSQ) {
        for (PathData DPDAEGCJAB : YKNWWMLCSQ) {
            FileStatus RULSSGGVJQ = DPDAEGCJAB.stat;
            ZUILOQCBMA = maxLength(ZUILOQCBMA, RULSSGGVJQ.getReplication());
            NCRZNCLKBE = maxLength(NCRZNCLKBE, RULSSGGVJQ.getLen());
            AUPQGLRUID = maxLength(AUPQGLRUID, RULSSGGVJQ.getOwner());
            XIRRRQFSHY = maxLength(XIRRRQFSHY, RULSSGGVJQ.getGroup());
        }
        StringBuilder HQOVQVSEST = new StringBuilder();
        HQOVQVSEST.append("%s%s");// permission string

        HQOVQVSEST.append(("%" + ZUILOQCBMA) + "s ");
        // Do not use '%-0s' as a formatting conversion, since it will throw a
        // a MissingFormatWidthException if it is used in String.format().
        // http://docs.oracle.com/javase/1.5.0/docs/api/java/util/Formatter.html#intFlags
        HQOVQVSEST.append(AUPQGLRUID > 0 ? ("%-" + AUPQGLRUID) + "s " : "%s");
        HQOVQVSEST.append(XIRRRQFSHY > 0 ? ("%-" + XIRRRQFSHY) + "s " : "%s");
        HQOVQVSEST.append(("%" + NCRZNCLKBE) + "s ");
        HQOVQVSEST.append("%s %s");// mod time & path

        LOPLANLCCK = HQOVQVSEST.toString();
    }

    private int maxLength(int RDLEFUKZHZ, Object HPMSYQAHKR) {
        return Math.max(RDLEFUKZHZ, HPMSYQAHKR != null ? String.valueOf(HPMSYQAHKR).length() : 0);
    }

    /**
     * Get a recursive listing of all files in that match the file patterns.
     * Same as "-ls -R"
     */
    public static class Lsr extends Ls {
        public static final String OQJVDYRKIQ = "lsr";

        @Override
        protected void processOptions(LinkedList<String> args) throws IOException {
            args.addFirst("-R");
            super.processOptions(args);
        }

        @Override
        public String getReplacementCommand() {
            return "ls -R";
        }
    }
}