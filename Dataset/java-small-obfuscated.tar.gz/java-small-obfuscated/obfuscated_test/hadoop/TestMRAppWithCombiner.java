@SuppressWarnings("deprecation")
public class TestMRAppWithCombiner {
    protected static MiniMRYarnCluster WWUAXYIXTD;

    private static Configuration ODQWGOLEJA = new Configuration();

    private static FileSystem ETUMFLQQGH;

    private static final Log JEAYLQPWJQ = LogFactory.getLog(TestMRAppWithCombiner.class);

    static {
        try {
            TestMRAppWithCombiner.ETUMFLQQGH = FileSystem.getLocal(TestMRAppWithCombiner.ODQWGOLEJA);
        } catch (IOException io) {
            throw new RuntimeException("problem getting local fs", io);
        }
    }

    @BeforeClass
    public static void setup() throws IOException {
        if (!new File(MiniMRYarnCluster.APPJAR).exists()) {
            TestMRAppWithCombiner.JEAYLQPWJQ.info(("MRAppJar " + MiniMRYarnCluster.APPJAR) + " not found. Not running test.");
            return;
        }
        if (TestMRAppWithCombiner.WWUAXYIXTD == null) {
            TestMRAppWithCombiner.WWUAXYIXTD = new MiniMRYarnCluster(TestMRJobs.class.getName(), 3);
            Configuration QQJSGHKYBW = new Configuration();
            TestMRAppWithCombiner.WWUAXYIXTD.init(QQJSGHKYBW);
            TestMRAppWithCombiner.WWUAXYIXTD.start();
        }
        // Copy MRAppJar and make it private. TODO: FIXME. This is a hack to
        // workaround the absent public discache.
        TestMRAppWithCombiner.ETUMFLQQGH.copyFromLocalFile(new Path(MiniMRYarnCluster.APPJAR), APP_JAR);
        TestMRAppWithCombiner.ETUMFLQQGH.setPermission(APP_JAR, new FsPermission("700"));
    }

    @AfterClass
    public static void tearDown() {
        if (TestMRAppWithCombiner.WWUAXYIXTD != null) {
            TestMRAppWithCombiner.WWUAXYIXTD.stop();
            TestMRAppWithCombiner.WWUAXYIXTD = null;
        }
    }

    @Test
    public void testCombinerShouldUpdateTheReporter() throws Exception {
        JobConf PUQULOLUOH = new JobConf(TestMRAppWithCombiner.WWUAXYIXTD.getConfig());
        int TRTPZPEFDZ = 5;
        int YBXGFWIBLB = 2;
        Path FNHHAPNKVT = new Path(TestMRAppWithCombiner.WWUAXYIXTD.getTestWorkDir().getAbsolutePath(), "testCombinerShouldUpdateTheReporter-in");
        Path HQIDDYGQQI = new Path(TestMRAppWithCombiner.WWUAXYIXTD.getTestWorkDir().getAbsolutePath(), "testCombinerShouldUpdateTheReporter-out");
        TestMRAppWithCombiner.createInputOutPutFolder(FNHHAPNKVT, HQIDDYGQQI, TRTPZPEFDZ);
        PUQULOLUOH.setJobName("test-job-with-combiner");
        PUQULOLUOH.setMapperClass(IdentityMapper.class);
        PUQULOLUOH.setCombinerClass(TestMRAppWithCombiner.MyCombinerToCheckReporter.class);
        // conf.setJarByClass(MyCombinerToCheckReporter.class);
        PUQULOLUOH.setReducerClass(IdentityReducer.class);
        DistributedCache.addFileToClassPath(APP_JAR, PUQULOLUOH);
        PUQULOLUOH.setOutputCommitter(CustomOutputCommitter.class);
        PUQULOLUOH.setInputFormat(TextInputFormat.class);
        PUQULOLUOH.setOutputKeyClass(LongWritable.class);
        PUQULOLUOH.setOutputValueClass(Text.class);
        FileInputFormat.setInputPaths(PUQULOLUOH, FNHHAPNKVT);
        FileOutputFormat.setOutputPath(PUQULOLUOH, HQIDDYGQQI);
        PUQULOLUOH.setNumMapTasks(TRTPZPEFDZ);
        PUQULOLUOH.setNumReduceTasks(YBXGFWIBLB);
        TestMRAppWithCombiner.runJob(PUQULOLUOH);
    }

    static void createInputOutPutFolder(Path MVXNJSVTYC, Path TXRSDXACJA, int AURXRRIFVG) throws Exception {
        FileSystem OPVUPHRZKD = FileSystem.get(TestMRAppWithCombiner.ODQWGOLEJA);
        if (OPVUPHRZKD.exists(TXRSDXACJA)) {
            OPVUPHRZKD.delete(TXRSDXACJA, true);
        }
        if (!OPVUPHRZKD.exists(MVXNJSVTYC)) {
            OPVUPHRZKD.mkdirs(MVXNJSVTYC);
        }
        String CIKLYYMCCX = "The quick brown fox\n" + ("has many silly\n" + "red fox sox\n");
        for (int YHGUYVPMBD = 0; YHGUYVPMBD < AURXRRIFVG; ++YHGUYVPMBD) {
            DataOutputStream LZVOTNNIYQ = OPVUPHRZKD.create(new Path(MVXNJSVTYC, "part-" + YHGUYVPMBD));
            LZVOTNNIYQ.writeBytes(CIKLYYMCCX);
            LZVOTNNIYQ.close();
        }
    }

    static boolean runJob(JobConf XQJLBEUZTU) throws Exception {
        JobClient TGNPKCTCKN = new JobClient(XQJLBEUZTU);
        RunningJob WYPNOGKEXB = TGNPKCTCKN.submitJob(XQJLBEUZTU);
        return TGNPKCTCKN.monitorAndPrintJob(XQJLBEUZTU, WYPNOGKEXB);
    }

    class MyCombinerToCheckReporter<K, V> extends IdentityReducer<K, V> {
        public void reduce(K key, Iterator<V> values, OutputCollector<K, V> output, Reporter reporter) throws IOException {
            if (Reporter.NULL == reporter) {
                Assert.fail("A valid Reporter should have been used but, Reporter.NULL is used");
            }
        }
    }
}