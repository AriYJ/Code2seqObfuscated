/**
 * This exception is thrown by ResourceManager if it's loading an incompatible
 * version of state from state store on recovery.
 */
public class RMStateVersionIncompatibleException extends YarnException {
    private static final long OLDIQKKJVN = 1364408L;

    public RMStateVersionIncompatibleException(Throwable APLJJBMILK) {
        super(APLJJBMILK);
    }

    public RMStateVersionIncompatibleException(String POLNNIJFUK) {
        super(POLNNIJFUK);
    }

    public RMStateVersionIncompatibleException(String KGYUSWXAKR, Throwable OBYKZVZNIW) {
        super(KGYUSWXAKR, OBYKZVZNIW);
    }
}