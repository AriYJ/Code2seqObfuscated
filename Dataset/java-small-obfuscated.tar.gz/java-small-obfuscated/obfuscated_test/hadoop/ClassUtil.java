@InterfaceAudience.Private
public class ClassUtil {
    /**
     * Find a jar that contains a class of the same name, if any.
     * It will return a jar file, even if that is not the first thing
     * on the class path that has a class with the same name.
     *
     * @param clazz
     * 		the class to find.
     * @return a jar file that contains the class, or null.
     * @throws IOException
     * 		
     */
    public static String findContainingJar(Class<?> DUAKFLWUAW) {
        ClassLoader AMCYHKGIFK = DUAKFLWUAW.getClassLoader();
        String LHPIDBRQAC = DUAKFLWUAW.getName().replaceAll("\\.", "/") + ".class";
        try {
            for (final Enumeration<URL> MTSMPXQHID = AMCYHKGIFK.getResources(LHPIDBRQAC); MTSMPXQHID.hasMoreElements();) {
                final URL ZHEDYGNSAY = MTSMPXQHID.nextElement();
                if ("jar".equals(ZHEDYGNSAY.getProtocol())) {
                    String RYUAMUCKQL = ZHEDYGNSAY.getPath();
                    if (RYUAMUCKQL.startsWith("file:")) {
                        RYUAMUCKQL = RYUAMUCKQL.substring("file:".length());
                    }
                    RYUAMUCKQL = URLDecoder.decode(RYUAMUCKQL, "UTF-8");
                    return RYUAMUCKQL.replaceAll("!.*$", "");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
}