/**
 * Tests snapshot deletion.
 */
public class TestSnapshotDeletion {
    protected static final long ZEYLXCEMSK = 0;

    protected static final short RKWXJYWJHQ = 3;

    protected static final short LAXZFQHRKV = 2;

    protected static final long LIRRTWIVQU = 1024;

    private final Path QRMQKTOSCR = new Path("/TestSnapshot");

    private final Path XHNRQOMIBU = new Path(QRMQKTOSCR, "sub1");

    private final Path WIHUITOUKJ = new Path(XHNRQOMIBU, "subsub1");

    protected Configuration WRRTENSDKC;

    protected MiniDFSCluster BODFFKCFZY;

    protected FSNamesystem XVHVMUWEDD;

    protected FSDirectory GKFUQGFBYD;

    protected BlockManager JHOXUECNUP;

    protected DistributedFileSystem JEKHARZUCY;

    @Rule
    public ExpectedException EWYQTXGZWA = ExpectedException.none();

    @Before
    public void setUp() throws Exception {
        WRRTENSDKC = new Configuration();
        BODFFKCFZY = new MiniDFSCluster.Builder(WRRTENSDKC).numDataNodes(TestSnapshotDeletion.RKWXJYWJHQ).format(true).build();
        BODFFKCFZY.waitActive();
        XVHVMUWEDD = BODFFKCFZY.getNamesystem();
        GKFUQGFBYD = XVHVMUWEDD.getFSDirectory();
        JHOXUECNUP = XVHVMUWEDD.getBlockManager();
        JEKHARZUCY = BODFFKCFZY.getFileSystem();
    }

    @After
    public void tearDown() throws Exception {
        if (BODFFKCFZY != null) {
            BODFFKCFZY.shutdown();
        }
    }

    /**
     * Deleting snapshottable directory with snapshots must fail.
     */
    @Test(timeout = 300000)
    public void testDeleteDirectoryWithSnapshot() throws Exception {
        Path MPSMAUGTMW = new Path(XHNRQOMIBU, "file0");
        Path EZEMOGHQVL = new Path(XHNRQOMIBU, "file1");
        DFSTestUtil.createFile(JEKHARZUCY, MPSMAUGTMW, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, EZEMOGHQVL, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        // Allow snapshot for sub1, and create snapshot for it
        JEKHARZUCY.allowSnapshot(XHNRQOMIBU);
        JEKHARZUCY.createSnapshot(XHNRQOMIBU, "s1");
        // Deleting a snapshottable dir with snapshots should fail
        EWYQTXGZWA.expect(RemoteException.class);
        String XSTUZYPOPD = ((("The directory " + XHNRQOMIBU.toString()) + " cannot be deleted since ") + XHNRQOMIBU.toString()) + " is snapshottable and already has snapshots";
        EWYQTXGZWA.expectMessage(XSTUZYPOPD);
        JEKHARZUCY.delete(XHNRQOMIBU, true);
    }

    /**
     * Test applying editlog of operation which deletes a snapshottable directory
     * without snapshots. The snapshottable dir list in snapshot manager should be
     * updated.
     */
    @Test(timeout = 300000)
    public void testApplyEditLogForDeletion() throws Exception {
        final Path MNPZRBOSXB = new Path("/foo");
        final Path QPZAWTSUJT = new Path(MNPZRBOSXB, "bar1");
        final Path MLFKLCISLG = new Path(MNPZRBOSXB, "bar2");
        JEKHARZUCY.mkdirs(QPZAWTSUJT);
        JEKHARZUCY.mkdirs(MLFKLCISLG);
        // allow snapshots on bar1 and bar2
        JEKHARZUCY.allowSnapshot(QPZAWTSUJT);
        JEKHARZUCY.allowSnapshot(MLFKLCISLG);
        assertEquals(2, BODFFKCFZY.getNamesystem().getSnapshotManager().getNumSnapshottableDirs());
        assertEquals(2, BODFFKCFZY.getNamesystem().getSnapshotManager().getSnapshottableDirs().length);
        // delete /foo
        JEKHARZUCY.delete(MNPZRBOSXB, true);
        BODFFKCFZY.restartNameNode(0);
        // the snapshottable dir list in snapshot manager should be empty
        assertEquals(0, BODFFKCFZY.getNamesystem().getSnapshotManager().getNumSnapshottableDirs());
        assertEquals(0, BODFFKCFZY.getNamesystem().getSnapshotManager().getSnapshottableDirs().length);
        JEKHARZUCY.setSafeMode(SAFEMODE_ENTER);
        JEKHARZUCY.saveNamespace();
        JEKHARZUCY.setSafeMode(SAFEMODE_LEAVE);
        BODFFKCFZY.restartNameNode(0);
    }

    /**
     * Deleting directory with snapshottable descendant with snapshots must fail.
     */
    @Test(timeout = 300000)
    public void testDeleteDirectoryWithSnapshot2() throws Exception {
        Path UPTOGSSLQK = new Path(XHNRQOMIBU, "file0");
        Path YVRWWWZDKQ = new Path(XHNRQOMIBU, "file1");
        DFSTestUtil.createFile(JEKHARZUCY, UPTOGSSLQK, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, YVRWWWZDKQ, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        Path LMQJBRQLNJ = new Path(WIHUITOUKJ, "file0");
        Path PLMAYGVYUR = new Path(WIHUITOUKJ, "file1");
        DFSTestUtil.createFile(JEKHARZUCY, LMQJBRQLNJ, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, PLMAYGVYUR, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        // Allow snapshot for subsub1, and create snapshot for it
        JEKHARZUCY.allowSnapshot(WIHUITOUKJ);
        JEKHARZUCY.createSnapshot(WIHUITOUKJ, "s1");
        // Deleting dir while its descedant subsub1 having snapshots should fail
        EWYQTXGZWA.expect(RemoteException.class);
        String FCOYZKFAAA = WIHUITOUKJ.toString() + " is snapshottable and already has snapshots";
        EWYQTXGZWA.expectMessage(FCOYZKFAAA);
        JEKHARZUCY.delete(QRMQKTOSCR, true);
    }

    private static INodeDirectory getDir(final FSDirectory HIIKBWELLB, final Path AOPCQJUHAN) throws IOException {
        final String YZDXCPCRFT = AOPCQJUHAN.toString();
        return INodeDirectory.valueOf(HIIKBWELLB.getINode(YZDXCPCRFT), YZDXCPCRFT);
    }

    private void checkQuotaUsageComputation(final Path FRFDIJVLAB, final long HAJDJMOXLK, final long RDEHLZWMIV) throws IOException {
        INodeDirectory YHXUYNUYBN = TestSnapshotDeletion.getDir(GKFUQGFBYD, FRFDIJVLAB);
        assertTrue(YHXUYNUYBN.isQuotaSet());
        Quota.Counts DUUFDKRABO = YHXUYNUYBN.getDirectoryWithQuotaFeature().getSpaceConsumed();
        assertEquals(YHXUYNUYBN.dumpTreeRecursively().toString(), HAJDJMOXLK, DUUFDKRABO.get(NAMESPACE));
        assertEquals(YHXUYNUYBN.dumpTreeRecursively().toString(), RDEHLZWMIV, DUUFDKRABO.get(DISKSPACE));
        Quota.Counts AKJJELZXXH = Counts.newInstance();
        YHXUYNUYBN.computeQuotaUsage(AKJJELZXXH, false);
        assertEquals(YHXUYNUYBN.dumpTreeRecursively().toString(), HAJDJMOXLK, AKJJELZXXH.get(NAMESPACE));
        assertEquals(YHXUYNUYBN.dumpTreeRecursively().toString(), RDEHLZWMIV, AKJJELZXXH.get(DISKSPACE));
    }

    /**
     * Test deleting a directory which is a descendant of a snapshottable
     * directory. In the test we need to cover the following cases:
     *
     * <pre>
     * 1. Delete current INodeFile/INodeDirectory without taking any snapshot.
     * 2. Delete current INodeFile/INodeDirectory while snapshots have been taken
     *    on ancestor(s).
     * 3. Delete current INodeFileWithSnapshot.
     * 4. Delete current INodeDirectoryWithSnapshot.
     * </pre>
     */
    @Test(timeout = 300000)
    public void testDeleteCurrentFileDirectory() throws Exception {
        // create a folder which will be deleted before taking snapshots
        Path OCAQGYGWIM = new Path(WIHUITOUKJ, "deleteDir");
        Path YAMVGHZFVS = new Path(OCAQGYGWIM, "deleteFile");
        // create a directory that we will not change during the whole process.
        Path SCBTYAUHKQ = new Path(XHNRQOMIBU, "noChangeDirParent");
        Path ZWFYFBDEJL = new Path(SCBTYAUHKQ, "noChangeDir");
        // create a file that we will not change in the future
        Path NMPSTILYBJ = new Path(ZWFYFBDEJL, "noChangeFile");
        DFSTestUtil.createFile(JEKHARZUCY, YAMVGHZFVS, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, NMPSTILYBJ, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        // we will change this file's metadata in the future
        Path QPFETWFSPP = new Path(WIHUITOUKJ, "metaChangeFile1");
        DFSTestUtil.createFile(JEKHARZUCY, QPFETWFSPP, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        // another file, created under noChangeDir, whose metadata will be changed
        Path CBGHQGRKUN = new Path(ZWFYFBDEJL, "metaChangeFile2");
        DFSTestUtil.createFile(JEKHARZUCY, CBGHQGRKUN, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        // Case 1: delete deleteDir before taking snapshots
        JEKHARZUCY.delete(OCAQGYGWIM, true);
        // create snapshot s0
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, QRMQKTOSCR, "s0");
        // after creating snapshot s0, create a directory tempdir under dir and then
        // delete dir immediately
        Path FSUVISHCSZ = new Path(QRMQKTOSCR, "tempdir");
        Path WHBVVVHHDF = new Path(FSUVISHCSZ, "tempfile");
        DFSTestUtil.createFile(JEKHARZUCY, WHBVVVHHDF, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        final INodeFile NPLBUVCWII = TestSnapshotBlocksMap.assertBlockCollection(WHBVVVHHDF.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        BlockInfo[] UAMQMEPKAA = NPLBUVCWII.getBlocks();
        JEKHARZUCY.delete(FSUVISHCSZ, true);
        // check dir's quota usage
        checkQuotaUsageComputation(QRMQKTOSCR, 9L, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 3);
        // check blocks of tempFile
        for (BlockInfo LFPOPGXOEF : UAMQMEPKAA) {
            assertNull(JHOXUECNUP.getBlockCollection(LFPOPGXOEF));
        }
        // make a change: create a new file under subsub
        Path KEXUQDTHJK = new Path(WIHUITOUKJ, "newFile");
        DFSTestUtil.createFile(JEKHARZUCY, KEXUQDTHJK, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        // further change: change the replicator factor of metaChangeFile
        JEKHARZUCY.setReplication(QPFETWFSPP, TestSnapshotDeletion.LAXZFQHRKV);
        JEKHARZUCY.setReplication(CBGHQGRKUN, TestSnapshotDeletion.LAXZFQHRKV);
        // create snapshot s1
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, QRMQKTOSCR, "s1");
        // check dir's quota usage
        checkQuotaUsageComputation(QRMQKTOSCR, 14L, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 4);
        // get two snapshots for later use
        Snapshot DHGQKHPZIJ = GKFUQGFBYD.getINode(QRMQKTOSCR.toString()).asDirectory().getSnapshot(DFSUtil.string2Bytes("s0"));
        Snapshot QOWHTOHMGQ = GKFUQGFBYD.getINode(QRMQKTOSCR.toString()).asDirectory().getSnapshot(DFSUtil.string2Bytes("s1"));
        // Case 2 + Case 3: delete noChangeDirParent, noChangeFile, and
        // metaChangeFile2. Note that when we directly delete a directory, the
        // directory will be converted to an INodeDirectoryWithSnapshot. To make
        // sure the deletion goes through an INodeDirectory, we delete the parent
        // of noChangeDir
        JEKHARZUCY.delete(SCBTYAUHKQ, true);
        // while deletion, we add a diff for metaChangeFile2 as its snapshot copy
        // for s1, we also add diffs for both sub and noChangeDirParent
        checkQuotaUsageComputation(QRMQKTOSCR, 17L, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 4);
        // check the snapshot copy of noChangeDir
        Path EMULYORFLX = SnapshotTestHelper.getSnapshotPath(QRMQKTOSCR, "s1", (((XHNRQOMIBU.getName() + "/") + SCBTYAUHKQ.getName()) + "/") + ZWFYFBDEJL.getName());
        INodeDirectory UORODUHCLR = ((INodeDirectory) (GKFUQGFBYD.getINode(EMULYORFLX.toString())));
        // should still be an INodeDirectory
        assertEquals(INodeDirectory.class, UORODUHCLR.getClass());
        ReadOnlyList<INode> ITTLQYNTQK = UORODUHCLR.getChildrenList(CURRENT_STATE_ID);
        // check 2 children: noChangeFile and metaChangeFile2
        assertEquals(2, ITTLQYNTQK.size());
        INode YGPDLGYTJQ = ITTLQYNTQK.get(1);
        assertEquals(NMPSTILYBJ.getName(), YGPDLGYTJQ.getLocalName());
        assertEquals(INodeFile.class, YGPDLGYTJQ.getClass());
        TestSnapshotBlocksMap.assertBlockCollection(new Path(EMULYORFLX, YGPDLGYTJQ.getLocalName()).toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        INodeFile DDJZFWLMOW = ITTLQYNTQK.get(0).asFile();
        assertEquals(CBGHQGRKUN.getName(), DDJZFWLMOW.getLocalName());
        assertTrue(DDJZFWLMOW.isWithSnapshot());
        assertFalse(DDJZFWLMOW.isUnderConstruction());
        TestSnapshotBlocksMap.assertBlockCollection(new Path(EMULYORFLX, DDJZFWLMOW.getLocalName()).toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        // check the replication factor of metaChangeFile2SCopy
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, DDJZFWLMOW.getFileReplication(CURRENT_STATE_ID));
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, DDJZFWLMOW.getFileReplication(QOWHTOHMGQ.getId()));
        assertEquals(TestSnapshotDeletion.RKWXJYWJHQ, DDJZFWLMOW.getFileReplication(DHGQKHPZIJ.getId()));
        // Case 4: delete directory sub
        // before deleting sub, we first create a new file under sub
        Path JRAYWZNBUR = new Path(XHNRQOMIBU, "newFile");
        DFSTestUtil.createFile(JEKHARZUCY, JRAYWZNBUR, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        final INodeFile TCBIWJYTCQ = TestSnapshotBlocksMap.assertBlockCollection(JRAYWZNBUR.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        UAMQMEPKAA = TCBIWJYTCQ.getBlocks();
        checkQuotaUsageComputation(QRMQKTOSCR, 18L, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 5);
        JEKHARZUCY.delete(XHNRQOMIBU, true);
        // while deletion, we add diff for subsub and metaChangeFile1, and remove
        // newFile
        checkQuotaUsageComputation(QRMQKTOSCR, 19L, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 4);
        for (BlockInfo COOSHXVABG : UAMQMEPKAA) {
            assertNull(JHOXUECNUP.getBlockCollection(COOSHXVABG));
        }
        // make sure the whole subtree of sub is stored correctly in snapshot
        Path GWZTRFDTRD = SnapshotTestHelper.getSnapshotPath(QRMQKTOSCR, "s1", XHNRQOMIBU.getName());
        INodeDirectory ZRGSHKOEXM = GKFUQGFBYD.getINode(GWZTRFDTRD.toString()).asDirectory();
        assertTrue(ZRGSHKOEXM.isWithSnapshot());
        // the snapshot copy of sub has only one child subsub.
        // newFile should have been destroyed
        assertEquals(1, ZRGSHKOEXM.getChildrenList(CURRENT_STATE_ID).size());
        // but should have two children, subsub and noChangeDir, when s1 was taken
        assertEquals(2, ZRGSHKOEXM.getChildrenList(QOWHTOHMGQ.getId()).size());
        // check the snapshot copy of subsub, which is contained in the subtree of
        // sub's snapshot copy
        INode PTTNOHASMK = ZRGSHKOEXM.getChildrenList(CURRENT_STATE_ID).get(0);
        assertTrue(PTTNOHASMK.asDirectory().isWithSnapshot());
        assertTrue(ZRGSHKOEXM == PTTNOHASMK.getParent());
        // check the children of subsub
        INodeDirectory XOGNBZTISQ = ((INodeDirectory) (PTTNOHASMK));
        ITTLQYNTQK = XOGNBZTISQ.getChildrenList(CURRENT_STATE_ID);
        assertEquals(2, ITTLQYNTQK.size());
        assertEquals(ITTLQYNTQK.get(0).getLocalName(), QPFETWFSPP.getName());
        assertEquals(ITTLQYNTQK.get(1).getLocalName(), KEXUQDTHJK.getName());
        // only one child before snapshot s0
        ITTLQYNTQK = XOGNBZTISQ.getChildrenList(DHGQKHPZIJ.getId());
        assertEquals(1, ITTLQYNTQK.size());
        INode CNPEGXYYKX = ITTLQYNTQK.get(0);
        assertEquals(CNPEGXYYKX.getLocalName(), QPFETWFSPP.getName());
        // check snapshot copy of metaChangeFile1
        INodeFile OAOVIBGCXY = CNPEGXYYKX.asFile();
        assertTrue(OAOVIBGCXY.isWithSnapshot());
        assertFalse(OAOVIBGCXY.isUnderConstruction());
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, OAOVIBGCXY.getFileReplication(CURRENT_STATE_ID));
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, OAOVIBGCXY.getFileReplication(QOWHTOHMGQ.getId()));
        assertEquals(TestSnapshotDeletion.RKWXJYWJHQ, OAOVIBGCXY.getFileReplication(DHGQKHPZIJ.getId()));
    }

    /**
     * Test deleting the earliest (first) snapshot. In this simplest scenario, the
     * snapshots are taken on the same directory, and we do not need to combine
     * snapshot diffs.
     */
    @Test(timeout = 300000)
    public void testDeleteEarliestSnapshot1() throws Exception {
        // create files under sub
        Path MTKCHXYFXC = new Path(XHNRQOMIBU, "file0");
        Path MGIMWDDQQQ = new Path(XHNRQOMIBU, "file1");
        DFSTestUtil.createFile(JEKHARZUCY, MTKCHXYFXC, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, MGIMWDDQQQ, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        String CLMSMFOZOY = "s1";
        try {
            JEKHARZUCY.deleteSnapshot(XHNRQOMIBU, CLMSMFOZOY);
            fail(("SnapshotException expected: " + XHNRQOMIBU.toString()) + " is not snapshottable yet");
        } catch (Exception e) {
            GenericTestUtils.assertExceptionContains("Directory is not a snapshottable directory: " + XHNRQOMIBU, e);
        }
        // make sub snapshottable
        JEKHARZUCY.allowSnapshot(XHNRQOMIBU);
        try {
            JEKHARZUCY.deleteSnapshot(XHNRQOMIBU, CLMSMFOZOY);
            fail((("SnapshotException expected: snapshot " + CLMSMFOZOY) + " does not exist for ") + XHNRQOMIBU.toString());
        } catch (Exception e) {
            GenericTestUtils.assertExceptionContains(((("Cannot delete snapshot " + CLMSMFOZOY) + " from path ") + XHNRQOMIBU.toString()) + ": the snapshot does not exist.", e);
        }
        // create snapshot s1 for sub
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, XHNRQOMIBU, CLMSMFOZOY);
        // check quota usage computation
        checkQuotaUsageComputation(XHNRQOMIBU, 4, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 2);
        // delete s1
        JEKHARZUCY.deleteSnapshot(XHNRQOMIBU, CLMSMFOZOY);
        checkQuotaUsageComputation(XHNRQOMIBU, 3, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 2);
        // now we can create a snapshot with the same name
        JEKHARZUCY.createSnapshot(XHNRQOMIBU, CLMSMFOZOY);
        checkQuotaUsageComputation(XHNRQOMIBU, 4, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 2);
        // create a new file under sub
        Path QWDCOURBVR = new Path(XHNRQOMIBU, "newFile");
        DFSTestUtil.createFile(JEKHARZUCY, QWDCOURBVR, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        // create another snapshot s2
        String ZCJQGSIPNY = "s2";
        JEKHARZUCY.createSnapshot(XHNRQOMIBU, ZCJQGSIPNY);
        checkQuotaUsageComputation(XHNRQOMIBU, 6, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 3);
        // Get the filestatus of sub under snapshot s2
        Path IFDKYOTXTI = SnapshotTestHelper.getSnapshotPath(XHNRQOMIBU, ZCJQGSIPNY, "newFile");
        FileStatus BYCNKNTLJD = JEKHARZUCY.getFileStatus(IFDKYOTXTI);
        // delete s1
        JEKHARZUCY.deleteSnapshot(XHNRQOMIBU, CLMSMFOZOY);
        checkQuotaUsageComputation(XHNRQOMIBU, 5, (TestSnapshotDeletion.LIRRTWIVQU * TestSnapshotDeletion.RKWXJYWJHQ) * 3);
        FileStatus XKAOVRWVJB = JEKHARZUCY.getFileStatus(IFDKYOTXTI);
        System.out.println(((("Before deletion: " + BYCNKNTLJD.toString()) + "\n") + "After deletion: ") + XKAOVRWVJB.toString());
        assertEquals(BYCNKNTLJD.toString(), XKAOVRWVJB.toString());
    }

    /**
     * Test deleting the earliest (first) snapshot. In this more complicated
     * scenario, the snapshots are taken across directories.
     * <pre>
     * The test covers the following scenarios:
     * 1. delete the first diff in the diff list of a directory
     * 2. delete the first diff in the diff list of a file
     * </pre>
     * Also, the recursive cleanTree process should cover both INodeFile and
     * INodeDirectory.
     */
    @Test(timeout = 300000)
    public void testDeleteEarliestSnapshot2() throws Exception {
        Path PHAJVDMRFG = new Path(XHNRQOMIBU, "noChangeDir");
        Path ZRXGXXWRHF = new Path(PHAJVDMRFG, "noChangeFile");
        Path VOIDMRMBDI = new Path(PHAJVDMRFG, "metaChangeFile");
        Path UXYOGCXXAH = new Path(PHAJVDMRFG, "metaChangeDir");
        Path XNESBGIIQT = new Path(UXYOGCXXAH, "toDeleteFile");
        DFSTestUtil.createFile(JEKHARZUCY, ZRXGXXWRHF, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, VOIDMRMBDI, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, XNESBGIIQT, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        final INodeFile AIIPDCGMQR = TestSnapshotBlocksMap.assertBlockCollection(XNESBGIIQT.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        BlockInfo[] JDOWIBSZDN = AIIPDCGMQR.getBlocks();
        // create snapshot s0 on dir
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, QRMQKTOSCR, "s0");
        checkQuotaUsageComputation(QRMQKTOSCR, 8, (3 * TestSnapshotDeletion.LIRRTWIVQU) * TestSnapshotDeletion.RKWXJYWJHQ);
        // delete /TestSnapshot/sub/noChangeDir/metaChangeDir/toDeleteFile
        JEKHARZUCY.delete(XNESBGIIQT, true);
        // the deletion adds diff of toDeleteFile and metaChangeDir
        checkQuotaUsageComputation(QRMQKTOSCR, 10, (3 * TestSnapshotDeletion.LIRRTWIVQU) * TestSnapshotDeletion.RKWXJYWJHQ);
        // change metadata of /TestSnapshot/sub/noChangeDir/metaChangeDir and
        // /TestSnapshot/sub/noChangeDir/metaChangeFile
        JEKHARZUCY.setReplication(VOIDMRMBDI, TestSnapshotDeletion.LAXZFQHRKV);
        JEKHARZUCY.setOwner(UXYOGCXXAH, "unknown", "unknown");
        checkQuotaUsageComputation(QRMQKTOSCR, 11, (3 * TestSnapshotDeletion.LIRRTWIVQU) * TestSnapshotDeletion.RKWXJYWJHQ);
        // create snapshot s1 on dir
        JEKHARZUCY.createSnapshot(QRMQKTOSCR, "s1");
        checkQuotaUsageComputation(QRMQKTOSCR, 12, (3 * TestSnapshotDeletion.LIRRTWIVQU) * TestSnapshotDeletion.RKWXJYWJHQ);
        // delete snapshot s0
        JEKHARZUCY.deleteSnapshot(QRMQKTOSCR, "s0");
        // namespace: remove toDeleteFile and its diff, metaChangeFile's diff,
        // metaChangeDir's diff, dir's diff. diskspace: remove toDeleteFile, and
        // metaChangeFile's replication factor decreases
        checkQuotaUsageComputation(QRMQKTOSCR, 7, ((2 * TestSnapshotDeletion.LIRRTWIVQU) * TestSnapshotDeletion.RKWXJYWJHQ) - TestSnapshotDeletion.LIRRTWIVQU);
        for (BlockInfo PMJRTEGSFX : JDOWIBSZDN) {
            assertNull(JHOXUECNUP.getBlockCollection(PMJRTEGSFX));
        }
        // check 1. there is no snapshot s0
        final INodeDirectory DZICZZSSFZ = GKFUQGFBYD.getINode(QRMQKTOSCR.toString()).asDirectory();
        Snapshot NZHKVIFIHJ = DZICZZSSFZ.getSnapshot(DFSUtil.string2Bytes("s0"));
        assertNull(NZHKVIFIHJ);
        Snapshot MMPOONLIJW = DZICZZSSFZ.getSnapshot(DFSUtil.string2Bytes("s1"));
        DirectoryDiffList HMMVCFBOOU = DZICZZSSFZ.getDiffs();
        assertEquals(1, HMMVCFBOOU.asList().size());
        assertEquals(MMPOONLIJW.getId(), HMMVCFBOOU.getLast().getSnapshotId());
        HMMVCFBOOU = GKFUQGFBYD.getINode(UXYOGCXXAH.toString()).asDirectory().getDiffs();
        assertEquals(0, HMMVCFBOOU.asList().size());
        // check 2. noChangeDir and noChangeFile are still there
        final INodeDirectory THYPFTXXCV = ((INodeDirectory) (GKFUQGFBYD.getINode(PHAJVDMRFG.toString())));
        assertEquals(INodeDirectory.class, THYPFTXXCV.getClass());
        final INodeFile TCWHXOAUYM = ((INodeFile) (GKFUQGFBYD.getINode(ZRXGXXWRHF.toString())));
        assertEquals(INodeFile.class, TCWHXOAUYM.getClass());
        TestSnapshotBlocksMap.assertBlockCollection(ZRXGXXWRHF.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        // check 3: current metadata of metaChangeFile and metaChangeDir
        FileStatus LZNEPQLAPD = JEKHARZUCY.getFileStatus(UXYOGCXXAH);
        assertEquals("unknown", LZNEPQLAPD.getOwner());
        assertEquals("unknown", LZNEPQLAPD.getGroup());
        LZNEPQLAPD = JEKHARZUCY.getFileStatus(VOIDMRMBDI);
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, LZNEPQLAPD.getReplication());
        TestSnapshotBlocksMap.assertBlockCollection(VOIDMRMBDI.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        // check 4: no snapshot copy for toDeleteFile
        try {
            LZNEPQLAPD = JEKHARZUCY.getFileStatus(XNESBGIIQT);
            fail("should throw FileNotFoundException");
        } catch (FileNotFoundException e) {
            GenericTestUtils.assertExceptionContains("File does not exist: " + XNESBGIIQT.toString(), e);
        }
        final Path ANRZLADUCM = SnapshotTestHelper.getSnapshotPath(QRMQKTOSCR, "s0", XNESBGIIQT.toString().substring(QRMQKTOSCR.toString().length()));
        try {
            LZNEPQLAPD = JEKHARZUCY.getFileStatus(ANRZLADUCM);
            fail("should throw FileNotFoundException");
        } catch (FileNotFoundException e) {
            GenericTestUtils.assertExceptionContains("File does not exist: " + ANRZLADUCM.toString(), e);
        }
    }

    /**
     * Test deleting snapshots in a more complicated scenario: need to combine
     * snapshot diffs, but no need to handle diffs distributed in a dir tree
     */
    @Test(timeout = 300000)
    public void testCombineSnapshotDiff1() throws Exception {
        testCombineSnapshotDiffImpl(XHNRQOMIBU, "", 1);
    }

    /**
     * Test deleting snapshots in more complicated scenarios (snapshot diffs are
     * distributed in the directory sub-tree)
     */
    @Test(timeout = 300000)
    public void testCombineSnapshotDiff2() throws Exception {
        testCombineSnapshotDiffImpl(XHNRQOMIBU, "subsub1/subsubsub1/", 3);
    }

    /**
     * When combine two snapshots, make sure files/directories created after the
     * prior snapshot get destroyed.
     */
    @Test(timeout = 300000)
    public void testCombineSnapshotDiff3() throws Exception {
        // create initial dir and subdir
        Path GUKORRNUZE = new Path("/dir");
        Path TYNTNNILLT = new Path(GUKORRNUZE, "subdir1");
        Path WUGOOELELE = new Path(GUKORRNUZE, "subdir2");
        JEKHARZUCY.mkdirs(WUGOOELELE);
        Path CPGROEIBSC = new Path(TYNTNNILLT, "subsubdir");
        JEKHARZUCY.mkdirs(CPGROEIBSC);
        // take snapshots on subdir and dir
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, GUKORRNUZE, "s1");
        // create new dir under initial dir
        Path TZQPDALDCP = new Path(CPGROEIBSC, "newdir");
        Path WHGQNUWCXN = new Path(TZQPDALDCP, "newfile");
        DFSTestUtil.createFile(JEKHARZUCY, WHGQNUWCXN, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        Path WJVJPUGDRJ = new Path(WUGOOELELE, "newfile");
        DFSTestUtil.createFile(JEKHARZUCY, WJVJPUGDRJ, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        // create another snapshot
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, GUKORRNUZE, "s2");
        checkQuotaUsageComputation(GUKORRNUZE, 11, (TestSnapshotDeletion.LIRRTWIVQU * 2) * TestSnapshotDeletion.RKWXJYWJHQ);
        // delete subsubdir and subDir2
        JEKHARZUCY.delete(CPGROEIBSC, true);
        JEKHARZUCY.delete(WUGOOELELE, true);
        // add diff of s2 to subDir1, subsubDir, and subDir2
        checkQuotaUsageComputation(GUKORRNUZE, 14, (TestSnapshotDeletion.LIRRTWIVQU * 2) * TestSnapshotDeletion.RKWXJYWJHQ);
        // delete snapshot s2
        JEKHARZUCY.deleteSnapshot(GUKORRNUZE, "s2");
        // delete s2 diff in dir, subDir2, and subsubDir. Delete newFile, newDir,
        // and newFile2. Rename s2 diff to s1 for subDir1
        checkQuotaUsageComputation(GUKORRNUZE, 8, 0);
        // Check rename of snapshot diff in subDir1
        Path DHDZAQCBIX = SnapshotTestHelper.getSnapshotPath(GUKORRNUZE, "s1", TYNTNNILLT.getName());
        Path LXYFPJTECS = SnapshotTestHelper.getSnapshotPath(GUKORRNUZE, "s2", TYNTNNILLT.getName());
        assertTrue(JEKHARZUCY.exists(DHDZAQCBIX));
        assertFalse(JEKHARZUCY.exists(LXYFPJTECS));
    }

    /**
     * Test snapshot deletion
     *
     * @param snapshotRoot
     * 		The dir where the snapshots are created
     * @param modDirStr
     * 		The snapshotRoot itself or one of its sub-directory,
     * 		where the modifications happen. It is represented as a relative
     * 		path to the snapshotRoot.
     */
    private void testCombineSnapshotDiffImpl(Path ZKXDNJEDLO, String XBXJESTROZ, int SYWUNNYAPR) throws Exception {
        Path ORWIYIYOQK = (XBXJESTROZ.isEmpty()) ? ZKXDNJEDLO : new Path(ZKXDNJEDLO, XBXJESTROZ);
        final int DAPRARMRUU = (XBXJESTROZ.isEmpty()) ? 0 : 1;
        Path VSAGEFZJYP = new Path(ORWIYIYOQK, "file10");
        Path RJMZCQZHPO = new Path(ORWIYIYOQK, "file11");
        Path AMYSGCIDHU = new Path(ORWIYIYOQK, "file12");
        Path YRANNRAAKA = new Path(ORWIYIYOQK, "file13");
        Path DVVQSQYAAP = new Path(ORWIYIYOQK, "file14");
        Path HIFQWXZGWU = new Path(ORWIYIYOQK, "file15");
        DFSTestUtil.createFile(JEKHARZUCY, VSAGEFZJYP, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.LAXZFQHRKV, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, RJMZCQZHPO, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.LAXZFQHRKV, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, AMYSGCIDHU, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.LAXZFQHRKV, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, YRANNRAAKA, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.LAXZFQHRKV, TestSnapshotDeletion.ZEYLXCEMSK);
        // create snapshot s1 for snapshotRoot
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, ZKXDNJEDLO, "s1");
        checkQuotaUsageComputation(ZKXDNJEDLO, SYWUNNYAPR + 5, 8 * TestSnapshotDeletion.LIRRTWIVQU);
        // delete file11
        JEKHARZUCY.delete(RJMZCQZHPO, true);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 6) + DAPRARMRUU, 8 * TestSnapshotDeletion.LIRRTWIVQU);
        // modify file12
        JEKHARZUCY.setReplication(AMYSGCIDHU, TestSnapshotDeletion.RKWXJYWJHQ);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 7) + DAPRARMRUU, 9 * TestSnapshotDeletion.LIRRTWIVQU);
        // modify file13
        JEKHARZUCY.setReplication(YRANNRAAKA, TestSnapshotDeletion.RKWXJYWJHQ);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 8) + DAPRARMRUU, 10 * TestSnapshotDeletion.LIRRTWIVQU);
        // create file14
        DFSTestUtil.createFile(JEKHARZUCY, DVVQSQYAAP, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 9) + DAPRARMRUU, 13 * TestSnapshotDeletion.LIRRTWIVQU);
        // create file15
        DFSTestUtil.createFile(JEKHARZUCY, HIFQWXZGWU, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 10) + DAPRARMRUU, 16 * TestSnapshotDeletion.LIRRTWIVQU);
        // create snapshot s2 for snapshotRoot
        JEKHARZUCY.createSnapshot(ZKXDNJEDLO, "s2");
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 11) + DAPRARMRUU, 16 * TestSnapshotDeletion.LIRRTWIVQU);
        // create file11 again: (0, d) + (c, 0)
        DFSTestUtil.createFile(JEKHARZUCY, RJMZCQZHPO, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 12) + (DAPRARMRUU * 2), 19 * TestSnapshotDeletion.LIRRTWIVQU);
        // delete file12
        JEKHARZUCY.delete(AMYSGCIDHU, true);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 13) + (DAPRARMRUU * 2), 19 * TestSnapshotDeletion.LIRRTWIVQU);
        // modify file13
        JEKHARZUCY.setReplication(YRANNRAAKA, ((short) (TestSnapshotDeletion.RKWXJYWJHQ - 2)));
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 14) + (DAPRARMRUU * 2), 19 * TestSnapshotDeletion.LIRRTWIVQU);
        // delete file14: (c, 0) + (0, d)
        JEKHARZUCY.delete(DVVQSQYAAP, true);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 15) + (DAPRARMRUU * 2), 19 * TestSnapshotDeletion.LIRRTWIVQU);
        // modify file15
        JEKHARZUCY.setReplication(HIFQWXZGWU, TestSnapshotDeletion.LAXZFQHRKV);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 16) + (DAPRARMRUU * 2), 19 * TestSnapshotDeletion.LIRRTWIVQU);
        // create snapshot s3 for snapshotRoot
        JEKHARZUCY.createSnapshot(ZKXDNJEDLO, "s3");
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 17) + (DAPRARMRUU * 2), 19 * TestSnapshotDeletion.LIRRTWIVQU);
        // modify file10, to check if the posterior diff was set correctly
        JEKHARZUCY.setReplication(VSAGEFZJYP, TestSnapshotDeletion.RKWXJYWJHQ);
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 18) + (DAPRARMRUU * 2), 20 * TestSnapshotDeletion.LIRRTWIVQU);
        Path IFGIIPWLXM = SnapshotTestHelper.getSnapshotPath(ZKXDNJEDLO, "s1", XBXJESTROZ + "file10");
        Path RQRJTXUPRM = SnapshotTestHelper.getSnapshotPath(ZKXDNJEDLO, "s1", XBXJESTROZ + "file11");
        Path KKDRXZGERR = SnapshotTestHelper.getSnapshotPath(ZKXDNJEDLO, "s1", XBXJESTROZ + "file12");
        Path RVZPQOGUYI = SnapshotTestHelper.getSnapshotPath(ZKXDNJEDLO, "s1", XBXJESTROZ + "file13");
        Path ZRHVVYJOUX = SnapshotTestHelper.getSnapshotPath(ZKXDNJEDLO, "s2", XBXJESTROZ + "file14");
        Path KKDBCFUUKB = SnapshotTestHelper.getSnapshotPath(ZKXDNJEDLO, "s2", XBXJESTROZ + "file15");
        FileStatus ODVDKTFCNN = JEKHARZUCY.getFileStatus(IFGIIPWLXM);
        FileStatus AGJYVULNVX = JEKHARZUCY.getFileStatus(RQRJTXUPRM);
        FileStatus HGVLQRZEDT = JEKHARZUCY.getFileStatus(KKDRXZGERR);
        FileStatus CBAYFPCOVR = JEKHARZUCY.getFileStatus(RVZPQOGUYI);
        INodeFile NEJJRCITOX = TestSnapshotBlocksMap.assertBlockCollection(ZRHVVYJOUX.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        BlockInfo[] FFJGMWHSLG = NEJJRCITOX.getBlocks();
        TestSnapshotBlocksMap.assertBlockCollection(KKDBCFUUKB.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        // delete s2, in which process we need to combine the diff in s2 to s1
        JEKHARZUCY.deleteSnapshot(ZKXDNJEDLO, "s2");
        checkQuotaUsageComputation(ZKXDNJEDLO, (SYWUNNYAPR + 12) + DAPRARMRUU, 14 * TestSnapshotDeletion.LIRRTWIVQU);
        // check the correctness of s1
        FileStatus NYDPOOMQOU = JEKHARZUCY.getFileStatus(IFGIIPWLXM);
        FileStatus DJYIYPONHT = JEKHARZUCY.getFileStatus(RQRJTXUPRM);
        FileStatus JCWJHEWFBA = JEKHARZUCY.getFileStatus(KKDRXZGERR);
        FileStatus YECSBFYZOB = JEKHARZUCY.getFileStatus(RVZPQOGUYI);
        assertEquals(ODVDKTFCNN.toString(), NYDPOOMQOU.toString());
        assertEquals(AGJYVULNVX.toString(), DJYIYPONHT.toString());
        assertEquals(HGVLQRZEDT.toString(), JCWJHEWFBA.toString());
        assertEquals(CBAYFPCOVR.toString(), YECSBFYZOB.toString());
        TestSnapshotBlocksMap.assertBlockCollection(IFGIIPWLXM.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        TestSnapshotBlocksMap.assertBlockCollection(RQRJTXUPRM.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        TestSnapshotBlocksMap.assertBlockCollection(KKDRXZGERR.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        TestSnapshotBlocksMap.assertBlockCollection(RVZPQOGUYI.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        // make sure file14 and file15 are not included in s1
        Path UFXXMPCGPN = SnapshotTestHelper.getSnapshotPath(ZKXDNJEDLO, "s1", XBXJESTROZ + "file14");
        Path EDVXXHETHW = SnapshotTestHelper.getSnapshotPath(ZKXDNJEDLO, "s1", XBXJESTROZ + "file15");
        assertFalse(JEKHARZUCY.exists(UFXXMPCGPN));
        assertFalse(JEKHARZUCY.exists(EDVXXHETHW));
        for (BlockInfo BKHVJUWULA : FFJGMWHSLG) {
            assertNull(JHOXUECNUP.getBlockCollection(BKHVJUWULA));
        }
        INodeFile LOSIVAUFOS = ((INodeFile) (GKFUQGFBYD.getINode(YRANNRAAKA.toString())));
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, LOSIVAUFOS.getBlockReplication());
        TestSnapshotBlocksMap.assertBlockCollection(YRANNRAAKA.toString(), 1, GKFUQGFBYD, JHOXUECNUP);
        INodeFile HHLOFKBHYZ = ((INodeFile) (GKFUQGFBYD.getINode(KKDRXZGERR.toString())));
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, HHLOFKBHYZ.getBlockReplication());
    }

    /**
     * Test deleting snapshots with modification on the metadata of directory
     */
    @Test(timeout = 300000)
    public void testDeleteSnapshotWithDirModification() throws Exception {
        Path TVYQLLFGGS = new Path(XHNRQOMIBU, "file");
        DFSTestUtil.createFile(JEKHARZUCY, TVYQLLFGGS, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        JEKHARZUCY.setOwner(XHNRQOMIBU, "user1", "group1");
        // create snapshot s1 for sub1, and change the metadata of sub1
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, XHNRQOMIBU, "s1");
        checkQuotaUsageComputation(XHNRQOMIBU, 3, TestSnapshotDeletion.LIRRTWIVQU * 3);
        JEKHARZUCY.setOwner(XHNRQOMIBU, "user2", "group2");
        checkQuotaUsageComputation(XHNRQOMIBU, 3, TestSnapshotDeletion.LIRRTWIVQU * 3);
        // create snapshot s2 for sub1, but do not modify sub1 afterwards
        JEKHARZUCY.createSnapshot(XHNRQOMIBU, "s2");
        checkQuotaUsageComputation(XHNRQOMIBU, 4, TestSnapshotDeletion.LIRRTWIVQU * 3);
        // create snapshot s3 for sub1, and change the metadata of sub1
        JEKHARZUCY.createSnapshot(XHNRQOMIBU, "s3");
        checkQuotaUsageComputation(XHNRQOMIBU, 5, TestSnapshotDeletion.LIRRTWIVQU * 3);
        JEKHARZUCY.setOwner(XHNRQOMIBU, "user3", "group3");
        checkQuotaUsageComputation(XHNRQOMIBU, 5, TestSnapshotDeletion.LIRRTWIVQU * 3);
        // delete snapshot s3
        JEKHARZUCY.deleteSnapshot(XHNRQOMIBU, "s3");
        checkQuotaUsageComputation(XHNRQOMIBU, 4, TestSnapshotDeletion.LIRRTWIVQU * 3);
        // check sub1's metadata in snapshot s2
        FileStatus SNCGBCZZLF = JEKHARZUCY.getFileStatus(new Path(XHNRQOMIBU, HdfsConstants.DOT_SNAPSHOT_DIR + "/s2"));
        assertEquals("user2", SNCGBCZZLF.getOwner());
        assertEquals("group2", SNCGBCZZLF.getGroup());
        // delete snapshot s2
        JEKHARZUCY.deleteSnapshot(XHNRQOMIBU, "s2");
        checkQuotaUsageComputation(XHNRQOMIBU, 3, TestSnapshotDeletion.LIRRTWIVQU * 3);
        // check sub1's metadata in snapshot s1
        FileStatus DUWQUJAAIT = JEKHARZUCY.getFileStatus(new Path(XHNRQOMIBU, HdfsConstants.DOT_SNAPSHOT_DIR + "/s1"));
        assertEquals("user1", DUWQUJAAIT.getOwner());
        assertEquals("group1", DUWQUJAAIT.getGroup());
    }

    @Test
    public void testDeleteSnapshotWithPermissionsDisabled() throws Exception {
        BODFFKCFZY.shutdown();
        Configuration XWFUWXBEOA = new Configuration(WRRTENSDKC);
        XWFUWXBEOA.setBoolean(DFS_PERMISSIONS_ENABLED_KEY, false);
        BODFFKCFZY = new MiniDFSCluster.Builder(XWFUWXBEOA).numDataNodes(0).build();
        BODFFKCFZY.waitActive();
        JEKHARZUCY = BODFFKCFZY.getFileSystem();
        final Path VCKZDYPHQQ = new Path("/dir");
        JEKHARZUCY.mkdirs(VCKZDYPHQQ);
        JEKHARZUCY.allowSnapshot(VCKZDYPHQQ);
        JEKHARZUCY.mkdirs(new Path(VCKZDYPHQQ, "/test"));
        JEKHARZUCY.createSnapshot(VCKZDYPHQQ, "s1");
        UserGroupInformation VGWBELGCMQ = UserGroupInformation.createRemoteUser("anotheruser");
        VGWBELGCMQ.doAs(new PrivilegedAction<Object>() {
            @Override
            public Object run() {
                DistributedFileSystem YDKEODWBID = null;
                try {
                    YDKEODWBID = BODFFKCFZY.getFileSystem();
                    YDKEODWBID.deleteSnapshot(VCKZDYPHQQ, "s1");
                } catch (IOException e) {
                    fail("Failed to delete snapshot : " + e.getLocalizedMessage());
                } finally {
                    IOUtils.closeStream(YDKEODWBID);
                }
                return null;
            }
        });
    }

    /**
     * A test covering the case where the snapshot diff to be deleted is renamed
     * to its previous snapshot.
     */
    @Test(timeout = 300000)
    public void testRenameSnapshotDiff() throws Exception {
        BODFFKCFZY.getNamesystem().getSnapshotManager().setAllowNestedSnapshots(true);
        final Path EWUVPIWAIR = new Path(XHNRQOMIBU, "file0");
        final Path QVVUTLWWLJ = new Path(WIHUITOUKJ, "file0");
        DFSTestUtil.createFile(JEKHARZUCY, EWUVPIWAIR, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, QVVUTLWWLJ, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        JEKHARZUCY.setOwner(WIHUITOUKJ, "owner", "group");
        // create snapshot s0 on sub
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, XHNRQOMIBU, "s0");
        checkQuotaUsageComputation(XHNRQOMIBU, 5, TestSnapshotDeletion.LIRRTWIVQU * 6);
        // make some changes on both sub and subsub
        final Path GCFHLMSEDM = new Path(XHNRQOMIBU, "file1");
        final Path EBKOLUHLIS = new Path(WIHUITOUKJ, "file1");
        DFSTestUtil.createFile(JEKHARZUCY, GCFHLMSEDM, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.LAXZFQHRKV, TestSnapshotDeletion.ZEYLXCEMSK);
        DFSTestUtil.createFile(JEKHARZUCY, EBKOLUHLIS, TestSnapshotDeletion.LIRRTWIVQU, TestSnapshotDeletion.RKWXJYWJHQ, TestSnapshotDeletion.ZEYLXCEMSK);
        checkQuotaUsageComputation(XHNRQOMIBU, 8, TestSnapshotDeletion.LIRRTWIVQU * 11);
        // create snapshot s1 on sub
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, XHNRQOMIBU, "s1");
        checkQuotaUsageComputation(XHNRQOMIBU, 9, TestSnapshotDeletion.LIRRTWIVQU * 11);
        // create snapshot s2 on dir
        SnapshotTestHelper.createSnapshot(JEKHARZUCY, QRMQKTOSCR, "s2");
        checkQuotaUsageComputation(QRMQKTOSCR, 11, TestSnapshotDeletion.LIRRTWIVQU * 11);
        checkQuotaUsageComputation(XHNRQOMIBU, 9, TestSnapshotDeletion.LIRRTWIVQU * 11);
        // make changes on subsub and subsubFile1
        JEKHARZUCY.setOwner(WIHUITOUKJ, "unknown", "unknown");
        JEKHARZUCY.setReplication(EBKOLUHLIS, TestSnapshotDeletion.LAXZFQHRKV);
        checkQuotaUsageComputation(QRMQKTOSCR, 13, TestSnapshotDeletion.LIRRTWIVQU * 11);
        checkQuotaUsageComputation(XHNRQOMIBU, 11, TestSnapshotDeletion.LIRRTWIVQU * 11);
        // make changes on sub
        JEKHARZUCY.delete(GCFHLMSEDM, true);
        checkQuotaUsageComputation(new Path("/"), 16, TestSnapshotDeletion.LIRRTWIVQU * 11);
        checkQuotaUsageComputation(QRMQKTOSCR, 15, TestSnapshotDeletion.LIRRTWIVQU * 11);
        checkQuotaUsageComputation(XHNRQOMIBU, 13, TestSnapshotDeletion.LIRRTWIVQU * 11);
        Path XIIUKQFFJR = SnapshotTestHelper.getSnapshotPath(QRMQKTOSCR, "s2", (XHNRQOMIBU.getName() + Path.SEPARATOR) + WIHUITOUKJ.getName());
        Path PWORDVWSMX = SnapshotTestHelper.getSnapshotPath(QRMQKTOSCR, "s2", (((XHNRQOMIBU.getName() + Path.SEPARATOR) + WIHUITOUKJ.getName()) + Path.SEPARATOR) + EBKOLUHLIS.getName());
        Path IPVXEFEVNE = SnapshotTestHelper.getSnapshotPath(QRMQKTOSCR, "s2", (XHNRQOMIBU.getName() + Path.SEPARATOR) + GCFHLMSEDM.getName());
        FileStatus OGPUZQVMJT = JEKHARZUCY.getFileStatus(XIIUKQFFJR);
        assertEquals("owner", OGPUZQVMJT.getOwner());
        assertEquals("group", OGPUZQVMJT.getGroup());
        FileStatus WHLYXTHCDA = JEKHARZUCY.getFileStatus(PWORDVWSMX);
        assertEquals(TestSnapshotDeletion.RKWXJYWJHQ, WHLYXTHCDA.getReplication());
        FileStatus YTJEBOCOJD = JEKHARZUCY.getFileStatus(IPVXEFEVNE);
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, YTJEBOCOJD.getReplication());
        // delete snapshot s2
        JEKHARZUCY.deleteSnapshot(QRMQKTOSCR, "s2");
        checkQuotaUsageComputation(new Path("/"), 14, TestSnapshotDeletion.LIRRTWIVQU * 11);
        checkQuotaUsageComputation(QRMQKTOSCR, 13, TestSnapshotDeletion.LIRRTWIVQU * 11);
        checkQuotaUsageComputation(XHNRQOMIBU, 12, TestSnapshotDeletion.LIRRTWIVQU * 11);
        // no snapshot copy for s2
        try {
            JEKHARZUCY.getFileStatus(XIIUKQFFJR);
            fail("should throw FileNotFoundException");
        } catch (FileNotFoundException e) {
            GenericTestUtils.assertExceptionContains("File does not exist: " + XIIUKQFFJR.toString(), e);
        }
        try {
            JEKHARZUCY.getFileStatus(PWORDVWSMX);
            fail("should throw FileNotFoundException");
        } catch (FileNotFoundException e) {
            GenericTestUtils.assertExceptionContains("File does not exist: " + PWORDVWSMX.toString(), e);
        }
        try {
            JEKHARZUCY.getFileStatus(IPVXEFEVNE);
            fail("should throw FileNotFoundException");
        } catch (FileNotFoundException e) {
            GenericTestUtils.assertExceptionContains("File does not exist: " + IPVXEFEVNE.toString(), e);
        }
        // the snapshot copy of s2 should now be renamed to s1 under sub
        XIIUKQFFJR = SnapshotTestHelper.getSnapshotPath(XHNRQOMIBU, "s1", WIHUITOUKJ.getName());
        PWORDVWSMX = SnapshotTestHelper.getSnapshotPath(XHNRQOMIBU, "s1", (WIHUITOUKJ.getName() + Path.SEPARATOR) + EBKOLUHLIS.getName());
        IPVXEFEVNE = SnapshotTestHelper.getSnapshotPath(XHNRQOMIBU, "s1", GCFHLMSEDM.getName());
        OGPUZQVMJT = JEKHARZUCY.getFileStatus(XIIUKQFFJR);
        assertEquals("owner", OGPUZQVMJT.getOwner());
        assertEquals("group", OGPUZQVMJT.getGroup());
        WHLYXTHCDA = JEKHARZUCY.getFileStatus(PWORDVWSMX);
        assertEquals(TestSnapshotDeletion.RKWXJYWJHQ, WHLYXTHCDA.getReplication());
        // also subFile1's snapshot copy should have been moved to diff of s1 as
        // combination
        YTJEBOCOJD = JEKHARZUCY.getFileStatus(IPVXEFEVNE);
        assertEquals(TestSnapshotDeletion.LAXZFQHRKV, YTJEBOCOJD.getReplication());
    }

    @Test
    public void testDeleteSnapshotCommandWithIllegalArguments() throws Exception {
        ByteArrayOutputStream ERTKDPFNQG = new ByteArrayOutputStream();
        PrintStream ZLCBGUZYVN = new PrintStream(ERTKDPFNQG);
        System.setOut(ZLCBGUZYVN);
        System.setErr(ZLCBGUZYVN);
        FsShell FCGWPBXWJD = new FsShell();
        FCGWPBXWJD.setConf(WRRTENSDKC);
        String[] FVLUGRMJWN = new String[]{ "-deleteSnapshot", "/tmp" };
        int OYYKHLQXWG = FCGWPBXWJD.run(FVLUGRMJWN);
        assertTrue(OYYKHLQXWG == (-1));
        assertTrue(ERTKDPFNQG.toString().contains(FVLUGRMJWN[0] + ": Incorrect number of arguments."));
        ERTKDPFNQG.reset();
        String[] CHQEDIYESG = new String[]{ "-deleteSnapshot", "/tmp", "s1", "s2" };
        OYYKHLQXWG = FCGWPBXWJD.run(CHQEDIYESG);
        assertTrue(OYYKHLQXWG == (-1));
        assertTrue(ERTKDPFNQG.toString().contains(CHQEDIYESG[0] + ": Incorrect number of arguments."));
        ZLCBGUZYVN.close();
        ERTKDPFNQG.close();
    }

    /* OP_DELETE_SNAPSHOT edits op was not decrementing the safemode threshold on
    restart in HA mode. HDFS-5504
     */
    @Test(timeout = 60000)
    public void testHANNRestartAfterSnapshotDeletion() throws Exception {
        JEKHARZUCY.close();
        BODFFKCFZY.shutdown();
        WRRTENSDKC = new Configuration();
        BODFFKCFZY = new MiniDFSCluster.Builder(WRRTENSDKC).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleHATopology()).numDataNodes(1).build();
        BODFFKCFZY.transitionToActive(0);
        // stop the standby namenode
        NameNode JTNMUGRNGL = BODFFKCFZY.getNameNode(1);
        JTNMUGRNGL.stop();
        JEKHARZUCY = ((DistributedFileSystem) (HATestUtil.configureFailoverFs(BODFFKCFZY, WRRTENSDKC)));
        Path TKNLNCURRW = new Path("/dir");
        Path TVUXEIBUBO = new Path(TKNLNCURRW, "sub");
        JEKHARZUCY.mkdirs(TKNLNCURRW);
        JEKHARZUCY.allowSnapshot(TKNLNCURRW);
        for (int WMQGVFLYBL = 0; WMQGVFLYBL < 5; WMQGVFLYBL++) {
            DFSTestUtil.createFile(JEKHARZUCY, new Path(TVUXEIBUBO, "" + WMQGVFLYBL), 100, ((short) (1)), 1024L);
        }
        // take snapshot
        JEKHARZUCY.createSnapshot(TKNLNCURRW, "s0");
        // delete the subdir
        JEKHARZUCY.delete(TVUXEIBUBO, true);
        // roll the edit log
        NameNode CLEVISKVQC = BODFFKCFZY.getNameNode(0);
        CLEVISKVQC.getRpcServer().rollEditLog();
        JEKHARZUCY.deleteSnapshot(TKNLNCURRW, "s0");
        // wait for the blocks deletion at namenode
        Thread.sleep(2000);
        NameNodeAdapter.abortEditLogs(CLEVISKVQC);
        BODFFKCFZY.restartNameNode(0, false);
        BODFFKCFZY.transitionToActive(0);
        // wait till the cluster becomes active
        BODFFKCFZY.waitClusterUp();
    }
}