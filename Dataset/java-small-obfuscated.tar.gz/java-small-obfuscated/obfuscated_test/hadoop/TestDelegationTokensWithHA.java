/**
 * Test case for client support of delegation tokens in an HA cluster.
 * See HDFS-2904 for more info.
 */
public class TestDelegationTokensWithHA {
    private static final Configuration OATCCMWCPD = new Configuration();

    private static final Log OVFAPOXQUM = LogFactory.getLog(TestDelegationTokensWithHA.class);

    private static MiniDFSCluster ULOCGVMIYC;

    private static NameNode PZIMXPBSVG;

    private static NameNode PIETIAEIRQ;

    private static FileSystem OOKMRTZCLN;

    private static DelegationTokenSecretManager HIJIKAUVWJ;

    private static DistributedFileSystem JGVJTWZBKC;

    private volatile boolean MTVNVSWTEU = false;

    @Before
    public void setupCluster() throws Exception {
        SecurityUtilTestHelper.setTokenServiceUseIp(true);
        TestDelegationTokensWithHA.OATCCMWCPD.setBoolean(DFS_NAMENODE_DELEGATION_TOKEN_ALWAYS_USE_KEY, true);
        TestDelegationTokensWithHA.OATCCMWCPD.set(HADOOP_SECURITY_AUTH_TO_LOCAL, "RULE:[2:$1@$0](JobTracker@.*FOO.COM)s/@.*//" + "DEFAULT");
        TestDelegationTokensWithHA.ULOCGVMIYC = new MiniDFSCluster.Builder(TestDelegationTokensWithHA.OATCCMWCPD).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).build();
        TestDelegationTokensWithHA.ULOCGVMIYC.waitActive();
        String AJJYCFSFDO = HATestUtil.getLogicalHostname(TestDelegationTokensWithHA.ULOCGVMIYC);
        HATestUtil.setFailoverConfigurations(TestDelegationTokensWithHA.ULOCGVMIYC, TestDelegationTokensWithHA.OATCCMWCPD, AJJYCFSFDO, 0);
        TestDelegationTokensWithHA.PZIMXPBSVG = TestDelegationTokensWithHA.ULOCGVMIYC.getNameNode(0);
        TestDelegationTokensWithHA.PIETIAEIRQ = TestDelegationTokensWithHA.ULOCGVMIYC.getNameNode(1);
        TestDelegationTokensWithHA.OOKMRTZCLN = HATestUtil.configureFailoverFs(TestDelegationTokensWithHA.ULOCGVMIYC, TestDelegationTokensWithHA.OATCCMWCPD);
        TestDelegationTokensWithHA.JGVJTWZBKC = ((DistributedFileSystem) (TestDelegationTokensWithHA.OOKMRTZCLN));
        TestDelegationTokensWithHA.ULOCGVMIYC.transitionToActive(0);
        TestDelegationTokensWithHA.HIJIKAUVWJ = NameNodeAdapter.getDtSecretManager(TestDelegationTokensWithHA.PZIMXPBSVG.getNamesystem());
    }

    @After
    public void shutdownCluster() throws IOException {
        if (TestDelegationTokensWithHA.ULOCGVMIYC != null) {
            TestDelegationTokensWithHA.ULOCGVMIYC.shutdown();
        }
    }

    @Test
    public void testDelegationTokenDFSApi() throws Exception {
        final Token<DelegationTokenIdentifier> DNYRFJFBYA = getDelegationToken(TestDelegationTokensWithHA.OOKMRTZCLN, "JobTracker");
        DelegationTokenIdentifier CPAOEXKSFD = new DelegationTokenIdentifier();
        byte[] ZEPTTRQCYD = DNYRFJFBYA.getIdentifier();
        CPAOEXKSFD.readFields(new DataInputStream(new ByteArrayInputStream(ZEPTTRQCYD)));
        // Ensure that it's present in the NN's secret manager and can
        // be renewed directly from there.
        TestDelegationTokensWithHA.OVFAPOXQUM.info("A valid token should have non-null password, " + "and should be renewed successfully");
        assertTrue(null != TestDelegationTokensWithHA.HIJIKAUVWJ.retrievePassword(CPAOEXKSFD));
        TestDelegationTokensWithHA.HIJIKAUVWJ.renewToken(DNYRFJFBYA, "JobTracker");
        // Use the client conf with the failover info present to check
        // renewal.
        Configuration CBZWWOUZAW = TestDelegationTokensWithHA.JGVJTWZBKC.getConf();
        TestDelegationTokensWithHA.doRenewOrCancel(DNYRFJFBYA, CBZWWOUZAW, TestDelegationTokensWithHA.TokenTestAction.RENEW);
        // Using a configuration that doesn't have the logical nameservice
        // configured should result in a reasonable error message.
        Configuration DFXSHOUXTE = new Configuration();
        try {
            TestDelegationTokensWithHA.doRenewOrCancel(DNYRFJFBYA, DFXSHOUXTE, TestDelegationTokensWithHA.TokenTestAction.RENEW);
            fail("Did not throw trying to renew with an empty conf!");
        } catch (IOException ioe) {
            GenericTestUtils.assertExceptionContains("Unable to map logical nameservice URI", ioe);
        }
        // Ensure that the token can be renewed again after a failover.
        TestDelegationTokensWithHA.ULOCGVMIYC.transitionToStandby(0);
        TestDelegationTokensWithHA.ULOCGVMIYC.transitionToActive(1);
        TestDelegationTokensWithHA.doRenewOrCancel(DNYRFJFBYA, CBZWWOUZAW, TestDelegationTokensWithHA.TokenTestAction.RENEW);
        TestDelegationTokensWithHA.doRenewOrCancel(DNYRFJFBYA, CBZWWOUZAW, TestDelegationTokensWithHA.TokenTestAction.CANCEL);
    }

    private class EditLogTailerForTest extends EditLogTailer {
        public EditLogTailerForTest(FSNamesystem namesystem, Configuration conf) {
            super(namesystem, conf);
        }

        public void catchupDuringFailover() throws IOException {
            synchronized(TestDelegationTokensWithHA.this) {
                while (!MTVNVSWTEU) {
                    try {
                        TestDelegationTokensWithHA.OVFAPOXQUM.info("The editlog tailer is waiting to catchup...");
                        TestDelegationTokensWithHA.this.wait();
                    } catch (InterruptedException e) {
                    }
                } 
            }
            super.catchupDuringFailover();
        }
    }

    /**
     * Test if correct exception (StandbyException or RetriableException) can be
     * thrown during the NN failover.
     */
    @Test
    public void testDelegationTokenDuringNNFailover() throws Exception {
        EditLogTailer KBQLILMYUI = TestDelegationTokensWithHA.PIETIAEIRQ.getNamesystem().getEditLogTailer();
        // stop the editLogTailer of nn1
        KBQLILMYUI.stop();
        Configuration WDYIBXNBJI = ((Configuration) (Whitebox.getInternalState(KBQLILMYUI, "conf")));
        TestDelegationTokensWithHA.PIETIAEIRQ.getNamesystem().setEditLogTailerForTests(new TestDelegationTokensWithHA.EditLogTailerForTest(TestDelegationTokensWithHA.PIETIAEIRQ.getNamesystem(), WDYIBXNBJI));
        // create token
        final Token<DelegationTokenIdentifier> IPWCZRGKXV = getDelegationToken(TestDelegationTokensWithHA.OOKMRTZCLN, "JobTracker");
        DelegationTokenIdentifier HOKXFYJEKZ = new DelegationTokenIdentifier();
        byte[] OIHBSNVHNV = IPWCZRGKXV.getIdentifier();
        HOKXFYJEKZ.readFields(new DataInputStream(new ByteArrayInputStream(OIHBSNVHNV)));
        // Ensure that it's present in the nn0 secret manager and can
        // be renewed directly from there.
        TestDelegationTokensWithHA.OVFAPOXQUM.info("A valid token should have non-null password, " + "and should be renewed successfully");
        assertTrue(null != TestDelegationTokensWithHA.HIJIKAUVWJ.retrievePassword(HOKXFYJEKZ));
        TestDelegationTokensWithHA.HIJIKAUVWJ.renewToken(IPWCZRGKXV, "JobTracker");
        // transition nn0 to standby
        TestDelegationTokensWithHA.ULOCGVMIYC.transitionToStandby(0);
        try {
            TestDelegationTokensWithHA.ULOCGVMIYC.getNameNodeRpc(0).renewDelegationToken(IPWCZRGKXV);
            fail("StandbyException is expected since nn0 is in standby state");
        } catch (StandbyException e) {
            GenericTestUtils.assertExceptionContains(STANDBY.toString(), e);
        }
        new Thread() {
            @Override
            public void run() {
                try {
                    TestDelegationTokensWithHA.ULOCGVMIYC.transitionToActive(1);
                } catch (Exception e) {
                    TestDelegationTokensWithHA.OVFAPOXQUM.error("Transition nn1 to active failed", e);
                }
            }
        }.start();
        Thread.sleep(1000);
        try {
            TestDelegationTokensWithHA.PIETIAEIRQ.getNamesystem().verifyToken(IPWCZRGKXV.decodeIdentifier(), IPWCZRGKXV.getPassword());
            fail("RetriableException/StandbyException is expected since nn1 is in transition");
        } catch (IOException e) {
            assertTrue((e instanceof StandbyException) || (e instanceof RetriableException));
            TestDelegationTokensWithHA.OVFAPOXQUM.info("Got expected exception", e);
        }
        MTVNVSWTEU = true;
        synchronized(this) {
            this.notifyAll();
        }
        Configuration TWHFDRMGMD = TestDelegationTokensWithHA.JGVJTWZBKC.getConf();
        TestDelegationTokensWithHA.doRenewOrCancel(IPWCZRGKXV, TWHFDRMGMD, TestDelegationTokensWithHA.TokenTestAction.RENEW);
        TestDelegationTokensWithHA.doRenewOrCancel(IPWCZRGKXV, TWHFDRMGMD, TestDelegationTokensWithHA.TokenTestAction.CANCEL);
    }

    @Test
    public void testDelegationTokenWithDoAs() throws Exception {
        final Token<DelegationTokenIdentifier> LRRZTHCOYR = getDelegationToken(TestDelegationTokensWithHA.OOKMRTZCLN, "JobTracker");
        final UserGroupInformation HCFJFLXDGY = UserGroupInformation.createRemoteUser("JobTracker/foo.com@FOO.COM");
        final UserGroupInformation WWFXYYWWYU = UserGroupInformation.createRemoteUser("JobTracker");
        HCFJFLXDGY.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                // try renew with long name
                LRRZTHCOYR.renew(TestDelegationTokensWithHA.OATCCMWCPD);
                return null;
            }
        });
        WWFXYYWWYU.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                LRRZTHCOYR.renew(TestDelegationTokensWithHA.OATCCMWCPD);
                return null;
            }
        });
        HCFJFLXDGY.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                LRRZTHCOYR.cancel(TestDelegationTokensWithHA.OATCCMWCPD);
                return null;
            }
        });
    }

    @Test
    public void testHAUtilClonesDelegationTokens() throws Exception {
        final Token<DelegationTokenIdentifier> TOCDETFISG = getDelegationToken(TestDelegationTokensWithHA.OOKMRTZCLN, "JobTracker");
        UserGroupInformation NKEBPXOAEK = UserGroupInformation.createRemoteUser("test");
        URI WUSVBCFNGV = new URI("hdfs://my-ha-uri/");
        TOCDETFISG.setService(HAUtil.buildTokenServiceForLogicalUri(WUSVBCFNGV, HDFS_URI_SCHEME));
        NKEBPXOAEK.addToken(TOCDETFISG);
        Collection<InetSocketAddress> LIVTZFUCHZ = new HashSet<InetSocketAddress>();
        LIVTZFUCHZ.add(new InetSocketAddress("localhost", TestDelegationTokensWithHA.PZIMXPBSVG.getNameNodeAddress().getPort()));
        LIVTZFUCHZ.add(new InetSocketAddress("localhost", TestDelegationTokensWithHA.PIETIAEIRQ.getNameNodeAddress().getPort()));
        HAUtil.cloneDelegationTokenForLogicalUri(NKEBPXOAEK, WUSVBCFNGV, LIVTZFUCHZ);
        Collection<Token<? extends TokenIdentifier>> NIQFEUIECX = NKEBPXOAEK.getTokens();
        assertEquals(3, NIQFEUIECX.size());
        TestDelegationTokensWithHA.OVFAPOXQUM.info("Tokens:\n" + com.google.common.base.Joiner.on("\n").join(NIQFEUIECX));
        DelegationTokenSelector PVFDEQOCTZ = new DelegationTokenSelector();
        // check that the token selected for one of the physical IPC addresses
        // matches the one we received
        for (InetSocketAddress CRQLROBJYJ : LIVTZFUCHZ) {
            Text RKXOJQOEWN = SecurityUtil.buildTokenService(CRQLROBJYJ);
            Token<DelegationTokenIdentifier> OUPVGTLONI = PVFDEQOCTZ.selectToken(RKXOJQOEWN, NKEBPXOAEK.getTokens());
            assertNotNull(OUPVGTLONI);
            assertArrayEquals(TOCDETFISG.getIdentifier(), OUPVGTLONI.getIdentifier());
            assertArrayEquals(TOCDETFISG.getPassword(), OUPVGTLONI.getPassword());
        }
        // switch to host-based tokens, shouldn't match existing tokens
        SecurityUtilTestHelper.setTokenServiceUseIp(false);
        for (InetSocketAddress SNGJVTQIQM : LIVTZFUCHZ) {
            Text WWCIFQYOHI = SecurityUtil.buildTokenService(SNGJVTQIQM);
            Token<DelegationTokenIdentifier> PFIPTPZQBP = PVFDEQOCTZ.selectToken(WWCIFQYOHI, NKEBPXOAEK.getTokens());
            assertNull(PFIPTPZQBP);
        }
        // reclone the tokens, and see if they match now
        HAUtil.cloneDelegationTokenForLogicalUri(NKEBPXOAEK, WUSVBCFNGV, LIVTZFUCHZ);
        for (InetSocketAddress SJMLGITWAJ : LIVTZFUCHZ) {
            Text FILICAVLXV = SecurityUtil.buildTokenService(SJMLGITWAJ);
            Token<DelegationTokenIdentifier> FATPKYIFVZ = PVFDEQOCTZ.selectToken(FILICAVLXV, NKEBPXOAEK.getTokens());
            assertNotNull(FATPKYIFVZ);
            assertArrayEquals(TOCDETFISG.getIdentifier(), FATPKYIFVZ.getIdentifier());
            assertArrayEquals(TOCDETFISG.getPassword(), FATPKYIFVZ.getPassword());
        }
    }

    /**
     * HDFS-3062: DistributedFileSystem.getCanonicalServiceName() throws an
     * exception if the URI is a logical URI. This bug fails the combination of
     * ha + mapred + security.
     */
    @Test
    public void testDFSGetCanonicalServiceName() throws Exception {
        URI GGEUGENUUW = HATestUtil.getLogicalUri(TestDelegationTokensWithHA.ULOCGVMIYC);
        String XFLPRGFUYB = HAUtil.buildTokenServiceForLogicalUri(GGEUGENUUW, HDFS_URI_SCHEME).toString();
        assertEquals(XFLPRGFUYB, TestDelegationTokensWithHA.JGVJTWZBKC.getCanonicalServiceName());
        final String PMKPKGGXIG = UserGroupInformation.getCurrentUser().getShortUserName();
        final Token<DelegationTokenIdentifier> JFIFLMPDPW = getDelegationToken(TestDelegationTokensWithHA.JGVJTWZBKC, PMKPKGGXIG);
        assertEquals(XFLPRGFUYB, JFIFLMPDPW.getService().toString());
        // make sure the logical uri is handled correctly
        JFIFLMPDPW.renew(TestDelegationTokensWithHA.JGVJTWZBKC.getConf());
        JFIFLMPDPW.cancel(TestDelegationTokensWithHA.JGVJTWZBKC.getConf());
    }

    @Test
    public void testHdfsGetCanonicalServiceName() throws Exception {
        Configuration APCMGMRNSQ = TestDelegationTokensWithHA.JGVJTWZBKC.getConf();
        URI XMRLXJWRCU = HATestUtil.getLogicalUri(TestDelegationTokensWithHA.ULOCGVMIYC);
        AbstractFileSystem UTBEQZYIZF = AbstractFileSystem.createFileSystem(XMRLXJWRCU, APCMGMRNSQ);
        String XSKLQHMUIL = HAUtil.buildTokenServiceForLogicalUri(XMRLXJWRCU, HDFS_URI_SCHEME).toString();
        assertEquals(XSKLQHMUIL, UTBEQZYIZF.getCanonicalServiceName());
        Token<?> SDCIVKBVER = UTBEQZYIZF.getDelegationTokens(UserGroupInformation.getCurrentUser().getShortUserName()).get(0);
        assertEquals(XSKLQHMUIL, SDCIVKBVER.getService().toString());
        // make sure the logical uri is handled correctly
        SDCIVKBVER.renew(APCMGMRNSQ);
        SDCIVKBVER.cancel(APCMGMRNSQ);
    }

    /**
     * Test if StandbyException can be thrown from StandbyNN, when it's requested for
     * password. (HDFS-6475). With StandbyException, the client can failover to try
     * activeNN.
     */
    @Test
    public void testDelegationTokenStandbyNNAppearFirst() throws Exception {
        // make nn0 the standby NN, and nn1 the active NN
        TestDelegationTokensWithHA.ULOCGVMIYC.transitionToStandby(0);
        TestDelegationTokensWithHA.ULOCGVMIYC.transitionToActive(1);
        final DelegationTokenSecretManager KTDYJWHGAQ = NameNodeAdapter.getDtSecretManager(TestDelegationTokensWithHA.PIETIAEIRQ.getNamesystem());
        // create token
        final Token<DelegationTokenIdentifier> LJDPSCCCSE = getDelegationToken(TestDelegationTokensWithHA.OOKMRTZCLN, "JobTracker");
        final DelegationTokenIdentifier LAXSTSGOME = new DelegationTokenIdentifier();
        byte[] EVNCOYEQKL = LJDPSCCCSE.getIdentifier();
        LAXSTSGOME.readFields(new DataInputStream(new ByteArrayInputStream(EVNCOYEQKL)));
        assertTrue(null != KTDYJWHGAQ.retrievePassword(LAXSTSGOME));
        final UserGroupInformation ZIRJNCNDWI = UserGroupInformation.createRemoteUser("JobTracker");
        ZIRJNCNDWI.addToken(LJDPSCCCSE);
        ZIRJNCNDWI.doAs(new PrivilegedExceptionAction<Object>() {
            @Override
            public Object run() {
                try {
                    try {
                        byte[] WWKZPAMVZW = TestDelegationTokensWithHA.HIJIKAUVWJ.retrievePassword(LAXSTSGOME);
                        fail("InvalidToken with cause StandbyException is expected" + " since nn0 is standby");
                        return WWKZPAMVZW;
                    } catch (IOException e) {
                        // Mimic the UserProvider class logic (server side) by throwing
                        // SecurityException here
                        throw new SecurityException("Failed to obtain user group information: " + e, e);
                    }
                } catch (Exception oe) {
                    // 
                    // The exception oe caught here is
                    // java.lang.SecurityException: Failed to obtain user group
                    // information: org.apache.hadoop.security.token.
                    // SecretManager$InvalidToken: StandbyException
                    // 
                    HttpServletResponse BBDXLHEALV = mock(HttpServletResponse.class);
                    ExceptionHandler ETUEXBZTTL = new ExceptionHandler();
                    ETUEXBZTTL.initResponse(BBDXLHEALV);
                    // The Response (resp) below is what the server will send to client
                    // 
                    // BEFORE HDFS-6475 fix, the resp.entity is
                    // {"RemoteException":{"exception":"SecurityException",
                    // "javaClassName":"java.lang.SecurityException",
                    // "message":"Failed to obtain user group information:
                    // org.apache.hadoop.security.token.SecretManager$InvalidToken:
                    // StandbyException"}}
                    // AFTER the fix, the resp.entity is
                    // {"RemoteException":{"exception":"StandbyException",
                    // "javaClassName":"org.apache.hadoop.ipc.StandbyException",
                    // "message":"Operation category READ is not supported in
                    // state standby"}}
                    // 
                    Response UNTEWNOJQE = ETUEXBZTTL.toResponse(oe);
                    // Mimic the client side logic by parsing the response from server
                    // 
                    Map<?, ?> MABGBDBQLL = ((Map<?, ?>) (JSON.parse(UNTEWNOJQE.getEntity().toString())));
                    RemoteException YXBECIMFSA = JsonUtil.toRemoteException(MABGBDBQLL);
                    Exception WXIPMVOPNU = ((RemoteException) (YXBECIMFSA)).unwrapRemoteException(StandbyException.class);
                    assertTrue(WXIPMVOPNU instanceof StandbyException);
                    return null;
                }
            }
        });
    }

    @SuppressWarnings("unchecked")
    private Token<DelegationTokenIdentifier> getDelegationToken(FileSystem AKXWIOTKSP, String QZSIXFVIPD) throws IOException {
        final Token<?>[] TRGPESUZLB = AKXWIOTKSP.addDelegationTokens(QZSIXFVIPD, null);
        assertEquals(1, TRGPESUZLB.length);
        return ((Token<DelegationTokenIdentifier>) (TRGPESUZLB[0]));
    }

    enum TokenTestAction {

        RENEW,
        CANCEL;}

    private static void doRenewOrCancel(final Token<DelegationTokenIdentifier> KIKDLVRWCN, final Configuration PXZKYNTKUV, final TestDelegationTokensWithHA.TokenTestAction LXKECMXGAL) throws IOException, InterruptedException {
        UserGroupInformation.createRemoteUser("JobTracker").doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                switch (LXKECMXGAL) {
                    case RENEW :
                        KIKDLVRWCN.renew(PXZKYNTKUV);
                        break;
                    case CANCEL :
                        KIKDLVRWCN.cancel(PXZKYNTKUV);
                        break;
                    default :
                        fail("bad action:" + LXKECMXGAL);
                }
                return null;
            }
        });
    }
}