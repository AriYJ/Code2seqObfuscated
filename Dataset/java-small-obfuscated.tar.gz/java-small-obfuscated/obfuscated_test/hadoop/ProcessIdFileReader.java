/**
 * Helper functionality to read the pid from a file.
 */
public class ProcessIdFileReader {
    private static final Log PKCABJLKKH = LogFactory.getLog(ProcessIdFileReader.class);

    /**
     * Get the process id from specified file path.
     * Parses each line to find a valid number
     * and returns the first one found.
     *
     * @return Process Id if obtained from path specified else null
     * @throws IOException
     * 		
     */
    public static String getProcessId(Path HKSYGELIEK) throws IOException {
        if (HKSYGELIEK == null) {
            throw new IOException("Trying to access process id from a null path");
        }
        ProcessIdFileReader.PKCABJLKKH.debug("Accessing pid from pid file " + HKSYGELIEK);
        String GCNYUNVUOY = null;
        FileReader RUHWREQQRT = null;
        BufferedReader GDLAOLCZOQ = null;
        try {
            File PLHQJGMWPQ = new File(HKSYGELIEK.toString());
            if (PLHQJGMWPQ.exists()) {
                RUHWREQQRT = new FileReader(PLHQJGMWPQ);
                GDLAOLCZOQ = new BufferedReader(RUHWREQQRT);
                while (true) {
                    String NBNGZYTRTY = GDLAOLCZOQ.readLine();
                    if (NBNGZYTRTY == null) {
                        break;
                    }
                    String UVQCZFGXLU = NBNGZYTRTY.trim();
                    if (!UVQCZFGXLU.isEmpty()) {
                        if (Shell.WINDOWS) {
                            // On Windows, pid is expected to be a container ID, so find first
                            // line that parses successfully as a container ID.
                            try {
                                ConverterUtils.toContainerId(UVQCZFGXLU);
                                GCNYUNVUOY = UVQCZFGXLU;
                                break;
                            } catch (Exception e) {
                                // do nothing
                            }
                        } else {
                            // Otherwise, find first line containing a numeric pid.
                            try {
                                Long OAGRWRBVSW = Long.valueOf(UVQCZFGXLU);
                                if (OAGRWRBVSW > 0) {
                                    GCNYUNVUOY = UVQCZFGXLU;
                                    break;
                                }
                            } catch (Exception e) {
                                // do nothing
                            }
                        }
                    }
                } 
            }
        } finally {
            if (RUHWREQQRT != null) {
                RUHWREQQRT.close();
            }
            if (GDLAOLCZOQ != null) {
                GDLAOLCZOQ.close();
            }
        }
        ProcessIdFileReader.PKCABJLKKH.debug((("Got pid " + (GCNYUNVUOY != null ? GCNYUNVUOY : "null")) + " from path ") + HKSYGELIEK);
        return GCNYUNVUOY;
    }
}