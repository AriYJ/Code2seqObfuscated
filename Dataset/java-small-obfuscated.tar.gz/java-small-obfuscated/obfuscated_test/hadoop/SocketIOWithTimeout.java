/**
 * This supports input and output streams for a socket channels.
 * These streams can have a timeout.
 */
abstract class SocketIOWithTimeout {
    // This is intentionally package private.
    static final Log TWCWMWKUMW = LogFactory.getLog(SocketIOWithTimeout.class);

    private SelectableChannel LTZVQMKLOX;

    private long IKNQMRWANK;

    private boolean IZAISWSTGG = false;

    private static SocketIOWithTimeout.SelectorPool VEBGCTWYBZ = new SocketIOWithTimeout.SelectorPool();

    /* A timeout value of 0 implies wait for ever. 
    We should have a value of timeout that implies zero wait.. i.e. 
    read or write returns immediately.

    This will set channel to non-blocking.
     */
    SocketIOWithTimeout(SelectableChannel WIKANLXLSG, long AVXCMZGHVS) throws IOException {
        SocketIOWithTimeout.checkChannelValidity(WIKANLXLSG);
        this.LTZVQMKLOX = WIKANLXLSG;
        this.IKNQMRWANK = AVXCMZGHVS;
        // Set non-blocking
        WIKANLXLSG.configureBlocking(false);
    }

    void close() {
        IZAISWSTGG = true;
    }

    boolean isOpen() {
        return (!IZAISWSTGG) && LTZVQMKLOX.isOpen();
    }

    SelectableChannel getChannel() {
        return LTZVQMKLOX;
    }

    /**
     * Utility function to check if channel is ok.
     * Mainly to throw IOException instead of runtime exception
     * in case of mismatch. This mismatch can occur for many runtime
     * reasons.
     */
    static void checkChannelValidity(Object XJXQVKJEZZ) throws IOException {
        if (XJXQVKJEZZ == null) {
            /* Most common reason is that original socket does not have a channel.
            So making this an IOException rather than a RuntimeException.
             */
            throw new IOException("Channel is null. Check " + "how the channel or socket is created.");
        }
        if (!(XJXQVKJEZZ instanceof SelectableChannel)) {
            throw new IOException("Channel should be a SelectableChannel");
        }
    }

    /**
     * Performs actual IO operations. This is not expected to block.
     *
     * @param buf
     * 		
     * @return number of bytes (or some equivalent). 0 implies underlying
    channel is drained completely. We will wait if more IO is
    required.
     * @throws IOException
     * 		
     */
    abstract int performIO(ByteBuffer ICASUOTYVP) throws IOException;

    /**
     * Performs one IO and returns number of bytes read or written.
     * It waits up to the specified timeout. If the channel is
     * not read before the timeout, SocketTimeoutException is thrown.
     *
     * @param buf
     * 		buffer for IO
     * @param ops
     * 		Selection Ops used for waiting. Suggested values:
     * 		SelectionKey.OP_READ while reading and SelectionKey.OP_WRITE while
     * 		writing.
     * @return number of bytes read or written. negative implies end of stream.
     * @throws IOException
     * 		
     */
    int doIO(ByteBuffer HYOVORFDXH, int YSLWRMDYKZ) throws IOException {
        /* For now only one thread is allowed. If user want to read or write
        from multiple threads, multiple streams could be created. In that
        case multiple threads work as well as underlying channel supports it.
         */
        if (!HYOVORFDXH.hasRemaining()) {
            throw new IllegalArgumentException("Buffer has no data left.");
            // or should we just return 0?
        }
        while (HYOVORFDXH.hasRemaining()) {
            if (IZAISWSTGG) {
                return -1;
            }
            try {
                int BIELDARZON = performIO(HYOVORFDXH);
                if (BIELDARZON != 0) {
                    // successful io or an error.
                    return BIELDARZON;
                }
            } catch (IOException e) {
                if (!LTZVQMKLOX.isOpen()) {
                    IZAISWSTGG = true;
                }
                throw e;
            }
            // now wait for socket to be ready.
            int RBGXCCUMUZ = 0;
            try {
                RBGXCCUMUZ = SocketIOWithTimeout.VEBGCTWYBZ.select(LTZVQMKLOX, YSLWRMDYKZ, IKNQMRWANK);
            } catch (IOException e) {
                // unexpected IOException.
                IZAISWSTGG = true;
                throw e;
            }
            if (RBGXCCUMUZ == 0) {
                throw new SocketTimeoutException(SocketIOWithTimeout.timeoutExceptionString(LTZVQMKLOX, IKNQMRWANK, YSLWRMDYKZ));
            }
            // otherwise the socket should be ready for io.
        } 
        return 0;// does not reach here.

    }

    /**
     * The contract is similar to {@link SocketChannel#connect(SocketAddress)}
     * with a timeout.
     *
     * @see SocketChannel#connect(SocketAddress)
     * @param channel
     * 		- this should be a {@link SelectableChannel}
     * @param endpoint
     * 		
     * @throws IOException
     * 		
     */
    static void connect(SocketChannel STOCAJBOJT, SocketAddress XYLEZPZAJV, int FVFPIFTZFU) throws IOException {
        boolean FJWQPJSHGJ = STOCAJBOJT.isBlocking();
        if (FJWQPJSHGJ) {
            STOCAJBOJT.configureBlocking(false);
        }
        try {
            if (STOCAJBOJT.connect(XYLEZPZAJV)) {
                return;
            }
            long NCLHRFWRDP = FVFPIFTZFU;
            long TXYLMMHKZX = (FVFPIFTZFU > 0) ? Time.now() + FVFPIFTZFU : 0;
            while (true) {
                // we might have to call finishConnect() more than once
                // for some channels (with user level protocols)
                int MEXIIUVWRP = SocketIOWithTimeout.VEBGCTWYBZ.select(((SelectableChannel) (STOCAJBOJT)), SelectionKey.OP_CONNECT, NCLHRFWRDP);
                if ((MEXIIUVWRP > 0) && STOCAJBOJT.finishConnect()) {
                    return;
                }
                if ((MEXIIUVWRP == 0) || ((FVFPIFTZFU > 0) && ((NCLHRFWRDP = TXYLMMHKZX - Time.now()) <= 0))) {
                    throw new SocketTimeoutException(SocketIOWithTimeout.timeoutExceptionString(STOCAJBOJT, FVFPIFTZFU, SelectionKey.OP_CONNECT));
                }
            } 
        } catch (IOException e) {
            // javadoc for SocketChannel.connect() says channel should be closed.
            try {
                STOCAJBOJT.close();
            } catch (IOException ignored) {
            }
            throw e;
        } finally {
            if (FJWQPJSHGJ && STOCAJBOJT.isOpen()) {
                STOCAJBOJT.configureBlocking(true);
            }
        }
    }

    /**
     * This is similar to {@link #doIO(ByteBuffer, int)} except that it
     * does not perform any I/O. It just waits for the channel to be ready
     * for I/O as specified in ops.
     *
     * @param ops
     * 		Selection Ops used for waiting
     * @throws SocketTimeoutException
     * 		if select on the channel times out.
     * @throws IOException
     * 		if any other I/O error occurs.
     */
    void waitForIO(int WMHDRFQRDL) throws IOException {
        if (SocketIOWithTimeout.VEBGCTWYBZ.select(LTZVQMKLOX, WMHDRFQRDL, IKNQMRWANK) == 0) {
            throw new SocketTimeoutException(SocketIOWithTimeout.timeoutExceptionString(LTZVQMKLOX, IKNQMRWANK, WMHDRFQRDL));
        }
    }

    public void setTimeout(long OHRMYRHFBL) {
        this.IKNQMRWANK = OHRMYRHFBL;
    }

    private static String timeoutExceptionString(SelectableChannel DRVWGRHGNC, long DXTUHAFTRZ, int MWRMRQCRRU) {
        String BXGWJXNBZU;
        switch (MWRMRQCRRU) {
            case SelectionKey.OP_READ :
                BXGWJXNBZU = "read";
                break;
            case SelectionKey.OP_WRITE :
                BXGWJXNBZU = "write";
                break;
            case SelectionKey.OP_CONNECT :
                BXGWJXNBZU = "connect";
                break;
            default :
                BXGWJXNBZU = "" + MWRMRQCRRU;
        }
        return ((((DXTUHAFTRZ + " millis timeout while ") + "waiting for channel to be ready for ") + BXGWJXNBZU) + ". ch : ") + DRVWGRHGNC;
    }

    /**
     * This maintains a pool of selectors. These selectors are closed
     * once they are idle (unused) for a few seconds.
     */
    private static class SelectorPool {
        private static class SelectorInfo {
            Selector XCMDBRUVKI;

            long ELFBOZKZJE;

            LinkedList<SocketIOWithTimeout.SelectorPool.SelectorInfo> XVJZQBWOQJ;

            void close() {
                if (XCMDBRUVKI != null) {
                    try {
                        XCMDBRUVKI.close();
                    } catch (IOException e) {
                        SocketIOWithTimeout.TWCWMWKUMW.warn("Unexpected exception while closing selector : ", e);
                    }
                }
            }
        }

        private static class ProviderInfo {
            SelectorProvider YIBEJWDXSI;

            LinkedList<SocketIOWithTimeout.SelectorPool.SelectorInfo> TTICPEPYGH;// lifo


            SocketIOWithTimeout.SelectorPool.ProviderInfo MCBKADCCAS;
        }

        private static final long OTSGDMLUUU = 10 * 1000;// 10 seconds.


        private SocketIOWithTimeout.SelectorPool.ProviderInfo UFVRAYTCNS = null;

        /**
         * Waits on the channel with the given timeout using one of the
         * cached selectors. It also removes any cached selectors that are
         * idle for a few seconds.
         *
         * @param channel
         * 		
         * @param ops
         * 		
         * @param timeout
         * 		
         * @return 
         * @throws IOException
         * 		
         */
        int select(SelectableChannel channel, int ops, long timeout) throws IOException {
            SocketIOWithTimeout.SelectorPool.SelectorInfo info = get(channel);
            SelectionKey key = null;
            int ret = 0;
            try {
                while (true) {
                    long start = (timeout == 0) ? 0 : Time.now();
                    key = channel.register(info.XCMDBRUVKI, ops);
                    ret = info.XCMDBRUVKI.select(timeout);
                    if (ret != 0) {
                        return ret;
                    }
                    /* Sometimes select() returns 0 much before timeout for 
                    unknown reasons. So select again if required.
                     */
                    if (timeout > 0) {
                        timeout -= Time.now() - start;
                        if (timeout <= 0) {
                            return 0;
                        }
                    }
                    if (Thread.currentThread().isInterrupted()) {
                        throw new InterruptedIOException((((("Interruped while waiting for " + "IO on channel ") + channel) + ". ") + timeout) + " millis timeout left.");
                    }
                } 
            } finally {
                if (key != null) {
                    key.cancel();
                }
                // clear the canceled key.
                try {
                    info.XCMDBRUVKI.selectNow();
                } catch (IOException e) {
                    SocketIOWithTimeout.TWCWMWKUMW.info("Unexpected Exception while clearing selector : ", e);
                    // don't put the selector back.
                    info.close();
                    return ret;
                }
                release(info);
            }
        }

        /**
         * Takes one selector from end of LRU list of free selectors.
         * If there are no selectors awailable, it creates a new selector.
         * Also invokes trimIdleSelectors().
         *
         * @param channel
         * 		
         * @return 
         * @throws IOException
         * 		
         */
        private synchronized SocketIOWithTimeout.SelectorPool.SelectorInfo get(SelectableChannel channel) throws IOException {
            SocketIOWithTimeout.SelectorPool.SelectorInfo selInfo = null;
            SelectorProvider provider = channel.provider();
            // pick the list : rarely there is more than one provider in use.
            SocketIOWithTimeout.SelectorPool.ProviderInfo pList = UFVRAYTCNS;
            while ((pList != null) && (pList.YIBEJWDXSI != provider)) {
                pList = pList.MCBKADCCAS;
            } 
            if (pList == null) {
                // LOG.info("Creating new ProviderInfo : " + provider.toString());
                pList = new SocketIOWithTimeout.SelectorPool.ProviderInfo();
                pList.YIBEJWDXSI = provider;
                pList.TTICPEPYGH = new LinkedList<SocketIOWithTimeout.SelectorPool.SelectorInfo>();
                pList.MCBKADCCAS = UFVRAYTCNS;
                UFVRAYTCNS = pList;
            }
            LinkedList<SocketIOWithTimeout.SelectorPool.SelectorInfo> queue = pList.TTICPEPYGH;
            if (queue.isEmpty()) {
                Selector selector = provider.openSelector();
                selInfo = new SocketIOWithTimeout.SelectorPool.SelectorInfo();
                selInfo.XCMDBRUVKI = selector;
                selInfo.XVJZQBWOQJ = queue;
            } else {
                selInfo = queue.removeLast();
            }
            trimIdleSelectors(Time.now());
            return selInfo;
        }

        /**
         * puts selector back at the end of LRU list of free selectos.
         * Also invokes trimIdleSelectors().
         *
         * @param info
         * 		
         */
        private synchronized void release(SocketIOWithTimeout.SelectorPool.SelectorInfo info) {
            long now = Time.now();
            trimIdleSelectors(now);
            info.ELFBOZKZJE = now;
            info.XVJZQBWOQJ.addLast(info);
        }

        /**
         * Closes selectors that are idle for IDLE_TIMEOUT (10 sec). It does not
         * traverse the whole list, just over the one that have crossed
         * the timeout.
         */
        private void trimIdleSelectors(long now) {
            long cutoff = now - SocketIOWithTimeout.SelectorPool.OTSGDMLUUU;
            for (SocketIOWithTimeout.SelectorPool.ProviderInfo pList = UFVRAYTCNS; pList != null; pList = pList.MCBKADCCAS) {
                if (pList.TTICPEPYGH.isEmpty()) {
                    continue;
                }
                for (Iterator<SocketIOWithTimeout.SelectorPool.SelectorInfo> it = pList.TTICPEPYGH.iterator(); it.hasNext();) {
                    SocketIOWithTimeout.SelectorPool.SelectorInfo info = it.next();
                    if (info.ELFBOZKZJE > cutoff) {
                        break;
                    }
                    it.remove();
                    info.close();
                }
            }
        }
    }
}