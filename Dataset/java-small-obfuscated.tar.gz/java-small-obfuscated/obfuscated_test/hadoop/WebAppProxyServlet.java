public class WebAppProxyServlet extends HttpServlet {
    private static final long KUSNLIOUYN = 1L;

    private static final Log TULDPMSLXJ = LogFactory.getLog(WebAppProxyServlet.class);

    private static final HashSet<String> EEGAZINGNE = new HashSet<String>(Arrays.asList("User-Agent", "Accept", "Accept-Encoding", "Accept-Language", "Accept-Charset"));

    public static final String YAEHUJPJNT = "proxy-user";

    private final List<TrackingUriPlugin> IEHBRGOZFX;

    private final String SRZNZUSGXX;

    private final transient YarnConfiguration NVDVGUZUOQ;

    // Empty
    private static class _ implements Hamlet._ {}

    private static class Page extends Hamlet {
        Page(PrintWriter out) {
            super(out, 0, false);
        }

        public HTML<WebAppProxyServlet._> html() {
            return new HTML<WebAppProxyServlet._>("html", null, EnumSet.of(ENDTAG));
        }
    }

    /**
     * Default constructor
     */
    public WebAppProxyServlet() {
        super();
        NVDVGUZUOQ = new YarnConfiguration();
        this.IEHBRGOZFX = NVDVGUZUOQ.getInstances(YARN_TRACKING_URL_GENERATOR, TrackingUriPlugin.class);
        this.SRZNZUSGXX = StringHelper.pjoin(WebAppUtils.getResolvedRMWebAppURLWithScheme(NVDVGUZUOQ), "cluster", "app");
    }

    /**
     * Output 404 with appropriate message.
     *
     * @param resp
     * 		the http response.
     * @param message
     * 		the message to include on the page.
     * @throws IOException
     * 		on any error.
     */
    private static void notFound(HttpServletResponse IOGNABQXYP, String BYVZCRSYID) throws IOException {
        IOGNABQXYP.setStatus(SC_NOT_FOUND);
        IOGNABQXYP.setContentType(MimeType.HTML);
        WebAppProxyServlet.Page FODNTPAKYR = new WebAppProxyServlet.Page(IOGNABQXYP.getWriter());
        FODNTPAKYR.html().h1(BYVZCRSYID)._();
    }

    /**
     * Warn the user that the link may not be safe!
     *
     * @param resp
     * 		the http response
     * @param link
     * 		the link to point to
     * @param user
     * 		the user that owns the link.
     * @throws IOException
     * 		on any error.
     */
    private static void warnUserPage(HttpServletResponse KCSWLFUUYF, String VXDKQGCUAC, String CFUZCHPWMO, ApplicationId SNVOKZRJNP) throws IOException {
        // Set the cookie when we warn which overrides the query parameter
        // This is so that if a user passes in the approved query parameter without
        // having first visited this page then this page will still be displayed
        KCSWLFUUYF.addCookie(WebAppProxyServlet.makeCheckCookie(SNVOKZRJNP, false));
        KCSWLFUUYF.setContentType(MimeType.HTML);
        WebAppProxyServlet.Page OQOTMNYGZB = new WebAppProxyServlet.Page(KCSWLFUUYF.getWriter());
        OQOTMNYGZB.html().h1("WARNING: The following page may not be safe!").h3()._("click ").a(VXDKQGCUAC, "here")._(" to continue to an Application Master web interface owned by ", CFUZCHPWMO)._()._();
    }

    /**
     * Download link and have it be the response.
     *
     * @param req
     * 		the http request
     * @param resp
     * 		the http response
     * @param link
     * 		the link to download
     * @param c
     * 		the cookie to set if any
     * @throws IOException
     * 		on any error.
     */
    private static void proxyLink(HttpServletRequest IBLVFAGSEF, HttpServletResponse QVNKNOKOXO, URI REYMCJPMBO, Cookie AKFDAHOTDY, String GFSOFAUSWZ) throws IOException {
        org.apache.commons.httpclient.URI UBHGYSCQRE = new org.apache.commons.httpclient.URI(REYMCJPMBO.toString(), false);
        HttpClientParams TXLZIXTWMD = new HttpClientParams();
        TXLZIXTWMD.setCookiePolicy(BROWSER_COMPATIBILITY);
        TXLZIXTWMD.setBooleanParameter(ALLOW_CIRCULAR_REDIRECTS, true);
        HttpClient ZBWKCXIMVV = new HttpClient(TXLZIXTWMD);
        // Make sure we send the request from the proxy address in the config
        // since that is what the AM filter checks against. IP aliasing or
        // similar could cause issues otherwise.
        HostConfiguration GQNZNRWWHP = new HostConfiguration();
        InetAddress OUZMGBRPJK = InetAddress.getByName(GFSOFAUSWZ);
        if (WebAppProxyServlet.TULDPMSLXJ.isDebugEnabled()) {
            WebAppProxyServlet.TULDPMSLXJ.debug("local InetAddress for proxy host: " + OUZMGBRPJK.toString());
        }
        GQNZNRWWHP.setLocalAddress(OUZMGBRPJK);
        HttpMethod UEQOQTTVPN = new org.apache.commons.httpclient.methods.GetMethod(UBHGYSCQRE.getEscapedURI());
        @SuppressWarnings("unchecked")
        Enumeration<String> JBQJSPBGQS = IBLVFAGSEF.getHeaderNames();
        while (JBQJSPBGQS.hasMoreElements()) {
            String UYVSIHBEUS = JBQJSPBGQS.nextElement();
            if (WebAppProxyServlet.EEGAZINGNE.contains(UYVSIHBEUS)) {
                String ZJZLKHWTAD = IBLVFAGSEF.getHeader(UYVSIHBEUS);
                WebAppProxyServlet.TULDPMSLXJ.debug((("REQ HEADER: " + UYVSIHBEUS) + " : ") + ZJZLKHWTAD);
                UEQOQTTVPN.setRequestHeader(UYVSIHBEUS, ZJZLKHWTAD);
            }
        } 
        String MWJAAKZVXD = IBLVFAGSEF.getRemoteUser();
        if ((MWJAAKZVXD != null) && (!MWJAAKZVXD.isEmpty())) {
            UEQOQTTVPN.setRequestHeader("Cookie", (WebAppProxyServlet.YAEHUJPJNT + "=") + URLEncoder.encode(MWJAAKZVXD, "ASCII"));
        }
        OutputStream SFRDXPSFZB = QVNKNOKOXO.getOutputStream();
        try {
            QVNKNOKOXO.setStatus(ZBWKCXIMVV.executeMethod(GQNZNRWWHP, UEQOQTTVPN));
            for (Header DLXXDUTGUC : UEQOQTTVPN.getResponseHeaders()) {
                QVNKNOKOXO.setHeader(DLXXDUTGUC.getName(), DLXXDUTGUC.getValue());
            }
            if (AKFDAHOTDY != null) {
                QVNKNOKOXO.addCookie(AKFDAHOTDY);
            }
            InputStream MNSEDCDCVL = UEQOQTTVPN.getResponseBodyAsStream();
            if (MNSEDCDCVL != null) {
                IOUtils.copyBytes(MNSEDCDCVL, SFRDXPSFZB, 4096, true);
            }
        } finally {
            UEQOQTTVPN.releaseConnection();
        }
    }

    private static String getCheckCookieName(ApplicationId YRDRDWGIWH) {
        return "checked_" + YRDRDWGIWH;
    }

    private static Cookie makeCheckCookie(ApplicationId CGILPCBYXQ, boolean HLGVDQVYDW) {
        Cookie AIMZMUEOJO = new Cookie(WebAppProxyServlet.getCheckCookieName(CGILPCBYXQ), String.valueOf(HLGVDQVYDW));
        AIMZMUEOJO.setPath(ProxyUriUtils.getPath(CGILPCBYXQ));
        AIMZMUEOJO.setMaxAge((60 * 60) * 2);// 2 hours in seconds

        return AIMZMUEOJO;
    }

    private boolean isSecurityEnabled() {
        Boolean KBWZZNUSSS = ((Boolean) (getServletContext().getAttribute(WebAppProxy.IS_SECURITY_ENABLED_ATTRIBUTE)));
        if (KBWZZNUSSS != null)
            return KBWZZNUSSS;

        return false;
    }

    private ApplicationReport getApplicationReport(ApplicationId UTHGFXVSEA) throws IOException, YarnException {
        return ((AppReportFetcher) (getServletContext().getAttribute(WebAppProxy.FETCHER_ATTRIBUTE))).getApplicationReport(UTHGFXVSEA);
    }

    private String getProxyHost() throws IOException {
        return ((String) (getServletContext().getAttribute(WebAppProxy.PROXY_HOST_ATTRIBUTE)));
    }

    @Override
    protected void doGet(HttpServletRequest IDKDUMJAOA, HttpServletResponse UFTUVIRRWM) throws IOException {
        try {
            String BAPYPTGVNJ = IDKDUMJAOA.getParameter(PROXY_APPROVAL_PARAM);
            boolean UTUSRZJLYM = false;
            boolean SYNNMOOQTL = (BAPYPTGVNJ != null) && Boolean.valueOf(BAPYPTGVNJ);
            boolean KUJARLITXG = isSecurityEnabled();
            final String CALMRVZTSN = IDKDUMJAOA.getRemoteUser();
            final String ACACJFDUQN = IDKDUMJAOA.getPathInfo();
            String[] SJRMEHLXGF = ACACJFDUQN.split("/", 3);
            if (SJRMEHLXGF.length < 2) {
                WebAppProxyServlet.TULDPMSLXJ.warn((CALMRVZTSN + " Gave an invalid proxy path ") + ACACJFDUQN);
                WebAppProxyServlet.notFound(UFTUVIRRWM, "Your path appears to be formatted incorrectly.");
                return;
            }
            // parts[0] is empty because path info always starts with a /
            String GJRHALOXMB = SJRMEHLXGF[1];
            String WQYALORWMH = (SJRMEHLXGF.length > 2) ? SJRMEHLXGF[2] : "";
            ApplicationId CIXSSKCVNZ = Apps.toAppID(GJRHALOXMB);
            if (CIXSSKCVNZ == null) {
                WebAppProxyServlet.TULDPMSLXJ.warn(((IDKDUMJAOA.getRemoteUser() + " Attempting to access ") + GJRHALOXMB) + " that is invalid");
                WebAppProxyServlet.notFound(UFTUVIRRWM, GJRHALOXMB + " appears to be formatted incorrectly.");
                return;
            }
            if (KUJARLITXG) {
                String OAOWUZJQGE = WebAppProxyServlet.getCheckCookieName(CIXSSKCVNZ);
                Cookie[] SMCURLRBCL = IDKDUMJAOA.getCookies();
                if (SMCURLRBCL != null) {
                    for (Cookie FYTXZQPILN : SMCURLRBCL) {
                        if (OAOWUZJQGE.equals(FYTXZQPILN.getName())) {
                            UTUSRZJLYM = true;
                            SYNNMOOQTL = SYNNMOOQTL || Boolean.valueOf(FYTXZQPILN.getValue());
                            break;
                        }
                    }
                }
            }
            boolean LDSFZHKXAB = KUJARLITXG && ((!UTUSRZJLYM) || (!SYNNMOOQTL));
            ApplicationReport OGGODNNVSU = null;
            try {
                OGGODNNVSU = getApplicationReport(CIXSSKCVNZ);
            } catch (ApplicationNotFoundException e) {
                OGGODNNVSU = null;
            }
            if (OGGODNNVSU == null) {
                WebAppProxyServlet.TULDPMSLXJ.warn(((IDKDUMJAOA.getRemoteUser() + " Attempting to access ") + CIXSSKCVNZ) + " that was not found");
                URI OMPFXXMZPW = ProxyUriUtils.getUriFromTrackingPlugins(CIXSSKCVNZ, this.IEHBRGOZFX);
                if (OMPFXXMZPW != null) {
                    UFTUVIRRWM.sendRedirect(UFTUVIRRWM.encodeRedirectURL(OMPFXXMZPW.toString()));
                    return;
                }
                WebAppProxyServlet.notFound(UFTUVIRRWM, (("Application " + GJRHALOXMB) + " could not be found, ") + "please try the history server");
                return;
            }
            String FMBJVCYFLY = OGGODNNVSU.getOriginalTrackingUrl();
            URI EQLAMDUMAA = null;
            // fallback to ResourceManager's app page if no tracking URI provided
            if ((FMBJVCYFLY == null) || FMBJVCYFLY.equals("N/A")) {
                UFTUVIRRWM.sendRedirect(UFTUVIRRWM.encodeRedirectURL(StringHelper.pjoin(SRZNZUSGXX, CIXSSKCVNZ.toString())));
                return;
            } else {
                if (ProxyUriUtils.getSchemeFromUrl(FMBJVCYFLY).isEmpty()) {
                    EQLAMDUMAA = ProxyUriUtils.getUriFromAMUrl(WebAppUtils.getHttpSchemePrefix(NVDVGUZUOQ), FMBJVCYFLY);
                } else {
                    EQLAMDUMAA = new URI(FMBJVCYFLY);
                }
            }
            String EZHFOWGEKT = OGGODNNVSU.getUser();
            if (LDSFZHKXAB && (!EZHFOWGEKT.equals(CALMRVZTSN))) {
                WebAppProxyServlet.TULDPMSLXJ.info(((((("Asking " + CALMRVZTSN) + " if they want to connect to the ") + "app master GUI of ") + GJRHALOXMB) + " owned by ") + EZHFOWGEKT);
                WebAppProxyServlet.warnUserPage(UFTUVIRRWM, ProxyUriUtils.getPathAndQuery(CIXSSKCVNZ, WQYALORWMH, IDKDUMJAOA.getQueryString(), true), EZHFOWGEKT, CIXSSKCVNZ);
                return;
            }
            URI TMRVUQVXDE = new URI(EQLAMDUMAA.getScheme(), EQLAMDUMAA.getAuthority(), StringHelper.ujoin(EQLAMDUMAA.getPath(), WQYALORWMH), IDKDUMJAOA.getQueryString(), null);
            WebAppProxyServlet.TULDPMSLXJ.info((((((IDKDUMJAOA.getRemoteUser() + " is accessing unchecked ") + TMRVUQVXDE) + " which is the app master GUI of ") + GJRHALOXMB) + " owned by ") + EZHFOWGEKT);
            switch (OGGODNNVSU.getYarnApplicationState()) {
                case KILLED :
                case FINISHED :
                case FAILED :
                    UFTUVIRRWM.sendRedirect(UFTUVIRRWM.encodeRedirectURL(TMRVUQVXDE.toString()));
                    return;
            }
            Cookie VAALTZMOBF = null;
            if (UTUSRZJLYM && SYNNMOOQTL) {
                VAALTZMOBF = WebAppProxyServlet.makeCheckCookie(CIXSSKCVNZ, true);
            }
            WebAppProxyServlet.proxyLink(IDKDUMJAOA, UFTUVIRRWM, TMRVUQVXDE, VAALTZMOBF, getProxyHost());
        } catch (URISyntaxException e) {
            throw new IOException(e);
        } catch (YarnException e) {
            throw new IOException(e);
        }
    }
}