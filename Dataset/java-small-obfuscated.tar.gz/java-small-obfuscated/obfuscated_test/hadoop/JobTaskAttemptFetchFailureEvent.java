public class JobTaskAttemptFetchFailureEvent extends JobEvent {
    private final TaskAttemptId LERALAFLGW;

    private final List<TaskAttemptId> SJYEOMCUHP;

    public JobTaskAttemptFetchFailureEvent(TaskAttemptId MBOTQEGZIJ, List<TaskAttemptId> YONUEEHODC) {
        super(MBOTQEGZIJ.getTaskId().getJobId(), JOB_TASK_ATTEMPT_FETCH_FAILURE);
        this.LERALAFLGW = MBOTQEGZIJ;
        this.SJYEOMCUHP = YONUEEHODC;
    }

    public List<TaskAttemptId> getMaps() {
        return SJYEOMCUHP;
    }

    public TaskAttemptId getReduce() {
        return LERALAFLGW;
    }
}