@Singleton
@Provider
public class MyTestJAXBContextResolver implements ContextResolver<JAXBContext> {
    private JAXBContext AWZCJDHZUN;

    private final Set<Class> XAEFBTONFW;

    // you have to specify all the dao classes here
    private final Class[] VVZPFBAUTT = new Class[]{ MyInfo.class };

    public MyTestJAXBContextResolver() throws Exception {
        this.XAEFBTONFW = new HashSet<Class>(Arrays.asList(VVZPFBAUTT));
        this.AWZCJDHZUN = new com.sun.jersey.api.json.JSONJAXBContext(com.sun.jersey.api.json.JSONConfiguration.natural().rootUnwrapping(false).build(), VVZPFBAUTT);
    }

    @Override
    public JAXBContext getContext(Class<?> FWFYBDECKY) {
        return XAEFBTONFW.contains(FWFYBDECKY) ? AWZCJDHZUN : null;
    }
}