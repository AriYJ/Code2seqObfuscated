/**
 * This class implements a mapper/reducer class that can be used to perform
 * field selections in a manner similar to unix cut. The input data is treated
 * as fields separated by a user specified separator (the default value is
 * "\t"). The user can specify a list of fields that form the map output keys,
 * and a list of fields that form the map output values. If the inputformat is
 * TextInputFormat, the mapper will ignore the key to the map function. and the
 * fields are from the value only. Otherwise, the fields are the union of those
 * from the key and those from the value.
 *
 * The field separator is under attribute "mapreduce.fieldsel.data.field.separator"
 *
 * The map output field list spec is under attribute
 * "mapreduce.fieldsel.map.output.key.value.fields.spec".
 * The value is expected to be like "keyFieldsSpec:valueFieldsSpec"
 * key/valueFieldsSpec are comma (,) separated field spec: fieldSpec,fieldSpec,fieldSpec ...
 * Each field spec can be a simple number (e.g. 5) specifying a specific field, or a range
 * (like 2-5) to specify a range of fields, or an open range (like 3-) specifying all
 * the fields starting from field 3. The open range field spec applies value fields only.
 * They have no effect on the key fields.
 *
 * Here is an example: "4,3,0,1:6,5,1-3,7-". It specifies to use fields 4,3,0 and 1 for keys,
 * and use fields 6,5,1,2,3,7 and above for values.
 *
 * The reduce output field list spec is under attribute
 * "mapreduce.fieldsel.reduce.output.key.value.fields.spec".
 *
 * The reducer extracts output key/value pairs in a similar manner, except that
 * the key is never ignored.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class FieldSelectionHelper {
    public static Text TZGGXUQFPS = new Text("");

    public static final String SAVNBEAYLM = "mapreduce.fieldsel.data.field.separator";

    public static final String QAALFRAOSE = "mapreduce.fieldsel.map.output.key.value.fields.spec";

    public static final String FVDQCAMSTD = "mapreduce.fieldsel.reduce.output.key.value.fields.spec";

    /**
     * Extract the actual field numbers from the given field specs.
     * If a field spec is in the form of "n-" (like 3-), then n will be the
     * return value. Otherwise, -1 will be returned.
     *
     * @param fieldListSpec
     * 		an array of field specs
     * @param fieldList
     * 		an array of field numbers extracted from the specs.
     * @return number n if some field spec is in the form of "n-", -1 otherwise.
     */
    private static int extractFields(String[] CBKSBAXPEU, List<Integer> IVHJNYFFUI) {
        int SENVXTEJFX = -1;
        int HZNBVNKGXR = 0;
        int DJSIGEBLBO = 0;
        int XQMMBQLCPV = -1;
        String PZCTLIKMWV = null;
        for (HZNBVNKGXR = 0; HZNBVNKGXR < CBKSBAXPEU.length; HZNBVNKGXR++) {
            PZCTLIKMWV = CBKSBAXPEU[HZNBVNKGXR];
            if (PZCTLIKMWV.length() == 0) {
                continue;
            }
            XQMMBQLCPV = PZCTLIKMWV.indexOf('-');
            if (XQMMBQLCPV < 0) {
                Integer JKYTWMPFGM = new Integer(PZCTLIKMWV);
                IVHJNYFFUI.add(JKYTWMPFGM);
            } else {
                String AEIIWMTQTV = PZCTLIKMWV.substring(0, XQMMBQLCPV);
                String FHUDMCBTLF = PZCTLIKMWV.substring(XQMMBQLCPV + 1);
                if (AEIIWMTQTV.length() == 0) {
                    AEIIWMTQTV = "0";
                }
                if (FHUDMCBTLF.length() == 0) {
                    SENVXTEJFX = Integer.parseInt(AEIIWMTQTV);
                    continue;
                }
                int XGWORMJDOU = Integer.parseInt(AEIIWMTQTV);
                int FZRNDZWASR = Integer.parseInt(FHUDMCBTLF);
                for (DJSIGEBLBO = XGWORMJDOU; DJSIGEBLBO <= FZRNDZWASR; DJSIGEBLBO++) {
                    IVHJNYFFUI.add(DJSIGEBLBO);
                }
            }
        }
        return SENVXTEJFX;
    }

    private static String selectFields(String[] XUGOABXSST, List<Integer> YUSIAKSFEF, int FILODZUJRN, String MZOQLHJSJC) {
        String ZPGKYONUYX = null;
        int YGHZFXIORI = 0;
        StringBuffer OHIKYZHUXU = null;
        if ((YUSIAKSFEF != null) && (YUSIAKSFEF.size() > 0)) {
            if (OHIKYZHUXU == null) {
                OHIKYZHUXU = new StringBuffer();
            }
            for (Integer KWEUHTQHDG : YUSIAKSFEF) {
                if (KWEUHTQHDG < XUGOABXSST.length) {
                    OHIKYZHUXU.append(XUGOABXSST[KWEUHTQHDG]);
                }
                OHIKYZHUXU.append(MZOQLHJSJC);
            }
        }
        if (FILODZUJRN >= 0) {
            if (OHIKYZHUXU == null) {
                OHIKYZHUXU = new StringBuffer();
            }
            for (YGHZFXIORI = FILODZUJRN; YGHZFXIORI < XUGOABXSST.length; YGHZFXIORI++) {
                OHIKYZHUXU.append(XUGOABXSST[YGHZFXIORI]).append(MZOQLHJSJC);
            }
        }
        if (OHIKYZHUXU != null) {
            ZPGKYONUYX = OHIKYZHUXU.toString();
            if (ZPGKYONUYX.length() > 0) {
                ZPGKYONUYX = ZPGKYONUYX.substring(0, ZPGKYONUYX.length() - 1);
            }
        }
        return ZPGKYONUYX;
    }

    public static int parseOutputKeyValueSpec(String DMAVYQPAOH, List<Integer> UNXPVPOQRV, List<Integer> LJKZFELZQD) {
        String[] NQKMWFWWZL = DMAVYQPAOH.split(":", -1);
        String[] WNYZJGXDEW = NQKMWFWWZL[0].split(",");
        String[] RCVCBNNTDF = new String[0];
        if (NQKMWFWWZL.length > 1) {
            RCVCBNNTDF = NQKMWFWWZL[1].split(",");
        }
        FieldSelectionHelper.extractFields(WNYZJGXDEW, UNXPVPOQRV);
        return FieldSelectionHelper.extractFields(RCVCBNNTDF, LJKZFELZQD);
    }

    public static String specToString(String UAPFEIJCFK, String VDDPVQXEVA, int PRZIBGNYQT, List<Integer> QAKUBMHXXP, List<Integer> XYEGPNGJQU) {
        StringBuffer GTORLXNKCA = new StringBuffer();
        GTORLXNKCA.append("fieldSeparator: ").append(UAPFEIJCFK).append("\n");
        GTORLXNKCA.append("keyValueSpec: ").append(VDDPVQXEVA).append("\n");
        GTORLXNKCA.append("allValueFieldsFrom: ").append(PRZIBGNYQT);
        GTORLXNKCA.append("\n");
        GTORLXNKCA.append("keyFieldList.length: ").append(QAKUBMHXXP.size());
        GTORLXNKCA.append("\n");
        for (Integer LVLSVENLPF : QAKUBMHXXP) {
            GTORLXNKCA.append("\t").append(LVLSVENLPF).append("\n");
        }
        GTORLXNKCA.append("valueFieldList.length: ").append(XYEGPNGJQU.size());
        GTORLXNKCA.append("\n");
        for (Integer SBWGUTLOYF : XYEGPNGJQU) {
            GTORLXNKCA.append("\t").append(SBWGUTLOYF).append("\n");
        }
        return GTORLXNKCA.toString();
    }

    private Text SNEXHKDMFP = null;

    private Text RTKDOIMEZT = null;

    public FieldSelectionHelper() {
    }

    public FieldSelectionHelper(Text KQBZOXKVLD, Text CCPWTVBANN) {
        this.SNEXHKDMFP = KQBZOXKVLD;
        this.RTKDOIMEZT = CCPWTVBANN;
    }

    public Text getKey() {
        return SNEXHKDMFP;
    }

    public Text getValue() {
        return RTKDOIMEZT;
    }

    public void extractOutputKeyValue(String LVYFFMRAFU, String MZMRWBLQRB, String VNCORHDEHI, List<Integer> QLXVJSNYUP, List<Integer> LLNOTDOLLG, int XGOLFSCSRT, boolean BAPMEUSMQG, boolean TIUEPMMHEF) {
        if (!BAPMEUSMQG) {
            MZMRWBLQRB = LVYFFMRAFU + MZMRWBLQRB;
        }
        String[] HLIFEKQFEL = MZMRWBLQRB.split(VNCORHDEHI);
        String YDFDPPXGKQ = FieldSelectionHelper.selectFields(HLIFEKQFEL, QLXVJSNYUP, -1, VNCORHDEHI);
        String UTKPJOMJHZ = FieldSelectionHelper.selectFields(HLIFEKQFEL, LLNOTDOLLG, XGOLFSCSRT, VNCORHDEHI);
        if (TIUEPMMHEF && (YDFDPPXGKQ == null)) {
            YDFDPPXGKQ = UTKPJOMJHZ;
            UTKPJOMJHZ = null;
        }
        if (YDFDPPXGKQ != null) {
            this.SNEXHKDMFP = new Text(YDFDPPXGKQ);
        }
        if (UTKPJOMJHZ != null) {
            this.RTKDOIMEZT = new Text(UTKPJOMJHZ);
        }
    }
}