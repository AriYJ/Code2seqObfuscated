/**
 * OutputStream that writes into a {@link ByteBuffer}.
 */
@InterfaceAudience.Private
@InterfaceStability.Stable
public class ByteBufferOutputStream extends OutputStream {
    private final ByteBuffer XAIEYDEHYH;

    public ByteBufferOutputStream(ByteBuffer JAXMSSFEYG) {
        this.XAIEYDEHYH = JAXMSSFEYG;
    }

    @Override
    public void write(int HUXHDZSAYR) throws IOException {
        XAIEYDEHYH.put(((byte) (HUXHDZSAYR)));
    }

    @Override
    public void write(byte[] OQICQDYMWK, int AYIZVOHKQV, int CXQGJDIJZP) throws IOException {
        XAIEYDEHYH.put(OQICQDYMWK, AYIZVOHKQV, CXQGJDIJZP);
    }
}