public class DefaultSpeculator extends AbstractService implements Speculator {
    private static final long ITCYQHIDLL = Long.MIN_VALUE;

    private static final long LBPJTMJOLW = Long.MIN_VALUE + 1;

    private static final long PVQFNLPFBI = Long.MIN_VALUE + 2;

    private static final long ACCVNCLNRF = Long.MIN_VALUE + 3;

    private static final long FONPHJMJVK = Long.MIN_VALUE + 4;

    private static final long PZXZPISTUW = Long.MIN_VALUE + 5;

    private static final long NSVHKHIFOV = 1000L * 1L;

    private static final long ROADSTUKWR = 1000L * 15L;

    private static final double ZDORHSDPAY = 0.1;

    private static final double AYLBLSAOCT = 0.01;

    private static final int OGPBXVCOTB = 10;

    private static final Log MMXUFZBCQG = LogFactory.getLog(DefaultSpeculator.class);

    private final ConcurrentMap<TaskId, Boolean> TKNIEZKSVX = new ConcurrentHashMap<TaskId, Boolean>();

    // Used to track any TaskAttempts that aren't heart-beating for a while, so
    // that we can aggressively speculate instead of waiting for task-timeout.
    private final ConcurrentMap<TaskAttemptId, DefaultSpeculator.TaskAttemptHistoryStatistics> QWBKCKGTFY = new ConcurrentHashMap<TaskAttemptId, DefaultSpeculator.TaskAttemptHistoryStatistics>();

    // Regular heartbeat from tasks is every 3 secs. So if we don't get a
    // heartbeat in 9 secs (3 heartbeats), we simulate a heartbeat with no change
    // in progress.
    private static final long NNGUHLWBGB = 9 * 1000;

    // These are the current needs, not the initial needs.  For each job, these
    // record the number of attempts that exist and that are actively
    // waiting for a container [as opposed to running or finished]
    private final ConcurrentMap<JobId, AtomicInteger> JESUEKZUMT = new ConcurrentHashMap<JobId, AtomicInteger>();

    private final ConcurrentMap<JobId, AtomicInteger> ZMSYFEQRJC = new ConcurrentHashMap<JobId, AtomicInteger>();

    private final Set<TaskId> UTXUJTHNVE = new HashSet<TaskId>();

    private final Configuration NPUZPQIBMK;

    private AppContext YHTJCFKVKW;

    private Thread RGLOGXCEVV = null;

    private volatile boolean SEVSQIMUST = false;

    private BlockingQueue<SpeculatorEvent> KJIXEYYZLI = new LinkedBlockingQueue<SpeculatorEvent>();

    private TaskRuntimeEstimator YXPACMWXHF;

    private BlockingQueue<Object> DLVBVCRJOH = new LinkedBlockingQueue<Object>();

    private final Clock QDKYCQFWJU;

    private final EventHandler<TaskEvent> QASSEZXALH;

    public DefaultSpeculator(Configuration ZQGSKVFZEY, AppContext XCQUIEFBUJ) {
        this(ZQGSKVFZEY, XCQUIEFBUJ, XCQUIEFBUJ.getClock());
    }

    public DefaultSpeculator(Configuration RMNWEXRCFX, AppContext PKSRWTDZRL, Clock WKILDMJEJC) {
        this(RMNWEXRCFX, PKSRWTDZRL, DefaultSpeculator.getEstimator(RMNWEXRCFX, PKSRWTDZRL), WKILDMJEJC);
    }

    private static TaskRuntimeEstimator getEstimator(Configuration LWQFEXMZCH, AppContext LFTPKVHNSQ) {
        TaskRuntimeEstimator AXXEUACAIK;
        try {
            // "yarn.mapreduce.job.task.runtime.estimator.class"
            Class<? extends TaskRuntimeEstimator> HNFTSEFTBI = LWQFEXMZCH.getClass(MR_AM_TASK_ESTIMATOR, LegacyTaskRuntimeEstimator.class, TaskRuntimeEstimator.class);
            Constructor<? extends TaskRuntimeEstimator> FRJYPXJTOY = HNFTSEFTBI.getConstructor();
            AXXEUACAIK = FRJYPXJTOY.newInstance();
            AXXEUACAIK.contextualize(LWQFEXMZCH, LFTPKVHNSQ);
        } catch (InstantiationException ex) {
            DefaultSpeculator.MMXUFZBCQG.error("Can't make a speculation runtime extimator", ex);
            throw new YarnRuntimeException(ex);
        } catch (IllegalAccessException ex) {
            DefaultSpeculator.MMXUFZBCQG.error("Can't make a speculation runtime extimator", ex);
            throw new YarnRuntimeException(ex);
        } catch (InvocationTargetException ex) {
            DefaultSpeculator.MMXUFZBCQG.error("Can't make a speculation runtime extimator", ex);
            throw new YarnRuntimeException(ex);
        } catch (NoSuchMethodException ex) {
            DefaultSpeculator.MMXUFZBCQG.error("Can't make a speculation runtime extimator", ex);
            throw new YarnRuntimeException(ex);
        }
        return AXXEUACAIK;
    }

    // This constructor is designed to be called by other constructors.
    // However, it's public because we do use it in the test cases.
    // Normally we figure out our own estimator.
    public DefaultSpeculator(Configuration ECWOZSGFFK, AppContext DGWQAITLGD, TaskRuntimeEstimator AJLEQJUZPK, Clock WGFMDKONCX) {
        super(DefaultSpeculator.class.getName());
        this.NPUZPQIBMK = ECWOZSGFFK;
        this.YHTJCFKVKW = DGWQAITLGD;
        this.YXPACMWXHF = AJLEQJUZPK;
        this.QDKYCQFWJU = WGFMDKONCX;
        this.QASSEZXALH = DGWQAITLGD.getEventHandler();
    }

    /* ************************************************************* */
    // This is the task-mongering that creates the two new threads -- one for
    // processing events from the event queue and one for periodically
    // looking for speculation opportunities
    @Override
    protected void serviceStart() throws Exception {
        Runnable CAFDBAKDYQ = new Runnable() {
            @Override
            public void run() {
                while ((!SEVSQIMUST) && (!Thread.currentThread().isInterrupted())) {
                    long EHYJIUXJRA = QDKYCQFWJU.getTime();
                    try {
                        int EFELAMUVCU = computeSpeculations();
                        long UPGZRXPDKB = (EFELAMUVCU > 0) ? DefaultSpeculator.ROADSTUKWR : DefaultSpeculator.NSVHKHIFOV;
                        long ZLZZPSUORP = Math.max(UPGZRXPDKB, QDKYCQFWJU.getTime() - EHYJIUXJRA);
                        if (EFELAMUVCU > 0) {
                            DefaultSpeculator.MMXUFZBCQG.info(((("We launched " + EFELAMUVCU) + " speculations.  Sleeping ") + ZLZZPSUORP) + " milliseconds.");
                        }
                        Object UMXLUGDFIH = DLVBVCRJOH.poll(ZLZZPSUORP, TimeUnit.MILLISECONDS);
                    } catch (InterruptedException e) {
                        if (!SEVSQIMUST) {
                            DefaultSpeculator.MMXUFZBCQG.error("Background thread returning, interrupted", e);
                        }
                        return;
                    }
                } 
            }
        };
        RGLOGXCEVV = new Thread(CAFDBAKDYQ, "DefaultSpeculator background processing");
        RGLOGXCEVV.start();
        super.serviceStart();
    }

    @Override
    protected void serviceStop() throws Exception {
        SEVSQIMUST = true;
        // this could be called before background thread is established
        if (RGLOGXCEVV != null) {
            RGLOGXCEVV.interrupt();
        }
        super.serviceStop();
    }

    @Override
    public void handleAttempt(TaskAttemptStatus FGSGZBFSWX) {
        long XDPNLKEXFV = QDKYCQFWJU.getTime();
        statusUpdate(FGSGZBFSWX, XDPNLKEXFV);
    }

    // This section is not part of the Speculator interface; it's used only for
    // testing
    public boolean eventQueueEmpty() {
        return KJIXEYYZLI.isEmpty();
    }

    // This interface is intended to be used only for test cases.
    public void scanForSpeculations() {
        DefaultSpeculator.MMXUFZBCQG.info("We got asked to run a debug speculation scan.");
        // debug
        System.out.println("We got asked to run a debug speculation scan.");
        System.out.println(("There are " + DLVBVCRJOH.size()) + " events stacked already.");
        DLVBVCRJOH.add(new Object());
        Thread.yield();
    }

    /* ************************************************************* */
    // This section contains the code that gets run for a SpeculatorEvent
    private AtomicInteger containerNeed(TaskId GHGWTXNZZH) {
        JobId ZZLUMYPPQD = GHGWTXNZZH.getJobId();
        TaskType RHFVFZDAZD = GHGWTXNZZH.getTaskType();
        ConcurrentMap<JobId, AtomicInteger> AWLXBJIKFJ = (RHFVFZDAZD == TaskType.MAP) ? JESUEKZUMT : ZMSYFEQRJC;
        AtomicInteger XREDWQZALM = AWLXBJIKFJ.get(ZZLUMYPPQD);
        if (XREDWQZALM == null) {
            AWLXBJIKFJ.putIfAbsent(ZZLUMYPPQD, new AtomicInteger(0));
            XREDWQZALM = AWLXBJIKFJ.get(ZZLUMYPPQD);
        }
        return XREDWQZALM;
    }

    private synchronized void processSpeculatorEvent(SpeculatorEvent WYFXCZHTXV) {
        switch (WYFXCZHTXV.getType()) {
            case ATTEMPT_STATUS_UPDATE :
                statusUpdate(WYFXCZHTXV.getReportedStatus(), WYFXCZHTXV.getTimestamp());
                break;
            case TASK_CONTAINER_NEED_UPDATE :
                {
                    AtomicInteger TJJKOSTFVC = containerNeed(WYFXCZHTXV.getTaskID());
                    TJJKOSTFVC.addAndGet(WYFXCZHTXV.containersNeededChange());
                    break;
                }
            case ATTEMPT_START :
                {
                    DefaultSpeculator.MMXUFZBCQG.info("ATTEMPT_START " + WYFXCZHTXV.getTaskID());
                    YXPACMWXHF.enrollAttempt(WYFXCZHTXV.getReportedStatus(), WYFXCZHTXV.getTimestamp());
                    break;
                }
            case JOB_CREATE :
                {
                    DefaultSpeculator.MMXUFZBCQG.info("JOB_CREATE " + WYFXCZHTXV.getJobID());
                    YXPACMWXHF.contextualize(getConfig(), YHTJCFKVKW);
                    break;
                }
        }
    }

    /**
     * Absorbs one TaskAttemptStatus
     *
     * @param reportedStatus
     * 		the status report that we got from a task attempt
     * 		that we want to fold into the speculation data for this job
     * @param timestamp
     * 		the time this status corresponds to.  This matters
     * 		because statuses contain progress.
     */
    protected void statusUpdate(TaskAttemptStatus DEIBFWPOUW, long MJMCTPFDBG) {
        String XWMIDGTDDS = DEIBFWPOUW.taskState.toString();
        TaskAttemptId YRYLUIBKCU = DEIBFWPOUW.id;
        TaskId CSJTOESDRS = YRYLUIBKCU.getTaskId();
        Job DPXYFEKLSN = YHTJCFKVKW.getJob(CSJTOESDRS.getJobId());
        if (DPXYFEKLSN == null) {
            return;
        }
        Task BZPZJZLQHI = DPXYFEKLSN.getTask(CSJTOESDRS);
        if (BZPZJZLQHI == null) {
            return;
        }
        YXPACMWXHF.updateAttempt(DEIBFWPOUW, MJMCTPFDBG);
        if (XWMIDGTDDS.equals(RUNNING.name())) {
            TKNIEZKSVX.putIfAbsent(CSJTOESDRS, Boolean.TRUE);
        } else {
            TKNIEZKSVX.remove(CSJTOESDRS, Boolean.TRUE);
            if (!XWMIDGTDDS.equals(STARTING.name())) {
                QWBKCKGTFY.remove(YRYLUIBKCU);
            }
        }
    }

    /* ************************************************************* */
    // This is the code section that runs periodically and adds speculations for
    // those jobs that need them.
    // This can return a few magic values for tasks that shouldn't speculate:
    // returns ON_SCHEDULE if thresholdRuntime(taskID) says that we should not
    // considering speculating this task
    // returns ALREADY_SPECULATING if that is true.  This has priority.
    // returns TOO_NEW if our companion task hasn't gotten any information
    // returns PROGRESS_IS_GOOD if the task is sailing through
    // returns NOT_RUNNING if the task is not running
    // 
    // All of these values are negative.  Any value that should be allowed to
    // speculate is 0 or positive.
    private long speculationValue(TaskId PIMPYLMJBH, long XWBEJXCZMR) {
        Job DRJRKFRXEX = YHTJCFKVKW.getJob(PIMPYLMJBH.getJobId());
        Task XIILZOARDU = DRJRKFRXEX.getTask(PIMPYLMJBH);
        Map<TaskAttemptId, TaskAttempt> RAZFQXJTMF = XIILZOARDU.getAttempts();
        long TEVNMRUYBE = Long.MIN_VALUE;
        long BMXJVMIBSS = Long.MIN_VALUE;
        if (!UTXUJTHNVE.contains(PIMPYLMJBH)) {
            TEVNMRUYBE = YXPACMWXHF.thresholdRuntime(PIMPYLMJBH);
            if (TEVNMRUYBE == Long.MAX_VALUE) {
                return DefaultSpeculator.ITCYQHIDLL;
            }
        }
        TaskAttemptId SJYZABLMVC = null;
        int PWPYZAWYUY = 0;
        for (TaskAttempt XUUUSMHBYI : RAZFQXJTMF.values()) {
            if ((XUUUSMHBYI.getState() == TaskAttemptState.RUNNING) || (XUUUSMHBYI.getState() == TaskAttemptState.STARTING)) {
                if ((++PWPYZAWYUY) > 1) {
                    return DefaultSpeculator.LBPJTMJOLW;
                }
                SJYZABLMVC = XUUUSMHBYI.getID();
                long KQNOIFVCSW = YXPACMWXHF.estimatedRuntime(SJYZABLMVC);
                long XQEHDTHOBO = YXPACMWXHF.attemptEnrolledTime(SJYZABLMVC);
                if (XQEHDTHOBO > XWBEJXCZMR) {
                    // This background process ran before we could process the task
                    // attempt status change that chronicles the attempt start
                    return DefaultSpeculator.PVQFNLPFBI;
                }
                long QPYKNBZKPF = KQNOIFVCSW + XQEHDTHOBO;
                long YWZKPQLOWZ = XWBEJXCZMR + YXPACMWXHF.estimatedNewAttemptRuntime(PIMPYLMJBH);
                float XSPMKDVLAU = XUUUSMHBYI.getProgress();
                DefaultSpeculator.TaskAttemptHistoryStatistics URDOKBHGFF = QWBKCKGTFY.get(SJYZABLMVC);
                if (URDOKBHGFF == null) {
                    QWBKCKGTFY.put(SJYZABLMVC, new DefaultSpeculator.TaskAttemptHistoryStatistics(KQNOIFVCSW, XSPMKDVLAU, XWBEJXCZMR));
                } else {
                    if ((KQNOIFVCSW == URDOKBHGFF.getEstimatedRunTime()) && (XSPMKDVLAU == URDOKBHGFF.getProgress())) {
                        // Previous stats are same as same stats
                        if (URDOKBHGFF.notHeartbeatedInAWhile(XWBEJXCZMR)) {
                            // Stats have stagnated for a while, simulate heart-beat.
                            TaskAttemptStatus EZVDXILNPR = new TaskAttemptStatus();
                            EZVDXILNPR.id = SJYZABLMVC;
                            EZVDXILNPR.progress = XSPMKDVLAU;
                            EZVDXILNPR.taskState = XUUUSMHBYI.getState();
                            // Now simulate the heart-beat
                            handleAttempt(EZVDXILNPR);
                        }
                    } else {
                        // Stats have changed - update our data structure
                        URDOKBHGFF.setEstimatedRunTime(KQNOIFVCSW);
                        URDOKBHGFF.setProgress(XSPMKDVLAU);
                        URDOKBHGFF.resetHeartBeatTime(XWBEJXCZMR);
                    }
                }
                if (QPYKNBZKPF < XWBEJXCZMR) {
                    return DefaultSpeculator.ACCVNCLNRF;
                }
                if (YWZKPQLOWZ >= QPYKNBZKPF) {
                    return DefaultSpeculator.PZXZPISTUW;
                }
                BMXJVMIBSS = QPYKNBZKPF - YWZKPQLOWZ;
            }
        }
        // If we are here, there's at most one task attempt.
        if (PWPYZAWYUY == 0) {
            return DefaultSpeculator.FONPHJMJVK;
        }
        if (TEVNMRUYBE == Long.MIN_VALUE) {
            TEVNMRUYBE = YXPACMWXHF.thresholdRuntime(PIMPYLMJBH);
            if (TEVNMRUYBE == Long.MAX_VALUE) {
                return DefaultSpeculator.ITCYQHIDLL;
            }
        }
        return BMXJVMIBSS;
    }

    // Add attempt to a given Task.
    protected void addSpeculativeAttempt(TaskId HHNWBOAKGA) {
        DefaultSpeculator.MMXUFZBCQG.info("DefaultSpeculator.addSpeculativeAttempt -- we are speculating " + HHNWBOAKGA);
        QASSEZXALH.handle(new TaskEvent(HHNWBOAKGA, TaskEventType.T_ADD_SPEC_ATTEMPT));
        UTXUJTHNVE.add(HHNWBOAKGA);
    }

    @Override
    public void handle(SpeculatorEvent NKFJFAKUNE) {
        processSpeculatorEvent(NKFJFAKUNE);
    }

    private int maybeScheduleAMapSpeculation() {
        return maybeScheduleASpeculation(MAP);
    }

    private int maybeScheduleAReduceSpeculation() {
        return maybeScheduleASpeculation(REDUCE);
    }

    private int maybeScheduleASpeculation(TaskType NUSBMDUXJE) {
        int BFGHXQRYTH = 0;
        long GOILFYYIWO = QDKYCQFWJU.getTime();
        ConcurrentMap<JobId, AtomicInteger> JPJIUCIHCM = (NUSBMDUXJE == TaskType.MAP) ? JESUEKZUMT : ZMSYFEQRJC;
        for (Map.Entry<JobId, AtomicInteger> MSRQXXVRQT : JPJIUCIHCM.entrySet()) {
            // This race conditon is okay.  If we skip a speculation attempt we
            // should have tried because the event that lowers the number of
            // containers needed to zero hasn't come through, it will next time.
            // Also, if we miss the fact that the number of containers needed was
            // zero but increased due to a failure it's not too bad to launch one
            // container prematurely.
            if (MSRQXXVRQT.getValue().get() > 0) {
                continue;
            }
            int DSYKUIHZBL = 0;
            int EYQVHVJFRW = 0;
            // loop through the tasks of the kind
            Job JHRSIELEPZ = YHTJCFKVKW.getJob(MSRQXXVRQT.getKey());
            Map<TaskId, Task> ELZXLBYRDF = JHRSIELEPZ.getTasks(NUSBMDUXJE);
            int UBEWILZJWN = ((int) (Math.max(DefaultSpeculator.OGPBXVCOTB, DefaultSpeculator.AYLBLSAOCT * ELZXLBYRDF.size())));
            TaskId UWDXVYOIFJ = null;
            long HFQETHRKTD = -1L;
            // this loop is potentially pricey.
            // TODO track the tasks that are potentially worth looking at
            for (Map.Entry<TaskId, Task> YGTETNXIKF : ELZXLBYRDF.entrySet()) {
                long FMMLVEKCGD = speculationValue(YGTETNXIKF.getKey(), GOILFYYIWO);
                if (FMMLVEKCGD == DefaultSpeculator.LBPJTMJOLW) {
                    ++DSYKUIHZBL;
                }
                if (FMMLVEKCGD != DefaultSpeculator.FONPHJMJVK) {
                    ++EYQVHVJFRW;
                }
                if (FMMLVEKCGD > HFQETHRKTD) {
                    UWDXVYOIFJ = YGTETNXIKF.getKey();
                    HFQETHRKTD = FMMLVEKCGD;
                }
            }
            UBEWILZJWN = ((int) (Math.max(UBEWILZJWN, DefaultSpeculator.ZDORHSDPAY * EYQVHVJFRW)));
            // If we found a speculation target, fire it off
            if ((UWDXVYOIFJ != null) && (UBEWILZJWN > DSYKUIHZBL)) {
                addSpeculativeAttempt(UWDXVYOIFJ);
                ++BFGHXQRYTH;
            }
        }
        return BFGHXQRYTH;
    }

    private int computeSpeculations() {
        // We'll try to issue one map and one reduce speculation per job per run
        return maybeScheduleAMapSpeculation() + maybeScheduleAReduceSpeculation();
    }

    static class TaskAttemptHistoryStatistics {
        private long VJHDZXXTPQ;

        private float HOSOMXDLDR;

        private long DTKGHRPNMR;

        public TaskAttemptHistoryStatistics(long estimatedRunTime, float progress, long nonProgressStartTime) {
            this.VJHDZXXTPQ = estimatedRunTime;
            this.HOSOMXDLDR = progress;
            resetHeartBeatTime(nonProgressStartTime);
        }

        public long getEstimatedRunTime() {
            return this.VJHDZXXTPQ;
        }

        public float getProgress() {
            return this.HOSOMXDLDR;
        }

        public void setEstimatedRunTime(long estimatedRunTime) {
            this.VJHDZXXTPQ = estimatedRunTime;
        }

        public void setProgress(float progress) {
            this.HOSOMXDLDR = progress;
        }

        public boolean notHeartbeatedInAWhile(long now) {
            if ((now - DTKGHRPNMR) <= DefaultSpeculator.NNGUHLWBGB) {
                return false;
            } else {
                resetHeartBeatTime(now);
                return true;
            }
        }

        public void resetHeartBeatTime(long lastHeartBeatTime) {
            this.DTKGHRPNMR = lastHeartBeatTime;
        }
    }
}