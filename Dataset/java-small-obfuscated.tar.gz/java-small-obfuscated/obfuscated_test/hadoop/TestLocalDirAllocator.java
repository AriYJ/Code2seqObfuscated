/**
 * This test LocalDirAllocator works correctly;
 * Every test case uses different buffer dirs to
 * enforce the AllocatorPerContext initialization.
 * This test does not run on Cygwin because under Cygwin
 * a directory can be created in a read-only directory
 * which breaks this test.
 */
@RunWith(Parameterized.class)
public class TestLocalDirAllocator {
    private static final Configuration WVZSGZFBLM = new Configuration();

    private static final String UTLPMFBUHE = "build/test/temp";

    private static final String LCRALHIYMW;

    private static final String UTTLACCSRZ;

    private static final Path JVGCBYJIEN = new Path(TestLocalDirAllocator.UTLPMFBUHE);

    private static final File HWFFOSJCZX = new File(TestLocalDirAllocator.UTLPMFBUHE);

    private static final String CLBKKJNQMR = "mapred.local.dir";

    private static final String XGKZWPEUFZ = "block";

    private static final LocalDirAllocator WRVJPLKJDM = new LocalDirAllocator(TestLocalDirAllocator.CLBKKJNQMR);

    static LocalFileSystem FRTWUTXICJ;

    private static final boolean UWCVERVIPL = System.getProperty("os.name").startsWith("Windows");

    static final int GWVHESFMTX = 100;

    private static final String CMPBTVLDQU = "/RELATIVE";

    private static final String BLRORLYNVF = "/ABSOLUTE";

    private static final String RJJEBNJIJQ = "/QUALIFIED";

    private final String TBGLUHBTVP;

    private final String HMWAYRVTJP;

    static {
        try {
            TestLocalDirAllocator.FRTWUTXICJ = FileSystem.getLocal(TestLocalDirAllocator.WVZSGZFBLM);
            TestLocalDirAllocator.rmBufferDirs();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            System.exit(-1);
        }
        // absolute path in test environment
        // /home/testuser/src/hadoop-common-project/hadoop-common/build/test/temp
        LCRALHIYMW = new Path(TestLocalDirAllocator.FRTWUTXICJ.getWorkingDirectory(), TestLocalDirAllocator.UTLPMFBUHE).toUri().getPath();
        // file:/home/testuser/src/hadoop-common-project/hadoop-common/build/test/temp
        UTTLACCSRZ = new Path(TestLocalDirAllocator.FRTWUTXICJ.getWorkingDirectory(), TestLocalDirAllocator.UTLPMFBUHE).toUri().toString();
    }

    public TestLocalDirAllocator(String TDFRTOELEK, String GRFYCCIALP) {
        TBGLUHBTVP = TDFRTOELEK;
        HMWAYRVTJP = GRFYCCIALP;
    }

    @Parameters
    public static Collection<Object[]> params() {
        Object[][] PXIEXSFUOF = new Object[][]{ new Object[]{ TestLocalDirAllocator.UTLPMFBUHE, TestLocalDirAllocator.CMPBTVLDQU }, new Object[]{ TestLocalDirAllocator.LCRALHIYMW, TestLocalDirAllocator.BLRORLYNVF }, new Object[]{ TestLocalDirAllocator.UTTLACCSRZ, TestLocalDirAllocator.RJJEBNJIJQ } };
        return Arrays.asList(PXIEXSFUOF);
    }

    private static void rmBufferDirs() throws IOException {
        assertTrue((!TestLocalDirAllocator.FRTWUTXICJ.exists(TestLocalDirAllocator.JVGCBYJIEN)) || TestLocalDirAllocator.FRTWUTXICJ.delete(TestLocalDirAllocator.JVGCBYJIEN, true));
    }

    private static void validateTempDirCreation(String KPXWMYHQGO) throws IOException {
        File ZIFUJPTRAA = TestLocalDirAllocator.createTempFile(TestLocalDirAllocator.GWVHESFMTX);
        assertTrue(((("Checking for " + KPXWMYHQGO) + " in ") + ZIFUJPTRAA) + " - FAILED!", ZIFUJPTRAA.getPath().startsWith(new Path(KPXWMYHQGO, TestLocalDirAllocator.XGKZWPEUFZ).toUri().getPath()));
    }

    private static File createTempFile() throws IOException {
        return TestLocalDirAllocator.createTempFile(-1);
    }

    private static File createTempFile(long ETRENZHCRK) throws IOException {
        File NOMWDAKDGP = TestLocalDirAllocator.WRVJPLKJDM.createTmpFileForWrite(TestLocalDirAllocator.XGKZWPEUFZ, ETRENZHCRK, TestLocalDirAllocator.WVZSGZFBLM);
        NOMWDAKDGP.delete();
        return NOMWDAKDGP;
    }

    private String buildBufferDir(String KOMCVNUMRG, int HPTUEHYWBU) {
        return (KOMCVNUMRG + HMWAYRVTJP) + HPTUEHYWBU;
    }

    /**
     * Two buffer dirs. The first dir does not exist & is on a read-only disk;
     * The second dir exists & is RW
     *
     * @throws Exception
     * 		
     */
    @Test(timeout = 30000)
    public void test0() throws Exception {
        if (TestLocalDirAllocator.UWCVERVIPL)
            return;

        String UZASPKGRPP = buildBufferDir(TBGLUHBTVP, 0);
        String MHJPBMNUXI = buildBufferDir(TBGLUHBTVP, 1);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, (UZASPKGRPP + ",") + MHJPBMNUXI);
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(MHJPBMNUXI)));
            TestLocalDirAllocator.HWFFOSJCZX.setReadOnly();
            TestLocalDirAllocator.validateTempDirCreation(MHJPBMNUXI);
            TestLocalDirAllocator.validateTempDirCreation(MHJPBMNUXI);
        } finally {
            Shell.execCommand(Shell.getSetPermissionCommand("u+w", false, TestLocalDirAllocator.UTLPMFBUHE));
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    /**
     * Two buffer dirs. The first dir exists & is on a read-only disk;
     * The second dir exists & is RW
     *
     * @throws Exception
     * 		
     */
    @Test(timeout = 30000)
    public void testROBufferDirAndRWBufferDir() throws Exception {
        if (TestLocalDirAllocator.UWCVERVIPL)
            return;

        String QHSTABQJTK = buildBufferDir(TBGLUHBTVP, 1);
        String CJVDDXHPNE = buildBufferDir(TBGLUHBTVP, 2);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, (QHSTABQJTK + ",") + CJVDDXHPNE);
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(CJVDDXHPNE)));
            TestLocalDirAllocator.HWFFOSJCZX.setReadOnly();
            TestLocalDirAllocator.validateTempDirCreation(CJVDDXHPNE);
            TestLocalDirAllocator.validateTempDirCreation(CJVDDXHPNE);
        } finally {
            Shell.execCommand(Shell.getSetPermissionCommand("u+w", false, TestLocalDirAllocator.UTLPMFBUHE));
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    /**
     * Two buffer dirs. Both do not exist but on a RW disk.
     * Check if tmp dirs are allocated in a round-robin
     */
    @Test(timeout = 30000)
    public void testDirsNotExist() throws Exception {
        if (TestLocalDirAllocator.UWCVERVIPL)
            return;

        String EHVYKROMIY = buildBufferDir(TBGLUHBTVP, 2);
        String XQKGTBHHSE = buildBufferDir(TBGLUHBTVP, 3);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, (EHVYKROMIY + ",") + XQKGTBHHSE);
            // create the first file, and then figure the round-robin sequence
            TestLocalDirAllocator.createTempFile(TestLocalDirAllocator.GWVHESFMTX);
            int NKATOPFDKY = (TestLocalDirAllocator.WRVJPLKJDM.getCurrentDirectoryIndex() == 0) ? 2 : 3;
            int FFZIBDVEZU = (NKATOPFDKY == 2) ? 3 : 2;
            // check if tmp dirs are allocated in a round-robin manner
            TestLocalDirAllocator.validateTempDirCreation(buildBufferDir(TBGLUHBTVP, NKATOPFDKY));
            TestLocalDirAllocator.validateTempDirCreation(buildBufferDir(TBGLUHBTVP, FFZIBDVEZU));
            TestLocalDirAllocator.validateTempDirCreation(buildBufferDir(TBGLUHBTVP, NKATOPFDKY));
        } finally {
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    /**
     * Two buffer dirs. Both exists and on a R/W disk.
     * Later disk1 becomes read-only.
     *
     * @throws Exception
     * 		
     */
    @Test(timeout = 30000)
    public void testRWBufferDirBecomesRO() throws Exception {
        if (TestLocalDirAllocator.UWCVERVIPL)
            return;

        String APGRWUEYKM = buildBufferDir(TBGLUHBTVP, 3);
        String QDTOSSKENO = buildBufferDir(TBGLUHBTVP, 4);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, (APGRWUEYKM + ",") + QDTOSSKENO);
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(APGRWUEYKM)));
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(QDTOSSKENO)));
            // Create the first small file
            TestLocalDirAllocator.createTempFile(TestLocalDirAllocator.GWVHESFMTX);
            // Determine the round-robin sequence
            int UORSNSOGRG = (TestLocalDirAllocator.WRVJPLKJDM.getCurrentDirectoryIndex() == 0) ? 3 : 4;
            TestLocalDirAllocator.validateTempDirCreation(buildBufferDir(TBGLUHBTVP, UORSNSOGRG));
            // change buffer directory 2 to be read only
            new File(new Path(QDTOSSKENO).toUri().getPath()).setReadOnly();
            TestLocalDirAllocator.validateTempDirCreation(APGRWUEYKM);
            TestLocalDirAllocator.validateTempDirCreation(APGRWUEYKM);
        } finally {
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    /**
     * Two buffer dirs, on read-write disk.
     *
     * Try to create a whole bunch of files.
     *  Verify that they do indeed all get created where they should.
     *
     *  Would ideally check statistical properties of distribution, but
     *  we don't have the nerve to risk false-positives here.
     *
     * @throws Exception
     * 		
     */
    static final int BGJPMHHMVM = 100;

    @Test(timeout = 30000)
    public void testCreateManyFiles() throws Exception {
        if (TestLocalDirAllocator.UWCVERVIPL)
            return;

        String GQEIWIHXIL = buildBufferDir(TBGLUHBTVP, 5);
        String AWBNIENYFS = buildBufferDir(TBGLUHBTVP, 6);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, (GQEIWIHXIL + ",") + AWBNIENYFS);
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(GQEIWIHXIL)));
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(AWBNIENYFS)));
            int EGAKRIYJWJ = 0;
            int WNSGHFOVTK = 0;
            for (int TGDFKDADTY = 0; TGDFKDADTY < TestLocalDirAllocator.BGJPMHHMVM; ++TGDFKDADTY) {
                File AIPZDOYQFR = TestLocalDirAllocator.createTempFile();
                if (AIPZDOYQFR.getPath().startsWith(new Path(GQEIWIHXIL, TestLocalDirAllocator.XGKZWPEUFZ).toUri().getPath())) {
                    EGAKRIYJWJ++;
                } else
                    if (AIPZDOYQFR.getPath().startsWith(new Path(AWBNIENYFS, TestLocalDirAllocator.XGKZWPEUFZ).toUri().getPath())) {
                        WNSGHFOVTK++;
                    }

                AIPZDOYQFR.delete();
            }
            assertTrue((EGAKRIYJWJ + WNSGHFOVTK) == TestLocalDirAllocator.BGJPMHHMVM);
        } finally {
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    /**
     * Two buffer dirs. The first dir does not exist & is on a read-only disk;
     * The second dir exists & is RW
     * getLocalPathForWrite with checkAccess set to false should create a parent
     * directory. With checkAccess true, the directory should not be created.
     *
     * @throws Exception
     * 		
     */
    @Test(timeout = 30000)
    public void testLocalPathForWriteDirCreation() throws IOException {
        String SNPDCLLSLT = buildBufferDir(TBGLUHBTVP, 0);
        String BHZTYMEXTR = buildBufferDir(TBGLUHBTVP, 1);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, (SNPDCLLSLT + ",") + BHZTYMEXTR);
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(BHZTYMEXTR)));
            TestLocalDirAllocator.HWFFOSJCZX.setReadOnly();
            Path JMRSXCONKJ = TestLocalDirAllocator.WRVJPLKJDM.getLocalPathForWrite("p1/x", TestLocalDirAllocator.GWVHESFMTX, TestLocalDirAllocator.WVZSGZFBLM);
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.getFileStatus(JMRSXCONKJ.getParent()).isDirectory());
            Path RMJNCHHZYK = TestLocalDirAllocator.WRVJPLKJDM.getLocalPathForWrite("p2/x", TestLocalDirAllocator.GWVHESFMTX, TestLocalDirAllocator.WVZSGZFBLM, false);
            try {
                TestLocalDirAllocator.FRTWUTXICJ.getFileStatus(RMJNCHHZYK.getParent());
            } catch (Exception e) {
                assertEquals(e.getClass(), FileNotFoundException.class);
            }
        } finally {
            Shell.execCommand(Shell.getSetPermissionCommand("u+w", false, TestLocalDirAllocator.UTLPMFBUHE));
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    /* Test when mapred.local.dir not configured and called
    getLocalPathForWrite
     */
    @Test(timeout = 30000)
    public void testShouldNotthrowNPE() throws Exception {
        Configuration QAXLUMCLGL = new Configuration();
        try {
            TestLocalDirAllocator.WRVJPLKJDM.getLocalPathForWrite("/test", QAXLUMCLGL);
            fail(("Exception not thrown when " + TestLocalDirAllocator.CLBKKJNQMR) + " is not set");
        } catch (IOException e) {
            assertEquals(TestLocalDirAllocator.CLBKKJNQMR + " not configured", e.getMessage());
        } catch (NullPointerException e) {
            fail("Lack of configuration should not have thrown an NPE.");
        }
    }

    /**
     * Test no side effect files are left over. After creating a temp
     * temp file, remove both the temp file and its parent. Verify that
     * no files or directories are left over as can happen when File objects
     * are mistakenly created from fully qualified path strings.
     *
     * @throws IOException
     * 		
     */
    @Test(timeout = 30000)
    public void testNoSideEffects() throws IOException {
        assumeTrue(!TestLocalDirAllocator.UWCVERVIPL);
        String GUMBRNIFCE = buildBufferDir(TBGLUHBTVP, 0);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, GUMBRNIFCE);
            File XLGWHISSPD = TestLocalDirAllocator.WRVJPLKJDM.createTmpFileForWrite(TestLocalDirAllocator.XGKZWPEUFZ, -1, TestLocalDirAllocator.WVZSGZFBLM);
            assertTrue(XLGWHISSPD.delete());
            assertTrue(XLGWHISSPD.getParentFile().delete());
            assertFalse(new File(GUMBRNIFCE).exists());
        } finally {
            Shell.execCommand(Shell.getSetPermissionCommand("u+w", false, TestLocalDirAllocator.UTLPMFBUHE));
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    /**
     * Test getLocalPathToRead() returns correct filename and "file" schema.
     *
     * @throws IOException
     * 		
     */
    @Test(timeout = 30000)
    public void testGetLocalPathToRead() throws IOException {
        assumeTrue(!TestLocalDirAllocator.UWCVERVIPL);
        String NCCTWWJFDP = buildBufferDir(TBGLUHBTVP, 0);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, NCCTWWJFDP);
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(NCCTWWJFDP)));
            File RAGQKPKFAD = TestLocalDirAllocator.WRVJPLKJDM.createTmpFileForWrite(TestLocalDirAllocator.XGKZWPEUFZ, TestLocalDirAllocator.GWVHESFMTX, TestLocalDirAllocator.WVZSGZFBLM);
            Path ZBEFRXDOHF = TestLocalDirAllocator.WRVJPLKJDM.getLocalPathToRead(RAGQKPKFAD.getName(), TestLocalDirAllocator.WVZSGZFBLM);
            assertEquals(RAGQKPKFAD.getName(), ZBEFRXDOHF.getName());
            assertEquals("file", ZBEFRXDOHF.getFileSystem(TestLocalDirAllocator.WVZSGZFBLM).getUri().getScheme());
        } finally {
            Shell.execCommand(Shell.getSetPermissionCommand("u+w", false, TestLocalDirAllocator.UTLPMFBUHE));
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    /**
     * Test that {@link LocalDirAllocator#getAllLocalPathsToRead(String, Configuration)}
     * returns correct filenames and "file" schema.
     *
     * @throws IOException
     * 		
     */
    @Test(timeout = 30000)
    public void testGetAllLocalPathsToRead() throws IOException {
        assumeTrue(!TestLocalDirAllocator.UWCVERVIPL);
        String SHIVJETDRK = buildBufferDir(TBGLUHBTVP, 0);
        String LCBKZRHTST = buildBufferDir(TBGLUHBTVP, 1);
        try {
            TestLocalDirAllocator.WVZSGZFBLM.set(TestLocalDirAllocator.CLBKKJNQMR, (SHIVJETDRK + ",") + LCBKZRHTST);
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(SHIVJETDRK)));
            assertTrue(TestLocalDirAllocator.FRTWUTXICJ.mkdirs(new Path(LCBKZRHTST)));
            TestLocalDirAllocator.FRTWUTXICJ.create(new Path((SHIVJETDRK + Path.SEPARATOR) + TestLocalDirAllocator.XGKZWPEUFZ));
            TestLocalDirAllocator.FRTWUTXICJ.create(new Path((LCBKZRHTST + Path.SEPARATOR) + TestLocalDirAllocator.XGKZWPEUFZ));
            // check both the paths are returned as paths to read:
            final Iterable<Path> LLPDBUPVHM = TestLocalDirAllocator.WRVJPLKJDM.getAllLocalPathsToRead(TestLocalDirAllocator.XGKZWPEUFZ, TestLocalDirAllocator.WVZSGZFBLM);
            int NEJZCYRAEB = 0;
            for (final Path HYPQYDSJEJ : LLPDBUPVHM) {
                NEJZCYRAEB++;
                assertEquals(TestLocalDirAllocator.XGKZWPEUFZ, HYPQYDSJEJ.getName());
                assertEquals("file", HYPQYDSJEJ.getFileSystem(TestLocalDirAllocator.WVZSGZFBLM).getUri().getScheme());
            }
            assertEquals(2, NEJZCYRAEB);
            // test #next() while no element to iterate any more:
            try {
                Path OERDTCSRDT = LLPDBUPVHM.iterator().next();
                assertFalse(("NoSuchElementException must be thrown, but returned [" + OERDTCSRDT) + "] instead.", true);// exception expected

            } catch (NoSuchElementException nsee) {
                // okay
            }
            // test modification not allowed:
            final Iterable<Path> OZAHPBNUEB = TestLocalDirAllocator.WRVJPLKJDM.getAllLocalPathsToRead(TestLocalDirAllocator.XGKZWPEUFZ, TestLocalDirAllocator.WVZSGZFBLM);
            final Iterator<Path> WMQYJYQXKR = OZAHPBNUEB.iterator();
            try {
                WMQYJYQXKR.remove();
                assertFalse(true);// exception expected

            } catch (UnsupportedOperationException uoe) {
                // okay
            }
        } finally {
            Shell.execCommand(new String[]{ "chmod", "u+w", TestLocalDirAllocator.UTLPMFBUHE });
            TestLocalDirAllocator.rmBufferDirs();
        }
    }

    @Test(timeout = 30000)
    public void testRemoveContext() throws IOException {
        String XNGVDKBRFI = buildBufferDir(TBGLUHBTVP, 0);
        try {
            String VBLTNZNZLE = "application_1340842292563_0004.app.cache.dirs";
            TestLocalDirAllocator.WVZSGZFBLM.set(VBLTNZNZLE, XNGVDKBRFI);
            LocalDirAllocator XKEJBOYVYW = new LocalDirAllocator(VBLTNZNZLE);
            XKEJBOYVYW.getLocalPathForWrite("p1/x", TestLocalDirAllocator.GWVHESFMTX, TestLocalDirAllocator.WVZSGZFBLM);
            assertTrue(LocalDirAllocator.isContextValid(VBLTNZNZLE));
            LocalDirAllocator.removeContext(VBLTNZNZLE);
            assertFalse(LocalDirAllocator.isContextValid(VBLTNZNZLE));
        } finally {
            TestLocalDirAllocator.rmBufferDirs();
        }
    }
}