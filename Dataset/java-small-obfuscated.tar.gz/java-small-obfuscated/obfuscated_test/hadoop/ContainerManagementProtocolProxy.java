/**
 * Helper class to manage container manager proxies
 */
@LimitedPrivate({ "MapReduce", "YARN" })
public class ContainerManagementProtocolProxy {
    static final Log DSNEBOIDHT = LogFactory.getLog(ContainerManagementProtocolProxy.class);

    private final int XDZKIAWDDW;

    private final LinkedHashMap<String, ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData> BLLTXRBYXT;

    private final Configuration OJTPCUIWHG;

    private final YarnRPC RIAQBUJEMH;

    private NMTokenCache QZUABCBQPV;

    public ContainerManagementProtocolProxy(Configuration PCGBCHQDAM) {
        this(PCGBCHQDAM, NMTokenCache.getSingleton());
    }

    public ContainerManagementProtocolProxy(Configuration OKQBHWKMYJ, NMTokenCache VPRFXLWWIJ) {
        this.OJTPCUIWHG = OKQBHWKMYJ;
        this.QZUABCBQPV = VPRFXLWWIJ;
        XDZKIAWDDW = OKQBHWKMYJ.getInt(NM_CLIENT_MAX_NM_PROXIES, DEFAULT_NM_CLIENT_MAX_NM_PROXIES);
        if (XDZKIAWDDW < 1) {
            throw new org.apache.hadoop.yarn.exceptions.YarnRuntimeException(((YarnConfiguration.NM_CLIENT_MAX_NM_PROXIES + " (") + XDZKIAWDDW) + ") can not be less than 1.");
        }
        ContainerManagementProtocolProxy.DSNEBOIDHT.info((YarnConfiguration.NM_CLIENT_MAX_NM_PROXIES + " : ") + XDZKIAWDDW);
        BLLTXRBYXT = new LinkedHashMap<String, ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData>();
        RIAQBUJEMH = YarnRPC.create(OKQBHWKMYJ);
    }

    public synchronized ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData getProxy(String GWHVLKHOEX, ContainerId XWRMVVRMCW) throws InvalidToken {
        // This get call will update the map which is working as LRU cache.
        ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData DBVVKCMTOA = BLLTXRBYXT.get(GWHVLKHOEX);
        while ((DBVVKCMTOA != null) && (!DBVVKCMTOA.SUDESYPQOO.getIdentifier().equals(QZUABCBQPV.getToken(GWHVLKHOEX).getIdentifier()))) {
            ContainerManagementProtocolProxy.DSNEBOIDHT.info("Refreshing proxy as NMToken got updated for node : " + GWHVLKHOEX);
            // Token is updated. check if anyone has already tried closing it.
            if (!DBVVKCMTOA.NPQZBNCYEZ) {
                // try closing the proxy. Here if someone is already using it
                // then we might not close it. In which case we will wait.
                removeProxy(DBVVKCMTOA);
            } else {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (DBVVKCMTOA.QDPTMBZHYR < 0) {
                DBVVKCMTOA = BLLTXRBYXT.get(GWHVLKHOEX);
            }
        } 
        if (DBVVKCMTOA == null) {
            DBVVKCMTOA = new ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData(RIAQBUJEMH, GWHVLKHOEX, XWRMVVRMCW, QZUABCBQPV.getToken(GWHVLKHOEX));
            if (BLLTXRBYXT.size() > XDZKIAWDDW) {
                // Number of existing proxy exceed the limit.
                String IQYFMFGNTV = BLLTXRBYXT.keySet().iterator().next();
                removeProxy(BLLTXRBYXT.get(IQYFMFGNTV));
            }
            BLLTXRBYXT.put(GWHVLKHOEX, DBVVKCMTOA);
        }
        // This is to track active users of this proxy.
        DBVVKCMTOA.QDPTMBZHYR++;
        updateLRUCache(GWHVLKHOEX);
        return DBVVKCMTOA;
    }

    private void updateLRUCache(String JIAMNGUWDP) {
        ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData AVFXUDAHYH = BLLTXRBYXT.remove(JIAMNGUWDP);
        BLLTXRBYXT.put(JIAMNGUWDP, AVFXUDAHYH);
    }

    public synchronized void mayBeCloseProxy(ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData FIXJFUYKNS) {
        FIXJFUYKNS.QDPTMBZHYR--;
        if (FIXJFUYKNS.NPQZBNCYEZ && (FIXJFUYKNS.QDPTMBZHYR < 0)) {
            ContainerManagementProtocolProxy.DSNEBOIDHT.info("Closing proxy : " + FIXJFUYKNS.RWWPMLFEHX);
            BLLTXRBYXT.remove(FIXJFUYKNS.RWWPMLFEHX);
            try {
                RIAQBUJEMH.stopProxy(FIXJFUYKNS.getContainerManagementProtocol(), OJTPCUIWHG);
            } finally {
                this.notifyAll();
            }
        }
    }

    private synchronized void removeProxy(ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData KSREHAWIES) {
        if (!KSREHAWIES.NPQZBNCYEZ) {
            KSREHAWIES.NPQZBNCYEZ = true;
            mayBeCloseProxy(KSREHAWIES);
        }
    }

    public synchronized void stopAllProxies() {
        List<String> DBFHUMLION = new ArrayList<String>();
        DBFHUMLION.addAll(this.BLLTXRBYXT.keySet());
        for (String JPUOTNVQAF : DBFHUMLION) {
            ContainerManagementProtocolProxy.ContainerManagementProtocolProxyData HRNOADRFRS = BLLTXRBYXT.get(JPUOTNVQAF);
            // Explicitly reducing the proxy count to allow stopping proxy.
            HRNOADRFRS.QDPTMBZHYR = 0;
            try {
                removeProxy(HRNOADRFRS);
            } catch (Throwable t) {
                ContainerManagementProtocolProxy.DSNEBOIDHT.error("Error closing connection", t);
            }
        }
        BLLTXRBYXT.clear();
    }

    public class ContainerManagementProtocolProxyData {
        private final String RWWPMLFEHX;

        private final ContainerManagementProtocol GQKTNXDQXO;

        private int QDPTMBZHYR;

        private boolean NPQZBNCYEZ;

        private final Token SUDESYPQOO;

        @Private
        @VisibleForTesting
        public ContainerManagementProtocolProxyData(YarnRPC rpc, String containerManagerBindAddr, ContainerId containerId, Token token) throws InvalidToken {
            this.RWWPMLFEHX = containerManagerBindAddr;
            this.QDPTMBZHYR = 0;
            this.NPQZBNCYEZ = false;
            this.SUDESYPQOO = token;
            this.GQKTNXDQXO = newProxy(rpc, containerManagerBindAddr, containerId, token);
        }

        @Private
        @VisibleForTesting
        protected ContainerManagementProtocol newProxy(final YarnRPC rpc, String containerManagerBindAddr, ContainerId containerId, Token token) throws InvalidToken {
            if (token == null) {
                throw new InvalidToken("No NMToken sent for " + containerManagerBindAddr);
            }
            final InetSocketAddress cmAddr = NetUtils.createSocketAddr(containerManagerBindAddr);
            ContainerManagementProtocolProxy.DSNEBOIDHT.info("Opening proxy : " + containerManagerBindAddr);
            // the user in createRemoteUser in this context has to be ContainerID
            UserGroupInformation user = UserGroupInformation.createRemoteUser(containerId.getApplicationAttemptId().toString());
            org.apache.hadoop.security.token.Token<NMTokenIdentifier> nmToken = ConverterUtils.convertFromYarn(token, cmAddr);
            user.addToken(nmToken);
            ContainerManagementProtocol proxy = user.doAs(new PrivilegedAction<ContainerManagementProtocol>() {
                @Override
                public ContainerManagementProtocol run() {
                    return ((ContainerManagementProtocol) (rpc.getProxy(ContainerManagementProtocol.class, cmAddr, OJTPCUIWHG)));
                }
            });
            return proxy;
        }

        public ContainerManagementProtocol getContainerManagementProtocol() {
            return GQKTNXDQXO;
        }
    }
}