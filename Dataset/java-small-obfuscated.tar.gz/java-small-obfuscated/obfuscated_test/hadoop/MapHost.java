@InterfaceAudience.LimitedPrivate({ "MapReduce" })
@InterfaceStability.Unstable
public class MapHost {
    // Host penalized due to shuffle failures
    public static enum State {

        IDLE,
        // No map outputs available
        BUSY,
        // Map outputs are being fetched
        PENDING,
        // Known map outputs which need to be fetched
        PENALIZED;}

    private MapHost.State ERPIMWOQQW = MapHost.State.IDLE;

    private final String ZSLYIXPYVN;

    private final String QZQDOTRWKG;

    private List<TaskAttemptID> NVBDZUIAXQ = new ArrayList<TaskAttemptID>();

    public MapHost(String BGNXDCDJNH, String EYDKMDTBKJ) {
        this.ZSLYIXPYVN = BGNXDCDJNH;
        this.QZQDOTRWKG = EYDKMDTBKJ;
    }

    public MapHost.State getState() {
        return ERPIMWOQQW;
    }

    public String getHostName() {
        return ZSLYIXPYVN;
    }

    public String getBaseUrl() {
        return QZQDOTRWKG;
    }

    public synchronized void addKnownMap(TaskAttemptID TIBXJLWGYU) {
        NVBDZUIAXQ.add(TIBXJLWGYU);
        if (ERPIMWOQQW == MapHost.State.IDLE) {
            ERPIMWOQQW = MapHost.State.PENDING;
        }
    }

    public synchronized List<TaskAttemptID> getAndClearKnownMaps() {
        List<TaskAttemptID> TSADSEVDZP = NVBDZUIAXQ;
        NVBDZUIAXQ = new ArrayList<TaskAttemptID>();
        return TSADSEVDZP;
    }

    public synchronized void markBusy() {
        ERPIMWOQQW = MapHost.State.BUSY;
    }

    public synchronized void markPenalized() {
        ERPIMWOQQW = MapHost.State.PENALIZED;
    }

    public synchronized int getNumKnownMapOutputs() {
        return NVBDZUIAXQ.size();
    }

    /**
     * Called when the node is done with its penalty or done copying.
     *
     * @return the host's new state
     */
    public synchronized MapHost.State markAvailable() {
        if (NVBDZUIAXQ.isEmpty()) {
            ERPIMWOQQW = MapHost.State.IDLE;
        } else {
            ERPIMWOQQW = MapHost.State.PENDING;
        }
        return ERPIMWOQQW;
    }

    @Override
    public String toString() {
        return ZSLYIXPYVN;
    }

    /**
     * Mark the host as penalized
     */
    public synchronized void penalize() {
        ERPIMWOQQW = MapHost.State.PENALIZED;
    }
}