public class AMLauncherEvent extends AbstractEvent<AMLauncherEventType> {
    private final RMAppAttempt KAICMHKOUO;

    public AMLauncherEvent(AMLauncherEventType CNQJTJXGQB, RMAppAttempt WKWSXCQYPP) {
        super(CNQJTJXGQB);
        this.KAICMHKOUO = WKWSXCQYPP;
    }

    public RMAppAttempt getAppAttempt() {
        return this.KAICMHKOUO;
    }
}