public class TestJNIGroupsMapping {
    @Before
    public void isNativeCodeLoaded() {
        assumeTrue(NativeCodeLoader.isNativeCodeLoaded());
    }

    @Test
    public void testJNIGroupsMapping() throws Exception {
        // for the user running the test, check whether the
        // ShellBasedUnixGroupsMapping and the JniBasedUnixGroupsMapping
        // return the same groups
        String HKPJCNZXBB = UserGroupInformation.getCurrentUser().getShortUserName();
        testForUser(HKPJCNZXBB);
        // check for a dummy non-existent user (both the implementations should
        // return an empty list
        testForUser("fooBarBaz1234DoesNotExist");
    }

    private void testForUser(String QLZOWPOOMW) throws Exception {
        GroupMappingServiceProvider CJNQPUTPDD = new ShellBasedUnixGroupsMapping();
        List<String> HOOACMHGDG = CJNQPUTPDD.getGroups(QLZOWPOOMW);
        CJNQPUTPDD = new JniBasedUnixGroupsMapping();
        List<String> EVSUUTYDUM = CJNQPUTPDD.getGroups(QLZOWPOOMW);
        String[] DSPHSDINRU = HOOACMHGDG.toArray(new String[0]);
        Arrays.sort(DSPHSDINRU);
        String[] XQOLLZROGK = EVSUUTYDUM.toArray(new String[0]);
        Arrays.sort(XQOLLZROGK);
        if (!Arrays.equals(DSPHSDINRU, XQOLLZROGK)) {
            fail((((("Groups returned by " + ShellBasedUnixGroupsMapping.class.getCanonicalName()) + " and ") + JniBasedUnixGroupsMapping.class.getCanonicalName()) + " didn't match for ") + QLZOWPOOMW);
        }
    }
}