/**
 * This class tests that pipelines survive data node death and recovery.
 */
public class TestDatanodeDeath {
    {
        ((org.apache.commons.logging.impl.Log4JLogger) (NameNode.stateChangeLog)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (NameNode.blockStateChangeLog)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (LeaseManager.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (org.apache.commons.logging.LogFactory.getLog(org.apache.hadoop.hdfs.server.namenode.FSNamesystem.class))).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (DataNode.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (DFSClient.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (InterDatanodeProtocol.LOG)).getLogger().setLevel(Level.ALL);
    }

    static final int IHUPCAUDEG = 8192;

    static final int LNTLIMRBOX = 2;

    static final int NXSOAYQPAU = (TestDatanodeDeath.LNTLIMRBOX * TestDatanodeDeath.IHUPCAUDEG) + 1;

    static final int IATYEDIEFJ = 15;

    static final short RFYGWEYJKT = 3;

    final int ZETLKDUYGY = 3;

    final int DVRIYQGVFP = 5;

    TestDatanodeDeath.Workload[] SYCIZFRYTL = null;

    // 
    // an object that does a bunch of transactions
    // 
    static class Workload extends Thread {
        private final short ATPIRUUJDG;

        private final int WAPGDBJBTD;

        private final int EAECTMAHSO;

        private final FileSystem VAEHWBBCQF;

        private long KLAZTHFQAA;

        private final long FGAILRFMQL;

        Workload(long myseed, FileSystem fs, int threadIndex, int numberOfFiles, short replication, long stamp) {
            this.FGAILRFMQL = myseed;
            EAECTMAHSO = threadIndex;
            this.VAEHWBBCQF = fs;
            this.WAPGDBJBTD = numberOfFiles;
            this.ATPIRUUJDG = replication;
            this.KLAZTHFQAA = stamp;
        }

        // create a bunch of files. Write to them and then verify.
        @Override
        public void run() {
            System.out.println("Workload starting ");
            for (int i = 0; i < WAPGDBJBTD; i++) {
                Path filename = new Path((EAECTMAHSO + ".") + i);
                try {
                    System.out.println("Workload processing file " + filename);
                    FSDataOutputStream stm = TestDatanodeDeath.createFile(VAEHWBBCQF, filename, ATPIRUUJDG);
                    DFSOutputStream dfstream = ((DFSOutputStream) (stm.getWrappedStream()));
                    dfstream.setArtificialSlowdown(1000);
                    TestDatanodeDeath.writeFile(stm, FGAILRFMQL);
                    stm.close();
                    TestDatanodeDeath.checkFile(VAEHWBBCQF, filename, ATPIRUUJDG, TestDatanodeDeath.LNTLIMRBOX, TestDatanodeDeath.NXSOAYQPAU, FGAILRFMQL);
                } catch (Throwable e) {
                    System.out.println("Workload exception " + e);
                    assertTrue(e.toString(), false);
                }
                // increment the stamp to indicate that another file is done.
                synchronized(this) {
                    KLAZTHFQAA++;
                }
            }
        }

        public synchronized void resetStamp() {
            this.KLAZTHFQAA = 0;
        }

        public synchronized long getStamp() {
            return KLAZTHFQAA;
        }
    }

    // 
    // creates a file and returns a descriptor for writing to it.
    // 
    private static FSDataOutputStream createFile(FileSystem VYCTYZUITN, Path BURYVBJHBU, short ISIBALTNWA) throws IOException {
        // create and write a file that contains three blocks of data
        FSDataOutputStream EKKIRPXOMR = VYCTYZUITN.create(BURYVBJHBU, true, VYCTYZUITN.getConf().getInt(CommonConfigurationKeys.IO_FILE_BUFFER_SIZE_KEY, 4096), ISIBALTNWA, TestDatanodeDeath.IHUPCAUDEG);
        return EKKIRPXOMR;
    }

    // 
    // writes to file
    // 
    private static void writeFile(FSDataOutputStream GKMUUWIDQC, long RGCOHVDRGZ) throws IOException {
        byte[] SPDLPJRXSE = AppendTestUtil.randomBytes(RGCOHVDRGZ, TestDatanodeDeath.NXSOAYQPAU);
        int TSWYMXNRVX = TestDatanodeDeath.NXSOAYQPAU / 2;
        GKMUUWIDQC.write(SPDLPJRXSE, 0, TSWYMXNRVX);
        GKMUUWIDQC.write(SPDLPJRXSE, TSWYMXNRVX, TestDatanodeDeath.NXSOAYQPAU - TSWYMXNRVX);
    }

    // 
    // verify that the data written are sane
    // 
    private static void checkFile(FileSystem DDBHANWNUU, Path PVJMJBPEWL, int CARAMBURLG, int TQVXWTQAJF, int NTROBKRHEU, long OEAXNIQGDY) throws IOException {
        boolean CRHRIXRYDL = false;
        int GVFYYMXQAA = 0;
        long UKHEEZDQUI = DDBHANWNUU.getFileStatus(PVJMJBPEWL).getLen();
        assertTrue((((PVJMJBPEWL + " should be of size ") + NTROBKRHEU) + " but found to be of size ") + UKHEEZDQUI, UKHEEZDQUI == NTROBKRHEU);
        // wait till all full blocks are confirmed by the datanodes.
        while (!CRHRIXRYDL) {
            GVFYYMXQAA++;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
            CRHRIXRYDL = true;
            BlockLocation[] EWADSEXFHV = DDBHANWNUU.getFileBlockLocations(DDBHANWNUU.getFileStatus(PVJMJBPEWL), 0, NTROBKRHEU);
            if (EWADSEXFHV.length < TQVXWTQAJF) {
                if (GVFYYMXQAA > 100) {
                    System.out.println((((((("File " + PVJMJBPEWL) + " has only ") + EWADSEXFHV.length) + " blocks, ") + " but is expected to have ") + TQVXWTQAJF) + " blocks.");
                }
                CRHRIXRYDL = false;
                continue;
            }
            for (int GDQYXKOOBM = 0; GDQYXKOOBM < EWADSEXFHV.length; GDQYXKOOBM++) {
                if (EWADSEXFHV[GDQYXKOOBM].getHosts().length < CARAMBURLG) {
                    if (GVFYYMXQAA > 100) {
                        System.out.println((((((((((("File " + PVJMJBPEWL) + " has ") + EWADSEXFHV.length) + " blocks: ") + " The ") + GDQYXKOOBM) + " block has only ") + EWADSEXFHV[GDQYXKOOBM].getHosts().length) + " replicas but is expected to have ") + CARAMBURLG) + " replicas.");
                    }
                    CRHRIXRYDL = false;
                    break;
                }
            }
        } 
        FSDataInputStream IHZNVZCYJA = DDBHANWNUU.open(PVJMJBPEWL);
        final byte[] MGOSBPDWYD = AppendTestUtil.randomBytes(OEAXNIQGDY, TestDatanodeDeath.NXSOAYQPAU);
        // do a sanity check. Read the file
        byte[] DYSNCTZNKV = new byte[NTROBKRHEU];
        IHZNVZCYJA.readFully(0, DYSNCTZNKV);
        TestDatanodeDeath.checkData(DYSNCTZNKV, 0, MGOSBPDWYD, "Read 1");
    }

    private static void checkData(byte[] UVJGGVTHKH, int SUSNOXOOZR, byte[] JFNXKTYQXP, String XNLLYMZYSW) {
        for (int FJVHUPTLZX = 0; FJVHUPTLZX < UVJGGVTHKH.length; FJVHUPTLZX++) {
            assertEquals((((((XNLLYMZYSW + " byte ") + (SUSNOXOOZR + FJVHUPTLZX)) + " differs. expected ") + JFNXKTYQXP[SUSNOXOOZR + FJVHUPTLZX]) + " actual ") + UVJGGVTHKH[FJVHUPTLZX], UVJGGVTHKH[FJVHUPTLZX], JFNXKTYQXP[SUSNOXOOZR + FJVHUPTLZX]);
            UVJGGVTHKH[FJVHUPTLZX] = 0;
        }
    }

    /**
     * A class that kills one datanode and recreates a new one. It waits to
     * ensure that that all workers have finished at least one file since the
     * last kill of a datanode. This guarantees that all three replicas of
     * a block do not get killed (otherwise the file will be corrupt and the
     * test will fail).
     */
    class Modify extends Thread {
        volatile boolean JGWJJJTUJW;

        final MiniDFSCluster JHZPMLXAPP;

        final Configuration EHHLBDOGFE;

        Modify(Configuration conf, MiniDFSCluster cluster) {
            JGWJJJTUJW = true;
            this.JHZPMLXAPP = cluster;
            this.EHHLBDOGFE = conf;
        }

        @Override
        public void run() {
            while (JGWJJJTUJW) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    continue;
                }
                // check if all threads have a new stamp.
                // If so, then all workers have finished at least one file
                // since the last stamp.
                boolean loop = false;
                for (int i = 0; i < DVRIYQGVFP; i++) {
                    if (SYCIZFRYTL[i].getStamp() == 0) {
                        loop = true;
                        break;
                    }
                }
                if (loop) {
                    continue;
                }
                // Now it is guaranteed that there will be at least one valid
                // replica of a file.
                for (int i = 0; i < (TestDatanodeDeath.RFYGWEYJKT - 1); i++) {
                    // pick a random datanode to shutdown
                    int victim = AppendTestUtil.nextInt(TestDatanodeDeath.IATYEDIEFJ);
                    try {
                        System.out.println("Stopping datanode " + victim);
                        JHZPMLXAPP.restartDataNode(victim);
                        // cluster.startDataNodes(conf, 1, true, null, null);
                    } catch (IOException e) {
                        System.out.println("TestDatanodeDeath Modify exception " + e);
                        assertTrue("TestDatanodeDeath Modify exception " + e, false);
                        JGWJJJTUJW = false;
                    }
                }
                // set a new stamp for all workers
                for (int i = 0; i < DVRIYQGVFP; i++) {
                    SYCIZFRYTL[i].resetStamp();
                }
            } 
        }

        // Make the thread exit.
        void close() {
            JGWJJJTUJW = false;
            this.interrupt();
        }
    }

    /**
     * Test that writing to files is good even when datanodes in the pipeline
     * dies.
     */
    private void complexTest() throws IOException {
        Configuration ULKXDPBTWC = new HdfsConfiguration();
        ULKXDPBTWC.setInt(DFS_NAMENODE_HEARTBEAT_RECHECK_INTERVAL_KEY, 2000);
        ULKXDPBTWC.setInt(DFS_HEARTBEAT_INTERVAL_KEY, 2);
        ULKXDPBTWC.setInt(DFS_NAMENODE_REPLICATION_PENDING_TIMEOUT_SEC_KEY, 2);
        ULKXDPBTWC.setInt(DFS_CLIENT_SOCKET_TIMEOUT_KEY, 5000);
        MiniDFSCluster QYAECIMTUR = new MiniDFSCluster.Builder(ULKXDPBTWC).numDataNodes(TestDatanodeDeath.IATYEDIEFJ).build();
        QYAECIMTUR.waitActive();
        FileSystem UPIXOTGNNH = QYAECIMTUR.getFileSystem();
        TestDatanodeDeath.Modify EALXXBGHKD = null;
        try {
            // Create threads and make them run workload concurrently.
            SYCIZFRYTL = new TestDatanodeDeath.Workload[DVRIYQGVFP];
            for (int UNGKPDOUHD = 0; UNGKPDOUHD < DVRIYQGVFP; UNGKPDOUHD++) {
                SYCIZFRYTL[UNGKPDOUHD] = new TestDatanodeDeath.Workload(AppendTestUtil.nextLong(), UPIXOTGNNH, UNGKPDOUHD, ZETLKDUYGY, TestDatanodeDeath.RFYGWEYJKT, 0);
                SYCIZFRYTL[UNGKPDOUHD].start();
            }
            // Create a thread that kills existing datanodes and creates new ones.
            EALXXBGHKD = new TestDatanodeDeath.Modify(ULKXDPBTWC, QYAECIMTUR);
            EALXXBGHKD.start();
            // wait for all transactions to get over
            for (int WLFWZIOWSG = 0; WLFWZIOWSG < DVRIYQGVFP; WLFWZIOWSG++) {
                try {
                    System.out.println(("Waiting for thread " + WLFWZIOWSG) + " to complete...");
                    SYCIZFRYTL[WLFWZIOWSG].join();
                    // if most of the threads are done, then stop restarting datanodes.
                    if (WLFWZIOWSG >= (DVRIYQGVFP / 2)) {
                        EALXXBGHKD.close();
                    }
                } catch (InterruptedException e) {
                    WLFWZIOWSG--;// retry

                }
            }
        } finally {
            if (EALXXBGHKD != null) {
                EALXXBGHKD.close();
                try {
                    EALXXBGHKD.join();
                } catch (InterruptedException e) {
                }
            }
            UPIXOTGNNH.close();
            QYAECIMTUR.shutdown();
        }
    }

    /**
     * Write to one file, then kill one datanode in the pipeline and then
     * close the file.
     */
    private void simpleTest(int XAUWFQITFD) throws IOException {
        Configuration IZKOYURENZ = new HdfsConfiguration();
        IZKOYURENZ.setInt(DFS_NAMENODE_HEARTBEAT_RECHECK_INTERVAL_KEY, 2000);
        IZKOYURENZ.setInt(DFS_HEARTBEAT_INTERVAL_KEY, 1);
        IZKOYURENZ.setInt(DFS_NAMENODE_REPLICATION_PENDING_TIMEOUT_SEC_KEY, 2);
        IZKOYURENZ.setInt(DFS_CLIENT_SOCKET_TIMEOUT_KEY, 5000);
        int FAZGAFXXAX = 5;
        System.out.println("SimpleTest starting with DataNode to Kill " + XAUWFQITFD);
        MiniDFSCluster YIBHQYJLYK = new MiniDFSCluster.Builder(IZKOYURENZ).numDataNodes(FAZGAFXXAX).build();
        YIBHQYJLYK.waitActive();
        FileSystem GERPSUTUPP = YIBHQYJLYK.getFileSystem();
        short NRXGTZGINH = 3;
        Path NYNWMLJCKJ = new Path("simpletest.dat");
        try {
            // create a file and write one block of data
            System.out.println("SimpleTest creating file " + NYNWMLJCKJ);
            FSDataOutputStream KWZRSJJYSY = TestDatanodeDeath.createFile(GERPSUTUPP, NYNWMLJCKJ, NRXGTZGINH);
            DFSOutputStream JQQTLNIQXT = ((DFSOutputStream) (KWZRSJJYSY.getWrappedStream()));
            // these are test settings
            JQQTLNIQXT.setChunksPerPacket(5);
            JQQTLNIQXT.setArtificialSlowdown(3000);
            final long QYYJCUEMME = AppendTestUtil.nextLong();
            byte[] AHREQURTTK = AppendTestUtil.randomBytes(QYYJCUEMME, TestDatanodeDeath.NXSOAYQPAU);
            int KAIPSTGOYS = TestDatanodeDeath.NXSOAYQPAU / 4;
            KWZRSJJYSY.write(AHREQURTTK, 0, KAIPSTGOYS);
            DatanodeInfo[] CTNQIRWCGX = JQQTLNIQXT.getPipeline();
            int IOOQRELWYH = 5;
            while (((IOOQRELWYH--) > 0) && (CTNQIRWCGX == null)) {
                try {
                    System.out.println("SimpleTest: Waiting for pipeline to be created.");
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                }
                CTNQIRWCGX = JQQTLNIQXT.getPipeline();
            } 
            if (CTNQIRWCGX == null) {
                int ZDIUJCRONM = AppendTestUtil.nextInt(FAZGAFXXAX);
                System.out.println("SimpleTest stopping datanode random " + ZDIUJCRONM);
                YIBHQYJLYK.stopDataNode(ZDIUJCRONM);
            } else {
                int ROHTUPHMUI = XAUWFQITFD;
                System.out.println("SimpleTest stopping datanode " + CTNQIRWCGX[ROHTUPHMUI]);
                YIBHQYJLYK.stopDataNode(CTNQIRWCGX[ROHTUPHMUI].getXferAddr());
            }
            System.out.println("SimpleTest stopping datanode complete");
            // write some more data to file, close and verify
            KWZRSJJYSY.write(AHREQURTTK, KAIPSTGOYS, TestDatanodeDeath.NXSOAYQPAU - KAIPSTGOYS);
            KWZRSJJYSY.close();
            TestDatanodeDeath.checkFile(GERPSUTUPP, NYNWMLJCKJ, NRXGTZGINH, TestDatanodeDeath.LNTLIMRBOX, TestDatanodeDeath.NXSOAYQPAU, QYYJCUEMME);
        } catch (Throwable e) {
            System.out.println("Simple Workload exception " + e);
            e.printStackTrace();
            assertTrue(e.toString(), false);
        } finally {
            GERPSUTUPP.close();
            YIBHQYJLYK.shutdown();
        }
    }

    @Test
    public void testSimple0() throws IOException {
        simpleTest(0);
    }

    @Test
    public void testSimple1() throws IOException {
        simpleTest(1);
    }

    @Test
    public void testSimple2() throws IOException {
        simpleTest(2);
    }

    @Test
    public void testComplex() throws IOException {
        complexTest();
    }
}