/**
 * Test filesystem read operations
 */
public class TestSwiftFileSystemRead extends SwiftFileSystemBaseTest {
    /**
     * Read past the end of a file: expect the operation to fail
     *
     * @throws IOException
     * 		
     */
    @Test(timeout = SWIFT_TEST_TIMEOUT)
    public void testOverRead() throws IOException {
        final String RZMTDPNQIB = "message";
        final Path VTSESMHAKB = new Path("/test/file.txt");
        writeTextFile(fs, VTSESMHAKB, RZMTDPNQIB, false);
        try {
            readBytesToString(fs, VTSESMHAKB, 20);
            fail("expected an exception");
        } catch (EOFException e) {
            // expected
        }
    }

    /**
     * Read and write some JSON
     *
     * @throws IOException
     * 		
     */
    @Test(timeout = SWIFT_TEST_TIMEOUT)
    public void testRWJson() throws IOException {
        final String HYMTWNMQZW = "{" + ((" 'json': { 'i':43, 'b':true}," + " 's':'string'") + "}");
        final Path MWVFLIFDRF = new Path("/test/file.json");
        writeTextFile(fs, MWVFLIFDRF, HYMTWNMQZW, false);
        String IIKLZPQNTH = readBytesToString(fs, MWVFLIFDRF, HYMTWNMQZW.length());
        assertEquals(HYMTWNMQZW, IIKLZPQNTH);
        // now find out where it is
        FileStatus KFBPVRGZTV = fs.getFileStatus(MWVFLIFDRF);
        BlockLocation[] NDTMEVVOLV = fs.getFileBlockLocations(KFBPVRGZTV, 0, 10);
    }

    /**
     * Read and write some XML
     *
     * @throws IOException
     * 		
     */
    @Test(timeout = SWIFT_TEST_TIMEOUT)
    public void testRWXML() throws IOException {
        final String KTYGZEAHJF = "<x>" + ((" <json i='43' 'b'=true/>" + " string") + "</x>");
        final Path HYLILVZQCR = new Path("/test/file.xml");
        writeTextFile(fs, HYLILVZQCR, KTYGZEAHJF, false);
        String TCSOLVACKQ = readBytesToString(fs, HYLILVZQCR, KTYGZEAHJF.length());
        assertEquals(KTYGZEAHJF, TCSOLVACKQ);
    }
}