/**
 * Rename names src to dst. Rename is done using following steps:
 * <ul>
 * <li>Checks are made to ensure src exists and appropriate flags are being
 * passed to overwrite existing destination.
 * <li>src is removed.
 * <li>dst if it exists is removed.
 * <li>src is renamed and added to directory tree as dst.
 * </ul>
 *
 * During any of the above steps, the state of src and dst is reverted back to
 * what it was prior to rename. This test ensures that the state is reverted
 * back.
 *
 * This test uses AspectJ to simulate failures.
 */
public class TestFiRename {
    private static final Log XNQHBUXYTD = LogFactory.getLog(TestFiRename.class);

    private static String DKUFDLSDJI = "";

    private static String VIMZEEAMKC = "";

    private static byte[] BSHERSUHBR = new byte[]{ 0 };

    private static String TUQBOULYJP = PathUtils.getTestDirName(TestFiRename.class);

    private static Configuration OHRJZUNWGB = new Configuration();

    static {
        TestFiRename.OHRJZUNWGB.setInt("io.bytes.per.checksum", 1);
    }

    private MiniDFSCluster BTEUEMTXEY = null;

    private FileContext NJPFNXQIUY = null;

    @Before
    public void setup() throws IOException {
        restartCluster(true);
    }

    @After
    public void teardown() throws IOException {
        if (NJPFNXQIUY != null) {
            NJPFNXQIUY.delete(getTestRootPath(), true);
        }
        if (BTEUEMTXEY != null) {
            BTEUEMTXEY.shutdown();
        }
    }

    private void restartCluster(boolean UEZDNNJFGV) throws IOException {
        if (BTEUEMTXEY != null) {
            BTEUEMTXEY.shutdown();
            BTEUEMTXEY = null;
        }
        BTEUEMTXEY = new MiniDFSCluster.Builder(TestFiRename.OHRJZUNWGB).format(UEZDNNJFGV).build();
        BTEUEMTXEY.waitClusterUp();
        NJPFNXQIUY = FileContext.getFileContext(BTEUEMTXEY.getURI(0), TestFiRename.OHRJZUNWGB);
    }

    /**
     * Returns true to indicate an exception should be thrown to simulate failure
     * during removal of a node from directory tree.
     */
    public static boolean throwExceptionOnRemove(String KCWTMICNCS) {
        boolean TKIBFWZMUE = TestFiRename.DKUFDLSDJI.endsWith(KCWTMICNCS);
        if (TKIBFWZMUE) {
            TestFiRename.DKUFDLSDJI = "";
        }
        return TKIBFWZMUE;
    }

    /**
     * Returns true to indicate an exception should be thrown to simulate failure
     * during addition of a node to directory tree.
     */
    public static boolean throwExceptionOnAdd(String XBHCSISIDZ) {
        boolean BKZESMCABE = TestFiRename.VIMZEEAMKC.endsWith(XBHCSISIDZ);
        if (BKZESMCABE) {
            TestFiRename.VIMZEEAMKC = "";
        }
        return BKZESMCABE;
    }

    /**
     * Set child name on removal of which failure should be simulated
     */
    public static void exceptionOnRemove(String DVDWQLFPLO) {
        TestFiRename.DKUFDLSDJI = DVDWQLFPLO;
        TestFiRename.VIMZEEAMKC = "";
    }

    /**
     * Set child name on addition of which failure should be simulated
     */
    public static void exceptionOnAdd(String VOKJXIAALV) {
        TestFiRename.DKUFDLSDJI = "";
        TestFiRename.VIMZEEAMKC = VOKJXIAALV;
    }

    private Path getTestRootPath() {
        return NJPFNXQIUY.makeQualified(new Path(TestFiRename.TUQBOULYJP));
    }

    private Path getTestPath(String ORMATYOMTS) {
        return NJPFNXQIUY.makeQualified(new Path(TestFiRename.TUQBOULYJP, ORMATYOMTS));
    }

    private void createFile(Path WVLTVIAMSH) throws IOException {
        FSDataOutputStream XHOBALUGFH = NJPFNXQIUY.create(WVLTVIAMSH, EnumSet.of(CREATE), CreateOpts.createParent());
        XHOBALUGFH.write(TestFiRename.BSHERSUHBR, 0, TestFiRename.BSHERSUHBR.length);
        XHOBALUGFH.close();
    }

    /**
     * Rename test when src exists and dst does not
     */
    @Test
    public void testFailureNonExistentDst() throws Exception {
        final Path BZBDDLFZZQ = getTestPath("testFailureNonExistenSrc/dir/src");
        final Path IWSMETFQUK = getTestPath("testFailureNonExistenSrc/newdir/dst");
        createFile(BZBDDLFZZQ);
        // During rename, while removing src, an exception is thrown
        TestFiRename.exceptionOnRemove(BZBDDLFZZQ.toString());
        rename(BZBDDLFZZQ, IWSMETFQUK, true, true, false, NONE);
        // During rename, while adding dst an exception is thrown
        TestFiRename.exceptionOnAdd(IWSMETFQUK.toString());
        rename(BZBDDLFZZQ, IWSMETFQUK, true, true, false, NONE);
    }

    /**
     * Rename test when src and dst exist
     */
    @Test
    public void testFailuresExistingDst() throws Exception {
        final Path ZQQNVKFSYN = getTestPath("testFailuresExistingDst/dir/src");
        final Path VEYOGIZUYU = getTestPath("testFailuresExistingDst/newdir/dst");
        createFile(ZQQNVKFSYN);
        createFile(VEYOGIZUYU);
        // During rename, while removing src, an exception is thrown
        TestFiRename.exceptionOnRemove(ZQQNVKFSYN.toString());
        rename(ZQQNVKFSYN, VEYOGIZUYU, true, true, true, OVERWRITE);
        // During rename, while removing dst, an exception is thrown
        TestFiRename.exceptionOnRemove(VEYOGIZUYU.toString());
        rename(ZQQNVKFSYN, VEYOGIZUYU, true, true, true, OVERWRITE);
        // During rename, while adding dst an exception is thrown
        TestFiRename.exceptionOnAdd(VEYOGIZUYU.toString());
        rename(ZQQNVKFSYN, VEYOGIZUYU, true, true, true, OVERWRITE);
    }

    /**
     * Rename test where both src and dst are files
     */
    @Test
    public void testDeletionOfDstFile() throws Exception {
        Path XWGDQRYIXW = getTestPath("testDeletionOfDstFile/dir/src");
        Path ZMCFPTTRGK = getTestPath("testDeletionOfDstFile/newdir/dst");
        createFile(XWGDQRYIXW);
        createFile(ZMCFPTTRGK);
        final FSNamesystem PXHSVGXEZO = BTEUEMTXEY.getNamesystem();
        final long TLTZQYGBRK = PXHSVGXEZO.getBlocksTotal();
        final long VYWAJFNBWG = PXHSVGXEZO.getFilesTotal();
        rename(XWGDQRYIXW, ZMCFPTTRGK, false, false, true, OVERWRITE);
        // After successful rename the blocks corresponing dst are deleted
        Assert.assertEquals(TLTZQYGBRK - 1, PXHSVGXEZO.getBlocksTotal());
        // After successful rename dst file is deleted
        Assert.assertEquals(VYWAJFNBWG - 1, PXHSVGXEZO.getFilesTotal());
        // Restart the cluster to ensure new rename operation
        // recorded in editlog is processed right
        restartCluster(false);
        int KEBOVNKZQZ = 0;
        boolean KRYSLQDOLN = true;
        XWGDQRYIXW = getTestPath("testDeletionOfDstFile/dir/src");
        ZMCFPTTRGK = getTestPath("testDeletionOfDstFile/newdir/dst");
        while (KRYSLQDOLN && (KEBOVNKZQZ < 5)) {
            try {
                exists(NJPFNXQIUY, XWGDQRYIXW);
                KRYSLQDOLN = false;
            } catch (Exception e) {
                TestFiRename.XNQHBUXYTD.warn(((("Exception " + " count ") + KEBOVNKZQZ) + " ") + e.getMessage());
                Thread.sleep(1000);
                KEBOVNKZQZ++;
            }
        } 
        Assert.assertFalse(exists(NJPFNXQIUY, XWGDQRYIXW));
        Assert.assertTrue(exists(NJPFNXQIUY, ZMCFPTTRGK));
    }

    /**
     * Rename test where both src and dst are directories
     */
    @Test
    public void testDeletionOfDstDirectory() throws Exception {
        Path BGQOVLPFUD = getTestPath("testDeletionOfDstDirectory/dir/src");
        Path FZMBIZOGVD = getTestPath("testDeletionOfDstDirectory/newdir/dst");
        NJPFNXQIUY.mkdir(BGQOVLPFUD, DEFAULT_PERM, true);
        NJPFNXQIUY.mkdir(FZMBIZOGVD, DEFAULT_PERM, true);
        FSNamesystem KSIBOWPTJC = BTEUEMTXEY.getNamesystem();
        long HHGAECJEVS = KSIBOWPTJC.getFilesTotal();
        rename(BGQOVLPFUD, FZMBIZOGVD, false, false, true, OVERWRITE);
        // After successful rename dst directory is deleted
        Assert.assertEquals(HHGAECJEVS - 1, KSIBOWPTJC.getFilesTotal());
        // Restart the cluster to ensure new rename operation
        // recorded in editlog is processed right
        restartCluster(false);
        BGQOVLPFUD = getTestPath("testDeletionOfDstDirectory/dir/src");
        FZMBIZOGVD = getTestPath("testDeletionOfDstDirectory/newdir/dst");
        int IYWRMAINIX = 0;
        boolean JIHCRZDTSZ = true;
        while (JIHCRZDTSZ && (IYWRMAINIX < 5)) {
            try {
                exists(NJPFNXQIUY, BGQOVLPFUD);
                JIHCRZDTSZ = false;
            } catch (Exception e) {
                TestFiRename.XNQHBUXYTD.warn(((("Exception " + " count ") + IYWRMAINIX) + " ") + e.getMessage());
                Thread.sleep(1000);
                IYWRMAINIX++;
            }
        } 
        Assert.assertFalse(exists(NJPFNXQIUY, BGQOVLPFUD));
        Assert.assertTrue(exists(NJPFNXQIUY, FZMBIZOGVD));
    }

    private void rename(Path KLMEYQGBMY, Path LSSHWFBBAM, boolean FWOTCXBVQT, boolean VXUYCWPFPY, boolean YTGZYXXPOE, Rename... AAYKUTWZSL) throws IOException {
        try {
            NJPFNXQIUY.rename(KLMEYQGBMY, LSSHWFBBAM, AAYKUTWZSL);
            Assert.assertFalse("Expected exception is not thrown", FWOTCXBVQT);
        } catch (Exception e) {
            TestFiRename.XNQHBUXYTD.warn("Exception ", e);
            Assert.assertTrue(FWOTCXBVQT);
        }
        Assert.assertEquals(VXUYCWPFPY, exists(NJPFNXQIUY, KLMEYQGBMY));
        Assert.assertEquals(YTGZYXXPOE, exists(NJPFNXQIUY, LSSHWFBBAM));
    }
}