public class TestJoinDatamerge extends TestCase {
    private static MiniDFSCluster ULWYGMWQQX = null;

    public static Test suite() {
        TestSetup CMNYOVKQHY = new TestSetup(new TestSuite(TestJoinDatamerge.class)) {
            protected void setUp() throws Exception {
                Configuration DDLCGNNMGM = new Configuration();
                TestJoinDatamerge.ULWYGMWQQX = new MiniDFSCluster.Builder(DDLCGNNMGM).numDataNodes(2).build();
            }

            protected void tearDown() throws Exception {
                if (TestJoinDatamerge.ULWYGMWQQX != null) {
                    TestJoinDatamerge.ULWYGMWQQX.shutdown();
                }
            }
        };
        return CMNYOVKQHY;
    }

    private static Writer[] createWriters(Path KKBWLTRGRJ, Configuration HGXDYQLVKS, int VRPTECABBQ, Path[] VDIAKTBMYU) throws IOException {
        for (int UEKYOENYSH = 0; UEKYOENYSH < VRPTECABBQ; ++UEKYOENYSH) {
            VDIAKTBMYU[UEKYOENYSH] = new Path(KKBWLTRGRJ, Integer.toString(UEKYOENYSH + 10, 36));
        }
        SequenceFile[] HHQTKMMVBT = new SequenceFile.Writer[VRPTECABBQ];
        for (int ZVDHODZGZC = 0; ZVDHODZGZC < VRPTECABBQ; ++ZVDHODZGZC) {
            HHQTKMMVBT[ZVDHODZGZC] = new SequenceFile.Writer(KKBWLTRGRJ.getFileSystem(HGXDYQLVKS), HGXDYQLVKS, VDIAKTBMYU[ZVDHODZGZC], IntWritable.class, IntWritable.class);
        }
        return HHQTKMMVBT;
    }

    private static Path[] writeSimpleSrc(Path TVQYNOCCGC, Configuration MVNUDPDTUI, int ZHRUNFDQPL) throws IOException {
        SequenceFile[] QXKDXNUBQT = null;
        Path[] YBGPZQEQFE = new Path[ZHRUNFDQPL];
        try {
            QXKDXNUBQT = TestJoinDatamerge.createWriters(TVQYNOCCGC, MVNUDPDTUI, ZHRUNFDQPL, YBGPZQEQFE);
            final int MTGAQNMGDN = (ZHRUNFDQPL * 2) + 1;
            IntWritable CECARTISHB = new IntWritable();
            IntWritable GNRWPXDWXC = new IntWritable();
            for (int FQZLSILPKC = 0; FQZLSILPKC < MTGAQNMGDN; ++FQZLSILPKC) {
                for (int CEXRUQMJRG = 0; CEXRUQMJRG < ZHRUNFDQPL; ++CEXRUQMJRG) {
                    CECARTISHB.set((FQZLSILPKC % ZHRUNFDQPL) == 0 ? FQZLSILPKC * ZHRUNFDQPL : (FQZLSILPKC * ZHRUNFDQPL) + CEXRUQMJRG);
                    GNRWPXDWXC.set((10 * FQZLSILPKC) + CEXRUQMJRG);
                    QXKDXNUBQT[CEXRUQMJRG].append(CECARTISHB, GNRWPXDWXC);
                    if (CEXRUQMJRG == FQZLSILPKC) {
                        // add duplicate key
                        QXKDXNUBQT[CEXRUQMJRG].append(CECARTISHB, GNRWPXDWXC);
                    }
                }
            }
        } finally {
            if (QXKDXNUBQT != null) {
                for (int PJNXKWTKUQ = 0; PJNXKWTKUQ < ZHRUNFDQPL; ++PJNXKWTKUQ) {
                    if (QXKDXNUBQT[PJNXKWTKUQ] != null)
                        QXKDXNUBQT[PJNXKWTKUQ].close();

                }
            }
        }
        return YBGPZQEQFE;
    }

    private static String stringify(IntWritable GEBOAPSEQL, Writable XGBVZMUWPA) {
        StringBuilder VWUSRLGACR = new StringBuilder();
        VWUSRLGACR.append("(" + GEBOAPSEQL);
        VWUSRLGACR.append(("," + XGBVZMUWPA) + ")");
        return VWUSRLGACR.toString();
    }

    private static abstract class SimpleCheckerMapBase<V extends Writable> extends Mapper<IntWritable, V, IntWritable, IntWritable> {
        protected static final IntWritable CVBUFFNHNQ = new IntWritable(1);

        int YEJZULVYRR;

        public void setup(Context context) {
            YEJZULVYRR = context.getConfiguration().getInt("testdatamerge.sources", 0);
            TestJoinDatamerge.SimpleCheckerMapBase.assertTrue("Invalid src count: " + YEJZULVYRR, YEJZULVYRR > 0);
        }
    }

    private static abstract class SimpleCheckerReduceBase extends Reducer<IntWritable, IntWritable, IntWritable, IntWritable> {
        protected static final IntWritable DDRCOESTWK = new IntWritable(1);

        int UXGMQEMPUD;

        public void setup(Context context) {
            UXGMQEMPUD = context.getConfiguration().getInt("testdatamerge.sources", 0);
            assertTrue("Invalid src count: " + UXGMQEMPUD, UXGMQEMPUD > 0);
        }

        public void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int seen = 0;
            for (IntWritable value : values) {
                seen += value.get();
            }
            assertTrue("Bad count for " + key.get(), verify(key.get(), seen));
            context.write(key, new IntWritable(seen));
        }

        public abstract boolean verify(int key, int occ);
    }

    private static class InnerJoinMapChecker extends TestJoinDatamerge.SimpleCheckerMapBase<TupleWritable> {
        public void map(IntWritable key, TupleWritable val, Context context) throws IOException, InterruptedException {
            int k = key.get();
            final String kvstr = "Unexpected tuple: " + TestJoinDatamerge.stringify(key, val);
            assertTrue(kvstr, 0 == (k % (YEJZULVYRR * YEJZULVYRR)));
            for (int i = 0; i < val.size(); ++i) {
                final int vali = ((IntWritable) (val.get(i))).get();
                assertTrue(kvstr, ((vali - i) * YEJZULVYRR) == (10 * k));
            }
            context.write(key, TestJoinDatamerge.SimpleCheckerMapBase.CVBUFFNHNQ);
            // If the user modifies the key or any of the values in the tuple, it
            // should not affect the rest of the join.
            key.set(-1);
            if (val.has(0)) {
                ((IntWritable) (val.get(0))).set(0);
            }
        }
    }

    private static class InnerJoinReduceChecker extends TestJoinDatamerge.SimpleCheckerReduceBase {
        public boolean verify(int key, int occ) {
            return ((key == 0) && (occ == 2)) || (((key != 0) && ((key % (UXGMQEMPUD * UXGMQEMPUD)) == 0)) && (occ == 1));
        }
    }

    private static class OuterJoinMapChecker extends TestJoinDatamerge.SimpleCheckerMapBase<TupleWritable> {
        public void map(IntWritable key, TupleWritable val, Context context) throws IOException, InterruptedException {
            int k = key.get();
            final String kvstr = "Unexpected tuple: " + TestJoinDatamerge.stringify(key, val);
            if (0 == (k % (YEJZULVYRR * YEJZULVYRR))) {
                for (int i = 0; i < val.size(); ++i) {
                    assertTrue(kvstr, val.get(i) instanceof IntWritable);
                    final int vali = ((IntWritable) (val.get(i))).get();
                    assertTrue(kvstr, ((vali - i) * YEJZULVYRR) == (10 * k));
                }
            } else {
                for (int i = 0; i < val.size(); ++i) {
                    if (i == (k % YEJZULVYRR)) {
                        assertTrue(kvstr, val.get(i) instanceof IntWritable);
                        final int vali = ((IntWritable) (val.get(i))).get();
                        assertTrue(kvstr, (YEJZULVYRR * (vali - i)) == (10 * (k - i)));
                    } else {
                        assertTrue(kvstr, !val.has(i));
                    }
                }
            }
            context.write(key, TestJoinDatamerge.SimpleCheckerMapBase.CVBUFFNHNQ);
            // If the user modifies the key or any of the values in the tuple, it
            // should not affect the rest of the join.
            key.set(-1);
            if (val.has(0)) {
                ((IntWritable) (val.get(0))).set(0);
            }
        }
    }

    private static class OuterJoinReduceChecker extends TestJoinDatamerge.SimpleCheckerReduceBase {
        public boolean verify(int key, int occ) {
            if ((key < (UXGMQEMPUD * UXGMQEMPUD)) && ((key % (UXGMQEMPUD + 1)) == 0)) {
                return 2 == occ;
            }
            return 1 == occ;
        }
    }

    private static class OverrideMapChecker extends TestJoinDatamerge.SimpleCheckerMapBase<IntWritable> {
        public void map(IntWritable key, IntWritable val, Context context) throws IOException, InterruptedException {
            int k = key.get();
            final int vali = val.get();
            final String kvstr = "Unexpected tuple: " + TestJoinDatamerge.stringify(key, val);
            if (0 == (k % (YEJZULVYRR * YEJZULVYRR))) {
                assertTrue(kvstr, vali == ((((k * 10) / YEJZULVYRR) + YEJZULVYRR) - 1));
            } else {
                final int i = k % YEJZULVYRR;
                assertTrue(kvstr, (YEJZULVYRR * (vali - i)) == (10 * (k - i)));
            }
            context.write(key, TestJoinDatamerge.SimpleCheckerMapBase.CVBUFFNHNQ);
            // If the user modifies the key or any of the values in the tuple, it
            // should not affect the rest of the join.
            key.set(-1);
            val.set(0);
        }
    }

    private static class OverrideReduceChecker extends TestJoinDatamerge.SimpleCheckerReduceBase {
        public boolean verify(int key, int occ) {
            if (((key < (UXGMQEMPUD * UXGMQEMPUD)) && ((key % (UXGMQEMPUD + 1)) == 0)) && (key != 0)) {
                return 2 == occ;
            }
            return 1 == occ;
        }
    }

    private static void joinAs(String CIRTDUMGRS, Class<? extends TestJoinDatamerge.SimpleCheckerMapBase<?>> XDYHFSXTPM, Class<? extends TestJoinDatamerge.SimpleCheckerReduceBase> OZFQSYWJOX) throws Exception {
        final int ZEYQHMCHHS = 4;
        Configuration OLYKKQWJBB = new Configuration();
        Path HGHLXQINDM = TestJoinDatamerge.ULWYGMWQQX.getFileSystem().makeQualified(new Path("/" + CIRTDUMGRS));
        Path[] ZTUUIIBGZF = TestJoinDatamerge.writeSimpleSrc(HGHLXQINDM, OLYKKQWJBB, ZEYQHMCHHS);
        OLYKKQWJBB.set(JOIN_EXPR, CompositeInputFormat.compose(CIRTDUMGRS, SequenceFileInputFormat.class, ZTUUIIBGZF));
        OLYKKQWJBB.setInt("testdatamerge.sources", ZEYQHMCHHS);
        Job PWMVRQDJVX = Job.getInstance(OLYKKQWJBB);
        PWMVRQDJVX.setInputFormatClass(CompositeInputFormat.class);
        FileOutputFormat.setOutputPath(PWMVRQDJVX, new Path(HGHLXQINDM, "out"));
        PWMVRQDJVX.setMapperClass(XDYHFSXTPM);
        PWMVRQDJVX.setReducerClass(OZFQSYWJOX);
        PWMVRQDJVX.setOutputFormatClass(SequenceFileOutputFormat.class);
        PWMVRQDJVX.setOutputKeyClass(IntWritable.class);
        PWMVRQDJVX.setOutputValueClass(IntWritable.class);
        PWMVRQDJVX.waitForCompletion(true);
        assertTrue("Job failed", PWMVRQDJVX.isSuccessful());
        if ("outer".equals(CIRTDUMGRS)) {
            TestJoinDatamerge.checkOuterConsistency(PWMVRQDJVX, ZTUUIIBGZF);
        }
        HGHLXQINDM.getFileSystem(OLYKKQWJBB).delete(HGHLXQINDM, true);
    }

    public void testSimpleInnerJoin() throws Exception {
        TestJoinDatamerge.joinAs("inner", TestJoinDatamerge.InnerJoinMapChecker.class, TestJoinDatamerge.InnerJoinReduceChecker.class);
    }

    public void testSimpleOuterJoin() throws Exception {
        TestJoinDatamerge.joinAs("outer", TestJoinDatamerge.OuterJoinMapChecker.class, TestJoinDatamerge.OuterJoinReduceChecker.class);
    }

    private static void checkOuterConsistency(Job EEOLSQXCOL, Path[] XJKVRNELMY) throws IOException {
        Path JZVKGPUFIZ = FileOutputFormat.getOutputPath(EEOLSQXCOL);
        FileStatus[] NRACLVLXZC = TestJoinDatamerge.ULWYGMWQQX.getFileSystem().listStatus(JZVKGPUFIZ, new Utils.OutputFileUtils.OutputFilesFilter());
        assertEquals("number of part files is more than 1. It is" + NRACLVLXZC.length, 1, NRACLVLXZC.length);
        assertTrue("output file with zero length" + NRACLVLXZC[0].getLen(), 0 < NRACLVLXZC[0].getLen());
        SequenceFile.Reader ODMWESIAXF = new SequenceFile.Reader(TestJoinDatamerge.ULWYGMWQQX.getFileSystem(), NRACLVLXZC[0].getPath(), EEOLSQXCOL.getConfiguration());
        IntWritable NACTRUYHKK = new IntWritable();
        IntWritable NIGCGJNBAG = new IntWritable();
        while (ODMWESIAXF.next(NACTRUYHKK, NIGCGJNBAG)) {
            assertEquals("counts does not match", NIGCGJNBAG.get(), TestJoinDatamerge.countProduct(NACTRUYHKK, XJKVRNELMY, EEOLSQXCOL.getConfiguration()));
        } 
        ODMWESIAXF.close();
    }

    private static int countProduct(IntWritable CGUMIJPZFP, Path[] KMUEXYIBOU, Configuration PHGWARVPGY) throws IOException {
        int CROUBGXQTO = 1;
        for (Path QNAPHEHJOH : KMUEXYIBOU) {
            int ISITYQHSGD = 0;
            SequenceFile.Reader BORDRTNPIX = new SequenceFile.Reader(TestJoinDatamerge.ULWYGMWQQX.getFileSystem(), QNAPHEHJOH, PHGWARVPGY);
            IntWritable NDLIIOHGRO = new IntWritable();
            IntWritable NPVUBMJJTU = new IntWritable();
            while (BORDRTNPIX.next(NDLIIOHGRO, NPVUBMJJTU)) {
                if (NDLIIOHGRO.equals(CGUMIJPZFP)) {
                    ISITYQHSGD++;
                }
            } 
            BORDRTNPIX.close();
            if (ISITYQHSGD != 0) {
                CROUBGXQTO *= ISITYQHSGD;
            }
        }
        return CROUBGXQTO;
    }

    public void testSimpleOverride() throws Exception {
        TestJoinDatamerge.joinAs("override", TestJoinDatamerge.OverrideMapChecker.class, TestJoinDatamerge.OverrideReduceChecker.class);
    }

    public void testNestedJoin() throws Exception {
        // outer(inner(S1,...,Sn),outer(S1,...Sn))
        final int IULXPJOCEC = 3;
        final int AYODJXOWJX = (IULXPJOCEC + 1) * (IULXPJOCEC + 1);
        Configuration BFJQUCGKIA = new Configuration();
        Path GVTUKDHKXW = TestJoinDatamerge.ULWYGMWQQX.getFileSystem().makeQualified(new Path("/nested"));
        int[][] HCREYXEEXA = new int[IULXPJOCEC][];
        for (int LLRNNAPNYT = 0; LLRNNAPNYT < IULXPJOCEC; ++LLRNNAPNYT) {
            HCREYXEEXA[LLRNNAPNYT] = new int[AYODJXOWJX];
            for (int BFKQOPKSYW = 0; BFKQOPKSYW < AYODJXOWJX; ++BFKQOPKSYW) {
                HCREYXEEXA[LLRNNAPNYT][BFKQOPKSYW] = (LLRNNAPNYT + 2) * (BFKQOPKSYW + 1);
            }
        }
        Path[] KCIJTBACOD = new Path[IULXPJOCEC];
        SequenceFile[] CRNGFSOWQK = TestJoinDatamerge.createWriters(GVTUKDHKXW, BFJQUCGKIA, IULXPJOCEC, KCIJTBACOD);
        IntWritable WAETZFELYO = new IntWritable();
        for (int YZLWUQNUOH = 0; YZLWUQNUOH < IULXPJOCEC; ++YZLWUQNUOH) {
            IntWritable HOVHYJNOOV = new IntWritable();
            HOVHYJNOOV.set(YZLWUQNUOH);
            for (int BIUNFLZJIN = 0; BIUNFLZJIN < AYODJXOWJX; ++BIUNFLZJIN) {
                WAETZFELYO.set(HCREYXEEXA[YZLWUQNUOH][BIUNFLZJIN]);
                CRNGFSOWQK[YZLWUQNUOH].append(WAETZFELYO, HOVHYJNOOV);
            }
            CRNGFSOWQK[YZLWUQNUOH].close();
        }
        CRNGFSOWQK = null;
        StringBuilder PKKPLAOSRY = new StringBuilder();
        PKKPLAOSRY.append("outer(inner(");
        for (int LKYUXSBEXK = 0; LKYUXSBEXK < IULXPJOCEC; ++LKYUXSBEXK) {
            PKKPLAOSRY.append(CompositeInputFormat.compose(SequenceFileInputFormat.class, KCIJTBACOD[LKYUXSBEXK].toString()));
            if ((LKYUXSBEXK + 1) != IULXPJOCEC)
                PKKPLAOSRY.append(",");

        }
        PKKPLAOSRY.append("),outer(");
        PKKPLAOSRY.append(CompositeInputFormat.compose(Fake_IF.class, "foobar"));
        PKKPLAOSRY.append(",");
        for (int MHMAUOAVWS = 0; MHMAUOAVWS < IULXPJOCEC; ++MHMAUOAVWS) {
            PKKPLAOSRY.append(CompositeInputFormat.compose(SequenceFileInputFormat.class, KCIJTBACOD[MHMAUOAVWS].toString()));
            PKKPLAOSRY.append(",");
        }
        PKKPLAOSRY.append(CompositeInputFormat.compose(Fake_IF.class, "raboof") + "))");
        BFJQUCGKIA.set(JOIN_EXPR, PKKPLAOSRY.toString());
        Fake_IF.setKeyClass(BFJQUCGKIA, IntWritable.class);
        Fake_IF.setValClass(BFJQUCGKIA, IntWritable.class);
        Job USGZLZKDKS = Job.getInstance(BFJQUCGKIA);
        Path BGBNMDWIGY = new Path(GVTUKDHKXW, "out");
        FileOutputFormat.setOutputPath(USGZLZKDKS, BGBNMDWIGY);
        USGZLZKDKS.setInputFormatClass(CompositeInputFormat.class);
        USGZLZKDKS.setMapperClass(Mapper.class);
        USGZLZKDKS.setReducerClass(Reducer.class);
        USGZLZKDKS.setNumReduceTasks(0);
        USGZLZKDKS.setOutputKeyClass(IntWritable.class);
        USGZLZKDKS.setOutputValueClass(TupleWritable.class);
        USGZLZKDKS.setOutputFormatClass(SequenceFileOutputFormat.class);
        USGZLZKDKS.waitForCompletion(true);
        assertTrue("Job failed", USGZLZKDKS.isSuccessful());
        FileStatus[] MOFFZKBPUH = TestJoinDatamerge.ULWYGMWQQX.getFileSystem().listStatus(BGBNMDWIGY, new Utils.OutputFileUtils.OutputFilesFilter());
        assertEquals(1, MOFFZKBPUH.length);
        assertTrue(0 < MOFFZKBPUH[0].getLen());
        SequenceFile.Reader SYDZGBUKEA = new SequenceFile.Reader(TestJoinDatamerge.ULWYGMWQQX.getFileSystem(), MOFFZKBPUH[0].getPath(), BFJQUCGKIA);
        TupleWritable ZCIRHOYUNA = new TupleWritable();
        while (SYDZGBUKEA.next(WAETZFELYO, ZCIRHOYUNA)) {
            assertFalse(((TupleWritable) (ZCIRHOYUNA.get(1))).has(0));
            assertFalse(((TupleWritable) (ZCIRHOYUNA.get(1))).has(IULXPJOCEC + 1));
            boolean UKBJNOROKC = true;
            int HUHCXQLREU = WAETZFELYO.get();
            for (int THLIOMKHYW = 2; THLIOMKHYW < (IULXPJOCEC + 2); ++THLIOMKHYW) {
                if (((HUHCXQLREU % THLIOMKHYW) == 0) && (HUHCXQLREU <= (THLIOMKHYW * AYODJXOWJX))) {
                    assertEquals(THLIOMKHYW - 2, ((IntWritable) (((TupleWritable) (ZCIRHOYUNA.get(1))).get(THLIOMKHYW - 1))).get());
                } else
                    UKBJNOROKC = false;

            }
            if (UKBJNOROKC) {
                // present in all sources; chk inner
                assertTrue(ZCIRHOYUNA.has(0));
                for (int BBAUAAGVFR = 0; BBAUAAGVFR < IULXPJOCEC; ++BBAUAAGVFR)
                    assertTrue(((TupleWritable) (ZCIRHOYUNA.get(0))).has(BBAUAAGVFR));

            } else {
                // should not be present in inner join
                assertFalse(ZCIRHOYUNA.has(0));
            }
        } 
        SYDZGBUKEA.close();
        GVTUKDHKXW.getFileSystem(BFJQUCGKIA).delete(GVTUKDHKXW, true);
    }

    public void testEmptyJoin() throws Exception {
        Configuration LTHNMKLDYK = new Configuration();
        Path HSNTAGAVPN = TestJoinDatamerge.ULWYGMWQQX.getFileSystem().makeQualified(new Path("/empty"));
        Path[] CPOHGJMTVF = new Path[]{ new Path(HSNTAGAVPN, "i0"), new Path("i1"), new Path("i2") };
        LTHNMKLDYK.set(JOIN_EXPR, CompositeInputFormat.compose("outer", Fake_IF.class, CPOHGJMTVF));
        Fake_IF.setKeyClass(LTHNMKLDYK, IncomparableKey.class);
        Job YDOMJXWNKU = Job.getInstance(LTHNMKLDYK);
        YDOMJXWNKU.setInputFormatClass(CompositeInputFormat.class);
        FileOutputFormat.setOutputPath(YDOMJXWNKU, new Path(HSNTAGAVPN, "out"));
        YDOMJXWNKU.setMapperClass(Mapper.class);
        YDOMJXWNKU.setReducerClass(Reducer.class);
        YDOMJXWNKU.setOutputKeyClass(IncomparableKey.class);
        YDOMJXWNKU.setOutputValueClass(NullWritable.class);
        YDOMJXWNKU.waitForCompletion(true);
        assertTrue(YDOMJXWNKU.isSuccessful());
        HSNTAGAVPN.getFileSystem(LTHNMKLDYK).delete(HSNTAGAVPN, true);
    }
}