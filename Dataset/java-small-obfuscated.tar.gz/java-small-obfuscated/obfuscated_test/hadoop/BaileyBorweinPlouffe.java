/**
 * A map/reduce program that uses Bailey-Borwein-Plouffe to compute exact
 * digits of Pi.
 * This program is able to calculate digit positions
 * lower than a certain limit, which is roughly 10^8.
 * If the limit is exceeded,
 * the corresponding results may be incorrect due to overflow errors.
 * For computing higher bits of Pi, consider using distbbp.
 *
 * Reference:
 *
 * [1] David H. Bailey, Peter B. Borwein and Simon Plouffe.  On the Rapid
 *     Computation of Various Polylogarithmic Constants.
 *     Math. Comp., 66:903-913, 1996.
 */
public class BaileyBorweinPlouffe extends Configured implements Tool {
    public static final String VCKCBDLYBQ = "A map/reduce program that uses Bailey-Borwein-Plouffe to compute exact digits of Pi.";

    private static final String LTKTWIXBHH = "mapreduce." + BaileyBorweinPlouffe.class.getSimpleName();

    // custom job properties
    private static final String SUOVWSHKQU = BaileyBorweinPlouffe.LTKTWIXBHH + ".dir";

    private static final String CXRZPLGQXO = BaileyBorweinPlouffe.LTKTWIXBHH + ".hex.file";

    private static final String SREKCNGSQS = BaileyBorweinPlouffe.LTKTWIXBHH + ".digit.start";

    private static final String PAWDPKKXNG = BaileyBorweinPlouffe.LTKTWIXBHH + ".digit.size";

    private static final String VDYRFRJIIH = BaileyBorweinPlouffe.LTKTWIXBHH + ".digit.parts";

    private static final Log MMZGXUKXCR = LogFactory.getLog(BaileyBorweinPlouffe.class);

    /**
     * Mapper class computing digits of Pi.
     */
    public static class BbpMapper extends Mapper<LongWritable, IntWritable, LongWritable, BytesWritable> {
        /**
         * Compute the (offset+1)th to (offset+length)th digits.
         */
        protected void map(LongWritable offset, IntWritable length, final Context context) throws IOException, InterruptedException {
            BaileyBorweinPlouffe.MMZGXUKXCR.info((("offset=" + offset) + ", length=") + length);
            // compute digits
            final byte[] bytes = new byte[length.get() >> 1];
            long d = offset.get();
            for (int i = 0; i < bytes.length; d += 4) {
                final long digits = BaileyBorweinPlouffe.hexDigits(d);
                bytes[i++] = ((byte) (digits >> 8));
                bytes[i++] = ((byte) (digits));
            }
            // output map results
            context.write(offset, new BytesWritable(bytes));
        }
    }

    /**
     * Reducer for concatenating map outputs.
     */
    public static class BbpReducer extends Reducer<LongWritable, BytesWritable, LongWritable, BytesWritable> {
        /**
         * Storing hex digits
         */
        private final List<Byte> YPWRTVWYXU = new ArrayList<Byte>();

        /**
         * Concatenate map outputs.
         */
        @Override
        protected void reduce(LongWritable offset, Iterable<BytesWritable> values, Context context) throws IOException, InterruptedException {
            // read map outputs
            for (BytesWritable bytes : values) {
                for (int i = 0; i < bytes.getLength(); i++)
                    YPWRTVWYXU.add(bytes.getBytes()[i]);

            }
            BaileyBorweinPlouffe.MMZGXUKXCR.info("hex.size() = " + YPWRTVWYXU.size());
        }

        /**
         * Write output to files.
         */
        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            final Configuration conf = context.getConfiguration();
            final Path dir = new Path(conf.get(BaileyBorweinPlouffe.SUOVWSHKQU));
            final FileSystem fs = dir.getFileSystem(conf);
            // write hex output
            {
                final Path hexfile = new Path(conf.get(BaileyBorweinPlouffe.CXRZPLGQXO));
                final OutputStream out = new BufferedOutputStream(fs.create(hexfile));
                try {
                    for (byte b : YPWRTVWYXU)
                        out.write(b);

                } finally {
                    out.close();
                }
            }
            // If the starting digit is 1,
            // the hex value can be converted to decimal value.
            if (conf.getInt(BaileyBorweinPlouffe.SREKCNGSQS, 1) == 1) {
                final Path outfile = new Path(dir, "pi.txt");
                BaileyBorweinPlouffe.MMZGXUKXCR.info("Writing text output to " + outfile);
                final OutputStream outputstream = fs.create(outfile);
                try {
                    final PrintWriter out = new PrintWriter(new OutputStreamWriter(outputstream, Charsets.UTF_8), true);
                    // write hex text
                    BaileyBorweinPlouffe.print(out, YPWRTVWYXU.iterator(), "Pi = 0x3.", "%02X", 5, 5);
                    out.println(("Total number of hexadecimal digits is " + (2 * YPWRTVWYXU.size())) + ".");
                    // write decimal text
                    final BaileyBorweinPlouffe.Fraction dec = new BaileyBorweinPlouffe.Fraction(YPWRTVWYXU);
                    final int decDigits = 2 * YPWRTVWYXU.size();// TODO: this is conservative.

                    BaileyBorweinPlouffe.print(out, new Iterator<Integer>() {
                        private int CNGUDFPHCY = 0;

                        public boolean hasNext() {
                            return CNGUDFPHCY < decDigits;
                        }

                        public Integer next() {
                            CNGUDFPHCY++;
                            return dec.times10();
                        }

                        public void remove() {
                        }
                    }, "Pi = 3.", "%d", 10, 5);
                    out.println(("Total number of decimal digits is " + decDigits) + ".");
                } finally {
                    outputstream.close();
                }
            }
        }
    }

    /**
     * Print out elements in a nice format.
     */
    private static <T> void print(PrintWriter OKHJOHTWRI, Iterator<T> KLSNQACADW, String YXFJVBPPMF, String SWIGIPFHGO, int CWYKSVPJXX, int CBIDBLLOJM) {
        final StringBuilder WASRPVNNGX = new StringBuilder("\n");
        for (int IPUGMMFGRP = 0; IPUGMMFGRP < YXFJVBPPMF.length(); IPUGMMFGRP++)
            WASRPVNNGX.append(" ");

        final String KQNZHQERXL = WASRPVNNGX.toString();
        OKHJOHTWRI.print("\n" + YXFJVBPPMF);
        for (int MJWIAQYVUA = 0; KLSNQACADW.hasNext(); MJWIAQYVUA++) {
            if ((MJWIAQYVUA > 0) && ((MJWIAQYVUA % CWYKSVPJXX) == 0))
                OKHJOHTWRI.print(((MJWIAQYVUA / CWYKSVPJXX) % CBIDBLLOJM) == 0 ? KQNZHQERXL : " ");

            OKHJOHTWRI.print(String.format(SWIGIPFHGO, KLSNQACADW.next()));
        }
        OKHJOHTWRI.println();
    }

    /**
     * Input split for the {@link BbpInputFormat}.
     */
    public static class BbpSplit extends InputSplit implements Writable {
        private static final String[] AYSOYDOUKP = new String[]{  };

        private long XPHMUOBVOW;

        private int TJWSTXXRTD;

        /**
         * Public default constructor for the Writable interface.
         */
        public BbpSplit() {
        }

        private BbpSplit(int i, long offset, int size) {
            BaileyBorweinPlouffe.MMZGXUKXCR.info((((((("Map #" + i) + ": workload=") + BaileyBorweinPlouffe.workload(offset, size)) + ", offset=") + offset) + ", size=") + size);
            this.XPHMUOBVOW = offset;
            this.TJWSTXXRTD = size;
        }

        private long getOffset() {
            return XPHMUOBVOW;
        }

        /**
         * {@inheritDoc }
         */
        public long getLength() {
            return TJWSTXXRTD;
        }

        /**
         * No location is needed.
         */
        public String[] getLocations() {
            return BaileyBorweinPlouffe.BbpSplit.AYSOYDOUKP;
        }

        /**
         * {@inheritDoc }
         */
        public void readFields(DataInput in) throws IOException {
            XPHMUOBVOW = in.readLong();
            TJWSTXXRTD = in.readInt();
        }

        /**
         * {@inheritDoc }
         */
        public void write(DataOutput out) throws IOException {
            out.writeLong(XPHMUOBVOW);
            out.writeInt(TJWSTXXRTD);
        }
    }

    /**
     * Input format for the {@link BbpMapper}.
     * Keys and values represent offsets and sizes, respectively.
     */
    public static class BbpInputFormat extends InputFormat<LongWritable, IntWritable> {
        /**
         * {@inheritDoc }
         */
        public List<InputSplit> getSplits(JobContext context) {
            // get the property values
            final int startDigit = context.getConfiguration().getInt(BaileyBorweinPlouffe.SREKCNGSQS, 1);
            final int nDigits = context.getConfiguration().getInt(BaileyBorweinPlouffe.PAWDPKKXNG, 100);
            final int nMaps = context.getConfiguration().getInt(BaileyBorweinPlouffe.VDYRFRJIIH, 1);
            // create splits
            final List<InputSplit> splits = new ArrayList<InputSplit>(nMaps);
            final int[] parts = BaileyBorweinPlouffe.partition(startDigit - 1, nDigits, nMaps);
            for (int i = 0; i < parts.length; ++i) {
                final int k = (i < (parts.length - 1)) ? parts[i + 1] : (nDigits + startDigit) - 1;
                splits.add(new BaileyBorweinPlouffe.BbpSplit(i, parts[i], k - parts[i]));
            }
            return splits;
        }

        /**
         * {@inheritDoc }
         */
        public RecordReader<LongWritable, IntWritable> createRecordReader(InputSplit generic, TaskAttemptContext context) {
            final BaileyBorweinPlouffe.BbpSplit split = ((BaileyBorweinPlouffe.BbpSplit) (generic));
            // return a record reader
            return new RecordReader<LongWritable, IntWritable>() {
                boolean TJULGSXALS = false;

                public void initialize(InputSplit split, TaskAttemptContext context) {
                }

                public boolean nextKeyValue() {
                    // Each record only contains one key.
                    return !TJULGSXALS ? TJULGSXALS = true : false;
                }

                public LongWritable getCurrentKey() {
                    return new LongWritable(split.getOffset());
                }

                public IntWritable getCurrentValue() {
                    return new IntWritable(((int) (split.getLength())));
                }

                public float getProgress() {
                    return TJULGSXALS ? 1.0F : 0.0F;
                }

                public void close() {
                }
            };
        }
    }

    /**
     * Create and setup a job
     */
    private static Job createJob(String EEJLCVPOXL, Configuration AQODKOLXHA) throws IOException {
        final Job QDSUMCUVRA = new Job(AQODKOLXHA, (BaileyBorweinPlouffe.LTKTWIXBHH + "_") + EEJLCVPOXL);
        final Configuration MFYWBBCRDM = QDSUMCUVRA.getConfiguration();
        QDSUMCUVRA.setJarByClass(BaileyBorweinPlouffe.class);
        // setup mapper
        QDSUMCUVRA.setMapperClass(BaileyBorweinPlouffe.BbpMapper.class);
        QDSUMCUVRA.setMapOutputKeyClass(LongWritable.class);
        QDSUMCUVRA.setMapOutputValueClass(BytesWritable.class);
        // setup reducer
        QDSUMCUVRA.setReducerClass(BaileyBorweinPlouffe.BbpReducer.class);
        QDSUMCUVRA.setOutputKeyClass(LongWritable.class);
        QDSUMCUVRA.setOutputValueClass(BytesWritable.class);
        QDSUMCUVRA.setNumReduceTasks(1);
        // setup input
        QDSUMCUVRA.setInputFormatClass(BaileyBorweinPlouffe.BbpInputFormat.class);
        // disable task timeout
        MFYWBBCRDM.setLong(TASK_TIMEOUT, 0);
        // do not use speculative execution
        MFYWBBCRDM.setBoolean(MAP_SPECULATIVE, false);
        MFYWBBCRDM.setBoolean(REDUCE_SPECULATIVE, false);
        return QDSUMCUVRA;
    }

    /**
     * Run a map/reduce job to compute Pi.
     */
    private static void compute(int EOPTEVITDY, int NVMPBAPSOP, int WJZQKAMTVN, String JOTJYAKVDF, Configuration NIARGKOVAR, PrintStream GLGRPOVIDS) throws IOException {
        final String TYSBKWLNRM = (EOPTEVITDY + "_") + NVMPBAPSOP;
        // setup wroking directory
        GLGRPOVIDS.println("Working Directory = " + JOTJYAKVDF);
        GLGRPOVIDS.println();
        final FileSystem KQCRZIKYPO = FileSystem.get(NIARGKOVAR);
        final Path XWJXSCLGJW = KQCRZIKYPO.makeQualified(new Path(JOTJYAKVDF));
        if (KQCRZIKYPO.exists(XWJXSCLGJW)) {
            throw new IOException(("Working directory " + XWJXSCLGJW) + " already exists.  Please remove it first.");
        } else
            if (!KQCRZIKYPO.mkdirs(XWJXSCLGJW)) {
                throw new IOException("Cannot create working directory " + XWJXSCLGJW);
            }

        GLGRPOVIDS.println("Start Digit      = " + EOPTEVITDY);
        GLGRPOVIDS.println("Number of Digits = " + NVMPBAPSOP);
        GLGRPOVIDS.println("Number of Maps   = " + WJZQKAMTVN);
        // setup a job
        final Job EUWYTJMVKG = BaileyBorweinPlouffe.createJob(TYSBKWLNRM, NIARGKOVAR);
        final Path TMVPQPGARB = new Path(XWJXSCLGJW, ("pi_" + TYSBKWLNRM) + ".hex");
        FileOutputFormat.setOutputPath(EUWYTJMVKG, new Path(XWJXSCLGJW, "out"));
        // setup custom properties
        EUWYTJMVKG.getConfiguration().set(BaileyBorweinPlouffe.SUOVWSHKQU, XWJXSCLGJW.toString());
        EUWYTJMVKG.getConfiguration().set(BaileyBorweinPlouffe.CXRZPLGQXO, TMVPQPGARB.toString());
        EUWYTJMVKG.getConfiguration().setInt(BaileyBorweinPlouffe.SREKCNGSQS, EOPTEVITDY);
        EUWYTJMVKG.getConfiguration().setInt(BaileyBorweinPlouffe.PAWDPKKXNG, NVMPBAPSOP);
        EUWYTJMVKG.getConfiguration().setInt(BaileyBorweinPlouffe.VDYRFRJIIH, WJZQKAMTVN);
        // start a map/reduce job
        GLGRPOVIDS.println("\nStarting Job ...");
        final long SIJTPOABPA = System.currentTimeMillis();
        try {
            if (!EUWYTJMVKG.waitForCompletion(true)) {
                GLGRPOVIDS.println("Job failed.");
                System.exit(1);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            final double NDJMKUTILN = (System.currentTimeMillis() - SIJTPOABPA) / 1000.0;
            GLGRPOVIDS.println(("Duration is " + NDJMKUTILN) + " seconds.");
        }
        GLGRPOVIDS.println("Output file: " + TMVPQPGARB);
    }

    /**
     * Parse arguments and then runs a map/reduce job.
     *
     * @return a non-zero value if there is an error. Otherwise, return 0.
     */
    public int run(String[] RAHQQHHGCW) throws IOException {
        if (RAHQQHHGCW.length != 4) {
            System.err.println(("Usage: java " + getClass().getName()) + " <startDigit> <nDigits> <nMaps> <workingDir>");
            ToolRunner.printGenericCommandUsage(System.err);
            return -1;
        }
        final int MNINKWJPVQ = Integer.parseInt(RAHQQHHGCW[0]);
        final int RFTBMSBDZX = Integer.parseInt(RAHQQHHGCW[1]);
        final int LUWJNCKYZU = Integer.parseInt(RAHQQHHGCW[2]);
        final String BKVQTGQCMN = RAHQQHHGCW[3];
        if (MNINKWJPVQ <= 0) {
            throw new IllegalArgumentException(("startDigit = " + MNINKWJPVQ) + " <= 0");
        } else
            if (RFTBMSBDZX <= 0) {
                throw new IllegalArgumentException(("nDigits = " + RFTBMSBDZX) + " <= 0");
            } else
                if ((RFTBMSBDZX % BaileyBorweinPlouffe.XOWAQZSHBR) != 0) {
                    throw new IllegalArgumentException((("nDigits = " + RFTBMSBDZX) + " is not a multiple of ") + BaileyBorweinPlouffe.XOWAQZSHBR);
                } else
                    if (((RFTBMSBDZX - 1L) + MNINKWJPVQ) > (BaileyBorweinPlouffe.RMXBYWENDF + BaileyBorweinPlouffe.XOWAQZSHBR)) {
                        throw new UnsupportedOperationException(((((("nDigits - 1 + startDigit = " + ((RFTBMSBDZX - 1L) + MNINKWJPVQ)) + " > IMPLEMENTATION_LIMIT + BBP_HEX_DIGITS,") + ", where IMPLEMENTATION_LIMIT=") + BaileyBorweinPlouffe.RMXBYWENDF) + "and BBP_HEX_DIGITS=") + BaileyBorweinPlouffe.XOWAQZSHBR);
                    } else
                        if (LUWJNCKYZU <= 0) {
                            throw new IllegalArgumentException(("nMaps = " + LUWJNCKYZU) + " <= 0");
                        }




        BaileyBorweinPlouffe.compute(MNINKWJPVQ, RFTBMSBDZX, LUWJNCKYZU, BKVQTGQCMN, getConf(), System.out);
        return 0;
    }

    /**
     * The main method for running it as a stand alone command.
     */
    public static void main(String[] TAHSSXHRGR) throws Exception {
        System.exit(ToolRunner.run(null, new BaileyBorweinPlouffe(), TAHSSXHRGR));
    }

    // ///////////////////////////////////////////////////////////////////
    // static fields and methods for Bailey-Borwein-Plouffe algorithm. //
    // ///////////////////////////////////////////////////////////////////
    /**
     * Limitation of the program.
     * The program may return incorrect results if the limit is exceeded.
     * The default value is 10^8.
     * The program probably can handle some higher values such as 2^28.
     */
    private static final long RMXBYWENDF = 100000000;

    private static final long NBXOBDQIPE = 32;

    private static final long XOWAQZSHBR = 4;

    private static final long KRUHZOJQZD = 1 << (4 * BaileyBorweinPlouffe.XOWAQZSHBR);

    /**
     * Compute the exact (d+1)th to (d+{@link #BBP_HEX_DIGITS})th
     * hex digits of pi.
     */
    static long hexDigits(final long AHSHPHYQJO) {
        if (AHSHPHYQJO < 0) {
            throw new IllegalArgumentException(("d = " + AHSHPHYQJO) + " < 0");
        } else
            if (AHSHPHYQJO > BaileyBorweinPlouffe.RMXBYWENDF) {
                throw new IllegalArgumentException((("d = " + AHSHPHYQJO) + " > IMPLEMENTATION_LIMIT = ") + BaileyBorweinPlouffe.RMXBYWENDF);
            }

        final double GCOXHWVXIY = BaileyBorweinPlouffe.sum(1, AHSHPHYQJO);
        final double TRRFMKHEUY = BaileyBorweinPlouffe.sum(4, AHSHPHYQJO);
        final double RHDAXSCDWX = BaileyBorweinPlouffe.sum(5, AHSHPHYQJO);
        final double QWGZBLIVHP = BaileyBorweinPlouffe.sum(6, AHSHPHYQJO);
        double JAUBZTPOZK = GCOXHWVXIY + GCOXHWVXIY;
        if (JAUBZTPOZK >= 1)
            JAUBZTPOZK--;

        JAUBZTPOZK *= 2;
        if (JAUBZTPOZK >= 1)
            JAUBZTPOZK--;

        JAUBZTPOZK -= TRRFMKHEUY;
        if (JAUBZTPOZK < 0)
            JAUBZTPOZK++;

        JAUBZTPOZK -= TRRFMKHEUY;
        if (JAUBZTPOZK < 0)
            JAUBZTPOZK++;

        JAUBZTPOZK -= RHDAXSCDWX;
        if (JAUBZTPOZK < 0)
            JAUBZTPOZK++;

        JAUBZTPOZK -= QWGZBLIVHP;
        if (JAUBZTPOZK < 0)
            JAUBZTPOZK++;

        return ((long) (JAUBZTPOZK * BaileyBorweinPlouffe.KRUHZOJQZD));
    }

    /**
     * Approximate the fraction part of
     * $16^d \sum_{k=0}^\infty \frac{16^{d-k}}{8k+j}$
     * for d > 0 and j = 1, 4, 5, 6.
     */
    private static double sum(final long PWIYYMJSSW, final long PROOUJDJPC) {
        long BXOTTGDCZZ = (PWIYYMJSSW == 1) ? 1 : 0;
        double AOXTAXCPGV = 0;
        if (BXOTTGDCZZ <= PROOUJDJPC) {
            AOXTAXCPGV = 1.0 / ((PROOUJDJPC << 3) | PWIYYMJSSW);
            for (; BXOTTGDCZZ < PROOUJDJPC; BXOTTGDCZZ++) {
                final long JOMKGRBSPH = (BXOTTGDCZZ << 3) | PWIYYMJSSW;
                AOXTAXCPGV += (BaileyBorweinPlouffe.mod((PROOUJDJPC - BXOTTGDCZZ) << 2, JOMKGRBSPH) * 1.0) / JOMKGRBSPH;
                if (AOXTAXCPGV >= 1)
                    AOXTAXCPGV--;

            }
            BXOTTGDCZZ++;
        }
        if (BXOTTGDCZZ >= (1L << (BaileyBorweinPlouffe.NBXOBDQIPE - 7)))
            return AOXTAXCPGV;

        for (; ; BXOTTGDCZZ++) {
            final long JYYHVMGRUS = (BXOTTGDCZZ << 3) | PWIYYMJSSW;
            final long DXIXXNYPYE = (BXOTTGDCZZ - PROOUJDJPC) << 2;
            if ((BaileyBorweinPlouffe.NBXOBDQIPE <= DXIXXNYPYE) || ((1L << (BaileyBorweinPlouffe.NBXOBDQIPE - DXIXXNYPYE)) < JYYHVMGRUS)) {
                return AOXTAXCPGV;
            }
            AOXTAXCPGV += 1.0 / (JYYHVMGRUS << DXIXXNYPYE);
            if (AOXTAXCPGV >= 1)
                AOXTAXCPGV--;

        }
    }

    /**
     * Compute $2^e \mod n$ for e > 0, n > 2
     */
    static long mod(final long PNXNEBBBUI, final long JTSFFWDKKD) {
        long BRPDLQXBCV = ((PNXNEBBBUI & 0xffffffff00000000L) == 0) ? 0xffffffffL : 0xffffffff00000000L;
        BRPDLQXBCV &= (((PNXNEBBBUI & 0xffff0000ffff0000L) & BRPDLQXBCV) == 0) ? 0xffff0000ffffL : 0xffff0000ffff0000L;
        BRPDLQXBCV &= (((PNXNEBBBUI & 0xff00ff00ff00ff00L) & BRPDLQXBCV) == 0) ? 0xff00ff00ff00ffL : 0xff00ff00ff00ff00L;
        BRPDLQXBCV &= (((PNXNEBBBUI & 0xf0f0f0f0f0f0f0f0L) & BRPDLQXBCV) == 0) ? 0xf0f0f0f0f0f0f0fL : 0xf0f0f0f0f0f0f0f0L;
        BRPDLQXBCV &= (((PNXNEBBBUI & 0xccccccccccccccccL) & BRPDLQXBCV) == 0) ? 0x3333333333333333L : 0xccccccccccccccccL;
        BRPDLQXBCV &= (((PNXNEBBBUI & 0xaaaaaaaaaaaaaaaaL) & BRPDLQXBCV) == 0) ? 0x5555555555555555L : 0xaaaaaaaaaaaaaaaaL;
        long QBJWLYTTJH = 2;
        for (BRPDLQXBCV >>= 1; BRPDLQXBCV > 0; BRPDLQXBCV >>= 1) {
            QBJWLYTTJH *= QBJWLYTTJH;
            QBJWLYTTJH %= JTSFFWDKKD;
            if ((PNXNEBBBUI & BRPDLQXBCV) != 0) {
                QBJWLYTTJH += QBJWLYTTJH;
                if (QBJWLYTTJH >= JTSFFWDKKD)
                    QBJWLYTTJH -= JTSFFWDKKD;

            }
        }
        return QBJWLYTTJH;
    }

    /**
     * Represent a number x in hex for 1 > x >= 0
     */
    private static class Fraction {
        private final int[] NHUKJMPHZO;// only use 24-bit


        private int UHIDPVVOWR = 0;// index to the first non-zero integer


        /**
         * Construct a fraction represented by the bytes.
         */
        Fraction(List<Byte> bytes) {
            NHUKJMPHZO = new int[(bytes.size() + 2) / 3];
            for (int i = 0; i < bytes.size(); i++) {
                final int b = 0xff & bytes.get(i);
                NHUKJMPHZO[(NHUKJMPHZO.length - 1) - (i / 3)] |= b << ((2 - (i % 3)) << 3);
            }
            skipZeros();
        }

        /**
         * Compute y = 10*x and then set x to the fraction part of y, where x is the
         * fraction represented by this object.
         *
         * @return integer part of y
         */
        int times10() {
            int carry = 0;
            for (int i = UHIDPVVOWR; i < NHUKJMPHZO.length; i++) {
                NHUKJMPHZO[i] <<= 1;
                NHUKJMPHZO[i] += carry + (NHUKJMPHZO[i] << 2);
                carry = NHUKJMPHZO[i] >> 24;
                NHUKJMPHZO[i] &= 0xffffff;
            }
            skipZeros();
            return carry;
        }

        private void skipZeros() {
            for (; (UHIDPVVOWR < NHUKJMPHZO.length) && (NHUKJMPHZO[UHIDPVVOWR] == 0); UHIDPVVOWR++);
        }
    }

    /**
     * Partition input so that the workload of each part is
     * approximately the same.
     */
    static int[] partition(final int BUPQDVAQBQ, final int ESLNFAKHPA, final int KIYOQTNDDD) {
        final int[] VCRMHNHVAM = new int[KIYOQTNDDD];
        final long BSGNGAIPED = BaileyBorweinPlouffe.workload(BUPQDVAQBQ, ESLNFAKHPA);
        final int SNMWVPQVWO = BUPQDVAQBQ % 4;
        VCRMHNHVAM[0] = BUPQDVAQBQ;
        for (int TSJLEWIVUP = 1; TSJLEWIVUP < KIYOQTNDDD; TSJLEWIVUP++) {
            final long NQBRHRDMNA = (BUPQDVAQBQ + (TSJLEWIVUP * (BSGNGAIPED / KIYOQTNDDD))) + ((TSJLEWIVUP * (BSGNGAIPED % KIYOQTNDDD)) / KIYOQTNDDD);
            // search the closest value
            int ILSJQGFJJL = VCRMHNHVAM[TSJLEWIVUP - 1];
            int PSESQSIZKV = BUPQDVAQBQ + ESLNFAKHPA;
            for (; PSESQSIZKV > (ILSJQGFJJL + 4);) {
                final int QUCVCUQJAB = ((((PSESQSIZKV + ILSJQGFJJL) - (2 * SNMWVPQVWO)) / 8) * 4) + SNMWVPQVWO;
                final long GHUTHTDNOY = BaileyBorweinPlouffe.workload(QUCVCUQJAB);
                if (GHUTHTDNOY == NQBRHRDMNA)
                    PSESQSIZKV = ILSJQGFJJL = QUCVCUQJAB;
                else
                    if (GHUTHTDNOY > NQBRHRDMNA)
                        PSESQSIZKV = QUCVCUQJAB;
                    else
                        ILSJQGFJJL = QUCVCUQJAB;


            }
            VCRMHNHVAM[TSJLEWIVUP] = (PSESQSIZKV == ILSJQGFJJL) ? PSESQSIZKV : (BaileyBorweinPlouffe.workload(PSESQSIZKV) - NQBRHRDMNA) > (NQBRHRDMNA - BaileyBorweinPlouffe.workload(ILSJQGFJJL)) ? ILSJQGFJJL : PSESQSIZKV;
        }
        return VCRMHNHVAM;
    }

    private static final long EJTANXQXCO = 4294967295L;// prevent overflow


    /**
     * Estimate the workload for input size n (in some unit).
     */
    private static long workload(final long VBCUGPYZYU) {
        if (VBCUGPYZYU < 0) {
            throw new IllegalArgumentException(("n = " + VBCUGPYZYU) + " < 0");
        } else
            if (VBCUGPYZYU > BaileyBorweinPlouffe.EJTANXQXCO) {
                throw new IllegalArgumentException((("n = " + VBCUGPYZYU) + " > MAX_N = ") + BaileyBorweinPlouffe.EJTANXQXCO);
            }

        return (VBCUGPYZYU & 1L) == 0L ? (VBCUGPYZYU >> 1) * (VBCUGPYZYU + 1) : VBCUGPYZYU * ((VBCUGPYZYU + 1) >> 1);
    }

    private static long workload(long WTRMYKHYBU, long CQIUGPSMGU) {
        return BaileyBorweinPlouffe.workload(WTRMYKHYBU + CQIUGPSMGU) - BaileyBorweinPlouffe.workload(WTRMYKHYBU);
    }
}