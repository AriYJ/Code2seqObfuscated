/**
 * This class creates gzip compressors/decompressors.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class GzipCodec extends DefaultCodec {
    /**
     * A bridge that wraps around a DeflaterOutputStream to make it
     * a CompressionOutputStream.
     */
    @InterfaceStability.Evolving
    protected static class GzipOutputStream extends CompressorStream {
        private static class ResetableGZIPOutputStream extends GZIPOutputStream {
            private static final int CGVVLFEBKD = 8;

            public static final String SAOIQCGNNX = System.getProperty("java.version");

            private static final boolean CSELOBNXMZ = IBM_JAVA && GzipCodec.GzipOutputStream.ResetableGZIPOutputStream.SAOIQCGNNX.contains("1.6.0");

            public ResetableGZIPOutputStream(OutputStream out) throws IOException {
                super(out);
            }

            public void resetState() throws IOException {
                def.reset();
            }

            /**
             * Override this method for HADOOP-8419.
             * Override because IBM implementation calls def.end() which
             * causes problem when reseting the stream for reuse.
             */
            @Override
            public void finish() throws IOException {
                if (GzipCodec.GzipOutputStream.ResetableGZIPOutputStream.CSELOBNXMZ) {
                    if (!def.finished()) {
                        def.finish();
                        while (!def.finished()) {
                            int i = def.deflate(this.buf, 0, this.buf.length);
                            if (def.finished() && (i <= (this.buf.length - GzipCodec.GzipOutputStream.ResetableGZIPOutputStream.CGVVLFEBKD))) {
                                writeTrailer(this.buf, i);
                                i += GzipCodec.GzipOutputStream.ResetableGZIPOutputStream.CGVVLFEBKD;
                                out.write(this.buf, 0, i);
                                return;
                            }
                            if (i > 0) {
                                out.write(this.buf, 0, i);
                            }
                        } 
                        byte[] arrayOfByte = new byte[GzipCodec.GzipOutputStream.ResetableGZIPOutputStream.CGVVLFEBKD];
                        writeTrailer(arrayOfByte, 0);
                        out.write(arrayOfByte);
                    }
                } else {
                    super.finish();
                }
            }

            /**
             * re-implement for HADOOP-8419 because the relative method in jdk is invisible
             */
            private void writeTrailer(byte[] paramArrayOfByte, int paramInt) throws IOException {
                writeInt(((int) (this.crc.getValue())), paramArrayOfByte, paramInt);
                writeInt(this.def.getTotalIn(), paramArrayOfByte, paramInt + 4);
            }

            /**
             * re-implement for HADOOP-8419 because the relative method in jdk is invisible
             */
            private void writeInt(int paramInt1, byte[] paramArrayOfByte, int paramInt2) throws IOException {
                writeShort(paramInt1 & 0xffff, paramArrayOfByte, paramInt2);
                writeShort((paramInt1 >> 16) & 0xffff, paramArrayOfByte, paramInt2 + 2);
            }

            /**
             * re-implement for HADOOP-8419 because the relative method in jdk is invisible
             */
            private void writeShort(int paramInt1, byte[] paramArrayOfByte, int paramInt2) throws IOException {
                paramArrayOfByte[paramInt2] = ((byte) (paramInt1 & 0xff));
                paramArrayOfByte[paramInt2 + 1] = ((byte) ((paramInt1 >> 8) & 0xff));
            }
        }

        public GzipOutputStream(OutputStream out) throws IOException {
            super(new GzipCodec.GzipOutputStream.ResetableGZIPOutputStream(out));
        }

        /**
         * Allow children types to put a different type in here.
         *
         * @param out
         * 		the Deflater stream to use
         */
        protected GzipOutputStream(CompressorStream out) {
            super(out);
        }

        @Override
        public void close() throws IOException {
            out.close();
        }

        @Override
        public void flush() throws IOException {
            out.flush();
        }

        @Override
        public void write(int b) throws IOException {
            out.write(b);
        }

        @Override
        public void write(byte[] data, int offset, int length) throws IOException {
            out.write(data, offset, length);
        }

        @Override
        public void finish() throws IOException {
            ((GzipCodec.GzipOutputStream.ResetableGZIPOutputStream) (out)).finish();
        }

        @Override
        public void resetState() throws IOException {
            ((GzipCodec.GzipOutputStream.ResetableGZIPOutputStream) (out)).resetState();
        }
    }

    @Override
    public CompressionOutputStream createOutputStream(OutputStream XMFOLWSUKZ) throws IOException {
        if (!ZlibFactory.isNativeZlibLoaded(conf)) {
            return new GzipCodec.GzipOutputStream(XMFOLWSUKZ);
        }
        return Util.createOutputStreamWithCodecPool(this, conf, XMFOLWSUKZ);
    }

    @Override
    public CompressionOutputStream createOutputStream(OutputStream RFIHIWTDAO, Compressor HQNKOGUAES) throws IOException {
        return HQNKOGUAES != null ? new CompressorStream(RFIHIWTDAO, HQNKOGUAES, conf.getInt("io.file.buffer.size", 4 * 1024)) : createOutputStream(RFIHIWTDAO);
    }

    @Override
    public Compressor createCompressor() {
        return ZlibFactory.isNativeZlibLoaded(conf) ? new GzipCodec.GzipZlibCompressor(conf) : null;
    }

    @Override
    public Class<? extends Compressor> getCompressorType() {
        return ZlibFactory.isNativeZlibLoaded(conf) ? GzipCodec.GzipZlibCompressor.class : null;
    }

    @Override
    public CompressionInputStream createInputStream(InputStream PYXLQHVNVP) throws IOException {
        return Util.createInputStreamWithCodecPool(this, conf, PYXLQHVNVP);
    }

    @Override
    public CompressionInputStream createInputStream(InputStream UBGAINGCWJ, Decompressor OJYLSJDJQL) throws IOException {
        if (OJYLSJDJQL == null) {
            OJYLSJDJQL = createDecompressor();// always succeeds (or throws)

        }
        return new DecompressorStream(UBGAINGCWJ, OJYLSJDJQL, conf.getInt("io.file.buffer.size", 4 * 1024));
    }

    @Override
    public Decompressor createDecompressor() {
        return ZlibFactory.isNativeZlibLoaded(conf) ? new GzipCodec.GzipZlibDecompressor() : new BuiltInGzipDecompressor();
    }

    @Override
    public Class<? extends Decompressor> getDecompressorType() {
        return ZlibFactory.isNativeZlibLoaded(conf) ? GzipCodec.GzipZlibDecompressor.class : BuiltInGzipDecompressor.class;
    }

    @Override
    public DirectDecompressor createDirectDecompressor() {
        return ZlibFactory.isNativeZlibLoaded(conf) ? new ZlibDecompressor.ZlibDirectDecompressor(CompressionHeader.AUTODETECT_GZIP_ZLIB, 0) : null;
    }

    @Override
    public String getDefaultExtension() {
        return ".gz";
    }

    static final class GzipZlibCompressor extends ZlibCompressor {
        public GzipZlibCompressor() {
            super(DEFAULT_COMPRESSION, DEFAULT_STRATEGY, GZIP_FORMAT, 64 * 1024);
        }

        public GzipZlibCompressor(Configuration conf) {
            super(ZlibFactory.getCompressionLevel(conf), ZlibFactory.getCompressionStrategy(conf), GZIP_FORMAT, 64 * 1024);
        }
    }

    static final class GzipZlibDecompressor extends ZlibDecompressor {
        public GzipZlibDecompressor() {
            super(AUTODETECT_GZIP_ZLIB, 64 * 1024);
        }
    }
}