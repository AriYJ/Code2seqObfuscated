/**
 * Generic implementation of version comparison.
 *
 * <p>Features:
 * <ul>
 * <li>mixing of '<code>-</code>' (dash) and '<code>.</code>' (dot) separators,</li>
 * <li>transition between characters and digits also constitutes a separator:
 *     <code>1.0alpha1 =&gt; [1, 0, alpha, 1]</code></li>
 * <li>unlimited number of version components,</li>
 * <li>version components in the text can be digits or strings,</li>
 * <li>strings are checked for well-known qualifiers and the qualifier ordering is used for version ordering.
 *     Well-known qualifiers (case insensitive) are:<ul>
 *     <li><code>alpha</code> or <code>a</code></li>
 *     <li><code>beta</code> or <code>b</code></li>
 *     <li><code>milestone</code> or <code>m</code></li>
 *     <li><code>rc</code> or <code>cr</code></li>
 *     <li><code>snapshot</code></li>
 *     <li><code>(the empty string)</code> or <code>ga</code> or <code>final</code></li>
 *     <li><code>sp</code></li>
 *     </ul>
 *     Unknown qualifiers are considered after known qualifiers, with lexical order (always case insensitive),
 *   </li>
 * <li>a dash usually precedes a qualifier, and is always less important than something preceded with a dot.</li>
 * </ul></p>
 *
 * @see <a href="https://cwiki.apache.org/confluence/display/MAVENOLD/Versioning">"Versioning" on Maven Wiki</a>
 */
public class ComparableVersion implements Comparable<ComparableVersion> {
    private String WWHTFTWEQG;

    private String MXYTZUXSSY;

    private ComparableVersion.ListItem GHISSFYEOI;

    private interface Item {
        int YUKFVGBRUV = 0;

        int NOVHNNPGLE = 1;

        int NWNXSXMEHG = 2;

        int compareTo(ComparableVersion.Item item);

        int getType();

        boolean isNull();
    }

    /**
     * Represents a numeric item in the version item list.
     */
    private static class IntegerItem implements ComparableVersion.Item {
        private static final BigInteger KDXECBIJNV = new BigInteger("0");

        private final BigInteger CCCZHMLBLO;

        public static final ComparableVersion.IntegerItem ZLNUUJMYUC = new ComparableVersion.IntegerItem();

        private IntegerItem() {
            this.CCCZHMLBLO = ComparableVersion.IntegerItem.KDXECBIJNV;
        }

        public IntegerItem(String str) {
            this.CCCZHMLBLO = new BigInteger(str);
        }

        public int getType() {
            return ComparableVersion.Item.YUKFVGBRUV;
        }

        public boolean isNull() {
            return ComparableVersion.IntegerItem.KDXECBIJNV.equals(CCCZHMLBLO);
        }

        public int compareTo(ComparableVersion.Item item) {
            if (item == null) {
                return ComparableVersion.IntegerItem.KDXECBIJNV.equals(CCCZHMLBLO) ? 0 : 1;// 1.0 == 1, 1.1 > 1

            }
            switch (item.getType()) {
                case ComparableVersion.Item.YUKFVGBRUV :
                    return CCCZHMLBLO.compareTo(((ComparableVersion.IntegerItem) (item)).CCCZHMLBLO);
                case ComparableVersion.Item.NOVHNNPGLE :
                    return 1;// 1.1 > 1-sp

                case ComparableVersion.Item.NWNXSXMEHG :
                    return 1;// 1.1 > 1-1

                default :
                    throw new RuntimeException("invalid item: " + item.getClass());
            }
        }

        public String toString() {
            return CCCZHMLBLO.toString();
        }
    }

    /**
     * Represents a string in the version item list, usually a qualifier.
     */
    private static class StringItem implements ComparableVersion.Item {
        private static final String[] FQIDPAAZGY = new String[]{ "alpha", "beta", "milestone", "rc", "snapshot", "", "sp" };

        private static final List<String> NHVSFNWKCK = Arrays.asList(ComparableVersion.StringItem.FQIDPAAZGY);

        private static final Properties DCIYBOKHGH = new Properties();

        static {
            ComparableVersion.StringItem.DCIYBOKHGH.put("ga", "");
            ComparableVersion.StringItem.DCIYBOKHGH.put("final", "");
            ComparableVersion.StringItem.DCIYBOKHGH.put("cr", "rc");
        }

        /**
         * A comparable value for the empty-string qualifier. This one is used to determine if a given qualifier makes
         * the version older than one without a qualifier, or more recent.
         */
        private static final String PYXSHLCCYO = String.valueOf(ComparableVersion.StringItem.NHVSFNWKCK.indexOf(""));

        private String PCBCAPDXKQ;

        public StringItem(String value, boolean followedByDigit) {
            if (followedByDigit && (value.length() == 1)) {
                // a1 = alpha-1, b1 = beta-1, m1 = milestone-1
                switch (value.charAt(0)) {
                    case 'a' :
                        value = "alpha";
                        break;
                    case 'b' :
                        value = "beta";
                        break;
                    case 'm' :
                        value = "milestone";
                        break;
                }
            }
            this.PCBCAPDXKQ = ComparableVersion.StringItem.DCIYBOKHGH.getProperty(value, value);
        }

        public int getType() {
            return ComparableVersion.Item.NOVHNNPGLE;
        }

        public boolean isNull() {
            return ComparableVersion.StringItem.comparableQualifier(PCBCAPDXKQ).compareTo(ComparableVersion.StringItem.PYXSHLCCYO) == 0;
        }

        /**
         * Returns a comparable value for a qualifier.
         *
         * This method takes into account the ordering of known qualifiers then unknown qualifiers with lexical ordering.
         *
         * just returning an Integer with the index here is faster, but requires a lot of if/then/else to check for -1
         * or QUALIFIERS.size and then resort to lexical ordering. Most comparisons are decided by the first character,
         * so this is still fast. If more characters are needed then it requires a lexical sort anyway.
         *
         * @param qualifier
         * 		
         * @return an equivalent value that can be used with lexical comparison
         */
        public static String comparableQualifier(String qualifier) {
            int i = ComparableVersion.StringItem.NHVSFNWKCK.indexOf(qualifier);
            return i == (-1) ? (ComparableVersion.StringItem.NHVSFNWKCK.size() + "-") + qualifier : String.valueOf(i);
        }

        public int compareTo(ComparableVersion.Item item) {
            if (item == null) {
                // 1-rc < 1, 1-ga > 1
                return ComparableVersion.StringItem.comparableQualifier(PCBCAPDXKQ).compareTo(ComparableVersion.StringItem.PYXSHLCCYO);
            }
            switch (item.getType()) {
                case ComparableVersion.Item.YUKFVGBRUV :
                    return -1;// 1.any < 1.1 ?

                case ComparableVersion.Item.NOVHNNPGLE :
                    return ComparableVersion.StringItem.comparableQualifier(PCBCAPDXKQ).compareTo(ComparableVersion.StringItem.comparableQualifier(((ComparableVersion.StringItem) (item)).PCBCAPDXKQ));
                case ComparableVersion.Item.NWNXSXMEHG :
                    return -1;// 1.any < 1-1

                default :
                    throw new RuntimeException("invalid item: " + item.getClass());
            }
        }

        public String toString() {
            return PCBCAPDXKQ;
        }
    }

    /**
     * Represents a version list item. This class is used both for the global item list and for sub-lists (which start
     * with '-(number)' in the version specification).
     */
    private static class ListItem extends ArrayList<ComparableVersion.Item> implements ComparableVersion.Item {
        public int getType() {
            return ComparableVersion.Item.NWNXSXMEHG;
        }

        public boolean isNull() {
            return size() == 0;
        }

        void normalize() {
            for (ListIterator<ComparableVersion.Item> iterator = listIterator(size()); iterator.hasPrevious();) {
                ComparableVersion.Item item = iterator.previous();
                if (item.isNull()) {
                    iterator.remove();// remove null trailing items: 0, "", empty list

                } else {
                    break;
                }
            }
        }

        public int compareTo(ComparableVersion.Item item) {
            if (item == null) {
                if (size() == 0) {
                    return 0;// 1-0 = 1- (normalize) = 1

                }
                ComparableVersion.Item first = get(0);
                return first.compareTo(null);
            }
            switch (item.getType()) {
                case ComparableVersion.Item.YUKFVGBRUV :
                    return -1;// 1-1 < 1.0.x

                case ComparableVersion.Item.NOVHNNPGLE :
                    return 1;// 1-1 > 1-sp

                case ComparableVersion.Item.NWNXSXMEHG :
                    Iterator<ComparableVersion.Item> left = iterator();
                    Iterator<ComparableVersion.Item> right = ((ComparableVersion.ListItem) (item)).iterator();
                    while (left.hasNext() || right.hasNext()) {
                        ComparableVersion.Item l = (left.hasNext()) ? left.next() : null;
                        ComparableVersion.Item r = (right.hasNext()) ? right.next() : null;
                        // if this is shorter, then invert the compare and mul with -1
                        int result = (l == null) ? (-1) * r.compareTo(l) : l.compareTo(r);
                        if (result != 0) {
                            return result;
                        }
                    } 
                    return 0;
                default :
                    throw new RuntimeException("invalid item: " + item.getClass());
            }
        }

        public String toString() {
            StringBuilder buffer = new StringBuilder("(");
            for (Iterator<ComparableVersion.Item> iter = iterator(); iter.hasNext();) {
                buffer.append(iter.next());
                if (iter.hasNext()) {
                    buffer.append(',');
                }
            }
            buffer.append(')');
            return buffer.toString();
        }
    }

    public ComparableVersion(String EOKQGYRYCS) {
        parseVersion(EOKQGYRYCS);
    }

    public final void parseVersion(String RTRFUQUUWD) {
        this.WWHTFTWEQG = RTRFUQUUWD;
        GHISSFYEOI = new ComparableVersion.ListItem();
        RTRFUQUUWD = RTRFUQUUWD.toLowerCase(Locale.ENGLISH);
        ComparableVersion.ListItem MQHTVHZKCJ = GHISSFYEOI;
        Stack<ComparableVersion.Item> NRDKLELCCJ = new Stack<ComparableVersion.Item>();
        NRDKLELCCJ.push(MQHTVHZKCJ);
        boolean FWQWIAUGOW = false;
        int UBHWLJSVWW = 0;
        for (int YCKUSYOJUD = 0; YCKUSYOJUD < RTRFUQUUWD.length(); YCKUSYOJUD++) {
            char GDANSPQPGN = RTRFUQUUWD.charAt(YCKUSYOJUD);
            if (GDANSPQPGN == '.') {
                if (YCKUSYOJUD == UBHWLJSVWW) {
                    MQHTVHZKCJ.add(ComparableVersion.IntegerItem.ZLNUUJMYUC);
                } else {
                    MQHTVHZKCJ.add(ComparableVersion.parseItem(FWQWIAUGOW, RTRFUQUUWD.substring(UBHWLJSVWW, YCKUSYOJUD)));
                }
                UBHWLJSVWW = YCKUSYOJUD + 1;
            } else
                if (GDANSPQPGN == '-') {
                    if (YCKUSYOJUD == UBHWLJSVWW) {
                        MQHTVHZKCJ.add(ComparableVersion.IntegerItem.ZLNUUJMYUC);
                    } else {
                        MQHTVHZKCJ.add(ComparableVersion.parseItem(FWQWIAUGOW, RTRFUQUUWD.substring(UBHWLJSVWW, YCKUSYOJUD)));
                    }
                    UBHWLJSVWW = YCKUSYOJUD + 1;
                    if (FWQWIAUGOW) {
                        MQHTVHZKCJ.normalize();// 1.0-* = 1-*

                        if (((YCKUSYOJUD + 1) < RTRFUQUUWD.length()) && Character.isDigit(RTRFUQUUWD.charAt(YCKUSYOJUD + 1))) {
                            // new ListItem only if previous were digits and new char is a digit,
                            // ie need to differentiate only 1.1 from 1-1
                            MQHTVHZKCJ.add(MQHTVHZKCJ = new ComparableVersion.ListItem());
                            NRDKLELCCJ.push(MQHTVHZKCJ);
                        }
                    }
                } else
                    if (Character.isDigit(GDANSPQPGN)) {
                        if ((!FWQWIAUGOW) && (YCKUSYOJUD > UBHWLJSVWW)) {
                            MQHTVHZKCJ.add(new ComparableVersion.StringItem(RTRFUQUUWD.substring(UBHWLJSVWW, YCKUSYOJUD), true));
                            UBHWLJSVWW = YCKUSYOJUD;
                        }
                        FWQWIAUGOW = true;
                    } else {
                        if (FWQWIAUGOW && (YCKUSYOJUD > UBHWLJSVWW)) {
                            MQHTVHZKCJ.add(ComparableVersion.parseItem(true, RTRFUQUUWD.substring(UBHWLJSVWW, YCKUSYOJUD)));
                            UBHWLJSVWW = YCKUSYOJUD;
                        }
                        FWQWIAUGOW = false;
                    }


        }
        if (RTRFUQUUWD.length() > UBHWLJSVWW) {
            MQHTVHZKCJ.add(ComparableVersion.parseItem(FWQWIAUGOW, RTRFUQUUWD.substring(UBHWLJSVWW)));
        }
        while (!NRDKLELCCJ.isEmpty()) {
            MQHTVHZKCJ = ((ComparableVersion.ListItem) (NRDKLELCCJ.pop()));
            MQHTVHZKCJ.normalize();
        } 
        MXYTZUXSSY = GHISSFYEOI.toString();
    }

    private static ComparableVersion.Item parseItem(boolean UCKQXRGRXY, String QYFIEFHIIS) {
        return UCKQXRGRXY ? new ComparableVersion.IntegerItem(QYFIEFHIIS) : new ComparableVersion.StringItem(QYFIEFHIIS, false);
    }

    public int compareTo(ComparableVersion LGFKCVMEVB) {
        return GHISSFYEOI.compareTo(LGFKCVMEVB.GHISSFYEOI);
    }

    public String toString() {
        return WWHTFTWEQG;
    }

    public boolean equals(Object AGSQJWUPBF) {
        return (AGSQJWUPBF instanceof ComparableVersion) && MXYTZUXSSY.equals(((ComparableVersion) (AGSQJWUPBF)).MXYTZUXSSY);
    }

    public int hashCode() {
        return MXYTZUXSSY.hashCode();
    }
}