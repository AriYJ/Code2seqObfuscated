/**
 * {@link JobHistoryParser} to parse job histories for hadoop 0.20 (META=1).
 */
public class Hadoop20JHParser implements JobHistoryParser {
    final LineReader MHWIGKIIXN;

    static final String ODFUZEGLSG = " .";

    static final int ZILSFXUFVS = 1;

    /**
     * Can this parser parse the input?
     *
     * @param input
     * 		
     * @return Whether this parser can parse the input.
     * @throws IOException
     * 		We will deem a stream to be a good 0.20 job history stream if the
     * 		first line is exactly "Meta VERSION=\"1\" ."
     */
    public static boolean canParse(InputStream TVVGGJFNTI) throws IOException {
        try {
            LineReader SIBAHSHEEZ = new LineReader(TVVGGJFNTI);
            Text JULVNKFIKY = new Text();
            return (SIBAHSHEEZ.readLine(JULVNKFIKY) != 0) && JULVNKFIKY.toString().equals("Meta VERSION=\"1\" .");
        } catch (EOFException e) {
            return false;
        }
    }

    public Hadoop20JHParser(InputStream VFUNKPZFGC) throws IOException {
        super();
        MHWIGKIIXN = new LineReader(VFUNKPZFGC);
    }

    public Hadoop20JHParser(LineReader ASWLXACRLL) throws IOException {
        super();
        this.MHWIGKIIXN = ASWLXACRLL;
    }

    Map<String, HistoryEventEmitter> TZPBSUPKDU = new HashMap<String, HistoryEventEmitter>();

    Queue<HistoryEvent> LLWMJIHOEJ = new LinkedList<HistoryEvent>();

    enum LineType {

        JOB("Job", "JOBID") {
            HistoryEventEmitter createEmitter() {
                return new Job20LineHistoryEventEmitter();
            }
        },
        TASK("Task", "TASKID") {
            HistoryEventEmitter createEmitter() {
                return new Task20LineHistoryEventEmitter();
            }
        },
        MAP_ATTEMPT("MapAttempt", "TASK_ATTEMPT_ID") {
            HistoryEventEmitter createEmitter() {
                return new MapAttempt20LineHistoryEventEmitter();
            }
        },
        REDUCE_ATTEMPT("ReduceAttempt", "TASK_ATTEMPT_ID") {
            HistoryEventEmitter createEmitter() {
                return new ReduceAttempt20LineHistoryEventEmitter();
            }
        };
        private LogRecordType BFDWMURPBC;

        private String NLHVTFDPHC;

        LineType(String s, String name) {
            BFDWMURPBC = LogRecordType.intern(s);
            this.NLHVTFDPHC = name;
        }

        LogRecordType recordType() {
            return BFDWMURPBC;
        }

        String getName(ParsedLine line) {
            return line.get(NLHVTFDPHC);
        }

        abstract HistoryEventEmitter createEmitter();

        static Hadoop20JHParser.LineType findLineType(LogRecordType lrt) {
            for (Hadoop20JHParser.LineType lt : Hadoop20JHParser.LineType.values()) {
                if (lt.BFDWMURPBC == lrt) {
                    return lt;
                }
            }
            return null;
        }
    }

    @Override
    public HistoryEvent nextEvent() {
        try {
            while (LLWMJIHOEJ.isEmpty()) {
                ParsedLine TVQHUWSFOF = new ParsedLine(getFullLine(), Hadoop20JHParser.ZILSFXUFVS);
                Hadoop20JHParser.LineType RFDJKZWWYR = Hadoop20JHParser.LineType.findLineType(TVQHUWSFOF.getType());
                if (RFDJKZWWYR == null) {
                    continue;
                }
                String ZIPCXSFNKA = RFDJKZWWYR.getName(TVQHUWSFOF);
                HistoryEventEmitter RYIRPEZSUJ = findOrMakeEmitter(ZIPCXSFNKA, RFDJKZWWYR);
                Pair<Queue<HistoryEvent>, HistoryEventEmitter.PostEmitAction> RHOSMMPJJO = RYIRPEZSUJ.emitterCore(TVQHUWSFOF, ZIPCXSFNKA);
                if (RHOSMMPJJO.second() == PostEmitAction.REMOVE_HEE) {
                    TZPBSUPKDU.remove(ZIPCXSFNKA);
                }
                LLWMJIHOEJ = RHOSMMPJJO.first();
            } 
            return LLWMJIHOEJ.poll();
        } catch (EOFException e) {
            return null;
        } catch (IOException e) {
            return null;
        }
    }

    HistoryEventEmitter findOrMakeEmitter(String ITQWZHYSGL, Hadoop20JHParser.LineType YRNPPTCJTW) {
        HistoryEventEmitter GRADEDBBFQ = TZPBSUPKDU.get(ITQWZHYSGL);
        if (GRADEDBBFQ == null) {
            GRADEDBBFQ = YRNPPTCJTW.createEmitter();
            TZPBSUPKDU.put(ITQWZHYSGL, GRADEDBBFQ);
        }
        return GRADEDBBFQ;
    }

    private String getOneLine() throws IOException {
        Text DASKNPJZKT = new Text();
        if (MHWIGKIIXN.readLine(DASKNPJZKT) == 0) {
            throw new EOFException("apparent bad line");
        }
        return DASKNPJZKT.toString();
    }

    private String getFullLine() throws IOException {
        String GWZTJDPZLI = getOneLine();
        while (GWZTJDPZLI.length() < Hadoop20JHParser.ODFUZEGLSG.length()) {
            GWZTJDPZLI = getOneLine();
        } 
        if (GWZTJDPZLI.endsWith(Hadoop20JHParser.ODFUZEGLSG)) {
            return GWZTJDPZLI;
        }
        StringBuilder RYKBTBXIBS = new StringBuilder(GWZTJDPZLI);
        String TWURCJTGTB;
        do {
            TWURCJTGTB = getOneLine();
            if (TWURCJTGTB == null) {
                return RYKBTBXIBS.toString();
            }
            RYKBTBXIBS.append("\n");
            RYKBTBXIBS.append(TWURCJTGTB);
        } while ((TWURCJTGTB.length() < Hadoop20JHParser.ODFUZEGLSG.length()) || (!Hadoop20JHParser.ODFUZEGLSG.equals(TWURCJTGTB.substring(TWURCJTGTB.length() - Hadoop20JHParser.ODFUZEGLSG.length()))) );
        return RYKBTBXIBS.toString();
    }

    @Override
    public void close() throws IOException {
        if (MHWIGKIIXN != null) {
            MHWIGKIIXN.close();
        }
    }
}