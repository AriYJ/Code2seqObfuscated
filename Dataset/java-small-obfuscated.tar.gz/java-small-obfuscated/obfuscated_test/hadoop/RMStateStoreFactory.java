public class RMStateStoreFactory {
    public static RMStateStore getStore(Configuration FDQDZGSEXW) {
        RMStateStore QNSERMRXXZ = ReflectionUtils.newInstance(FDQDZGSEXW.getClass(RM_STORE, MemoryRMStateStore.class, RMStateStore.class), FDQDZGSEXW);
        return QNSERMRXXZ;
    }
}