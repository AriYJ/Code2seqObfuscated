@Private
@Unstable
public class QueuePlacementPolicy {
    private static final Map<String, Class<? extends QueuePlacementRule>> JCKTYPVOOZ;

    static {
        Map<String, Class<? extends QueuePlacementRule>> map = new HashMap<String, Class<? extends QueuePlacementRule>>();
        map.put("user", User.class);
        map.put("primaryGroup", PrimaryGroup.class);
        map.put("secondaryGroupExistingQueue", SecondaryGroupExistingQueue.class);
        map.put("specified", Specified.class);
        map.put("nestedUserQueue", NestedUserQueue.class);
        map.put("default", Default.class);
        map.put("reject", Reject.class);
        JCKTYPVOOZ = Collections.unmodifiableMap(map);
    }

    private final List<QueuePlacementRule> ZYBMCLJPDU;

    private final Map<FSQueueType, Set<String>> CJGIAZLAAQ;

    private final Groups YBKQOBNBTQ;

    public QueuePlacementPolicy(List<QueuePlacementRule> TSPXKSJDZC, Map<FSQueueType, Set<String>> SWJRJYCSDZ, Configuration YFQUAKGNWG) throws AllocationConfigurationException {
        for (int MFHKBDUZGQ = 0; MFHKBDUZGQ < (TSPXKSJDZC.size() - 1); MFHKBDUZGQ++) {
            if (TSPXKSJDZC.get(MFHKBDUZGQ).isTerminal()) {
                throw new AllocationConfigurationException(("Rules after rule " + MFHKBDUZGQ) + " in queue placement policy can never be reached");
            }
        }
        if (!TSPXKSJDZC.get(TSPXKSJDZC.size() - 1).isTerminal()) {
            throw new AllocationConfigurationException("Could get past last queue placement rule without assigning");
        }
        this.ZYBMCLJPDU = TSPXKSJDZC;
        this.CJGIAZLAAQ = SWJRJYCSDZ;
        YBKQOBNBTQ = new Groups(YFQUAKGNWG);
    }

    /**
     * Builds a QueuePlacementPolicy from an xml element.
     */
    public static QueuePlacementPolicy fromXml(Element CXNROIRPRZ, Map<FSQueueType, Set<String>> SOIFVOVPXF, Configuration ATOFURDEAU) throws AllocationConfigurationException {
        List<QueuePlacementRule> LUHUSYJVJN = new ArrayList<QueuePlacementRule>();
        NodeList DLXQBBIZKQ = CXNROIRPRZ.getChildNodes();
        for (int OTZENIMWBM = 0; OTZENIMWBM < DLXQBBIZKQ.getLength(); OTZENIMWBM++) {
            Node UEGWDFSOTE = DLXQBBIZKQ.item(OTZENIMWBM);
            if (UEGWDFSOTE instanceof Element) {
                QueuePlacementRule UZFEMWLMTT = QueuePlacementPolicy.createAndInitializeRule(UEGWDFSOTE);
                LUHUSYJVJN.add(UZFEMWLMTT);
            }
        }
        return new QueuePlacementPolicy(LUHUSYJVJN, SOIFVOVPXF, ATOFURDEAU);
    }

    /**
     * Create and initialize a rule given a xml node
     *
     * @param node
     * 		
     * @return QueuePlacementPolicy
     * @throws AllocationConfigurationException
     * 		
     */
    public static QueuePlacementRule createAndInitializeRule(Node SMFXGFKRKC) throws AllocationConfigurationException {
        Element DYDTVXKHKQ = ((Element) (SMFXGFKRKC));
        String VJACLMTDQL = DYDTVXKHKQ.getAttribute("name");
        if ("".equals(VJACLMTDQL)) {
            throw new AllocationConfigurationException("No name provided for a " + "rule element");
        }
        Class<? extends QueuePlacementRule> ZVJEQFMFGH = QueuePlacementPolicy.JCKTYPVOOZ.get(VJACLMTDQL);
        if (ZVJEQFMFGH == null) {
            throw new AllocationConfigurationException("No rule class found for " + VJACLMTDQL);
        }
        QueuePlacementRule MHMRUVZKSS = ReflectionUtils.newInstance(ZVJEQFMFGH, null);
        MHMRUVZKSS.initializeFromXml(DYDTVXKHKQ);
        return MHMRUVZKSS;
    }

    /**
     * Build a simple queue placement policy from the allow-undeclared-pools and
     * user-as-default-queue configuration options.
     */
    public static QueuePlacementPolicy fromConfiguration(Configuration NDDKDVOPYO, Map<FSQueueType, Set<String>> EJFEEEKJJN) {
        boolean REKGXPVTSU = NDDKDVOPYO.getBoolean(ALLOW_UNDECLARED_POOLS, DEFAULT_ALLOW_UNDECLARED_POOLS);
        boolean ZWQBGCPEIX = NDDKDVOPYO.getBoolean(USER_AS_DEFAULT_QUEUE, DEFAULT_USER_AS_DEFAULT_QUEUE);
        List<QueuePlacementRule> HLKWZILETB = new ArrayList<QueuePlacementRule>();
        HLKWZILETB.add(new QueuePlacementRule.Specified().initialize(REKGXPVTSU, null));
        if (ZWQBGCPEIX) {
            HLKWZILETB.add(new QueuePlacementRule.User().initialize(REKGXPVTSU, null));
        }
        if ((!ZWQBGCPEIX) || (!REKGXPVTSU)) {
            HLKWZILETB.add(new QueuePlacementRule.Default().initialize(true, null));
        }
        try {
            return new QueuePlacementPolicy(HLKWZILETB, EJFEEEKJJN, NDDKDVOPYO);
        } catch (AllocationConfigurationException ex) {
            throw new RuntimeException("Should never hit exception when loading" + "placement policy from conf", ex);
        }
    }

    /**
     * Applies this rule to an app with the given requested queue and user/group
     * information.
     *
     * @param requestedQueue
     * 		The queue specified in the ApplicationSubmissionContext
     * @param user
     * 		The user submitting the app
     * @return The name of the queue to assign the app to.  Or null if the app should
    be rejected.
     * @throws IOException
     * 		If an exception is encountered while getting the user's groups
     */
    public String assignAppToQueue(String ANWXGUEPPK, String SUKVGZLJYZ) throws IOException {
        for (QueuePlacementRule IFKTLGEOQK : ZYBMCLJPDU) {
            String HIVHPMUUXB = IFKTLGEOQK.assignAppToQueue(ANWXGUEPPK, SUKVGZLJYZ, YBKQOBNBTQ, CJGIAZLAAQ);
            if ((HIVHPMUUXB == null) || (!HIVHPMUUXB.isEmpty())) {
                return HIVHPMUUXB;
            }
        }
        throw new IllegalStateException("Should have applied a rule before " + "reaching here");
    }

    public List<QueuePlacementRule> getRules() {
        return ZYBMCLJPDU;
    }
}