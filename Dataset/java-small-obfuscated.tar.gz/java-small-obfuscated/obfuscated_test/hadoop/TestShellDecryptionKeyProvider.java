public class TestShellDecryptionKeyProvider {
    public static final Log KOPYMJPJVZ = LogFactory.getLog(TestShellDecryptionKeyProvider.class);

    private static File PKQPAIGWRH = new File(System.getProperty("test.build.data", "/tmp"), "TestShellDecryptionKeyProvider");

    @Test
    public void testScriptPathNotSpecified() throws Exception {
        if (!Shell.WINDOWS) {
            return;
        }
        ShellDecryptionKeyProvider CCVKKPNCQC = new ShellDecryptionKeyProvider();
        Configuration BWWRWFJCJG = new Configuration();
        String MCNJEGDGGB = "testacct";
        String FRCFQOIFXC = "key";
        BWWRWFJCJG.set(SimpleKeyProvider.KEY_ACCOUNT_KEY_PREFIX + MCNJEGDGGB, FRCFQOIFXC);
        try {
            CCVKKPNCQC.getStorageAccountKey(MCNJEGDGGB, BWWRWFJCJG);
            Assert.fail("fs.azure.shellkeyprovider.script is not specified, we should throw");
        } catch (KeyProviderException e) {
            TestShellDecryptionKeyProvider.KOPYMJPJVZ.info("Received an expected exception: " + e.getMessage());
        }
    }

    @Test
    public void testValidScript() throws Exception {
        if (!Shell.WINDOWS) {
            return;
        }
        String UXRSDTZAHD = "decretedKey";
        // Create a simple script which echoes the given key plus the given
        // expected result (so that we validate both script input and output)
        File ZTGZDMPYBM = new File(TestShellDecryptionKeyProvider.PKQPAIGWRH, "testScript.cmd");
        FileUtils.writeStringToFile(ZTGZDMPYBM, "@echo %1 " + UXRSDTZAHD);
        ShellDecryptionKeyProvider XSPDCZNORV = new ShellDecryptionKeyProvider();
        Configuration ZMQDZOMOMU = new Configuration();
        String RLPAKMPTIA = "testacct";
        String LTKDODMPCF = "key1";
        ZMQDZOMOMU.set(SimpleKeyProvider.KEY_ACCOUNT_KEY_PREFIX + RLPAKMPTIA, LTKDODMPCF);
        ZMQDZOMOMU.set(KEY_ACCOUNT_SHELLKEYPROVIDER_SCRIPT, "cmd /c " + ZTGZDMPYBM.getAbsolutePath());
        String TNTPWJUYBS = XSPDCZNORV.getStorageAccountKey(RLPAKMPTIA, ZMQDZOMOMU);
        assertEquals((LTKDODMPCF + " ") + UXRSDTZAHD, TNTPWJUYBS);
    }
}