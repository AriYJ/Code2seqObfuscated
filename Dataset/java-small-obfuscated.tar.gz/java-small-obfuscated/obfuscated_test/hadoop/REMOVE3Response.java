/**
 * REMOVE3 Response
 */
public class REMOVE3Response extends NFS3Response {
    private WccData CDNJFZKGVS;

    public REMOVE3Response(int BODYCCQMMP) {
        this(BODYCCQMMP, null);
    }

    public REMOVE3Response(int JPDDQAVFRE, WccData LYBVKXZCYM) {
        super(JPDDQAVFRE);
        this.CDNJFZKGVS = LYBVKXZCYM;
    }

    @Override
    public XDR writeHeaderAndResponse(XDR XDQUPZHAUF, int WWJQGMILSR, Verifier JDXIMFHLXR) {
        super.writeHeaderAndResponse(XDQUPZHAUF, WWJQGMILSR, JDXIMFHLXR);
        if (CDNJFZKGVS == null) {
            CDNJFZKGVS = new WccData(null, null);
        }
        CDNJFZKGVS.serialize(XDQUPZHAUF);
        return XDQUPZHAUF;
    }
}