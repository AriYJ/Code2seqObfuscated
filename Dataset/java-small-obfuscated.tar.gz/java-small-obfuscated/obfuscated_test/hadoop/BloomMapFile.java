/**
 * This class extends {@link MapFile} and provides very much the same
 * functionality. However, it uses dynamic Bloom filters to provide
 * quick membership test for keys, and it offers a fast version of
 * {@link Reader#get(WritableComparable, Writable)} operation, especially in
 * case of sparsely populated MapFile-s.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class BloomMapFile {
    private static final Log CEIFPSSHZN = LogFactory.getLog(BloomMapFile.class);

    public static final String ITGKKKWJXB = "bloom";

    public static final int YBCVEKILZJ = 5;

    public static void delete(FileSystem FCGMIRANCI, String ZCPDMOBUBR) throws IOException {
        Path SJEXQNFDBB = new Path(ZCPDMOBUBR);
        Path LSKZNWEBWU = new Path(SJEXQNFDBB, MapFile.DATA_FILE_NAME);
        Path YQGBKYGHEE = new Path(SJEXQNFDBB, MapFile.INDEX_FILE_NAME);
        Path ONGTTYVMNE = new Path(SJEXQNFDBB, BloomMapFile.ITGKKKWJXB);
        FCGMIRANCI.delete(LSKZNWEBWU, true);
        FCGMIRANCI.delete(YQGBKYGHEE, true);
        FCGMIRANCI.delete(ONGTTYVMNE, true);
        FCGMIRANCI.delete(SJEXQNFDBB, true);
    }

    private static byte[] byteArrayForBloomKey(DataOutputBuffer JWMPUMSOAV) {
        int AWLJCQEYBY = JWMPUMSOAV.getLength();
        byte[] WGNPLRHQYN = JWMPUMSOAV.getData();
        if (AWLJCQEYBY != WGNPLRHQYN.length) {
            WGNPLRHQYN = new byte[AWLJCQEYBY];
            System.arraycopy(JWMPUMSOAV.getData(), 0, WGNPLRHQYN, 0, AWLJCQEYBY);
        }
        return WGNPLRHQYN;
    }

    public static class Writer extends MapFile.Writer {
        private DynamicBloomFilter HVALYLIVVO;

        private int ABRWSOIKYY;

        private int VANZOGGRBL;

        private Key LELHTCZBTS = new Key();

        private DataOutputBuffer KNHKREYOZD = new DataOutputBuffer();

        private FileSystem CHQPVRXNHM;

        private Path XQZDXZLJRZ;

        @Deprecated
        public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class<? extends Writable> valClass, CompressionType compress, CompressionCodec codec, Progressable progress) throws IOException {
            this(conf, new Path(dirName), keyClass(keyClass), valueClass(valClass), compression(compress, codec), progressable(progress));
        }

        @Deprecated
        public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass, CompressionType compress, Progressable progress) throws IOException {
            this(conf, new Path(dirName), keyClass(keyClass), valueClass(valClass), compression(compress), progressable(progress));
        }

        @Deprecated
        public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass, CompressionType compress) throws IOException {
            this(conf, new Path(dirName), keyClass(keyClass), valueClass(valClass), compression(compress));
        }

        @Deprecated
        public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, CompressionType compress, CompressionCodec codec, Progressable progress) throws IOException {
            this(conf, new Path(dirName), comparator(comparator), valueClass(valClass), compression(compress, codec), progressable(progress));
        }

        @Deprecated
        public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, CompressionType compress, Progressable progress) throws IOException {
            this(conf, new Path(dirName), comparator(comparator), valueClass(valClass), compression(compress), progressable(progress));
        }

        @Deprecated
        public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass, CompressionType compress) throws IOException {
            this(conf, new Path(dirName), comparator(comparator), valueClass(valClass), compression(compress));
        }

        @Deprecated
        public Writer(Configuration conf, FileSystem fs, String dirName, WritableComparator comparator, Class valClass) throws IOException {
            this(conf, new Path(dirName), comparator(comparator), valueClass(valClass));
        }

        @Deprecated
        public Writer(Configuration conf, FileSystem fs, String dirName, Class<? extends WritableComparable> keyClass, Class valClass) throws IOException {
            this(conf, new Path(dirName), keyClass(keyClass), valueClass(valClass));
        }

        public Writer(Configuration conf, Path dir, SequenceFile... options) throws IOException {
            super(conf, dir, options);
            this.CHQPVRXNHM = dir.getFileSystem(conf);
            this.XQZDXZLJRZ = dir;
            initBloomFilter(conf);
        }

        private synchronized void initBloomFilter(Configuration conf) {
            ABRWSOIKYY = conf.getInt("io.mapfile.bloom.size", 1024 * 1024);
            // vector size should be <code>-kn / (ln(1 - c^(1/k)))</code> bits for
            // single key, where <code> is the number of hash functions,
            // <code>n</code> is the number of keys and <code>c</code> is the desired
            // max. error rate.
            // Our desired error rate is by default 0.005, i.e. 0.5%
            float errorRate = conf.getFloat("io.mapfile.bloom.error.rate", 0.005F);
            VANZOGGRBL = ((int) (Math.ceil(((double) ((-BloomMapFile.YBCVEKILZJ) * ABRWSOIKYY)) / Math.log(1.0 - Math.pow(errorRate, 1.0 / BloomMapFile.YBCVEKILZJ)))));
            HVALYLIVVO = new DynamicBloomFilter(VANZOGGRBL, BloomMapFile.YBCVEKILZJ, Hash.getHashType(conf), ABRWSOIKYY);
        }

        @Override
        public synchronized void append(WritableComparable key, Writable val) throws IOException {
            super.append(key, val);
            KNHKREYOZD.reset();
            key.write(KNHKREYOZD);
            LELHTCZBTS.set(BloomMapFile.byteArrayForBloomKey(KNHKREYOZD), 1.0);
            HVALYLIVVO.add(LELHTCZBTS);
        }

        @Override
        public synchronized void close() throws IOException {
            super.close();
            DataOutputStream out = CHQPVRXNHM.create(new Path(XQZDXZLJRZ, BloomMapFile.ITGKKKWJXB), true);
            try {
                HVALYLIVVO.write(out);
                out.flush();
                out.close();
                out = null;
            } finally {
                IOUtils.closeStream(out);
            }
        }
    }

    public static class Reader extends MapFile.Reader {
        private DynamicBloomFilter GYRQFKSGKD;

        private DataOutputBuffer YAIHDIAXBF = new DataOutputBuffer();

        private Key MUIABFGPYX = new Key();

        public Reader(Path dir, Configuration conf, SequenceFile... options) throws IOException {
            super(dir, conf, options);
            initBloomFilter(dir, conf);
        }

        @Deprecated
        public Reader(FileSystem fs, String dirName, Configuration conf) throws IOException {
            this(new Path(dirName), conf);
        }

        @Deprecated
        public Reader(FileSystem fs, String dirName, WritableComparator comparator, Configuration conf, boolean open) throws IOException {
            this(new Path(dirName), conf, comparator(comparator));
        }

        @Deprecated
        public Reader(FileSystem fs, String dirName, WritableComparator comparator, Configuration conf) throws IOException {
            this(new Path(dirName), conf, comparator(comparator));
        }

        private void initBloomFilter(Path dirName, Configuration conf) {
            DataInputStream in = null;
            try {
                FileSystem fs = dirName.getFileSystem(conf);
                in = fs.open(new Path(dirName, BloomMapFile.ITGKKKWJXB));
                GYRQFKSGKD = new DynamicBloomFilter();
                GYRQFKSGKD.readFields(in);
                in.close();
                in = null;
            } catch (IOException ioe) {
                BloomMapFile.CEIFPSSHZN.warn(("Can't open BloomFilter: " + ioe) + " - fallback to MapFile.");
                GYRQFKSGKD = null;
            } finally {
                IOUtils.closeStream(in);
            }
        }

        /**
         * Checks if this MapFile has the indicated key. The membership test is
         * performed using a Bloom filter, so the result has always non-zero
         * probability of false positives.
         *
         * @param key
         * 		key to check
         * @return false iff key doesn't exist, true if key probably exists.
         * @throws IOException
         * 		
         */
        public boolean probablyHasKey(WritableComparable key) throws IOException {
            if (GYRQFKSGKD == null) {
                return true;
            }
            YAIHDIAXBF.reset();
            key.write(YAIHDIAXBF);
            MUIABFGPYX.set(BloomMapFile.byteArrayForBloomKey(YAIHDIAXBF), 1.0);
            return GYRQFKSGKD.membershipTest(MUIABFGPYX);
        }

        /**
         * Fast version of the
         * {@link MapFile.Reader#get(WritableComparable, Writable)} method. First
         * it checks the Bloom filter for the existence of the key, and only if
         * present it performs the real get operation. This yields significant
         * performance improvements for get operations on sparsely populated files.
         */
        @Override
        public synchronized Writable get(WritableComparable key, Writable val) throws IOException {
            if (!probablyHasKey(key)) {
                return null;
            }
            return super.get(key, val);
        }

        /**
         * Retrieve the Bloom filter used by this instance of the Reader.
         *
         * @return a Bloom filter (see {@link Filter})
         */
        public Filter getBloomFilter() {
            return GYRQFKSGKD;
        }
    }
}