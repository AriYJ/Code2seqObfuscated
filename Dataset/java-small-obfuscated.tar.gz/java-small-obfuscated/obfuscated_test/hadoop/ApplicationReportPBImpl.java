@Private
@Unstable
public class ApplicationReportPBImpl extends ApplicationReport {
    ApplicationReportProto OQXAABVDMW = ApplicationReportProto.getDefaultInstance();

    Builder LCLIUACMHC = null;

    boolean HJXSWQDMIS = false;

    private ApplicationId VSPKWMXSFQ;

    private ApplicationAttemptId BYJIFVNOYU;

    private Token KSAZYGTGWN = null;

    private Token PHMJIQPSCU = null;

    private Set<String> LKIDGEKJLE = null;

    public ApplicationReportPBImpl() {
        LCLIUACMHC = ApplicationReportProto.newBuilder();
    }

    public ApplicationReportPBImpl(ApplicationReportProto OGILBHKVXH) {
        this.OQXAABVDMW = OGILBHKVXH;
        HJXSWQDMIS = true;
    }

    @Override
    public ApplicationId getApplicationId() {
        if (this.VSPKWMXSFQ != null) {
            return this.VSPKWMXSFQ;
        }
        ApplicationReportProtoOrBuilder NKSZRWMENM = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!NKSZRWMENM.hasApplicationId()) {
            return null;
        }
        this.VSPKWMXSFQ = convertFromProtoFormat(NKSZRWMENM.getApplicationId());
        return this.VSPKWMXSFQ;
    }

    public void setApplicationResourceUsageReport(ApplicationResourceUsageReport QXMYHIMCVQ) {
        maybeInitBuilder();
        if (QXMYHIMCVQ == null) {
            LCLIUACMHC.clearAppResourceUsage();
            return;
        }
        LCLIUACMHC.setAppResourceUsage(convertToProtoFormat(QXMYHIMCVQ));
    }

    @Override
    public ApplicationAttemptId getCurrentApplicationAttemptId() {
        if (this.BYJIFVNOYU != null) {
            return this.BYJIFVNOYU;
        }
        ApplicationReportProtoOrBuilder JDXCDJDVHE = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!JDXCDJDVHE.hasCurrentApplicationAttemptId()) {
            return null;
        }
        this.BYJIFVNOYU = convertFromProtoFormat(JDXCDJDVHE.getCurrentApplicationAttemptId());
        return this.BYJIFVNOYU;
    }

    @Override
    public ApplicationResourceUsageReport getApplicationResourceUsageReport() {
        ApplicationReportProtoOrBuilder XADLCZYHWR = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!XADLCZYHWR.hasAppResourceUsage()) {
            return null;
        }
        return convertFromProtoFormat(XADLCZYHWR.getAppResourceUsage());
    }

    @Override
    public String getTrackingUrl() {
        ApplicationReportProtoOrBuilder VWRMTVUEDZ = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!VWRMTVUEDZ.hasTrackingUrl()) {
            return null;
        }
        return VWRMTVUEDZ.getTrackingUrl();
    }

    @Override
    public String getOriginalTrackingUrl() {
        ApplicationReportProtoOrBuilder SSIEHQZCCA = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!SSIEHQZCCA.hasOriginalTrackingUrl()) {
            return null;
        }
        return SSIEHQZCCA.getOriginalTrackingUrl();
    }

    @Override
    public String getName() {
        ApplicationReportProtoOrBuilder XJWKKIUTFH = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!XJWKKIUTFH.hasName()) {
            return null;
        }
        return XJWKKIUTFH.getName();
    }

    @Override
    public String getQueue() {
        ApplicationReportProtoOrBuilder JOXRPTAPIP = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!JOXRPTAPIP.hasQueue()) {
            return null;
        }
        return JOXRPTAPIP.getQueue();
    }

    @Override
    public YarnApplicationState getYarnApplicationState() {
        ApplicationReportProtoOrBuilder DJUISKJDML = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!DJUISKJDML.hasYarnApplicationState()) {
            return null;
        }
        return convertFromProtoFormat(DJUISKJDML.getYarnApplicationState());
    }

    @Override
    public String getHost() {
        ApplicationReportProtoOrBuilder RMBYVZNQEF = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!RMBYVZNQEF.hasHost()) {
            return null;
        }
        return RMBYVZNQEF.getHost();
    }

    @Override
    public int getRpcPort() {
        ApplicationReportProtoOrBuilder OFMBXEDVOB = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        return OFMBXEDVOB.getRpcPort();
    }

    @Override
    public Token getClientToAMToken() {
        ApplicationReportProtoOrBuilder OJPYUZDMIR = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (this.KSAZYGTGWN != null) {
            return this.KSAZYGTGWN;
        }
        if (!OJPYUZDMIR.hasClientToAmToken()) {
            return null;
        }
        this.KSAZYGTGWN = convertFromProtoFormat(OJPYUZDMIR.getClientToAmToken());
        return this.KSAZYGTGWN;
    }

    @Override
    public String getUser() {
        ApplicationReportProtoOrBuilder JDWHNNVMVG = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!JDWHNNVMVG.hasUser()) {
            return null;
        }
        return JDWHNNVMVG.getUser();
    }

    @Override
    public String getDiagnostics() {
        ApplicationReportProtoOrBuilder HEXENKCKTX = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!HEXENKCKTX.hasDiagnostics()) {
            return null;
        }
        return HEXENKCKTX.getDiagnostics();
    }

    @Override
    public long getStartTime() {
        ApplicationReportProtoOrBuilder OGOZRXVEUF = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        return OGOZRXVEUF.getStartTime();
    }

    @Override
    public long getFinishTime() {
        ApplicationReportProtoOrBuilder TVHPFIJQLX = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        return TVHPFIJQLX.getFinishTime();
    }

    @Override
    public FinalApplicationStatus getFinalApplicationStatus() {
        ApplicationReportProtoOrBuilder LLXFWUKCSO = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!LLXFWUKCSO.hasFinalApplicationStatus()) {
            return null;
        }
        return convertFromProtoFormat(LLXFWUKCSO.getFinalApplicationStatus());
    }

    @Override
    public float getProgress() {
        ApplicationReportProtoOrBuilder UCTILFRKKM = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        return UCTILFRKKM.getProgress();
    }

    @Override
    public String getApplicationType() {
        ApplicationReportProtoOrBuilder DGCVGZUEOX = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (!DGCVGZUEOX.hasApplicationType()) {
            return null;
        }
        return DGCVGZUEOX.getApplicationType();
    }

    @Override
    public Token getAMRMToken() {
        ApplicationReportProtoOrBuilder XENDVYOAWW = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        if (PHMJIQPSCU != null) {
            return PHMJIQPSCU;
        }
        if (!XENDVYOAWW.hasAmRmToken()) {
            return null;
        }
        PHMJIQPSCU = convertFromProtoFormat(XENDVYOAWW.getAmRmToken());
        return PHMJIQPSCU;
    }

    private void initApplicationTags() {
        if (this.LKIDGEKJLE != null) {
            return;
        }
        ApplicationReportProtoOrBuilder ASFIXFWNOT = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC;
        this.LKIDGEKJLE = new HashSet<String>();
        this.LKIDGEKJLE.addAll(ASFIXFWNOT.getApplicationTagsList());
    }

    @Override
    public Set<String> getApplicationTags() {
        initApplicationTags();
        return this.LKIDGEKJLE;
    }

    @Override
    public void setApplicationId(ApplicationId ARDDNZTQWP) {
        maybeInitBuilder();
        if (ARDDNZTQWP == null)
            LCLIUACMHC.clearApplicationId();

        this.VSPKWMXSFQ = ARDDNZTQWP;
    }

    @Override
    public void setCurrentApplicationAttemptId(ApplicationAttemptId GUEOZAFIXO) {
        maybeInitBuilder();
        if (GUEOZAFIXO == null)
            LCLIUACMHC.clearCurrentApplicationAttemptId();

        this.BYJIFVNOYU = GUEOZAFIXO;
    }

    @Override
    public void setTrackingUrl(String LLZWTOVKLO) {
        maybeInitBuilder();
        if (LLZWTOVKLO == null) {
            LCLIUACMHC.clearTrackingUrl();
            return;
        }
        LCLIUACMHC.setTrackingUrl(LLZWTOVKLO);
    }

    @Override
    public void setOriginalTrackingUrl(String PYGZUJDCJB) {
        maybeInitBuilder();
        if (PYGZUJDCJB == null) {
            LCLIUACMHC.clearOriginalTrackingUrl();
            return;
        }
        LCLIUACMHC.setOriginalTrackingUrl(PYGZUJDCJB);
    }

    @Override
    public void setName(String MVCBHQJKOQ) {
        maybeInitBuilder();
        if (MVCBHQJKOQ == null) {
            LCLIUACMHC.clearName();
            return;
        }
        LCLIUACMHC.setName(MVCBHQJKOQ);
    }

    @Override
    public void setQueue(String LSPVMKYJEC) {
        maybeInitBuilder();
        if (LSPVMKYJEC == null) {
            LCLIUACMHC.clearQueue();
            return;
        }
        LCLIUACMHC.setQueue(LSPVMKYJEC);
    }

    @Override
    public void setYarnApplicationState(YarnApplicationState RFBEIYLDFN) {
        maybeInitBuilder();
        if (RFBEIYLDFN == null) {
            LCLIUACMHC.clearYarnApplicationState();
            return;
        }
        LCLIUACMHC.setYarnApplicationState(convertToProtoFormat(RFBEIYLDFN));
    }

    @Override
    public void setHost(String NGTHBQSGKU) {
        maybeInitBuilder();
        if (NGTHBQSGKU == null) {
            LCLIUACMHC.clearHost();
            return;
        }
        LCLIUACMHC.setHost(NGTHBQSGKU);
    }

    @Override
    public void setRpcPort(int MERSPMTKWN) {
        maybeInitBuilder();
        LCLIUACMHC.setRpcPort(MERSPMTKWN);
    }

    @Override
    public void setClientToAMToken(Token WMNWFTDYOA) {
        maybeInitBuilder();
        if (WMNWFTDYOA == null)
            LCLIUACMHC.clearClientToAmToken();

        this.KSAZYGTGWN = WMNWFTDYOA;
    }

    @Override
    public void setUser(String HLKRYAYDRJ) {
        maybeInitBuilder();
        if (HLKRYAYDRJ == null) {
            LCLIUACMHC.clearUser();
            return;
        }
        LCLIUACMHC.setUser(HLKRYAYDRJ);
    }

    @Override
    public void setApplicationType(String WWJGFYCLJG) {
        maybeInitBuilder();
        if (WWJGFYCLJG == null) {
            LCLIUACMHC.clearApplicationType();
            return;
        }
        LCLIUACMHC.setApplicationType(WWJGFYCLJG);
    }

    @Override
    public void setApplicationTags(Set<String> YPURPUIEHY) {
        maybeInitBuilder();
        if ((YPURPUIEHY == null) || YPURPUIEHY.isEmpty()) {
            LCLIUACMHC.clearApplicationTags();
        }
        this.LKIDGEKJLE = YPURPUIEHY;
    }

    @Override
    public void setDiagnostics(String TMGTMXDFYV) {
        maybeInitBuilder();
        if (TMGTMXDFYV == null) {
            LCLIUACMHC.clearDiagnostics();
            return;
        }
        LCLIUACMHC.setDiagnostics(TMGTMXDFYV);
    }

    @Override
    public void setStartTime(long GZQJFXSPZK) {
        maybeInitBuilder();
        LCLIUACMHC.setStartTime(GZQJFXSPZK);
    }

    @Override
    public void setFinishTime(long HYIZFFUFUN) {
        maybeInitBuilder();
        LCLIUACMHC.setFinishTime(HYIZFFUFUN);
    }

    @Override
    public void setFinalApplicationStatus(FinalApplicationStatus QKMPPRJWMI) {
        maybeInitBuilder();
        if (QKMPPRJWMI == null) {
            LCLIUACMHC.clearFinalApplicationStatus();
            return;
        }
        LCLIUACMHC.setFinalApplicationStatus(convertToProtoFormat(QKMPPRJWMI));
    }

    @Override
    public void setProgress(float OXHEPUNTDY) {
        maybeInitBuilder();
        LCLIUACMHC.setProgress(OXHEPUNTDY);
    }

    @Override
    public void setAMRMToken(Token UPLLKFLGUQ) {
        maybeInitBuilder();
        if (UPLLKFLGUQ == null) {
            LCLIUACMHC.clearAmRmToken();
        }
        this.PHMJIQPSCU = UPLLKFLGUQ;
    }

    public ApplicationReportProto getProto() {
        mergeLocalToProto();
        OQXAABVDMW = (HJXSWQDMIS) ? OQXAABVDMW : LCLIUACMHC.build();
        HJXSWQDMIS = true;
        return OQXAABVDMW;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object JCXSQYHFSS) {
        if (JCXSQYHFSS == null)
            return false;

        if (JCXSQYHFSS.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(JCXSQYHFSS).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }

    private void mergeLocalToBuilder() {
        if ((this.VSPKWMXSFQ != null) && (!((ApplicationIdPBImpl) (this.VSPKWMXSFQ)).getProto().equals(LCLIUACMHC.getApplicationId()))) {
            LCLIUACMHC.setApplicationId(convertToProtoFormat(this.VSPKWMXSFQ));
        }
        if ((this.BYJIFVNOYU != null) && (!((ApplicationAttemptIdPBImpl) (this.BYJIFVNOYU)).getProto().equals(LCLIUACMHC.getCurrentApplicationAttemptId()))) {
            LCLIUACMHC.setCurrentApplicationAttemptId(convertToProtoFormat(this.BYJIFVNOYU));
        }
        if ((this.KSAZYGTGWN != null) && (!((TokenPBImpl) (this.KSAZYGTGWN)).getProto().equals(LCLIUACMHC.getClientToAmToken()))) {
            LCLIUACMHC.setClientToAmToken(convertToProtoFormat(this.KSAZYGTGWN));
        }
        if ((this.PHMJIQPSCU != null) && (!((TokenPBImpl) (this.PHMJIQPSCU)).getProto().equals(LCLIUACMHC.getAmRmToken()))) {
            LCLIUACMHC.setAmRmToken(convertToProtoFormat(this.PHMJIQPSCU));
        }
        if ((this.LKIDGEKJLE != null) && (!this.LKIDGEKJLE.isEmpty())) {
            LCLIUACMHC.clearApplicationTags();
            LCLIUACMHC.addAllApplicationTags(this.LKIDGEKJLE);
        }
    }

    private void mergeLocalToProto() {
        if (HJXSWQDMIS)
            maybeInitBuilder();

        mergeLocalToBuilder();
        OQXAABVDMW = LCLIUACMHC.build();
        HJXSWQDMIS = true;
    }

    private void maybeInitBuilder() {
        if (HJXSWQDMIS || (LCLIUACMHC == null)) {
            LCLIUACMHC = ApplicationReportProto.newBuilder(OQXAABVDMW);
        }
        HJXSWQDMIS = false;
    }

    private ApplicationIdProto convertToProtoFormat(ApplicationId NFDBDKXKLP) {
        return ((ApplicationIdPBImpl) (NFDBDKXKLP)).getProto();
    }

    private ApplicationAttemptIdProto convertToProtoFormat(ApplicationAttemptId LFYLUUAAPW) {
        return ((ApplicationAttemptIdPBImpl) (LFYLUUAAPW)).getProto();
    }

    private ApplicationResourceUsageReport convertFromProtoFormat(ApplicationResourceUsageReportProto TIJPTPOCPR) {
        return ProtoUtils.convertFromProtoFormat(TIJPTPOCPR);
    }

    private ApplicationResourceUsageReportProto convertToProtoFormat(ApplicationResourceUsageReport HJIDMIFQQB) {
        return ProtoUtils.convertToProtoFormat(HJIDMIFQQB);
    }

    private ApplicationIdPBImpl convertFromProtoFormat(ApplicationIdProto GARMVGCDMJ) {
        return new ApplicationIdPBImpl(GARMVGCDMJ);
    }

    private ApplicationAttemptIdPBImpl convertFromProtoFormat(ApplicationAttemptIdProto PGRVBGUUAE) {
        return new ApplicationAttemptIdPBImpl(PGRVBGUUAE);
    }

    private YarnApplicationState convertFromProtoFormat(YarnApplicationStateProto BNKWZSHRFN) {
        return ProtoUtils.convertFromProtoFormat(BNKWZSHRFN);
    }

    private YarnApplicationStateProto convertToProtoFormat(YarnApplicationState WIBPYDRQOU) {
        return ProtoUtils.convertToProtoFormat(WIBPYDRQOU);
    }

    private FinalApplicationStatus convertFromProtoFormat(FinalApplicationStatusProto LVQTHALWGV) {
        return ProtoUtils.convertFromProtoFormat(LVQTHALWGV);
    }

    private FinalApplicationStatusProto convertToProtoFormat(FinalApplicationStatus AOCCJEAOSJ) {
        return ProtoUtils.convertToProtoFormat(AOCCJEAOSJ);
    }

    private TokenPBImpl convertFromProtoFormat(TokenProto REHPMDJJLA) {
        return new TokenPBImpl(REHPMDJJLA);
    }

    private TokenProto convertToProtoFormat(Token SOHHRXUXGJ) {
        return ((TokenPBImpl) (SOHHRXUXGJ)).getProto();
    }
}