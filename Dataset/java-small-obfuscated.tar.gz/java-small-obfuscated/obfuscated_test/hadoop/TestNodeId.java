public class TestNodeId {
    @Test
    public void testNodeId() {
        NodeId VSASFQYZFD = NodeId.newInstance("10.18.52.124", 8041);
        NodeId UTFJQFWLGA = NodeId.newInstance("10.18.52.125", 8038);
        NodeId NKCEKYQUTA = NodeId.newInstance("10.18.52.124", 8041);
        NodeId YWRRPYOAPO = NodeId.newInstance("10.18.52.124", 8039);
        Assert.assertTrue(VSASFQYZFD.equals(NKCEKYQUTA));
        Assert.assertFalse(VSASFQYZFD.equals(UTFJQFWLGA));
        Assert.assertFalse(NKCEKYQUTA.equals(YWRRPYOAPO));
        Assert.assertTrue(VSASFQYZFD.compareTo(NKCEKYQUTA) == 0);
        Assert.assertTrue(VSASFQYZFD.compareTo(UTFJQFWLGA) < 0);
        Assert.assertTrue(NKCEKYQUTA.compareTo(YWRRPYOAPO) > 0);
        Assert.assertTrue(VSASFQYZFD.hashCode() == NKCEKYQUTA.hashCode());
        Assert.assertFalse(VSASFQYZFD.hashCode() == UTFJQFWLGA.hashCode());
        Assert.assertFalse(NKCEKYQUTA.hashCode() == YWRRPYOAPO.hashCode());
        Assert.assertEquals("10.18.52.124:8041", VSASFQYZFD.toString());
    }
}