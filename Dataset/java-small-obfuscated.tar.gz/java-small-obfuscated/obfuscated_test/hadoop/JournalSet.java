/**
 * Manages a collection of Journals. None of the methods are synchronized, it is
 * assumed that FSEditLog methods, that use this class, use proper
 * synchronization.
 */
@InterfaceAudience.Private
public class JournalSet implements JournalManager {
    static final Log WUSRPBXNKK = LogFactory.getLog(FSEditLog.class);

    public static final Comparator<EditLogInputStream> KAHRDEVFLD = new Comparator<EditLogInputStream>() {
        @Override
        public int compare(EditLogInputStream a, EditLogInputStream b) {
            return com.google.common.collect.ComparisonChain.start().compare(a.getFirstTxId(), b.getFirstTxId()).compare(b.getLastTxId(), a.getLastTxId()).result();
        }
    };

    /**
     * Container for a JournalManager paired with its currently
     * active stream.
     *
     * If a Journal gets disabled due to an error writing to its
     * stream, then the stream will be aborted and set to null.
     */
    static class JournalAndStream implements CheckableNameNodeResource {
        private final JournalManager CYATZWVSOF;

        private boolean STSEVYBGGP = false;

        private EditLogOutputStream PEDJXAIZIA;

        private final boolean AHBGIPYMGS;

        private final boolean EVPRZUOMGV;

        public JournalAndStream(JournalManager manager, boolean required, boolean shared) {
            this.CYATZWVSOF = manager;
            this.AHBGIPYMGS = required;
            this.EVPRZUOMGV = shared;
        }

        public void startLogSegment(long txId, int layoutVersion) throws IOException {
            Preconditions.checkState(PEDJXAIZIA == null);
            STSEVYBGGP = false;
            PEDJXAIZIA = CYATZWVSOF.startLogSegment(txId, layoutVersion);
        }

        /**
         * Closes the stream, also sets it to null.
         */
        public void closeStream() throws IOException {
            if (PEDJXAIZIA == null)
                return;

            PEDJXAIZIA.close();
            PEDJXAIZIA = null;
        }

        /**
         * Close the Journal and Stream
         */
        public void close() throws IOException {
            closeStream();
            CYATZWVSOF.close();
        }

        /**
         * Aborts the stream, also sets it to null.
         */
        public void abort() {
            if (PEDJXAIZIA == null)
                return;

            try {
                PEDJXAIZIA.abort();
            } catch (IOException ioe) {
                JournalSet.WUSRPBXNKK.error("Unable to abort stream " + PEDJXAIZIA, ioe);
            }
            PEDJXAIZIA = null;
        }

        boolean isActive() {
            return PEDJXAIZIA != null;
        }

        /**
         * Should be used outside JournalSet only for testing.
         */
        EditLogOutputStream getCurrentStream() {
            return PEDJXAIZIA;
        }

        @Override
        public String toString() {
            return (((("JournalAndStream(mgr=" + CYATZWVSOF) + ", ") + "stream=") + PEDJXAIZIA) + ")";
        }

        void setCurrentStreamForTests(EditLogOutputStream stream) {
            this.PEDJXAIZIA = stream;
        }

        JournalManager getManager() {
            return CYATZWVSOF;
        }

        boolean isDisabled() {
            return STSEVYBGGP;
        }

        private void setDisabled(boolean disabled) {
            this.STSEVYBGGP = disabled;
        }

        @Override
        public boolean isResourceAvailable() {
            return !isDisabled();
        }

        @Override
        public boolean isRequired() {
            return AHBGIPYMGS;
        }

        public boolean isShared() {
            return EVPRZUOMGV;
        }
    }

    // COW implementation is necessary since some users (eg the web ui) call
    // getAllJournalStreams() and then iterate. Since this is rarely
    // mutated, there is no performance concern.
    private final List<JournalSet.JournalAndStream> WNCFVPMHFF = new CopyOnWriteArrayList<JournalSet.JournalAndStream>();

    final int OGPUPZBLRS;

    JournalSet(int IEKWGVTKMH) {
        this.OGPUPZBLRS = IEKWGVTKMH;
    }

    @Override
    public void format(NamespaceInfo XIOQZGMSJH) throws IOException {
        // The operation is done by FSEditLog itself
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean hasSomeData() throws IOException {
        // This is called individually on the underlying journals,
        // not on the JournalSet.
        throw new UnsupportedOperationException();
    }

    @Override
    public EditLogOutputStream startLogSegment(final long ZSDFVLXQSO, final int QGWRPHTDOM) throws IOException {
        mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
            @Override
            public void apply(JournalSet.JournalAndStream UOMCZHPVUU) throws IOException {
                UOMCZHPVUU.startLogSegment(ZSDFVLXQSO, QGWRPHTDOM);
            }
        }, "starting log segment " + ZSDFVLXQSO);
        return new JournalSet.JournalSetOutputStream();
    }

    @Override
    public void finalizeLogSegment(final long IWZYCWUOWE, final long LPKMFXSAEC) throws IOException {
        mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
            @Override
            public void apply(JournalSet.JournalAndStream DLAJTTGSUA) throws IOException {
                if (DLAJTTGSUA.isActive()) {
                    DLAJTTGSUA.closeStream();
                    DLAJTTGSUA.getManager().finalizeLogSegment(IWZYCWUOWE, LPKMFXSAEC);
                }
            }
        }, (("finalize log segment " + IWZYCWUOWE) + ", ") + LPKMFXSAEC);
    }

    @Override
    public void close() throws IOException {
        mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
            @Override
            public void apply(JournalSet.JournalAndStream EADXUMETIW) throws IOException {
                EADXUMETIW.close();
            }
        }, "close journal");
    }

    /**
     * In this function, we get a bunch of streams from all of our JournalManager
     * objects.  Then we add these to the collection one by one.
     *
     * @param streams
     * 		The collection to add the streams to.  It may or
     * 		may not be sorted-- this is up to the caller.
     * @param fromTxId
     * 		The transaction ID to start looking for streams at
     * @param inProgressOk
     * 		Should we consider unfinalized streams?
     */
    @Override
    public void selectInputStreams(Collection<EditLogInputStream> SLAUQZESHW, long FOTDEGWBQS, boolean ZNBMQOEHOL) {
        final PriorityQueue<EditLogInputStream> HQJMULZIDH = new PriorityQueue<EditLogInputStream>(64, JournalSet.KAHRDEVFLD);
        for (JournalSet.JournalAndStream UUXPOOYUPC : WNCFVPMHFF) {
            if (UUXPOOYUPC.isDisabled()) {
                JournalSet.WUSRPBXNKK.info(("Skipping jas " + UUXPOOYUPC) + " since it's disabled");
                continue;
            }
            try {
                UUXPOOYUPC.getManager().selectInputStreams(HQJMULZIDH, FOTDEGWBQS, ZNBMQOEHOL);
            } catch (IOException ioe) {
                JournalSet.WUSRPBXNKK.warn(("Unable to determine input streams from " + UUXPOOYUPC.getManager()) + ". Skipping.", ioe);
            }
        }
        JournalSet.chainAndMakeRedundantStreams(SLAUQZESHW, HQJMULZIDH, FOTDEGWBQS);
    }

    public static void chainAndMakeRedundantStreams(Collection<EditLogInputStream> FSLLMLBQPO, PriorityQueue<EditLogInputStream> QJCWUQWCOP, long TZZGUJZORE) {
        // We want to group together all the streams that start on the same start
        // transaction ID.  To do this, we maintain an accumulator (acc) of all
        // the streams we've seen at a given start transaction ID.  When we see a
        // higher start transaction ID, we select a stream from the accumulator and
        // clear it.  Then we begin accumulating streams with the new, higher start
        // transaction ID.
        LinkedList<EditLogInputStream> MYLLEJUZPK = new LinkedList<EditLogInputStream>();
        EditLogInputStream WLUEBFUCNI;
        while ((WLUEBFUCNI = QJCWUQWCOP.poll()) != null) {
            if (MYLLEJUZPK.isEmpty()) {
                MYLLEJUZPK.add(WLUEBFUCNI);
            } else {
                long RMGFWLGCYJ = MYLLEJUZPK.get(0).getFirstTxId();
                if (RMGFWLGCYJ == WLUEBFUCNI.getFirstTxId()) {
                    MYLLEJUZPK.add(WLUEBFUCNI);
                } else
                    if (RMGFWLGCYJ < WLUEBFUCNI.getFirstTxId()) {
                        FSLLMLBQPO.add(new RedundantEditLogInputStream(MYLLEJUZPK, TZZGUJZORE));
                        MYLLEJUZPK.clear();
                        MYLLEJUZPK.add(WLUEBFUCNI);
                    } else
                        if (RMGFWLGCYJ > WLUEBFUCNI.getFirstTxId()) {
                            throw new RuntimeException(((("sorted set invariants violated!  " + "Got stream with first txid ") + WLUEBFUCNI.getFirstTxId()) + ", but the last firstTxId was ") + RMGFWLGCYJ);
                        }


            }
        } 
        if (!MYLLEJUZPK.isEmpty()) {
            FSLLMLBQPO.add(new RedundantEditLogInputStream(MYLLEJUZPK, TZZGUJZORE));
            MYLLEJUZPK.clear();
        }
    }

    /**
     * Returns true if there are no journals, all redundant journals are disabled,
     * or any required journals are disabled.
     *
     * @return True if there no journals, all redundant journals are disabled,
    or any required journals are disabled.
     */
    public boolean isEmpty() {
        return !NameNodeResourcePolicy.areResourcesAvailable(WNCFVPMHFF, OGPUPZBLRS);
    }

    /**
     * Called when some journals experience an error in some operation.
     */
    private void disableAndReportErrorOnJournals(List<JournalSet.JournalAndStream> GEXCTHPIAZ) {
        if ((GEXCTHPIAZ == null) || GEXCTHPIAZ.isEmpty()) {
            return;// nothing to do

        }
        for (JournalSet.JournalAndStream HHWGNGFGFP : GEXCTHPIAZ) {
            JournalSet.WUSRPBXNKK.error("Disabling journal " + HHWGNGFGFP);
            HHWGNGFGFP.abort();
            HHWGNGFGFP.setDisabled(true);
        }
    }

    /**
     * Implementations of this interface encapsulate operations that can be
     * iteratively applied on all the journals. For example see
     * {@link JournalSet#mapJournalsAndReportErrors}.
     */
    private interface JournalClosure {
        /**
         * The operation on JournalAndStream.
         *
         * @param jas
         * 		Object on which operations are performed.
         * @throws IOException
         * 		
         */
        public void apply(JournalSet.JournalAndStream jas) throws IOException;
    }

    /**
     * Apply the given operation across all of the journal managers, disabling
     * any for which the closure throws an IOException.
     *
     * @param closure
     * 		{@link JournalClosure} object encapsulating the operation.
     * @param status
     * 		message used for logging errors (e.g. "opening journal")
     * @throws IOException
     * 		If the operation fails on all the journals.
     */
    private void mapJournalsAndReportErrors(JournalSet.JournalClosure DADWRDLXLQ, String UQCBCTPVUA) throws IOException {
        List<JournalSet.JournalAndStream> KOUPIEMHKZ = Lists.newLinkedList();
        for (JournalSet.JournalAndStream YZKTHNHGFN : WNCFVPMHFF) {
            try {
                DADWRDLXLQ.apply(YZKTHNHGFN);
            } catch (Throwable t) {
                if (YZKTHNHGFN.isRequired()) {
                    final String IBCTSCEAVM = ((("Error: " + UQCBCTPVUA) + " failed for required journal (") + YZKTHNHGFN) + ")";
                    JournalSet.WUSRPBXNKK.fatal(IBCTSCEAVM, t);
                    // If we fail on *any* of the required journals, then we must not
                    // continue on any of the other journals. Abort them to ensure that
                    // retry behavior doesn't allow them to keep going in any way.
                    abortAllJournals();
                    // the current policy is to shutdown the NN on errors to shared edits
                    // dir. There are many code paths to shared edits failures - syncs,
                    // roll of edits etc. All of them go through this common function
                    // where the isRequired() check is made. Applying exit policy here
                    // to catch all code paths.
                    terminate(1, IBCTSCEAVM);
                } else {
                    JournalSet.WUSRPBXNKK.error(((("Error: " + UQCBCTPVUA) + " failed for (journal ") + YZKTHNHGFN) + ")", t);
                    KOUPIEMHKZ.add(YZKTHNHGFN);
                }
            }
        }
        disableAndReportErrorOnJournals(KOUPIEMHKZ);
        if (!NameNodeResourcePolicy.areResourcesAvailable(WNCFVPMHFF, OGPUPZBLRS)) {
            String APKGDCBVTW = UQCBCTPVUA + " failed for too many journals";
            JournalSet.WUSRPBXNKK.error("Error: " + APKGDCBVTW);
            throw new IOException(APKGDCBVTW);
        }
    }

    /**
     * Abort all of the underlying streams.
     */
    private void abortAllJournals() {
        for (JournalSet.JournalAndStream MQPKMKAWMO : WNCFVPMHFF) {
            if (MQPKMKAWMO.isActive()) {
                MQPKMKAWMO.abort();
            }
        }
    }

    /**
     * An implementation of EditLogOutputStream that applies a requested method on
     * all the journals that are currently active.
     */
    private class JournalSetOutputStream extends EditLogOutputStream {
        JournalSetOutputStream() throws IOException {
            super();
        }

        @Override
        public void write(final FSEditLogOp op) throws IOException {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream jas) throws IOException {
                    if (jas.isActive()) {
                        jas.getCurrentStream().write(op);
                    }
                }
            }, "write op");
        }

        @Override
        public void writeRaw(final byte[] data, final int offset, final int length) throws IOException {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream jas) throws IOException {
                    if (jas.isActive()) {
                        jas.getCurrentStream().writeRaw(data, offset, length);
                    }
                }
            }, "write bytes");
        }

        @Override
        public void create(final int layoutVersion) throws IOException {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream jas) throws IOException {
                    if (jas.isActive()) {
                        jas.getCurrentStream().create(layoutVersion);
                    }
                }
            }, "create");
        }

        @Override
        public void close() throws IOException {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream jas) throws IOException {
                    jas.closeStream();
                }
            }, "close");
        }

        @Override
        public void abort() throws IOException {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream jas) throws IOException {
                    jas.abort();
                }
            }, "abort");
        }

        @Override
        public void setReadyToFlush() throws IOException {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream jas) throws IOException {
                    if (jas.isActive()) {
                        jas.getCurrentStream().setReadyToFlush();
                    }
                }
            }, "setReadyToFlush");
        }

        @Override
        protected void flushAndSync(final boolean durable) throws IOException {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream jas) throws IOException {
                    if (jas.isActive()) {
                        jas.getCurrentStream().flushAndSync(durable);
                    }
                }
            }, "flushAndSync");
        }

        @Override
        public void flush() throws IOException {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream jas) throws IOException {
                    if (jas.isActive()) {
                        jas.getCurrentStream().flush();
                    }
                }
            }, "flush");
        }

        @Override
        public boolean shouldForceSync() {
            for (JournalSet.JournalAndStream js : WNCFVPMHFF) {
                if (js.isActive() && js.getCurrentStream().shouldForceSync()) {
                    return true;
                }
            }
            return false;
        }

        @Override
        protected long getNumSync() {
            for (JournalSet.JournalAndStream jas : WNCFVPMHFF) {
                if (jas.isActive()) {
                    return jas.getCurrentStream().getNumSync();
                }
            }
            return 0;
        }
    }

    @Override
    public void setOutputBufferCapacity(final int WGYAWPOLBU) {
        try {
            mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
                @Override
                public void apply(JournalSet.JournalAndStream CFXTPFMPPF) throws IOException {
                    CFXTPFMPPF.getManager().setOutputBufferCapacity(WGYAWPOLBU);
                }
            }, "setOutputBufferCapacity");
        } catch (IOException e) {
            JournalSet.WUSRPBXNKK.error("Error in setting outputbuffer capacity");
        }
    }

    List<JournalSet.JournalAndStream> getAllJournalStreams() {
        return WNCFVPMHFF;
    }

    List<JournalManager> getJournalManagers() {
        List<JournalManager> JCBOKLOXYG = new ArrayList<JournalManager>();
        for (JournalSet.JournalAndStream GODOHCNGMP : WNCFVPMHFF) {
            JCBOKLOXYG.add(GODOHCNGMP.getManager());
        }
        return JCBOKLOXYG;
    }

    void add(JournalManager BYIOJNVAPQ, boolean AVKCBJDTVD) {
        add(BYIOJNVAPQ, AVKCBJDTVD, false);
    }

    void add(JournalManager ARTLENARMD, boolean UFGRSAKAMA, boolean RDKBWLGWGA) {
        JournalSet.JournalAndStream WLTLAMOYKP = new JournalSet.JournalAndStream(ARTLENARMD, UFGRSAKAMA, RDKBWLGWGA);
        WNCFVPMHFF.add(WLTLAMOYKP);
    }

    void remove(JournalManager IHOWLXYKDM) {
        JournalSet.JournalAndStream ERPAZPDFOK = null;
        for (JournalSet.JournalAndStream WBKEWKLHSR : WNCFVPMHFF) {
            if (WBKEWKLHSR.getManager().equals(IHOWLXYKDM)) {
                ERPAZPDFOK = WBKEWKLHSR;
                break;
            }
        }
        if (ERPAZPDFOK != null) {
            ERPAZPDFOK.abort();
            WNCFVPMHFF.remove(ERPAZPDFOK);
        }
    }

    @Override
    public void purgeLogsOlderThan(final long COGCGNHILB) throws IOException {
        mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
            @Override
            public void apply(JournalSet.JournalAndStream JRHFYRVEHH) throws IOException {
                JRHFYRVEHH.getManager().purgeLogsOlderThan(COGCGNHILB);
            }
        }, "purgeLogsOlderThan " + COGCGNHILB);
    }

    @Override
    public void recoverUnfinalizedSegments() throws IOException {
        mapJournalsAndReportErrors(new JournalSet.JournalClosure() {
            @Override
            public void apply(JournalSet.JournalAndStream CSRWJKUIHI) throws IOException {
                CSRWJKUIHI.getManager().recoverUnfinalizedSegments();
            }
        }, "recoverUnfinalizedSegments");
    }

    /**
     * Return a manifest of what finalized edit logs are available. All available
     * edit logs are returned starting from the transaction id passed. If
     * 'fromTxId' falls in the middle of a log, that log is returned as well.
     *
     * @param fromTxId
     * 		Starting transaction id to read the logs.
     * @return RemoteEditLogManifest object.
     */
    public synchronized RemoteEditLogManifest getEditLogManifest(long AYBIVBAWQD) {
        // Collect RemoteEditLogs available from each FileJournalManager
        List<RemoteEditLog> LFDQUGWHJY = Lists.newArrayList();
        for (JournalSet.JournalAndStream JZDPHIPJUY : WNCFVPMHFF) {
            if (JZDPHIPJUY.getManager() instanceof FileJournalManager) {
                FileJournalManager VAXKEKLWPL = ((FileJournalManager) (JZDPHIPJUY.getManager()));
                try {
                    LFDQUGWHJY.addAll(VAXKEKLWPL.getRemoteEditLogs(AYBIVBAWQD, false));
                } catch (Throwable t) {
                    JournalSet.WUSRPBXNKK.warn("Cannot list edit logs in " + VAXKEKLWPL, t);
                }
            }
        }
        // Group logs by their starting txid
        ImmutableListMultimap<Long, RemoteEditLog> HEKQXQNQJR = Multimaps.index(LFDQUGWHJY, GET_START_TXID);
        long PWSFWSMIWR = AYBIVBAWQD;
        List<RemoteEditLog> OYMXZGCWEO = Lists.newArrayList();
        while (true) {
            ImmutableList<RemoteEditLog> QFFWWZLPHG = HEKQXQNQJR.get(PWSFWSMIWR);
            if (QFFWWZLPHG.isEmpty()) {
                // we have a gap in logs - for example because we recovered some old
                // storage directory with ancient logs. Clear out any logs we've
                // accumulated so far, and then skip to the next segment of logs
                // after the gap.
                SortedSet<Long> LYUACRLURP = Sets.newTreeSet(HEKQXQNQJR.keySet());
                LYUACRLURP = LYUACRLURP.tailSet(PWSFWSMIWR);
                if (LYUACRLURP.isEmpty()) {
                    break;
                } else {
                    if (JournalSet.WUSRPBXNKK.isDebugEnabled()) {
                        JournalSet.WUSRPBXNKK.debug((("Found gap in logs at " + PWSFWSMIWR) + ": ") + "not returning previous logs in manifest.");
                    }
                    OYMXZGCWEO.clear();
                    PWSFWSMIWR = LYUACRLURP.first();
                    continue;
                }
            }
            // Find the one that extends the farthest forward
            RemoteEditLog SMKCBBKMQJ = Collections.max(QFFWWZLPHG);
            OYMXZGCWEO.add(SMKCBBKMQJ);
            // And then start looking from after that point
            PWSFWSMIWR = SMKCBBKMQJ.getEndTxId() + 1;
        } 
        RemoteEditLogManifest CLPLAFJCSV = new RemoteEditLogManifest(OYMXZGCWEO);
        if (JournalSet.WUSRPBXNKK.isDebugEnabled()) {
            JournalSet.WUSRPBXNKK.debug((("Generated manifest for logs since " + AYBIVBAWQD) + ":") + CLPLAFJCSV);
        }
        return CLPLAFJCSV;
    }

    /**
     * Add sync times to the buffer.
     */
    String getSyncTimes() {
        StringBuilder RUCJXIHOEK = new StringBuilder();
        for (JournalSet.JournalAndStream XMVVFRSVKU : WNCFVPMHFF) {
            if (XMVVFRSVKU.isActive()) {
                RUCJXIHOEK.append(XMVVFRSVKU.getCurrentStream().getTotalSyncTime());
                RUCJXIHOEK.append(" ");
            }
        }
        return RUCJXIHOEK.toString();
    }

    @Override
    public void doPreUpgrade() throws IOException {
        // This operation is handled by FSEditLog directly.
        throw new UnsupportedOperationException();
    }

    @Override
    public void doUpgrade(Storage ZURVEKNUXK) throws IOException {
        // This operation is handled by FSEditLog directly.
        throw new UnsupportedOperationException();
    }

    @Override
    public void doFinalize() throws IOException {
        // This operation is handled by FSEditLog directly.
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean canRollBack(StorageInfo MKRLHZAYVR, StorageInfo RWWORFZXYW, int DDQULLOXPD) throws IOException {
        // This operation is handled by FSEditLog directly.
        throw new UnsupportedOperationException();
    }

    @Override
    public void doRollback() throws IOException {
        // This operation is handled by FSEditLog directly.
        throw new UnsupportedOperationException();
    }

    @Override
    public void discardSegments(long UOFFICXWFT) throws IOException {
        // This operation is handled by FSEditLog directly.
        throw new UnsupportedOperationException();
    }

    @Override
    public long getJournalCTime() throws IOException {
        // This operation is handled by FSEditLog directly.
        throw new UnsupportedOperationException();
    }
}