/**
 * Testing {@link LightWeightCache}
 */
public class TestLightWeightCache {
    private static final long LZYQVDJYER = Time.now();

    private static final long QGKETATJUD = TestLightWeightCache.LZYQVDJYER;

    private static final Random LVVEHPSZKQ = new Random(TestLightWeightCache.QGKETATJUD);

    static {
        TestLightWeightCache.println((("Start time = " + new Date(TestLightWeightCache.LZYQVDJYER)) + ", seed=") + TestLightWeightCache.QGKETATJUD);
    }

    private static void print(Object FHZSSOKWQK) {
        System.out.print(FHZSSOKWQK);
        System.out.flush();
    }

    private static void println(Object SRNYBMIGAR) {
        System.out.println(SRNYBMIGAR);
    }

    @Test
    public void testLightWeightCache() {
        // test randomized creation expiration with zero access expiration
        {
            final long BLWHYBBAGC = TestLightWeightCache.LVVEHPSZKQ.nextInt(1024) + 1;
            TestLightWeightCache.check(1, BLWHYBBAGC, 0L, 1 << 10, 65537);
            TestLightWeightCache.check(17, BLWHYBBAGC, 0L, 1 << 16, 17);
            TestLightWeightCache.check(255, BLWHYBBAGC, 0L, 1 << 16, 65537);
        }
        // test randomized creation/access expiration periods
        for (int WESOALNPWB = 0; WESOALNPWB < 3; WESOALNPWB++) {
            final long WXMCSTYGYB = TestLightWeightCache.LVVEHPSZKQ.nextInt(1024) + 1;
            final long FITKMGVNMS = TestLightWeightCache.LVVEHPSZKQ.nextInt(1024) + 1;
            TestLightWeightCache.check(1, WXMCSTYGYB, FITKMGVNMS, 1 << 10, 65537);
            TestLightWeightCache.check(17, WXMCSTYGYB, FITKMGVNMS, 1 << 16, 17);
            TestLightWeightCache.check(255, WXMCSTYGYB, FITKMGVNMS, 1 << 16, 65537);
        }
        // test size limit
        final int EPSJBKXTLO = 1 << 16;
        for (int FJVIMLSTUQ = 0; FJVIMLSTUQ < 10; FJVIMLSTUQ++) {
            final int OYVJMMTKSQ = TestLightWeightCache.LVVEHPSZKQ.nextInt(1024) + 1;
            final int LMVWOQGZDT = TestLightWeightCache.LVVEHPSZKQ.nextInt(OYVJMMTKSQ) + 1;
            TestLightWeightCache.checkSizeLimit(LMVWOQGZDT, EPSJBKXTLO, OYVJMMTKSQ);
        }
    }

    private static void checkSizeLimit(final int DAYBIJUPGN, final int OCXTEFNHPI, final int ZWMXCDPTDC) {
        final TestLightWeightCache.LightWeightCacheTestCase DMJSWIPFXW = new TestLightWeightCache.LightWeightCacheTestCase(DAYBIJUPGN, DAYBIJUPGN, 1L << 32, 1L << 32, OCXTEFNHPI, ZWMXCDPTDC);
        // keep putting entries and check size limit
        TestLightWeightCache.print("  check size ................. ");
        for (int PHGOAUBHIW = 0; PHGOAUBHIW < DMJSWIPFXW.BWCTFAZTLV.size(); PHGOAUBHIW++) {
            DMJSWIPFXW.VQJHEKVZPC.put(DMJSWIPFXW.BWCTFAZTLV.get(PHGOAUBHIW));
            Assert.assertTrue(DMJSWIPFXW.VQJHEKVZPC.size() <= DAYBIJUPGN);
        }
        TestLightWeightCache.println("DONE " + DMJSWIPFXW.stat());
    }

    /**
     * Test various createionExpirationPeriod and accessExpirationPeriod.
     * It runs ~2 minutes. If you are changing the implementation,
     * please un-comment the following line in order to run the test.
     */
    // @Test
    public void testExpirationPeriods() {
        for (int NUKXGADYYO = -4; NUKXGADYYO < 10; NUKXGADYYO += 4) {
            final long CEBNSKCANC = (NUKXGADYYO < 0) ? 0L : 1L << NUKXGADYYO;
            for (int VCMZQCDWZR = 0; VCMZQCDWZR < 10; VCMZQCDWZR += 4) {
                final long JOVZCARHIG = 1L << VCMZQCDWZR;
                TestLightWeightCache.runTests(1, JOVZCARHIG, CEBNSKCANC);
                for (int QONPCNSXPC = 1; QONPCNSXPC < (Integer.SIZE - 1); QONPCNSXPC += 8) {
                    TestLightWeightCache.runTests((1 << QONPCNSXPC) + 1, JOVZCARHIG, CEBNSKCANC);
                }
            }
        }
    }

    /**
     * Run tests with various table lengths.
     */
    private static void runTests(final int DKDRWZYJYM, final long MXHZQSILZW, final long CRGAWJIFIR) {
        TestLightWeightCache.println((((("\n\n\n*** runTest: modulus=" + DKDRWZYJYM) + ", creationExpirationPeriod=") + MXHZQSILZW) + ", accessExpirationPeriod=") + CRGAWJIFIR);
        for (int OJWOPHQPXN = 0; OJWOPHQPXN <= 16; OJWOPHQPXN += 4) {
            final int TRVDOORDAS = 1 << OJWOPHQPXN;
            final int GXVUJBPILF = OJWOPHQPXN + 2;
            final int BSJFVJTPCK = Math.max(1, GXVUJBPILF / 3);
            for (int HNARYYZAMG = GXVUJBPILF; HNARYYZAMG > 0; HNARYYZAMG -= BSJFVJTPCK) {
                final int CLMKTGWIXI = 1 << HNARYYZAMG;
                TestLightWeightCache.check(TRVDOORDAS, MXHZQSILZW, CRGAWJIFIR, CLMKTGWIXI, DKDRWZYJYM);
            }
        }
    }

    private static void check(int QYFQWGFBJN, long RUYDSABZNH, long QCMLFKRAIW, int UOYKSEXQRY, int WPHVRKQDEN) {
        TestLightWeightCache.check(new TestLightWeightCache.LightWeightCacheTestCase(QYFQWGFBJN, -1, RUYDSABZNH, QCMLFKRAIW, UOYKSEXQRY, WPHVRKQDEN));
    }

    /**
     * check the following operations
     * (1) put
     * (2) remove & put
     * (3) remove
     * (4) remove & put again
     */
    private static void check(final TestLightWeightCache.LightWeightCacheTestCase VHISPGGCEP) {
        // check put
        TestLightWeightCache.print("  check put .................. ");
        for (int ONHZTAYLAD = 0; ONHZTAYLAD < (VHISPGGCEP.BWCTFAZTLV.size() / 2); ONHZTAYLAD++) {
            VHISPGGCEP.put(VHISPGGCEP.BWCTFAZTLV.get(ONHZTAYLAD));
        }
        for (int ICSHIJZRRY = 0; ICSHIJZRRY < VHISPGGCEP.BWCTFAZTLV.size(); ICSHIJZRRY++) {
            VHISPGGCEP.put(VHISPGGCEP.BWCTFAZTLV.get(ICSHIJZRRY));
        }
        TestLightWeightCache.println("DONE " + VHISPGGCEP.stat());
        // check remove and put
        TestLightWeightCache.print("  check remove & put ......... ");
        for (int TOMSFDRYFH = 0; TOMSFDRYFH < 10; TOMSFDRYFH++) {
            for (int GDDCVQBGPN = 0; GDDCVQBGPN < (VHISPGGCEP.BWCTFAZTLV.size() / 2); GDDCVQBGPN++) {
                final int YZLOBQJFKZ = TestLightWeightCache.LVVEHPSZKQ.nextInt(VHISPGGCEP.BWCTFAZTLV.size());
                VHISPGGCEP.remove(VHISPGGCEP.BWCTFAZTLV.get(YZLOBQJFKZ));
            }
            for (int FUGHPKQEZH = 0; FUGHPKQEZH < (VHISPGGCEP.BWCTFAZTLV.size() / 2); FUGHPKQEZH++) {
                final int PFPAQOSHZQ = TestLightWeightCache.LVVEHPSZKQ.nextInt(VHISPGGCEP.BWCTFAZTLV.size());
                VHISPGGCEP.put(VHISPGGCEP.BWCTFAZTLV.get(PFPAQOSHZQ));
            }
        }
        TestLightWeightCache.println("DONE " + VHISPGGCEP.stat());
        // check remove
        TestLightWeightCache.print("  check remove ............... ");
        for (int CHBDSEDNKN = 0; CHBDSEDNKN < VHISPGGCEP.BWCTFAZTLV.size(); CHBDSEDNKN++) {
            VHISPGGCEP.remove(VHISPGGCEP.BWCTFAZTLV.get(CHBDSEDNKN));
        }
        Assert.assertEquals(0, VHISPGGCEP.VQJHEKVZPC.size());
        TestLightWeightCache.println("DONE " + VHISPGGCEP.stat());
        // check remove and put again
        TestLightWeightCache.print("  check remove & put again ... ");
        for (int VYSPVWOPZW = 0; VYSPVWOPZW < 10; VYSPVWOPZW++) {
            for (int XMYKTQWJSU = 0; XMYKTQWJSU < (VHISPGGCEP.BWCTFAZTLV.size() / 2); XMYKTQWJSU++) {
                final int MTHUCDHOPT = TestLightWeightCache.LVVEHPSZKQ.nextInt(VHISPGGCEP.BWCTFAZTLV.size());
                VHISPGGCEP.remove(VHISPGGCEP.BWCTFAZTLV.get(MTHUCDHOPT));
            }
            for (int IISTEWHLUO = 0; IISTEWHLUO < (VHISPGGCEP.BWCTFAZTLV.size() / 2); IISTEWHLUO++) {
                final int RLAVFWIZXS = TestLightWeightCache.LVVEHPSZKQ.nextInt(VHISPGGCEP.BWCTFAZTLV.size());
                VHISPGGCEP.put(VHISPGGCEP.BWCTFAZTLV.get(RLAVFWIZXS));
            }
        }
        TestLightWeightCache.println("DONE " + VHISPGGCEP.stat());
        final long SYLFBVUNQD = (Time.now() - TestLightWeightCache.LZYQVDJYER) / 1000L;
        TestLightWeightCache.println(("total time elapsed=" + SYLFBVUNQD) + "s\n");
    }

    /**
     * The test case contains two data structures, a cache and a hashMap.
     * The hashMap is used to verify the correctness of the cache.  Note that
     * no automatic eviction is performed in the hashMap.  Thus, we have
     * (1) If an entry exists in cache, it MUST exist in the hashMap.
     * (2) If an entry does not exist in the cache, it may or may not exist in the
     *     hashMap.  If it exists, it must be expired.
     */
    private static class LightWeightCacheTestCase implements GSet<TestLightWeightCache.IntEntry, TestLightWeightCache.IntEntry> {
        /**
         * hashMap will not evict entries automatically.
         */
        final GSet<TestLightWeightCache.IntEntry, TestLightWeightCache.IntEntry> MNUJBMCVJY = new GSetByHashMap<TestLightWeightCache.IntEntry, TestLightWeightCache.IntEntry>(1024, 0.75F);

        final LightWeightCache<TestLightWeightCache.IntEntry, TestLightWeightCache.IntEntry> VQJHEKVZPC;

        final TestLightWeightCache.IntData BWCTFAZTLV;

        final String YGTBVAISXX;

        final long ETJJKUEKWR = Time.now();

        /**
         * Determine the probability in {@link #check()}.
         */
        final int AOIWARGKLM;

        int JRQCZPGEJF = 0;

        int DGECLSAMDF = 0;

        private long OMYHPHTSIM = TestLightWeightCache.LVVEHPSZKQ.nextInt();

        LightWeightCacheTestCase(int tablelength, int sizeLimit, long creationExpirationPeriod, long accessExpirationPeriod, int datasize, int modulus) {
            AOIWARGKLM = Math.min((datasize >> 7) + 1, 1 << 16);
            YGTBVAISXX = (((((((((((((getClass().getSimpleName() + "(") + new Date(ETJJKUEKWR)) + "): tablelength=") + tablelength) + ", creationExpirationPeriod=") + creationExpirationPeriod) + ", accessExpirationPeriod=") + accessExpirationPeriod) + ", datasize=") + datasize) + ", modulus=") + modulus) + ", denominator=") + AOIWARGKLM;
            TestLightWeightCache.println(YGTBVAISXX);
            BWCTFAZTLV = new TestLightWeightCache.IntData(datasize, modulus);
            VQJHEKVZPC = new LightWeightCache<TestLightWeightCache.IntEntry, TestLightWeightCache.IntEntry>(tablelength, sizeLimit, creationExpirationPeriod, 0, new LightWeightCache.Clock() {
                @Override
                long currentTime() {
                    return OMYHPHTSIM;
                }
            });
            Assert.assertEquals(0, VQJHEKVZPC.size());
        }

        private boolean containsTest(TestLightWeightCache.IntEntry key) {
            final boolean c = VQJHEKVZPC.contains(key);
            if (c) {
                Assert.assertTrue(MNUJBMCVJY.contains(key));
            } else {
                final TestLightWeightCache.IntEntry h = MNUJBMCVJY.remove(key);
                if (h != null) {
                    Assert.assertTrue(VQJHEKVZPC.isExpired(h, OMYHPHTSIM));
                }
            }
            return c;
        }

        @Override
        public boolean contains(TestLightWeightCache.IntEntry key) {
            final boolean e = containsTest(key);
            check();
            return e;
        }

        private TestLightWeightCache.IntEntry getTest(TestLightWeightCache.IntEntry key) {
            final TestLightWeightCache.IntEntry c = VQJHEKVZPC.get(key);
            if (c != null) {
                Assert.assertEquals(MNUJBMCVJY.get(key).id, c.DONKXEELJD);
            } else {
                final TestLightWeightCache.IntEntry h = MNUJBMCVJY.remove(key);
                if (h != null) {
                    Assert.assertTrue(VQJHEKVZPC.isExpired(h, OMYHPHTSIM));
                }
            }
            return c;
        }

        @Override
        public TestLightWeightCache.IntEntry get(TestLightWeightCache.IntEntry key) {
            final TestLightWeightCache.IntEntry e = getTest(key);
            check();
            return e;
        }

        private TestLightWeightCache.IntEntry putTest(TestLightWeightCache.IntEntry entry) {
            final TestLightWeightCache.IntEntry c = VQJHEKVZPC.put(entry);
            if (c != null) {
                Assert.assertEquals(MNUJBMCVJY.put(entry).id, c.DONKXEELJD);
            } else {
                final TestLightWeightCache.IntEntry h = MNUJBMCVJY.put(entry);
                if ((h != null) && (h != entry)) {
                    // if h == entry, its expiration time is already updated
                    Assert.assertTrue(VQJHEKVZPC.isExpired(h, OMYHPHTSIM));
                }
            }
            return c;
        }

        @Override
        public TestLightWeightCache.IntEntry put(TestLightWeightCache.IntEntry entry) {
            final TestLightWeightCache.IntEntry e = putTest(entry);
            check();
            return e;
        }

        private TestLightWeightCache.IntEntry removeTest(TestLightWeightCache.IntEntry key) {
            final TestLightWeightCache.IntEntry c = VQJHEKVZPC.remove(key);
            if (c != null) {
                Assert.assertEquals(c.DONKXEELJD, MNUJBMCVJY.remove(key).id);
            } else {
                final TestLightWeightCache.IntEntry h = MNUJBMCVJY.remove(key);
                if (h != null) {
                    Assert.assertTrue(VQJHEKVZPC.isExpired(h, OMYHPHTSIM));
                }
            }
            return c;
        }

        @Override
        public TestLightWeightCache.IntEntry remove(TestLightWeightCache.IntEntry key) {
            final TestLightWeightCache.IntEntry e = removeTest(key);
            check();
            return e;
        }

        private int sizeTest() {
            final int c = VQJHEKVZPC.size();
            Assert.assertTrue(MNUJBMCVJY.size() >= c);
            return c;
        }

        @Override
        public int size() {
            final int s = sizeTest();
            check();
            return s;
        }

        @Override
        public Iterator<TestLightWeightCache.IntEntry> iterator() {
            throw new UnsupportedOperationException();
        }

        boolean tossCoin() {
            return TestLightWeightCache.LVVEHPSZKQ.nextInt(AOIWARGKLM) == 0;
        }

        void check() {
            OMYHPHTSIM += TestLightWeightCache.LVVEHPSZKQ.nextInt() & 0x3;
            // test size
            sizeTest();
            if (tossCoin()) {
                // test get(..), check content and test iterator
                JRQCZPGEJF++;
                for (TestLightWeightCache.IntEntry i : VQJHEKVZPC) {
                    getTest(i);
                }
            }
            if (tossCoin()) {
                // test contains(..)
                DGECLSAMDF++;
                final int count = Math.min(BWCTFAZTLV.size(), 1000);
                if (count == BWCTFAZTLV.size()) {
                    for (TestLightWeightCache.IntEntry i : BWCTFAZTLV.ZXTFGWTRXF) {
                        containsTest(i);
                    }
                } else {
                    for (int j = 0; j < count; j++) {
                        containsTest(BWCTFAZTLV.get(TestLightWeightCache.LVVEHPSZKQ.nextInt(BWCTFAZTLV.size())));
                    }
                }
            }
        }

        String stat() {
            final long t = Time.now() - ETJJKUEKWR;
            return String.format(" iterate=%5d, contain=%5d, time elapsed=%5d.%03ds", JRQCZPGEJF, DGECLSAMDF, t / 1000, t % 1000);
        }

        @Override
        public void clear() {
            MNUJBMCVJY.clear();
            VQJHEKVZPC.clear();
            Assert.assertEquals(0, size());
        }
    }

    private static class IntData {
        final TestLightWeightCache.IntEntry[] ZXTFGWTRXF;

        IntData(int size, int modulus) {
            ZXTFGWTRXF = new TestLightWeightCache.IntEntry[size];
            for (int i = 0; i < ZXTFGWTRXF.length; i++) {
                ZXTFGWTRXF[i] = new TestLightWeightCache.IntEntry(i, TestLightWeightCache.LVVEHPSZKQ.nextInt(modulus));
            }
        }

        TestLightWeightCache.IntEntry get(int i) {
            return ZXTFGWTRXF[i];
        }

        int size() {
            return ZXTFGWTRXF.length;
        }
    }

    /**
     * Entries of {@link LightWeightCache} in this test
     */
    private static class IntEntry implements Comparable<TestLightWeightCache.IntEntry> , LightWeightCache.Entry {
        private LinkedElement CCTVQSQOXO;

        final int DONKXEELJD;

        final int LGTWVGMXCN;

        private long JGILYYZTUY = 0;

        IntEntry(int id, int value) {
            this.DONKXEELJD = id;
            this.LGTWVGMXCN = value;
        }

        @Override
        public boolean equals(Object obj) {
            return ((obj != null) && (obj instanceof TestLightWeightCache.IntEntry)) && (LGTWVGMXCN == ((TestLightWeightCache.IntEntry) (obj)).LGTWVGMXCN);
        }

        @Override
        public int hashCode() {
            return LGTWVGMXCN;
        }

        @Override
        public int compareTo(TestLightWeightCache.IntEntry that) {
            return LGTWVGMXCN - that.LGTWVGMXCN;
        }

        @Override
        public String toString() {
            return (((DONKXEELJD + "#") + LGTWVGMXCN) + ",expirationTime=") + JGILYYZTUY;
        }

        @Override
        public LinkedElement getNext() {
            return CCTVQSQOXO;
        }

        @Override
        public void setNext(LightWeightGSet.LinkedElement e) {
            CCTVQSQOXO = e;
        }

        @Override
        public void setExpirationTime(long timeNano) {
            this.JGILYYZTUY = timeNano;
        }

        @Override
        public long getExpirationTime() {
            return JGILYYZTUY;
        }
    }
}