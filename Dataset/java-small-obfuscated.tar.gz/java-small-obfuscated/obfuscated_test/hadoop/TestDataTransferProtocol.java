/**
 * This tests data transfer protocol handling in the Datanode. It sends
 * various forms of wrong data and verifies that Datanode handles it well.
 */
public class TestDataTransferProtocol {
    private static final Log FWGXVYDRKW = LogFactory.getLog("org.apache.hadoop.hdfs.TestDataTransferProtocol");

    private static final DataChecksum WKYKDJKNQC = DataChecksum.newDataChecksum(CRC32C, 512);

    DatanodeID UMWZCOFUEX;

    InetSocketAddress KCIJLLNOEM;

    final ByteArrayOutputStream NGBMGWGWCV = new ByteArrayOutputStream(128);

    final DataOutputStream WJPGVPTECM = new DataOutputStream(NGBMGWGWCV);

    final Sender OONDAJTBCD = new Sender(WJPGVPTECM);

    final ByteArrayOutputStream FSPTVCMQTX = new ByteArrayOutputStream(128);

    final DataOutputStream ORYPUGEINB = new DataOutputStream(FSPTVCMQTX);

    private void sendRecvData(String CFLSBFJSBH, boolean GIKJKWTZLB) throws IOException {
        /* Opens a socket to datanode
        sends the data in sendBuf.
        If there is data in expectedBuf, expects to receive the data
            from datanode that matches expectedBuf.
        If there is an exception while recieving, throws it
            only if exceptionExcepted is false.
         */
        Socket TBEYEPVFPV = null;
        try {
            if (CFLSBFJSBH != null) {
                TestDataTransferProtocol.FWGXVYDRKW.info("Testing : " + CFLSBFJSBH);
            }
            TestDataTransferProtocol.FWGXVYDRKW.info("Going to write:" + StringUtils.byteToHexString(NGBMGWGWCV.toByteArray()));
            TBEYEPVFPV = new Socket();
            TBEYEPVFPV.connect(KCIJLLNOEM, READ_TIMEOUT);
            TBEYEPVFPV.setSoTimeout(READ_TIMEOUT);
            OutputStream ATZLXYYZXQ = TBEYEPVFPV.getOutputStream();
            // Should we excuse
            byte[] RMZRJRRILN = new byte[FSPTVCMQTX.size()];
            DataInputStream LMMFUCPYMO = new DataInputStream(TBEYEPVFPV.getInputStream());
            ATZLXYYZXQ.write(NGBMGWGWCV.toByteArray());
            ATZLXYYZXQ.flush();
            try {
                LMMFUCPYMO.readFully(RMZRJRRILN);
            } catch (EOFException eof) {
                if (GIKJKWTZLB) {
                    TestDataTransferProtocol.FWGXVYDRKW.info("Got EOF as expected.");
                    return;
                }
                throw eof;
            }
            String LAABCTPUSQ = StringUtils.byteToHexString(RMZRJRRILN);
            String IQMVHZERZG = StringUtils.byteToHexString(FSPTVCMQTX.toByteArray());
            TestDataTransferProtocol.FWGXVYDRKW.info("Received: " + LAABCTPUSQ);
            TestDataTransferProtocol.FWGXVYDRKW.info("Expected: " + IQMVHZERZG);
            if (GIKJKWTZLB) {
                throw new IOException(("Did not recieve IOException when an exception " + "is expected while reading from ") + UMWZCOFUEX);
            }
            assertEquals(IQMVHZERZG, LAABCTPUSQ);
        } finally {
            IOUtils.closeSocket(TBEYEPVFPV);
        }
    }

    void readFile(FileSystem HAJURDNSFU, Path SAWGXDQBWH, int DRCNISPQEQ) throws IOException {
        byte[] YXJQMSSTRO = new byte[DRCNISPQEQ];
        FSDataInputStream DWJBKJCFKY = HAJURDNSFU.open(SAWGXDQBWH);
        DWJBKJCFKY.readFully(YXJQMSSTRO);
    }

    private void writeZeroLengthPacket(ExtendedBlock OGLOAFQOBP, String HQOJQJMSKZ) throws IOException {
        PacketHeader FKFYEHRICA = // size of packet
        // OffsetInBlock
        // sequencenumber
        // lastPacketInBlock
        // chunk length
        new PacketHeader(8, OGLOAFQOBP.getNumBytes(), 100, true, 0, false);
        // sync block
        FKFYEHRICA.write(WJPGVPTECM);
        WJPGVPTECM.writeInt(0);// zero checksum

        // ok finally write a block with 0 len
        sendResponse(SUCCESS, "", null, ORYPUGEINB);
        new org.apache.hadoop.hdfs.protocol.datatransfer.PipelineAck(100, new Status[]{ Status.SUCCESS }).write(ORYPUGEINB);
        sendRecvData(HQOJQJMSKZ, false);
    }

    private void sendResponse(Status JHNORYADDM, String PRKHGNHYAS, String YWDTKKBAOS, DataOutputStream MGNZOQTRZZ) throws IOException {
        Builder GHQHXRDDZA = org.apache.hadoop.hdfs.protocol.proto.DataTransferProtos.BlockOpResponseProto.newBuilder().setStatus(JHNORYADDM);
        if (PRKHGNHYAS != null) {
            GHQHXRDDZA.setFirstBadLink(PRKHGNHYAS);
        }
        if (YWDTKKBAOS != null) {
            GHQHXRDDZA.setMessage(YWDTKKBAOS);
        }
        GHQHXRDDZA.build().writeDelimitedTo(MGNZOQTRZZ);
    }

    private void testWrite(ExtendedBlock YWESPZCDBV, BlockConstructionStage LBZNQATQQR, long ELXGDUAHOA, String XAFCUOLBSX, Boolean ZVTIGEARBN) throws IOException {
        NGBMGWGWCV.reset();
        FSPTVCMQTX.reset();
        writeBlock(YWESPZCDBV, LBZNQATQQR, ELXGDUAHOA, TestDataTransferProtocol.WKYKDJKNQC);
        if (ZVTIGEARBN) {
            sendResponse(ERROR, null, null, ORYPUGEINB);
            sendRecvData(XAFCUOLBSX, true);
        } else
            if (LBZNQATQQR == BlockConstructionStage.PIPELINE_CLOSE_RECOVERY) {
                // ok finally write a block with 0 len
                sendResponse(SUCCESS, "", null, ORYPUGEINB);
                sendRecvData(XAFCUOLBSX, false);
            } else {
                writeZeroLengthPacket(YWESPZCDBV, XAFCUOLBSX);
            }

    }

    @Test
    public void testOpWrite() throws IOException {
        int IQSDLWEBQJ = 1;
        final long ERDRURDIZJ = 128;
        Configuration KLWUPVQOPA = new HdfsConfiguration();
        MiniDFSCluster YFAQTIMRLW = new MiniDFSCluster.Builder(KLWUPVQOPA).numDataNodes(IQSDLWEBQJ).build();
        try {
            YFAQTIMRLW.waitActive();
            String FUQVDUZJKC = YFAQTIMRLW.getNamesystem().getBlockPoolId();
            UMWZCOFUEX = DataNodeTestUtils.getDNRegistrationForBP(YFAQTIMRLW.getDataNodes().get(0), FUQVDUZJKC);
            KCIJLLNOEM = NetUtils.createSocketAddr(UMWZCOFUEX.getXferAddr());
            FileSystem BPQZLAMSWD = YFAQTIMRLW.getFileSystem();
            /* Test writing to finalized replicas */
            Path VNLHFIBIWG = new Path("dataprotocol.dat");
            DFSTestUtil.createFile(BPQZLAMSWD, VNLHFIBIWG, 1L, ((short) (IQSDLWEBQJ)), 0L);
            // get the first blockid for the file
            ExtendedBlock QALSKERUVC = DFSTestUtil.getFirstBlock(BPQZLAMSWD, VNLHFIBIWG);
            // test PIPELINE_SETUP_CREATE on a finalized block
            testWrite(QALSKERUVC, PIPELINE_SETUP_CREATE, 0L, "Cannot create an existing block", true);
            // test PIPELINE_DATA_STREAMING on a finalized block
            testWrite(QALSKERUVC, DATA_STREAMING, 0L, "Unexpected stage", true);
            // test PIPELINE_SETUP_STREAMING_RECOVERY on an existing block
            long NKZGPCLLTS = QALSKERUVC.getGenerationStamp() + 1;
            testWrite(QALSKERUVC, PIPELINE_SETUP_STREAMING_RECOVERY, NKZGPCLLTS, "Cannot recover data streaming to a finalized replica", true);
            // test PIPELINE_SETUP_APPEND on an existing block
            NKZGPCLLTS = QALSKERUVC.getGenerationStamp() + 1;
            testWrite(QALSKERUVC, PIPELINE_SETUP_APPEND, NKZGPCLLTS, "Append to a finalized replica", false);
            QALSKERUVC.setGenerationStamp(NKZGPCLLTS);
            // test PIPELINE_SETUP_APPEND_RECOVERY on an existing block
            VNLHFIBIWG = new Path("dataprotocol1.dat");
            DFSTestUtil.createFile(BPQZLAMSWD, VNLHFIBIWG, 1L, ((short) (IQSDLWEBQJ)), 0L);
            QALSKERUVC = DFSTestUtil.getFirstBlock(BPQZLAMSWD, VNLHFIBIWG);
            NKZGPCLLTS = QALSKERUVC.getGenerationStamp() + 1;
            testWrite(QALSKERUVC, PIPELINE_SETUP_APPEND_RECOVERY, NKZGPCLLTS, "Recover appending to a finalized replica", false);
            // test PIPELINE_CLOSE_RECOVERY on an existing block
            VNLHFIBIWG = new Path("dataprotocol2.dat");
            DFSTestUtil.createFile(BPQZLAMSWD, VNLHFIBIWG, 1L, ((short) (IQSDLWEBQJ)), 0L);
            QALSKERUVC = DFSTestUtil.getFirstBlock(BPQZLAMSWD, VNLHFIBIWG);
            NKZGPCLLTS = QALSKERUVC.getGenerationStamp() + 1;
            testWrite(QALSKERUVC, PIPELINE_CLOSE_RECOVERY, NKZGPCLLTS, "Recover failed close to a finalized replica", false);
            QALSKERUVC.setGenerationStamp(NKZGPCLLTS);
            // Test writing to a new block. Don't choose the next sequential
            // block ID to avoid conflicting with IDs chosen by the NN.
            long PELOOEHLVB = QALSKERUVC.getBlockId() + ERDRURDIZJ;
            ExtendedBlock YQBOTCVPMS = new ExtendedBlock(QALSKERUVC.getBlockPoolId(), PELOOEHLVB, 0, QALSKERUVC.getGenerationStamp());
            // test PIPELINE_SETUP_CREATE on a new block
            testWrite(YQBOTCVPMS, PIPELINE_SETUP_CREATE, 0L, "Create a new block", false);
            // test PIPELINE_SETUP_STREAMING_RECOVERY on a new block
            NKZGPCLLTS = YQBOTCVPMS.getGenerationStamp() + 1;
            YQBOTCVPMS.setBlockId(YQBOTCVPMS.getBlockId() + 1);
            testWrite(YQBOTCVPMS, PIPELINE_SETUP_STREAMING_RECOVERY, NKZGPCLLTS, "Recover a new block", true);
            // test PIPELINE_SETUP_APPEND on a new block
            NKZGPCLLTS = YQBOTCVPMS.getGenerationStamp() + 1;
            testWrite(YQBOTCVPMS, PIPELINE_SETUP_APPEND, NKZGPCLLTS, "Cannot append to a new block", true);
            // test PIPELINE_SETUP_APPEND_RECOVERY on a new block
            YQBOTCVPMS.setBlockId(YQBOTCVPMS.getBlockId() + 1);
            NKZGPCLLTS = YQBOTCVPMS.getGenerationStamp() + 1;
            testWrite(YQBOTCVPMS, PIPELINE_SETUP_APPEND_RECOVERY, NKZGPCLLTS, "Cannot append to a new block", true);
            /* Test writing to RBW replicas */
            Path HAAEJJOQJM = new Path("dataprotocol1.dat");
            DFSTestUtil.createFile(BPQZLAMSWD, HAAEJJOQJM, 1L, ((short) (IQSDLWEBQJ)), 0L);
            DFSOutputStream ZYVGVTTMYD = ((DFSOutputStream) (BPQZLAMSWD.append(HAAEJJOQJM).getWrappedStream()));
            ZYVGVTTMYD.write(1);
            ZYVGVTTMYD.hflush();
            FSDataInputStream BJNGNGGVDU = BPQZLAMSWD.open(HAAEJJOQJM);
            QALSKERUVC = DFSTestUtil.getAllBlocks(BJNGNGGVDU).get(0).getBlock();
            QALSKERUVC.setNumBytes(2L);
            try {
                // test PIPELINE_SETUP_CREATE on a RBW block
                testWrite(QALSKERUVC, PIPELINE_SETUP_CREATE, 0L, "Cannot create a RBW block", true);
                // test PIPELINE_SETUP_APPEND on an existing block
                NKZGPCLLTS = QALSKERUVC.getGenerationStamp() + 1;
                testWrite(QALSKERUVC, PIPELINE_SETUP_APPEND, NKZGPCLLTS, "Cannot append to a RBW replica", true);
                // test PIPELINE_SETUP_APPEND on an existing block
                testWrite(QALSKERUVC, PIPELINE_SETUP_APPEND_RECOVERY, NKZGPCLLTS, "Recover append to a RBW replica", false);
                QALSKERUVC.setGenerationStamp(NKZGPCLLTS);
                // test PIPELINE_SETUP_STREAMING_RECOVERY on a RBW block
                VNLHFIBIWG = new Path("dataprotocol2.dat");
                DFSTestUtil.createFile(BPQZLAMSWD, VNLHFIBIWG, 1L, ((short) (IQSDLWEBQJ)), 0L);
                ZYVGVTTMYD = ((DFSOutputStream) (BPQZLAMSWD.append(VNLHFIBIWG).getWrappedStream()));
                ZYVGVTTMYD.write(1);
                ZYVGVTTMYD.hflush();
                BJNGNGGVDU = BPQZLAMSWD.open(VNLHFIBIWG);
                QALSKERUVC = DFSTestUtil.getAllBlocks(BJNGNGGVDU).get(0).getBlock();
                QALSKERUVC.setNumBytes(2L);
                NKZGPCLLTS = QALSKERUVC.getGenerationStamp() + 1;
                testWrite(QALSKERUVC, PIPELINE_SETUP_STREAMING_RECOVERY, NKZGPCLLTS, "Recover a RBW replica", false);
            } finally {
                IOUtils.closeStream(BJNGNGGVDU);
                IOUtils.closeStream(ZYVGVTTMYD);
            }
        } finally {
            YFAQTIMRLW.shutdown();
        }
    }

    @Test
    public void testDataTransferProtocol() throws IOException {
        Random RYXKRCWYWQ = new Random();
        int FURAYWRJCH = 1024 * 1024;
        Path UFWUQKRQOQ = new Path("dataprotocol.dat");
        int NXADRJACTB = 1;
        Configuration FFCRRPEBTC = new HdfsConfiguration();
        FFCRRPEBTC.setInt(DFS_REPLICATION_KEY, NXADRJACTB);
        MiniDFSCluster DZKEQSAWET = new MiniDFSCluster.Builder(FFCRRPEBTC).numDataNodes(NXADRJACTB).build();
        try {
            DZKEQSAWET.waitActive();
            UMWZCOFUEX = DZKEQSAWET.getFileSystem().getDataNodeStats(DatanodeReportType.LIVE)[0];
            KCIJLLNOEM = NetUtils.createSocketAddr(UMWZCOFUEX.getXferAddr());
            FileSystem NJIAHRTFLZ = DZKEQSAWET.getFileSystem();
            int OZSTKOTNMW = Math.min(FFCRRPEBTC.getInt(DFS_BLOCK_SIZE_KEY, 4096), 4096);
            DFSTestUtil.createFile(NJIAHRTFLZ, UFWUQKRQOQ, OZSTKOTNMW, OZSTKOTNMW, NJIAHRTFLZ.getDefaultBlockSize(UFWUQKRQOQ), NJIAHRTFLZ.getDefaultReplication(UFWUQKRQOQ), 0L);
            // get the first blockid for the file
            final ExtendedBlock BOIRGXWMQR = DFSTestUtil.getFirstBlock(NJIAHRTFLZ, UFWUQKRQOQ);
            final String XXKASKXATH = BOIRGXWMQR.getBlockPoolId();
            long LMTGWARSYN = BOIRGXWMQR.getBlockId() + 1;
            FSPTVCMQTX.reset();
            NGBMGWGWCV.reset();
            // bad version
            ORYPUGEINB.writeShort(((short) (DataTransferProtocol.DATA_TRANSFER_VERSION - 1)));
            WJPGVPTECM.writeShort(((short) (DataTransferProtocol.DATA_TRANSFER_VERSION - 1)));
            sendRecvData("Wrong Version", true);
            // bad ops
            NGBMGWGWCV.reset();
            WJPGVPTECM.writeShort(((short) (DATA_TRANSFER_VERSION)));
            WJPGVPTECM.writeByte(WRITE_BLOCK.code - 1);
            sendRecvData("Wrong Op Code", true);
            /* Test OP_WRITE_BLOCK */
            NGBMGWGWCV.reset();
            DataChecksum RLCARSORQJ = Mockito.spy(TestDataTransferProtocol.WKYKDJKNQC);
            Mockito.doReturn(-1).when(RLCARSORQJ).getBytesPerChecksum();
            writeBlock(XXKASKXATH, LMTGWARSYN, RLCARSORQJ);
            FSPTVCMQTX.reset();
            sendResponse(ERROR, null, null, ORYPUGEINB);
            sendRecvData("wrong bytesPerChecksum while writing", true);
            NGBMGWGWCV.reset();
            FSPTVCMQTX.reset();
            writeBlock(XXKASKXATH, ++LMTGWARSYN, TestDataTransferProtocol.WKYKDJKNQC);
            PacketHeader VXCUJANBAD = // size of packet
            // offset in block,
            // seqno
            // last packet
            // bad datalen
            new PacketHeader(4, 0, 100, false, (-1) - RYXKRCWYWQ.nextInt(FURAYWRJCH), false);
            VXCUJANBAD.write(WJPGVPTECM);
            sendResponse(SUCCESS, "", null, ORYPUGEINB);
            new org.apache.hadoop.hdfs.protocol.datatransfer.PipelineAck(100, new Status[]{ Status.ERROR }).write(ORYPUGEINB);
            sendRecvData("negative DATA_CHUNK len while writing block " + LMTGWARSYN, true);
            // test for writing a valid zero size block
            NGBMGWGWCV.reset();
            FSPTVCMQTX.reset();
            writeBlock(XXKASKXATH, ++LMTGWARSYN, TestDataTransferProtocol.WKYKDJKNQC);
            VXCUJANBAD = // size of packet
            // OffsetInBlock
            // sequencenumber
            // lastPacketInBlock
            // chunk length
            new PacketHeader(8, 0, 100, true, 0, false);
            VXCUJANBAD.write(WJPGVPTECM);
            WJPGVPTECM.writeInt(0);
            // zero checksum
            WJPGVPTECM.flush();
            // ok finally write a block with 0 len
            sendResponse(SUCCESS, "", null, ORYPUGEINB);
            new org.apache.hadoop.hdfs.protocol.datatransfer.PipelineAck(100, new Status[]{ Status.SUCCESS }).write(ORYPUGEINB);
            sendRecvData("Writing a zero len block blockid " + LMTGWARSYN, false);
            /* Test OP_READ_BLOCK */
            String JLVAKZWZWN = DZKEQSAWET.getNamesystem().getBlockPoolId();
            ExtendedBlock IICTVGFKJP = new ExtendedBlock(JLVAKZWZWN, BOIRGXWMQR.getLocalBlock());
            long VNBTTHVXLL = IICTVGFKJP.getBlockId();
            // bad block id
            NGBMGWGWCV.reset();
            FSPTVCMQTX.reset();
            IICTVGFKJP.setBlockId(VNBTTHVXLL - 1);
            OONDAJTBCD.readBlock(IICTVGFKJP, DUMMY_TOKEN, "cl", 0L, OZSTKOTNMW, true, CachingStrategy.newDefaultStrategy());
            sendRecvData(("Wrong block ID " + LMTGWARSYN) + " for read", false);
            // negative block start offset -1L
            NGBMGWGWCV.reset();
            IICTVGFKJP.setBlockId(VNBTTHVXLL);
            OONDAJTBCD.readBlock(IICTVGFKJP, DUMMY_TOKEN, "cl", -1L, OZSTKOTNMW, true, CachingStrategy.newDefaultStrategy());
            sendRecvData("Negative start-offset for read for block " + BOIRGXWMQR.getBlockId(), false);
            // bad block start offset
            NGBMGWGWCV.reset();
            OONDAJTBCD.readBlock(IICTVGFKJP, DUMMY_TOKEN, "cl", OZSTKOTNMW, OZSTKOTNMW, true, CachingStrategy.newDefaultStrategy());
            sendRecvData("Wrong start-offset for reading block " + BOIRGXWMQR.getBlockId(), false);
            // negative length is ok. Datanode assumes we want to read the whole block.
            FSPTVCMQTX.reset();
            org.apache.hadoop.hdfs.protocol.proto.DataTransferProtos.BlockOpResponseProto.newBuilder().setStatus(SUCCESS).setReadOpChecksumInfo(org.apache.hadoop.hdfs.protocol.proto.DataTransferProtos.ReadOpChecksumInfoProto.newBuilder().setChecksum(org.apache.hadoop.hdfs.protocol.datatransfer.DataTransferProtoUtil.toProto(TestDataTransferProtocol.WKYKDJKNQC)).setChunkOffset(0L)).build().writeDelimitedTo(ORYPUGEINB);
            NGBMGWGWCV.reset();
            OONDAJTBCD.readBlock(IICTVGFKJP, DUMMY_TOKEN, "cl", 0L, (-1L) - RYXKRCWYWQ.nextInt(FURAYWRJCH), true, CachingStrategy.newDefaultStrategy());
            sendRecvData("Negative length for reading block " + BOIRGXWMQR.getBlockId(), false);
            // length is more than size of block.
            FSPTVCMQTX.reset();
            sendResponse(ERROR, null, (((("opReadBlock " + BOIRGXWMQR) + " received exception java.io.IOException:  ") + "Offset 0 and length 4097 don't match block ") + BOIRGXWMQR) + " ( blockLen 4096 )", ORYPUGEINB);
            NGBMGWGWCV.reset();
            OONDAJTBCD.readBlock(IICTVGFKJP, DUMMY_TOKEN, "cl", 0L, OZSTKOTNMW + 1, true, CachingStrategy.newDefaultStrategy());
            sendRecvData("Wrong length for reading block " + BOIRGXWMQR.getBlockId(), false);
            // At the end of all this, read the file to make sure that succeeds finally.
            NGBMGWGWCV.reset();
            OONDAJTBCD.readBlock(IICTVGFKJP, DUMMY_TOKEN, "cl", 0L, OZSTKOTNMW, true, CachingStrategy.newDefaultStrategy());
            readFile(NJIAHRTFLZ, UFWUQKRQOQ, OZSTKOTNMW);
        } finally {
            DZKEQSAWET.shutdown();
        }
    }

    @Test
    public void testPacketHeader() throws IOException {
        PacketHeader BMNJJWVXBJ = // size of packet
        // OffsetInBlock
        // sequencenumber
        // lastPacketInBlock
        // chunk length
        new PacketHeader(4, 1024, 100, false, 4096, false);
        ByteArrayOutputStream UPYSTFQWBQ = new ByteArrayOutputStream();
        BMNJJWVXBJ.write(new DataOutputStream(UPYSTFQWBQ));
        // Read back using DataInput
        PacketHeader AHEYZNSFCX = new PacketHeader();
        ByteArrayInputStream HYAEDVXKZC = new ByteArrayInputStream(UPYSTFQWBQ.toByteArray());
        AHEYZNSFCX.readFields(new DataInputStream(HYAEDVXKZC));
        assertEquals(BMNJJWVXBJ, AHEYZNSFCX);
        // Read back using ByteBuffer
        AHEYZNSFCX = new PacketHeader();
        AHEYZNSFCX.readFields(ByteBuffer.wrap(UPYSTFQWBQ.toByteArray()));
        assertEquals(BMNJJWVXBJ, AHEYZNSFCX);
        assertTrue(BMNJJWVXBJ.sanityCheck(99));
        assertFalse(BMNJJWVXBJ.sanityCheck(100));
    }

    void writeBlock(String ZFWESEZYIS, long ZMTLNADJTY, DataChecksum TVXXQSFXII) throws IOException {
        writeBlock(new ExtendedBlock(ZFWESEZYIS, ZMTLNADJTY), PIPELINE_SETUP_CREATE, 0L, TVXXQSFXII);
    }

    void writeBlock(ExtendedBlock UFKBDZZMOY, BlockConstructionStage QFFRPUOOLW, long PIQJQNHDAY, DataChecksum GIUEJPACKX) throws IOException {
        OONDAJTBCD.writeBlock(UFKBDZZMOY, DEFAULT, DUMMY_TOKEN, "cl", new DatanodeInfo[1], new StorageType[1], null, QFFRPUOOLW, 0, UFKBDZZMOY.getNumBytes(), UFKBDZZMOY.getNumBytes(), PIQJQNHDAY, GIUEJPACKX, CachingStrategy.newDefaultStrategy());
    }
}