@InterfaceAudience.Private
public class HDFSConcat {
    private static final String XPVCAHFRZD = "hdfs://localhost:9000";

    public static void main(String... XGQIZBKLZS) throws IOException {
        if (XGQIZBKLZS.length < 2) {
            System.err.println("Usage HDFSConcat target srcs..");
            System.exit(0);
        }
        Configuration XJJGKALMTL = new Configuration();
        String TRWGIEZHCN = XJJGKALMTL.get("fs.default.name", HDFSConcat.XPVCAHFRZD);
        Path XVLIIAZGGN = new Path(TRWGIEZHCN);
        DistributedFileSystem RJGPTAZONE = ((DistributedFileSystem) (FileSystem.get(XVLIIAZGGN.toUri(), XJJGKALMTL)));
        Path[] PWMANJFVNW = new Path[XGQIZBKLZS.length - 1];
        for (int XKSJTRRBUV = 1; XKSJTRRBUV < XGQIZBKLZS.length; XKSJTRRBUV++) {
            PWMANJFVNW[XKSJTRRBUV - 1] = new Path(XGQIZBKLZS[XKSJTRRBUV]);
        }
        RJGPTAZONE.concat(new Path(XGQIZBKLZS[0]), PWMANJFVNW);
    }
}