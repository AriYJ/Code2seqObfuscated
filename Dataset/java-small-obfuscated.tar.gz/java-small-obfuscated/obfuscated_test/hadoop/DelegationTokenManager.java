/**
 * Delegation Token Manager used by the
 * {@link KerberosDelegationTokenAuthenticationHandler}.
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
class DelegationTokenManager {
    private static class DelegationTokenSecretManager extends AbstractDelegationTokenSecretManager<DelegationTokenIdentifier> {
        private Text FFIGLJCAOQ;

        public DelegationTokenSecretManager(Text tokenKind, long delegationKeyUpdateInterval, long delegationTokenMaxLifetime, long delegationTokenRenewInterval, long delegationTokenRemoverScanInterval) {
            super(delegationKeyUpdateInterval, delegationTokenMaxLifetime, delegationTokenRenewInterval, delegationTokenRemoverScanInterval);
            this.FFIGLJCAOQ = tokenKind;
        }

        @Override
        public DelegationTokenIdentifier createIdentifier() {
            return new DelegationTokenIdentifier(FFIGLJCAOQ);
        }
    }

    private AbstractDelegationTokenSecretManager BEDLDBBHTE = null;

    private boolean FVMOGNBBRP;

    private Text YPZHAJWXZO;

    public DelegationTokenManager(Text PLZZQPFKQO, long RMKBJFKNMZ, long LSJJSAHSUO, long UVEDSQVMGM, long GMGVYXOYQF) {
        this.BEDLDBBHTE = new DelegationTokenManager.DelegationTokenSecretManager(PLZZQPFKQO, RMKBJFKNMZ, LSJJSAHSUO, UVEDSQVMGM, GMGVYXOYQF);
        this.YPZHAJWXZO = PLZZQPFKQO;
        FVMOGNBBRP = true;
    }

    /**
     * Sets an external <code>DelegationTokenSecretManager</code> instance to
     * manage creation and verification of Delegation Tokens.
     * <p/>
     * This is useful for use cases where secrets must be shared across multiple
     * services.
     *
     * @param secretManager
     * 		a <code>DelegationTokenSecretManager</code> instance
     */
    public void setExternalDelegationTokenSecretManager(AbstractDelegationTokenSecretManager PTQHWNLARX) {
        this.BEDLDBBHTE.stopThreads();
        this.BEDLDBBHTE = PTQHWNLARX;
        this.YPZHAJWXZO = PTQHWNLARX.createIdentifier().getKind();
        FVMOGNBBRP = false;
    }

    public void init() {
        if (FVMOGNBBRP) {
            try {
                BEDLDBBHTE.startThreads();
            } catch (IOException ex) {
                throw new RuntimeException((("Could not start " + BEDLDBBHTE.getClass()) + ": ") + ex.toString(), ex);
            }
        }
    }

    public void destroy() {
        if (FVMOGNBBRP) {
            BEDLDBBHTE.stopThreads();
        }
    }

    @SuppressWarnings("unchecked")
    public Token<DelegationTokenIdentifier> createToken(UserGroupInformation BDHYGWWYGR, String MQZTBZDRAQ) {
        MQZTBZDRAQ = (MQZTBZDRAQ == null) ? BDHYGWWYGR.getShortUserName() : MQZTBZDRAQ;
        String CPOFUVNQPG = BDHYGWWYGR.getUserName();
        Text HJILFAKWFB = new Text(CPOFUVNQPG);
        Text VJDQNFAXCI = null;
        if (BDHYGWWYGR.getRealUser() != null) {
            VJDQNFAXCI = new Text(BDHYGWWYGR.getRealUser().getUserName());
        }
        DelegationTokenIdentifier RXJKXKCPBN = new DelegationTokenIdentifier(YPZHAJWXZO, HJILFAKWFB, new Text(MQZTBZDRAQ), VJDQNFAXCI);
        return new Token<DelegationTokenIdentifier>(RXJKXKCPBN, BEDLDBBHTE);
    }

    @SuppressWarnings("unchecked")
    public long renewToken(Token<DelegationTokenIdentifier> RGZWFTSTEN, String HSIJMKSNUJ) throws IOException {
        return BEDLDBBHTE.renewToken(RGZWFTSTEN, HSIJMKSNUJ);
    }

    @SuppressWarnings("unchecked")
    public void cancelToken(Token<DelegationTokenIdentifier> NCLFSXCRVR, String FATYSFYLHT) throws IOException {
        FATYSFYLHT = (FATYSFYLHT != null) ? FATYSFYLHT : verifyToken(NCLFSXCRVR).getShortUserName();
        BEDLDBBHTE.cancelToken(NCLFSXCRVR, FATYSFYLHT);
    }

    @SuppressWarnings("unchecked")
    public UserGroupInformation verifyToken(Token<DelegationTokenIdentifier> AWDMZJBKBG) throws IOException {
        ByteArrayInputStream GKWGRFMNCW = new ByteArrayInputStream(AWDMZJBKBG.getIdentifier());
        DataInputStream QHYVTNMMWE = new DataInputStream(GKWGRFMNCW);
        DelegationTokenIdentifier BHTKGYIJXH = new DelegationTokenIdentifier(YPZHAJWXZO);
        BHTKGYIJXH.readFields(QHYVTNMMWE);
        QHYVTNMMWE.close();
        BEDLDBBHTE.verifyToken(BHTKGYIJXH, AWDMZJBKBG.getPassword());
        return BHTKGYIJXH.getUser();
    }
}