public class TestCombineOutputCollector {
    private CombineOutputCollector<String, Integer> TRJFBLXFXH;

    Counter EXTLAXGJEN = new Counters.Counter() {
        private long UUOMGCFNXQ;

        @Override
        public void setValue(long value) {
            this.UUOMGCFNXQ = value;
        }

        @Override
        public void setDisplayName(String displayName) {
            // TODO Auto-generated method stub
        }

        @Override
        public void increment(long incr) {
            this.UUOMGCFNXQ += incr;
        }

        @Override
        public long getValue() {
            return UUOMGCFNXQ;
        }

        @Override
        public String getName() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public String getDisplayName() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public String makeEscapedCompactString() {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public long getCounter() {
            return UUOMGCFNXQ;
        }

        @Override
        public boolean contentEquals(Counter counter) {
            // TODO Auto-generated method stub
            return false;
        }

        @Override
        public void write(DataOutput out) throws IOException {
        }

        @Override
        public void readFields(DataInput in) throws IOException {
        }
    };

    @Test
    public void testCustomCollect() throws Throwable {
        // mock creation
        TaskReporter EVWIIDRQAO = mock(TaskReporter.class);
        @SuppressWarnings("unchecked")
        Writer<String, Integer> OKIDSELLFC = mock(Writer.class);
        Configuration NNERSZDDIE = new Configuration();
        NNERSZDDIE.set(COMBINE_RECORDS_BEFORE_PROGRESS, "2");
        TRJFBLXFXH = new CombineOutputCollector<String, Integer>(EXTLAXGJEN, EVWIIDRQAO, NNERSZDDIE);
        TRJFBLXFXH.setWriter(OKIDSELLFC);
        verify(EVWIIDRQAO, never()).progress();
        TRJFBLXFXH.collect("dummy", 1);
        verify(EVWIIDRQAO, never()).progress();
        TRJFBLXFXH.collect("dummy", 2);
        verify(EVWIIDRQAO, times(1)).progress();
    }

    @Test
    public void testDefaultCollect() throws Throwable {
        // mock creation
        TaskReporter NVFTVROIGK = mock(TaskReporter.class);
        @SuppressWarnings("unchecked")
        Writer<String, Integer> OKHERENMFH = mock(Writer.class);
        Configuration DWRQJBLRVZ = new Configuration();
        TRJFBLXFXH = new CombineOutputCollector<String, Integer>(EXTLAXGJEN, NVFTVROIGK, DWRQJBLRVZ);
        TRJFBLXFXH.setWriter(OKHERENMFH);
        verify(NVFTVROIGK, never()).progress();
        for (int EJCFDZMDYE = 0; EJCFDZMDYE < Task.DEFAULT_COMBINE_RECORDS_BEFORE_PROGRESS; EJCFDZMDYE++) {
            TRJFBLXFXH.collect("dummy", EJCFDZMDYE);
        }
        verify(NVFTVROIGK, times(1)).progress();
        for (int PBKUMJXSZZ = 0; PBKUMJXSZZ < Task.DEFAULT_COMBINE_RECORDS_BEFORE_PROGRESS; PBKUMJXSZZ++) {
            TRJFBLXFXH.collect("dummy", PBKUMJXSZZ);
        }
        verify(NVFTVROIGK, times(2)).progress();
    }
}