public class GetTaskReportResponsePBImpl extends ProtoBase<GetTaskReportResponseProto> implements GetTaskReportResponse {
    GetTaskReportResponseProto KLYLDKLJFY = GetTaskReportResponseProto.getDefaultInstance();

    Builder WRDGHBWSYV = null;

    boolean USTMBVIMAA = false;

    private TaskReport PXQRBHLFMM = null;

    public GetTaskReportResponsePBImpl() {
        WRDGHBWSYV = GetTaskReportResponseProto.newBuilder();
    }

    public GetTaskReportResponsePBImpl(GetTaskReportResponseProto BWDSZSGHFY) {
        this.KLYLDKLJFY = BWDSZSGHFY;
        USTMBVIMAA = true;
    }

    public GetTaskReportResponseProto getProto() {
        mergeLocalToProto();
        KLYLDKLJFY = (USTMBVIMAA) ? KLYLDKLJFY : WRDGHBWSYV.build();
        USTMBVIMAA = true;
        return KLYLDKLJFY;
    }

    private void mergeLocalToBuilder() {
        if (this.PXQRBHLFMM != null) {
            WRDGHBWSYV.setTaskReport(convertToProtoFormat(this.PXQRBHLFMM));
        }
    }

    private void mergeLocalToProto() {
        if (USTMBVIMAA)
            maybeInitBuilder();

        mergeLocalToBuilder();
        KLYLDKLJFY = WRDGHBWSYV.build();
        USTMBVIMAA = true;
    }

    private void maybeInitBuilder() {
        if (USTMBVIMAA || (WRDGHBWSYV == null)) {
            WRDGHBWSYV = GetTaskReportResponseProto.newBuilder(KLYLDKLJFY);
        }
        USTMBVIMAA = false;
    }

    @Override
    public TaskReport getTaskReport() {
        GetTaskReportResponseProtoOrBuilder AVFUJVAHHE = (USTMBVIMAA) ? KLYLDKLJFY : WRDGHBWSYV;
        if (this.PXQRBHLFMM != null) {
            return this.PXQRBHLFMM;
        }
        if (!AVFUJVAHHE.hasTaskReport()) {
            return null;
        }
        this.PXQRBHLFMM = convertFromProtoFormat(AVFUJVAHHE.getTaskReport());
        return this.PXQRBHLFMM;
    }

    @Override
    public void setTaskReport(TaskReport BJRXJYIFOM) {
        maybeInitBuilder();
        if (BJRXJYIFOM == null)
            WRDGHBWSYV.clearTaskReport();

        this.PXQRBHLFMM = BJRXJYIFOM;
    }

    private TaskReportPBImpl convertFromProtoFormat(TaskReportProto CBAYUVAAUI) {
        return new TaskReportPBImpl(CBAYUVAAUI);
    }

    private TaskReportProto convertToProtoFormat(TaskReport QRZEAYPHZJ) {
        return ((TaskReportPBImpl) (QRZEAYPHZJ)).getProto();
    }
}