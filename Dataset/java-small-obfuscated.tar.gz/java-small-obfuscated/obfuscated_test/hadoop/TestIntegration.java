public class TestIntegration {
    private static final Log MTELXETXDY = LogFactory.getLog(TestIntegration.class);

    private static FileSystem EFIYZBGVZE;

    private static Path EBKFHQRZBF;

    private static Path XFWHHLGIOU;

    private static String GPTVJYTABH;

    private static Configuration getConf() {
        Configuration VTQBOLLJAV = new Configuration();
        VTQBOLLJAV.set("fs.default.name", "file:///");
        VTQBOLLJAV.set("mapred.job.tracker", "local");
        return VTQBOLLJAV;
    }

    @BeforeClass
    public static void setup() {
        try {
            TestIntegration.EFIYZBGVZE = FileSystem.get(TestIntegration.getConf());
            TestIntegration.EBKFHQRZBF = new Path("target/tmp/listing").makeQualified(TestIntegration.EFIYZBGVZE.getUri(), TestIntegration.EFIYZBGVZE.getWorkingDirectory());
            TestIntegration.XFWHHLGIOU = new Path("target/tmp/target").makeQualified(TestIntegration.EFIYZBGVZE.getUri(), TestIntegration.EFIYZBGVZE.getWorkingDirectory());
            TestIntegration.GPTVJYTABH = new Path("target/tmp").makeQualified(TestIntegration.EFIYZBGVZE.getUri(), TestIntegration.EFIYZBGVZE.getWorkingDirectory()).toString();
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered ", e);
        }
    }

    @Test(timeout = 100000)
    public void testSingleFileMissingTarget() {
        caseSingleFileMissingTarget(false);
        caseSingleFileMissingTarget(true);
    }

    private void caseSingleFileMissingTarget(boolean LFTTGBBQBZ) {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "singlefile1/file1");
            createFiles("singlefile1/file1");
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, false, LFTTGBBQBZ);
            checkResult(TestIntegration.XFWHHLGIOU, 1);
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testSingleFileTargetFile() {
        caseSingleFileTargetFile(false);
        caseSingleFileTargetFile(true);
    }

    private void caseSingleFileTargetFile(boolean OSAWCCIFRN) {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "singlefile1/file1");
            createFiles("singlefile1/file1", "target");
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, false, OSAWCCIFRN);
            checkResult(TestIntegration.XFWHHLGIOU, 1);
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testSingleFileTargetDir() {
        caseSingleFileTargetDir(false);
        caseSingleFileTargetDir(true);
    }

    private void caseSingleFileTargetDir(boolean DLASUTNQPY) {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "singlefile2/file2");
            createFiles("singlefile2/file2");
            mkdirs(TestIntegration.XFWHHLGIOU.toString());
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, true, DLASUTNQPY);
            checkResult(TestIntegration.XFWHHLGIOU, 1, "file2");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testSingleDirTargetMissing() {
        caseSingleDirTargetMissing(false);
        caseSingleDirTargetMissing(true);
    }

    private void caseSingleDirTargetMissing(boolean AHBEYOVXNF) {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "singledir");
            mkdirs(TestIntegration.GPTVJYTABH + "/singledir/dir1");
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, false, AHBEYOVXNF);
            checkResult(TestIntegration.XFWHHLGIOU, 1, "dir1");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testSingleDirTargetPresent() {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "singledir");
            mkdirs(TestIntegration.GPTVJYTABH + "/singledir/dir1");
            mkdirs(TestIntegration.XFWHHLGIOU.toString());
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, true, false);
            checkResult(TestIntegration.XFWHHLGIOU, 1, "singledir/dir1");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testUpdateSingleDirTargetPresent() {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "Usingledir");
            mkdirs(TestIntegration.GPTVJYTABH + "/Usingledir/Udir1");
            mkdirs(TestIntegration.XFWHHLGIOU.toString());
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, true, true);
            checkResult(TestIntegration.XFWHHLGIOU, 1, "Udir1");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testMultiFileTargetPresent() {
        caseMultiFileTargetPresent(false);
        caseMultiFileTargetPresent(true);
    }

    private void caseMultiFileTargetPresent(boolean UWXAUPISZF) {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "multifile/file3", "multifile/file4", "multifile/file5");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            mkdirs(TestIntegration.XFWHHLGIOU.toString());
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, true, UWXAUPISZF);
            checkResult(TestIntegration.XFWHHLGIOU, 3, "file3", "file4", "file5");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testCustomCopyListing() {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "multifile1/file3", "multifile1/file4", "multifile1/file5");
            createFiles("multifile1/file3", "multifile1/file4", "multifile1/file5");
            mkdirs(TestIntegration.XFWHHLGIOU.toString());
            Configuration SGLDVSWGIX = TestIntegration.getConf();
            try {
                SGLDVSWGIX.setClass(CONF_LABEL_COPY_LISTING_CLASS, TestIntegration.CustomCopyListing.class, CopyListing.class);
                DistCpOptions UBWFBKJGGW = new DistCpOptions(Arrays.asList(new Path((TestIntegration.GPTVJYTABH + "/") + "multifile1")), TestIntegration.XFWHHLGIOU);
                UBWFBKJGGW.setSyncFolder(true);
                UBWFBKJGGW.setDeleteMissing(false);
                UBWFBKJGGW.setOverwrite(false);
                try {
                    new DistCp(SGLDVSWGIX, UBWFBKJGGW).execute();
                } catch (Exception e) {
                    TestIntegration.MTELXETXDY.error("Exception encountered ", e);
                    throw new IOException(e);
                }
            } finally {
                SGLDVSWGIX.unset(CONF_LABEL_COPY_LISTING_CLASS);
            }
            checkResult(TestIntegration.XFWHHLGIOU, 2, "file4", "file5");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    private static class CustomCopyListing extends SimpleCopyListing {
        public CustomCopyListing(Configuration configuration, Credentials credentials) {
            super(configuration, credentials);
        }

        @Override
        protected boolean shouldCopy(Path path, DistCpOptions options) {
            return !path.getName().equals("file3");
        }
    }

    @Test(timeout = 100000)
    public void testMultiFileTargetMissing() {
        caseMultiFileTargetMissing(false);
        caseMultiFileTargetMissing(true);
    }

    private void caseMultiFileTargetMissing(boolean PYYIVIJNKY) {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "multifile/file3", "multifile/file4", "multifile/file5");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, false, PYYIVIJNKY);
            checkResult(TestIntegration.XFWHHLGIOU, 3, "file3", "file4", "file5");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testMultiDirTargetPresent() {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "multifile", "singledir");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            mkdirs(TestIntegration.XFWHHLGIOU.toString(), TestIntegration.GPTVJYTABH + "/singledir/dir1");
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, true, false);
            checkResult(TestIntegration.XFWHHLGIOU, 2, "multifile/file3", "multifile/file4", "multifile/file5", "singledir/dir1");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testUpdateMultiDirTargetPresent() {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "Umultifile", "Usingledir");
            createFiles("Umultifile/Ufile3", "Umultifile/Ufile4", "Umultifile/Ufile5");
            mkdirs(TestIntegration.XFWHHLGIOU.toString(), TestIntegration.GPTVJYTABH + "/Usingledir/Udir1");
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, true, true);
            checkResult(TestIntegration.XFWHHLGIOU, 4, "Ufile3", "Ufile4", "Ufile5", "Udir1");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testMultiDirTargetMissing() {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "multifile", "singledir");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            mkdirs(TestIntegration.GPTVJYTABH + "/singledir/dir1");
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, false, false);
            checkResult(TestIntegration.XFWHHLGIOU, 2, "multifile/file3", "multifile/file4", "multifile/file5", "singledir/dir1");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testUpdateMultiDirTargetMissing() {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "multifile", "singledir");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            mkdirs(TestIntegration.GPTVJYTABH + "/singledir/dir1");
            runTest(TestIntegration.EBKFHQRZBF, TestIntegration.XFWHHLGIOU, false, true);
            checkResult(TestIntegration.XFWHHLGIOU, 4, "file3", "file4", "file5", "dir1");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
        }
    }

    @Test(timeout = 100000)
    public void testDeleteMissingInDestination() {
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "srcdir");
            createFiles("srcdir/file1", "dstdir/file1", "dstdir/file2");
            Path CHRLXZAAYL = new Path(TestIntegration.GPTVJYTABH + "/dstdir");
            runTest(TestIntegration.EBKFHQRZBF, CHRLXZAAYL, false, true, true, false);
            checkResult(CHRLXZAAYL, 1, "file1");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while running distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, "target/tmp1");
        }
    }

    @Test(timeout = 100000)
    public void testOverwrite() {
        byte[] IEUCOGQQRN = "contents1".getBytes();
        byte[] WRYGLTGXLN = "contents2".getBytes();
        Assert.assertEquals(IEUCOGQQRN.length, WRYGLTGXLN.length);
        try {
            addEntries(TestIntegration.EBKFHQRZBF, "srcdir");
            createWithContents("srcdir/file1", IEUCOGQQRN);
            createWithContents("dstdir/file1", WRYGLTGXLN);
            Path FFPWRYYCSU = new Path(TestIntegration.GPTVJYTABH + "/dstdir");
            runTest(TestIntegration.EBKFHQRZBF, FFPWRYYCSU, false, false, false, true);
            checkResult(FFPWRYYCSU, 1, "file1");
            // make sure dstdir/file1 has been overwritten with the contents
            // of srcdir/file1
            FSDataInputStream JSDSYTGDQH = TestIntegration.EFIYZBGVZE.open(new Path(TestIntegration.GPTVJYTABH + "/dstdir/file1"));
            byte[] IDJBXCJYUA = new byte[IEUCOGQQRN.length];
            JSDSYTGDQH.readFully(IDJBXCJYUA);
            JSDSYTGDQH.close();
            Assert.assertArrayEquals(IEUCOGQQRN, IDJBXCJYUA);
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while running distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, "target/tmp1");
        }
    }

    @Test(timeout = 100000)
    public void testGlobTargetMissingSingleLevel() {
        try {
            Path INTKSXYJNX = new Path("target/tmp1/listing").makeQualified(TestIntegration.EFIYZBGVZE.getUri(), TestIntegration.EFIYZBGVZE.getWorkingDirectory());
            addEntries(INTKSXYJNX, "*");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            createFiles("singledir/dir2/file6");
            runTest(INTKSXYJNX, TestIntegration.XFWHHLGIOU, false, false);
            checkResult(TestIntegration.XFWHHLGIOU, 2, "multifile/file3", "multifile/file4", "multifile/file5", "singledir/dir2/file6");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while testing distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, "target/tmp1");
        }
    }

    @Test(timeout = 100000)
    public void testUpdateGlobTargetMissingSingleLevel() {
        try {
            Path QSIDBRGDRD = new Path("target/tmp1/listing").makeQualified(TestIntegration.EFIYZBGVZE.getUri(), TestIntegration.EFIYZBGVZE.getWorkingDirectory());
            addEntries(QSIDBRGDRD, "*");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            createFiles("singledir/dir2/file6");
            runTest(QSIDBRGDRD, TestIntegration.XFWHHLGIOU, false, true);
            checkResult(TestIntegration.XFWHHLGIOU, 4, "file3", "file4", "file5", "dir2/file6");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while running distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, "target/tmp1");
        }
    }

    @Test(timeout = 100000)
    public void testGlobTargetMissingMultiLevel() {
        try {
            Path KDPBVOTZNR = new Path("target/tmp1/listing").makeQualified(TestIntegration.EFIYZBGVZE.getUri(), TestIntegration.EFIYZBGVZE.getWorkingDirectory());
            addEntries(KDPBVOTZNR, "*/*");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            createFiles("singledir1/dir3/file7", "singledir1/dir3/file8", "singledir1/dir3/file9");
            runTest(KDPBVOTZNR, TestIntegration.XFWHHLGIOU, false, false);
            checkResult(TestIntegration.XFWHHLGIOU, 4, "file3", "file4", "file5", "dir3/file7", "dir3/file8", "dir3/file9");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while running distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, "target/tmp1");
        }
    }

    @Test(timeout = 100000)
    public void testUpdateGlobTargetMissingMultiLevel() {
        try {
            Path MRFCNEFWOY = new Path("target/tmp1/listing").makeQualified(TestIntegration.EFIYZBGVZE.getUri(), TestIntegration.EFIYZBGVZE.getWorkingDirectory());
            addEntries(MRFCNEFWOY, "*/*");
            createFiles("multifile/file3", "multifile/file4", "multifile/file5");
            createFiles("singledir1/dir3/file7", "singledir1/dir3/file8", "singledir1/dir3/file9");
            runTest(MRFCNEFWOY, TestIntegration.XFWHHLGIOU, false, true);
            checkResult(TestIntegration.XFWHHLGIOU, 6, "file3", "file4", "file5", "file7", "file8", "file9");
        } catch (IOException e) {
            TestIntegration.MTELXETXDY.error("Exception encountered while running distcp", e);
            Assert.fail("distcp failure");
        } finally {
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, TestIntegration.GPTVJYTABH);
            TestDistCpUtils.delete(TestIntegration.EFIYZBGVZE, "target/tmp1");
        }
    }

    @Test(timeout = 100000)
    public void testCleanup() {
        try {
            Path GJAPIVPTDK = new Path("noscheme:///file");
            List<Path> ICJXGMNCYH = new ArrayList<Path>();
            ICJXGMNCYH.add(GJAPIVPTDK);
            DistCpOptions ZIUJNIOMUI = new DistCpOptions(ICJXGMNCYH, TestIntegration.XFWHHLGIOU);
            Configuration KKAUCZFDNL = TestIntegration.getConf();
            Path GDNORFKFKW = JobSubmissionFiles.getStagingDir(new org.apache.hadoop.mapreduce.Cluster(KKAUCZFDNL), KKAUCZFDNL);
            GDNORFKFKW.getFileSystem(KKAUCZFDNL).mkdirs(GDNORFKFKW);
            try {
                new DistCp(KKAUCZFDNL, ZIUJNIOMUI).execute();
            } catch (Throwable t) {
                Assert.assertEquals(GDNORFKFKW.getFileSystem(KKAUCZFDNL).listStatus(GDNORFKFKW).length, 0);
            }
        } catch (Exception e) {
            TestIntegration.MTELXETXDY.error("Exception encountered ", e);
            Assert.fail("testCleanup failed " + e.getMessage());
        }
    }

    private void addEntries(Path XDTYGJUOZD, String... UJVULUNEGA) throws IOException {
        OutputStream GQNHCQILUE = TestIntegration.EFIYZBGVZE.create(XDTYGJUOZD);
        try {
            for (String MYFKVPEIRK : UJVULUNEGA) {
                GQNHCQILUE.write(((TestIntegration.GPTVJYTABH + "/") + MYFKVPEIRK).getBytes());
                GQNHCQILUE.write("\n".getBytes());
            }
        } finally {
            GQNHCQILUE.close();
        }
    }

    private void createFiles(String... XKIEVFADCP) throws IOException {
        for (String EPJPGYLUBV : XKIEVFADCP) {
            OutputStream HLEAIOXWRE = TestIntegration.EFIYZBGVZE.create(new Path((TestIntegration.GPTVJYTABH + "/") + EPJPGYLUBV));
            try {
                HLEAIOXWRE.write(((TestIntegration.GPTVJYTABH + "/") + EPJPGYLUBV).getBytes());
                HLEAIOXWRE.write("\n".getBytes());
            } finally {
                HLEAIOXWRE.close();
            }
        }
    }

    private void createWithContents(String PQRZQFIVXE, byte[] WWHOWARTIE) throws IOException {
        OutputStream DYWIFHMGGP = TestIntegration.EFIYZBGVZE.create(new Path((TestIntegration.GPTVJYTABH + "/") + PQRZQFIVXE));
        try {
            DYWIFHMGGP.write(WWHOWARTIE);
        } finally {
            DYWIFHMGGP.close();
        }
    }

    private void mkdirs(String... PZLULFXQPO) throws IOException {
        for (String VFOMUNZSLE : PZLULFXQPO) {
            TestIntegration.EFIYZBGVZE.mkdirs(new Path(VFOMUNZSLE));
        }
    }

    private void runTest(Path KVYLDAFNLV, Path EEREXTGVGB, boolean PQWAXYNNED, boolean XATKPYTVJV) throws IOException {
        runTest(KVYLDAFNLV, EEREXTGVGB, PQWAXYNNED, XATKPYTVJV, false, false);
    }

    private void runTest(Path UCWLVTCVBN, Path IZDRPMPNEF, boolean FTRYRFIIFF, boolean NDTTFJSIAI, boolean DTISSDGCVV, boolean GFGQHAXDTO) throws IOException {
        DistCpOptions ZXCXJHMIYQ = new DistCpOptions(UCWLVTCVBN, IZDRPMPNEF);
        ZXCXJHMIYQ.setSyncFolder(NDTTFJSIAI);
        ZXCXJHMIYQ.setDeleteMissing(DTISSDGCVV);
        ZXCXJHMIYQ.setOverwrite(GFGQHAXDTO);
        ZXCXJHMIYQ.setTargetPathExists(FTRYRFIIFF);
        try {
            new DistCp(TestIntegration.getConf(), ZXCXJHMIYQ).execute();
        } catch (Exception e) {
            TestIntegration.MTELXETXDY.error("Exception encountered ", e);
            throw new IOException(e);
        }
    }

    private void checkResult(Path TVHVIKCJHR, int ESQQYOVGQC, String... FUHCTWNNVN) throws IOException {
        Assert.assertEquals(ESQQYOVGQC, TestIntegration.EFIYZBGVZE.listStatus(TVHVIKCJHR).length);
        if ((FUHCTWNNVN == null) || (FUHCTWNNVN.length == 0)) {
            Assert.assertTrue(TVHVIKCJHR.toString(), TestIntegration.EFIYZBGVZE.exists(TVHVIKCJHR));
            return;
        }
        for (String IMHOECRZJY : FUHCTWNNVN) {
            Assert.assertTrue(new Path(TVHVIKCJHR, IMHOECRZJY).toString(), TestIntegration.EFIYZBGVZE.exists(new Path(TVHVIKCJHR, IMHOECRZJY)));
        }
    }
}