public class TestRolloverSignerSecretProvider {
    @Test
    public void testGetAndRollSecrets() throws Exception {
        long PQFPHMRJJM = 15 * 1000;// rollover every 15 sec

        byte[] CKYDDASMXD = "doctor".getBytes();
        byte[] PIAEAKYTXF = "who".getBytes();
        byte[] LWUJOCBEAH = "tardis".getBytes();
        TestRolloverSignerSecretProvider.TRolloverSignerSecretProvider FSJISNBUKA = new TestRolloverSignerSecretProvider.TRolloverSignerSecretProvider(new byte[][]{ CKYDDASMXD, PIAEAKYTXF, LWUJOCBEAH });
        try {
            FSJISNBUKA.init(null, PQFPHMRJJM);
            byte[] ERKRDULZWG = FSJISNBUKA.getCurrentSecret();
            byte[][] SECUWPTOIW = FSJISNBUKA.getAllSecrets();
            Assert.assertArrayEquals(CKYDDASMXD, ERKRDULZWG);
            Assert.assertEquals(2, SECUWPTOIW.length);
            Assert.assertArrayEquals(CKYDDASMXD, SECUWPTOIW[0]);
            Assert.assertNull(SECUWPTOIW[1]);
            Thread.sleep(PQFPHMRJJM + 2000);
            ERKRDULZWG = FSJISNBUKA.getCurrentSecret();
            SECUWPTOIW = FSJISNBUKA.getAllSecrets();
            Assert.assertArrayEquals(PIAEAKYTXF, ERKRDULZWG);
            Assert.assertEquals(2, SECUWPTOIW.length);
            Assert.assertArrayEquals(PIAEAKYTXF, SECUWPTOIW[0]);
            Assert.assertArrayEquals(CKYDDASMXD, SECUWPTOIW[1]);
            Thread.sleep(PQFPHMRJJM + 2000);
            ERKRDULZWG = FSJISNBUKA.getCurrentSecret();
            SECUWPTOIW = FSJISNBUKA.getAllSecrets();
            Assert.assertArrayEquals(LWUJOCBEAH, ERKRDULZWG);
            Assert.assertEquals(2, SECUWPTOIW.length);
            Assert.assertArrayEquals(LWUJOCBEAH, SECUWPTOIW[0]);
            Assert.assertArrayEquals(PIAEAKYTXF, SECUWPTOIW[1]);
            Thread.sleep(PQFPHMRJJM + 2000);
        } finally {
            FSJISNBUKA.destroy();
        }
    }

    class TRolloverSignerSecretProvider extends RolloverSignerSecretProvider {
        private byte[][] EMXATATMMN;

        private int VISNNIEITT;

        public TRolloverSignerSecretProvider(byte[][] newSecretSequence) throws Exception {
            super();
            this.EMXATATMMN = newSecretSequence;
            this.VISNNIEITT = 0;
        }

        @Override
        protected byte[] generateNewSecret() {
            return EMXATATMMN[VISNNIEITT++];
        }
    }
}