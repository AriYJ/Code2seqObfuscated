public class RMStateUpdateAppAttemptEvent extends RMStateStoreEvent {
    ApplicationAttemptState AXBVHZEXRT;

    public RMStateUpdateAppAttemptEvent(ApplicationAttemptState AJFQXLKDGY) {
        super(UPDATE_APP_ATTEMPT);
        this.AXBVHZEXRT = AJFQXLKDGY;
    }

    public ApplicationAttemptState getAppAttemptState() {
        return AXBVHZEXRT;
    }
}