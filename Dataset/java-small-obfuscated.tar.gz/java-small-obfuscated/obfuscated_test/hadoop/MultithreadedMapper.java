/**
 * Multithreaded implementation for @link org.apache.hadoop.mapreduce.Mapper.
 * <p>
 * It can be used instead of the default implementation,
 *
 * @unknown org.apache.hadoop.mapred.MapRunner, when the Map operation is not CPU
bound in order to improve throughput.
<p>
Mapper implementations using this MapRunnable must be thread-safe.
<p>
The Map-Reduce job has to be configured with the mapper to use via
{@link #setMapperClass(Configuration, Class)} and
the number of thread the thread-pool can use with the
{@link #getNumberOfThreads(Configuration) method. The default
value is 10 threads.
<p>
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class MultithreadedMapper<K1, V1, K2, V2> extends Mapper<K1, V1, K2, V2> {
    private static final Log AKNYGTMOTO = LogFactory.getLog(MultithreadedMapper.class);

    public static String IPSBRLAGSM = "mapreduce.mapper.multithreadedmapper.threads";

    public static String GHTWVFVMDO = "mapreduce.mapper.multithreadedmapper.mapclass";

    private Class<? extends Mapper<K1, V1, K2, V2>> NGEKZNSYVG;

    private Context KIADQFIHMX;

    private List<MultithreadedMapper<K1, V1, K2, V2>.MapRunner> MYXUZIUHNY;

    /**
     * The number of threads in the thread pool that will run the map function.
     *
     * @param job
     * 		the job
     * @return the number of threads
     */
    public static int getNumberOfThreads(JobContext TIASCBMLXD) {
        return TIASCBMLXD.getConfiguration().getInt(MultithreadedMapper.IPSBRLAGSM, 10);
    }

    /**
     * Set the number of threads in the pool for running maps.
     *
     * @param job
     * 		the job to modify
     * @param threads
     * 		the new number of threads
     */
    public static void setNumberOfThreads(Job WQEWGOKGJJ, int PEUIHIBWMK) {
        WQEWGOKGJJ.getConfiguration().setInt(MultithreadedMapper.IPSBRLAGSM, PEUIHIBWMK);
    }

    /**
     * Get the application's mapper class.
     *
     * @param <K1>
     * 		the map's input key type
     * @param <V1>
     * 		the map's input value type
     * @param <K2>
     * 		the map's output key type
     * @param <V2>
     * 		the map's output value type
     * @param job
     * 		the job
     * @return the mapper class to run
     */
    @SuppressWarnings("unchecked")
    public static <K1, V1, K2, V2> Class<Mapper<K1, V1, K2, V2>> getMapperClass(JobContext VUKOFJRILE) {
        return ((Class<Mapper<K1, V1, K2, V2>>) (VUKOFJRILE.getConfiguration().getClass(MultithreadedMapper.GHTWVFVMDO, Mapper.class)));
    }

    /**
     * Set the application's mapper class.
     *
     * @param <K1>
     * 		the map input key type
     * @param <V1>
     * 		the map input value type
     * @param <K2>
     * 		the map output key type
     * @param <V2>
     * 		the map output value type
     * @param job
     * 		the job to modify
     * @param cls
     * 		the class to use as the mapper
     */
    public static <K1, V1, K2, V2> void setMapperClass(Job XDEUEXMBRG, Class<? extends Mapper<K1, V1, K2, V2>> KLKVIUFADI) {
        if (MultithreadedMapper.class.isAssignableFrom(KLKVIUFADI)) {
            throw new IllegalArgumentException("Can't have recursive " + "MultithreadedMapper instances.");
        }
        XDEUEXMBRG.getConfiguration().setClass(MultithreadedMapper.GHTWVFVMDO, KLKVIUFADI, Mapper.class);
    }

    /**
     * Run the application's maps using a thread pool.
     */
    @Override
    public void run(Context DAYSBNIMDC) throws IOException, InterruptedException {
        KIADQFIHMX = DAYSBNIMDC;
        int FUPTGBKVAI = MultithreadedMapper.getNumberOfThreads(DAYSBNIMDC);
        NGEKZNSYVG = MultithreadedMapper.getMapperClass(DAYSBNIMDC);
        if (MultithreadedMapper.AKNYGTMOTO.isDebugEnabled()) {
            MultithreadedMapper.AKNYGTMOTO.debug(("Configuring multithread runner to use " + FUPTGBKVAI) + " threads");
        }
        MYXUZIUHNY = new ArrayList<MultithreadedMapper<K1, V1, K2, V2>.MapRunner>(FUPTGBKVAI);
        for (int JBNUUVOMGG = 0; JBNUUVOMGG < FUPTGBKVAI; ++JBNUUVOMGG) {
            MultithreadedMapper<K1, V1, K2, V2>.MapRunner CIUULTXWWG = new MapRunner(DAYSBNIMDC);
            CIUULTXWWG.start();
            MYXUZIUHNY.add(JBNUUVOMGG, CIUULTXWWG);
        }
        for (int VKZPDPQAWV = 0; VKZPDPQAWV < FUPTGBKVAI; ++VKZPDPQAWV) {
            MultithreadedMapper<K1, V1, K2, V2>.MapRunner YHHPRHEQSU = MYXUZIUHNY.get(VKZPDPQAWV);
            YHHPRHEQSU.join();
            Throwable CALLBWZVCJ = YHHPRHEQSU.throwable;
            if (CALLBWZVCJ != null) {
                if (CALLBWZVCJ instanceof IOException) {
                    throw ((IOException) (CALLBWZVCJ));
                } else
                    if (CALLBWZVCJ instanceof InterruptedException) {
                        throw ((InterruptedException) (CALLBWZVCJ));
                    } else {
                        throw new RuntimeException(CALLBWZVCJ);
                    }

            }
        }
    }

    private class SubMapRecordReader extends RecordReader<K1, V1> {
        private K1 DHZKTCUVUH;

        private V1 ZKAZKAWHKE;

        private Configuration FVDCNYDCRI;

        @Override
        public void close() throws IOException {
        }

        @Override
        public float getProgress() throws IOException, InterruptedException {
            return 0;
        }

        @Override
        public void initialize(InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
            FVDCNYDCRI = context.getConfiguration();
        }

        @Override
        public boolean nextKeyValue() throws IOException, InterruptedException {
            synchronized(KIADQFIHMX) {
                if (!KIADQFIHMX.nextKeyValue()) {
                    return false;
                }
                DHZKTCUVUH = ReflectionUtils.copy(KIADQFIHMX.getConfiguration(), KIADQFIHMX.getCurrentKey(), DHZKTCUVUH);
                ZKAZKAWHKE = ReflectionUtils.copy(FVDCNYDCRI, KIADQFIHMX.getCurrentValue(), ZKAZKAWHKE);
                return true;
            }
        }

        public K1 getCurrentKey() {
            return DHZKTCUVUH;
        }

        @Override
        public V1 getCurrentValue() {
            return ZKAZKAWHKE;
        }
    }

    private class SubMapRecordWriter extends RecordWriter<K2, V2> {
        @Override
        public void close(TaskAttemptContext context) throws IOException, InterruptedException {
        }

        @Override
        public void write(K2 key, V2 value) throws IOException, InterruptedException {
            synchronized(KIADQFIHMX) {
                KIADQFIHMX.write(key, value);
            }
        }
    }

    private class SubMapStatusReporter extends StatusReporter {
        @Override
        public Counter getCounter(Enum<?> name) {
            return KIADQFIHMX.getCounter(name);
        }

        @Override
        public Counter getCounter(String group, String name) {
            return KIADQFIHMX.getCounter(group, name);
        }

        @Override
        public void progress() {
            KIADQFIHMX.progress();
        }

        @Override
        public void setStatus(String status) {
            KIADQFIHMX.setStatus(status);
        }

        @Override
        public float getProgress() {
            return KIADQFIHMX.getProgress();
        }
    }

    private class MapRunner extends Thread {
        private Mapper<K1, V1, K2, V2> YSTACZKIYV;

        private Context UNEUZEXQVJ;

        private Throwable TJTQQKPFVY;

        private RecordReader<K1, V1> CSYPZFSSCE = new SubMapRecordReader();

        MapRunner(Context context) throws IOException, InterruptedException {
            YSTACZKIYV = ReflectionUtils.newInstance(NGEKZNSYVG, context.getConfiguration());
            MapContext<K1, V1, K2, V2> mapContext = new org.apache.hadoop.mapreduce.task.MapContextImpl<K1, V1, K2, V2>(KIADQFIHMX.getConfiguration(), KIADQFIHMX.getTaskAttemptID(), CSYPZFSSCE, new SubMapRecordWriter(), context.getOutputCommitter(), new SubMapStatusReporter(), KIADQFIHMX.getInputSplit());
            UNEUZEXQVJ = new WrappedMapper<K1, V1, K2, V2>().getMapContext(mapContext);
            CSYPZFSSCE.initialize(context.getInputSplit(), context);
        }

        @Override
        public void run() {
            try {
                YSTACZKIYV.run(UNEUZEXQVJ);
                CSYPZFSSCE.close();
            } catch (Throwable ie) {
                TJTQQKPFVY = ie;
            }
        }
    }
}