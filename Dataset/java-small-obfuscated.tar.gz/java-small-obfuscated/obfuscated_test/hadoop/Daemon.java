/**
 * A thread that has called {@link Thread#setDaemon(boolean)} with true.
 */
@InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
@InterfaceStability.Unstable
public class Daemon extends Thread {
    {
        setDaemon(true);// always a daemon

    }

    /**
     * Provide a factory for named daemon threads,
     * for use in ExecutorServices constructors
     */
    @InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
    public static class DaemonFactory extends Daemon implements ThreadFactory {
        @Override
        public Thread newThread(Runnable runnable) {
            return new Daemon(runnable);
        }
    }

    Runnable IKFICCIBKJ = null;

    /**
     * Construct a daemon thread.
     */
    public Daemon() {
        super();
    }

    /**
     * Construct a daemon thread.
     */
    public Daemon(Runnable NFKYIHVKQR) {
        super(NFKYIHVKQR);
        this.IKFICCIBKJ = NFKYIHVKQR;
        this.setName(((Object) (NFKYIHVKQR)).toString());
    }

    /**
     * Construct a daemon thread to be part of a specified thread group.
     */
    public Daemon(ThreadGroup RPJJLTDWVS, Runnable SKLJQYYPGH) {
        super(RPJJLTDWVS, SKLJQYYPGH);
        this.IKFICCIBKJ = SKLJQYYPGH;
        this.setName(((Object) (SKLJQYYPGH)).toString());
    }

    public Runnable getRunnable() {
        return IKFICCIBKJ;
    }
}