/**
 * A {@link GSet} implementation by {@link HashMap}.
 */
@InterfaceAudience.Private
public class GSetByHashMap<K, E extends K> implements GSet<K, E> {
    private final HashMap<K, E> FGBPHBFWRS;

    public GSetByHashMap(int QOPVFAXHAM, float IKRFPZLDEQ) {
        FGBPHBFWRS = new HashMap<K, E>(QOPVFAXHAM, IKRFPZLDEQ);
    }

    @Override
    public int size() {
        return FGBPHBFWRS.size();
    }

    @Override
    public boolean contains(K RBQNLYGBWM) {
        return FGBPHBFWRS.containsKey(RBQNLYGBWM);
    }

    @Override
    public E get(K KYYRBTGPWI) {
        return FGBPHBFWRS.get(KYYRBTGPWI);
    }

    @Override
    public E put(E TDTSCABZOQ) {
        if (TDTSCABZOQ == null) {
            throw new UnsupportedOperationException("Null element is not supported.");
        }
        return FGBPHBFWRS.put(TDTSCABZOQ, TDTSCABZOQ);
    }

    @Override
    public E remove(K XWMHZBTOHB) {
        return FGBPHBFWRS.remove(XWMHZBTOHB);
    }

    @Override
    public Iterator<E> iterator() {
        return FGBPHBFWRS.values().iterator();
    }

    @Override
    public void clear() {
        FGBPHBFWRS.clear();
    }
}