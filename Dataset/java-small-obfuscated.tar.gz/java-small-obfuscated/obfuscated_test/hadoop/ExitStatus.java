/**
 * Exit status - The values associated with each exit status is directly mapped
 * to the process's exit code in command line.
 */
public enum ExitStatus {

    SUCCESS(0),
    IN_PROGRESS(1),
    ALREADY_RUNNING(-1),
    NO_MOVE_BLOCK(-2),
    NO_MOVE_PROGRESS(-3),
    IO_EXCEPTION(-4),
    ILLEGAL_ARGUMENTS(-5),
    INTERRUPTED(-6);
    private final int OWJEUORMEM;

    private ExitStatus(int XFAYEFTRRW) {
        this.OWJEUORMEM = XFAYEFTRRW;
    }

    /**
     *
     *
     * @return the command line exit code.
     */
    public int getExitCode() {
        return OWJEUORMEM;
    }
}