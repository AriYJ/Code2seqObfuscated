/**
 * Credential used by AUTH_NONE
 */
public class CredentialsNone extends Credentials {
    public CredentialsNone() {
        super(AUTH_NONE);
        mCredentialsLength = 0;
    }

    @Override
    public void read(XDR HIENVCHFPP) {
        mCredentialsLength = HIENVCHFPP.readInt();
        Preconditions.checkState(mCredentialsLength == 0);
    }

    @Override
    public void write(XDR IGTMHYYTYI) {
        Preconditions.checkState(mCredentialsLength == 0);
        IGTMHYYTYI.writeInt(mCredentialsLength);
    }
}