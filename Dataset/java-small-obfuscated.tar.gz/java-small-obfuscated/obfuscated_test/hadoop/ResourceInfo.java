@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ResourceInfo {
    int WMYSKTNJNW;

    int XZZPEVBEXK;

    public ResourceInfo() {
    }

    public ResourceInfo(Resource MMPYCKZEER) {
        WMYSKTNJNW = MMPYCKZEER.getMemory();
        XZZPEVBEXK = MMPYCKZEER.getVirtualCores();
    }

    public int getMemory() {
        return WMYSKTNJNW;
    }

    public int getvCores() {
        return XZZPEVBEXK;
    }

    @Override
    public String toString() {
        return ((("<memory:" + WMYSKTNJNW) + ", vCores:") + XZZPEVBEXK) + ">";
    }

    public void setMemory(int TUHZYEMETT) {
        this.WMYSKTNJNW = TUHZYEMETT;
    }

    public void setvCores(int TFWPGPUCBF) {
        this.XZZPEVBEXK = TFWPGPUCBF;
    }
}