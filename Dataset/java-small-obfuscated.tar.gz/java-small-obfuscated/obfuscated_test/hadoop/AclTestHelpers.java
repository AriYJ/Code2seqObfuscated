/**
 * Helper methods useful for writing ACL tests.
 */
public final class AclTestHelpers {
    /**
     * Create a new AclEntry with scope, type and permission (no name).
     *
     * @param scope
     * 		AclEntryScope scope of the ACL entry
     * @param type
     * 		AclEntryType ACL entry type
     * @param permission
     * 		FsAction set of permissions in the ACL entry
     * @return AclEntry new AclEntry
     */
    public static AclEntry aclEntry(AclEntryScope MLETRPKJBZ, AclEntryType LVPOXRASPI, FsAction GUHQVVMIAB) {
        return new AclEntry.Builder().setScope(MLETRPKJBZ).setType(LVPOXRASPI).setPermission(GUHQVVMIAB).build();
    }

    /**
     * Create a new AclEntry with scope, type, name and permission.
     *
     * @param scope
     * 		AclEntryScope scope of the ACL entry
     * @param type
     * 		AclEntryType ACL entry type
     * @param name
     * 		String optional ACL entry name
     * @param permission
     * 		FsAction set of permissions in the ACL entry
     * @return AclEntry new AclEntry
     */
    public static AclEntry aclEntry(AclEntryScope KBFFIZGDXU, AclEntryType SKPXRCMNDR, String WGLOBQOAUL, FsAction SXFUYFOYWX) {
        return new AclEntry.Builder().setScope(KBFFIZGDXU).setType(SKPXRCMNDR).setName(WGLOBQOAUL).setPermission(SXFUYFOYWX).build();
    }

    /**
     * Create a new AclEntry with scope, type and name (no permission).
     *
     * @param scope
     * 		AclEntryScope scope of the ACL entry
     * @param type
     * 		AclEntryType ACL entry type
     * @param name
     * 		String optional ACL entry name
     * @return AclEntry new AclEntry
     */
    public static AclEntry aclEntry(AclEntryScope TDIOEUKDJC, AclEntryType PZHEYJILGF, String IQXGHIQLCS) {
        return new AclEntry.Builder().setScope(TDIOEUKDJC).setType(PZHEYJILGF).setName(IQXGHIQLCS).build();
    }

    /**
     * Create a new AclEntry with scope and type (no name or permission).
     *
     * @param scope
     * 		AclEntryScope scope of the ACL entry
     * @param type
     * 		AclEntryType ACL entry type
     * @return AclEntry new AclEntry
     */
    public static AclEntry aclEntry(AclEntryScope UJVXZLEIMN, AclEntryType NKAIRABEOF) {
        return new AclEntry.Builder().setScope(UJVXZLEIMN).setType(NKAIRABEOF).build();
    }

    /**
     * Asserts that permission is denied to the given fs/user for the given file.
     *
     * @param fs
     * 		FileSystem to check
     * @param user
     * 		UserGroupInformation owner of fs
     * @param pathToCheck
     * 		Path file to check
     * @throws Exception
     * 		if there is an unexpected error
     */
    public static void assertFilePermissionDenied(FileSystem BCYUMBTLFZ, UserGroupInformation YUWCTTLKDG, Path KSMAEEABTI) throws Exception {
        try {
            DFSTestUtil.readFileBuffer(BCYUMBTLFZ, KSMAEEABTI);
            fail((("expected AccessControlException for user " + YUWCTTLKDG) + ", path = ") + KSMAEEABTI);
        } catch (AccessControlException e) {
            // expected
        }
    }

    /**
     * Asserts that permission is granted to the given fs/user for the given file.
     *
     * @param fs
     * 		FileSystem to check
     * @param user
     * 		UserGroupInformation owner of fs
     * @param pathToCheck
     * 		Path file to check
     * @throws Exception
     * 		if there is an unexpected error
     */
    public static void assertFilePermissionGranted(FileSystem KWWJWTDOWJ, UserGroupInformation ZTWGPDGQSG, Path FPSJMEEDHE) throws Exception {
        try {
            DFSTestUtil.readFileBuffer(KWWJWTDOWJ, FPSJMEEDHE);
        } catch (AccessControlException e) {
            fail((("expected permission granted for user " + ZTWGPDGQSG) + ", path = ") + FPSJMEEDHE);
        }
    }

    /**
     * Asserts the value of the FsPermission bits on the inode of a specific path.
     *
     * @param fs
     * 		FileSystem to use for check
     * @param pathToCheck
     * 		Path inode to check
     * @param perm
     * 		short expected permission bits
     * @throws IOException
     * 		thrown if there is an I/O error
     */
    public static void assertPermission(FileSystem TZDIITRUJW, Path GMPBTZNXSJ, short LIQNGJBQDP) throws IOException {
        short VPCLMICSBM = ((short) (LIQNGJBQDP & 01777));
        FsPermission BICFGOGKOW = TZDIITRUJW.getFileStatus(GMPBTZNXSJ).getPermission();
        assertEquals(VPCLMICSBM, BICFGOGKOW.toShort());
        assertEquals((LIQNGJBQDP & (1 << 12)) != 0, BICFGOGKOW.getAclBit());
    }
}