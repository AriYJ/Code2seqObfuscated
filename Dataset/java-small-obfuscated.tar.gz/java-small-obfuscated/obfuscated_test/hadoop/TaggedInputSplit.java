/**
 * An {@link InputSplit} that tags another InputSplit with extra data for use
 * by {@link DelegatingInputFormat}s and {@link DelegatingMapper}s.
 */
class TaggedInputSplit implements Configurable , InputSplit {
    private Class<? extends InputSplit> SASUKESWMG;

    private InputSplit RGWIBDDZLQ;

    private Class<? extends InputFormat> HCPUFYEEGD;

    private Class<? extends Mapper> TADVSZCAOQ;

    private Configuration KBMWAKUGXA;

    public TaggedInputSplit() {
        // Default constructor.
    }

    /**
     * Creates a new TaggedInputSplit.
     *
     * @param inputSplit
     * 		The InputSplit to be tagged
     * @param conf
     * 		The configuration to use
     * @param inputFormatClass
     * 		The InputFormat class to use for this job
     * @param mapperClass
     * 		The Mapper class to use for this job
     */
    public TaggedInputSplit(InputSplit ISDHBWUQCT, Configuration HSVSDNOLBB, Class<? extends InputFormat> STZMGKBEXE, Class<? extends Mapper> MISRMWCVII) {
        this.SASUKESWMG = ISDHBWUQCT.getClass();
        this.RGWIBDDZLQ = ISDHBWUQCT;
        this.KBMWAKUGXA = HSVSDNOLBB;
        this.HCPUFYEEGD = STZMGKBEXE;
        this.TADVSZCAOQ = MISRMWCVII;
    }

    /**
     * Retrieves the original InputSplit.
     *
     * @return The InputSplit that was tagged
     */
    public InputSplit getInputSplit() {
        return RGWIBDDZLQ;
    }

    /**
     * Retrieves the InputFormat class to use for this split.
     *
     * @return The InputFormat class to use
     */
    public Class<? extends InputFormat> getInputFormatClass() {
        return HCPUFYEEGD;
    }

    /**
     * Retrieves the Mapper class to use for this split.
     *
     * @return The Mapper class to use
     */
    public Class<? extends Mapper> getMapperClass() {
        return TADVSZCAOQ;
    }

    public long getLength() throws IOException {
        return RGWIBDDZLQ.getLength();
    }

    public String[] getLocations() throws IOException {
        return RGWIBDDZLQ.getLocations();
    }

    @SuppressWarnings("unchecked")
    public void readFields(DataInput UQMCPKLAPL) throws IOException {
        SASUKESWMG = ((Class<? extends InputSplit>) (readClass(UQMCPKLAPL)));
        RGWIBDDZLQ = ((InputSplit) (ReflectionUtils.newInstance(SASUKESWMG, KBMWAKUGXA)));
        RGWIBDDZLQ.readFields(UQMCPKLAPL);
        HCPUFYEEGD = ((Class<? extends InputFormat>) (readClass(UQMCPKLAPL)));
        TADVSZCAOQ = ((Class<? extends Mapper>) (readClass(UQMCPKLAPL)));
    }

    private Class<?> readClass(DataInput DZUEAHXIFB) throws IOException {
        String OFNYHNULUT = StringInterner.weakIntern(Text.readString(DZUEAHXIFB));
        try {
            return KBMWAKUGXA.getClassByName(OFNYHNULUT);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("readObject can't find class", e);
        }
    }

    public void write(DataOutput ROMYDEKATN) throws IOException {
        Text.writeString(ROMYDEKATN, SASUKESWMG.getName());
        RGWIBDDZLQ.write(ROMYDEKATN);
        Text.writeString(ROMYDEKATN, HCPUFYEEGD.getName());
        Text.writeString(ROMYDEKATN, TADVSZCAOQ.getName());
    }

    public Configuration getConf() {
        return KBMWAKUGXA;
    }

    public void setConf(Configuration PGONOOGSJY) {
        this.KBMWAKUGXA = PGONOOGSJY;
    }

    @Override
    public String toString() {
        return RGWIBDDZLQ.toString();
    }
}