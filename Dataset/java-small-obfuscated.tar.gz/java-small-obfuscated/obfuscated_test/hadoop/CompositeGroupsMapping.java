/**
 * An implementation of {@link GroupMappingServiceProvider} which
 * composites other group mapping providers for determining group membership.
 * This allows to combine existing provider implementations and composite
 * a virtually new provider without customized development to deal with complex situation.
 */
@InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
@InterfaceStability.Evolving
public class CompositeGroupsMapping implements Configurable , GroupMappingServiceProvider {
    public static final String XPQDGDFVCW = GROUP_MAPPING_CONFIG_PREFIX + ".providers";

    public static final String WMBTYDKLJE = CompositeGroupsMapping.XPQDGDFVCW + ".combined";

    public static final String GEFVTRDEAU = GROUP_MAPPING_CONFIG_PREFIX + ".provider";

    private static final Log FHCXEPFNCR = LogFactory.getLog(CompositeGroupsMapping.class);

    private List<GroupMappingServiceProvider> AOASLMBNYU = new ArrayList<GroupMappingServiceProvider>();

    private Configuration TCSFCHEWAX;

    private boolean ZMNXNWHAPV;

    /**
     * Returns list of groups for a user.
     *
     * @param user
     * 		get groups for this user
     * @return list of groups for a given user
     */
    @Override
    public synchronized List<String> getGroups(String GVJOCQQJZQ) throws IOException {
        Set<String> MMIJSDFBLG = new TreeSet<String>();
        List<String> UZZQACRIKT = null;
        for (GroupMappingServiceProvider QYUCREZCKS : AOASLMBNYU) {
            try {
                UZZQACRIKT = QYUCREZCKS.getGroups(GVJOCQQJZQ);
            } catch (Exception e) {
                // LOG.warn("Exception trying to get groups for user " + user, e);
            }
            if ((UZZQACRIKT != null) && (!UZZQACRIKT.isEmpty())) {
                MMIJSDFBLG.addAll(UZZQACRIKT);
                if (!ZMNXNWHAPV)
                    break;

            }
        }
        List<String> UDKDMZLPEM = new ArrayList<String>(MMIJSDFBLG.size());
        UDKDMZLPEM.addAll(MMIJSDFBLG);
        return UDKDMZLPEM;
    }

    /**
     * Caches groups, no need to do that for this provider
     */
    @Override
    public void cacheGroupsRefresh() throws IOException {
        // does nothing in this provider of user to groups mapping
    }

    /**
     * Adds groups to cache, no need to do that for this provider
     *
     * @param groups
     * 		unused
     */
    @Override
    public void cacheGroupsAdd(List<String> TZGRCYBTDO) throws IOException {
        // does nothing in this provider of user to groups mapping
    }

    @Override
    public synchronized Configuration getConf() {
        return TCSFCHEWAX;
    }

    @Override
    public synchronized void setConf(Configuration IHKMVFTAZR) {
        this.TCSFCHEWAX = IHKMVFTAZR;
        this.ZMNXNWHAPV = IHKMVFTAZR.getBoolean(CompositeGroupsMapping.WMBTYDKLJE, true);
        loadMappingProviders();
    }

    private void loadMappingProviders() {
        String[] KOPJUVQQFH = TCSFCHEWAX.getStrings(CompositeGroupsMapping.XPQDGDFVCW, new String[]{  });
        String LNKSBMCWMH;
        for (String CRDDFZVVJP : KOPJUVQQFH) {
            LNKSBMCWMH = (CompositeGroupsMapping.GEFVTRDEAU + ".") + CRDDFZVVJP;
            Class<?> DMAPDBOYMR = TCSFCHEWAX.getClass(LNKSBMCWMH, null);
            if (DMAPDBOYMR == null) {
                CompositeGroupsMapping.FHCXEPFNCR.error(("The mapping provider, " + CRDDFZVVJP) + " does not have a valid class");
            } else {
                addMappingProvider(CRDDFZVVJP, DMAPDBOYMR);
            }
        }
    }

    private void addMappingProvider(String YDNWENGRFW, Class<?> DURTODRWNL) {
        Configuration CSBEFPWMEV = prepareConf(YDNWENGRFW);
        GroupMappingServiceProvider BVHJNYXTLI = ((GroupMappingServiceProvider) (ReflectionUtils.newInstance(DURTODRWNL, CSBEFPWMEV)));
        AOASLMBNYU.add(BVHJNYXTLI);
    }

    /* For any provider specific configuration properties, such as "hadoop.security.group.mapping.ldap.url" 
    and the like, allow them to be configured as "hadoop.security.group.mapping.provider.PROVIDER-X.ldap.url",
    so that a provider such as LdapGroupsMapping can be used to composite a complex one with other providers.
     */
    private Configuration prepareConf(String FOCBMKFYPT) {
        Configuration TWRWANYSBB = new Configuration();
        Iterator<Map.Entry<String, String>> YVJNGETKDP = TCSFCHEWAX.iterator();
        String PEDNJNNHLP = (CompositeGroupsMapping.GEFVTRDEAU + ".") + FOCBMKFYPT;
        while (YVJNGETKDP.hasNext()) {
            Map.Entry<String, String> VYVWCZZGDZ = YVJNGETKDP.next();
            String CBFMXDTBWL = VYVWCZZGDZ.getKey();
            // get a property like "hadoop.security.group.mapping.provider.PROVIDER-X.ldap.url"
            if (CBFMXDTBWL.startsWith(PEDNJNNHLP) && (!CBFMXDTBWL.equals(PEDNJNNHLP))) {
                // restore to be the one like "hadoop.security.group.mapping.ldap.url"
                // so that can be used by original provider.
                CBFMXDTBWL = CBFMXDTBWL.replace(".provider." + FOCBMKFYPT, "");
                TWRWANYSBB.set(CBFMXDTBWL, VYVWCZZGDZ.getValue());
            }
        } 
        return TWRWANYSBB;
    }
}