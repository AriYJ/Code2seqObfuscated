/**
 * Implementation of the Cormode, Korn, Muthukrishnan, and Srivastava algorithm
 * for streaming calculation of targeted high-percentile epsilon-approximate
 * quantiles.
 *
 * This is a generalization of the earlier work by Greenwald and Khanna (GK),
 * which essentially allows different error bounds on the targeted quantiles,
 * which allows for far more efficient calculation of high-percentiles.
 *
 * See: Cormode, Korn, Muthukrishnan, and Srivastava
 * "Effective Computation of Biased Quantiles over Data Streams" in ICDE 2005
 *
 * Greenwald and Khanna,
 * "Space-efficient online computation of quantile summaries" in SIGMOD 2001
 */
@InterfaceAudience.Private
public class SampleQuantiles {
    /**
     * Total number of items in stream
     */
    private long TGMAXYHTYY = 0;

    /**
     * Current list of sampled items, maintained in sorted order with error bounds
     */
    private LinkedList<SampleQuantiles.SampleItem> CNTDKLLKAM;

    /**
     * Buffers incoming items to be inserted in batch. Items are inserted into
     * the buffer linearly. When the buffer fills, it is flushed into the samples
     * array in its entirety.
     */
    private long[] QUVZQDSVTX = new long[500];

    private int OJPXHEXYAU = 0;

    /**
     * Array of Quantiles that we care about, along with desired error.
     */
    private final Quantile[] HCONYJOGKQ;

    public SampleQuantiles(Quantile[] GNHHIOOYYC) {
        this.HCONYJOGKQ = GNHHIOOYYC;
        this.CNTDKLLKAM = new LinkedList<SampleQuantiles.SampleItem>();
    }

    /**
     * Specifies the allowable error for this rank, depending on which quantiles
     * are being targeted.
     *
     * This is the f(r_i, n) function from the CKMS paper. It's basically how wide
     * the range of this rank can be.
     *
     * @param rank
     * 		the index in the list of samples
     */
    private double allowableError(int DQYRPOFRJB) {
        int PNOEQBYLHC = CNTDKLLKAM.size();
        double ZLQKDBXHDO = PNOEQBYLHC + 1;
        for (Quantile IUCJGTFVXG : HCONYJOGKQ) {
            double TZWAPQBMQF;
            if (DQYRPOFRJB <= (IUCJGTFVXG.quantile * PNOEQBYLHC)) {
                TZWAPQBMQF = ((2.0 * IUCJGTFVXG.error) * (PNOEQBYLHC - DQYRPOFRJB)) / (1.0 - IUCJGTFVXG.quantile);
            } else {
                TZWAPQBMQF = ((2.0 * IUCJGTFVXG.error) * DQYRPOFRJB) / IUCJGTFVXG.quantile;
            }
            if (TZWAPQBMQF < ZLQKDBXHDO) {
                ZLQKDBXHDO = TZWAPQBMQF;
            }
        }
        return ZLQKDBXHDO;
    }

    /**
     * Add a new value from the stream.
     *
     * @param v
     * 		
     */
    public synchronized void insert(long XZZHSNVHSD) {
        QUVZQDSVTX[OJPXHEXYAU] = XZZHSNVHSD;
        OJPXHEXYAU++;
        TGMAXYHTYY++;
        if (OJPXHEXYAU == QUVZQDSVTX.length) {
            insertBatch();
            compress();
        }
    }

    /**
     * Merges items from buffer into the samples array in one pass.
     * This is more efficient than doing an insert on every item.
     */
    private void insertBatch() {
        if (OJPXHEXYAU == 0) {
            return;
        }
        Arrays.sort(QUVZQDSVTX, 0, OJPXHEXYAU);
        // Base case: no samples
        int TJETSHSPWD = 0;
        if (CNTDKLLKAM.size() == 0) {
            SampleQuantiles.SampleItem GJKZODCNOA = new SampleQuantiles.SampleItem(QUVZQDSVTX[0], 1, 0);
            CNTDKLLKAM.add(GJKZODCNOA);
            TJETSHSPWD++;
        }
        ListIterator<SampleQuantiles.SampleItem> EPTUYXVDFX = CNTDKLLKAM.listIterator();
        SampleQuantiles.SampleItem FOEQHTQCGD = EPTUYXVDFX.next();
        for (int SOXBEDINVA = TJETSHSPWD; SOXBEDINVA < OJPXHEXYAU; SOXBEDINVA++) {
            long HKNBGEATHV = QUVZQDSVTX[SOXBEDINVA];
            while ((EPTUYXVDFX.nextIndex() < CNTDKLLKAM.size()) && (FOEQHTQCGD.TCQILEEDQO < HKNBGEATHV)) {
                FOEQHTQCGD = EPTUYXVDFX.next();
            } 
            // If we found that bigger item, back up so we insert ourselves before it
            if (FOEQHTQCGD.TCQILEEDQO > HKNBGEATHV) {
                EPTUYXVDFX.previous();
            }
            // We use different indexes for the edge comparisons, because of the above
            // if statement that adjusts the iterator
            int COFPWHUVTQ;
            if ((EPTUYXVDFX.previousIndex() == 0) || (EPTUYXVDFX.nextIndex() == CNTDKLLKAM.size())) {
                COFPWHUVTQ = 0;
            } else {
                COFPWHUVTQ = ((int) (Math.floor(allowableError(EPTUYXVDFX.nextIndex())))) - 1;
            }
            SampleQuantiles.SampleItem MYSXDPSICJ = new SampleQuantiles.SampleItem(HKNBGEATHV, 1, COFPWHUVTQ);
            EPTUYXVDFX.add(MYSXDPSICJ);
            FOEQHTQCGD = MYSXDPSICJ;
        }
        OJPXHEXYAU = 0;
    }

    /**
     * Try to remove extraneous items from the set of sampled items. This checks
     * if an item is unnecessary based on the desired error bounds, and merges it
     * with the adjacent item if it is.
     */
    private void compress() {
        if (CNTDKLLKAM.size() < 2) {
            return;
        }
        ListIterator<SampleQuantiles.SampleItem> RSYIGDLSYM = CNTDKLLKAM.listIterator();
        SampleQuantiles.SampleItem NRYSBUAFHO = null;
        SampleQuantiles.SampleItem AXWYDOZRBT = RSYIGDLSYM.next();
        while (RSYIGDLSYM.hasNext()) {
            NRYSBUAFHO = AXWYDOZRBT;
            AXWYDOZRBT = RSYIGDLSYM.next();
            if (((NRYSBUAFHO.WGGNJXXUXW + AXWYDOZRBT.WGGNJXXUXW) + AXWYDOZRBT.UOZJHXIRRT) <= allowableError(RSYIGDLSYM.previousIndex())) {
                AXWYDOZRBT.WGGNJXXUXW += NRYSBUAFHO.WGGNJXXUXW;
                // Remove prev. it.remove() kills the last thing returned.
                RSYIGDLSYM.previous();
                RSYIGDLSYM.previous();
                RSYIGDLSYM.remove();
                // it.next() is now equal to next, skip it back forward again
                RSYIGDLSYM.next();
            }
        } 
    }

    /**
     * Get the estimated value at the specified quantile.
     *
     * @param quantile
     * 		Queried quantile, e.g. 0.50 or 0.99.
     * @return Estimated value at that quantile.
     */
    private long query(double XLYIEAFISN) {
        Preconditions.checkState(!CNTDKLLKAM.isEmpty(), "no data in estimator");
        int KYYQSETWDY = 0;
        int DQSNENYEDL = ((int) (XLYIEAFISN * TGMAXYHTYY));
        ListIterator<SampleQuantiles.SampleItem> KBQLFCLPSQ = CNTDKLLKAM.listIterator();
        SampleQuantiles.SampleItem PDHXEUAAQZ = null;
        SampleQuantiles.SampleItem NZUURANLCI = KBQLFCLPSQ.next();
        for (int EVJEIAIDMB = 1; EVJEIAIDMB < CNTDKLLKAM.size(); EVJEIAIDMB++) {
            PDHXEUAAQZ = NZUURANLCI;
            NZUURANLCI = KBQLFCLPSQ.next();
            KYYQSETWDY += PDHXEUAAQZ.WGGNJXXUXW;
            if (((KYYQSETWDY + NZUURANLCI.WGGNJXXUXW) + NZUURANLCI.UOZJHXIRRT) > (DQSNENYEDL + (allowableError(EVJEIAIDMB) / 2))) {
                return PDHXEUAAQZ.TCQILEEDQO;
            }
        }
        // edge case of wanting max value
        return CNTDKLLKAM.get(CNTDKLLKAM.size() - 1).TCQILEEDQO;
    }

    /**
     * Get a snapshot of the current values of all the tracked quantiles.
     *
     * @return snapshot of the tracked quantiles. If no items are added
    to the estimator, returns null.
     */
    public synchronized Map<Quantile, Long> snapshot() {
        // flush the buffer first for best results
        insertBatch();
        if (CNTDKLLKAM.isEmpty()) {
            return null;
        }
        Map<Quantile, Long> YOBDJQXXTE = new TreeMap<Quantile, Long>();
        for (int LUJTCISFMA = 0; LUJTCISFMA < HCONYJOGKQ.length; LUJTCISFMA++) {
            YOBDJQXXTE.put(HCONYJOGKQ[LUJTCISFMA], query(HCONYJOGKQ[LUJTCISFMA].quantile));
        }
        return YOBDJQXXTE;
    }

    /**
     * Returns the number of items that the estimator has processed
     *
     * @return count total number of items processed
     */
    public synchronized long getCount() {
        return TGMAXYHTYY;
    }

    /**
     * Returns the number of samples kept by the estimator
     *
     * @return count current number of samples
     */
    @VisibleForTesting
    public synchronized int getSampleCount() {
        return CNTDKLLKAM.size();
    }

    /**
     * Resets the estimator, clearing out all previously inserted items
     */
    public synchronized void clear() {
        TGMAXYHTYY = 0;
        OJPXHEXYAU = 0;
        CNTDKLLKAM.clear();
    }

    @Override
    public synchronized String toString() {
        Map<Quantile, Long> TCICXAMUQB = snapshot();
        if (TCICXAMUQB == null) {
            return "[no samples]";
        } else {
            return com.google.common.base.Joiner.on("\n").withKeyValueSeparator(": ").join(TCICXAMUQB);
        }
    }

    /**
     * Describes a measured value passed to the estimator, tracking additional
     * metadata required by the CKMS algorithm.
     */
    private static class SampleItem {
        /**
         * Value of the sampled item (e.g. a measured latency value)
         */
        public final long TCQILEEDQO;

        /**
         * Difference between the lowest possible rank of the previous item, and
         * the lowest possible rank of this item.
         *
         * The sum of the g of all previous items yields this item's lower bound.
         */
        public int WGGNJXXUXW;

        /**
         * Difference between the item's greatest possible rank and lowest possible
         * rank.
         */
        public final int UOZJHXIRRT;

        public SampleItem(long value, int lowerDelta, int delta) {
            this.TCQILEEDQO = value;
            this.WGGNJXXUXW = lowerDelta;
            this.UOZJHXIRRT = delta;
        }

        @Override
        public String toString() {
            return String.format("%d, %d, %d", TCQILEEDQO, WGGNJXXUXW, UOZJHXIRRT);
        }
    }
}