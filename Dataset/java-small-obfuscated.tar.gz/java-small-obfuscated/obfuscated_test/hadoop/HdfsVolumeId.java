/**
 * HDFS-specific volume identifier which implements {@link VolumeId}. Can be
 * used to differentiate between the data directories on a single datanode. This
 * identifier is only unique on a per-datanode basis.
 */
@InterfaceStability.Unstable
@InterfaceAudience.Public
public class HdfsVolumeId implements VolumeId {
    private final byte[] DBQQKUVVQS;

    public HdfsVolumeId(byte[] ZRQVYDYFYO) {
        Preconditions.checkNotNull(ZRQVYDYFYO, "id cannot be null");
        this.DBQQKUVVQS = ZRQVYDYFYO;
    }

    @Override
    public int compareTo(VolumeId IBEBFOOWBR) {
        if (IBEBFOOWBR == null) {
            return 1;
        }
        return hashCode() - IBEBFOOWBR.hashCode();
    }

    @Override
    public int hashCode() {
        return new org.apache.commons.lang.builder.HashCodeBuilder().append(DBQQKUVVQS).toHashCode();
    }

    @Override
    public boolean equals(Object SSNXGNBIQR) {
        if ((SSNXGNBIQR == null) || (SSNXGNBIQR.getClass() != getClass())) {
            return false;
        }
        if (SSNXGNBIQR == this) {
            return true;
        }
        HdfsVolumeId ZALMUKHICM = ((HdfsVolumeId) (SSNXGNBIQR));
        return new org.apache.commons.lang.builder.EqualsBuilder().append(this.DBQQKUVVQS, ZALMUKHICM.DBQQKUVVQS).isEquals();
    }

    @Override
    public String toString() {
        return StringUtils.byteToHexString(DBQQKUVVQS);
    }
}