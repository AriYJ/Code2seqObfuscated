public class TestProtoUtil {
    /**
     * Values to test encoding as variable length integers
     */
    private static final int[] VLZPABRNYM = new int[]{ 0, 1, -1, 127, 128, 129, 255, 256, 257, 0x1234, -0x1234, 0x123456, -0x123456, 0x12345678, -0x12345678 };

    /**
     * Test that readRawVarint32 is compatible with the varints encoded
     * by ProtoBuf's CodedOutputStream.
     */
    @Test
    public void testVarInt() throws IOException {
        // Test a few manufactured values
        for (int FLIQQNDVXU : TestProtoUtil.VLZPABRNYM) {
            doVarIntTest(FLIQQNDVXU);
        }
        // Check 1-bits at every bit position
        for (int WBWRHBMMMR = 1; WBWRHBMMMR != 0; WBWRHBMMMR <<= 1) {
            doVarIntTest(WBWRHBMMMR);
            doVarIntTest(-WBWRHBMMMR);
            doVarIntTest(WBWRHBMMMR - 1);
            doVarIntTest(~WBWRHBMMMR);
        }
    }

    private void doVarIntTest(int IZNMSOCIAH) throws IOException {
        ByteArrayOutputStream BUUABQZPFZ = new ByteArrayOutputStream();
        CodedOutputStream GAIICCTKYI = CodedOutputStream.newInstance(BUUABQZPFZ);
        GAIICCTKYI.writeRawVarint32(IZNMSOCIAH);
        GAIICCTKYI.flush();
        DataInputStream KNACSRIGLE = new DataInputStream(new ByteArrayInputStream(BUUABQZPFZ.toByteArray()));
        assertEquals(IZNMSOCIAH, ProtoUtil.readRawVarint32(KNACSRIGLE));
    }

    @Test
    public void testRpcClientId() {
        byte[] WPCRJAPLOH = ClientId.getClientId();
        RpcRequestHeaderProto YHZKAVGHGL = ProtoUtil.makeRpcRequestHeader(RPC_PROTOCOL_BUFFER, RPC_FINAL_PACKET, 0, INVALID_RETRY_COUNT, WPCRJAPLOH);
        assertTrue(Arrays.equals(WPCRJAPLOH, YHZKAVGHGL.getClientId().toByteArray()));
    }
}