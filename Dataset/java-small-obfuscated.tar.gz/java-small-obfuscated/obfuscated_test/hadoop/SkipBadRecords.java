/**
 * Utility class for skip bad records functionality. It contains various
 * settings related to skipping of bad records.
 *
 * <p>Hadoop provides an optional mode of execution in which the bad records
 * are detected and skipped in further attempts.
 *
 * <p>This feature can be used when map/reduce tasks crashes deterministically on
 * certain input. This happens due to bugs in the map/reduce function. The usual
 * course would be to fix these bugs. But sometimes this is not possible;
 * perhaps the bug is in third party libraries for which the source code is
 * not available. Due to this, the task never reaches to completion even with
 * multiple attempts and complete data for that task is lost.</p>
 *
 * <p>With this feature, only a small portion of data is lost surrounding
 * the bad record, which may be acceptable for some user applications.
 * see {@link SkipBadRecords#setMapperMaxSkipRecords(Configuration, long)}</p>
 *
 * <p>The skipping mode gets kicked off after certain no of failures
 * see {@link SkipBadRecords#setAttemptsToStartSkipping(Configuration, int)}</p>
 *
 * <p>In the skipping mode, the map/reduce task maintains the record range which
 * is getting processed at all times. Before giving the input to the
 * map/reduce function, it sends this record range to the Task tracker.
 * If task crashes, the Task tracker knows which one was the last reported
 * range. On further attempts that range get skipped.</p>
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class SkipBadRecords {
    /**
     * Special counters which are written by the application and are
     * used by the framework for detecting bad records. For detecting bad records
     * these counters must be incremented by the application.
     */
    public static final String DFXMANTYEF = "SkippingTaskCounters";

    /**
     * Number of processed map records.
     *
     * @see SkipBadRecords#getAutoIncrMapperProcCount(Configuration)
     */
    public static final String WBFOZGZPRJ = "MapProcessedRecords";

    /**
     * Number of processed reduce groups.
     *
     * @see SkipBadRecords#getAutoIncrReducerProcCount(Configuration)
     */
    public static final String DZUMTEPRHI = "ReduceProcessedGroups";

    private static final String XTRSTLYPSA = JobContext.SKIP_START_ATTEMPTS;

    private static final String YFYPHNNFND = JobContext.MAP_SKIP_INCR_PROC_COUNT;

    private static final String HREJWOPWJS = JobContext.REDUCE_SKIP_INCR_PROC_COUNT;

    private static final String ITTENAFDDC = JobContext.SKIP_OUTDIR;

    private static final String EODPWYFRPJ = JobContext.MAP_SKIP_MAX_RECORDS;

    private static final String VBNNPSEJKP = JobContext.REDUCE_SKIP_MAXGROUPS;

    /**
     * Get the number of Task attempts AFTER which skip mode
     * will be kicked off. When skip mode is kicked off, the
     * tasks reports the range of records which it will process
     * next to the TaskTracker. So that on failures, TT knows which
     * ones are possibly the bad records. On further executions,
     * those are skipped.
     * Default value is 2.
     *
     * @param conf
     * 		the configuration
     * @return attemptsToStartSkipping no of task attempts
     */
    public static int getAttemptsToStartSkipping(Configuration HKEJLSDHLX) {
        return HKEJLSDHLX.getInt(SkipBadRecords.XTRSTLYPSA, 2);
    }

    /**
     * Set the number of Task attempts AFTER which skip mode
     * will be kicked off. When skip mode is kicked off, the
     * tasks reports the range of records which it will process
     * next to the TaskTracker. So that on failures, TT knows which
     * ones are possibly the bad records. On further executions,
     * those are skipped.
     * Default value is 2.
     *
     * @param conf
     * 		the configuration
     * @param attemptsToStartSkipping
     * 		no of task attempts
     */
    public static void setAttemptsToStartSkipping(Configuration HGAUVQQCNP, int QUHOMSRYEH) {
        HGAUVQQCNP.setInt(SkipBadRecords.XTRSTLYPSA, QUHOMSRYEH);
    }

    /**
     * Get the flag which if set to true,
     * {@link SkipBadRecords#COUNTER_MAP_PROCESSED_RECORDS} is incremented
     * by MapRunner after invoking the map function. This value must be set to
     * false for applications which process the records asynchronously
     * or buffer the input records. For example streaming.
     * In such cases applications should increment this counter on their own.
     * Default value is true.
     *
     * @param conf
     * 		the configuration
     * @return <code>true</code> if auto increment
    {@link SkipBadRecords#COUNTER_MAP_PROCESSED_RECORDS}.
    <code>false</code> otherwise.
     */
    public static boolean getAutoIncrMapperProcCount(Configuration LLGJHLDIJO) {
        return LLGJHLDIJO.getBoolean(SkipBadRecords.YFYPHNNFND, true);
    }

    /**
     * Set the flag which if set to true,
     * {@link SkipBadRecords#COUNTER_MAP_PROCESSED_RECORDS} is incremented
     * by MapRunner after invoking the map function. This value must be set to
     * false for applications which process the records asynchronously
     * or buffer the input records. For example streaming.
     * In such cases applications should increment this counter on their own.
     * Default value is true.
     *
     * @param conf
     * 		the configuration
     * @param autoIncr
     * 		whether to auto increment
     * 		{@link SkipBadRecords#COUNTER_MAP_PROCESSED_RECORDS}.
     */
    public static void setAutoIncrMapperProcCount(Configuration DCXUPCRGRZ, boolean JLKPLQEAUI) {
        DCXUPCRGRZ.setBoolean(SkipBadRecords.YFYPHNNFND, JLKPLQEAUI);
    }

    /**
     * Get the flag which if set to true,
     * {@link SkipBadRecords#COUNTER_REDUCE_PROCESSED_GROUPS} is incremented
     * by framework after invoking the reduce function. This value must be set to
     * false for applications which process the records asynchronously
     * or buffer the input records. For example streaming.
     * In such cases applications should increment this counter on their own.
     * Default value is true.
     *
     * @param conf
     * 		the configuration
     * @return <code>true</code> if auto increment
    {@link SkipBadRecords#COUNTER_REDUCE_PROCESSED_GROUPS}.
    <code>false</code> otherwise.
     */
    public static boolean getAutoIncrReducerProcCount(Configuration TPTKRDMTTC) {
        return TPTKRDMTTC.getBoolean(SkipBadRecords.HREJWOPWJS, true);
    }

    /**
     * Set the flag which if set to true,
     * {@link SkipBadRecords#COUNTER_REDUCE_PROCESSED_GROUPS} is incremented
     * by framework after invoking the reduce function. This value must be set to
     * false for applications which process the records asynchronously
     * or buffer the input records. For example streaming.
     * In such cases applications should increment this counter on their own.
     * Default value is true.
     *
     * @param conf
     * 		the configuration
     * @param autoIncr
     * 		whether to auto increment
     * 		{@link SkipBadRecords#COUNTER_REDUCE_PROCESSED_GROUPS}.
     */
    public static void setAutoIncrReducerProcCount(Configuration IUZXZNFFGG, boolean FNLRMJOYEW) {
        IUZXZNFFGG.setBoolean(SkipBadRecords.HREJWOPWJS, FNLRMJOYEW);
    }

    /**
     * Get the directory to which skipped records are written. By default it is
     * the sub directory of the output _logs directory.
     * User can stop writing skipped records by setting the value null.
     *
     * @param conf
     * 		the configuration.
     * @return path skip output directory. Null is returned if this is not set
    and output directory is also not set.
     */
    public static Path getSkipOutputPath(Configuration YQIITSGSNS) {
        String UASUGAUOLO = YQIITSGSNS.get(SkipBadRecords.ITTENAFDDC);
        if (UASUGAUOLO != null) {
            if ("none".equals(UASUGAUOLO)) {
                return null;
            }
            return new Path(UASUGAUOLO);
        }
        Path CVOODHYXCQ = FileOutputFormat.getOutputPath(new JobConf(YQIITSGSNS));
        return CVOODHYXCQ == null ? null : new Path(CVOODHYXCQ, ("_logs" + Path.SEPARATOR) + "skip");
    }

    /**
     * Set the directory to which skipped records are written. By default it is
     * the sub directory of the output _logs directory.
     * User can stop writing skipped records by setting the value null.
     *
     * @param conf
     * 		the configuration.
     * @param path
     * 		skip output directory path
     */
    public static void setSkipOutputPath(JobConf ZFBWWBERDH, Path EGABXNOGMG) {
        String JPMLFRHNJR = null;
        if (EGABXNOGMG == null) {
            JPMLFRHNJR = "none";
        } else {
            JPMLFRHNJR = EGABXNOGMG.toString();
        }
        ZFBWWBERDH.set(SkipBadRecords.ITTENAFDDC, JPMLFRHNJR);
    }

    /**
     * Get the number of acceptable skip records surrounding the bad record PER
     * bad record in mapper. The number includes the bad record as well.
     * To turn the feature of detection/skipping of bad records off, set the
     * value to 0.
     * The framework tries to narrow down the skipped range by retrying
     * until this threshold is met OR all attempts get exhausted for this task.
     * Set the value to Long.MAX_VALUE to indicate that framework need not try to
     * narrow down. Whatever records(depends on application) get skipped are
     * acceptable.
     * Default value is 0.
     *
     * @param conf
     * 		the configuration
     * @return maxSkipRecs acceptable skip records.
     */
    public static long getMapperMaxSkipRecords(Configuration FXGYJFJNIF) {
        return FXGYJFJNIF.getLong(SkipBadRecords.EODPWYFRPJ, 0);
    }

    /**
     * Set the number of acceptable skip records surrounding the bad record PER
     * bad record in mapper. The number includes the bad record as well.
     * To turn the feature of detection/skipping of bad records off, set the
     * value to 0.
     * The framework tries to narrow down the skipped range by retrying
     * until this threshold is met OR all attempts get exhausted for this task.
     * Set the value to Long.MAX_VALUE to indicate that framework need not try to
     * narrow down. Whatever records(depends on application) get skipped are
     * acceptable.
     * Default value is 0.
     *
     * @param conf
     * 		the configuration
     * @param maxSkipRecs
     * 		acceptable skip records.
     */
    public static void setMapperMaxSkipRecords(Configuration TZLGFLVXVA, long CBATZSUCMN) {
        TZLGFLVXVA.setLong(SkipBadRecords.EODPWYFRPJ, CBATZSUCMN);
    }

    /**
     * Get the number of acceptable skip groups surrounding the bad group PER
     * bad group in reducer. The number includes the bad group as well.
     * To turn the feature of detection/skipping of bad groups off, set the
     * value to 0.
     * The framework tries to narrow down the skipped range by retrying
     * until this threshold is met OR all attempts get exhausted for this task.
     * Set the value to Long.MAX_VALUE to indicate that framework need not try to
     * narrow down. Whatever groups(depends on application) get skipped are
     * acceptable.
     * Default value is 0.
     *
     * @param conf
     * 		the configuration
     * @return maxSkipGrps acceptable skip groups.
     */
    public static long getReducerMaxSkipGroups(Configuration UQCPYOGLHZ) {
        return UQCPYOGLHZ.getLong(SkipBadRecords.VBNNPSEJKP, 0);
    }

    /**
     * Set the number of acceptable skip groups surrounding the bad group PER
     * bad group in reducer. The number includes the bad group as well.
     * To turn the feature of detection/skipping of bad groups off, set the
     * value to 0.
     * The framework tries to narrow down the skipped range by retrying
     * until this threshold is met OR all attempts get exhausted for this task.
     * Set the value to Long.MAX_VALUE to indicate that framework need not try to
     * narrow down. Whatever groups(depends on application) get skipped are
     * acceptable.
     * Default value is 0.
     *
     * @param conf
     * 		the configuration
     * @param maxSkipGrps
     * 		acceptable skip groups.
     */
    public static void setReducerMaxSkipGroups(Configuration LVPDIOPWVP, long UIFPAPRTDO) {
        LVPDIOPWVP.setLong(SkipBadRecords.VBNNPSEJKP, UIFPAPRTDO);
    }
}