public class TestFairSchedulerQueueACLs extends QueueACLsTestBase {
    @Override
    protected Configuration createConfiguration() throws IOException {
        FairSchedulerConfiguration QKHNNIXTZK = new FairSchedulerConfiguration();
        final String TZWMLNFTNB = new File(System.getProperty("test.build.data", "/tmp")).getAbsolutePath();
        final String JIMVJJHPKP = new File(TZWMLNFTNB, "test-queues.xml").getAbsolutePath();
        PrintWriter DIZUVREFNW = new PrintWriter(new FileWriter(JIMVJJHPKP));
        DIZUVREFNW.println("<?xml version=\"1.0\"?>");
        DIZUVREFNW.println("<allocations>");
        DIZUVREFNW.println("<queue name=\"root\">");
        DIZUVREFNW.println("  <aclSubmitApps> </aclSubmitApps>");
        DIZUVREFNW.println("  <aclAdministerApps>root_admin </aclAdministerApps>");
        DIZUVREFNW.println("  <queue name=\"queueA\">");
        DIZUVREFNW.println("    <aclSubmitApps>queueA_user,common_user </aclSubmitApps>");
        DIZUVREFNW.println("    <aclAdministerApps>queueA_admin </aclAdministerApps>");
        DIZUVREFNW.println("  </queue>");
        DIZUVREFNW.println("  <queue name=\"queueB\">");
        DIZUVREFNW.println("    <aclSubmitApps>queueB_user,common_user </aclSubmitApps>");
        DIZUVREFNW.println("    <aclAdministerApps>queueB_admin </aclAdministerApps>");
        DIZUVREFNW.println("  </queue>");
        DIZUVREFNW.println("</queue>");
        DIZUVREFNW.println("</allocations>");
        DIZUVREFNW.close();
        QKHNNIXTZK.set(ALLOCATION_FILE, JIMVJJHPKP);
        QKHNNIXTZK.setBoolean(YARN_ACL_ENABLE, true);
        QKHNNIXTZK.set("yarn.resourcemanager.scheduler.class", FairScheduler.class.getName());
        return QKHNNIXTZK;
    }
}