/**
 * A Writable class for Summation
 */
public final class SummationWritable implements Container<Summation> , WritableComparable<SummationWritable> {
    private Summation DKLHGVHFIT;

    public SummationWritable() {
    }

    SummationWritable(Summation QYNHSZAKUX) {
        this.DKLHGVHFIT = QYNHSZAKUX;
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public String toString() {
        return getClass().getSimpleName() + DKLHGVHFIT;
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public Summation getElement() {
        return DKLHGVHFIT;
    }

    /**
     * Read sigma from conf
     */
    public static Summation read(Class<?> KBFHICYWKF, Configuration WZLVFKSYSV) {
        return Summation.valueOf(WZLVFKSYSV.get(KBFHICYWKF.getSimpleName() + ".sigma"));
    }

    /**
     * Write sigma to conf
     */
    public static void write(Summation PINTMSPTKH, Class<?> NIJJFFGSLC, Configuration YIWNSLODVP) {
        YIWNSLODVP.set(NIJJFFGSLC.getSimpleName() + ".sigma", PINTMSPTKH.toString());
    }

    /**
     * Read Summation from DataInput
     */
    static Summation read(DataInput RKLZUOIYUJ) throws IOException {
        final SummationWritable XVFKTXUAFU = new SummationWritable();
        XVFKTXUAFU.readFields(RKLZUOIYUJ);
        return XVFKTXUAFU.getElement();
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public void readFields(DataInput PVXHOZFJFF) throws IOException {
        final ArithmeticProgression DSOJQPAAEH = SummationWritable.ArithmeticProgressionWritable.read(PVXHOZFJFF);
        final ArithmeticProgression ABSZVTLRTY = SummationWritable.ArithmeticProgressionWritable.read(PVXHOZFJFF);
        DKLHGVHFIT = new Summation(DSOJQPAAEH, ABSZVTLRTY);
        if (PVXHOZFJFF.readBoolean()) {
            DKLHGVHFIT.setValue(PVXHOZFJFF.readDouble());
        }
    }

    /**
     * Write sigma to DataOutput
     */
    public static void write(Summation GSCOXLZZWZ, DataOutput GNFCBFLVBC) throws IOException {
        SummationWritable.ArithmeticProgressionWritable.write(GSCOXLZZWZ.N, GNFCBFLVBC);
        SummationWritable.ArithmeticProgressionWritable.write(GSCOXLZZWZ.E, GNFCBFLVBC);
        final Double LTKTXXGVYU = GSCOXLZZWZ.getValue();
        if (LTKTXXGVYU == null)
            GNFCBFLVBC.writeBoolean(false);
        else {
            GNFCBFLVBC.writeBoolean(true);
            GNFCBFLVBC.writeDouble(LTKTXXGVYU);
        }
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public void write(DataOutput ZHYWTXIVBF) throws IOException {
        SummationWritable.write(DKLHGVHFIT, ZHYWTXIVBF);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public int compareTo(SummationWritable TYPPMTIYWB) {
        return this.DKLHGVHFIT.compareTo(TYPPMTIYWB.DKLHGVHFIT);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public boolean equals(Object OFNSEHLNDN) {
        if (this == OFNSEHLNDN)
            return true;
        else
            if ((OFNSEHLNDN != null) && (OFNSEHLNDN instanceof SummationWritable)) {
                final SummationWritable EYNFZMJOPZ = ((SummationWritable) (OFNSEHLNDN));
                return this.compareTo(EYNFZMJOPZ) == 0;
            }

        throw new IllegalArgumentException(OFNSEHLNDN == null ? "obj == null" : "obj.getClass()=" + OFNSEHLNDN.getClass());
    }

    /**
     * Not supported
     */
    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }

    /**
     * A writable class for ArithmeticProgression
     */
    private static class ArithmeticProgressionWritable {
        /**
         * Read ArithmeticProgression from DataInput
         */
        private static ArithmeticProgression read(DataInput in) throws IOException {
            return new ArithmeticProgression(in.readChar(), in.readLong(), in.readLong(), in.readLong());
        }

        /**
         * Write ArithmeticProgression to DataOutput
         */
        private static void write(ArithmeticProgression ap, DataOutput out) throws IOException {
            out.writeChar(ap.symbol);
            out.writeLong(ap.value);
            out.writeLong(ap.delta);
            out.writeLong(ap.limit);
        }
    }
}