public class TestReservedRawPaths {
    private Configuration NWJAOSUGPH;

    private FileSystemTestHelper NXVNBTEZER;

    private MiniDFSCluster UFVNLEECYV;

    private HdfsAdmin KOZDBFKXAO;

    private DistributedFileSystem UPRJASBULQ;

    private final String SWIVRQQTDJ = "testKey";

    protected FileSystemTestWrapper MCHCTWOMIG;

    protected FileContextTestWrapper USNCFSIITG;

    @Before
    public void setup() throws Exception {
        NWJAOSUGPH = new HdfsConfiguration();
        NXVNBTEZER = new FileSystemTestHelper();
        // Set up java key store
        String ALMDOPIDHU = NXVNBTEZER.getTestRootDir();
        File EMHGAZLTPR = new File(ALMDOPIDHU).getAbsoluteFile();
        NWJAOSUGPH.set(KEY_PROVIDER_PATH, ((JavaKeyStoreProvider.SCHEME_NAME + "://file") + EMHGAZLTPR) + "/test.jks");
        UFVNLEECYV = new MiniDFSCluster.Builder(NWJAOSUGPH).numDataNodes(1).build();
        Logger.getLogger(EncryptionZoneManager.class).setLevel(Level.TRACE);
        UPRJASBULQ = UFVNLEECYV.getFileSystem();
        MCHCTWOMIG = new FileSystemTestWrapper(UFVNLEECYV.getFileSystem());
        USNCFSIITG = new FileContextTestWrapper(FileContext.getFileContext(UFVNLEECYV.getURI(), NWJAOSUGPH));
        KOZDBFKXAO = new HdfsAdmin(UFVNLEECYV.getURI(), NWJAOSUGPH);
        // Need to set the client's KeyProvider to the NN's for JKS,
        // else the updates do not get flushed properly
        UPRJASBULQ.getClient().provider = UFVNLEECYV.getNameNode().getNamesystem().getProvider();
        DFSTestUtil.createKey(SWIVRQQTDJ, UFVNLEECYV, NWJAOSUGPH);
    }

    @After
    public void teardown() {
        if (UFVNLEECYV != null) {
            UFVNLEECYV.shutdown();
        }
    }

    /**
     * Basic read/write tests of raw files.
     * Create a non-encrypted file
     * Create an encryption zone
     * Verify that non-encrypted file contents and decrypted file in EZ are equal
     * Compare the raw encrypted bytes of the file with the decrypted version to
     *   ensure they're different
     * Compare the raw and non-raw versions of the non-encrypted file to ensure
     *   they're the same.
     */
    @Test(timeout = 120000)
    public void testReadWriteRaw() throws Exception {
        // Create a base file for comparison
        final Path OQLOEWZIQW = new Path("/base");
        final int JMJXZTPWVR = 8192;
        DFSTestUtil.createFile(UPRJASBULQ, OQLOEWZIQW, JMJXZTPWVR, ((short) (1)), 0xfeed);
        // Create the first enc file
        final Path LFDDXLEWVE = new Path("/zone");
        UPRJASBULQ.mkdirs(LFDDXLEWVE);
        KOZDBFKXAO.createEncryptionZone(LFDDXLEWVE, SWIVRQQTDJ);
        final Path FXKNXDBFUK = new Path(LFDDXLEWVE, "myfile");
        DFSTestUtil.createFile(UPRJASBULQ, FXKNXDBFUK, JMJXZTPWVR, ((short) (1)), 0xfeed);
        // Read them back in and compare byte-by-byte
        DFSTestUtil.verifyFilesEqual(UPRJASBULQ, OQLOEWZIQW, FXKNXDBFUK, JMJXZTPWVR);
        // Raw file should be different from encrypted file
        final Path REYCWWOICC = new Path(LFDDXLEWVE, "/.reserved/raw/zone/myfile");
        DFSTestUtil.verifyFilesNotEqual(UPRJASBULQ, REYCWWOICC, FXKNXDBFUK, JMJXZTPWVR);
        // Raw file should be same as /base which is not in an EZ
        final Path WSEJXJSYBO = new Path(LFDDXLEWVE, "/.reserved/raw/base");
        DFSTestUtil.verifyFilesEqual(UPRJASBULQ, OQLOEWZIQW, WSEJXJSYBO, JMJXZTPWVR);
    }

    private void assertPathEquals(Path JTLFISRITE, Path SAJJMLQKLU) throws IOException {
        final FileStatus ALRJOBORDL = UPRJASBULQ.getFileStatus(JTLFISRITE);
        final FileStatus DIQEVVNYNT = UPRJASBULQ.getFileStatus(SAJJMLQKLU);
        /* Use accessTime and modificationTime as substitutes for INode to check
        for resolution to the same underlying file.
         */
        assertEquals("Access times not equal", ALRJOBORDL.getAccessTime(), DIQEVVNYNT.getAccessTime());
        assertEquals("Modification times not equal", ALRJOBORDL.getModificationTime(), DIQEVVNYNT.getModificationTime());
        assertEquals("pathname1 not equal", JTLFISRITE, Path.getPathWithoutSchemeAndAuthority(ALRJOBORDL.getPath()));
        assertEquals("pathname1 not equal", SAJJMLQKLU, Path.getPathWithoutSchemeAndAuthority(DIQEVVNYNT.getPath()));
    }

    /**
     * Tests that getFileStatus on raw and non raw resolve to the same
     * file.
     */
    @Test(timeout = 120000)
    public void testGetFileStatus() throws Exception {
        final Path OWVKRKNIUA = new Path("zone");
        final Path JPFMQDPOFP = new Path("/", OWVKRKNIUA);
        UPRJASBULQ.mkdirs(JPFMQDPOFP);
        KOZDBFKXAO.createEncryptionZone(JPFMQDPOFP, SWIVRQQTDJ);
        final Path HOMBLOPXJH = new Path("base");
        final Path ISVBSJTMEX = new Path("/.reserved/raw");
        final Path PXAGRZHSDQ = new Path(ISVBSJTMEX, HOMBLOPXJH);
        final int ORLAGFPSEJ = 8192;
        DFSTestUtil.createFile(UPRJASBULQ, PXAGRZHSDQ, ORLAGFPSEJ, ((short) (1)), 0xfeed);
        assertPathEquals(new Path("/", HOMBLOPXJH), PXAGRZHSDQ);
        /* Repeat the test for a file in an ez. */
        final Path QWWYNBCBQK = new Path(JPFMQDPOFP, HOMBLOPXJH);
        final Path QXRHLMOAXD = new Path(new Path(ISVBSJTMEX, OWVKRKNIUA), HOMBLOPXJH);
        DFSTestUtil.createFile(UPRJASBULQ, QWWYNBCBQK, ORLAGFPSEJ, ((short) (1)), 0xfeed);
        assertPathEquals(QWWYNBCBQK, QXRHLMOAXD);
    }

    @Test(timeout = 120000)
    public void testReservedRoot() throws Exception {
        final Path SGNQCFVGLC = new Path("/");
        final Path DSTFUAYIGJ = new Path("/.reserved/raw");
        final Path KSQSDKJXPX = new Path("/.reserved/raw/");
        assertPathEquals(SGNQCFVGLC, DSTFUAYIGJ);
        assertPathEquals(SGNQCFVGLC, KSQSDKJXPX);
    }

    /* Verify mkdir works ok in .reserved/raw directory. */
    @Test(timeout = 120000)
    public void testReservedRawMkdir() throws Exception {
        final Path KPKDQYDNLA = new Path("zone");
        final Path XCJWDWVUGR = new Path("/", KPKDQYDNLA);
        UPRJASBULQ.mkdirs(XCJWDWVUGR);
        KOZDBFKXAO.createEncryptionZone(XCJWDWVUGR, SWIVRQQTDJ);
        final Path FTFLPHKEYJ = new Path("/.reserved/raw");
        final Path BUXZUIFDVY = new Path("dir1");
        final Path GLZGTEVMTE = new Path(FTFLPHKEYJ, BUXZUIFDVY);
        UPRJASBULQ.mkdirs(GLZGTEVMTE);
        assertPathEquals(GLZGTEVMTE, new Path("/", BUXZUIFDVY));
        UPRJASBULQ.delete(GLZGTEVMTE, true);
        final Path RJOSXHJFVB = new Path(FTFLPHKEYJ, KPKDQYDNLA);
        final Path SDPPYZUTXK = new Path(RJOSXHJFVB, BUXZUIFDVY);
        UPRJASBULQ.mkdirs(SDPPYZUTXK);
        assertPathEquals(SDPPYZUTXK, new Path(XCJWDWVUGR, BUXZUIFDVY));
        UPRJASBULQ.delete(SDPPYZUTXK, true);
    }

    @Test(timeout = 120000)
    public void testRelativePathnames() throws Exception {
        final Path KXCZLWPCVN = new Path("/.reserved/raw/base");
        final int JQIGDKYSHC = 8192;
        DFSTestUtil.createFile(UPRJASBULQ, KXCZLWPCVN, JQIGDKYSHC, ((short) (1)), 0xfeed);
        final Path RFYBRUHVUG = new Path("/");
        final Path QVLSVVPPAX = new Path("/.reserved/raw");
        assertPathEquals(RFYBRUHVUG, new Path(QVLSVVPPAX, "../raw"));
        assertPathEquals(RFYBRUHVUG, new Path(QVLSVVPPAX, "../../.reserved/raw"));
        assertPathEquals(KXCZLWPCVN, new Path(QVLSVVPPAX, "../raw/base"));
        assertPathEquals(KXCZLWPCVN, new Path(QVLSVVPPAX, "../../.reserved/raw/base"));
        assertPathEquals(KXCZLWPCVN, new Path(QVLSVVPPAX, "../../.reserved/raw/base/../base"));
        assertPathEquals(KXCZLWPCVN, new Path("/.reserved/../.reserved/raw/../raw/base"));
    }

    @Test(timeout = 120000)
    public void testAdminAccessOnly() throws Exception {
        final Path GYRIOGXEPT = new Path("zone");
        final Path DEUTOREYNO = new Path("/", GYRIOGXEPT);
        UPRJASBULQ.mkdirs(DEUTOREYNO);
        KOZDBFKXAO.createEncryptionZone(DEUTOREYNO, SWIVRQQTDJ);
        final Path FCWKCRVXHN = new Path("base");
        final Path OBYDRHHLVD = new Path("/.reserved/raw");
        final int UHPJZBMMAL = 8192;
        /* Test failure of create file in reserved/raw as non admin */
        final UserGroupInformation KPMBRQOLQK = UserGroupInformation.createUserForTesting("user", new String[]{ "mygroup" });
        KPMBRQOLQK.doAs(new PrivilegedExceptionAction<Object>() {
            @Override
            public Object run() throws Exception {
                final DistributedFileSystem HTEBESURJM = UFVNLEECYV.getFileSystem();
                try {
                    final Path PRXXCCLFXF = new Path(new Path(OBYDRHHLVD, GYRIOGXEPT), FCWKCRVXHN);
                    DFSTestUtil.createFile(HTEBESURJM, PRXXCCLFXF, UHPJZBMMAL, ((short) (1)), 0xfeed);
                    fail("access to /.reserved/raw is superuser-only operation");
                } catch (AccessControlException e) {
                    assertExceptionContains("Superuser privilege is required", e);
                }
                return null;
            }
        });
        /* Test failure of getFileStatus in reserved/raw as non admin */
        final Path FOIOHRXQID = new Path(new Path(OBYDRHHLVD, GYRIOGXEPT), FCWKCRVXHN);
        DFSTestUtil.createFile(UPRJASBULQ, FOIOHRXQID, UHPJZBMMAL, ((short) (1)), 0xfeed);
        KPMBRQOLQK.doAs(new PrivilegedExceptionAction<Object>() {
            @Override
            public Object run() throws Exception {
                final DistributedFileSystem EDKDPXPJOD = UFVNLEECYV.getFileSystem();
                try {
                    EDKDPXPJOD.getFileStatus(FOIOHRXQID);
                    fail("access to /.reserved/raw is superuser-only operation");
                } catch (AccessControlException e) {
                    assertExceptionContains("Superuser privilege is required", e);
                }
                return null;
            }
        });
        /* Test failure of listStatus in reserved/raw as non admin */
        KPMBRQOLQK.doAs(new PrivilegedExceptionAction<Object>() {
            @Override
            public Object run() throws Exception {
                final DistributedFileSystem ZECPAVLLFQ = UFVNLEECYV.getFileSystem();
                try {
                    ZECPAVLLFQ.listStatus(FOIOHRXQID);
                    fail("access to /.reserved/raw is superuser-only operation");
                } catch (AccessControlException e) {
                    assertExceptionContains("Superuser privilege is required", e);
                }
                return null;
            }
        });
        UPRJASBULQ.setPermission(new Path("/"), new FsPermission(((short) (0777))));
        /* Test failure of mkdir in reserved/raw as non admin */
        KPMBRQOLQK.doAs(new PrivilegedExceptionAction<Object>() {
            @Override
            public Object run() throws Exception {
                final DistributedFileSystem PZMBATEUFH = UFVNLEECYV.getFileSystem();
                final Path SMVVZLCWWN = new Path(OBYDRHHLVD, "dir1");
                try {
                    PZMBATEUFH.mkdirs(SMVVZLCWWN);
                    fail("access to /.reserved/raw is superuser-only operation");
                } catch (AccessControlException e) {
                    assertExceptionContains("Superuser privilege is required", e);
                }
                return null;
            }
        });
    }

    @Test(timeout = 120000)
    public void testListDotReserved() throws Exception {
        // Create a base file for comparison
        final Path OMFWXGCGQA = new Path("/.reserved/raw/base");
        final int FKNGCNTHBB = 8192;
        DFSTestUtil.createFile(UPRJASBULQ, OMFWXGCGQA, FKNGCNTHBB, ((short) (1)), 0xfeed);
        /* Ensure that you can't list /.reserved. Ever. */
        try {
            UPRJASBULQ.listStatus(new Path("/.reserved"));
            fail("expected FNFE");
        } catch (FileNotFoundException e) {
            assertExceptionContains("/.reserved does not exist", e);
        }
        try {
            UPRJASBULQ.listStatus(new Path("/.reserved/.inodes"));
            fail("expected FNFE");
        } catch (FileNotFoundException e) {
            assertExceptionContains("/.reserved/.inodes does not exist", e);
        }
        final FileStatus[] YTDGXZPPXV = UPRJASBULQ.listStatus(new Path("/.reserved/raw"));
        assertEquals("expected 1 entry", YTDGXZPPXV.length, 1);
        assertMatches(YTDGXZPPXV[0].getPath().toString(), "/.reserved/raw/base");
    }

    @Test(timeout = 120000)
    public void testListRecursive() throws Exception {
        Path AXMZBBXTKS = new Path("/");
        Path MUOWSYQZTR = AXMZBBXTKS;
        for (int JOTWKPUNVL = 0; JOTWKPUNVL < 3; JOTWKPUNVL++) {
            MUOWSYQZTR = new Path(MUOWSYQZTR, "dir" + JOTWKPUNVL);
            UPRJASBULQ.mkdirs(MUOWSYQZTR);
        }
        Path ERTXPTGIIS = new Path("/.reserved/raw");
        int TILOCHGGUI = 0;
        FileStatus[] IFCRLAUKIB = UPRJASBULQ.listStatus(ERTXPTGIIS);
        while ((IFCRLAUKIB != null) && (IFCRLAUKIB.length > 0)) {
            FileStatus YPLQNQFYNI = IFCRLAUKIB[0];
            assertMatches(YPLQNQFYNI.getPath().toString(), "/.reserved/raw");
            ERTXPTGIIS = Path.getPathWithoutSchemeAndAuthority(YPLQNQFYNI.getPath());
            TILOCHGGUI++;
            IFCRLAUKIB = UPRJASBULQ.listStatus(ERTXPTGIIS);
        } 
        assertEquals(3, TILOCHGGUI);
    }
}