/**
 * This test verifies DataNode command line processing.
 */
public class TestDatanodeStartupOptions {
    private Configuration LHJYOYOGKU = null;

    /**
     * Process the given arg list as command line arguments to the DataNode
     * to make sure we get the expected result. If the expected result is
     * success then further validate that the parsed startup option is the
     * same as what was expected.
     *
     * @param expectSuccess
     * 		
     * @param expectedOption
     * 		
     * @param conf
     * 		
     * @param arg
     * 		
     */
    private static void checkExpected(boolean EMACHBADBT, StartupOption GYQYXXYSZX, Configuration HQONKXIVEQ, String... BKHYLMMPTO) {
        String[] MTYPHMDADF = new String[BKHYLMMPTO.length];
        int EOTRBMFKZL = 0;
        for (String HZZKZRKJMU : BKHYLMMPTO) {
            MTYPHMDADF[EOTRBMFKZL++] = HZZKZRKJMU;
        }
        boolean MOHRMYJMTM = DataNode.parseArguments(MTYPHMDADF, HQONKXIVEQ);
        StartupOption WLJLVBJRZE = DataNode.getStartupOption(HQONKXIVEQ);
        assertThat(MOHRMYJMTM, is(EMACHBADBT));
        if (EMACHBADBT) {
            assertThat(WLJLVBJRZE, is(GYQYXXYSZX));
        }
    }

    /**
     * Reinitialize configuration before every test since DN stores the
     * parsed StartupOption in the configuration.
     */
    @Before
    public void initConfiguration() {
        LHJYOYOGKU = new HdfsConfiguration();
    }

    /**
     * A few options that should all parse successfully.
     */
    @Test(timeout = 60000)
    public void testStartupSuccess() {
        TestDatanodeStartupOptions.checkExpected(true, REGULAR, LHJYOYOGKU);
        TestDatanodeStartupOptions.checkExpected(true, REGULAR, LHJYOYOGKU, "-regular");
        TestDatanodeStartupOptions.checkExpected(true, REGULAR, LHJYOYOGKU, "-REGULAR");
        TestDatanodeStartupOptions.checkExpected(true, ROLLBACK, LHJYOYOGKU, "-rollback");
    }

    /**
     * A few options that should all fail to parse.
     */
    @Test(timeout = 60000)
    public void testStartupFailure() {
        TestDatanodeStartupOptions.checkExpected(false, REGULAR, LHJYOYOGKU, "unknownoption");
        TestDatanodeStartupOptions.checkExpected(false, REGULAR, LHJYOYOGKU, "-regular -rollback");
    }
}