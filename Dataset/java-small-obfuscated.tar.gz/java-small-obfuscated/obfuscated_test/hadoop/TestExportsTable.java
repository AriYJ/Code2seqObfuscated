public class TestExportsTable {
    @Test
    public void testExportPoint() throws IOException {
        NfsConfiguration WKXYGYSIWQ = new NfsConfiguration();
        MiniDFSCluster IJMNBWGNLU = null;
        String VDIHIBKLLU = "/myexport1";
        WKXYGYSIWQ.setStrings(DFS_NFS_EXPORT_POINT_KEY, VDIHIBKLLU);
        // Use emphral port in case tests are running in parallel
        WKXYGYSIWQ.setInt("nfs3.mountd.port", 0);
        WKXYGYSIWQ.setInt("nfs3.server.port", 0);
        try {
            IJMNBWGNLU = new MiniDFSCluster.Builder(WKXYGYSIWQ).numDataNodes(1).build();
            IJMNBWGNLU.waitActive();
            // Start nfs
            final Nfs3 LWLBPYZXLE = new Nfs3(WKXYGYSIWQ);
            LWLBPYZXLE.startServiceInternal(false);
            Mountd EITYKXXBAY = LWLBPYZXLE.getMountd();
            RpcProgramMountd TGALDALMUX = ((RpcProgramMountd) (EITYKXXBAY.getRpcProgram()));
            assertTrue(TGALDALMUX.getExports().size() == 1);
            String YNIKLYFVZR = TGALDALMUX.getExports().get(0);
            assertTrue(YNIKLYFVZR.equals(VDIHIBKLLU));
        } finally {
            if (IJMNBWGNLU != null) {
                IJMNBWGNLU.shutdown();
            }
        }
    }
}