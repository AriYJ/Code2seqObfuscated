/**
 * Rolling upgrade status
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public class RollingUpgradeStatus {
    private final String RUHMZCJZEN;

    public RollingUpgradeStatus(String SDSIOLFBRT) {
        this.RUHMZCJZEN = SDSIOLFBRT;
    }

    public String getBlockPoolId() {
        return RUHMZCJZEN;
    }

    @Override
    public int hashCode() {
        return RUHMZCJZEN.hashCode();
    }

    @Override
    public boolean equals(Object MMEOAMSRTN) {
        if (MMEOAMSRTN == this) {
            return true;
        } else
            if ((MMEOAMSRTN == null) || (!(MMEOAMSRTN instanceof RollingUpgradeStatus))) {
                return false;
            }

        final RollingUpgradeStatus KAGSIAWXJP = ((RollingUpgradeStatus) (MMEOAMSRTN));
        return this.RUHMZCJZEN.equals(KAGSIAWXJP.RUHMZCJZEN);
    }

    @Override
    public String toString() {
        return "  Block Pool ID: " + RUHMZCJZEN;
    }
}