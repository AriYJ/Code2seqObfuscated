/**
 * DatanodeRegistration class contains all information the name-node needs
 * to identify and verify a data-node when it contacts the name-node.
 * This information is sent by data-node with each communication request.
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public class DatanodeRegistration extends DatanodeID implements NodeRegistration {
    private final StorageInfo GUIZUJPQZY;

    private ExportedBlockKeys FEQHVDKVSE;

    private final String QRAFODCRUE;

    public DatanodeRegistration(DatanodeID KDTOFMKKIX, StorageInfo FXVDVMNNIO, ExportedBlockKeys DRGBETXIKF, String OAQUTASAVX) {
        super(KDTOFMKKIX);
        this.GUIZUJPQZY = FXVDVMNNIO;
        this.FEQHVDKVSE = DRGBETXIKF;
        this.QRAFODCRUE = OAQUTASAVX;
    }

    public StorageInfo getStorageInfo() {
        return GUIZUJPQZY;
    }

    public void setExportedKeys(ExportedBlockKeys DVAHQLEQOY) {
        this.FEQHVDKVSE = DVAHQLEQOY;
    }

    public ExportedBlockKeys getExportedKeys() {
        return FEQHVDKVSE;
    }

    public String getSoftwareVersion() {
        return QRAFODCRUE;
    }

    // NodeRegistration
    @Override
    public int getVersion() {
        return GUIZUJPQZY.getLayoutVersion();
    }

    // NodeRegistration
    @Override
    public String getRegistrationID() {
        return Storage.getRegistrationID(GUIZUJPQZY);
    }

    // NodeRegistration
    @Override
    public String getAddress() {
        return getXferAddr();
    }

    @Override
    public String toString() {
        return ((((((((((getClass().getSimpleName() + "(") + getIpAddr()) + ", datanodeUuid=") + getDatanodeUuid()) + ", infoPort=") + getInfoPort()) + ", ipcPort=") + getIpcPort()) + ", storageInfo=") + GUIZUJPQZY) + ")";
    }

    @Override
    public boolean equals(Object DIXFOKRFJV) {
        return super.equals(DIXFOKRFJV);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}