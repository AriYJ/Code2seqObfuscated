@Public
@Unstable
public class TimelineDelegationTokenSelector implements TokenSelector<TimelineDelegationTokenIdentifier> {
    private static final Log RVIZCRBWHL = LogFactory.getLog(TimelineDelegationTokenSelector.class);

    @SuppressWarnings("unchecked")
    public Token<TimelineDelegationTokenIdentifier> selectToken(Text WNMXXQTSRV, Collection<Token<? extends TokenIdentifier>> TOOEYIUCZC) {
        if (WNMXXQTSRV == null) {
            return null;
        }
        if (TimelineDelegationTokenSelector.RVIZCRBWHL.isDebugEnabled()) {
            TimelineDelegationTokenSelector.RVIZCRBWHL.debug("Looking for a token with service " + WNMXXQTSRV.toString());
        }
        for (Token<? extends TokenIdentifier> PAXVLGGMRN : TOOEYIUCZC) {
            if (TimelineDelegationTokenSelector.RVIZCRBWHL.isDebugEnabled()) {
                TimelineDelegationTokenSelector.RVIZCRBWHL.debug((("Token kind is " + PAXVLGGMRN.getKind().toString()) + " and the token's service name is ") + PAXVLGGMRN.getService());
            }
            if (KIND_NAME.equals(PAXVLGGMRN.getKind()) && WNMXXQTSRV.equals(PAXVLGGMRN.getService())) {
                return ((Token<TimelineDelegationTokenIdentifier>) (PAXVLGGMRN));
            }
        }
        return null;
    }
}