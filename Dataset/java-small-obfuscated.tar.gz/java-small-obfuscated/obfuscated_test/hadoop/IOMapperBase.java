/**
 * Base mapper class for IO operations.
 * <p>
 * Two abstract method {@link #doIO(Reporter, String, long)} and
 * {@link #collectStats(OutputCollector,String,long,Object)} should be
 * overloaded in derived classes to define the IO operation and the
 * statistics data to be collected by subsequent reducers.
 */
public abstract class IOMapperBase<T> extends Configured implements Mapper<Text, LongWritable, Text, Text> {
    protected byte[] SRZFUXZBKI;

    protected int OIXZQCOTMF;

    protected FileSystem IKHADVENCH;

    protected String IKKJIPNXGI;

    protected Closeable FZPKLIPWGH;

    public IOMapperBase() {
    }

    public void configure(JobConf FFYNMBRAVS) {
        setConf(FFYNMBRAVS);
        try {
            IKHADVENCH = FileSystem.get(FFYNMBRAVS);
        } catch (Exception e) {
            throw new RuntimeException("Cannot create file system.", e);
        }
        OIXZQCOTMF = FFYNMBRAVS.getInt("test.io.file.buffer.size", 4096);
        SRZFUXZBKI = new byte[OIXZQCOTMF];
        try {
            IKKJIPNXGI = InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            IKKJIPNXGI = "localhost";
        }
    }

    public void close() throws IOException {
    }

    /**
     * Perform io operation, usually read or write.
     *
     * @param reporter
     * 		
     * @param name
     * 		file name
     * @param value
     * 		offset within the file
     * @return object that is passed as a parameter to
    {@link #collectStats(OutputCollector,String,long,Object)}
     * @throws IOException
     * 		
     */
    abstract T doIO(Reporter OKZZNJNRLF, String GLMMALSJMB, long UHLJZMEVES) throws IOException;

    /**
     * Create an input or output stream based on the specified file.
     * Subclasses should override this method to provide an actual stream.
     *
     * @param name
     * 		file name
     * @return the stream
     * @throws IOException
     * 		
     */
    public Closeable getIOStream(String IQWCTNJWUT) throws IOException {
        return null;
    }

    /**
     * Collect stat data to be combined by a subsequent reducer.
     *
     * @param output
     * 		
     * @param name
     * 		file name
     * @param execTime
     * 		IO execution time
     * @param doIOReturnValue
     * 		value returned by {@link #doIO(Reporter,String,long)}
     * @throws IOException
     * 		
     */
    abstract void collectStats(OutputCollector<Text, Text> LKEGUKBJHA, String VRXAMLKWYS, long DLHPUPAUVV, T PWXBPAWXFC) throws IOException;

    /**
     * Map file name and offset into statistical data.
     * <p>
     * The map task is to get the
     * <tt>key</tt>, which contains the file name, and the
     * <tt>value</tt>, which is the offset within the file.
     *
     * The parameters are passed to the abstract method
     * {@link #doIO(Reporter,String,long)}, which performs the io operation,
     * usually read or write data, and then
     * {@link #collectStats(OutputCollector,String,long,Object)}
     * is called to prepare stat data for a subsequent reducer.
     */
    public void map(Text KTJXUIJNYU, LongWritable BSAFSEDYEQ, OutputCollector<Text, Text> CQUFHDLWTQ, Reporter FMPMSHEPKL) throws IOException {
        String FRWMCBEUUL = KTJXUIJNYU.toString();
        long AWQLAADJYW = BSAFSEDYEQ.get();
        FMPMSHEPKL.setStatus((("starting " + FRWMCBEUUL) + " ::host = ") + IKKJIPNXGI);
        this.stream = getIOStream(FRWMCBEUUL);
        T CHPYJLXRFL = null;
        long UZCFPOWZZJ = System.currentTimeMillis();
        try {
            CHPYJLXRFL = doIO(FMPMSHEPKL, FRWMCBEUUL, AWQLAADJYW);
        } finally {
            if (FZPKLIPWGH != null)
                FZPKLIPWGH.close();

        }
        long UIGSUGQRDU = System.currentTimeMillis();
        long JNTCEKSKZP = UIGSUGQRDU - UZCFPOWZZJ;
        collectStats(CQUFHDLWTQ, FRWMCBEUUL, JNTCEKSKZP, CHPYJLXRFL);
        FMPMSHEPKL.setStatus((("finished " + FRWMCBEUUL) + " ::host = ") + IKKJIPNXGI);
    }
}