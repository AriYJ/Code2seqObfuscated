/**
 * Dumping the information of a TFile.
 */
class TFileDumper {
    static final Log GIRSXODGLH = LogFactory.getLog(TFileDumper.class);

    private TFileDumper() {
        // namespace object not constructable.
    }

    private enum Align {

        LEFT,
        CENTER,
        RIGHT,
        ZERO_PADDED;
        static String format(String s, int width, TFileDumper.Align align) {
            if (s.length() >= width)
                return s;

            int room = width - s.length();
            TFileDumper.Align alignAdjusted = align;
            if (room == 1) {
                alignAdjusted = TFileDumper.Align.LEFT;
            }
            if (alignAdjusted == TFileDumper.Align.LEFT) {
                return s + String.format(("%" + room) + "s", "");
            }
            if (alignAdjusted == TFileDumper.Align.RIGHT) {
                return String.format(("%" + room) + "s", "") + s;
            }
            if (alignAdjusted == TFileDumper.Align.CENTER) {
                int half = room / 2;
                return (String.format(("%" + half) + "s", "") + s) + String.format(("%" + (room - half)) + "s", "");
            }
            throw new IllegalArgumentException("Unsupported alignment");
        }

        static String format(long l, int width, TFileDumper.Align align) {
            if (align == TFileDumper.Align.ZERO_PADDED) {
                return String.format(("%0" + width) + "d", l);
            }
            return TFileDumper.Align.format(Long.toString(l), width, align);
        }

        static int calculateWidth(String caption, long max) {
            return Math.max(caption.length(), Long.toString(max).length());
        }
    }

    /**
     * Dump information about TFile.
     *
     * @param file
     * 		Path string of the TFile
     * @param out
     * 		PrintStream to output the information.
     * @param conf
     * 		The configuration object.
     * @throws IOException
     * 		
     */
    public static void dumpInfo(String GXBTQYDQHV, PrintStream RXBNXJETDG, Configuration QZSUODYVQK) throws IOException {
        final int PPJZXGYLSW = 16;
        Path VYCMESSARR = new Path(GXBTQYDQHV);
        FileSystem JWHNOTVPAD = VYCMESSARR.getFileSystem(QZSUODYVQK);
        long FQSTOQFLJA = JWHNOTVPAD.getFileStatus(VYCMESSARR).getLen();
        FSDataInputStream HDBQFKPTYF = JWHNOTVPAD.open(VYCMESSARR);
        TFile.Reader NSKJHITLPV = new TFile.Reader(HDBQFKPTYF, FQSTOQFLJA, QZSUODYVQK);
        try {
            LinkedHashMap<String, String> QBVQWXVPYS = new LinkedHashMap<String, String>();
            int FOJDWMHNZU = NSKJHITLPV.readerBCF.getBlockCount();
            int EKLRRHIHRX = NSKJHITLPV.readerBCF.metaIndex.index.size();
            QBVQWXVPYS.put("BCFile Version", NSKJHITLPV.readerBCF.version.toString());
            QBVQWXVPYS.put("TFile Version", NSKJHITLPV.tfileMeta.version.toString());
            QBVQWXVPYS.put("File Length", Long.toString(FQSTOQFLJA));
            QBVQWXVPYS.put("Data Compression", NSKJHITLPV.readerBCF.getDefaultCompressionName());
            QBVQWXVPYS.put("Record Count", Long.toString(NSKJHITLPV.getEntryCount()));
            QBVQWXVPYS.put("Sorted", Boolean.toString(NSKJHITLPV.isSorted()));
            if (NSKJHITLPV.isSorted()) {
                QBVQWXVPYS.put("Comparator", NSKJHITLPV.getComparatorName());
            }
            QBVQWXVPYS.put("Data Block Count", Integer.toString(FOJDWMHNZU));
            long OJKKEWBCVI = 0;
            long ACCDIPEZQO = 0;
            if (FOJDWMHNZU > 0) {
                for (int OSBXNESQBN = 0; OSBXNESQBN < FOJDWMHNZU; ++OSBXNESQBN) {
                    BlockRegion WLVMZDXUYX = NSKJHITLPV.readerBCF.dataIndex.getBlockRegionList().get(OSBXNESQBN);
                    OJKKEWBCVI += WLVMZDXUYX.getCompressedSize();
                    ACCDIPEZQO += WLVMZDXUYX.getRawSize();
                }
                QBVQWXVPYS.put("Data Block Bytes", Long.toString(OJKKEWBCVI));
                if (!NSKJHITLPV.readerBCF.getDefaultCompressionName().equals("none")) {
                    QBVQWXVPYS.put("Data Block Uncompressed Bytes", Long.toString(ACCDIPEZQO));
                    QBVQWXVPYS.put("Data Block Compression Ratio", String.format("1:%.1f", ((double) (ACCDIPEZQO)) / OJKKEWBCVI));
                }
            }
            QBVQWXVPYS.put("Meta Block Count", Integer.toString(EKLRRHIHRX));
            long LXSOSZFOWA = 0;
            long FIDMRYPCYW = 0;
            if (EKLRRHIHRX > 0) {
                Collection<MetaIndexEntry> WHONONLCOP = NSKJHITLPV.readerBCF.metaIndex.index.values();
                boolean TBZGEUFACB = false;
                for (Iterator<MetaIndexEntry> LAGJWGCAUI = WHONONLCOP.iterator(); LAGJWGCAUI.hasNext();) {
                    MetaIndexEntry WCMBJDBKOI = LAGJWGCAUI.next();
                    LXSOSZFOWA += WCMBJDBKOI.getRegion().getCompressedSize();
                    FIDMRYPCYW += WCMBJDBKOI.getRegion().getRawSize();
                    if (WCMBJDBKOI.getCompressionAlgorithm() != Algorithm.NONE) {
                        TBZGEUFACB = true;
                    }
                }
                QBVQWXVPYS.put("Meta Block Bytes", Long.toString(LXSOSZFOWA));
                if (TBZGEUFACB) {
                    QBVQWXVPYS.put("Meta Block Uncompressed Bytes", Long.toString(FIDMRYPCYW));
                    QBVQWXVPYS.put("Meta Block Compression Ratio", String.format("1:%.1f", ((double) (FIDMRYPCYW)) / LXSOSZFOWA));
                }
            }
            QBVQWXVPYS.put("Meta-Data Size Ratio", String.format("1:%.1f", ((double) (OJKKEWBCVI)) / LXSOSZFOWA));
            long PEFOLHBBNW = (FQSTOQFLJA - OJKKEWBCVI) - LXSOSZFOWA;
            long GXIWLMZBVU = ((Magic.size() * 2) + (Long.SIZE / Byte.SIZE)) + Version.size();
            long NVGWFZLFZL = PEFOLHBBNW - GXIWLMZBVU;
            QBVQWXVPYS.put("Meta Block Index Bytes", Long.toString(NVGWFZLFZL));
            QBVQWXVPYS.put("Headers Etc Bytes", Long.toString(GXIWLMZBVU));
            // Now output the properties table.
            int OHVFZCZSMO = 0;
            Set<Map.Entry<String, String>> DRYVZOIXOT = QBVQWXVPYS.entrySet();
            for (Iterator<Map.Entry<String, String>> CSQUBVEKRI = DRYVZOIXOT.iterator(); CSQUBVEKRI.hasNext();) {
                Map.Entry<String, String> TLANCUFJVW = CSQUBVEKRI.next();
                if (TLANCUFJVW.getKey().length() > OHVFZCZSMO) {
                    OHVFZCZSMO = TLANCUFJVW.getKey().length();
                }
            }
            for (Iterator<Map.Entry<String, String>> OSZIHSTSPN = DRYVZOIXOT.iterator(); OSZIHSTSPN.hasNext();) {
                Map.Entry<String, String> CVULZEZUYB = OSZIHSTSPN.next();
                RXBNXJETDG.printf("%s : %s\n", TFileDumper.Align.format(CVULZEZUYB.getKey(), OHVFZCZSMO, TFileDumper.Align.LEFT), CVULZEZUYB.getValue());
            }
            RXBNXJETDG.println();
            NSKJHITLPV.checkTFileDataIndex();
            if (FOJDWMHNZU > 0) {
                String ERKWDOCBNX = "Data-Block";
                int ESOXQEKLOP = TFileDumper.Align.calculateWidth(ERKWDOCBNX, FOJDWMHNZU);
                int EIVADBUJWF = TFileDumper.Align.calculateWidth("", FOJDWMHNZU);
                String IUEJMNYDOD = "Offset";
                int WGPJVKYQWK = TFileDumper.Align.calculateWidth(IUEJMNYDOD, FQSTOQFLJA);
                String DICHOREUWG = "Length";
                int VOKJYUFKJJ = TFileDumper.Align.calculateWidth(DICHOREUWG, (OJKKEWBCVI / FOJDWMHNZU) * 10);
                String QJZEQPUPJI = "Raw-Size";
                int GYEDZERRBZ = TFileDumper.Align.calculateWidth(QJZEQPUPJI, (ACCDIPEZQO / FOJDWMHNZU) * 10);
                String NLCFZVDLEN = "Records";
                int UPMTCCJSCL = TFileDumper.Align.calculateWidth(NLCFZVDLEN, (NSKJHITLPV.getEntryCount() / FOJDWMHNZU) * 10);
                String IHEKFGJAJQ = "End-Key";
                int YGHUTPAMIU = Math.max(IHEKFGJAJQ.length(), (PPJZXGYLSW * 2) + 5);
                RXBNXJETDG.printf("%s %s %s %s %s %s\n", TFileDumper.Align.format(ERKWDOCBNX, ESOXQEKLOP, TFileDumper.Align.CENTER), TFileDumper.Align.format(IUEJMNYDOD, WGPJVKYQWK, TFileDumper.Align.CENTER), TFileDumper.Align.format(DICHOREUWG, VOKJYUFKJJ, TFileDumper.Align.CENTER), TFileDumper.Align.format(QJZEQPUPJI, GYEDZERRBZ, TFileDumper.Align.CENTER), TFileDumper.Align.format(NLCFZVDLEN, UPMTCCJSCL, TFileDumper.Align.CENTER), TFileDumper.Align.format(IHEKFGJAJQ, YGHUTPAMIU, TFileDumper.Align.LEFT));
                for (int VLLBGRNBTR = 0; VLLBGRNBTR < FOJDWMHNZU; ++VLLBGRNBTR) {
                    BlockRegion FBDKHYFRSL = NSKJHITLPV.readerBCF.dataIndex.getBlockRegionList().get(VLLBGRNBTR);
                    TFileIndexEntry GZRSGZUINC = NSKJHITLPV.tfileIndex.getEntry(VLLBGRNBTR);
                    RXBNXJETDG.printf("%s %s %s %s %s ", TFileDumper.Align.format(TFileDumper.Align.format(VLLBGRNBTR, EIVADBUJWF, TFileDumper.Align.ZERO_PADDED), ESOXQEKLOP, TFileDumper.Align.LEFT), TFileDumper.Align.format(FBDKHYFRSL.getOffset(), WGPJVKYQWK, TFileDumper.Align.LEFT), TFileDumper.Align.format(FBDKHYFRSL.getCompressedSize(), VOKJYUFKJJ, TFileDumper.Align.LEFT), TFileDumper.Align.format(FBDKHYFRSL.getRawSize(), GYEDZERRBZ, TFileDumper.Align.LEFT), TFileDumper.Align.format(GZRSGZUINC.kvEntries, UPMTCCJSCL, TFileDumper.Align.LEFT));
                    byte[] SOSRUFCXZQ = GZRSGZUINC.key;
                    boolean RMEUNJWIYL = true;
                    int KMXUJYGSRZ = Math.min(PPJZXGYLSW, SOSRUFCXZQ.length);
                    for (int RGFGKQEARR = 0; RGFGKQEARR < KMXUJYGSRZ; ++RGFGKQEARR) {
                        byte UGOWNJJNIX = SOSRUFCXZQ[RGFGKQEARR];
                        if (((UGOWNJJNIX < 32) && (UGOWNJJNIX != 9)) || (UGOWNJJNIX == 127)) {
                            RMEUNJWIYL = false;
                        }
                    }
                    if (!RMEUNJWIYL) {
                        RXBNXJETDG.print("0X");
                        for (int BYBRFKMRWW = 0; BYBRFKMRWW < KMXUJYGSRZ; ++BYBRFKMRWW) {
                            byte XUBYSVFMVP = SOSRUFCXZQ[VLLBGRNBTR];
                            RXBNXJETDG.printf("%X", XUBYSVFMVP);
                        }
                    } else {
                        RXBNXJETDG.print(new String(SOSRUFCXZQ, 0, KMXUJYGSRZ));
                    }
                    if (KMXUJYGSRZ < SOSRUFCXZQ.length) {
                        RXBNXJETDG.print("...");
                    }
                    RXBNXJETDG.println();
                }
            }
            RXBNXJETDG.println();
            if (EKLRRHIHRX > 0) {
                String THMRHXNHQI = "Meta-Block";
                int DEAVAEGRWY = 0;
                Set<Map.Entry<String, MetaIndexEntry>> XXSSIPPPXP = NSKJHITLPV.readerBCF.metaIndex.index.entrySet();
                for (Iterator<Map.Entry<String, MetaIndexEntry>> ZAATUZCLVP = XXSSIPPPXP.iterator(); ZAATUZCLVP.hasNext();) {
                    Map.Entry<String, MetaIndexEntry> ORAEMPHIEG = ZAATUZCLVP.next();
                    if (ORAEMPHIEG.getKey().length() > DEAVAEGRWY) {
                        DEAVAEGRWY = ORAEMPHIEG.getKey().length();
                    }
                }
                int NSBTMVWBOP = Math.max(THMRHXNHQI.length(), DEAVAEGRWY);
                String OCJOKSLHWF = "Offset";
                int ATCSKLACML = TFileDumper.Align.calculateWidth(OCJOKSLHWF, FQSTOQFLJA);
                String RDYHYSVUCD = "Length";
                int PXWQVBFRXJ = TFileDumper.Align.calculateWidth(RDYHYSVUCD, (LXSOSZFOWA / EKLRRHIHRX) * 10);
                String UQSUQAXDWU = "Raw-Size";
                int ESENLKYSKT = TFileDumper.Align.calculateWidth(UQSUQAXDWU, (FIDMRYPCYW / EKLRRHIHRX) * 10);
                String QDFNQHJMYO = "Compression";
                int NXBNVZXQLI = QDFNQHJMYO.length();
                RXBNXJETDG.printf("%s %s %s %s %s\n", TFileDumper.Align.format(THMRHXNHQI, NSBTMVWBOP, TFileDumper.Align.CENTER), TFileDumper.Align.format(OCJOKSLHWF, ATCSKLACML, TFileDumper.Align.CENTER), TFileDumper.Align.format(RDYHYSVUCD, PXWQVBFRXJ, TFileDumper.Align.CENTER), TFileDumper.Align.format(UQSUQAXDWU, ESENLKYSKT, TFileDumper.Align.CENTER), TFileDumper.Align.format(QDFNQHJMYO, NXBNVZXQLI, TFileDumper.Align.LEFT));
                for (Iterator<Map.Entry<String, MetaIndexEntry>> BJNQAVCFCT = XXSSIPPPXP.iterator(); BJNQAVCFCT.hasNext();) {
                    Map.Entry<String, MetaIndexEntry> SIYUFGMFFV = BJNQAVCFCT.next();
                    String FHSNYGAGHV = SIYUFGMFFV.getValue().getMetaName();
                    BlockRegion FOVWZHYGJY = SIYUFGMFFV.getValue().getRegion();
                    String GTHBDMCXWU = SIYUFGMFFV.getValue().getCompressionAlgorithm().getName();
                    RXBNXJETDG.printf("%s %s %s %s %s\n", TFileDumper.Align.format(FHSNYGAGHV, NSBTMVWBOP, TFileDumper.Align.LEFT), TFileDumper.Align.format(FOVWZHYGJY.getOffset(), ATCSKLACML, TFileDumper.Align.LEFT), TFileDumper.Align.format(FOVWZHYGJY.getCompressedSize(), PXWQVBFRXJ, TFileDumper.Align.LEFT), TFileDumper.Align.format(FOVWZHYGJY.getRawSize(), ESENLKYSKT, TFileDumper.Align.LEFT), TFileDumper.Align.format(GTHBDMCXWU, NXBNVZXQLI, TFileDumper.Align.LEFT));
                }
            }
        } finally {
            IOUtils.cleanup(TFileDumper.GIRSXODGLH, NSKJHITLPV, HDBQFKPTYF);
        }
    }
}