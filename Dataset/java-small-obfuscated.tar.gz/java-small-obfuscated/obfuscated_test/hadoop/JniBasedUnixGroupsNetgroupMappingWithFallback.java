public class JniBasedUnixGroupsNetgroupMappingWithFallback implements GroupMappingServiceProvider {
    private static final Log BLBYHCMBWI = LogFactory.getLog(JniBasedUnixGroupsNetgroupMappingWithFallback.class);

    private GroupMappingServiceProvider RGJXQVJYQD;

    public JniBasedUnixGroupsNetgroupMappingWithFallback() {
        if (NativeCodeLoader.isNativeCodeLoaded()) {
            this.RGJXQVJYQD = new JniBasedUnixGroupsNetgroupMapping();
        } else {
            JniBasedUnixGroupsNetgroupMappingWithFallback.BLBYHCMBWI.info("Falling back to shell based");
            this.RGJXQVJYQD = new ShellBasedUnixGroupsNetgroupMapping();
        }
        if (JniBasedUnixGroupsNetgroupMappingWithFallback.BLBYHCMBWI.isDebugEnabled()) {
            JniBasedUnixGroupsNetgroupMappingWithFallback.BLBYHCMBWI.debug("Group mapping impl=" + RGJXQVJYQD.getClass().getName());
        }
    }

    @Override
    public List<String> getGroups(String NBDRPOVHEM) throws IOException {
        return RGJXQVJYQD.getGroups(NBDRPOVHEM);
    }

    @Override
    public void cacheGroupsRefresh() throws IOException {
        RGJXQVJYQD.cacheGroupsRefresh();
    }

    @Override
    public void cacheGroupsAdd(List<String> CWKSRRNPBP) throws IOException {
        RGJXQVJYQD.cacheGroupsAdd(CWKSRRNPBP);
    }
}