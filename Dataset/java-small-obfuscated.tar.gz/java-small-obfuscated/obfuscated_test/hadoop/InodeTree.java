/**
 * InodeTree implements a mount-table as a tree of inodes.
 * It is used to implement ViewFs and ViewFileSystem.
 * In order to use it the caller must subclass it and implement
 * the abstract methods {@link #getTargetFileSystem(INodeDir)}, etc.
 *
 * The mountable is initialized from the config variables as
 * specified in {@link ViewFs}
 *
 * @param <T>
 * 		is AbstractFileSystem or FileSystem
 * 		
 * 		The three main methods are
 * 		{@link #InodeTreel(Configuration)} // constructor
 * 		{@link #InodeTree(Configuration, String)} // constructor
 * 		{@link #resolve(String, boolean)}
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
abstract class InodeTree<T> {
    static enum ResultKind {

        isInternalDir,
        isExternalDir;}

    static final Path AMYATMMITI = new Path("/");

    final InodeTree.INodeDir<T> CVJRWQCPUC;// the root of the mount table


    final String JTHPUPEOJT;// the homedir config value for this mount table


    List<InodeTree.MountPoint<T>> GNFLQDBLKM = new ArrayList<InodeTree.MountPoint<T>>();

    static class MountPoint<T> {
        String BTBXTYZODT;

        InodeTree.INodeLink<T> AVIVLHXWFX;

        MountPoint(String srcPath, InodeTree.INodeLink<T> mountLink) {
            BTBXTYZODT = srcPath;
            AVIVLHXWFX = mountLink;
        }
    }

    /**
     * Breaks file path into component names.
     *
     * @param path
     * 		
     * @return array of names component names
     */
    static String[] breakIntoPathComponents(final String KSUSKLENLB) {
        return KSUSKLENLB == null ? null : KSUSKLENLB.split(SEPARATOR);
    }

    /**
     * Internal class for inode tree
     *
     * @param <T>
     * 		
     */
    static abstract class INode<T> {
        final String EEHOSKKIRP;// the full path to the root


        public INode(String pathToNode, UserGroupInformation aUgi) {
            EEHOSKKIRP = pathToNode;
        }
    }

    /**
     * Internal class to represent an internal dir of the mount table
     *
     * @param <T>
     * 		
     */
    static class INodeDir<T> extends InodeTree.INode<T> {
        final Map<String, InodeTree.INode<T>> PSNITYPAMW = new HashMap<String, InodeTree.INode<T>>();

        T MCGVAFKDCF = null;// file system of this internal directory of mountT


        boolean UREWVIHUQM = false;

        INodeDir(final String pathToNode, final UserGroupInformation aUgi) {
            super(pathToNode, aUgi);
        }

        InodeTree.INode<T> resolve(final String pathComponent) throws FileNotFoundException {
            final InodeTree.INode<T> result = resolveInternal(pathComponent);
            if (result == null) {
                throw new FileNotFoundException();
            }
            return result;
        }

        InodeTree.INode<T> resolveInternal(final String pathComponent) {
            return PSNITYPAMW.get(pathComponent);
        }

        InodeTree.INodeDir<T> addDir(final String pathComponent, final UserGroupInformation aUgi) throws FileAlreadyExistsException {
            if (PSNITYPAMW.containsKey(pathComponent)) {
                throw new FileAlreadyExistsException();
            }
            final InodeTree.INodeDir<T> newDir = new InodeTree.INodeDir<T>((EEHOSKKIRP + (UREWVIHUQM ? "" : "/")) + pathComponent, aUgi);
            PSNITYPAMW.put(pathComponent, newDir);
            return newDir;
        }

        void addLink(final String pathComponent, final InodeTree.INodeLink<T> link) throws FileAlreadyExistsException {
            if (PSNITYPAMW.containsKey(pathComponent)) {
                throw new FileAlreadyExistsException();
            }
            PSNITYPAMW.put(pathComponent, link);
        }
    }

    /**
     * In internal class to represent a mount link
     * A mount link can be single dir link or a merge dir link.
     *
     * A merge dir link is  a merge (junction) of links to dirs:
     * example : <merge of 2 dirs
     *     /users -> hdfs:nn1//users
     *     /users -> hdfs:nn2//users
     *
     * For a merge, each target is checked to be dir when created but if target
     * is changed later it is then ignored (a dir with null entries)
     */
    static class INodeLink<T> extends InodeTree.INode<T> {
        final boolean QSKVWRAZNL;// true if MergeLink


        final URI[] BYLWJEGVEU;

        final T KEXMTYHQMC;// file system object created from the link.


        /**
         * Construct a mergeLink
         */
        INodeLink(final String pathToNode, final UserGroupInformation aUgi, final T targetMergeFs, final URI[] aTargetDirLinkList) {
            super(pathToNode, aUgi);
            KEXMTYHQMC = targetMergeFs;
            BYLWJEGVEU = aTargetDirLinkList;
            QSKVWRAZNL = true;
        }

        /**
         * Construct a simple link (i.e. not a mergeLink)
         */
        INodeLink(final String pathToNode, final UserGroupInformation aUgi, final T targetFs, final URI aTargetDirLink) {
            super(pathToNode, aUgi);
            KEXMTYHQMC = targetFs;
            BYLWJEGVEU = new URI[1];
            BYLWJEGVEU[0] = aTargetDirLink;
            QSKVWRAZNL = false;
        }

        /**
         * Get the target of the link
         * If a merge link then it returned as "," separated URI list.
         */
        Path getTargetLink() {
            // is merge link - use "," as separator between the merged URIs
            // String result = targetDirLinkList[0].toString();
            StringBuilder result = new StringBuilder(BYLWJEGVEU[0].toString());
            for (int i = 1; i < targetDirLinkList.length; ++i) {
                result.append(',').append(BYLWJEGVEU[i].toString());
            }
            return new Path(result.toString());
        }
    }

    private void createLink(final String MGWQROVTZU, final String SGPQCHEETV, final boolean RQRAVKEGEM, final UserGroupInformation APGZDATYKM) throws IOException, URISyntaxException, FileAlreadyExistsException, UnsupportedFileSystemException {
        // Validate that src is valid absolute path
        final Path TECZZNKVYU = new Path(MGWQROVTZU);
        if (!TECZZNKVYU.isAbsoluteAndSchemeAuthorityNull()) {
            throw new IOException("ViewFs:Non absolute mount name in config:" + MGWQROVTZU);
        }
        final String[] EKRHXTHXOF = InodeTree.breakIntoPathComponents(MGWQROVTZU);
        InodeTree.INodeDir<T> BGHFLRVYAK = CVJRWQCPUC;
        int UKKEAEFROP;
        // Ignore first initial slash, process all except last component
        for (UKKEAEFROP = 1; UKKEAEFROP < (EKRHXTHXOF.length - 1); UKKEAEFROP++) {
            final String LZLXYHPHDH = EKRHXTHXOF[UKKEAEFROP];
            InodeTree.INode<T> CMHHZJJYUX = BGHFLRVYAK.resolveInternal(LZLXYHPHDH);
            if (CMHHZJJYUX == null) {
                InodeTree.INodeDir<T> THMFWUTDZU = BGHFLRVYAK.addDir(LZLXYHPHDH, APGZDATYKM);
                THMFWUTDZU.InodeDirFs = getTargetFileSystem(THMFWUTDZU);
                CMHHZJJYUX = THMFWUTDZU;
            }
            if (CMHHZJJYUX instanceof InodeTree.INodeLink) {
                // Error - expected a dir but got a link
                throw new FileAlreadyExistsException(("Path " + CMHHZJJYUX.fullPath) + " already exists as link");
            } else {
                assert CMHHZJJYUX instanceof InodeTree.INodeDir;
                BGHFLRVYAK = ((InodeTree.INodeDir<T>) (CMHHZJJYUX));
            }
        }
        // Now process the last component
        // Add the link in 2 cases: does not exist or a link exists
        String BOMJNJJGPS = EKRHXTHXOF[UKKEAEFROP];// last component

        if (BGHFLRVYAK.resolveInternal(BOMJNJJGPS) != null) {
            // directory/link already exists
            StringBuilder UFLDJITTGQ = new StringBuilder(EKRHXTHXOF[0]);
            for (int GTUIZAETCX = 1; GTUIZAETCX <= UKKEAEFROP; ++GTUIZAETCX) {
                UFLDJITTGQ.append('/').append(EKRHXTHXOF[GTUIZAETCX]);
            }
            throw new FileAlreadyExistsException(("Path " + UFLDJITTGQ) + " already exists as dir; cannot create link here");
        }
        final InodeTree.INodeLink<T> PEQCYWYHHF;
        final String QHFYFOTCWF = (BGHFLRVYAK.fullPath + (BGHFLRVYAK == CVJRWQCPUC ? "" : "/")) + BOMJNJJGPS;
        if (RQRAVKEGEM) {
            // Target is list of URIs
            String[] SNHQBSIPET = StringUtils.getStrings(SGPQCHEETV);
            URI[] VOGVWJRUIY = new URI[SNHQBSIPET.length];
            int GWKQUZOZCS = 0;
            for (String YZEKDWQYNT : SNHQBSIPET) {
                VOGVWJRUIY[GWKQUZOZCS++] = new URI(YZEKDWQYNT);
            }
            PEQCYWYHHF = new InodeTree.INodeLink<T>(QHFYFOTCWF, APGZDATYKM, getTargetFileSystem(VOGVWJRUIY), VOGVWJRUIY);
        } else {
            PEQCYWYHHF = new InodeTree.INodeLink<T>(QHFYFOTCWF, APGZDATYKM, getTargetFileSystem(new URI(SGPQCHEETV)), new URI(SGPQCHEETV));
        }
        BGHFLRVYAK.addLink(BOMJNJJGPS, PEQCYWYHHF);
        GNFLQDBLKM.add(new InodeTree.MountPoint<T>(MGWQROVTZU, PEQCYWYHHF));
    }

    /**
     * Below the "public" methods of InodeTree
     */
    /**
     * The user of this class must subclass and implement the following
     * 3 abstract methods.
     *
     * @throws IOException
     * 		
     */
    protected abstract T getTargetFileSystem(final URI GVZRGTBLSP) throws IOException, URISyntaxException, UnsupportedFileSystemException;

    protected abstract T getTargetFileSystem(final InodeTree.INodeDir<T> VNJYGNGGDP) throws URISyntaxException;

    protected abstract T getTargetFileSystem(final URI[] FQJPTMWDAJ) throws URISyntaxException, UnsupportedFileSystemException;

    /**
     * Create Inode Tree from the specified mount-table specified in Config
     *
     * @param config
     * 		- the mount table keys are prefixed with
     * 		FsConstants.CONFIG_VIEWFS_PREFIX
     * @param viewName
     * 		- the name of the mount table - if null use defaultMT name
     * @throws UnsupportedFileSystemException
     * 		
     * @throws URISyntaxException
     * 		
     * @throws FileAlreadyExistsException
     * 		
     * @throws IOException
     * 		
     */
    protected InodeTree(final Configuration RDTXMSNPFU, final String ABTNDEKIPB) throws IOException, URISyntaxException, FileAlreadyExistsException, UnsupportedFileSystemException {
        String SNJJSYKFJU = ABTNDEKIPB;
        if (SNJJSYKFJU == null) {
            SNJJSYKFJU = Constants.CONFIG_VIEWFS_DEFAULT_MOUNT_TABLE;
        }
        JTHPUPEOJT = ConfigUtil.getHomeDirValue(RDTXMSNPFU, SNJJSYKFJU);
        CVJRWQCPUC = new InodeTree.INodeDir<T>("/", UserGroupInformation.getCurrentUser());
        root.InodeDirFs = getTargetFileSystem(CVJRWQCPUC);
        root.isRoot = true;
        final String MSZWHEKZZQ = ((Constants.CONFIG_VIEWFS_PREFIX + ".") + SNJJSYKFJU) + ".";
        final String JWYJFSWRNM = Constants.CONFIG_VIEWFS_LINK + ".";
        final String ZKJBUGHFWB = Constants.CONFIG_VIEWFS_LINK_MERGE + ".";
        boolean EGEBWDXKVK = false;
        final UserGroupInformation SJBYIBBXUM = UserGroupInformation.getCurrentUser();
        for (Map.Entry<String, String> YSZCEQGENL : RDTXMSNPFU) {
            final String MWVKEPVCUS = YSZCEQGENL.getKey();
            if (MWVKEPVCUS.startsWith(MSZWHEKZZQ)) {
                EGEBWDXKVK = true;
                boolean MCFNDEEKCK = false;
                String OGOVOQIDGG = MWVKEPVCUS.substring(MSZWHEKZZQ.length());
                if (OGOVOQIDGG.startsWith(JWYJFSWRNM)) {
                    OGOVOQIDGG = OGOVOQIDGG.substring(JWYJFSWRNM.length());
                } else
                    if (OGOVOQIDGG.startsWith(ZKJBUGHFWB)) {
                        // A merge link
                        MCFNDEEKCK = true;
                        OGOVOQIDGG = OGOVOQIDGG.substring(ZKJBUGHFWB.length());
                    } else
                        if (OGOVOQIDGG.startsWith(CONFIG_VIEWFS_HOMEDIR)) {
                            // ignore - we set home dir from config
                            continue;
                        } else {
                            throw new IOException("ViewFs: Cannot initialize: Invalid entry in Mount table in config: " + OGOVOQIDGG);
                        }


                final String SRMGORORAO = YSZCEQGENL.getValue();// link or merge link

                createLink(OGOVOQIDGG, SRMGORORAO, MCFNDEEKCK, SJBYIBBXUM);
            }
        }
        if (!EGEBWDXKVK) {
            throw new IOException((("ViewFs: Cannot initialize: Empty Mount table in config for " + "viewfs://") + SNJJSYKFJU) + "/");
        }
    }

    /**
     * Resolve returns ResolveResult.
     * The caller can continue the resolution of the remainingPath
     * in the targetFileSystem.
     *
     * If the input pathname leads to link to another file system then
     * the targetFileSystem is the one denoted by the link (except it is
     * file system chrooted to link target.
     * If the input pathname leads to an internal mount-table entry then
     * the target file system is one that represents the internal inode.
     */
    static class ResolveResult<T> {
        final InodeTree.ResultKind QHRUNELCPI;

        final T UUEWWBDZPT;

        final String OKBRQCQFNF;

        final Path GTWTPOFBMP;// to resolve in the target FileSystem


        ResolveResult(final InodeTree.ResultKind k, final T targetFs, final String resolveP, final Path remainingP) {
            QHRUNELCPI = k;
            UUEWWBDZPT = targetFs;
            OKBRQCQFNF = resolveP;
            GTWTPOFBMP = remainingP;
        }

        // isInternalDir of path resolution completed within the mount table
        boolean isInternalDir() {
            return QHRUNELCPI == InodeTree.ResultKind.isInternalDir;
        }
    }

    /**
     * Resolve the pathname p relative to root InodeDir
     *
     * @param p
     * 		- inout path
     * @param resolveLastComponent
     * 		
     * @return ResolveResult which allows further resolution of the remaining path
     * @throws FileNotFoundException
     * 		
     */
    InodeTree.ResolveResult<T> resolve(final String SETQGGXGFS, final boolean PBWENTISLA) throws FileNotFoundException {
        // TO DO: - more efficient to not split the path, but simply compare
        String[] RRTKMJAXOW = InodeTree.breakIntoPathComponents(SETQGGXGFS);
        if (RRTKMJAXOW.length <= 1) {
            // special case for when path is "/"
            InodeTree.ResolveResult<T> FLLYDSXHSD = new InodeTree.ResolveResult<T>(InodeTree.ResultKind.isInternalDir, root.InodeDirFs, root.fullPath, InodeTree.AMYATMMITI);
            return FLLYDSXHSD;
        }
        InodeTree.INodeDir<T> NYQYKGQAUB = CVJRWQCPUC;
        int FAMINVJVQL;
        // ignore first slash
        for (FAMINVJVQL = 1; FAMINVJVQL < (RRTKMJAXOW.length - (PBWENTISLA ? 0 : 1)); FAMINVJVQL++) {
            InodeTree.INode<T> UHYUVOCVJJ = NYQYKGQAUB.resolveInternal(RRTKMJAXOW[FAMINVJVQL]);
            if (UHYUVOCVJJ == null) {
                StringBuilder CUGUSTFLCF = new StringBuilder(RRTKMJAXOW[0]);
                for (int TCOGRWCAML = 1; TCOGRWCAML <= FAMINVJVQL; ++TCOGRWCAML) {
                    CUGUSTFLCF.append('/').append(RRTKMJAXOW[TCOGRWCAML]);
                }
                throw new FileNotFoundException(CUGUSTFLCF.toString());
            }
            if (UHYUVOCVJJ instanceof InodeTree.INodeLink) {
                final InodeTree.INodeLink<T> OFSFLMUDOM = ((InodeTree.INodeLink<T>) (UHYUVOCVJJ));
                final Path QKMNPYWSSO;
                if (FAMINVJVQL >= (RRTKMJAXOW.length - 1)) {
                    QKMNPYWSSO = InodeTree.AMYATMMITI;
                } else {
                    StringBuilder GFAIGHVYIT = new StringBuilder("/" + RRTKMJAXOW[FAMINVJVQL + 1]);
                    for (int WLTIMNVSYO = FAMINVJVQL + 2; WLTIMNVSYO < RRTKMJAXOW.length; ++WLTIMNVSYO) {
                        GFAIGHVYIT.append('/').append(RRTKMJAXOW[WLTIMNVSYO]);
                    }
                    QKMNPYWSSO = new Path(GFAIGHVYIT.toString());
                }
                final InodeTree.ResolveResult<T> PKGJJTJHGD = new InodeTree.ResolveResult<T>(InodeTree.ResultKind.isExternalDir, OFSFLMUDOM.targetFileSystem, UHYUVOCVJJ.fullPath, QKMNPYWSSO);
                return PKGJJTJHGD;
            } else
                if (UHYUVOCVJJ instanceof InodeTree.INodeDir) {
                    NYQYKGQAUB = ((InodeTree.INodeDir<T>) (UHYUVOCVJJ));
                }

        }
        // We have resolved to an internal dir in mount table.
        Path QMUGQGBIID;
        if (PBWENTISLA) {
            QMUGQGBIID = InodeTree.AMYATMMITI;
        } else {
            // note we have taken care of when path is "/" above
            // for internal dirs rem-path does not start with / since the lookup
            // that follows will do a children.get(remaningPath) and will have to
            // strip-out the initial /
            StringBuilder UPVGDYPSKX = new StringBuilder("/" + RRTKMJAXOW[FAMINVJVQL]);
            for (int HQCFEMXWNN = FAMINVJVQL + 1; HQCFEMXWNN < RRTKMJAXOW.length; ++HQCFEMXWNN) {
                UPVGDYPSKX.append('/').append(RRTKMJAXOW[HQCFEMXWNN]);
            }
            QMUGQGBIID = new Path(UPVGDYPSKX.toString());
        }
        final InodeTree.ResolveResult<T> JXEWRMONTS = new InodeTree.ResolveResult<T>(InodeTree.ResultKind.isInternalDir, NYQYKGQAUB.InodeDirFs, NYQYKGQAUB.fullPath, QMUGQGBIID);
        return JXEWRMONTS;
    }

    List<InodeTree.MountPoint<T>> getMountPoints() {
        return GNFLQDBLKM;
    }

    /**
     *
     *
     * @return home dir value from mount table; null if no config value
    was found.
     */
    String getHomeDirPrefixValue() {
        return JTHPUPEOJT;
    }
}