public class TestKerberosAuthenticator extends KerberosSecurityTestcase {
    @Before
    public void setup() throws Exception {
        // create keytab
        File UGWOBXTSWB = new File(KerberosTestUtils.getKeytabFile());
        String TGQRGXANKC = KerberosTestUtils.getClientPrincipal();
        String FHYABKEEAZ = KerberosTestUtils.getServerPrincipal();
        TGQRGXANKC = TGQRGXANKC.substring(0, TGQRGXANKC.lastIndexOf("@"));
        FHYABKEEAZ = FHYABKEEAZ.substring(0, FHYABKEEAZ.lastIndexOf("@"));
        getKdc().createPrincipal(UGWOBXTSWB, TGQRGXANKC, FHYABKEEAZ);
    }

    private Properties getAuthenticationHandlerConfiguration() {
        Properties MIZLFRYAAF = new Properties();
        MIZLFRYAAF.setProperty(AUTH_TYPE, "kerberos");
        MIZLFRYAAF.setProperty(PRINCIPAL, KerberosTestUtils.getServerPrincipal());
        MIZLFRYAAF.setProperty(KEYTAB, KerberosTestUtils.getKeytabFile());
        MIZLFRYAAF.setProperty(NAME_RULES, ("RULE:[1:$1@$0](.*@" + KerberosTestUtils.getRealm()) + ")s/@.*//\n");
        return MIZLFRYAAF;
    }

    @Test(timeout = 60000)
    public void testFallbacktoPseudoAuthenticator() throws Exception {
        AuthenticatorTestCase FMQIYRXITZ = new AuthenticatorTestCase();
        Properties PXTXZXCUBZ = new Properties();
        PXTXZXCUBZ.setProperty(AUTH_TYPE, "simple");
        PXTXZXCUBZ.setProperty(ANONYMOUS_ALLOWED, "false");
        AuthenticatorTestCase.setAuthenticationHandlerConfig(PXTXZXCUBZ);
        FMQIYRXITZ._testAuthentication(new KerberosAuthenticator(), false);
    }

    @Test(timeout = 60000)
    public void testFallbacktoPseudoAuthenticatorAnonymous() throws Exception {
        AuthenticatorTestCase CDBTQGTUMW = new AuthenticatorTestCase();
        Properties WAJVSFXMQS = new Properties();
        WAJVSFXMQS.setProperty(AUTH_TYPE, "simple");
        WAJVSFXMQS.setProperty(ANONYMOUS_ALLOWED, "true");
        AuthenticatorTestCase.setAuthenticationHandlerConfig(WAJVSFXMQS);
        CDBTQGTUMW._testAuthentication(new KerberosAuthenticator(), false);
    }

    @Test(timeout = 60000)
    public void testNotAuthenticated() throws Exception {
        AuthenticatorTestCase ZNWUJRJZXS = new AuthenticatorTestCase();
        AuthenticatorTestCase.setAuthenticationHandlerConfig(getAuthenticationHandlerConfiguration());
        ZNWUJRJZXS.start();
        try {
            URL SOMMLYTIDY = new URL(ZNWUJRJZXS.getBaseURL());
            HttpURLConnection FYBSRGROME = ((HttpURLConnection) (SOMMLYTIDY.openConnection()));
            FYBSRGROME.connect();
            Assert.assertEquals(HttpURLConnection.HTTP_UNAUTHORIZED, FYBSRGROME.getResponseCode());
            Assert.assertTrue(FYBSRGROME.getHeaderField(WWW_AUTHENTICATE) != null);
        } finally {
            ZNWUJRJZXS.stop();
        }
    }

    @Test(timeout = 60000)
    public void testAuthentication() throws Exception {
        final AuthenticatorTestCase LXBBCVDGJO = new AuthenticatorTestCase();
        AuthenticatorTestCase.setAuthenticationHandlerConfig(getAuthenticationHandlerConfiguration());
        KerberosTestUtils.doAsClient(new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                LXBBCVDGJO._testAuthentication(new KerberosAuthenticator(), false);
                return null;
            }
        });
    }

    @Test(timeout = 60000)
    public void testAuthenticationPost() throws Exception {
        final AuthenticatorTestCase ZRLEOLGWLF = new AuthenticatorTestCase();
        AuthenticatorTestCase.setAuthenticationHandlerConfig(getAuthenticationHandlerConfiguration());
        KerberosTestUtils.doAsClient(new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                ZRLEOLGWLF._testAuthentication(new KerberosAuthenticator(), true);
                return null;
            }
        });
    }
}