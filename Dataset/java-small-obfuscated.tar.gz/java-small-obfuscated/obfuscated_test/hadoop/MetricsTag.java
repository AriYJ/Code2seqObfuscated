/**
 * Immutable tag for metrics (for grouping on host/queue/username etc.)
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class MetricsTag implements MetricsInfo {
    private final MetricsInfo VHAQXKVFVD;

    private final String OZJJVEVCVG;

    /**
     * Construct the tag with name, description and value
     *
     * @param info
     * 		of the tag
     * @param value
     * 		of the tag
     */
    public MetricsTag(MetricsInfo SUCSBKQIGE, String VYZTBETUTQ) {
        this.VHAQXKVFVD = checkNotNull(SUCSBKQIGE, "tag info");
        this.OZJJVEVCVG = VYZTBETUTQ;
    }

    @Override
    public String name() {
        return VHAQXKVFVD.name();
    }

    @Override
    public String description() {
        return VHAQXKVFVD.description();
    }

    /**
     *
     *
     * @return the info object of the tag
     */
    public MetricsInfo info() {
        return VHAQXKVFVD;
    }

    /**
     * Get the value of the tag
     *
     * @return the value
     */
    public String value() {
        return OZJJVEVCVG;
    }

    @Override
    public boolean equals(Object MSKWXZPAYV) {
        if (MSKWXZPAYV instanceof MetricsTag) {
            final MetricsTag RYYSPBDROC = ((MetricsTag) (MSKWXZPAYV));
            return Objects.equal(VHAQXKVFVD, RYYSPBDROC.info()) && Objects.equal(OZJJVEVCVG, RYYSPBDROC.value());
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(VHAQXKVFVD, OZJJVEVCVG);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("info", VHAQXKVFVD).add("value", value()).toString();
    }
}