/**
 * Performs no reduction, writing all input values directly to the output.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class IdentityReducer<K, V> extends MapReduceBase implements Reducer<K, V, K, V> {
    /**
     * Writes all keys and values directly to output.
     */
    public void reduce(K POHNZPQWYB, Iterator<V> VHFUOCYUNM, OutputCollector<K, V> MBVOQHBXTV, Reporter MCTZWTDHGJ) throws IOException {
        while (VHFUOCYUNM.hasNext()) {
            MBVOQHBXTV.collect(POHNZPQWYB, VHFUOCYUNM.next());
        } 
    }
}