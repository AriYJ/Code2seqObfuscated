public class RMAuthenticationHandler extends KerberosAuthenticationHandler {
    public static final String DYEPXBWRCP = "kerberos-dt";

    public static final String VAPYZKPKFG = "Hadoop-YARN-Auth-Delegation-Token";

    static RMDelegationTokenSecretManager CHOHBXOBXX;

    static boolean DJXYVLCMBL = false;

    public RMAuthenticationHandler() {
        super();
    }

    /**
     * Returns authentication type of the handler.
     *
     * @return <code>kerberos-dt</code>
     */
    @Override
    public String getType() {
        return RMAuthenticationHandler.DYEPXBWRCP;
    }

    @Override
    public boolean managementOperation(AuthenticationToken WUUPOAOUKK, HttpServletRequest JTRTEFLPGJ, HttpServletResponse LSCNOYWORQ) {
        return true;
    }

    /**
     * Authenticates a request looking for the <code>delegation</code> header and
     * verifying it is a valid token. If the header is missing, it delegates the
     * authentication to the {@link KerberosAuthenticationHandler} unless it is
     * disabled.
     *
     * @param request
     * 		the HTTP client request.
     * @param response
     * 		the HTTP client response.
     * @return the authentication token for the authenticated request.
     * @throws IOException
     * 		thrown if an IO error occurred.
     * @throws AuthenticationException
     * 		thrown if the authentication failed.
     */
    @Override
    public AuthenticationToken authenticate(HttpServletRequest OWABQOHARA, HttpServletResponse DUYHBOGZBC) throws IOException, AuthenticationException {
        AuthenticationToken CKQQYJJXOP;
        String KNQYSFUXJI = this.getEncodedDelegationTokenFromRequest(OWABQOHARA);
        if (KNQYSFUXJI != null) {
            Token<RMDelegationTokenIdentifier> YOCYATZWFW = new Token<RMDelegationTokenIdentifier>();
            YOCYATZWFW.decodeFromUrlString(KNQYSFUXJI);
            UserGroupInformation HUEPMMQJMN = this.verifyToken(YOCYATZWFW);
            if (HUEPMMQJMN == null) {
                throw new AuthenticationException("Invalid token");
            }
            final String HWWVOLRHVN = HUEPMMQJMN.getShortUserName();
            CKQQYJJXOP = new AuthenticationToken(HWWVOLRHVN, HUEPMMQJMN.getUserName(), getType());
        } else {
            CKQQYJJXOP = super.authenticate(OWABQOHARA, DUYHBOGZBC);
            if (CKQQYJJXOP != null) {
                // create a token with auth type set correctly
                CKQQYJJXOP = new AuthenticationToken(CKQQYJJXOP.getUserName(), CKQQYJJXOP.getName(), super.getType());
            }
        }
        return CKQQYJJXOP;
    }

    /**
     * Verifies a delegation token.
     *
     * @param token
     * 		delegation token to verify.
     * @return the UGI for the token; null if the verification fails
     * @throws IOException
     * 		thrown if the token could not be verified.
     */
    protected UserGroupInformation verifyToken(Token<RMDelegationTokenIdentifier> DBPQBJXELL) throws IOException {
        if (RMAuthenticationHandler.DJXYVLCMBL == false) {
            throw new IllegalStateException("Secret manager not initialized");
        }
        ByteArrayInputStream CKYNSIZRCB = new ByteArrayInputStream(DBPQBJXELL.getIdentifier());
        DataInputStream PPXLROOCLQ = new DataInputStream(CKYNSIZRCB);
        RMDelegationTokenIdentifier GKSACVIZDD = RMAuthenticationHandler.CHOHBXOBXX.createIdentifier();
        try {
            GKSACVIZDD.readFields(PPXLROOCLQ);
            RMAuthenticationHandler.CHOHBXOBXX.verifyToken(GKSACVIZDD, DBPQBJXELL.getPassword());
        } catch (Throwable t) {
            return null;
        } finally {
            PPXLROOCLQ.close();
        }
        return GKSACVIZDD.getUser();
    }

    /**
     * Extract encoded delegation token from request
     *
     * @param req
     * 		HTTPServletRequest object
     * @return String containing the encoded token; null if encoded token not
    found
     */
    protected String getEncodedDelegationTokenFromRequest(HttpServletRequest RVVBYRUMGQ) {
        String YEVRPVOLBB = RVVBYRUMGQ.getHeader(RMAuthenticationHandler.VAPYZKPKFG);
        return YEVRPVOLBB;
    }

    public static void setSecretManager(RMDelegationTokenSecretManager COOTDFPXPS) {
        RMAuthenticationHandler.CHOHBXOBXX = COOTDFPXPS;
        RMAuthenticationHandler.DJXYVLCMBL = true;
    }
}