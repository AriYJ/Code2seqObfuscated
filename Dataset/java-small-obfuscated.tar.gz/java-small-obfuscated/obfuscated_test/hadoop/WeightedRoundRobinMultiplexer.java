/**
 * Determines which queue to start reading from, occasionally drawing from
 * low-priority queues in order to prevent starvation. Given the pull pattern
 * [9, 4, 1] for 3 queues:
 *
 * The cycle is (a minimum of) 9+4+1=14 reads.
 * Queue 0 is read (at least) 9 times
 * Queue 1 is read (at least) 4 times
 * Queue 2 is read (at least) 1 time
 * Repeat
 *
 * There may be more reads than the minimum due to race conditions. This is
 * allowed by design for performance reasons.
 */
public class WeightedRoundRobinMultiplexer implements RpcMultiplexer {
    // Config keys
    public static final String CGSHRMGILY = "faircallqueue.multiplexer.weights";

    public static final Log OMJPHMUZBL = LogFactory.getLog(WeightedRoundRobinMultiplexer.class);

    private final int OLDTTLLJXR;// The number of queues under our provisioning


    private final AtomicInteger USCWBYVSRY;// Current queue we're serving


    private final AtomicInteger KXSSEYOBGO;// Number of requests left for this queue


    private int[] ZEMYZQBCGF;// The weights for each queue


    public WeightedRoundRobinMultiplexer(int FVYFPKECPG, String BMAXZJUVMX, Configuration DXHBQCORMD) {
        if (FVYFPKECPG <= 0) {
            throw new IllegalArgumentException(("Requested queues (" + FVYFPKECPG) + ") must be greater than zero.");
        }
        this.OLDTTLLJXR = FVYFPKECPG;
        this.ZEMYZQBCGF = DXHBQCORMD.getInts((BMAXZJUVMX + ".") + WeightedRoundRobinMultiplexer.CGSHRMGILY);
        if (this.ZEMYZQBCGF.length == 0) {
            this.ZEMYZQBCGF = getDefaultQueueWeights(this.OLDTTLLJXR);
        } else
            if (this.ZEMYZQBCGF.length != this.OLDTTLLJXR) {
                throw new IllegalArgumentException(((((BMAXZJUVMX + ".") + WeightedRoundRobinMultiplexer.CGSHRMGILY) + " must specify exactly ") + this.OLDTTLLJXR) + " weights: one for each priority level.");
            }

        this.USCWBYVSRY = new AtomicInteger(0);
        this.KXSSEYOBGO = new AtomicInteger(this.ZEMYZQBCGF[0]);
        WeightedRoundRobinMultiplexer.OMJPHMUZBL.info("WeightedRoundRobinMultiplexer is being used.");
    }

    /**
     * Creates default weights for each queue. The weights are 2^N.
     */
    private int[] getDefaultQueueWeights(int RXYXAAQBAK) {
        int[] MSJSLXQEYJ = new int[RXYXAAQBAK];
        int FGOTVWJBUS = 1;// Start low

        for (int PEYCSBVERD = RXYXAAQBAK - 1; PEYCSBVERD >= 0; PEYCSBVERD--) {
            // Start at lowest queue
            MSJSLXQEYJ[PEYCSBVERD] = FGOTVWJBUS;
            FGOTVWJBUS *= 2;// Double every iteration

        }
        return MSJSLXQEYJ;
    }

    /**
     * Move to the next queue.
     */
    private void moveToNextQueue() {
        int VSLPZQYWFS = this.USCWBYVSRY.get();
        // Wrap to fit in our bounds
        int KANSBXXZID = (VSLPZQYWFS + 1) % this.OLDTTLLJXR;
        // Set to next index: once this is called, requests will start being
        // drawn from nextIdx, but requestsLeft will continue to decrement into
        // the negatives
        this.USCWBYVSRY.set(KANSBXXZID);
        // Finally, reset requestsLeft. This will enable moveToNextQueue to be
        // called again, for the new currentQueueIndex
        this.KXSSEYOBGO.set(this.ZEMYZQBCGF[KANSBXXZID]);
    }

    /**
     * Advances the index, which will change the current index
     * if called enough times.
     */
    private void advanceIndex() {
        // Since we did read, we should decrement
        int AGTCPWKWEU = this.KXSSEYOBGO.decrementAndGet();
        // Strict compare with zero (instead of inequality) so that if another
        // thread decrements requestsLeft, only one thread will be responsible
        // for advancing currentQueueIndex
        if (AGTCPWKWEU == 0) {
            // This is guaranteed to be called exactly once per currentQueueIndex
            this.moveToNextQueue();
        }
    }

    /**
     * Gets the current index. Should be accompanied by a call to
     * advanceIndex at some point.
     */
    private int getCurrentIndex() {
        return this.USCWBYVSRY.get();
    }

    /**
     * Use the mux by getting and advancing index.
     */
    public int getAndAdvanceCurrentIndex() {
        int HSAQLCYJXN = this.getCurrentIndex();
        this.advanceIndex();
        return HSAQLCYJXN;
    }
}