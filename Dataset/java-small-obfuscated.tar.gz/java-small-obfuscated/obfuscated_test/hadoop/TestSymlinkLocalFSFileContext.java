public class TestSymlinkLocalFSFileContext extends TestSymlinkLocalFS {
    @BeforeClass
    public static void testSetup() throws Exception {
        FileContext ZJAHDTFUUS = FileContext.getLocalFSFileContext();
        wrapper = new FileContextTestWrapper(ZJAHDTFUUS);
    }

    @Override
    public void testRenameFileWithDestParentSymlink() throws IOException {
        assumeTrue(!Shell.WINDOWS);
        super.testRenameFileWithDestParentSymlink();
    }
}