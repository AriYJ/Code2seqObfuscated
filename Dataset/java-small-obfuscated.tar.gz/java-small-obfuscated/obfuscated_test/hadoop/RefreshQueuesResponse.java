@Private
@Stable
public abstract class RefreshQueuesResponse {
    @Private
    @Unstable
    public static RefreshQueuesResponse newInstance() {
        RefreshQueuesResponse BWQSXCIEAN = Records.newRecord(RefreshQueuesResponse.class);
        return BWQSXCIEAN;
    }
}