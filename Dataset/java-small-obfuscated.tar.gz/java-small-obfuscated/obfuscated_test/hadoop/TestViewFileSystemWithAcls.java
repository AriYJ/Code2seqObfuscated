/**
 * Verify ACL through ViewFileSystem functionality.
 */
public class TestViewFileSystemWithAcls {
    private static MiniDFSCluster VJOQGAAZVM;

    private static Configuration TZRMDMZJYO = new Configuration();

    private static FileSystem ISZEGIHXAM;

    private static FileSystem DDCYKKDCKC;

    private FileSystem MEFVJCXKPS;

    private Configuration TKERTFUKOI;

    private FileSystem QTUYLCMVKF;

    private FileSystem UIXMYMWSMT;

    private Path ITVJLMVSRH;

    private Path SELDJFXJOD;

    private Path VLDDNYZXUW;

    private Path DCJZSCOWUA;

    private FileSystemTestHelper YHQUVZDCJS = new FileSystemTestHelper("/tmp/TestViewFileSystemWithAcls");

    @BeforeClass
    public static void clusterSetupAtBeginning() throws IOException {
        TestViewFileSystemWithAcls.TZRMDMZJYO.setBoolean(DFS_NAMENODE_ACLS_ENABLED_KEY, true);
        TestViewFileSystemWithAcls.VJOQGAAZVM = new MiniDFSCluster.Builder(TestViewFileSystemWithAcls.TZRMDMZJYO).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleFederatedTopology(2)).numDataNodes(2).build();
        TestViewFileSystemWithAcls.VJOQGAAZVM.waitClusterUp();
        TestViewFileSystemWithAcls.ISZEGIHXAM = TestViewFileSystemWithAcls.VJOQGAAZVM.getFileSystem(0);
        TestViewFileSystemWithAcls.DDCYKKDCKC = TestViewFileSystemWithAcls.VJOQGAAZVM.getFileSystem(1);
    }

    @AfterClass
    public static void ClusterShutdownAtEnd() throws Exception {
        TestViewFileSystemWithAcls.VJOQGAAZVM.shutdown();
    }

    @Before
    public void setUp() throws Exception {
        QTUYLCMVKF = TestViewFileSystemWithAcls.ISZEGIHXAM;
        UIXMYMWSMT = TestViewFileSystemWithAcls.DDCYKKDCKC;
        ITVJLMVSRH = YHQUVZDCJS.getAbsoluteTestRootPath(QTUYLCMVKF);
        SELDJFXJOD = YHQUVZDCJS.getAbsoluteTestRootPath(UIXMYMWSMT);
        QTUYLCMVKF.delete(ITVJLMVSRH, true);
        UIXMYMWSMT.delete(SELDJFXJOD, true);
        QTUYLCMVKF.mkdirs(ITVJLMVSRH);
        UIXMYMWSMT.mkdirs(SELDJFXJOD);
        TKERTFUKOI = ViewFileSystemTestSetup.createConfig();
        setupMountPoints();
        MEFVJCXKPS = FileSystem.get(VIEWFS_URI, TKERTFUKOI);
    }

    private void setupMountPoints() {
        VLDDNYZXUW = new Path("/mountOnNn1");
        DCJZSCOWUA = new Path("/mountOnNn2");
        ConfigUtil.addLink(TKERTFUKOI, VLDDNYZXUW.toString(), ITVJLMVSRH.toUri());
        ConfigUtil.addLink(TKERTFUKOI, DCJZSCOWUA.toString(), SELDJFXJOD.toUri());
    }

    @After
    public void tearDown() throws Exception {
        QTUYLCMVKF.delete(YHQUVZDCJS.getTestRootPath(QTUYLCMVKF), true);
        UIXMYMWSMT.delete(YHQUVZDCJS.getTestRootPath(UIXMYMWSMT), true);
    }

    /**
     * Verify a ViewFs wrapped over multiple federated NameNodes will
     * dispatch the ACL operations to the correct NameNode.
     */
    @Test
    public void testAclOnMountEntry() throws Exception {
        // Set ACLs on the first namespace and verify they are correct
        List<AclEntry> KAORVZRHTM = Lists.newArrayList(aclEntry(ACCESS, USER, READ_WRITE), aclEntry(ACCESS, USER, "foo", READ), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, NONE));
        MEFVJCXKPS.setAcl(VLDDNYZXUW, KAORVZRHTM);
        AclEntry[] XRXUHIBGWR = new AclEntry[]{ aclEntry(ACCESS, USER, "foo", READ), aclEntry(ACCESS, GROUP, READ) };
        assertArrayEquals(XRXUHIBGWR, aclEntryArray(MEFVJCXKPS.getAclStatus(VLDDNYZXUW)));
        // Double-check by getting ACL status using FileSystem
        // instead of ViewFs
        assertArrayEquals(XRXUHIBGWR, aclEntryArray(TestViewFileSystemWithAcls.ISZEGIHXAM.getAclStatus(ITVJLMVSRH)));
        // Modify the ACL entries on the first namespace
        KAORVZRHTM = Lists.newArrayList(aclEntry(DEFAULT, USER, "foo", READ));
        MEFVJCXKPS.modifyAclEntries(VLDDNYZXUW, KAORVZRHTM);
        XRXUHIBGWR = new AclEntry[]{ aclEntry(ACCESS, USER, "foo", READ), aclEntry(ACCESS, GROUP, READ), aclEntry(DEFAULT, USER, READ_WRITE), aclEntry(DEFAULT, USER, "foo", READ), aclEntry(DEFAULT, GROUP, READ), aclEntry(DEFAULT, MASK, READ), aclEntry(DEFAULT, OTHER, NONE) };
        assertArrayEquals(XRXUHIBGWR, aclEntryArray(MEFVJCXKPS.getAclStatus(VLDDNYZXUW)));
        MEFVJCXKPS.removeDefaultAcl(VLDDNYZXUW);
        XRXUHIBGWR = new AclEntry[]{ aclEntry(ACCESS, USER, "foo", READ), aclEntry(ACCESS, GROUP, READ) };
        assertArrayEquals(XRXUHIBGWR, aclEntryArray(MEFVJCXKPS.getAclStatus(VLDDNYZXUW)));
        assertArrayEquals(XRXUHIBGWR, aclEntryArray(TestViewFileSystemWithAcls.ISZEGIHXAM.getAclStatus(ITVJLMVSRH)));
        // Paranoid check: verify the other namespace does not
        // have ACLs set on the same path.
        assertEquals(0, MEFVJCXKPS.getAclStatus(DCJZSCOWUA).getEntries().size());
        assertEquals(0, TestViewFileSystemWithAcls.DDCYKKDCKC.getAclStatus(SELDJFXJOD).getEntries().size());
        // Remove the ACL entries on the first namespace
        MEFVJCXKPS.removeAcl(VLDDNYZXUW);
        assertEquals(0, MEFVJCXKPS.getAclStatus(VLDDNYZXUW).getEntries().size());
        assertEquals(0, TestViewFileSystemWithAcls.ISZEGIHXAM.getAclStatus(ITVJLMVSRH).getEntries().size());
        // Now set ACLs on the second namespace
        KAORVZRHTM = Lists.newArrayList(aclEntry(ACCESS, USER, "bar", READ));
        MEFVJCXKPS.modifyAclEntries(DCJZSCOWUA, KAORVZRHTM);
        XRXUHIBGWR = new AclEntry[]{ aclEntry(ACCESS, USER, "bar", READ), aclEntry(ACCESS, GROUP, READ_EXECUTE) };
        assertArrayEquals(XRXUHIBGWR, aclEntryArray(MEFVJCXKPS.getAclStatus(DCJZSCOWUA)));
        assertArrayEquals(XRXUHIBGWR, aclEntryArray(TestViewFileSystemWithAcls.DDCYKKDCKC.getAclStatus(SELDJFXJOD)));
        // Remove the ACL entries on the second namespace
        MEFVJCXKPS.removeAclEntries(DCJZSCOWUA, Lists.newArrayList(aclEntry(ACCESS, USER, "bar", READ)));
        XRXUHIBGWR = new AclEntry[]{ aclEntry(ACCESS, GROUP, READ_EXECUTE) };
        assertArrayEquals(XRXUHIBGWR, aclEntryArray(TestViewFileSystemWithAcls.DDCYKKDCKC.getAclStatus(SELDJFXJOD)));
        MEFVJCXKPS.removeAcl(DCJZSCOWUA);
        assertEquals(0, MEFVJCXKPS.getAclStatus(DCJZSCOWUA).getEntries().size());
        assertEquals(0, TestViewFileSystemWithAcls.DDCYKKDCKC.getAclStatus(SELDJFXJOD).getEntries().size());
    }

    private AclEntry[] aclEntryArray(AclStatus QKGZQYOYED) {
        return QKGZQYOYED.getEntries().toArray(new AclEntry[0]);
    }
}