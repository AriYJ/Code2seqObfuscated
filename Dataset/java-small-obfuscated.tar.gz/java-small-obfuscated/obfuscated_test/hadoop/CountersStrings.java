/**
 * String conversion utilities for counters.
 * Candidate for deprecation since we start to use JSON in 0.21+
 */
@InterfaceAudience.Private
public class CountersStrings {
    private static final char XSACZTNZUR = '{';

    private static final char CVJXKPKKGH = '}';

    private static final char CARDLHFRJR = '[';

    private static final char XGLRBQFVAO = ']';

    private static final char ZRUJJKKGQT = '(';

    private static final char TEVRVMNZJB = ')';

    private static char[] NXDRAHTMTC = new char[]{ CountersStrings.XSACZTNZUR, CountersStrings.CVJXKPKKGH, CountersStrings.CARDLHFRJR, CountersStrings.XGLRBQFVAO, CountersStrings.ZRUJJKKGQT, CountersStrings.TEVRVMNZJB };

    /**
     * Make the pre 0.21 counter string (for e.g. old job history files)
     * [(actual-name)(display-name)(value)]
     *
     * @param counter
     * 		to stringify
     * @return the stringified result
     */
    public static String toEscapedCompactString(Counter YLZIXIGSSB) {
        // First up, obtain the strings that need escaping. This will help us
        // determine the buffer length apriori.
        String QFQEKYQRPV;
        String VRNLYTKWDK;
        long DVCERPHERH;
        synchronized(YLZIXIGSSB) {
            QFQEKYQRPV = CountersStrings.escape(YLZIXIGSSB.getName());
            VRNLYTKWDK = CountersStrings.escape(YLZIXIGSSB.getDisplayName());
            DVCERPHERH = YLZIXIGSSB.getValue();
        }
        int FPNFQCTUAW = (QFQEKYQRPV.length() + VRNLYTKWDK.length()) + 4;
        FPNFQCTUAW += 8;// For the following delimiting characters

        StringBuilder BLPBYWGILU = new StringBuilder(FPNFQCTUAW);
        BLPBYWGILU.append(CountersStrings.CARDLHFRJR);
        // Add the counter name
        BLPBYWGILU.append(CountersStrings.ZRUJJKKGQT);
        BLPBYWGILU.append(QFQEKYQRPV);
        BLPBYWGILU.append(CountersStrings.TEVRVMNZJB);
        // Add the display name
        BLPBYWGILU.append(CountersStrings.ZRUJJKKGQT);
        BLPBYWGILU.append(VRNLYTKWDK);
        BLPBYWGILU.append(CountersStrings.TEVRVMNZJB);
        // Add the value
        BLPBYWGILU.append(CountersStrings.ZRUJJKKGQT);
        BLPBYWGILU.append(DVCERPHERH);
        BLPBYWGILU.append(CountersStrings.TEVRVMNZJB);
        BLPBYWGILU.append(CountersStrings.XGLRBQFVAO);
        return BLPBYWGILU.toString();
    }

    /**
     * Make the 0.21 counter group string.
     * format: {(actual-name)(display-name)(value)[][][]}
     * where [] are compact strings for the counters within.
     *
     * @param <G>
     * 		type of the group
     * @param group
     * 		to stringify
     * @return the stringified result
     */
    public static <G extends CounterGroupBase<?>> String toEscapedCompactString(G HFQQVWKIQG) {
        List<String> MXMEYWKBFD = Lists.newArrayList();
        int URQMAZEJOG;
        String OEJLCDSATR;
        String SZXHVWOWUD;
        synchronized(HFQQVWKIQG) {
            // First up, obtain the strings that need escaping. This will help us
            // determine the buffer length apriori.
            OEJLCDSATR = CountersStrings.escape(HFQQVWKIQG.getName());
            SZXHVWOWUD = CountersStrings.escape(HFQQVWKIQG.getDisplayName());
            int LVKCNLWKYK = 0;
            URQMAZEJOG = OEJLCDSATR.length() + SZXHVWOWUD.length();
            for (Counter KOXHMGUDBI : HFQQVWKIQG) {
                String PGWKVJIQHG = CountersStrings.toEscapedCompactString(KOXHMGUDBI);
                MXMEYWKBFD.add(PGWKVJIQHG);
                URQMAZEJOG += PGWKVJIQHG.length();
            }
        }
        URQMAZEJOG += 6;// for all the delimiting characters below

        StringBuilder ESLZOPMQGS = new StringBuilder(URQMAZEJOG);
        ESLZOPMQGS.append(CountersStrings.XSACZTNZUR);// group start

        // Add the group name
        ESLZOPMQGS.append(CountersStrings.ZRUJJKKGQT);
        ESLZOPMQGS.append(OEJLCDSATR);
        ESLZOPMQGS.append(CountersStrings.TEVRVMNZJB);
        // Add the display name
        ESLZOPMQGS.append(CountersStrings.ZRUJJKKGQT);
        ESLZOPMQGS.append(SZXHVWOWUD);
        ESLZOPMQGS.append(CountersStrings.TEVRVMNZJB);
        // write the value
        for (String ULCKAGFSQB : MXMEYWKBFD) {
            ESLZOPMQGS.append(ULCKAGFSQB);
        }
        ESLZOPMQGS.append(CountersStrings.CVJXKPKKGH);// group end

        return ESLZOPMQGS.toString();
    }

    /**
     * Make the pre 0.21 counters string
     *
     * @param <C>
     * 		type of the counter
     * @param <G>
     * 		type of the counter group
     * @param <T>
     * 		type of the counters object
     * @param counters
     * 		the object to stringify
     * @return the string in the following format
    {(groupName)(group-displayName)[(counterName)(displayName)(value)]*}*
     */
    public static <C extends Counter, G extends CounterGroupBase<C>, T extends AbstractCounters<C, G>> String toEscapedCompactString(T FUORFMELFZ) {
        String[] GCTSRZQUKF;
        int QSYMPJVVWM = 0;
        synchronized(FUORFMELFZ) {
            GCTSRZQUKF = new String[FUORFMELFZ.countCounters()];
            int LPRVWAEQVS = 0;
            // First up, obtain the escaped string for each group so that we can
            // determine the buffer length apriori.
            for (G MQMEYQQZXT : FUORFMELFZ) {
                String GYQQEOAYZE = CountersStrings.toEscapedCompactString(MQMEYQQZXT);
                GCTSRZQUKF[LPRVWAEQVS++] = GYQQEOAYZE;
                QSYMPJVVWM += GYQQEOAYZE.length();
            }
        }
        // Now construct the buffer
        StringBuilder NAMOOPYONU = new StringBuilder(QSYMPJVVWM);
        for (String WVCRAXGYKY : GCTSRZQUKF) {
            NAMOOPYONU.append(WVCRAXGYKY);
        }
        return NAMOOPYONU.toString();
    }

    // Escapes all the delimiters for counters i.e {,[,(,),],}
    private static String escape(String FMUWTPOTIK) {
        return StringUtils.escapeString(FMUWTPOTIK, ESCAPE_CHAR, CountersStrings.NXDRAHTMTC);
    }

    // Unescapes all the delimiters for counters i.e {,[,(,),],}
    private static String unescape(String ILLGNWJPBM) {
        return StringUtils.unEscapeString(ILLGNWJPBM, ESCAPE_CHAR, CountersStrings.NXDRAHTMTC);
    }

    // Extracts a block (data enclosed within delimeters) ignoring escape
    // sequences. Throws ParseException if an incomplete block is found else
    // returns null.
    private static String getBlock(String HHPEGYTNEJ, char XMSSMNWZLJ, char JWXDSKOODJ, IntWritable RUMWJKWDPW) throws ParseException {
        StringBuilder GPOKWSMLEV = new StringBuilder();
        int AYSLUZEJHM = StringUtils.findNext(HHPEGYTNEJ, XMSSMNWZLJ, ESCAPE_CHAR, RUMWJKWDPW.get(), GPOKWSMLEV);
        GPOKWSMLEV.setLength(0);// clear the buffer

        if (AYSLUZEJHM >= 0) {
            ++AYSLUZEJHM;// move over '('

            AYSLUZEJHM = StringUtils.findNext(HHPEGYTNEJ, JWXDSKOODJ, ESCAPE_CHAR, AYSLUZEJHM, GPOKWSMLEV);
            if (AYSLUZEJHM >= 0) {
                ++AYSLUZEJHM;// move over ')'

                RUMWJKWDPW.set(AYSLUZEJHM);
                return GPOKWSMLEV.toString();// found a block

            } else {
                throw new ParseException("Unexpected end of block", AYSLUZEJHM);
            }
        }
        return null;// found nothing

    }

    /**
     * Parse a pre 0.21 counters string into a counter object.
     *
     * @param <C>
     * 		type of the counter
     * @param <G>
     * 		type of the counter group
     * @param <T>
     * 		type of the counters object
     * @param compactString
     * 		to parse
     * @param counters
     * 		an empty counters object to hold the result
     * @return the counters object holding the result
     * @throws ParseException
     * 		
     */
    @SuppressWarnings("deprecation")
    public static <C extends Counter, G extends CounterGroupBase<C>, T extends AbstractCounters<C, G>> T parseEscapedCompactString(String CRRSFYRZNC, T PLCNVMCUVK) throws ParseException {
        IntWritable YRZEYRFKIK = new IntWritable(0);
        // Get the group to work on
        String RDFJHIRVLX = CountersStrings.getBlock(CRRSFYRZNC, CountersStrings.XSACZTNZUR, CountersStrings.CVJXKPKKGH, YRZEYRFKIK);
        while (RDFJHIRVLX != null) {
            IntWritable WEKHELNEBL = new IntWritable(0);
            // Get the actual name
            String PUCFWPGHOC = StringInterner.weakIntern(CountersStrings.getBlock(RDFJHIRVLX, CountersStrings.ZRUJJKKGQT, CountersStrings.TEVRVMNZJB, WEKHELNEBL));
            PUCFWPGHOC = StringInterner.weakIntern(CountersStrings.unescape(PUCFWPGHOC));
            // Get the display name
            String LFKNSVGUOX = StringInterner.weakIntern(CountersStrings.getBlock(RDFJHIRVLX, CountersStrings.ZRUJJKKGQT, CountersStrings.TEVRVMNZJB, WEKHELNEBL));
            LFKNSVGUOX = StringInterner.weakIntern(CountersStrings.unescape(LFKNSVGUOX));
            // Get the counters
            G AUCJRQTECC = PLCNVMCUVK.getGroup(PUCFWPGHOC);
            AUCJRQTECC.setDisplayName(LFKNSVGUOX);
            String BOVKVOHRAK = CountersStrings.getBlock(RDFJHIRVLX, CountersStrings.CARDLHFRJR, CountersStrings.XGLRBQFVAO, WEKHELNEBL);
            while (BOVKVOHRAK != null) {
                IntWritable MYZMVKAFNV = new IntWritable(0);
                // Get the actual name
                String VCBDTPVHFV = StringInterner.weakIntern(CountersStrings.getBlock(BOVKVOHRAK, CountersStrings.ZRUJJKKGQT, CountersStrings.TEVRVMNZJB, MYZMVKAFNV));
                VCBDTPVHFV = StringInterner.weakIntern(CountersStrings.unescape(VCBDTPVHFV));
                // Get the display name
                String DAGIILUMSN = StringInterner.weakIntern(CountersStrings.getBlock(BOVKVOHRAK, CountersStrings.ZRUJJKKGQT, CountersStrings.TEVRVMNZJB, MYZMVKAFNV));
                DAGIILUMSN = StringInterner.weakIntern(CountersStrings.unescape(DAGIILUMSN));
                // Get the value
                long IFGRIDDYJE = Long.parseLong(CountersStrings.getBlock(BOVKVOHRAK, CountersStrings.ZRUJJKKGQT, CountersStrings.TEVRVMNZJB, MYZMVKAFNV));
                // Add the counter
                Counter ACNXYUOXFE = AUCJRQTECC.findCounter(VCBDTPVHFV);
                ACNXYUOXFE.setDisplayName(DAGIILUMSN);
                ACNXYUOXFE.increment(IFGRIDDYJE);
                // Get the next counter
                BOVKVOHRAK = CountersStrings.getBlock(RDFJHIRVLX, CountersStrings.CARDLHFRJR, CountersStrings.XGLRBQFVAO, WEKHELNEBL);
            } 
            RDFJHIRVLX = CountersStrings.getBlock(CRRSFYRZNC, CountersStrings.XSACZTNZUR, CountersStrings.CVJXKPKKGH, YRZEYRFKIK);
        } 
        return PLCNVMCUVK;
    }
}