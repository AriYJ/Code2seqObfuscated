public class TestHFSTestCase extends HFSTestCase {
    @Test(expected = IllegalStateException.class)
    public void testDirNoAnnotation() throws Exception {
        TestDirHelper.getTestDir();
    }

    @Test(expected = IllegalStateException.class)
    public void testJettyNoAnnotation() throws Exception {
        TestJettyHelper.getJettyServer();
    }

    @Test(expected = IllegalStateException.class)
    public void testJettyNoAnnotation2() throws Exception {
        TestJettyHelper.getJettyURL();
    }

    @Test(expected = IllegalStateException.class)
    public void testHdfsNoAnnotation() throws Exception {
        TestHdfsHelper.getHdfsConf();
    }

    @Test(expected = IllegalStateException.class)
    public void testHdfsNoAnnotation2() throws Exception {
        TestHdfsHelper.getHdfsTestDir();
    }

    @Test
    @TestDir
    public void testDirAnnotation() throws Exception {
        assertNotNull(TestDirHelper.getTestDir());
    }

    @Test
    public void waitFor() {
        long ZESACCEFAL = Time.now();
        long FUFMHIUANH = waitFor(1000, new Predicate() {
            @Override
            public boolean evaluate() throws Exception {
                return true;
            }
        });
        long MMVCQBMYQS = Time.now();
        assertEquals(FUFMHIUANH, 0, 50);
        assertEquals((MMVCQBMYQS - ZESACCEFAL) - FUFMHIUANH, 0, 50);
    }

    @Test
    public void waitForTimeOutRatio1() {
        setWaitForRatio(1);
        long PRCEOYGJJL = Time.now();
        long HIYOQRJTOX = waitFor(200, new Predicate() {
            @Override
            public boolean evaluate() throws Exception {
                return false;
            }
        });
        long PHVAZVMDJD = Time.now();
        assertEquals(HIYOQRJTOX, -1);
        assertEquals(PHVAZVMDJD - PRCEOYGJJL, 200, 50);
    }

    @Test
    public void waitForTimeOutRatio2() {
        setWaitForRatio(2);
        long OWJNHPOJUG = Time.now();
        long RXXNMPIWBM = waitFor(200, new Predicate() {
            @Override
            public boolean evaluate() throws Exception {
                return false;
            }
        });
        long GHMWOCISPI = Time.now();
        assertEquals(RXXNMPIWBM, -1);
        assertEquals(GHMWOCISPI - OWJNHPOJUG, 200 * getWaitForRatio(), 50 * getWaitForRatio());
    }

    @Test
    public void sleepRatio1() {
        setWaitForRatio(1);
        long WJJQMCQFNU = Time.now();
        sleep(100);
        long FOVVBWFXUC = Time.now();
        assertEquals(FOVVBWFXUC - WJJQMCQFNU, 100, 50);
    }

    @Test
    public void sleepRatio2() {
        setWaitForRatio(1);
        long VXTBJDAGMX = Time.now();
        sleep(100);
        long UNAFWOMTMP = Time.now();
        assertEquals(UNAFWOMTMP - VXTBJDAGMX, 100 * getWaitForRatio(), 50 * getWaitForRatio());
    }

    @Test
    @TestHdfs
    public void testHadoopFileSystem() throws Exception {
        Configuration ZTXYTSYRJZ = TestHdfsHelper.getHdfsConf();
        FileSystem IQDPDMXAKR = FileSystem.get(ZTXYTSYRJZ);
        try {
            OutputStream KVHDVSZYTB = IQDPDMXAKR.create(new org.apache.hadoop.fs.Path(TestHdfsHelper.getHdfsTestDir(), "foo"));
            KVHDVSZYTB.write(new byte[]{ 1 });
            KVHDVSZYTB.close();
            InputStream KTNTPJBZEB = IQDPDMXAKR.open(new org.apache.hadoop.fs.Path(TestHdfsHelper.getHdfsTestDir(), "foo"));
            assertEquals(KTNTPJBZEB.read(), 1);
            assertEquals(KTNTPJBZEB.read(), -1);
            KTNTPJBZEB.close();
        } finally {
            IQDPDMXAKR.close();
        }
    }

    public static class MyServlet extends HttpServlet {
        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
            resp.getWriter().write("foo");
        }
    }

    @Test
    @TestJetty
    public void testJetty() throws Exception {
        Context KMBCNUNBIW = new Context();
        KMBCNUNBIW.setContextPath("/");
        KMBCNUNBIW.addServlet(TestHFSTestCase.MyServlet.class, "/bar");
        Server QXSAFNIJQS = TestJettyHelper.getJettyServer();
        QXSAFNIJQS.addHandler(KMBCNUNBIW);
        QXSAFNIJQS.start();
        URL XSXXLSCEJL = new URL(TestJettyHelper.getJettyURL(), "/bar");
        HttpURLConnection BLYLSAZQOJ = ((HttpURLConnection) (XSXXLSCEJL.openConnection()));
        assertEquals(BLYLSAZQOJ.getResponseCode(), HttpURLConnection.HTTP_OK);
        BufferedReader HXHAGOTIPN = new BufferedReader(new InputStreamReader(BLYLSAZQOJ.getInputStream()));
        assertEquals(HXHAGOTIPN.readLine(), "foo");
        HXHAGOTIPN.close();
    }

    @Test
    @TestException(exception = RuntimeException.class)
    public void testException0() {
        throw new RuntimeException("foo");
    }

    @Test
    @TestException(exception = RuntimeException.class, msgRegExp = ".o.")
    public void testException1() {
        throw new RuntimeException("foo");
    }
}