/**
 * This test makes sure that when
 * {@link DFSConfigKeys#DFS_CLIENT_TEST_DROP_NAMENODE_RESPONSE_NUM_KEY} is set,
 * DFSClient instances can still be created within NN/DN (e.g., the fs instance
 * used by the trash emptier thread in NN)
 */
public class TestLossyRetryInvocationHandler {
    @Test
    public void testStartNNWithTrashEmptier() throws Exception {
        MiniDFSCluster EAVWMVBAOO = null;
        Configuration IEIPFPJXOX = new HdfsConfiguration();
        // enable both trash emptier and dropping response
        IEIPFPJXOX.setLong("fs.trash.interval", 360);
        IEIPFPJXOX.setInt(DFS_CLIENT_TEST_DROP_NAMENODE_RESPONSE_NUM_KEY, 2);
        try {
            EAVWMVBAOO = new MiniDFSCluster.Builder(IEIPFPJXOX).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).build();
            EAVWMVBAOO.waitActive();
            EAVWMVBAOO.transitionToActive(0);
        } finally {
            if (EAVWMVBAOO != null) {
                EAVWMVBAOO.shutdown();
            }
        }
    }
}