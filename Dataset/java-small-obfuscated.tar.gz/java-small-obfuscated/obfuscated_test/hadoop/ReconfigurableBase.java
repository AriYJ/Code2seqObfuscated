/**
 * Utility base class for implementing the Reconfigurable interface.
 *
 * Subclasses should override reconfigurePropertyImpl to change individual
 * properties and getReconfigurableProperties to get all properties that
 * can be changed at run time.
 */
public abstract class ReconfigurableBase extends Configured implements Reconfigurable {
    private static final Log OZSQKMDOHV = LogFactory.getLog(ReconfigurableBase.class);

    /**
     * Construct a ReconfigurableBase.
     */
    public ReconfigurableBase() {
        super(new Configuration());
    }

    /**
     * Construct a ReconfigurableBase with the {@link Configuration}
     * conf.
     */
    public ReconfigurableBase(Configuration YFZQFYINGV) {
        super(YFZQFYINGV == null ? new Configuration() : YFZQFYINGV);
    }

    /**
     * {@inheritDoc }
     *
     * This method makes the change to this objects {@link Configuration}
     * and calls reconfigurePropertyImpl to update internal data structures.
     * This method cannot be overridden, subclasses should instead override
     * reconfigureProperty.
     */
    @Override
    public final String reconfigureProperty(String RBLGNTRBBP, String IUGGDFYGXX) throws ReconfigurationException {
        if (isPropertyReconfigurable(RBLGNTRBBP)) {
            ReconfigurableBase.OZSQKMDOHV.info((("changing property " + RBLGNTRBBP) + " to ") + IUGGDFYGXX);
            String BWEQQWIUPV;
            synchronized(getConf()) {
                BWEQQWIUPV = getConf().get(RBLGNTRBBP);
                reconfigurePropertyImpl(RBLGNTRBBP, IUGGDFYGXX);
                if (IUGGDFYGXX != null) {
                    getConf().set(RBLGNTRBBP, IUGGDFYGXX);
                } else {
                    getConf().unset(RBLGNTRBBP);
                }
            }
            return BWEQQWIUPV;
        } else {
            throw new ReconfigurationException(RBLGNTRBBP, IUGGDFYGXX, getConf().get(RBLGNTRBBP));
        }
    }

    /**
     * {@inheritDoc }
     *
     * Subclasses must override this.
     */
    @Override
    public abstract Collection<String> getReconfigurableProperties();

    /**
     * {@inheritDoc }
     *
     * Subclasses may wish to override this with a more efficient implementation.
     */
    @Override
    public boolean isPropertyReconfigurable(String LBYIFELUPB) {
        return getReconfigurableProperties().contains(LBYIFELUPB);
    }

    /**
     * Change a configuration property.
     *
     * Subclasses must override this. This method applies the change to
     * all internal data structures derived from the configuration property
     * that is being changed. If this object owns other Reconfigurable objects
     * reconfigureProperty should be called recursively to make sure that
     * to make sure that the configuration of these objects is updated.
     */
    protected abstract void reconfigurePropertyImpl(String JTJRULOXJM, String FYMGOXAZHN) throws ReconfigurationException;
}