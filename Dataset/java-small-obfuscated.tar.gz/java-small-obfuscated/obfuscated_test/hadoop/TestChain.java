public class TestChain {
    @Test
    public void testSetReducerWithReducerByValueAsTrue() throws Exception {
        JobConf DJWZDXBCJZ = new JobConf();
        JobConf VCCKVCFYAU = new JobConf();
        Chain.setReducer(DJWZDXBCJZ, TestChain.MyReducer.class, Object.class, Object.class, Object.class, Object.class, true, VCCKVCFYAU);
        boolean OCPOYUYMPZ = VCCKVCFYAU.getBoolean("chain.reducer.byValue", false);
        Assert.assertEquals("It should set chain.reducer.byValue as true " + "in reducerConf when we give value as true", true, OCPOYUYMPZ);
    }

    @Test
    public void testSetReducerWithReducerByValueAsFalse() throws Exception {
        JobConf QMQBJFXBPD = new JobConf();
        JobConf YNFASZXXRI = new JobConf();
        Chain.setReducer(QMQBJFXBPD, TestChain.MyReducer.class, Object.class, Object.class, Object.class, Object.class, false, YNFASZXXRI);
        boolean RXVGAUIPLM = YNFASZXXRI.getBoolean("chain.reducer.byValue", true);
        Assert.assertEquals("It should set chain.reducer.byValue as false " + "in reducerConf when we give value as false", false, RXVGAUIPLM);
    }

    interface MyReducer extends Reducer<Object, Object, Object, Object> {}
}