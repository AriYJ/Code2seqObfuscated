public class YarnClientProtocolProvider extends ClientProtocolProvider {
    @Override
    public ClientProtocol create(Configuration URVMQSLNIZ) throws IOException {
        if (YARN_FRAMEWORK_NAME.equals(URVMQSLNIZ.get(FRAMEWORK_NAME))) {
            return new YARNRunner(URVMQSLNIZ);
        }
        return null;
    }

    @Override
    public ClientProtocol create(InetSocketAddress NRXYCKLUQA, Configuration RSHUWEYWVU) throws IOException {
        return create(RSHUWEYWVU);
    }

    @Override
    public void close(ClientProtocol OCDYOGEILJ) throws IOException {
        // nothing to do
    }
}