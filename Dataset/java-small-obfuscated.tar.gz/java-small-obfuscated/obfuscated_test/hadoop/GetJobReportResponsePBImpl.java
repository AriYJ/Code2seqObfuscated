public class GetJobReportResponsePBImpl extends ProtoBase<GetJobReportResponseProto> implements GetJobReportResponse {
    GetJobReportResponseProto CJDZNJQTQW = GetJobReportResponseProto.getDefaultInstance();

    Builder WZNDEGAJZG = null;

    boolean VKTALOXSFW = false;

    private JobReport PVGDPIZMQF = null;

    public GetJobReportResponsePBImpl() {
        WZNDEGAJZG = GetJobReportResponseProto.newBuilder();
    }

    public GetJobReportResponsePBImpl(GetJobReportResponseProto UXSDZMWCYH) {
        this.CJDZNJQTQW = UXSDZMWCYH;
        VKTALOXSFW = true;
    }

    public GetJobReportResponseProto getProto() {
        mergeLocalToProto();
        CJDZNJQTQW = (VKTALOXSFW) ? CJDZNJQTQW : WZNDEGAJZG.build();
        VKTALOXSFW = true;
        return CJDZNJQTQW;
    }

    private void mergeLocalToBuilder() {
        if (this.PVGDPIZMQF != null) {
            WZNDEGAJZG.setJobReport(convertToProtoFormat(this.PVGDPIZMQF));
        }
    }

    private void mergeLocalToProto() {
        if (VKTALOXSFW)
            maybeInitBuilder();

        mergeLocalToBuilder();
        CJDZNJQTQW = WZNDEGAJZG.build();
        VKTALOXSFW = true;
    }

    private void maybeInitBuilder() {
        if (VKTALOXSFW || (WZNDEGAJZG == null)) {
            WZNDEGAJZG = GetJobReportResponseProto.newBuilder(CJDZNJQTQW);
        }
        VKTALOXSFW = false;
    }

    @Override
    public JobReport getJobReport() {
        GetJobReportResponseProtoOrBuilder PTMBVBHECB = (VKTALOXSFW) ? CJDZNJQTQW : WZNDEGAJZG;
        if (this.PVGDPIZMQF != null) {
            return this.PVGDPIZMQF;
        }
        if (!PTMBVBHECB.hasJobReport()) {
            return null;
        }
        this.PVGDPIZMQF = convertFromProtoFormat(PTMBVBHECB.getJobReport());
        return this.PVGDPIZMQF;
    }

    @Override
    public void setJobReport(JobReport JLMTWBMBRK) {
        maybeInitBuilder();
        if (JLMTWBMBRK == null)
            WZNDEGAJZG.clearJobReport();

        this.PVGDPIZMQF = JLMTWBMBRK;
    }

    private JobReportPBImpl convertFromProtoFormat(JobReportProto FJBTRIJMWJ) {
        return new JobReportPBImpl(FJBTRIJMWJ);
    }

    private JobReportProto convertToProtoFormat(JobReport QKGENKMGIC) {
        return ((JobReportPBImpl) (QKGENKMGIC)).getProto();
    }
}