/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with this
 * work for additional information regarding copyright ownership. The ASF
 * licenses this file to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
public class TestAllocateResponse {
    @Test
    public void testAllocateResponseWithIncDecContainers() {
        List<ContainerResourceIncrease> TWTQZUTAPL = new ArrayList<ContainerResourceIncrease>();
        List<ContainerResourceDecrease> NRPDUJMUDR = new ArrayList<ContainerResourceDecrease>();
        for (int PKCLJJJEYJ = 0; PKCLJJJEYJ < 3; PKCLJJJEYJ++) {
            TWTQZUTAPL.add(ContainerResourceIncrease.newInstance(null, Resource.newInstance(1024, PKCLJJJEYJ), null));
        }
        for (int AWZCINHECC = 0; AWZCINHECC < 5; AWZCINHECC++) {
            NRPDUJMUDR.add(ContainerResourceDecrease.newInstance(null, Resource.newInstance(1024, AWZCINHECC)));
        }
        AllocateResponse WMHTTSESYP = AllocateResponse.newInstance(3, new ArrayList<org.apache.hadoop.yarn.api.records.ContainerStatus>(), new ArrayList<org.apache.hadoop.yarn.api.records.Container>(), new ArrayList<org.apache.hadoop.yarn.api.records.NodeReport>(), null, AM_RESYNC, 3, null, new ArrayList<org.apache.hadoop.yarn.api.records.NMToken>(), TWTQZUTAPL, NRPDUJMUDR);
        // serde
        AllocateResponseProto UKXWJXXUUA = ((org.apache.hadoop.yarn.api.protocolrecords.impl.pb.AllocateResponsePBImpl) (WMHTTSESYP)).getProto();
        WMHTTSESYP = new org.apache.hadoop.yarn.api.protocolrecords.impl.pb.AllocateResponsePBImpl(UKXWJXXUUA);
        // check value
        Assert.assertEquals(TWTQZUTAPL.size(), WMHTTSESYP.getIncreasedContainers().size());
        Assert.assertEquals(NRPDUJMUDR.size(), WMHTTSESYP.getDecreasedContainers().size());
        for (int IPYLEHZDVD = 0; IPYLEHZDVD < TWTQZUTAPL.size(); IPYLEHZDVD++) {
            Assert.assertEquals(IPYLEHZDVD, WMHTTSESYP.getIncreasedContainers().get(IPYLEHZDVD).getCapability().getVirtualCores());
        }
        for (int RWDBXVGEZN = 0; RWDBXVGEZN < NRPDUJMUDR.size(); RWDBXVGEZN++) {
            Assert.assertEquals(RWDBXVGEZN, WMHTTSESYP.getDecreasedContainers().get(RWDBXVGEZN).getCapability().getVirtualCores());
        }
    }

    @Test
    public void testAllocateResponseWithoutIncDecContainers() {
        AllocateResponse RKIFCWOOVQ = AllocateResponse.newInstance(3, new ArrayList<org.apache.hadoop.yarn.api.records.ContainerStatus>(), new ArrayList<org.apache.hadoop.yarn.api.records.Container>(), new ArrayList<org.apache.hadoop.yarn.api.records.NodeReport>(), null, AM_RESYNC, 3, null, new ArrayList<org.apache.hadoop.yarn.api.records.NMToken>(), null, null);
        // serde
        AllocateResponseProto UZOAZMGMXG = ((org.apache.hadoop.yarn.api.protocolrecords.impl.pb.AllocateResponsePBImpl) (RKIFCWOOVQ)).getProto();
        RKIFCWOOVQ = new org.apache.hadoop.yarn.api.protocolrecords.impl.pb.AllocateResponsePBImpl(UZOAZMGMXG);
        // check value
        Assert.assertEquals(0, RKIFCWOOVQ.getIncreasedContainers().size());
        Assert.assertEquals(0, RKIFCWOOVQ.getDecreasedContainers().size());
    }
}