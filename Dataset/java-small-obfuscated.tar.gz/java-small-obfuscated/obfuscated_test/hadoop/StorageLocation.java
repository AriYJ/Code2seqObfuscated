/**
 * Encapsulates the URI and storage medium that together describe a
 * storage directory.
 * The default storage medium is assumed to be DISK, if none is specified.
 */
@InterfaceAudience.Private
public class StorageLocation {
    final StorageType XXXWSTDOIY;

    final File IGYAHBOLKU;

    /**
     * Regular expression that describes a storage uri with a storage type.
     *  e.g. [Disk]/storages/storage1/
     */
    private static final Pattern RMWGXSDQZB = Pattern.compile("^\\[(\\w*)\\](.+)$");

    private StorageLocation(StorageType JERTDVKHIP, URI VRUFFBLKVN) {
        this.XXXWSTDOIY = JERTDVKHIP;
        if ((VRUFFBLKVN.getScheme() == null) || "file".equalsIgnoreCase(VRUFFBLKVN.getScheme())) {
            // drop any (illegal) authority in the URI for backwards compatibility
            this.IGYAHBOLKU = new File(VRUFFBLKVN.getPath());
        } else {
            throw new IllegalArgumentException("Unsupported URI schema in " + VRUFFBLKVN);
        }
    }

    public StorageType getStorageType() {
        return this.XXXWSTDOIY;
    }

    URI getUri() {
        return IGYAHBOLKU.toURI();
    }

    public File getFile() {
        return this.IGYAHBOLKU;
    }

    /**
     * Attempt to parse a storage uri with storage class and URI. The storage
     * class component of the uri is case-insensitive.
     *
     * @param rawLocation
     * 		Location string of the format [type]uri, where [type] is
     * 		optional.
     * @return A StorageLocation object if successfully parsed, null otherwise.
    Does not throw any exceptions.
     */
    public static StorageLocation parse(String LVMURADBWU) throws IOException, SecurityException {
        Matcher GFSWLLVDHY = StorageLocation.RMWGXSDQZB.matcher(LVMURADBWU);
        StorageType EBDWPWSVAM = StorageType.DEFAULT;
        String UKXBIDIYCW = LVMURADBWU;
        if (GFSWLLVDHY.matches()) {
            String AAVHRJQCYB = GFSWLLVDHY.group(1);
            UKXBIDIYCW = GFSWLLVDHY.group(2);
            if (!AAVHRJQCYB.isEmpty()) {
                EBDWPWSVAM = StorageType.valueOf(AAVHRJQCYB.toUpperCase());
            }
        }
        return new StorageLocation(EBDWPWSVAM, Util.stringAsURI(UKXBIDIYCW));
    }

    @Override
    public String toString() {
        return (("[" + XXXWSTDOIY) + "]") + IGYAHBOLKU.toURI();
    }
}