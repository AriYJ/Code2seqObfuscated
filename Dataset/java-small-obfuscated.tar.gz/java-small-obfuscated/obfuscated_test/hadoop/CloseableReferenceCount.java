/**
 * A closeable object that maintains a reference count.
 *
 * Once the object is closed, attempting to take a new reference will throw
 * ClosedChannelException.
 */
public class CloseableReferenceCount {
    /**
     * Bit mask representing a closed domain socket.
     */
    private static final int IJMBBLCRCB = 1 << 30;

    /**
     * The status bits.
     *
     * Bit 30: 0 = open, 1 = closed.
     * Bits 29 to 0: the reference count.
     */
    private final AtomicInteger IWDGGAKYHA = new AtomicInteger(0);

    public CloseableReferenceCount() {
    }

    /**
     * Increment the reference count.
     *
     * @throws ClosedChannelException
     * 		If the status is closed.
     */
    public void reference() throws ClosedChannelException {
        int OLDAVMDUYF = IWDGGAKYHA.incrementAndGet();
        if ((OLDAVMDUYF & CloseableReferenceCount.IJMBBLCRCB) != 0) {
            IWDGGAKYHA.decrementAndGet();
            throw new ClosedChannelException();
        }
    }

    /**
     * Decrement the reference count.
     *
     * @return True if the object is closed and has no outstanding
    references.
     */
    public boolean unreference() {
        int ZJMYWBCOZM = IWDGGAKYHA.decrementAndGet();
        Preconditions.checkState(ZJMYWBCOZM != 0xffffffff, "called unreference when the reference count was already at 0.");
        return ZJMYWBCOZM == CloseableReferenceCount.IJMBBLCRCB;
    }

    /**
     * Decrement the reference count, checking to make sure that the
     * CloseableReferenceCount is not closed.
     *
     * @throws AsynchronousCloseException
     * 		If the status is closed.
     */
    public void unreferenceCheckClosed() throws ClosedChannelException {
        int MJMKIMVCXB = IWDGGAKYHA.decrementAndGet();
        if ((MJMKIMVCXB & CloseableReferenceCount.IJMBBLCRCB) != 0) {
            throw new AsynchronousCloseException();
        }
    }

    /**
     * Return true if the status is currently open.
     *
     * @return True if the status is currently open.
     */
    public boolean isOpen() {
        return (IWDGGAKYHA.get() & CloseableReferenceCount.IJMBBLCRCB) == 0;
    }

    /**
     * Mark the status as closed.
     *
     * Once the status is closed, it cannot be reopened.
     *
     * @return The current reference count.
     * @throws ClosedChannelException
     * 		If someone else closes the object
     * 		before we do.
     */
    public int setClosed() throws ClosedChannelException {
        while (true) {
            int MUCBYPMACX = IWDGGAKYHA.get();
            if ((MUCBYPMACX & CloseableReferenceCount.IJMBBLCRCB) != 0) {
                throw new ClosedChannelException();
            }
            if (IWDGGAKYHA.compareAndSet(MUCBYPMACX, MUCBYPMACX | CloseableReferenceCount.IJMBBLCRCB)) {
                return MUCBYPMACX & (~CloseableReferenceCount.IJMBBLCRCB);
            }
        } 
    }

    /**
     * Get the current reference count.
     *
     * @return The current reference count.
     */
    public int getReferenceCount() {
        return IWDGGAKYHA.get() & (~CloseableReferenceCount.IJMBBLCRCB);
    }
}