@Private
@Unstable
public class NodeIdPBImpl extends NodeId {
    NodeIdProto ORRJEGKEOJ = null;

    Builder HDMRRWFXJC = null;

    public NodeIdPBImpl() {
        HDMRRWFXJC = NodeIdProto.newBuilder();
    }

    public NodeIdPBImpl(NodeIdProto LJJHSJBRSA) {
        this.ORRJEGKEOJ = LJJHSJBRSA;
    }

    public NodeIdProto getProto() {
        return ORRJEGKEOJ;
    }

    @Override
    public String getHost() {
        Preconditions.checkNotNull(ORRJEGKEOJ);
        return ORRJEGKEOJ.getHost();
    }

    @Override
    protected void setHost(String SQJYJEQOIT) {
        Preconditions.checkNotNull(HDMRRWFXJC);
        HDMRRWFXJC.setHost(SQJYJEQOIT);
    }

    @Override
    public int getPort() {
        Preconditions.checkNotNull(ORRJEGKEOJ);
        return ORRJEGKEOJ.getPort();
    }

    @Override
    protected void setPort(int RUVAAVDEKQ) {
        Preconditions.checkNotNull(HDMRRWFXJC);
        HDMRRWFXJC.setPort(RUVAAVDEKQ);
    }

    @Override
    protected void build() {
        ORRJEGKEOJ = HDMRRWFXJC.build();
        HDMRRWFXJC = null;
    }
}