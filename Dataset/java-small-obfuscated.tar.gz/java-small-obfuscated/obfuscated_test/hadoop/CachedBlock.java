/**
 * Represents a cached block.
 */
@InterfaceAudience.LimitedPrivate({ "HDFS" })
public final class CachedBlock implements Element , LightWeightGSet.LinkedElement {
    private static final Object[] AKLZDAOGQM = new Object[0];

    /**
     * Block id.
     */
    private final long ALKKNMZPAH;

    /**
     * Used to implement #{LightWeightGSet.LinkedElement}
     */
    private LinkedElement QDHELSSBXE;

    /**
     * Bit 15: Mark
     * Bit 0-14: cache replication factor.
     */
    private short PBIXFOSWEL;

    /**
     * Used to implement the CachedBlocksList.
     *
     * Since this CachedBlock can be in multiple CachedBlocksList objects,
     * we need to be able to store multiple 'prev' and 'next' pointers.
     * The triplets array does this.
     *
     * Each triplet contains a CachedBlockList object followed by a
     * prev pointer, followed by a next pointer.
     */
    private Object[] QTVIIPEZJG;

    public CachedBlock(long ZHMXEUAHLJ, short ZGSOFBGDTC, boolean IJTFXMEZHE) {
        this.ALKKNMZPAH = ZHMXEUAHLJ;
        this.QTVIIPEZJG = CachedBlock.AKLZDAOGQM;
        setReplicationAndMark(ZGSOFBGDTC, IJTFXMEZHE);
    }

    public long getBlockId() {
        return ALKKNMZPAH;
    }

    @Override
    public int hashCode() {
        return ((int) (ALKKNMZPAH ^ (ALKKNMZPAH >>> 32)));
    }

    @Override
    public boolean equals(Object NOTUZTOUSM) {
        if (NOTUZTOUSM == null) {
            return false;
        }
        if (NOTUZTOUSM == this) {
            return true;
        }
        if (NOTUZTOUSM.getClass() != this.getClass()) {
            return false;
        }
        CachedBlock OMBUPAOQTA = ((CachedBlock) (NOTUZTOUSM));
        return OMBUPAOQTA.ALKKNMZPAH == ALKKNMZPAH;
    }

    public void setReplicationAndMark(short COZNZSNUNY, boolean VBKTVBKLAZ) {
        assert COZNZSNUNY >= 0;
        PBIXFOSWEL = ((short) ((COZNZSNUNY << 1) | (VBKTVBKLAZ ? 0x1 : 0x0)));
    }

    public boolean getMark() {
        return (PBIXFOSWEL & 0x1) != 0;
    }

    public short getReplication() {
        return ((short) (PBIXFOSWEL >>> 1));
    }

    /**
     * Return true if this CachedBlock is present on the given list.
     */
    public boolean isPresent(CachedBlocksList HCZXOPEIHP) {
        for (int MHBKGAOPTG = 0; MHBKGAOPTG < QTVIIPEZJG.length; MHBKGAOPTG += 3) {
            CachedBlocksList KHXVUIUCGT = ((CachedBlocksList) (QTVIIPEZJG[MHBKGAOPTG]));
            if (KHXVUIUCGT == HCZXOPEIHP) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get a list of the datanodes which this block is cached,
     * planned to be cached, or planned to be uncached on.
     *
     * @param type
     * 		If null, this parameter is ignored.
     * 		If it is non-null, we match only datanodes which
     * 		have it on this list.
     * 		See {@link DatanodeDescriptor.CachedBlocksList.Type}
     * 		for a description of all the lists.
     * @return The list of datanodes.  Modifying this list does not
    alter the state of the CachedBlock.
     */
    public List<DatanodeDescriptor> getDatanodes(Type EMBLBECSVV) {
        List<DatanodeDescriptor> UELTNSOBRF = new LinkedList<DatanodeDescriptor>();
        for (int WSAFGZQKHG = 0; WSAFGZQKHG < QTVIIPEZJG.length; WSAFGZQKHG += 3) {
            CachedBlocksList ZPMNNDVMNG = ((CachedBlocksList) (QTVIIPEZJG[WSAFGZQKHG]));
            if ((EMBLBECSVV == null) || (ZPMNNDVMNG.getType() == EMBLBECSVV)) {
                UELTNSOBRF.add(ZPMNNDVMNG.getDatanode());
            }
        }
        return UELTNSOBRF;
    }

    @Override
    public void insertInternal(IntrusiveCollection<? extends Element> SPGINNDWBI, Element ACRTNWXDLT, Element DCSFZQSFPY) {
        for (int UYPAQPTRAF = 0; UYPAQPTRAF < QTVIIPEZJG.length; UYPAQPTRAF += 3) {
            if (QTVIIPEZJG[UYPAQPTRAF] == SPGINNDWBI) {
                throw new RuntimeException("Trying to re-insert an element that " + "is already in the list.");
            }
        }
        Object[] GXOMQIIERT = Arrays.copyOf(QTVIIPEZJG, QTVIIPEZJG.length + 3);
        GXOMQIIERT[QTVIIPEZJG.length] = SPGINNDWBI;
        GXOMQIIERT[QTVIIPEZJG.length + 1] = ACRTNWXDLT;
        GXOMQIIERT[QTVIIPEZJG.length + 2] = DCSFZQSFPY;
        QTVIIPEZJG = GXOMQIIERT;
    }

    @Override
    public void setPrev(IntrusiveCollection<? extends Element> UZXTTFJRKY, Element GVZFKVJLXL) {
        for (int FLGCPMCODA = 0; FLGCPMCODA < QTVIIPEZJG.length; FLGCPMCODA += 3) {
            if (QTVIIPEZJG[FLGCPMCODA] == UZXTTFJRKY) {
                QTVIIPEZJG[FLGCPMCODA + 1] = GVZFKVJLXL;
                return;
            }
        }
        throw new RuntimeException("Called setPrev on an element that wasn't " + "in the list.");
    }

    @Override
    public void setNext(IntrusiveCollection<? extends Element> XMPQGACEVK, Element VAYNGTFJVN) {
        for (int CNESMIOUFB = 0; CNESMIOUFB < QTVIIPEZJG.length; CNESMIOUFB += 3) {
            if (QTVIIPEZJG[CNESMIOUFB] == XMPQGACEVK) {
                QTVIIPEZJG[CNESMIOUFB + 2] = VAYNGTFJVN;
                return;
            }
        }
        throw new RuntimeException("Called setNext on an element that wasn't " + "in the list.");
    }

    @Override
    public void removeInternal(IntrusiveCollection<? extends Element> ZCOHJTBKOL) {
        for (int LHCKQCTUOD = 0; LHCKQCTUOD < QTVIIPEZJG.length; LHCKQCTUOD += 3) {
            if (QTVIIPEZJG[LHCKQCTUOD] == ZCOHJTBKOL) {
                Object[] QAIVCQJHNG = new Object[QTVIIPEZJG.length - 3];
                System.arraycopy(QTVIIPEZJG, 0, QAIVCQJHNG, 0, LHCKQCTUOD);
                System.arraycopy(QTVIIPEZJG, LHCKQCTUOD + 3, QAIVCQJHNG, LHCKQCTUOD, QTVIIPEZJG.length - (LHCKQCTUOD + 3));
                QTVIIPEZJG = QAIVCQJHNG;
                return;
            }
        }
        throw new RuntimeException("Called remove on an element that wasn't " + "in the list.");
    }

    @Override
    public Element getPrev(IntrusiveCollection<? extends Element> DZFFVHZZJM) {
        for (int YPFCCTTBNC = 0; YPFCCTTBNC < QTVIIPEZJG.length; YPFCCTTBNC += 3) {
            if (QTVIIPEZJG[YPFCCTTBNC] == DZFFVHZZJM) {
                return ((Element) (QTVIIPEZJG[YPFCCTTBNC + 1]));
            }
        }
        throw new RuntimeException("Called getPrev on an element that wasn't " + "in the list.");
    }

    @Override
    public Element getNext(IntrusiveCollection<? extends Element> CTHRJWUNHL) {
        for (int XQKRWAAMYE = 0; XQKRWAAMYE < QTVIIPEZJG.length; XQKRWAAMYE += 3) {
            if (QTVIIPEZJG[XQKRWAAMYE] == CTHRJWUNHL) {
                return ((Element) (QTVIIPEZJG[XQKRWAAMYE + 2]));
            }
        }
        throw new RuntimeException("Called getNext on an element that wasn't " + "in the list.");
    }

    @Override
    public boolean isInList(IntrusiveCollection<? extends Element> KFREWCIPDF) {
        for (int XDGLKDLOUS = 0; XDGLKDLOUS < QTVIIPEZJG.length; XDGLKDLOUS += 3) {
            if (QTVIIPEZJG[XDGLKDLOUS] == KFREWCIPDF) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return new StringBuilder().append("{").append("blockId=").append(ALKKNMZPAH).append(", ").append("replication=").append(getReplication()).append(", ").append("mark=").append(getMark()).append("}").toString();
    }

    // LightWeightGSet.LinkedElement
    @Override
    public void setNext(LinkedElement OKWBSNEMCB) {
        this.QDHELSSBXE = OKWBSNEMCB;
    }

    // LightWeightGSet.LinkedElement
    @Override
    public LinkedElement getNext() {
        return QDHELSSBXE;
    }
}