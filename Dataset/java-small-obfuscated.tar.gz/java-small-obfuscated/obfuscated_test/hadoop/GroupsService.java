@InterfaceAudience.Private
public class GroupsService extends BaseService implements Groups {
    private static final String HAWIMEDJKZ = "groups";

    private Groups NTTVHGVUTM;

    public GroupsService() {
        super(GroupsService.HAWIMEDJKZ);
    }

    @Override
    protected void init() throws ServiceException {
        Configuration JMJXLVINUW = new Configuration(false);
        ConfigurationUtils.copy(getServiceConfig(), JMJXLVINUW);
        NTTVHGVUTM = new org.apache.hadoop.security.Groups(JMJXLVINUW);
    }

    @Override
    public Class getInterface() {
        return Groups.class;
    }

    @Override
    public List<String> getGroups(String GSETFTGPXO) throws IOException {
        return NTTVHGVUTM.getGroups(GSETFTGPXO);
    }
}