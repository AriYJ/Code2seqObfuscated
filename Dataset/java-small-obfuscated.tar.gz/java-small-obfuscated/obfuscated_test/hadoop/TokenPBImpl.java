@Private
@Unstable
public class TokenPBImpl extends Token {
    private TokenProto SWXOOTSSVS = TokenProto.getDefaultInstance();

    private Builder YACJUODEMH = null;

    private boolean NPNNCCBHIG = false;

    private ByteBuffer RQXUXMDHXQ;

    private ByteBuffer DLNOGJGXVJ;

    public TokenPBImpl() {
        YACJUODEMH = TokenProto.newBuilder();
    }

    public TokenPBImpl(TokenProto AUPATMMEKZ) {
        this.SWXOOTSSVS = AUPATMMEKZ;
        NPNNCCBHIG = true;
    }

    public synchronized TokenProto getProto() {
        mergeLocalToProto();
        SWXOOTSSVS = (NPNNCCBHIG) ? SWXOOTSSVS : YACJUODEMH.build();
        NPNNCCBHIG = true;
        return SWXOOTSSVS;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object SYTKWHKWEN) {
        if (SYTKWHKWEN == null)
            return false;

        if (SYTKWHKWEN.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(SYTKWHKWEN).getProto());
        }
        return false;
    }

    protected final ByteBuffer convertFromProtoFormat(ByteString KTRQRNJFZZ) {
        return ProtoUtils.convertFromProtoFormat(KTRQRNJFZZ);
    }

    protected final ByteString convertToProtoFormat(ByteBuffer EZCUQUOBVG) {
        return ProtoUtils.convertToProtoFormat(EZCUQUOBVG);
    }

    private synchronized void mergeLocalToBuilder() {
        if (this.RQXUXMDHXQ != null) {
            YACJUODEMH.setIdentifier(convertToProtoFormat(this.RQXUXMDHXQ));
        }
        if (this.DLNOGJGXVJ != null) {
            YACJUODEMH.setPassword(convertToProtoFormat(this.DLNOGJGXVJ));
        }
    }

    private synchronized void mergeLocalToProto() {
        if (NPNNCCBHIG)
            maybeInitBuilder();

        mergeLocalToBuilder();
        SWXOOTSSVS = YACJUODEMH.build();
        NPNNCCBHIG = true;
    }

    private synchronized void maybeInitBuilder() {
        if (NPNNCCBHIG || (YACJUODEMH == null)) {
            YACJUODEMH = TokenProto.newBuilder(SWXOOTSSVS);
        }
        NPNNCCBHIG = false;
    }

    @Override
    public synchronized ByteBuffer getIdentifier() {
        TokenProtoOrBuilder NJHPDNSBIJ = (NPNNCCBHIG) ? SWXOOTSSVS : YACJUODEMH;
        if (this.RQXUXMDHXQ != null) {
            return this.RQXUXMDHXQ;
        }
        if (!NJHPDNSBIJ.hasIdentifier()) {
            return null;
        }
        this.RQXUXMDHXQ = convertFromProtoFormat(NJHPDNSBIJ.getIdentifier());
        return this.RQXUXMDHXQ;
    }

    @Override
    public synchronized void setIdentifier(ByteBuffer XDDAEREGPI) {
        maybeInitBuilder();
        if (XDDAEREGPI == null)
            YACJUODEMH.clearIdentifier();

        this.RQXUXMDHXQ = XDDAEREGPI;
    }

    @Override
    public synchronized ByteBuffer getPassword() {
        TokenProtoOrBuilder YNFLMWPTIP = (NPNNCCBHIG) ? SWXOOTSSVS : YACJUODEMH;
        if (this.DLNOGJGXVJ != null) {
            return this.DLNOGJGXVJ;
        }
        if (!YNFLMWPTIP.hasPassword()) {
            return null;
        }
        this.DLNOGJGXVJ = convertFromProtoFormat(YNFLMWPTIP.getPassword());
        return this.DLNOGJGXVJ;
    }

    @Override
    public synchronized void setPassword(ByteBuffer ZVAJWQELBL) {
        maybeInitBuilder();
        if (ZVAJWQELBL == null)
            YACJUODEMH.clearPassword();

        this.DLNOGJGXVJ = ZVAJWQELBL;
    }

    @Override
    public synchronized String getKind() {
        TokenProtoOrBuilder EWDPXYGUBC = (NPNNCCBHIG) ? SWXOOTSSVS : YACJUODEMH;
        if (!EWDPXYGUBC.hasKind()) {
            return null;
        }
        return EWDPXYGUBC.getKind();
    }

    @Override
    public synchronized void setKind(String XAIQTNPRTW) {
        maybeInitBuilder();
        if (XAIQTNPRTW == null) {
            YACJUODEMH.clearKind();
            return;
        }
        YACJUODEMH.setKind(XAIQTNPRTW);
    }

    @Override
    public synchronized String getService() {
        TokenProtoOrBuilder VSZJEHATAW = (NPNNCCBHIG) ? SWXOOTSSVS : YACJUODEMH;
        if (!VSZJEHATAW.hasService()) {
            return null;
        }
        return VSZJEHATAW.getService();
    }

    @Override
    public synchronized void setService(String ZWGUIQQZQU) {
        maybeInitBuilder();
        if (ZWGUIQQZQU == null) {
            YACJUODEMH.clearService();
            return;
        }
        YACJUODEMH.setService(ZWGUIQQZQU);
    }

    @Override
    public String toString() {
        StringBuilder LPOKLEAHTW = new StringBuilder();
        LPOKLEAHTW.append("Token { ");
        LPOKLEAHTW.append("kind: ").append(getKind()).append(", ");
        LPOKLEAHTW.append("service: ").append(getService()).append(" }");
        return LPOKLEAHTW.toString();
    }
}