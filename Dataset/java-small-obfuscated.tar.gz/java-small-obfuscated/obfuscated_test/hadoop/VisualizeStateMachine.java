@Private
public class VisualizeStateMachine {
    /**
     *
     *
     * @param classes
     * 		list of classes which have static field
     * 		stateMachineFactory of type StateMachineFactory
     * @return graph represent this StateMachine
     */
    public static Graph getGraphFromClasses(String ZMAUPYKMZE, List<String> IYZQKHNLCI) throws Exception {
        Graph NYIITPSFMC = null;
        if (IYZQKHNLCI.size() != 1) {
            NYIITPSFMC = new Graph(ZMAUPYKMZE);
        }
        for (String VWCHYGETSL : IYZQKHNLCI) {
            Class KCUHFRYZCL = Class.forName(VWCHYGETSL);
            Field EKDEDMVHUZ = KCUHFRYZCL.getDeclaredField("stateMachineFactory");
            EKDEDMVHUZ.setAccessible(true);
            StateMachineFactory FTSYQLZJUH = ((StateMachineFactory) (EKDEDMVHUZ.get(null)));
            if (IYZQKHNLCI.size() == 1) {
                return FTSYQLZJUH.generateStateGraph(ZMAUPYKMZE);
            }
            String DWWEPUSPRE = KCUHFRYZCL.getSimpleName();
            if (DWWEPUSPRE.endsWith("Impl")) {
                DWWEPUSPRE = DWWEPUSPRE.substring(0, DWWEPUSPRE.length() - 4);
            }
            NYIITPSFMC.addSubGraph(FTSYQLZJUH.generateStateGraph(DWWEPUSPRE));
        }
        return NYIITPSFMC;
    }

    public static void main(String[] FLWNZHEUIG) throws Exception {
        if (FLWNZHEUIG.length < 3) {
            System.err.printf("Usage: %s <GraphName> <class[,class[,...]]> <OutputFile>\n", VisualizeStateMachine.class.getName());
            System.exit(1);
        }
        String[] NDUBWKVQNU = FLWNZHEUIG[1].split(",");
        ArrayList<String> BYFDOKLMEP = new ArrayList<String>();
        for (String ZXRNGBNSYZ : NDUBWKVQNU) {
            String SZWJPVASVO = ZXRNGBNSYZ.trim();
            if (SZWJPVASVO.length() > 0) {
                BYFDOKLMEP.add(SZWJPVASVO);
            }
        }
        Graph YFKJSTXCSF = VisualizeStateMachine.getGraphFromClasses(FLWNZHEUIG[0], BYFDOKLMEP);
        YFKJSTXCSF.save(FLWNZHEUIG[2]);
    }
}