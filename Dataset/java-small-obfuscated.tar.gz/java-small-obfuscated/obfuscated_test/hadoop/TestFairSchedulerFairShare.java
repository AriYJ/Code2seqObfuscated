public class TestFairSchedulerFairShare extends FairSchedulerTestBase {
    private static final String WIYWHFHRFQ = new File(TEST_DIR, TestFairSchedulerFairShare.class.getName() + ".xml").getAbsolutePath();

    @Before
    public void setup() throws IOException {
        conf = createConfiguration();
        conf.set(ALLOCATION_FILE, TestFairSchedulerFairShare.WIYWHFHRFQ);
    }

    @After
    public void teardown() {
        if (resourceManager != null) {
            resourceManager.stop();
            resourceManager = null;
        }
        conf = null;
    }

    private void createClusterWithQueuesAndOneNode(int VQQHXOFUWE, String RWIAFJYFRU) throws IOException {
        createClusterWithQueuesAndOneNode(VQQHXOFUWE, 0, RWIAFJYFRU);
    }

    private void createClusterWithQueuesAndOneNode(int ZVTLYOAOEQ, int LXAZKDUKVW, String AAANSATLLL) throws IOException {
        PrintWriter QZTLACEUUP = new PrintWriter(new FileWriter(TestFairSchedulerFairShare.WIYWHFHRFQ));
        QZTLACEUUP.println("<?xml version=\"1.0\"?>");
        QZTLACEUUP.println("<allocations>");
        QZTLACEUUP.println("<queue name=\"root\" >");
        QZTLACEUUP.println("   <queue name=\"parentA\" >");
        QZTLACEUUP.println("       <weight>8</weight>");
        QZTLACEUUP.println("       <queue name=\"childA1\" />");
        QZTLACEUUP.println("       <queue name=\"childA2\" />");
        QZTLACEUUP.println("       <queue name=\"childA3\" />");
        QZTLACEUUP.println("       <queue name=\"childA4\" />");
        QZTLACEUUP.println("   </queue>");
        QZTLACEUUP.println("   <queue name=\"parentB\" >");
        QZTLACEUUP.println("       <weight>1</weight>");
        QZTLACEUUP.println("       <queue name=\"childB1\" />");
        QZTLACEUUP.println("       <queue name=\"childB2\" />");
        QZTLACEUUP.println("   </queue>");
        QZTLACEUUP.println("</queue>");
        QZTLACEUUP.println(("<defaultQueueSchedulingPolicy>" + AAANSATLLL) + "</defaultQueueSchedulingPolicy>");
        QZTLACEUUP.println("</allocations>");
        QZTLACEUUP.close();
        resourceManager = new org.apache.hadoop.yarn.server.resourcemanager.MockRM(conf);
        resourceManager.start();
        scheduler = ((FairScheduler) (resourceManager.getResourceScheduler()));
        RMNode DIVWOVFNKI = MockNodes.newNodeInfo(1, Resources.createResource(ZVTLYOAOEQ, LXAZKDUKVW), 1, "127.0.0.1");
        NodeAddedSchedulerEvent FTTGXGNMPA = new NodeAddedSchedulerEvent(DIVWOVFNKI);
        scheduler.handle(FTTGXGNMPA);
    }

    @Test
    public void testFairShareNoAppsRunning() throws IOException {
        int UIEAYTIPZX = 16 * 1024;
        createClusterWithQueuesAndOneNode(UIEAYTIPZX, "fair");
        scheduler.update();
        // No apps are running in the cluster,verify if fair share is zero
        // for all queues under parentA and parentB.
        Collection<FSLeafQueue> QXPOQYLTHZ = scheduler.getQueueManager().getLeafQueues();
        for (FSLeafQueue KFKVVNVBWO : QXPOQYLTHZ) {
            if (KFKVVNVBWO.getName().startsWith("root.parentA")) {
                assertEquals(0, ((double) (KFKVVNVBWO.getFairShare().getMemory())) / UIEAYTIPZX, 0);
            } else
                if (KFKVVNVBWO.getName().startsWith("root.parentB")) {
                    assertEquals(0, ((double) (KFKVVNVBWO.getFairShare().getMemory())) / UIEAYTIPZX, 0);
                }

        }
        verifySteadyFairShareMemory(QXPOQYLTHZ, UIEAYTIPZX);
    }

    @Test
    public void testFairShareOneAppRunning() throws IOException {
        int KWIDTXMEWN = 16 * 1024;
        createClusterWithQueuesAndOneNode(KWIDTXMEWN, "fair");
        // Run a app in a childA1. Verify whether fair share is 100% in childA1,
        // since it is the only active queue.
        // Also verify if fair share is 0 for childA2. since no app is
        // running in it.
        createSchedulingRequest(2 * 1024, "root.parentA.childA1", "user1");
        scheduler.update();
        assertEquals(100, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA1", false).getFairShare().getMemory())) / KWIDTXMEWN) * 100, 0.1);
        assertEquals(0, ((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA2", false).getFairShare().getMemory())) / KWIDTXMEWN, 0.1);
        verifySteadyFairShareMemory(scheduler.getQueueManager().getLeafQueues(), KWIDTXMEWN);
    }

    @Test
    public void testFairShareMultipleActiveQueuesUnderSameParent() throws IOException {
        int LLKCQPLTGZ = 16 * 1024;
        createClusterWithQueuesAndOneNode(LLKCQPLTGZ, "fair");
        // Run apps in childA1,childA2,childA3
        createSchedulingRequest(2 * 1024, "root.parentA.childA1", "user1");
        createSchedulingRequest(2 * 1024, "root.parentA.childA2", "user2");
        createSchedulingRequest(2 * 1024, "root.parentA.childA3", "user3");
        scheduler.update();
        // Verify if fair share is 100 / 3 = 33%
        for (int AFVNEBLIDA = 1; AFVNEBLIDA <= 3; AFVNEBLIDA++) {
            assertEquals(33, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA" + AFVNEBLIDA, false).getFairShare().getMemory())) / LLKCQPLTGZ) * 100, 0.9);
        }
        verifySteadyFairShareMemory(scheduler.getQueueManager().getLeafQueues(), LLKCQPLTGZ);
    }

    @Test
    public void testFairShareMultipleActiveQueuesUnderDifferentParent() throws IOException {
        int VQZOZWBBVR = 16 * 1024;
        createClusterWithQueuesAndOneNode(VQZOZWBBVR, "fair");
        // Run apps in childA1,childA2 which are under parentA
        createSchedulingRequest(2 * 1024, "root.parentA.childA1", "user1");
        createSchedulingRequest(3 * 1024, "root.parentA.childA2", "user2");
        // Run app in childB1 which is under parentB
        createSchedulingRequest(1 * 1024, "root.parentB.childB1", "user3");
        // Run app in root.default queue
        createSchedulingRequest(1 * 1024, "root.default", "user4");
        scheduler.update();
        // The two active child queues under parentA would
        // get fair share of 80/2=40%
        for (int QBONNSTNRH = 1; QBONNSTNRH <= 2; QBONNSTNRH++) {
            assertEquals(40, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA" + QBONNSTNRH, false).getFairShare().getMemory())) / VQZOZWBBVR) * 100, 0.9);
        }
        // The child queue under parentB would get a fair share of 10%,
        // basically all of parentB's fair share
        assertEquals(10, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentB.childB1", false).getFairShare().getMemory())) / VQZOZWBBVR) * 100, 0.9);
        verifySteadyFairShareMemory(scheduler.getQueueManager().getLeafQueues(), VQZOZWBBVR);
    }

    @Test
    public void testFairShareResetsToZeroWhenAppsComplete() throws IOException {
        int POZAQVSDGV = 16 * 1024;
        createClusterWithQueuesAndOneNode(POZAQVSDGV, "fair");
        // Run apps in childA1,childA2 which are under parentA
        ApplicationAttemptId QBAZXUZBQH = createSchedulingRequest(2 * 1024, "root.parentA.childA1", "user1");
        ApplicationAttemptId SSTXLVBDBN = createSchedulingRequest(3 * 1024, "root.parentA.childA2", "user2");
        scheduler.update();
        // Verify if both the active queues under parentA get 50% fair
        // share
        for (int FVYRGYJPBK = 1; FVYRGYJPBK <= 2; FVYRGYJPBK++) {
            assertEquals(50, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA" + FVYRGYJPBK, false).getFairShare().getMemory())) / POZAQVSDGV) * 100, 0.9);
        }
        // Let app under childA1 complete. This should cause the fair share
        // of queue childA1 to be reset to zero,since the queue has no apps running.
        // Queue childA2's fair share would increase to 100% since its the only
        // active queue.
        AppAttemptRemovedSchedulerEvent URRNJAKVJE = new AppAttemptRemovedSchedulerEvent(QBAZXUZBQH, RMAppAttemptState.FINISHED, false);
        scheduler.handle(URRNJAKVJE);
        scheduler.update();
        assertEquals(0, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA1", false).getFairShare().getMemory())) / POZAQVSDGV) * 100, 0);
        assertEquals(100, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA2", false).getFairShare().getMemory())) / POZAQVSDGV) * 100, 0.1);
        verifySteadyFairShareMemory(scheduler.getQueueManager().getLeafQueues(), POZAQVSDGV);
    }

    @Test
    public void testFairShareWithDRFMultipleActiveQueuesUnderDifferentParent() throws IOException {
        int KCVQGKOWTP = 16 * 1024;
        int YQEZDFZWDE = 10;
        createClusterWithQueuesAndOneNode(KCVQGKOWTP, YQEZDFZWDE, "drf");
        // Run apps in childA1,childA2 which are under parentA
        createSchedulingRequest(2 * 1024, "root.parentA.childA1", "user1");
        createSchedulingRequest(3 * 1024, "root.parentA.childA2", "user2");
        // Run app in childB1 which is under parentB
        createSchedulingRequest(1 * 1024, "root.parentB.childB1", "user3");
        // Run app in root.default queue
        createSchedulingRequest(1 * 1024, "root.default", "user4");
        scheduler.update();
        // The two active child queues under parentA would
        // get 80/2=40% memory and vcores
        for (int KEZZRFSFYV = 1; KEZZRFSFYV <= 2; KEZZRFSFYV++) {
            assertEquals(40, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA" + KEZZRFSFYV, false).getFairShare().getMemory())) / KCVQGKOWTP) * 100, 0.9);
            assertEquals(40, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentA.childA" + KEZZRFSFYV, false).getFairShare().getVirtualCores())) / YQEZDFZWDE) * 100, 0.9);
        }
        // The only active child queue under parentB would get 10% memory and vcores
        assertEquals(10, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentB.childB1", false).getFairShare().getMemory())) / KCVQGKOWTP) * 100, 0.9);
        assertEquals(10, (((double) (scheduler.getQueueManager().getLeafQueue("root.parentB.childB1", false).getFairShare().getVirtualCores())) / YQEZDFZWDE) * 100, 0.9);
        Collection<FSLeafQueue> LUBTAAOALN = scheduler.getQueueManager().getLeafQueues();
        for (FSLeafQueue XEMOJRPTJA : LUBTAAOALN) {
            if (XEMOJRPTJA.getName().startsWith("root.parentA")) {
                assertEquals(0.2, ((double) (XEMOJRPTJA.getSteadyFairShare().getMemory())) / KCVQGKOWTP, 0.001);
                assertEquals(0.2, ((double) (XEMOJRPTJA.getSteadyFairShare().getVirtualCores())) / YQEZDFZWDE, 0.001);
            } else
                if (XEMOJRPTJA.getName().startsWith("root.parentB")) {
                    assertEquals(0.05, ((double) (XEMOJRPTJA.getSteadyFairShare().getMemory())) / KCVQGKOWTP, 0.001);
                    assertEquals(0.1, ((double) (XEMOJRPTJA.getSteadyFairShare().getVirtualCores())) / YQEZDFZWDE, 0.001);
                }

        }
    }

    /**
     * Verify whether steady fair shares for all leaf queues still follow
     * their weight, not related to active/inactive status.
     *
     * @param leafQueues
     * 		
     * @param nodeCapacity
     * 		
     */
    private void verifySteadyFairShareMemory(Collection<FSLeafQueue> XUVWMRUOBR, int FBSSWQWKUS) {
        for (FSLeafQueue IPIMIBGPCE : XUVWMRUOBR) {
            if (IPIMIBGPCE.getName().startsWith("root.parentA")) {
                assertEquals(0.2, ((double) (IPIMIBGPCE.getSteadyFairShare().getMemory())) / FBSSWQWKUS, 0.001);
            } else
                if (IPIMIBGPCE.getName().startsWith("root.parentB")) {
                    assertEquals(0.05, ((double) (IPIMIBGPCE.getSteadyFairShare().getMemory())) / FBSSWQWKUS, 0.001);
                }

        }
    }
}