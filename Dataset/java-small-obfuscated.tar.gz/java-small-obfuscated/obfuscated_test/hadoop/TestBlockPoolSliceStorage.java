/**
 * Test that BlockPoolSliceStorage can correctly generate trash and
 * restore directories for a given block file path.
 */
public class TestBlockPoolSliceStorage {
    public static final Log ZXPAJGUMRC = LogFactory.getLog(TestBlockPoolSliceStorage.class);

    final Random CWLCWVTZDN = new Random();

    BlockPoolSliceStorage GWDZFSAXLR;

    /**
     * BlockPoolSliceStorage with a dummy storage directory. The directory
     * need not exist. We need to extend BlockPoolSliceStorage so we can
     * call {@link Storage#addStorageDir}.
     */
    private static class StubBlockPoolSliceStorage extends BlockPoolSliceStorage {
        StubBlockPoolSliceStorage(int namespaceID, String bpID, long cTime, String clusterId) {
            super(namespaceID, bpID, cTime, clusterId);
            addStorageDir(new StorageDirectory(new File("/tmp/dontcare/" + bpID)));
            assertThat(storageDirs.size(), is(1));
        }
    }

    private String makeRandomIpAddress() {
        return (((((CWLCWVTZDN.nextInt(256) + ".") + CWLCWVTZDN.nextInt(256)) + ".") + CWLCWVTZDN.nextInt(256)) + ".") + CWLCWVTZDN.nextInt(256);
    }

    private String makeRandomBlockpoolId() {
        return (((("BP-" + CWLCWVTZDN.nextInt(Integer.MAX_VALUE)) + "-") + makeRandomIpAddress()) + "-") + CWLCWVTZDN.nextInt(Integer.MAX_VALUE);
    }

    private BlockPoolSliceStorage makeBlockPoolStorage() {
        return new TestBlockPoolSliceStorage.StubBlockPoolSliceStorage(CWLCWVTZDN.nextInt(Integer.MAX_VALUE), makeRandomBlockpoolId(), CWLCWVTZDN.nextInt(Integer.MAX_VALUE), UUID.randomUUID().toString());
    }

    private String makeRandomBlockFileSubdir(int UGHKYANSFH) {
        StringBuilder SRKXLFZYOY = new StringBuilder();
        SRKXLFZYOY.append(File.separator);
        for (int BBLEXAQQCZ = 0; BBLEXAQQCZ < UGHKYANSFH; ++BBLEXAQQCZ) {
            SRKXLFZYOY.append(("subdir" + CWLCWVTZDN.nextInt(64)) + File.separator);
        }
        return SRKXLFZYOY.toString();
    }

    /**
     * Test conversion from a block file path to its target trash
     * directory.
     */
    public void getTrashDirectoryForBlockFile(String MOJFVGFPSZ, int GCAMXMCFEA) {
        final String FJTEFXBTVI = makeRandomBlockFileSubdir(GCAMXMCFEA);
        final String LILBRVRFWF = MOJFVGFPSZ;
        String IEWUSAPMSH = (((GWDZFSAXLR.getSingularStorageDir().getRoot() + File.separator) + Storage.STORAGE_DIR_CURRENT) + FJTEFXBTVI) + LILBRVRFWF;
        String ZMOYHJSJIQ = ((GWDZFSAXLR.getSingularStorageDir().getRoot() + File.separator) + BlockPoolSliceStorage.TRASH_ROOT_DIR) + FJTEFXBTVI.substring(0, FJTEFXBTVI.length() - 1);
        TestBlockPoolSliceStorage.ZXPAJGUMRC.info("Got subdir " + FJTEFXBTVI);
        TestBlockPoolSliceStorage.ZXPAJGUMRC.info("Generated file path " + IEWUSAPMSH);
        assertThat(GWDZFSAXLR.getTrashDirectory(new File(IEWUSAPMSH)), is(ZMOYHJSJIQ));
    }

    /* Test conversion from a block file in a trash directory to its
    target directory for restore.
     */
    public void getRestoreDirectoryForBlockFile(String XKIDXVFHQD, int VFTFYELMRS) {
        BlockPoolSliceStorage RSXEEZTQGG = makeBlockPoolStorage();
        final String NZYNLVGGNB = makeRandomBlockFileSubdir(VFTFYELMRS);
        final String NZQCERNVWV = XKIDXVFHQD;
        String UKWANSCBUJ = (((RSXEEZTQGG.getSingularStorageDir().getRoot() + File.separator) + BlockPoolSliceStorage.TRASH_ROOT_DIR) + NZYNLVGGNB) + NZQCERNVWV;
        String WVCGFYTHUC = ((RSXEEZTQGG.getSingularStorageDir().getRoot() + File.separator) + Storage.STORAGE_DIR_CURRENT) + NZYNLVGGNB.substring(0, NZYNLVGGNB.length() - 1);
        TestBlockPoolSliceStorage.ZXPAJGUMRC.info("Generated deleted file path " + UKWANSCBUJ);
        assertThat(RSXEEZTQGG.getRestoreDirectory(new File(UKWANSCBUJ)), is(WVCGFYTHUC));
    }

    @Test(timeout = 300000)
    public void testGetTrashAndRestoreDirectories() {
        GWDZFSAXLR = makeBlockPoolStorage();
        // Test a few different nesting levels since block files
        // could be nested such as subdir1/subdir5/blk_...
        // Make sure all nesting levels are handled correctly.
        for (int MZIIEDLMIX = 0; MZIIEDLMIX < 3; ++MZIIEDLMIX) {
            getTrashDirectoryForBlockFile("blk_myblockfile", MZIIEDLMIX);
            getTrashDirectoryForBlockFile("blk_myblockfile.meta", MZIIEDLMIX);
            getRestoreDirectoryForBlockFile("blk_myblockfile", MZIIEDLMIX);
            getRestoreDirectoryForBlockFile("blk_myblockfile.meta", MZIIEDLMIX);
        }
    }
}