/**
 * DynamicInputFormat implements the "Worker pattern" for DistCp.
 * Rather than to split up the copy-list into a set of static splits,
 * the DynamicInputFormat does the following:
 * 1. Splits the copy-list into small chunks on the DFS.
 * 2. Creates a set of empty "dynamic" splits, that each consume as many chunks
 *    as it can.
 * This arrangement ensures that a single slow mapper won't slow down the entire
 * job (since the slack will be picked up by other mappers, who consume more
 * chunks.)
 * By varying the split-ratio, one can vary chunk sizes to achieve different
 * performance characteristics.
 */
public class DynamicInputFormat<K, V> extends InputFormat<K, V> {
    private static final Log MSOMDTPFEI = LogFactory.getLog(DynamicInputFormat.class);

    private static final String BWNJOMGHLW = "mapred.listing.split.ratio";

    private static final String VMWNSZUMCH = "mapred.num.splits";

    private static final String OXKMKFNQKD = "mapred.num.entries.per.chunk";

    /**
     * Implementation of InputFormat::getSplits(). This method splits up the
     * copy-listing file into chunks, and assigns the first batch to different
     * tasks.
     *
     * @param jobContext
     * 		JobContext for the map job.
     * @return The list of (empty) dynamic input-splits.
     * @throws IOException,
     * 		on failure.
     * @throws InterruptedException
     * 		
     */
    @Override
    public List<InputSplit> getSplits(JobContext VDZDAVPJKL) throws IOException, InterruptedException {
        DynamicInputFormat.MSOMDTPFEI.info("DynamicInputFormat: Getting splits for job:" + VDZDAVPJKL.getJobID());
        return createSplits(VDZDAVPJKL, splitCopyListingIntoChunksWithShuffle(VDZDAVPJKL));
    }

    private List<InputSplit> createSplits(JobContext FVXLQLEHTW, List<DynamicInputChunk> ZJPQYXSLWR) throws IOException {
        int ZRWXFAVRAA = DynamicInputFormat.getNumMapTasks(FVXLQLEHTW.getConfiguration());
        final int JHZAOKIDDE = Math.min(ZRWXFAVRAA, ZJPQYXSLWR.size());
        List<InputSplit> XDEHQSWVXJ = new ArrayList<InputSplit>(JHZAOKIDDE);
        for (int IPTRMNCLTQ = 0; IPTRMNCLTQ < JHZAOKIDDE; ++IPTRMNCLTQ) {
            TaskID ZHXJYNDIYC = new TaskID(FVXLQLEHTW.getJobID(), TaskType.MAP, IPTRMNCLTQ);
            ZJPQYXSLWR.get(IPTRMNCLTQ).assignTo(ZHXJYNDIYC);
            XDEHQSWVXJ.add(// Setting non-zero length for FileSplit size, to avoid a possible
            // future when 0-sized file-splits are considered "empty" and skipped
            // over.
            new org.apache.hadoop.mapreduce.lib.input.FileSplit(ZJPQYXSLWR.get(IPTRMNCLTQ).getPath(), 0, DynamicInputFormat.getMinRecordsPerChunk(FVXLQLEHTW.getConfiguration()), null));
        }
        DistCpUtils.publish(FVXLQLEHTW.getConfiguration(), DynamicInputFormat.VMWNSZUMCH, XDEHQSWVXJ.size());
        return XDEHQSWVXJ;
    }

    private static int KSGALJFATV = 16;

    private List<DynamicInputChunk> splitCopyListingIntoChunksWithShuffle(JobContext BDHBMBZWBY) throws IOException {
        final Configuration AONEHJHZXF = BDHBMBZWBY.getConfiguration();
        int CVNZMWBJIC = DynamicInputFormat.getNumberOfRecords(AONEHJHZXF);
        int RTOIBSGFXT = DynamicInputFormat.getNumMapTasks(AONEHJHZXF);
        int EOGVDNGOFO = DynamicInputFormat.getMaxChunksTolerable(AONEHJHZXF);
        // Number of chunks each map will process, on average.
        int CTXKMSFBPS = DynamicInputFormat.getListingSplitRatio(AONEHJHZXF, RTOIBSGFXT, CVNZMWBJIC);
        DynamicInputFormat.validateNumChunksUsing(CTXKMSFBPS, RTOIBSGFXT, EOGVDNGOFO);
        int XDZDTGOVHJ = ((int) (Math.ceil(((float) (CVNZMWBJIC)) / (CTXKMSFBPS * RTOIBSGFXT))));
        DistCpUtils.publish(BDHBMBZWBY.getConfiguration(), DynamicInputFormat.OXKMKFNQKD, XDZDTGOVHJ);
        final int STJKEMBMCE = ((int) (Math.ceil(((float) (CVNZMWBJIC)) / XDZDTGOVHJ)));
        int ZDKEEBVBIP = Math.min(DynamicInputFormat.KSGALJFATV, STJKEMBMCE);
        Path YEUNEVFOVS = DynamicInputFormat.getListingFilePath(AONEHJHZXF);
        SequenceFile.Reader RYPSLGAAOU = new SequenceFile.Reader(AONEHJHZXF, Reader.file(YEUNEVFOVS));
        List<DynamicInputChunk> FCXDOOQKTI = new ArrayList<DynamicInputChunk>();
        List<DynamicInputChunk> CTYUONUQSA = new ArrayList<DynamicInputChunk>();
        CopyListingFileStatus YLHEAESFZK = new CopyListingFileStatus();
        Text LGAMSCURPQ = new Text();
        int DOFXDJNHVX = 0;
        int YFNSSHTJEJ = 0;
        try {
            while (RYPSLGAAOU.next(LGAMSCURPQ, YLHEAESFZK)) {
                if ((DOFXDJNHVX % (ZDKEEBVBIP * XDZDTGOVHJ)) == 0) {
                    // All chunks full. Create new chunk-set.
                    DynamicInputFormat.closeAll(FCXDOOQKTI);
                    CTYUONUQSA.addAll(FCXDOOQKTI);
                    FCXDOOQKTI = DynamicInputFormat.createChunks(AONEHJHZXF, YFNSSHTJEJ, STJKEMBMCE, ZDKEEBVBIP);
                    YFNSSHTJEJ += FCXDOOQKTI.size();
                    ZDKEEBVBIP = FCXDOOQKTI.size();
                    DOFXDJNHVX = 0;
                }
                // Shuffle into open chunks.
                FCXDOOQKTI.get(DOFXDJNHVX % ZDKEEBVBIP).write(LGAMSCURPQ, YLHEAESFZK);
                ++DOFXDJNHVX;
            } 
        } finally {
            DynamicInputFormat.closeAll(FCXDOOQKTI);
            CTYUONUQSA.addAll(FCXDOOQKTI);
            IOUtils.closeStream(RYPSLGAAOU);
        }
        DynamicInputFormat.MSOMDTPFEI.info("Number of dynamic-chunk-files created: " + CTYUONUQSA.size());
        return CTYUONUQSA;
    }

    private static void validateNumChunksUsing(int EVTZEGRAFQ, int HFLDLAKBIN, int ZYGVJBAFNG) throws IOException {
        if ((EVTZEGRAFQ * HFLDLAKBIN) > ZYGVJBAFNG)
            throw new IOException(((("Too many chunks created with splitRatio:" + EVTZEGRAFQ) + ", numMaps:") + HFLDLAKBIN) + ". Reduce numMaps or decrease split-ratio to proceed.");

    }

    private static void closeAll(List<DynamicInputChunk> EROWPGPSWX) {
        for (DynamicInputChunk TSTOURTIJK : EROWPGPSWX)
            TSTOURTIJK.close();

    }

    private static List<DynamicInputChunk> createChunks(Configuration UWWNHDTEOA, int EFISWNZIDW, int DRKXLLKSWS, int LGULYVFXBA) throws IOException {
        List<DynamicInputChunk> LMRXWERXOK = new ArrayList<DynamicInputChunk>();
        int MPFLAQOVFW = Math.min(DRKXLLKSWS, EFISWNZIDW + LGULYVFXBA);
        // If there will be fewer than nChunksOpenAtOnce chunks left after
        // the current batch of chunks, fold the remaining chunks into
        // the current batch.
        if ((DRKXLLKSWS - MPFLAQOVFW) < LGULYVFXBA)
            MPFLAQOVFW = DRKXLLKSWS;

        for (int OWBPCXCYNO = EFISWNZIDW; OWBPCXCYNO < MPFLAQOVFW; ++OWBPCXCYNO)
            LMRXWERXOK.add(DynamicInputFormat.createChunk(OWBPCXCYNO, UWWNHDTEOA));

        return LMRXWERXOK;
    }

    private static DynamicInputChunk createChunk(int EHAIZXPPXC, Configuration UWNLCJDVOR) throws IOException {
        return DynamicInputChunk.createChunkForWrite(String.format("%05d", EHAIZXPPXC), UWNLCJDVOR);
    }

    private static Path getListingFilePath(Configuration WAHFHUKAPG) {
        String DFQAJUHVKG = WAHFHUKAPG.get(CONF_LABEL_LISTING_FILE_PATH, "");
        assert !DFQAJUHVKG.equals("") : "Listing file not found.";
        Path NVXXQVRXAM = new Path(DFQAJUHVKG);
        try {
            assert NVXXQVRXAM.getFileSystem(WAHFHUKAPG).exists(NVXXQVRXAM) : ("Listing file: " + NVXXQVRXAM) + " not found.";
        } catch (IOException e) {
            assert false : (("Listing file: " + NVXXQVRXAM) + " couldn't be accessed. ") + e.getMessage();
        }
        return NVXXQVRXAM;
    }

    private static int getNumberOfRecords(Configuration AUPPFXIHXU) {
        return DistCpUtils.getInt(AUPPFXIHXU, CONF_LABEL_TOTAL_NUMBER_OF_RECORDS);
    }

    private static int getNumMapTasks(Configuration NBTTDZAENQ) {
        return DistCpUtils.getInt(NBTTDZAENQ, NUM_MAPS);
    }

    private static int getListingSplitRatio(Configuration TMTOCYSQPV, int SZDRGJQMVT, int UQYVJKAPKI) {
        return TMTOCYSQPV.getInt(DynamicInputFormat.BWNJOMGHLW, DynamicInputFormat.getSplitRatio(SZDRGJQMVT, UQYVJKAPKI, TMTOCYSQPV));
    }

    private static int getMaxChunksTolerable(Configuration ZJZSSINYWK) {
        int XOITWABSCG = ZJZSSINYWK.getInt(CONF_LABEL_MAX_CHUNKS_TOLERABLE, MAX_CHUNKS_TOLERABLE_DEFAULT);
        if (XOITWABSCG <= 0) {
            DynamicInputFormat.MSOMDTPFEI.warn((DistCpConstants.CONF_LABEL_MAX_CHUNKS_TOLERABLE + " should be positive. Fall back to default value: ") + DistCpConstants.MAX_CHUNKS_TOLERABLE_DEFAULT);
            XOITWABSCG = DistCpConstants.MAX_CHUNKS_TOLERABLE_DEFAULT;
        }
        return XOITWABSCG;
    }

    private static int getMaxChunksIdeal(Configuration UBRZSOTNDB) {
        int UMNQDARAOZ = UBRZSOTNDB.getInt(CONF_LABEL_MAX_CHUNKS_IDEAL, MAX_CHUNKS_IDEAL_DEFAULT);
        if (UMNQDARAOZ <= 0) {
            DynamicInputFormat.MSOMDTPFEI.warn((DistCpConstants.CONF_LABEL_MAX_CHUNKS_IDEAL + " should be positive. Fall back to default value: ") + DistCpConstants.MAX_CHUNKS_IDEAL_DEFAULT);
            UMNQDARAOZ = DistCpConstants.MAX_CHUNKS_IDEAL_DEFAULT;
        }
        return UMNQDARAOZ;
    }

    private static int getMinRecordsPerChunk(Configuration ZYHJNLCEHF) {
        int OYTIRYGFNX = ZYHJNLCEHF.getInt(CONF_LABEL_MIN_RECORDS_PER_CHUNK, MIN_RECORDS_PER_CHUNK_DEFAULT);
        if (OYTIRYGFNX <= 0) {
            DynamicInputFormat.MSOMDTPFEI.warn((DistCpConstants.CONF_LABEL_MIN_RECORDS_PER_CHUNK + " should be positive. Fall back to default value: ") + DistCpConstants.MIN_RECORDS_PER_CHUNK_DEFAULT);
            OYTIRYGFNX = DistCpConstants.MIN_RECORDS_PER_CHUNK_DEFAULT;
        }
        return OYTIRYGFNX;
    }

    private static int getSplitRatio(Configuration VMJHCLIPSV) {
        int GEMIHUUZOR = VMJHCLIPSV.getInt(CONF_LABEL_SPLIT_RATIO, SPLIT_RATIO_DEFAULT);
        if (GEMIHUUZOR <= 0) {
            DynamicInputFormat.MSOMDTPFEI.warn((DistCpConstants.CONF_LABEL_SPLIT_RATIO + " should be positive. Fall back to default value: ") + DistCpConstants.SPLIT_RATIO_DEFAULT);
            GEMIHUUZOR = DistCpConstants.SPLIT_RATIO_DEFAULT;
        }
        return GEMIHUUZOR;
    }

    /**
     * Package private, for testability.
     *
     * @param nMaps
     * 		The number of maps requested for.
     * @param nRecords
     * 		The number of records to be copied.
     * @return The number of splits each map should handle, ideally.
     */
    static int getSplitRatio(int GOZVRDPBQJ, int UWUZWAEPDP) {
        return DynamicInputFormat.getSplitRatio(GOZVRDPBQJ, UWUZWAEPDP, new Configuration());
    }

    /**
     * Package private, for testability.
     *
     * @param nMaps
     * 		The number of maps requested for.
     * @param nRecords
     * 		The number of records to be copied.
     * @param conf
     * 		The configuration set by users.
     * @return The number of splits each map should handle, ideally.
     */
    static int getSplitRatio(int FTNOWWSVJG, int GGCKBTDAAD, Configuration NRLGTWVUWP) {
        int ZUORPMPXQV = DynamicInputFormat.getMaxChunksIdeal(NRLGTWVUWP);
        int UHYNBFNIBZ = DynamicInputFormat.getMinRecordsPerChunk(NRLGTWVUWP);
        int ICZMZGONLU = DynamicInputFormat.getSplitRatio(NRLGTWVUWP);
        if (FTNOWWSVJG == 1) {
            DynamicInputFormat.MSOMDTPFEI.warn("nMaps == 1. Why use DynamicInputFormat?");
            return 1;
        }
        if (FTNOWWSVJG > ZUORPMPXQV)
            return ICZMZGONLU;

        int TTCAUTPPAY = ((int) (Math.ceil(((float) (ZUORPMPXQV)) / FTNOWWSVJG)));
        int WCXPNCHSPG = ((int) (Math.ceil(((float) (GGCKBTDAAD)) / (FTNOWWSVJG * TTCAUTPPAY))));
        return WCXPNCHSPG < UHYNBFNIBZ ? ICZMZGONLU : TTCAUTPPAY;
    }

    static int getNumEntriesPerChunk(Configuration HGIOCQHCCZ) {
        return DistCpUtils.getInt(HGIOCQHCCZ, DynamicInputFormat.OXKMKFNQKD);
    }

    /**
     * Implementation of Inputformat::createRecordReader().
     *
     * @param inputSplit
     * 		The split for which the RecordReader is required.
     * @param taskAttemptContext
     * 		TaskAttemptContext for the current attempt.
     * @return DynamicRecordReader instance.
     * @throws IOException,
     * 		on failure.
     * @throws InterruptedException
     * 		
     */
    @Override
    public RecordReader<K, V> createRecordReader(InputSplit CTQYAXSRTM, TaskAttemptContext PSVGYZDUZH) throws IOException, InterruptedException {
        return new DynamicRecordReader<K, V>();
    }
}