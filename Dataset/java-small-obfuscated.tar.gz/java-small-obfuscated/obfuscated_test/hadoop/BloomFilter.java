/**
 * Implements a <i>Bloom filter</i>, as defined by Bloom in 1970.
 * <p>
 * The Bloom filter is a data structure that was introduced in 1970 and that has been adopted by
 * the networking research community in the past decade thanks to the bandwidth efficiencies that it
 * offers for the transmission of set membership information between networked hosts.  A sender encodes
 * the information into a bit vector, the Bloom filter, that is more compact than a conventional
 * representation. Computation and space costs for construction are linear in the number of elements.
 * The receiver uses the filter to test whether various elements are members of the set. Though the
 * filter will occasionally return a false positive, it will never return a false negative. When creating
 * the filter, the sender can choose its desired point in a trade-off between the false positive rate and the size.
 *
 * <p>
 * Originally created by
 * <a href="http://www.one-lab.org">European Commission One-Lab Project 034819</a>.
 *
 * @see Filter The general behavior of a filter
 * @see <a href="http://portal.acm.org/citation.cfm?id=362692&dl=ACM&coll=portal">Space/Time Trade-Offs in Hash Coding with Allowable Errors</a>
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class BloomFilter extends Filter {
    private static final byte[] TTGPKMAKNM = new byte[]{ ((byte) (0x1)), ((byte) (0x2)), ((byte) (0x4)), ((byte) (0x8)), ((byte) (0x10)), ((byte) (0x20)), ((byte) (0x40)), ((byte) (0x80)) };

    /**
     * The bit vector.
     */
    BitSet EEHBHMWVQE;

    /**
     * Default constructor - use with readFields
     */
    public BloomFilter() {
        super();
    }

    /**
     * Constructor
     *
     * @param vectorSize
     * 		The vector size of <i>this</i> filter.
     * @param nbHash
     * 		The number of hash function to consider.
     * @param hashType
     * 		type of the hashing function (see
     * 		{@link org.apache.hadoop.util.hash.Hash}).
     */
    public BloomFilter(int EFNJPGSTBK, int VYWDDQVLUZ, int UYRPRHIQJF) {
        super(EFNJPGSTBK, VYWDDQVLUZ, UYRPRHIQJF);
        EEHBHMWVQE = new BitSet(this.vectorSize);
    }

    @Override
    public void add(Key QSXJXSECMF) {
        if (QSXJXSECMF == null) {
            throw new NullPointerException("key cannot be null");
        }
        int[] BHTGNLCKFY = hash.hash(QSXJXSECMF);
        hash.clear();
        for (int DZECTWAUEH = 0; DZECTWAUEH < nbHash; DZECTWAUEH++) {
            EEHBHMWVQE.set(BHTGNLCKFY[DZECTWAUEH]);
        }
    }

    @Override
    public void and(Filter ZQKTKYVBQH) {
        if ((((ZQKTKYVBQH == null) || (!(ZQKTKYVBQH instanceof BloomFilter))) || (ZQKTKYVBQH.vectorSize != this.vectorSize)) || (ZQKTKYVBQH.nbHash != this.nbHash)) {
            throw new IllegalArgumentException("filters cannot be and-ed");
        }
        this.EEHBHMWVQE.and(((BloomFilter) (ZQKTKYVBQH)).EEHBHMWVQE);
    }

    @Override
    public boolean membershipTest(Key BNFSXIGIIX) {
        if (BNFSXIGIIX == null) {
            throw new NullPointerException("key cannot be null");
        }
        int[] MMSCVUXTRG = hash.hash(BNFSXIGIIX);
        hash.clear();
        for (int XGKULDPTOU = 0; XGKULDPTOU < nbHash; XGKULDPTOU++) {
            if (!EEHBHMWVQE.get(MMSCVUXTRG[XGKULDPTOU])) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void not() {
        EEHBHMWVQE.flip(0, vectorSize - 1);
    }

    @Override
    public void or(Filter PVCGBVXBDD) {
        if ((((PVCGBVXBDD == null) || (!(PVCGBVXBDD instanceof BloomFilter))) || (PVCGBVXBDD.vectorSize != this.vectorSize)) || (PVCGBVXBDD.nbHash != this.nbHash)) {
            throw new IllegalArgumentException("filters cannot be or-ed");
        }
        EEHBHMWVQE.or(((BloomFilter) (PVCGBVXBDD)).EEHBHMWVQE);
    }

    @Override
    public void xor(Filter POUBYMBAJK) {
        if ((((POUBYMBAJK == null) || (!(POUBYMBAJK instanceof BloomFilter))) || (POUBYMBAJK.vectorSize != this.vectorSize)) || (POUBYMBAJK.nbHash != this.nbHash)) {
            throw new IllegalArgumentException("filters cannot be xor-ed");
        }
        EEHBHMWVQE.xor(((BloomFilter) (POUBYMBAJK)).EEHBHMWVQE);
    }

    @Override
    public String toString() {
        return EEHBHMWVQE.toString();
    }

    /**
     *
     *
     * @return size of the the bloomfilter
     */
    public int getVectorSize() {
        return this.vectorSize;
    }

    // Writable
    @Override
    public void write(DataOutput XOZKLMXTWR) throws IOException {
        super.write(XOZKLMXTWR);
        byte[] JFTEPAJXPV = new byte[getNBytes()];
        for (int WBHUVWDLDO = 0, MGRKGOZKPR = 0, JFPDJNMEPH = 0; WBHUVWDLDO < vectorSize; WBHUVWDLDO++ , JFPDJNMEPH++) {
            if (JFPDJNMEPH == 8) {
                JFPDJNMEPH = 0;
                MGRKGOZKPR++;
            }
            if (JFPDJNMEPH == 0) {
                JFTEPAJXPV[MGRKGOZKPR] = 0;
            }
            if (EEHBHMWVQE.get(WBHUVWDLDO)) {
                JFTEPAJXPV[MGRKGOZKPR] |= BloomFilter.TTGPKMAKNM[JFPDJNMEPH];
            }
        }
        XOZKLMXTWR.write(JFTEPAJXPV);
    }

    @Override
    public void readFields(DataInput SCZJLNBPVZ) throws IOException {
        super.readFields(SCZJLNBPVZ);
        EEHBHMWVQE = new BitSet(this.vectorSize);
        byte[] JMWGUAGIZI = new byte[getNBytes()];
        SCZJLNBPVZ.readFully(JMWGUAGIZI);
        for (int CHXRKNQLBV = 0, DMQGCLYSCJ = 0, XGEUOSECAA = 0; CHXRKNQLBV < vectorSize; CHXRKNQLBV++ , XGEUOSECAA++) {
            if (XGEUOSECAA == 8) {
                XGEUOSECAA = 0;
                DMQGCLYSCJ++;
            }
            if ((JMWGUAGIZI[DMQGCLYSCJ] & BloomFilter.TTGPKMAKNM[XGEUOSECAA]) != 0) {
                EEHBHMWVQE.set(CHXRKNQLBV);
            }
        }
    }

    /* @return number of bytes needed to hold bit vector */
    private int getNBytes() {
        return (vectorSize + 7) / 8;
    }
}