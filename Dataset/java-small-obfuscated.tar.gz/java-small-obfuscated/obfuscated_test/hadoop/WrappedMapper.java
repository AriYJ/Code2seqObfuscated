/**
 * A {@link Mapper} which wraps a given one to allow custom
 * {@link Mapper.Context} implementations.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class WrappedMapper<KEYIN, VALUEIN, KEYOUT, VALUEOUT> extends Mapper<KEYIN, VALUEIN, KEYOUT, VALUEOUT> {
    /**
     * Get a wrapped {@link Mapper.Context} for custom implementations.
     *
     * @param mapContext
     * 		<code>MapContext</code> to be wrapped
     * @return a wrapped <code>Mapper.Context</code> for custom implementations
     */
    public Mapper.Context getMapContext(MapContext<KEYIN, VALUEIN, KEYOUT, VALUEOUT> ROHAXPOZZY) {
        return new Context(ROHAXPOZZY);
    }

    @InterfaceStability.Evolving
    public class Context extends Mapper.Context {
        protected MapContext<KEYIN, VALUEIN, KEYOUT, VALUEOUT> IIHQLZQXNQ;

        public Context(MapContext<KEYIN, VALUEIN, KEYOUT, VALUEOUT> mapContext) {
            this.mapContext = mapContext;
        }

        /**
         * Get the input split for this map.
         */
        public InputSplit getInputSplit() {
            return IIHQLZQXNQ.getInputSplit();
        }

        @Override
        public KEYIN getCurrentKey() throws IOException, InterruptedException {
            return IIHQLZQXNQ.getCurrentKey();
        }

        @Override
        public VALUEIN getCurrentValue() throws IOException, InterruptedException {
            return IIHQLZQXNQ.getCurrentValue();
        }

        @Override
        public boolean nextKeyValue() throws IOException, InterruptedException {
            return IIHQLZQXNQ.nextKeyValue();
        }

        @Override
        public Counter getCounter(Enum<?> counterName) {
            return IIHQLZQXNQ.getCounter(counterName);
        }

        @Override
        public Counter getCounter(String groupName, String counterName) {
            return IIHQLZQXNQ.getCounter(groupName, counterName);
        }

        @Override
        public OutputCommitter getOutputCommitter() {
            return IIHQLZQXNQ.getOutputCommitter();
        }

        @Override
        public void write(KEYOUT key, VALUEOUT value) throws IOException, InterruptedException {
            IIHQLZQXNQ.write(key, value);
        }

        @Override
        public String getStatus() {
            return IIHQLZQXNQ.getStatus();
        }

        @Override
        public TaskAttemptID getTaskAttemptID() {
            return IIHQLZQXNQ.getTaskAttemptID();
        }

        @Override
        public void setStatus(String msg) {
            IIHQLZQXNQ.setStatus(msg);
        }

        @Override
        public Path[] getArchiveClassPaths() {
            return IIHQLZQXNQ.getArchiveClassPaths();
        }

        @Override
        public String[] getArchiveTimestamps() {
            return IIHQLZQXNQ.getArchiveTimestamps();
        }

        @Override
        public URI[] getCacheArchives() throws IOException {
            return IIHQLZQXNQ.getCacheArchives();
        }

        @Override
        public URI[] getCacheFiles() throws IOException {
            return IIHQLZQXNQ.getCacheFiles();
        }

        @Override
        public Class<? extends Reducer<?, ?, ?, ?>> getCombinerClass() throws ClassNotFoundException {
            return IIHQLZQXNQ.getCombinerClass();
        }

        @Override
        public Configuration getConfiguration() {
            return IIHQLZQXNQ.getConfiguration();
        }

        @Override
        public Path[] getFileClassPaths() {
            return IIHQLZQXNQ.getFileClassPaths();
        }

        @Override
        public String[] getFileTimestamps() {
            return IIHQLZQXNQ.getFileTimestamps();
        }

        @Override
        public RawComparator<?> getCombinerKeyGroupingComparator() {
            return IIHQLZQXNQ.getCombinerKeyGroupingComparator();
        }

        @Override
        public RawComparator<?> getGroupingComparator() {
            return IIHQLZQXNQ.getGroupingComparator();
        }

        @Override
        public Class<? extends InputFormat<?, ?>> getInputFormatClass() throws ClassNotFoundException {
            return IIHQLZQXNQ.getInputFormatClass();
        }

        @Override
        public String getJar() {
            return IIHQLZQXNQ.getJar();
        }

        @Override
        public JobID getJobID() {
            return IIHQLZQXNQ.getJobID();
        }

        @Override
        public String getJobName() {
            return IIHQLZQXNQ.getJobName();
        }

        @Override
        public boolean getJobSetupCleanupNeeded() {
            return IIHQLZQXNQ.getJobSetupCleanupNeeded();
        }

        @Override
        public boolean getTaskCleanupNeeded() {
            return IIHQLZQXNQ.getTaskCleanupNeeded();
        }

        @Override
        public Path[] getLocalCacheArchives() throws IOException {
            return IIHQLZQXNQ.getLocalCacheArchives();
        }

        @Override
        public Path[] getLocalCacheFiles() throws IOException {
            return IIHQLZQXNQ.getLocalCacheFiles();
        }

        @Override
        public Class<?> getMapOutputKeyClass() {
            return IIHQLZQXNQ.getMapOutputKeyClass();
        }

        @Override
        public Class<?> getMapOutputValueClass() {
            return IIHQLZQXNQ.getMapOutputValueClass();
        }

        @Override
        public Class<? extends Mapper<?, ?, ?, ?>> getMapperClass() throws ClassNotFoundException {
            return IIHQLZQXNQ.getMapperClass();
        }

        @Override
        public int getMaxMapAttempts() {
            return IIHQLZQXNQ.getMaxMapAttempts();
        }

        @Override
        public int getMaxReduceAttempts() {
            return IIHQLZQXNQ.getMaxReduceAttempts();
        }

        @Override
        public int getNumReduceTasks() {
            return IIHQLZQXNQ.getNumReduceTasks();
        }

        @Override
        public Class<? extends OutputFormat<?, ?>> getOutputFormatClass() throws ClassNotFoundException {
            return IIHQLZQXNQ.getOutputFormatClass();
        }

        @Override
        public Class<?> getOutputKeyClass() {
            return IIHQLZQXNQ.getOutputKeyClass();
        }

        @Override
        public Class<?> getOutputValueClass() {
            return IIHQLZQXNQ.getOutputValueClass();
        }

        @Override
        public Class<? extends Partitioner<?, ?>> getPartitionerClass() throws ClassNotFoundException {
            return IIHQLZQXNQ.getPartitionerClass();
        }

        @Override
        public Class<? extends Reducer<?, ?, ?, ?>> getReducerClass() throws ClassNotFoundException {
            return IIHQLZQXNQ.getReducerClass();
        }

        @Override
        public RawComparator<?> getSortComparator() {
            return IIHQLZQXNQ.getSortComparator();
        }

        @Override
        public boolean getSymlink() {
            return IIHQLZQXNQ.getSymlink();
        }

        @Override
        public Path getWorkingDirectory() throws IOException {
            return IIHQLZQXNQ.getWorkingDirectory();
        }

        @Override
        public void progress() {
            IIHQLZQXNQ.progress();
        }

        @Override
        public boolean getProfileEnabled() {
            return IIHQLZQXNQ.getProfileEnabled();
        }

        @Override
        public String getProfileParams() {
            return IIHQLZQXNQ.getProfileParams();
        }

        @Override
        public IntegerRanges getProfileTaskRange(boolean isMap) {
            return IIHQLZQXNQ.getProfileTaskRange(isMap);
        }

        @Override
        public String getUser() {
            return IIHQLZQXNQ.getUser();
        }

        @Override
        public Credentials getCredentials() {
            return IIHQLZQXNQ.getCredentials();
        }

        @Override
        public float getProgress() {
            return IIHQLZQXNQ.getProgress();
        }
    }
}