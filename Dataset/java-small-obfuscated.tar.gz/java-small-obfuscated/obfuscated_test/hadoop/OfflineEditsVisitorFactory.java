/**
 * EditsVisitorFactory for different implementations of EditsVisitor
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class OfflineEditsVisitorFactory {
    /**
     * Factory function that creates an EditsVisitor object
     *
     * @param filename
     * 		output filename
     * @param processor
     * 		type of visitor to create
     * @param printToScreen
     * 		parameter passed to visitor constructor
     * @return EditsVisitor for appropriate output format (binary, xml, etc.)
     */
    public static OfflineEditsVisitor getEditsVisitor(String XCHTGXNIIZ, String LSOQBSCPDQ, boolean JKUQCGFBWF) throws IOException {
        if (LSOQBSCPDQ.toLowerCase().equals("binary")) {
            return new BinaryEditsVisitor(XCHTGXNIIZ);
        }
        OfflineEditsVisitor EQWMEQGMPF;
        OutputStream KWUANEFVZE = new FileOutputStream(XCHTGXNIIZ);
        OutputStream VUNNGLIFCJ = null;
        try {
            if (!JKUQCGFBWF) {
                VUNNGLIFCJ = KWUANEFVZE;
            } else {
                OutputStream[] EUUBOCPORR = new OutputStream[2];
                EUUBOCPORR[0] = KWUANEFVZE;
                EUUBOCPORR[1] = System.out;
                VUNNGLIFCJ = new TeeOutputStream(EUUBOCPORR);
            }
            if (LSOQBSCPDQ.toLowerCase().equals("xml")) {
                EQWMEQGMPF = new XmlEditsVisitor(VUNNGLIFCJ);
            } else
                if (LSOQBSCPDQ.toLowerCase().equals("stats")) {
                    EQWMEQGMPF = new StatisticsEditsVisitor(VUNNGLIFCJ);
                } else {
                    throw new IOException(("Unknown proccesor " + LSOQBSCPDQ) + " (valid processors: xml, binary, stats)");
                }

            VUNNGLIFCJ = KWUANEFVZE = null;
            return EQWMEQGMPF;
        } finally {
            IOUtils.closeStream(KWUANEFVZE);
            IOUtils.closeStream(VUNNGLIFCJ);
        }
    }
}