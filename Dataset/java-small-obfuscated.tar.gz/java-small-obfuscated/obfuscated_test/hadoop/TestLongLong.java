public class TestLongLong extends TestCase {
    static final Random DOCNSUMCIL = new Random();

    static final long RLTCBTLLFG = (1L << (LongLong.SIZE >> 1)) - 1;

    static long nextPositiveLong() {
        return TestLongLong.DOCNSUMCIL.nextLong() & TestLongLong.RLTCBTLLFG;
    }

    static void verifyMultiplication(long QTSARSIBMO, long PBVIOEWDCP) {
        final LongLong KLKBXGYDOD = LongLong.multiplication(new LongLong(), QTSARSIBMO, PBVIOEWDCP);
        final BigInteger OIKPBWKFVA = BigInteger.valueOf(QTSARSIBMO).multiply(BigInteger.valueOf(PBVIOEWDCP));
        final String JGKFYOHGBI = String.format(((("\na = %x\nb = %x\nll= " + KLKBXGYDOD) + "\nbi= ") + OIKPBWKFVA.toString(16)) + "\n", QTSARSIBMO, PBVIOEWDCP);
        // System.out.println(s);
        assertEquals(JGKFYOHGBI, OIKPBWKFVA, KLKBXGYDOD.toBigInteger());
    }

    public void testMultiplication() {
        for (int DSYBJUAXOQ = 0; DSYBJUAXOQ < 100; DSYBJUAXOQ++) {
            final long WDQRWVLJTC = TestLongLong.nextPositiveLong();
            final long ZJBHVGXZQA = TestLongLong.nextPositiveLong();
            TestLongLong.verifyMultiplication(WDQRWVLJTC, ZJBHVGXZQA);
        }
        final long ORGAVFSGVT = Long.MAX_VALUE & TestLongLong.RLTCBTLLFG;
        TestLongLong.verifyMultiplication(ORGAVFSGVT, ORGAVFSGVT);
    }

    static void verifyRightShift(long LQWWQHWWJB, long RVLCOQKSEW) {
        final LongLong PJCTDIHHAK = new LongLong().set(LQWWQHWWJB, RVLCOQKSEW);
        final BigInteger QUXGYNGSPZ = PJCTDIHHAK.toBigInteger();
        for (int CBQYDIXUDF = 0; CBQYDIXUDF < (LongLong.SIZE >> 1); CBQYDIXUDF++) {
            final long BWEXLKUMSH = PJCTDIHHAK.shiftRight(CBQYDIXUDF) & TestLongLong.RLTCBTLLFG;
            final long OBYPNNERBK = QUXGYNGSPZ.shiftRight(CBQYDIXUDF).longValue() & TestLongLong.RLTCBTLLFG;
            final String AKYXGVRXIN = String.format(((("\na = %x\nb = %x\nll= " + PJCTDIHHAK) + "\nbi= ") + QUXGYNGSPZ.toString(16)) + "\n", LQWWQHWWJB, RVLCOQKSEW);
            assertEquals(AKYXGVRXIN, OBYPNNERBK, BWEXLKUMSH);
        }
        final String LHWIUKJEON = String.format(((("\na = %x\nb = %x\nll= " + PJCTDIHHAK) + "\nbi= ") + QUXGYNGSPZ.toString(16)) + "\n", LQWWQHWWJB, RVLCOQKSEW);
        // System.out.println(s);
        assertEquals(LHWIUKJEON, QUXGYNGSPZ, PJCTDIHHAK.toBigInteger());
    }

    public void testRightShift() {
        for (int QQSNOPIMWY = 0; QQSNOPIMWY < 1000; QQSNOPIMWY++) {
            final long GBIZGTTRFQ = TestLongLong.nextPositiveLong();
            final long HSATYCOVBD = TestLongLong.nextPositiveLong();
            TestLongLong.verifyMultiplication(GBIZGTTRFQ, HSATYCOVBD);
        }
    }
}