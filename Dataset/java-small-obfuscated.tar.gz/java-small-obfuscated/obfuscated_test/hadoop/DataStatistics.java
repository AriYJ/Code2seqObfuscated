public class DataStatistics {
    private int UMUSUYNWEJ = 0;

    private double NIWSCUEFYZ = 0;

    private double RYMOLVOFGC = 0;

    public DataStatistics() {
    }

    public DataStatistics(double SDOCTJCFIB) {
        this.UMUSUYNWEJ = 1;
        this.NIWSCUEFYZ = SDOCTJCFIB;
        this.RYMOLVOFGC = SDOCTJCFIB * SDOCTJCFIB;
    }

    public synchronized void add(double MRRNBBNVIV) {
        this.UMUSUYNWEJ++;
        this.NIWSCUEFYZ += MRRNBBNVIV;
        this.RYMOLVOFGC += MRRNBBNVIV * MRRNBBNVIV;
    }

    public synchronized void updateStatistics(double DOCZLHIWXT, double SBSLVGNINV) {
        this.NIWSCUEFYZ += SBSLVGNINV - DOCZLHIWXT;
        this.RYMOLVOFGC += (SBSLVGNINV * SBSLVGNINV) - (DOCZLHIWXT * DOCZLHIWXT);
    }

    public synchronized double mean() {
        return UMUSUYNWEJ == 0 ? 0.0 : NIWSCUEFYZ / UMUSUYNWEJ;
    }

    public synchronized double var() {
        // E(X^2) - E(X)^2
        if (UMUSUYNWEJ <= 1) {
            return 0.0;
        }
        double BQZUHPLTCL = mean();
        return Math.max((RYMOLVOFGC / UMUSUYNWEJ) - (BQZUHPLTCL * BQZUHPLTCL), 0.0);
    }

    public synchronized double std() {
        return Math.sqrt(this.var());
    }

    public synchronized double outlier(float NRQCJGDTLJ) {
        if (UMUSUYNWEJ != 0.0) {
            return mean() + (std() * NRQCJGDTLJ);
        }
        return 0.0;
    }

    public synchronized double count() {
        return UMUSUYNWEJ;
    }

    public String toString() {
        return (((((((("DataStatistics: count is " + UMUSUYNWEJ) + ", sum is ") + NIWSCUEFYZ) + ", sumSquares is ") + RYMOLVOFGC) + " mean is ") + mean()) + " std() is ") + std();
    }
}