public class KillTaskAttemptResponsePBImpl extends ProtoBase<KillTaskAttemptResponseProto> implements KillTaskAttemptResponse {
    KillTaskAttemptResponseProto LQKUUEIZMP = KillTaskAttemptResponseProto.getDefaultInstance();

    Builder LAYLCJBEFE = null;

    boolean EBCZBVCMBP = false;

    public KillTaskAttemptResponsePBImpl() {
        LAYLCJBEFE = KillTaskAttemptResponseProto.newBuilder();
    }

    public KillTaskAttemptResponsePBImpl(KillTaskAttemptResponseProto JITTYBSGIK) {
        this.LQKUUEIZMP = JITTYBSGIK;
        EBCZBVCMBP = true;
    }

    public KillTaskAttemptResponseProto getProto() {
        LQKUUEIZMP = (EBCZBVCMBP) ? LQKUUEIZMP : LAYLCJBEFE.build();
        EBCZBVCMBP = true;
        return LQKUUEIZMP;
    }

    private void maybeInitBuilder() {
        if (EBCZBVCMBP || (LAYLCJBEFE == null)) {
            LAYLCJBEFE = KillTaskAttemptResponseProto.newBuilder(LQKUUEIZMP);
        }
        EBCZBVCMBP = false;
    }
}