public class TestLogalyzer {
    private static String EWTGSVINHR = System.getProperty("line.separator");

    private static String DISJKIHEHV = "\t";

    private static final Log WLNRMECIJJ = LogFactory.getLog(TestLogalyzer.class);

    private static File BAJTWETEYU = new File("target", TestLogalyzer.class.getName() + "-workSpace");

    private static File TDACTEIFKL = new File((TestLogalyzer.BAJTWETEYU.getAbsoluteFile() + File.separator) + "out");

    @Test
    public void testLogalyzer() throws Exception {
        Path NUWSYMREZE = createLogFile();
        String[] CSWPYDZOUK = new String[10];
        CSWPYDZOUK[0] = "-archiveDir";
        CSWPYDZOUK[1] = NUWSYMREZE.toString();
        CSWPYDZOUK[2] = "-grep";
        CSWPYDZOUK[3] = "44";
        CSWPYDZOUK[4] = "-sort";
        CSWPYDZOUK[5] = "0";
        CSWPYDZOUK[6] = "-analysis";
        CSWPYDZOUK[7] = TestLogalyzer.TDACTEIFKL.getAbsolutePath();
        CSWPYDZOUK[8] = "-separator";
        CSWPYDZOUK[9] = " ";
        Logalyzer.main(CSWPYDZOUK);
        checkResult();
    }

    private void checkResult() throws Exception {
        File IUFJZRJHWM = new File((TestLogalyzer.TDACTEIFKL.getAbsolutePath() + File.separator) + "part-00000");
        File CGLHSGREIJ = new File((TestLogalyzer.TDACTEIFKL.getAbsolutePath() + File.separator) + "_SUCCESS");
        Assert.assertTrue(CGLHSGREIJ.exists());
        FileInputStream TTXGYVESKI = new FileInputStream(IUFJZRJHWM);
        BufferedReader IZNFROUNZO = new BufferedReader(new InputStreamReader(TTXGYVESKI, "UTF-8"));
        String BQFQCQLPCA = IZNFROUNZO.readLine();
        Assert.assertTrue((("1 44" + TestLogalyzer.DISJKIHEHV) + "2").equals(BQFQCQLPCA));
        BQFQCQLPCA = IZNFROUNZO.readLine();
        Assert.assertTrue((("3 44" + TestLogalyzer.DISJKIHEHV) + "1").equals(BQFQCQLPCA));
        BQFQCQLPCA = IZNFROUNZO.readLine();
        Assert.assertTrue((("4 44" + TestLogalyzer.DISJKIHEHV) + "1").equals(BQFQCQLPCA));
        IZNFROUNZO.close();
    }

    /**
     * Create simple log file
     *
     * @return 
     * @throws IOException
     * 		
     */
    private Path createLogFile() throws IOException {
        FileContext LUOSIINBOK = FileContext.getLocalFSFileContext();
        Path WCCTQPVLDW = new Path(TestLogalyzer.BAJTWETEYU.getAbsoluteFile().getAbsolutePath());
        LUOSIINBOK.delete(WCCTQPVLDW, true);
        Path ZATNNHITTI = new Path(TestLogalyzer.BAJTWETEYU.getAbsolutePath(), "log");
        LUOSIINBOK.mkdir(ZATNNHITTI, null, true);
        TestLogalyzer.WLNRMECIJJ.info("create logfile.log");
        Path JVXWLWJLRZ = new Path(ZATNNHITTI, "logfile.log");
        FSDataOutputStream LHWSAOMZWH = LUOSIINBOK.create(JVXWLWJLRZ, EnumSet.of(CREATE));
        LHWSAOMZWH.writeBytes((((("4 3" + TestLogalyzer.EWTGSVINHR) + "1 3") + TestLogalyzer.EWTGSVINHR) + "4 44") + TestLogalyzer.EWTGSVINHR);
        LHWSAOMZWH.writeBytes((((("2 3" + TestLogalyzer.EWTGSVINHR) + "1 3") + TestLogalyzer.EWTGSVINHR) + "0 45") + TestLogalyzer.EWTGSVINHR);
        LHWSAOMZWH.writeBytes((((("4 3" + TestLogalyzer.EWTGSVINHR) + "1 3") + TestLogalyzer.EWTGSVINHR) + "1 44") + TestLogalyzer.EWTGSVINHR);
        LHWSAOMZWH.flush();
        LHWSAOMZWH.close();
        TestLogalyzer.WLNRMECIJJ.info("create logfile1.log");
        Path SRWHRLRBDX = new Path(ZATNNHITTI, "logfile1.log");
        LHWSAOMZWH = LUOSIINBOK.create(SRWHRLRBDX, EnumSet.of(CREATE));
        LHWSAOMZWH.writeBytes((((("4 3" + TestLogalyzer.EWTGSVINHR) + "1 3") + TestLogalyzer.EWTGSVINHR) + "3 44") + TestLogalyzer.EWTGSVINHR);
        LHWSAOMZWH.writeBytes((((("2 3" + TestLogalyzer.EWTGSVINHR) + "1 3") + TestLogalyzer.EWTGSVINHR) + "0 45") + TestLogalyzer.EWTGSVINHR);
        LHWSAOMZWH.writeBytes((((("4 3" + TestLogalyzer.EWTGSVINHR) + "1 3") + TestLogalyzer.EWTGSVINHR) + "1 44") + TestLogalyzer.EWTGSVINHR);
        LHWSAOMZWH.flush();
        LHWSAOMZWH.close();
        return ZATNNHITTI;
    }
}