/**
 * Tests for <code>XAttr</code> objects.
 */
public class TestXAttr {
    private static XAttr EDGSCPHVJK;

    private static XAttr IZWEBUGUIY;

    private static XAttr MBRFRSGHGF;

    private static XAttr KRGNQRPIPZ;

    private static XAttr ZIHYCRXPLF;

    private static XAttr NLXAQDQKPZ;

    @BeforeClass
    public static void setUp() throws Exception {
        byte[] LOVLLAMHCR = new byte[]{ 0x31, 0x32, 0x33 };
        TestXAttr.EDGSCPHVJK = new XAttr.Builder().setName("name").setValue(LOVLLAMHCR).build();
        TestXAttr.IZWEBUGUIY = new XAttr.Builder().setNameSpace(XAttr.NameSpace.USER).setName("name").setValue(LOVLLAMHCR).build();
        TestXAttr.MBRFRSGHGF = new XAttr.Builder().setNameSpace(XAttr.NameSpace.TRUSTED).setName("name").setValue(LOVLLAMHCR).build();
        TestXAttr.KRGNQRPIPZ = new XAttr.Builder().setNameSpace(XAttr.NameSpace.SYSTEM).setName("name").setValue(LOVLLAMHCR).build();
        TestXAttr.ZIHYCRXPLF = new XAttr.Builder().setNameSpace(XAttr.NameSpace.SECURITY).setName("name").setValue(LOVLLAMHCR).build();
        TestXAttr.NLXAQDQKPZ = new XAttr.Builder().setNameSpace(XAttr.NameSpace.RAW).setName("name").setValue(LOVLLAMHCR).build();
    }

    @Test
    public void testXAttrEquals() {
        assertNotSame(TestXAttr.IZWEBUGUIY, TestXAttr.MBRFRSGHGF);
        assertNotSame(TestXAttr.MBRFRSGHGF, TestXAttr.KRGNQRPIPZ);
        assertNotSame(TestXAttr.KRGNQRPIPZ, TestXAttr.ZIHYCRXPLF);
        assertNotSame(TestXAttr.ZIHYCRXPLF, TestXAttr.NLXAQDQKPZ);
        assertEquals(TestXAttr.EDGSCPHVJK, TestXAttr.IZWEBUGUIY);
        assertEquals(TestXAttr.IZWEBUGUIY, TestXAttr.IZWEBUGUIY);
        assertEquals(TestXAttr.MBRFRSGHGF, TestXAttr.MBRFRSGHGF);
        assertEquals(TestXAttr.KRGNQRPIPZ, TestXAttr.KRGNQRPIPZ);
        assertEquals(TestXAttr.ZIHYCRXPLF, TestXAttr.ZIHYCRXPLF);
        assertEquals(TestXAttr.NLXAQDQKPZ, TestXAttr.NLXAQDQKPZ);
        assertFalse(TestXAttr.IZWEBUGUIY.equals(TestXAttr.MBRFRSGHGF));
        assertFalse(TestXAttr.MBRFRSGHGF.equals(TestXAttr.KRGNQRPIPZ));
        assertFalse(TestXAttr.KRGNQRPIPZ.equals(TestXAttr.ZIHYCRXPLF));
        assertFalse(TestXAttr.ZIHYCRXPLF.equals(TestXAttr.NLXAQDQKPZ));
    }

    @Test
    public void testXAttrHashCode() {
        assertEquals(TestXAttr.EDGSCPHVJK.hashCode(), TestXAttr.IZWEBUGUIY.hashCode());
        assertFalse(TestXAttr.IZWEBUGUIY.hashCode() == TestXAttr.MBRFRSGHGF.hashCode());
        assertFalse(TestXAttr.MBRFRSGHGF.hashCode() == TestXAttr.KRGNQRPIPZ.hashCode());
        assertFalse(TestXAttr.KRGNQRPIPZ.hashCode() == TestXAttr.ZIHYCRXPLF.hashCode());
        assertFalse(TestXAttr.ZIHYCRXPLF.hashCode() == TestXAttr.NLXAQDQKPZ.hashCode());
    }
}