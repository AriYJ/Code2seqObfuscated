public class ZKFCTestUtil {
    public static void waitForHealthState(ZKFailoverController GKTGHMDGIQ, HealthMonitor.State ECOJDEIZYT, MultithreadedTestUtil.TestContext TXDDRWIVBU) throws Exception {
        while (GKTGHMDGIQ.getLastHealthState() != ECOJDEIZYT) {
            if (TXDDRWIVBU != null) {
                TXDDRWIVBU.checkException();
            }
            Thread.sleep(50);
        } 
    }
}