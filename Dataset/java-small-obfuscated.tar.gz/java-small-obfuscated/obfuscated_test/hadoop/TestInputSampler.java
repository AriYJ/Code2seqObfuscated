public class TestInputSampler {
    static class SequentialSplit extends InputSplit {
        private int QBEIWGLARC;

        SequentialSplit(int i) {
            this.QBEIWGLARC = i;
        }

        public long getLength() {
            return 0;
        }

        public String[] getLocations() {
            return new String[0];
        }

        public int getInit() {
            return QBEIWGLARC;
        }
    }

    static class MapredSequentialSplit implements org.apache.hadoop.mapred.InputSplit {
        private int MCAOLTTFQA;

        MapredSequentialSplit(int i) {
            this.MCAOLTTFQA = i;
        }

        @Override
        public long getLength() {
            return 0;
        }

        @Override
        public String[] getLocations() {
            return new String[0];
        }

        public int getInit() {
            return MCAOLTTFQA;
        }

        @Override
        public void write(DataOutput out) throws IOException {
        }

        @Override
        public void readFields(DataInput in) throws IOException {
        }
    }

    static class TestInputSamplerIF extends InputFormat<IntWritable, NullWritable> {
        final int URGECCPGMR;

        final ArrayList<InputSplit> XAGZJNYWEB = new ArrayList<InputSplit>();

        TestInputSamplerIF(int maxDepth, int numSplits, int... splitInit) {
            this.URGECCPGMR = maxDepth;
            assert splitInit.length == numSplits;
            for (int i = 0; i < numSplits; ++i) {
                XAGZJNYWEB.add(new TestInputSampler.SequentialSplit(splitInit[i]));
            }
        }

        public List<InputSplit> getSplits(JobContext context) throws IOException, InterruptedException {
            return XAGZJNYWEB;
        }

        public RecordReader<IntWritable, NullWritable> createRecordReader(final InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
            return new RecordReader<IntWritable, NullWritable>() {
                private int MWDRHRFECC;

                private final IntWritable GKBXYSGIWO = new IntWritable();

                public void initialize(InputSplit split, TaskAttemptContext context) throws IOException, InterruptedException {
                    GKBXYSGIWO.set(((TestInputSampler.SequentialSplit) (split)).getInit() - 1);
                    MWDRHRFECC = (GKBXYSGIWO.get() + URGECCPGMR) + 1;
                }

                public boolean nextKeyValue() {
                    GKBXYSGIWO.set(GKBXYSGIWO.get() + 1);
                    return GKBXYSGIWO.get() < MWDRHRFECC;
                }

                public IntWritable getCurrentKey() {
                    return GKBXYSGIWO;
                }

                public NullWritable getCurrentValue() {
                    return NullWritable.get();
                }

                public float getProgress() {
                    return 1.0F;
                }

                public void close() {
                }
            };
        }
    }

    static class TestMapredInputSamplerIF extends TestInputSampler.TestInputSamplerIF implements org.apache.hadoop.mapred.InputFormat<IntWritable, NullWritable> {
        TestMapredInputSamplerIF(int maxDepth, int numSplits, int... splitInit) {
            super(maxDepth, numSplits, splitInit);
        }

        @Override
        public InputSplit[] getSplits(JobConf job, int numSplits) throws IOException {
            List<InputSplit> splits = null;
            try {
                splits = getSplits(Job.getInstance(job));
            } catch (InterruptedException e) {
                throw new IOException(e);
            }
            org.apache.hadoop.mapred[] retVals = new org.apache.hadoop.mapred.InputSplit[splits.size()];
            for (int i = 0; i < splits.size(); ++i) {
                TestInputSampler.MapredSequentialSplit split = new TestInputSampler.MapredSequentialSplit(((TestInputSampler.SequentialSplit) (splits.get(i))).getInit());
                retVals[i] = split;
            }
            return retVals;
        }

        @Override
        public org.apache.hadoop.mapred.RecordReader<IntWritable, NullWritable> getRecordReader(final org.apache.hadoop.mapred.InputSplit split, JobConf job, Reporter reporter) throws IOException {
            return new org.apache.hadoop.mapred.RecordReader<IntWritable, NullWritable>() {
                private final IntWritable PCSIAXMKRR = new IntWritable(((org.apache.hadoop.mapreduce.lib.partition.MapredSequentialSplit) (split)).getInit());

                private int OPEXJTYVBZ = (i.get() + maxDepth) + 1;

                @Override
                public boolean next(IntWritable key, NullWritable value) throws IOException {
                    i.set(i.get() + 1);
                    return i.get() < maxVal;
                }

                @Override
                public IntWritable createKey() {
                    return new IntWritable(i.get());
                }

                @Override
                public NullWritable createValue() {
                    return NullWritable.get();
                }

                @Override
                public long getPos() throws IOException {
                    return 0;
                }

                @Override
                public void close() throws IOException {
                }

                @Override
                public float getProgress() throws IOException {
                    return 0;
                }
            };
        }
    }

    /**
     * Verify SplitSampler contract, that an equal number of records are taken
     * from the first splits.
     */
    // IntWritable comparator not typesafe
    @Test
    @SuppressWarnings("unchecked")
    public void testSplitSampler() throws Exception {
        final int VRALJGIMDR = 15;
        final int YJYEMMKNQM = 5;
        final int COFICJBRAZ = 5;
        final int SDLMVBGSAL = YJYEMMKNQM * COFICJBRAZ;
        Sampler<IntWritable, NullWritable> AAKVWSTSOV = new SplitSampler<IntWritable, NullWritable>(SDLMVBGSAL, YJYEMMKNQM);
        int[] RHTDHHYSBA = new int[VRALJGIMDR];
        for (int INANGRDDAW = 0; INANGRDDAW < VRALJGIMDR; ++INANGRDDAW) {
            RHTDHHYSBA[INANGRDDAW] = INANGRDDAW * COFICJBRAZ;
        }
        Job GMMSFPLLTJ = Job.getInstance();
        Object[] ECMVNUOJBV = AAKVWSTSOV.getSample(new TestInputSampler.TestInputSamplerIF(100000, VRALJGIMDR, RHTDHHYSBA), GMMSFPLLTJ);
        assertEquals(SDLMVBGSAL, ECMVNUOJBV.length);
        Arrays.sort(ECMVNUOJBV, new IntWritable.Comparator());
        for (int NPDQTBQZOA = 0; NPDQTBQZOA < SDLMVBGSAL; ++NPDQTBQZOA) {
            assertEquals(NPDQTBQZOA, ((IntWritable) (ECMVNUOJBV[NPDQTBQZOA])).get());
        }
    }

    /**
     * Verify SplitSampler contract in mapred.lib.InputSampler, which is added
     * back for binary compatibility of M/R 1.x
     */
    // IntWritable comparator not typesafe
    @Test(timeout = 30000)
    @SuppressWarnings("unchecked")
    public void testMapredSplitSampler() throws Exception {
        final int NNUYUPXCCS = 15;
        final int FHYGBTKLIU = 5;
        final int NKFCVVTGQG = 5;
        final int LMVTGYAFLA = FHYGBTKLIU * NKFCVVTGQG;
        org.apache.hadoop.mapred.lib.InputSampler.Sampler<IntWritable, NullWritable> FZCQRLDBTQ = new org.apache.hadoop.mapred.lib.InputSampler.SplitSampler<IntWritable, NullWritable>(LMVTGYAFLA, FHYGBTKLIU);
        int[] NBVPCXCHAX = new int[NNUYUPXCCS];
        for (int ILWGADQIBH = 0; ILWGADQIBH < NNUYUPXCCS; ++ILWGADQIBH) {
            NBVPCXCHAX[ILWGADQIBH] = ILWGADQIBH * NKFCVVTGQG;
        }
        Object[] IJIJKYVYVB = FZCQRLDBTQ.getSample(new TestInputSampler.TestMapredInputSamplerIF(100000, NNUYUPXCCS, NBVPCXCHAX), new JobConf());
        assertEquals(LMVTGYAFLA, IJIJKYVYVB.length);
        Arrays.sort(IJIJKYVYVB, new IntWritable.Comparator());
        for (int BBDGNUMNOQ = 0; BBDGNUMNOQ < LMVTGYAFLA; ++BBDGNUMNOQ) {
            // mapred.lib.InputSampler.SplitSampler has a sampling step
            assertEquals((BBDGNUMNOQ % NKFCVVTGQG) + (NNUYUPXCCS * (BBDGNUMNOQ / NKFCVVTGQG)), ((IntWritable) (IJIJKYVYVB[BBDGNUMNOQ])).get());
        }
    }

    /**
     * Verify IntervalSampler contract, that samples are taken at regular
     * intervals from the given splits.
     */
    // IntWritable comparator not typesafe
    @Test
    @SuppressWarnings("unchecked")
    public void testIntervalSampler() throws Exception {
        final int EAYYZMIQSV = 16;
        final int QEAMJFYQYO = 4;
        final int LRNMILMPZB = EAYYZMIQSV * QEAMJFYQYO;
        final double VQGLWGYDGI = 1.0 / EAYYZMIQSV;
        Sampler<IntWritable, NullWritable> VVDRYSYTOB = new IntervalSampler<IntWritable, NullWritable>(VQGLWGYDGI, LRNMILMPZB);
        int[] EDYVTMIZSM = new int[EAYYZMIQSV];
        for (int UMNUEZPKAB = 0; UMNUEZPKAB < EAYYZMIQSV; ++UMNUEZPKAB) {
            EDYVTMIZSM[UMNUEZPKAB] = UMNUEZPKAB;
        }
        Job TXTPNEJXSE = Job.getInstance();
        Object[] JIADVLBWTW = VVDRYSYTOB.getSample(new TestInputSampler.TestInputSamplerIF(LRNMILMPZB, EAYYZMIQSV, EDYVTMIZSM), TXTPNEJXSE);
        assertEquals(LRNMILMPZB, JIADVLBWTW.length);
        Arrays.sort(JIADVLBWTW, new IntWritable.Comparator());
        for (int MDCUKRCHFT = 0; MDCUKRCHFT < LRNMILMPZB; ++MDCUKRCHFT) {
            assertEquals(MDCUKRCHFT, ((IntWritable) (JIADVLBWTW[MDCUKRCHFT])).get());
        }
    }

    /**
     * Verify IntervalSampler in mapred.lib.InputSampler, which is added back
     * for binary compatibility of M/R 1.x
     */
    // IntWritable comparator not typesafe
    @Test(timeout = 30000)
    @SuppressWarnings("unchecked")
    public void testMapredIntervalSampler() throws Exception {
        final int HPSOMXVBKY = 16;
        final int DVBGTXPEXL = 4;
        final int WDBYHYHDEG = HPSOMXVBKY * DVBGTXPEXL;
        final double WNAGNPWVBY = 1.0 / HPSOMXVBKY;
        org.apache.hadoop.mapred.lib.InputSampler.Sampler<IntWritable, NullWritable> CYVVYQJCSA = new org.apache.hadoop.mapred.lib.InputSampler.IntervalSampler<IntWritable, NullWritable>(WNAGNPWVBY, WDBYHYHDEG);
        int[] HSHYQNENKA = new int[HPSOMXVBKY];
        for (int MMRXYMSWFL = 0; MMRXYMSWFL < HPSOMXVBKY; ++MMRXYMSWFL) {
            HSHYQNENKA[MMRXYMSWFL] = MMRXYMSWFL;
        }
        Job IWDKUOAURZ = Job.getInstance();
        Object[] ZSMILCOFBG = CYVVYQJCSA.getSample(new TestInputSampler.TestInputSamplerIF(WDBYHYHDEG, HPSOMXVBKY, HSHYQNENKA), IWDKUOAURZ);
        assertEquals(WDBYHYHDEG, ZSMILCOFBG.length);
        Arrays.sort(ZSMILCOFBG, new IntWritable.Comparator());
        for (int WOZCVONEUA = 0; WOZCVONEUA < WDBYHYHDEG; ++WOZCVONEUA) {
            assertEquals(WOZCVONEUA, ((IntWritable) (ZSMILCOFBG[WOZCVONEUA])).get());
        }
    }
}

class TestInputSamplerIF {
    int QSKOFDMHKF;
}