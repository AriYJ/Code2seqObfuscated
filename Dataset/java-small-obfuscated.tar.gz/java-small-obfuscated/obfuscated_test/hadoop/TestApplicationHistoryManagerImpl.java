public class TestApplicationHistoryManagerImpl extends ApplicationHistoryStoreTestUtils {
    ApplicationHistoryManagerImpl MXHHHNKEPB = null;

    @Before
    public void setup() throws Exception {
        Configuration KXFBXADHEU = new Configuration();
        KXFBXADHEU.setClass(APPLICATION_HISTORY_STORE, MemoryApplicationHistoryStore.class, ApplicationHistoryStore.class);
        MXHHHNKEPB = new ApplicationHistoryManagerImpl();
        MXHHHNKEPB.init(KXFBXADHEU);
        MXHHHNKEPB.start();
        store = MXHHHNKEPB.getHistoryStore();
    }

    @After
    public void tearDown() throws Exception {
        MXHHHNKEPB.stop();
    }

    @Test
    public void testApplicationReport() throws IOException, YarnException {
        ApplicationId PEIXBKHKLS = null;
        PEIXBKHKLS = ApplicationId.newInstance(0, 1);
        writeApplicationStartData(PEIXBKHKLS);
        writeApplicationFinishData(PEIXBKHKLS);
        ApplicationAttemptId UKQRCGJCLT = ApplicationAttemptId.newInstance(PEIXBKHKLS, 1);
        writeApplicationAttemptStartData(UKQRCGJCLT);
        writeApplicationAttemptFinishData(UKQRCGJCLT);
        ApplicationReport ZYEPILGVSD = MXHHHNKEPB.getApplication(PEIXBKHKLS);
        Assert.assertNotNull(ZYEPILGVSD);
        Assert.assertEquals(PEIXBKHKLS, ZYEPILGVSD.getApplicationId());
        Assert.assertEquals(UKQRCGJCLT, ZYEPILGVSD.getCurrentApplicationAttemptId());
        Assert.assertEquals(UKQRCGJCLT.toString(), ZYEPILGVSD.getHost());
        Assert.assertEquals("test type", ZYEPILGVSD.getApplicationType().toString());
        Assert.assertEquals("test queue", ZYEPILGVSD.getQueue().toString());
    }
}