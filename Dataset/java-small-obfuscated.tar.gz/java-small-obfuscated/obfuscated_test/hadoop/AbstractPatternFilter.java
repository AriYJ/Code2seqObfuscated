/**
 * Base class for pattern based filters
 */
@InterfaceAudience.Private
public abstract class AbstractPatternFilter extends MetricsFilter {
    protected static final String IGZXNBVMDL = "include";

    protected static final String JXMGRNHTCL = "exclude";

    protected static final String FRSLQPISEN = "include.tags";

    protected static final String SPMDBDVADH = "exclude.tags";

    private Pattern QWDITEVEFC;

    private Pattern NUGNHDZZXE;

    private final Map<String, Pattern> KVZMFMYNKC;

    private final Map<String, Pattern> LGRIPHKUKQ;

    private final Pattern SYDPRCPNUK = Pattern.compile("^(\\w+):(.*)");

    AbstractPatternFilter() {
        KVZMFMYNKC = Maps.newHashMap();
        LGRIPHKUKQ = Maps.newHashMap();
    }

    @Override
    public void init(SubsetConfiguration RZLJTQMPWK) {
        String UXKFWBPRWK = RZLJTQMPWK.getString(AbstractPatternFilter.IGZXNBVMDL);
        if ((UXKFWBPRWK != null) && (!UXKFWBPRWK.isEmpty())) {
            setIncludePattern(compile(UXKFWBPRWK));
        }
        UXKFWBPRWK = RZLJTQMPWK.getString(AbstractPatternFilter.JXMGRNHTCL);
        if ((UXKFWBPRWK != null) && (!UXKFWBPRWK.isEmpty())) {
            setExcludePattern(compile(UXKFWBPRWK));
        }
        String[] DXIIXIVBRA = RZLJTQMPWK.getStringArray(AbstractPatternFilter.FRSLQPISEN);
        if ((DXIIXIVBRA != null) && (DXIIXIVBRA.length != 0)) {
            for (String YGMNANSWEQ : DXIIXIVBRA) {
                Matcher QXDZCAGLWC = SYDPRCPNUK.matcher(YGMNANSWEQ);
                if (!QXDZCAGLWC.matches()) {
                    throw new MetricsException("Illegal tag pattern: " + YGMNANSWEQ);
                }
                setIncludeTagPattern(QXDZCAGLWC.group(1), compile(QXDZCAGLWC.group(2)));
            }
        }
        DXIIXIVBRA = RZLJTQMPWK.getStringArray(AbstractPatternFilter.SPMDBDVADH);
        if ((DXIIXIVBRA != null) && (DXIIXIVBRA.length != 0)) {
            for (String JGRWESCXDD : DXIIXIVBRA) {
                Matcher JKCTNLUXOQ = SYDPRCPNUK.matcher(JGRWESCXDD);
                if (!JKCTNLUXOQ.matches()) {
                    throw new MetricsException("Illegal tag pattern: " + JGRWESCXDD);
                }
                setExcludeTagPattern(JKCTNLUXOQ.group(1), compile(JKCTNLUXOQ.group(2)));
            }
        }
    }

    void setIncludePattern(Pattern OSWERGUBTH) {
        this.QWDITEVEFC = OSWERGUBTH;
    }

    void setExcludePattern(Pattern AFXZHVGNWB) {
        this.NUGNHDZZXE = AFXZHVGNWB;
    }

    void setIncludeTagPattern(String GQWWEOZKEP, Pattern TPPNWJSSUL) {
        KVZMFMYNKC.put(GQWWEOZKEP, TPPNWJSSUL);
    }

    void setExcludeTagPattern(String MNLVJZJBKM, Pattern RNTLXSYSLS) {
        LGRIPHKUKQ.put(MNLVJZJBKM, RNTLXSYSLS);
    }

    @Override
    public boolean accepts(MetricsTag RVDZUBAHJZ) {
        // Accept if whitelisted
        Pattern WPVXUAQEUK = KVZMFMYNKC.get(RVDZUBAHJZ.name());
        if ((WPVXUAQEUK != null) && WPVXUAQEUK.matcher(RVDZUBAHJZ.value()).matches()) {
            return true;
        }
        // Reject if blacklisted
        Pattern MPJXEQFGPI = LGRIPHKUKQ.get(RVDZUBAHJZ.name());
        if ((MPJXEQFGPI != null) && MPJXEQFGPI.matcher(RVDZUBAHJZ.value()).matches()) {
            return false;
        }
        // Reject if no match in whitelist only mode
        if ((!KVZMFMYNKC.isEmpty()) && LGRIPHKUKQ.isEmpty()) {
            return false;
        }
        return true;
    }

    @Override
    public boolean accepts(Iterable<MetricsTag> DFGCAHJHXR) {
        // Accept if any include tag pattern matches
        for (MetricsTag IUMMIQMNDG : DFGCAHJHXR) {
            Pattern UHNCYGJRBY = KVZMFMYNKC.get(IUMMIQMNDG.name());
            if ((UHNCYGJRBY != null) && UHNCYGJRBY.matcher(IUMMIQMNDG.value()).matches()) {
                return true;
            }
        }
        // Reject if any exclude tag pattern matches
        for (MetricsTag FBVESYFIJE : DFGCAHJHXR) {
            Pattern DHZGNFKJYD = LGRIPHKUKQ.get(FBVESYFIJE.name());
            if ((DHZGNFKJYD != null) && DHZGNFKJYD.matcher(FBVESYFIJE.value()).matches()) {
                return false;
            }
        }
        // Reject if no match in whitelist only mode
        if ((!KVZMFMYNKC.isEmpty()) && LGRIPHKUKQ.isEmpty()) {
            return false;
        }
        return true;
    }

    @Override
    public boolean accepts(String NJLIJTLGUA) {
        // Accept if whitelisted
        if ((QWDITEVEFC != null) && QWDITEVEFC.matcher(NJLIJTLGUA).matches()) {
            return true;
        }
        // Reject if blacklisted
        if ((NUGNHDZZXE != null) && NUGNHDZZXE.matcher(NJLIJTLGUA).matches()) {
            return false;
        }
        // Reject if no match in whitelist only mode
        if ((QWDITEVEFC != null) && (NUGNHDZZXE == null)) {
            return false;
        }
        return true;
    }

    /**
     * Compile a string pattern in to a pattern object
     *
     * @param s
     * 		the string pattern to compile
     * @return the compiled pattern object
     */
    protected abstract Pattern compile(String IQGOZVJQDV);
}