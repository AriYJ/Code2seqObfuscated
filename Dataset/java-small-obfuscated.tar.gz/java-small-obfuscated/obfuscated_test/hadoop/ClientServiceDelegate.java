public class ClientServiceDelegate {
    private static final Log RQKQGWYZTW = LogFactory.getLog(ClientServiceDelegate.class);

    private static final String GGIJTOFWWI = "N/A";

    // Caches for per-user NotRunningJobs
    private HashMap<JobState, HashMap<String, NotRunningJob>> LPVCKFCSSV;

    private final Configuration WVNYUBORLL;

    private final JobID WWUOXROLNF;

    private final ApplicationId FLDVIEALPG;

    private final ResourceMgrDelegate MNTIFEGNSA;

    private final MRClientProtocol UIGKVHPMVR;

    private MRClientProtocol XRJEPRAZGV = null;

    private RecordFactory CTXMQZITLZ = RecordFactoryProvider.getRecordFactory(null);

    private static String AHXSPNBMGO = "Unknown User";

    private String OUIHIGOLQM;

    private AtomicBoolean VLNLDZXNNK = new AtomicBoolean(false);

    private int CJESQUDMRI;

    private boolean DLSYIUGOBS = false;

    public ClientServiceDelegate(Configuration RHHGGVGTUF, ResourceMgrDelegate MAUPMLXFLP, JobID FKIRIZOQPW, MRClientProtocol AQNKZLGPRG) {
        this.WVNYUBORLL = new Configuration(RHHGGVGTUF);// Cloning for modifying.

        // For faster redirects from AM to HS.
        this.WVNYUBORLL.setInt(IPC_CLIENT_CONNECT_MAX_RETRIES_KEY, this.WVNYUBORLL.getInt(MR_CLIENT_TO_AM_IPC_MAX_RETRIES, DEFAULT_MR_CLIENT_TO_AM_IPC_MAX_RETRIES));
        this.WVNYUBORLL.setInt(IPC_CLIENT_CONNECT_MAX_RETRIES_ON_SOCKET_TIMEOUTS_KEY, this.WVNYUBORLL.getInt(MR_CLIENT_TO_AM_IPC_MAX_RETRIES_ON_TIMEOUTS, DEFAULT_MR_CLIENT_TO_AM_IPC_MAX_RETRIES_ON_TIMEOUTS));
        this.MNTIFEGNSA = MAUPMLXFLP;
        this.WWUOXROLNF = FKIRIZOQPW;
        this.UIGKVHPMVR = AQNKZLGPRG;
        this.FLDVIEALPG = TypeConverter.toYarn(FKIRIZOQPW).getAppId();
        LPVCKFCSSV = new HashMap<JobState, HashMap<String, NotRunningJob>>();
    }

    // Get the instance of the NotRunningJob corresponding to the specified
    // user and state
    private NotRunningJob getNotRunningJob(ApplicationReport UFHOPANBEL, JobState MGRWMEBLDV) {
        synchronized(LPVCKFCSSV) {
            HashMap<String, NotRunningJob> QSTNAAXJXC = LPVCKFCSSV.get(MGRWMEBLDV);
            if (QSTNAAXJXC == null) {
                QSTNAAXJXC = new HashMap<String, NotRunningJob>();
                LPVCKFCSSV.put(MGRWMEBLDV, QSTNAAXJXC);
            }
            String DOKXNXKUIB = (UFHOPANBEL == null) ? ClientServiceDelegate.AHXSPNBMGO : UFHOPANBEL.getUser();
            NotRunningJob UUDDCDFAOY = QSTNAAXJXC.get(DOKXNXKUIB);
            if (UUDDCDFAOY == null) {
                UUDDCDFAOY = new NotRunningJob(UFHOPANBEL, MGRWMEBLDV);
                QSTNAAXJXC.put(DOKXNXKUIB, UUDDCDFAOY);
            }
            return UUDDCDFAOY;
        }
    }

    private MRClientProtocol getProxy() throws IOException {
        if (XRJEPRAZGV != null) {
            return XRJEPRAZGV;
        }
        // Possibly allow nulls through the PB tunnel, otherwise deal with an exception
        // and redirect to the history server.
        ApplicationReport FQLSFWDZRR = null;
        try {
            FQLSFWDZRR = MNTIFEGNSA.getApplicationReport(FLDVIEALPG);
        } catch (YarnException e2) {
            throw new IOException(e2);
        }
        if (FQLSFWDZRR != null) {
            OUIHIGOLQM = FQLSFWDZRR.getTrackingUrl();
        }
        InetSocketAddress TOLIBRUJIQ = null;
        while ((FQLSFWDZRR == null) || (YarnApplicationState.RUNNING == FQLSFWDZRR.getYarnApplicationState())) {
            if (FQLSFWDZRR == null) {
                ClientServiceDelegate.RQKQGWYZTW.info(("Could not get Job info from RM for job " + WWUOXROLNF) + ". Redirecting to job history server.");
                return checkAndGetHSProxy(null, NEW);
            }
            try {
                if ((FQLSFWDZRR.getHost() == null) || "".equals(FQLSFWDZRR.getHost())) {
                    ClientServiceDelegate.RQKQGWYZTW.debug("AM not assigned to Job. Waiting to get the AM ...");
                    Thread.sleep(2000);
                    ClientServiceDelegate.RQKQGWYZTW.debug("Application state is " + FQLSFWDZRR.getYarnApplicationState());
                    FQLSFWDZRR = MNTIFEGNSA.getApplicationReport(FLDVIEALPG);
                    continue;
                } else
                    if (ClientServiceDelegate.GGIJTOFWWI.equals(FQLSFWDZRR.getHost())) {
                        if (!DLSYIUGOBS) {
                            ClientServiceDelegate.RQKQGWYZTW.info((("Job " + WWUOXROLNF) + " is running, but the host is unknown.") + " Verify user has VIEW_JOB access.");
                            DLSYIUGOBS = true;
                        }
                        return getNotRunningJob(FQLSFWDZRR, RUNNING);
                    }

                if (!WVNYUBORLL.getBoolean(JOB_AM_ACCESS_DISABLED, false)) {
                    UserGroupInformation XXULCSDDVN = UserGroupInformation.createRemoteUser(UserGroupInformation.getCurrentUser().getUserName());
                    TOLIBRUJIQ = NetUtils.createSocketAddrForHost(FQLSFWDZRR.getHost(), FQLSFWDZRR.getRpcPort());
                    if (UserGroupInformation.isSecurityEnabled()) {
                        Token YFGPNPHSMD = FQLSFWDZRR.getClientToAMToken();
                        org.apache.hadoop.security.token.Token<ClientToAMTokenIdentifier> QBKJCRUMGO = ConverterUtils.convertFromYarn(YFGPNPHSMD, TOLIBRUJIQ);
                        XXULCSDDVN.addToken(QBKJCRUMGO);
                    }
                    ClientServiceDelegate.RQKQGWYZTW.debug("Connecting to " + TOLIBRUJIQ);
                    final InetSocketAddress ZIKXUSTFMJ = TOLIBRUJIQ;
                    XRJEPRAZGV = XXULCSDDVN.doAs(new PrivilegedExceptionAction<MRClientProtocol>() {
                        @Override
                        public MRClientProtocol run() throws IOException {
                            return instantiateAMProxy(ZIKXUSTFMJ);
                        }
                    });
                } else {
                    if (!DLSYIUGOBS) {
                        ClientServiceDelegate.RQKQGWYZTW.info(("Network ACL closed to AM for job " + WWUOXROLNF) + ". Not going to try to reach the AM.");
                        DLSYIUGOBS = true;
                    }
                    return getNotRunningJob(null, RUNNING);
                }
                return XRJEPRAZGV;
            } catch (IOException e) {
                // possibly the AM has crashed
                // there may be some time before AM is restarted
                // keep retrying by getting the address from RM
                ClientServiceDelegate.RQKQGWYZTW.info(("Could not connect to " + TOLIBRUJIQ) + ". Waiting for getting the latest AM address...");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e1) {
                    ClientServiceDelegate.RQKQGWYZTW.warn("getProxy() call interruped", e1);
                    throw new YarnRuntimeException(e1);
                }
                try {
                    FQLSFWDZRR = MNTIFEGNSA.getApplicationReport(FLDVIEALPG);
                } catch (YarnException e1) {
                    throw new IOException(e1);
                }
                if (FQLSFWDZRR == null) {
                    ClientServiceDelegate.RQKQGWYZTW.info(("Could not get Job info from RM for job " + WWUOXROLNF) + ". Redirecting to job history server.");
                    return checkAndGetHSProxy(null, RUNNING);
                }
            } catch (InterruptedException e) {
                ClientServiceDelegate.RQKQGWYZTW.warn("getProxy() call interruped", e);
                throw new YarnRuntimeException(e);
            } catch (YarnException e) {
                throw new IOException(e);
            }
        } 
        /**
         * we just want to return if its allocating, so that we don't
         * block on it. This is to be able to return job status
         * on an allocating Application.
         */
        String MYQTJMDWAD = FQLSFWDZRR.getUser();
        if (MYQTJMDWAD == null) {
            throw new IOException("User is not set in the application report");
        }
        if ((((FQLSFWDZRR.getYarnApplicationState() == YarnApplicationState.NEW) || (FQLSFWDZRR.getYarnApplicationState() == YarnApplicationState.NEW_SAVING)) || (FQLSFWDZRR.getYarnApplicationState() == YarnApplicationState.SUBMITTED)) || (FQLSFWDZRR.getYarnApplicationState() == YarnApplicationState.ACCEPTED)) {
            XRJEPRAZGV = null;
            return getNotRunningJob(FQLSFWDZRR, NEW);
        }
        if (FQLSFWDZRR.getYarnApplicationState() == YarnApplicationState.FAILED) {
            XRJEPRAZGV = null;
            return getNotRunningJob(FQLSFWDZRR, FAILED);
        }
        if (FQLSFWDZRR.getYarnApplicationState() == YarnApplicationState.KILLED) {
            XRJEPRAZGV = null;
            return getNotRunningJob(FQLSFWDZRR, KILLED);
        }
        // History server can serve a job only if application
        // succeeded.
        if (FQLSFWDZRR.getYarnApplicationState() == YarnApplicationState.FINISHED) {
            ClientServiceDelegate.RQKQGWYZTW.info(("Application state is completed. FinalApplicationStatus=" + FQLSFWDZRR.getFinalApplicationStatus().toString()) + ". Redirecting to job history server");
            XRJEPRAZGV = checkAndGetHSProxy(FQLSFWDZRR, SUCCEEDED);
        }
        return XRJEPRAZGV;
    }

    private MRClientProtocol checkAndGetHSProxy(ApplicationReport ACRGVYXJAD, JobState VYTMJCTZNH) {
        if (null == UIGKVHPMVR) {
            ClientServiceDelegate.RQKQGWYZTW.warn("Job History Server is not configured.");
            return getNotRunningJob(ACRGVYXJAD, VYTMJCTZNH);
        }
        return UIGKVHPMVR;
    }

    MRClientProtocol instantiateAMProxy(final InetSocketAddress INTZLIMQGY) throws IOException {
        ClientServiceDelegate.RQKQGWYZTW.trace("Connecting to ApplicationMaster at: " + INTZLIMQGY);
        YarnRPC FMZHGZGNGX = YarnRPC.create(WVNYUBORLL);
        MRClientProtocol NHSVZWDRPZ = ((MRClientProtocol) (FMZHGZGNGX.getProxy(MRClientProtocol.class, INTZLIMQGY, WVNYUBORLL)));
        VLNLDZXNNK.set(true);
        ClientServiceDelegate.RQKQGWYZTW.trace("Connected to ApplicationMaster at: " + INTZLIMQGY);
        return NHSVZWDRPZ;
    }

    private synchronized Object invoke(String SZXABLRTNE, Class HSZMBQKNIB, Object BUHCXHTVRA) throws IOException {
        Method DJBCLEYVBB = null;
        try {
            DJBCLEYVBB = MRClientProtocol.class.getMethod(SZXABLRTNE, HSZMBQKNIB);
        } catch (SecurityException e) {
            throw new YarnRuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new YarnRuntimeException("Method name mismatch", e);
        }
        CJESQUDMRI = this.WVNYUBORLL.getInt(MR_CLIENT_MAX_RETRIES, DEFAULT_MR_CLIENT_MAX_RETRIES);
        IOException RXAIBVOUMA = null;
        while (CJESQUDMRI > 0) {
            MRClientProtocol MTBJIYXORA = null;
            try {
                MTBJIYXORA = getProxy();
                return DJBCLEYVBB.invoke(MTBJIYXORA, BUHCXHTVRA);
            } catch (InvocationTargetException e) {
                // Will not throw out YarnException anymore
                ClientServiceDelegate.RQKQGWYZTW.debug(("Failed to contact AM/History for job " + WWUOXROLNF) + " retrying..", e.getTargetException());
                // Force reconnection by setting the proxy to null.
                XRJEPRAZGV = null;
                // HS/AMS shut down
                // if it's AM shut down, do not decrement maxClientRetry as we wait for
                // AM to be restarted.
                if (!VLNLDZXNNK.get()) {
                    CJESQUDMRI--;
                }
                VLNLDZXNNK.set(false);
                RXAIBVOUMA = new IOException(e.getTargetException());
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ie) {
                    ClientServiceDelegate.RQKQGWYZTW.warn("ClientServiceDelegate invoke call interrupted", ie);
                    throw new YarnRuntimeException(ie);
                }
            } catch (Exception e) {
                ClientServiceDelegate.RQKQGWYZTW.debug(("Failed to contact AM/History for job " + WWUOXROLNF) + "  Will retry..", e);
                // Force reconnection by setting the proxy to null.
                XRJEPRAZGV = null;
                // RM shutdown
                CJESQUDMRI--;
                RXAIBVOUMA = new IOException(e.getMessage());
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ie) {
                    ClientServiceDelegate.RQKQGWYZTW.warn("ClientServiceDelegate invoke call interrupted", ie);
                    throw new YarnRuntimeException(ie);
                }
            }
        } 
        throw RXAIBVOUMA;
    }

    // Only for testing
    @VisibleForTesting
    public int getMaxClientRetry() {
        return this.CJESQUDMRI;
    }

    public Counters getJobCounters(JobID WUKPOLTGSB) throws IOException, InterruptedException {
        JobId BKNVHCYMST = TypeConverter.toYarn(WUKPOLTGSB);
        GetCountersRequest TKQTIYYXRA = CTXMQZITLZ.newRecordInstance(GetCountersRequest.class);
        TKQTIYYXRA.setJobId(BKNVHCYMST);
        Counters TJJOZPBUXV = ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.GetCountersResponse) (invoke("getCounters", GetCountersRequest.class, TKQTIYYXRA))).getCounters();
        return TypeConverter.fromYarn(TJJOZPBUXV);
    }

    public TaskCompletionEvent[] getTaskCompletionEvents(JobID PLSUSIXVYF, int EEXHPOJQMO, int SFZNQYYSXD) throws IOException, InterruptedException {
        JobId SRHZMBZDQY = TypeConverter.toYarn(PLSUSIXVYF);
        GetTaskAttemptCompletionEventsRequest ANMXVGUXZS = CTXMQZITLZ.newRecordInstance(GetTaskAttemptCompletionEventsRequest.class);
        ANMXVGUXZS.setJobId(SRHZMBZDQY);
        ANMXVGUXZS.setFromEventId(EEXHPOJQMO);
        ANMXVGUXZS.setMaxEvents(SFZNQYYSXD);
        List<TaskAttemptCompletionEvent> MXDUPJVTPT = ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.GetTaskAttemptCompletionEventsResponse) (invoke("getTaskAttemptCompletionEvents", GetTaskAttemptCompletionEventsRequest.class, ANMXVGUXZS))).getCompletionEventList();
        return TypeConverter.fromYarn(MXDUPJVTPT.toArray(new TaskAttemptCompletionEvent[0]));
    }

    public String[] getTaskDiagnostics(TaskAttemptID YPKGINRLOU) throws IOException, InterruptedException {
        TaskAttemptId LXLXKLPOGX = TypeConverter.toYarn(YPKGINRLOU);
        GetDiagnosticsRequest MCRNNULTRH = CTXMQZITLZ.newRecordInstance(GetDiagnosticsRequest.class);
        MCRNNULTRH.setTaskAttemptId(LXLXKLPOGX);
        List<String> OSEWCAJATF = ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.GetDiagnosticsResponse) (invoke("getDiagnostics", GetDiagnosticsRequest.class, MCRNNULTRH))).getDiagnosticsList();
        String[] HXWACLHPVK = new String[OSEWCAJATF.size()];
        int RCJQBVLPPO = 0;
        for (String ZBFJTQSUDQ : OSEWCAJATF) {
            HXWACLHPVK[RCJQBVLPPO++] = ZBFJTQSUDQ.toString();
        }
        return HXWACLHPVK;
    }

    public JobStatus getJobStatus(JobID XOKDGZLGKX) throws IOException {
        JobId YTPCJFFRQU = TypeConverter.toYarn(XOKDGZLGKX);
        GetJobReportRequest OXZEUNHDPZ = CTXMQZITLZ.newRecordInstance(GetJobReportRequest.class);
        OXZEUNHDPZ.setJobId(YTPCJFFRQU);
        JobReport WOJIBHUYGU = ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.GetJobReportResponse) (invoke("getJobReport", GetJobReportRequest.class, OXZEUNHDPZ))).getJobReport();
        JobStatus IHEEZGKYJS = null;
        if (WOJIBHUYGU != null) {
            if (StringUtils.isEmpty(WOJIBHUYGU.getJobFile())) {
                String EBCPCUZOVT = MRApps.getJobFile(WVNYUBORLL, WOJIBHUYGU.getUser(), XOKDGZLGKX);
                WOJIBHUYGU.setJobFile(EBCPCUZOVT);
            }
            String HJCWXDTRPV = WOJIBHUYGU.getTrackingUrl();
            String GUEFVKHFMM = (StringUtils.isNotEmpty(HJCWXDTRPV)) ? HJCWXDTRPV : OUIHIGOLQM;
            IHEEZGKYJS = TypeConverter.fromYarn(WOJIBHUYGU, GUEFVKHFMM);
        }
        return IHEEZGKYJS;
    }

    public TaskReport[] getTaskReports(JobID XBKTRFPFAB, TaskType FMKLXNFVTS) throws IOException {
        JobId DCEHAEAGVP = TypeConverter.toYarn(XBKTRFPFAB);
        GetTaskReportsRequest WSABOCGJEJ = CTXMQZITLZ.newRecordInstance(GetTaskReportsRequest.class);
        WSABOCGJEJ.setJobId(DCEHAEAGVP);
        WSABOCGJEJ.setTaskType(TypeConverter.toYarn(FMKLXNFVTS));
        List<org.apache.hadoop.mapreduce.v2.api.records.TaskReport> JXWVARAWAO = ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.GetTaskReportsResponse) (invoke("getTaskReports", GetTaskReportsRequest.class, WSABOCGJEJ))).getTaskReportList();
        return TypeConverter.fromYarn(JXWVARAWAO).toArray(new TaskReport[0]);
    }

    public boolean killTask(TaskAttemptID TKPLCPKEZR, boolean PXIWRUTEKP) throws IOException {
        TaskAttemptId TXIUKGVBWJ = TypeConverter.toYarn(TKPLCPKEZR);
        if (PXIWRUTEKP) {
            FailTaskAttemptRequest DDJSABFJJT = CTXMQZITLZ.newRecordInstance(FailTaskAttemptRequest.class);
            DDJSABFJJT.setTaskAttemptId(TXIUKGVBWJ);
            invoke("failTaskAttempt", FailTaskAttemptRequest.class, DDJSABFJJT);
        } else {
            KillTaskAttemptRequest KUCMOAPKDU = CTXMQZITLZ.newRecordInstance(KillTaskAttemptRequest.class);
            KUCMOAPKDU.setTaskAttemptId(TXIUKGVBWJ);
            invoke("killTaskAttempt", KillTaskAttemptRequest.class, KUCMOAPKDU);
        }
        return true;
    }

    public boolean killJob(JobID WNEOJFTNWC) throws IOException {
        JobId NYICAZHAXT = TypeConverter.toYarn(WNEOJFTNWC);
        KillJobRequest JIJEOTNNXI = CTXMQZITLZ.newRecordInstance(KillJobRequest.class);
        JIJEOTNNXI.setJobId(NYICAZHAXT);
        invoke("killJob", KillJobRequest.class, JIJEOTNNXI);
        return true;
    }

    public LogParams getLogFilePath(JobID WCCYKAUGGC, TaskAttemptID FQNIEVJGZV) throws IOException {
        JobId CLHZHRWHSP = TypeConverter.toYarn(WCCYKAUGGC);
        GetJobReportRequest OPFPUEBMXL = CTXMQZITLZ.newRecordInstance(GetJobReportRequest.class);
        OPFPUEBMXL.setJobId(CLHZHRWHSP);
        JobReport HVSBJNRAZS = ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.GetJobReportResponse) (invoke("getJobReport", GetJobReportRequest.class, OPFPUEBMXL))).getJobReport();
        if (java.util.EnumSet.of(SUCCEEDED, FAILED, KILLED, JobState.ERROR).contains(HVSBJNRAZS.getJobState())) {
            if (FQNIEVJGZV != null) {
                GetTaskAttemptReportRequest WKEQRCJKHE = CTXMQZITLZ.newRecordInstance(GetTaskAttemptReportRequest.class);
                WKEQRCJKHE.setTaskAttemptId(TypeConverter.toYarn(FQNIEVJGZV));
                TaskAttemptReport ONMVLVIXPW = ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.GetTaskAttemptReportResponse) (invoke("getTaskAttemptReport", GetTaskAttemptReportRequest.class, WKEQRCJKHE))).getTaskAttemptReport();
                if ((ONMVLVIXPW.getContainerId() == null) || (ONMVLVIXPW.getNodeManagerHost() == null)) {
                    throw new IOException("Unable to get log information for task: " + FQNIEVJGZV);
                }
                return new LogParams(ONMVLVIXPW.getContainerId().toString(), ONMVLVIXPW.getContainerId().getApplicationAttemptId().getApplicationId().toString(), NodeId.newInstance(ONMVLVIXPW.getNodeManagerHost(), ONMVLVIXPW.getNodeManagerPort()).toString(), HVSBJNRAZS.getUser());
            } else {
                if ((HVSBJNRAZS.getAMInfos() == null) || (HVSBJNRAZS.getAMInfos().size() == 0)) {
                    throw new IOException("Unable to get log information for job: " + WCCYKAUGGC);
                }
                AMInfo HOLMCBQACU = HVSBJNRAZS.getAMInfos().get(HVSBJNRAZS.getAMInfos().size() - 1);
                return new LogParams(HOLMCBQACU.getContainerId().toString(), HOLMCBQACU.getAppAttemptId().getApplicationId().toString(), NodeId.newInstance(HOLMCBQACU.getNodeManagerHost(), HOLMCBQACU.getNodeManagerPort()).toString(), HVSBJNRAZS.getUser());
            }
        } else {
            throw new IOException("Cannot get log path for a in-progress job");
        }
    }
}