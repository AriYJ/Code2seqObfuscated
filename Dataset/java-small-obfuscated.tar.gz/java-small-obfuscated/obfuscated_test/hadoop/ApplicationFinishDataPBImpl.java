public class ApplicationFinishDataPBImpl extends ApplicationFinishData {
    ApplicationFinishDataProto TIAMJNBMXL = ApplicationFinishDataProto.getDefaultInstance();

    Builder ROEVVWBMOO = null;

    boolean DMFDOBFXXF = false;

    private ApplicationId DODJEAMSZW;

    public ApplicationFinishDataPBImpl() {
        ROEVVWBMOO = ApplicationFinishDataProto.newBuilder();
    }

    public ApplicationFinishDataPBImpl(ApplicationFinishDataProto ZOPRYDYLFA) {
        this.TIAMJNBMXL = ZOPRYDYLFA;
        DMFDOBFXXF = true;
    }

    @Override
    public ApplicationId getApplicationId() {
        if (this.DODJEAMSZW != null) {
            return this.DODJEAMSZW;
        }
        ApplicationFinishDataProtoOrBuilder BLAYSPPCLC = (DMFDOBFXXF) ? TIAMJNBMXL : ROEVVWBMOO;
        if (!BLAYSPPCLC.hasApplicationId()) {
            return null;
        }
        this.DODJEAMSZW = convertFromProtoFormat(BLAYSPPCLC.getApplicationId());
        return this.DODJEAMSZW;
    }

    @Override
    public void setApplicationId(ApplicationId EHYPMVZSZP) {
        maybeInitBuilder();
        if (EHYPMVZSZP == null) {
            ROEVVWBMOO.clearApplicationId();
        }
        this.DODJEAMSZW = EHYPMVZSZP;
    }

    @Override
    public long getFinishTime() {
        ApplicationFinishDataProtoOrBuilder VUYYMFMYOG = (DMFDOBFXXF) ? TIAMJNBMXL : ROEVVWBMOO;
        return VUYYMFMYOG.getFinishTime();
    }

    @Override
    public void setFinishTime(long UVQHBHEJUA) {
        maybeInitBuilder();
        ROEVVWBMOO.setFinishTime(UVQHBHEJUA);
    }

    @Override
    public String getDiagnosticsInfo() {
        ApplicationFinishDataProtoOrBuilder KPTNLBVEUL = (DMFDOBFXXF) ? TIAMJNBMXL : ROEVVWBMOO;
        if (!KPTNLBVEUL.hasDiagnosticsInfo()) {
            return null;
        }
        return KPTNLBVEUL.getDiagnosticsInfo();
    }

    @Override
    public void setDiagnosticsInfo(String YGUQSWDKSR) {
        maybeInitBuilder();
        if (YGUQSWDKSR == null) {
            ROEVVWBMOO.clearDiagnosticsInfo();
            return;
        }
        ROEVVWBMOO.setDiagnosticsInfo(YGUQSWDKSR);
    }

    @Override
    public FinalApplicationStatus getFinalApplicationStatus() {
        ApplicationFinishDataProtoOrBuilder MIXVIQUFVT = (DMFDOBFXXF) ? TIAMJNBMXL : ROEVVWBMOO;
        if (!MIXVIQUFVT.hasFinalApplicationStatus()) {
            return null;
        }
        return convertFromProtoFormat(MIXVIQUFVT.getFinalApplicationStatus());
    }

    @Override
    public void setFinalApplicationStatus(FinalApplicationStatus FNHCWYMWJN) {
        maybeInitBuilder();
        if (FNHCWYMWJN == null) {
            ROEVVWBMOO.clearFinalApplicationStatus();
            return;
        }
        ROEVVWBMOO.setFinalApplicationStatus(convertToProtoFormat(FNHCWYMWJN));
    }

    @Override
    public YarnApplicationState getYarnApplicationState() {
        ApplicationFinishDataProtoOrBuilder BURUPEIYQS = (DMFDOBFXXF) ? TIAMJNBMXL : ROEVVWBMOO;
        if (!BURUPEIYQS.hasYarnApplicationState()) {
            return null;
        }
        return convertFromProtoFormat(BURUPEIYQS.getYarnApplicationState());
    }

    @Override
    public void setYarnApplicationState(YarnApplicationState LQROIJKHYT) {
        maybeInitBuilder();
        if (LQROIJKHYT == null) {
            ROEVVWBMOO.clearYarnApplicationState();
            return;
        }
        ROEVVWBMOO.setYarnApplicationState(convertToProtoFormat(LQROIJKHYT));
    }

    public ApplicationFinishDataProto getProto() {
        mergeLocalToProto();
        TIAMJNBMXL = (DMFDOBFXXF) ? TIAMJNBMXL : ROEVVWBMOO.build();
        DMFDOBFXXF = true;
        return TIAMJNBMXL;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object ZCDFTCVHPG) {
        if (ZCDFTCVHPG == null)
            return false;

        if (ZCDFTCVHPG.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(ZCDFTCVHPG).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }

    private void mergeLocalToBuilder() {
        if ((this.DODJEAMSZW != null) && (!((ApplicationIdPBImpl) (this.DODJEAMSZW)).getProto().equals(ROEVVWBMOO.getApplicationId()))) {
            ROEVVWBMOO.setApplicationId(convertToProtoFormat(this.DODJEAMSZW));
        }
    }

    private void mergeLocalToProto() {
        if (DMFDOBFXXF) {
            maybeInitBuilder();
        }
        mergeLocalToBuilder();
        TIAMJNBMXL = ROEVVWBMOO.build();
        DMFDOBFXXF = true;
    }

    private void maybeInitBuilder() {
        if (DMFDOBFXXF || (ROEVVWBMOO == null)) {
            ROEVVWBMOO = ApplicationFinishDataProto.newBuilder(TIAMJNBMXL);
        }
        DMFDOBFXXF = false;
    }

    private ApplicationIdProto convertToProtoFormat(ApplicationId UXNAGISWRV) {
        return ((ApplicationIdPBImpl) (UXNAGISWRV)).getProto();
    }

    private ApplicationIdPBImpl convertFromProtoFormat(ApplicationIdProto IVFMVWOFHR) {
        return new ApplicationIdPBImpl(IVFMVWOFHR);
    }

    private FinalApplicationStatus convertFromProtoFormat(FinalApplicationStatusProto OVWLOZBWAF) {
        return ProtoUtils.convertFromProtoFormat(OVWLOZBWAF);
    }

    private FinalApplicationStatusProto convertToProtoFormat(FinalApplicationStatus KLQWNRYZQJ) {
        return ProtoUtils.convertToProtoFormat(KLQWNRYZQJ);
    }

    private YarnApplicationStateProto convertToProtoFormat(YarnApplicationState KAOLBFBGBF) {
        return ProtoUtils.convertToProtoFormat(KAOLBFBGBF);
    }

    private YarnApplicationState convertFromProtoFormat(YarnApplicationStateProto QGHNTAULCN) {
        return ProtoUtils.convertFromProtoFormat(QGHNTAULCN);
    }
}