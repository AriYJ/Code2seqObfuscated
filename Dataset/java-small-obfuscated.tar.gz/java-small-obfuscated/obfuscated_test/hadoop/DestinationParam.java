/**
 * Destination path parameter.
 */
public class DestinationParam extends StringParam {
    /**
     * Parameter name.
     */
    public static final String PMZXOAQIJO = "destination";

    /**
     * Default parameter value.
     */
    public static final String ZVXXEXCRNK = "";

    private static final Domain ODSFVWKVFH = new Domain(DestinationParam.PMZXOAQIJO, null);

    private static String validate(final String EUSDLIWNJP) {
        if ((EUSDLIWNJP == null) || EUSDLIWNJP.equals(DestinationParam.ZVXXEXCRNK)) {
            return null;
        }
        if (!EUSDLIWNJP.startsWith(SEPARATOR)) {
            throw new IllegalArgumentException(((("Invalid parameter value: " + DestinationParam.PMZXOAQIJO) + " = \"") + EUSDLIWNJP) + "\" is not an absolute path.");
        }
        return new org.apache.hadoop.fs.Path(EUSDLIWNJP).toUri().getPath();
    }

    /**
     * Constructor.
     *
     * @param str
     * 		a string representation of the parameter value.
     */
    public DestinationParam(final String JLKMXZCIDF) {
        super(DestinationParam.ODSFVWKVFH, DestinationParam.validate(JLKMXZCIDF));
    }

    @Override
    public String getName() {
        return DestinationParam.PMZXOAQIJO;
    }
}