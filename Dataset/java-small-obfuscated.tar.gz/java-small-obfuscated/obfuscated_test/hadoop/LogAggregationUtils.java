@Private
public class LogAggregationUtils {
    /**
     * Constructs the full filename for an application's log file per node.
     *
     * @param remoteRootLogDir
     * 		
     * @param appId
     * 		
     * @param user
     * 		
     * @param nodeId
     * 		
     * @param suffix
     * 		
     * @return the remote log file.
     */
    public static Path getRemoteNodeLogFileForApp(Path GENAPOQJIG, ApplicationId UPGXKGXCHO, String PSDSMLCNZC, NodeId XHXYPKATYX, String JPESLCDLLT) {
        return new Path(LogAggregationUtils.getRemoteAppLogDir(GENAPOQJIG, UPGXKGXCHO, PSDSMLCNZC, JPESLCDLLT), LogAggregationUtils.getNodeString(XHXYPKATYX));
    }

    /**
     * Gets the remote app log dir.
     *
     * @param remoteRootLogDir
     * 		
     * @param appId
     * 		
     * @param user
     * 		
     * @param suffix
     * 		
     * @return the remote application specific log dir.
     */
    public static Path getRemoteAppLogDir(Path RNUAEVHCXY, ApplicationId KFLWUUVOXN, String IDZYHFVOCK, String OTYGQAYGCS) {
        return new Path(LogAggregationUtils.getRemoteLogSuffixedDir(RNUAEVHCXY, IDZYHFVOCK, OTYGQAYGCS), KFLWUUVOXN.toString());
    }

    /**
     * Gets the remote suffixed log dir for the user.
     *
     * @param remoteRootLogDir
     * 		
     * @param user
     * 		
     * @param suffix
     * 		
     * @return the remote suffixed log dir.
     */
    public static Path getRemoteLogSuffixedDir(Path HFTVJOWYZV, String XRPCVZJFSE, String BOMGIMZTKT) {
        if ((BOMGIMZTKT == null) || BOMGIMZTKT.isEmpty()) {
            return LogAggregationUtils.getRemoteLogUserDir(HFTVJOWYZV, XRPCVZJFSE);
        }
        // TODO Maybe support suffix to be more than a single file.
        return new Path(LogAggregationUtils.getRemoteLogUserDir(HFTVJOWYZV, XRPCVZJFSE), BOMGIMZTKT);
    }

    // TODO Add a utility method to list available log files. Ignore the
    // temporary ones.
    /**
     * Gets the remote log user dir.
     *
     * @param remoteRootLogDir
     * 		
     * @param user
     * 		
     * @return the remote per user log dir.
     */
    public static Path getRemoteLogUserDir(Path KEBWIJIXKI, String YBLWIJHAGF) {
        return new Path(KEBWIJIXKI, YBLWIJHAGF);
    }

    /**
     * Returns the suffix component of the log dir.
     *
     * @param conf
     * 		
     * @return the suffix which will be appended to the user log dir.
     */
    public static String getRemoteNodeLogDirSuffix(Configuration WYCJSFDREK) {
        return WYCJSFDREK.get(NM_REMOTE_APP_LOG_DIR_SUFFIX, DEFAULT_NM_REMOTE_APP_LOG_DIR_SUFFIX);
    }

    /**
     * Converts a nodeId to a form used in the app log file name.
     *
     * @param nodeId
     * 		
     * @return the node string to be used to construct the file name.
     */
    private static String getNodeString(NodeId DPNSPSCWVI) {
        return DPNSPSCWVI.toString().replace(":", "_");
    }
}