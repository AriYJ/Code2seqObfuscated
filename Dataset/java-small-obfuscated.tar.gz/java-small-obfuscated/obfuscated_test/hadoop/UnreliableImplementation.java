class UnreliableImplementation implements UnreliableInterface {
    private int FTTGWAWAJK;

    private int TCKZOYPIBJ;

    private int KUOHHPZUSJ;

    private int OTKVAPRMGP;

    private int ZDUEUCDOHK;

    private int QWVXZHZSOG;

    private String CZPVSJVHRR;

    private UnreliableImplementation.TypeOfExceptionToFailWith JPNDQFDGBB;

    public static enum TypeOfExceptionToFailWith {

        UNRELIABLE_EXCEPTION,
        STANDBY_EXCEPTION,
        IO_EXCEPTION,
        REMOTE_EXCEPTION;}

    public UnreliableImplementation() {
        this(null);
    }

    public UnreliableImplementation(String IJMMQSPYPW) {
        this(IJMMQSPYPW, UnreliableImplementation.TypeOfExceptionToFailWith.UNRELIABLE_EXCEPTION);
    }

    public void setIdentifier(String TRHAFCFBKI) {
        this.CZPVSJVHRR = TRHAFCFBKI;
    }

    public UnreliableImplementation(String VKDOFGLLMF, UnreliableImplementation.TypeOfExceptionToFailWith RVVJOUYRWH) {
        this.CZPVSJVHRR = VKDOFGLLMF;
        this.JPNDQFDGBB = RVVJOUYRWH;
    }

    @Override
    public void alwaysSucceeds() {
        // do nothing
    }

    @Override
    public void alwaysFailsWithFatalException() throws FatalException {
        throw new FatalException();
    }

    @Override
    public void alwaysFailsWithRemoteFatalException() throws RemoteException {
        throw new RemoteException(FatalException.class.getName(), "Oops");
    }

    @Override
    public void failsOnceThenSucceeds() throws UnreliableException {
        if ((FTTGWAWAJK++) == 0) {
            throw new UnreliableException();
        }
    }

    @Override
    public boolean failsOnceThenSucceedsWithReturnValue() throws UnreliableException {
        if ((TCKZOYPIBJ++) == 0) {
            throw new UnreliableException();
        }
        return true;
    }

    @Override
    public void failsTenTimesThenSucceeds() throws UnreliableException {
        if ((KUOHHPZUSJ++) < 10) {
            throw new UnreliableException();
        }
    }

    @Override
    public String succeedsOnceThenFailsReturningString() throws IOException, UnreliableException, StandbyException {
        if ((OTKVAPRMGP++) < 1) {
            return CZPVSJVHRR;
        } else {
            UnreliableImplementation.throwAppropriateException(JPNDQFDGBB, CZPVSJVHRR);
            return null;
        }
    }

    @Override
    public String succeedsTenTimesThenFailsReturningString() throws IOException, UnreliableException, StandbyException {
        if ((QWVXZHZSOG++) < 10) {
            return CZPVSJVHRR;
        } else {
            UnreliableImplementation.throwAppropriateException(JPNDQFDGBB, CZPVSJVHRR);
            return null;
        }
    }

    @Override
    public String succeedsOnceThenFailsReturningStringIdempotent() throws IOException, UnreliableException, StandbyException {
        if ((ZDUEUCDOHK++) < 1) {
            return CZPVSJVHRR;
        } else {
            UnreliableImplementation.throwAppropriateException(JPNDQFDGBB, CZPVSJVHRR);
            return null;
        }
    }

    @Override
    public String failsIfIdentifierDoesntMatch(String AWRJQMAMWR) throws IOException, UnreliableException, StandbyException {
        if (this.CZPVSJVHRR.equals(AWRJQMAMWR)) {
            return AWRJQMAMWR;
        } else {
            String XWLVNTMWNF = ((("expected '" + this.CZPVSJVHRR) + "' but received '") + AWRJQMAMWR) + "'";
            UnreliableImplementation.throwAppropriateException(JPNDQFDGBB, XWLVNTMWNF);
            return null;
        }
    }

    @Override
    public void nonIdempotentVoidFailsIfIdentifierDoesntMatch(String COYWQIBVEP) throws IOException, UnreliableException, StandbyException {
        if (this.CZPVSJVHRR.equals(COYWQIBVEP)) {
            return;
        } else {
            String THDTWGFUQZ = ((("expected '" + this.CZPVSJVHRR) + "' but received '") + COYWQIBVEP) + "'";
            UnreliableImplementation.throwAppropriateException(JPNDQFDGBB, THDTWGFUQZ);
        }
    }

    @Override
    public String toString() {
        return ((getClass().getSimpleName() + "[") + CZPVSJVHRR) + "]";
    }

    private static void throwAppropriateException(UnreliableImplementation.TypeOfExceptionToFailWith JHWMQSRHCB, String RDVKSTURSU) throws IOException, UnreliableException, StandbyException {
        switch (JHWMQSRHCB) {
            case STANDBY_EXCEPTION :
                throw new StandbyException(RDVKSTURSU);
            case UNRELIABLE_EXCEPTION :
                throw new UnreliableException(RDVKSTURSU);
            case IO_EXCEPTION :
                throw new IOException(RDVKSTURSU);
            case REMOTE_EXCEPTION :
                throw new RemoteException(IOException.class.getName(), RDVKSTURSU);
            default :
                throw new RuntimeException(RDVKSTURSU);
        }
    }
}