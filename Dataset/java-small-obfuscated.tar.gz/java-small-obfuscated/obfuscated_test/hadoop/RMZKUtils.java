/**
 * Helper class that provides utility methods specific to ZK operations
 */
@InterfaceAudience.Private
public class RMZKUtils {
    private static final Log FWWIUHYIUB = LogFactory.getLog(RMZKUtils.class);

    /**
     * Utility method to fetch the ZK ACLs from the configuration
     */
    public static List<ACL> getZKAcls(Configuration HMDNBKOMCU) throws Exception {
        // Parse authentication from configuration.
        String PMNBBHLLLX = HMDNBKOMCU.get(RM_ZK_ACL, DEFAULT_RM_ZK_ACL);
        try {
            PMNBBHLLLX = ZKUtil.resolveConfIndirection(PMNBBHLLLX);
            return ZKUtil.parseACLs(PMNBBHLLLX);
        } catch (Exception e) {
            RMZKUtils.FWWIUHYIUB.error("Couldn't read ACLs based on " + YarnConfiguration.RM_ZK_ACL);
            throw e;
        }
    }

    /**
     * Utility method to fetch ZK auth info from the configuration
     */
    public static List<ZKUtil.ZKAuthInfo> getZKAuths(Configuration ZRLMHQGETN) throws Exception {
        String MHEFWOIURX = ZRLMHQGETN.get(RM_ZK_AUTH);
        try {
            MHEFWOIURX = ZKUtil.resolveConfIndirection(MHEFWOIURX);
            if (MHEFWOIURX != null) {
                return ZKUtil.parseAuth(MHEFWOIURX);
            } else {
                return Collections.emptyList();
            }
        } catch (Exception e) {
            RMZKUtils.FWWIUHYIUB.error("Couldn't read Auth based on " + YarnConfiguration.RM_ZK_AUTH);
            throw e;
        }
    }
}