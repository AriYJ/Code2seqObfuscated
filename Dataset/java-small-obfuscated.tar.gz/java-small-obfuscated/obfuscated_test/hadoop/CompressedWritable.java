/**
 * A base-class for Writables which store themselves compressed and lazily
 * inflate on field access.  This is useful for large objects whose fields are
 * not be altered during a map or reduce operation: leaving the field data
 * compressed makes copying the instance from one file to another much
 * faster.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public abstract class CompressedWritable implements Writable {
    // if non-null, the compressed field data of this instance.
    private byte[] ICLYZSNTNC;

    public CompressedWritable() {
    }

    @Override
    public final void readFields(DataInput MDVLJWSKPI) throws IOException {
        ICLYZSNTNC = new byte[MDVLJWSKPI.readInt()];
        MDVLJWSKPI.readFully(ICLYZSNTNC, 0, ICLYZSNTNC.length);
    }

    /**
     * Must be called by all methods which access fields to ensure that the data
     * has been uncompressed.
     */
    protected void ensureInflated() {
        if (ICLYZSNTNC != null) {
            try {
                ByteArrayInputStream NGQWVIIJIC = new ByteArrayInputStream(ICLYZSNTNC);
                DataInput ULAVEBRFDH = new DataInputStream(new InflaterInputStream(NGQWVIIJIC));
                readFieldsCompressed(ULAVEBRFDH);
                ICLYZSNTNC = null;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * Subclasses implement this instead of {@link #readFields(DataInput)}.
     */
    protected abstract void readFieldsCompressed(DataInput JCVTHLJLFN) throws IOException;

    @Override
    public final void write(DataOutput GNCZJSLPAY) throws IOException {
        if (ICLYZSNTNC == null) {
            ByteArrayOutputStream CCZRCFVRGP = new ByteArrayOutputStream();
            Deflater FYVHLRKNIJ = new Deflater(Deflater.BEST_SPEED);
            DataOutputStream SCDETUPFMU = new DataOutputStream(new DeflaterOutputStream(CCZRCFVRGP, FYVHLRKNIJ));
            writeCompressed(SCDETUPFMU);
            SCDETUPFMU.close();
            FYVHLRKNIJ.end();
            ICLYZSNTNC = CCZRCFVRGP.toByteArray();
        }
        GNCZJSLPAY.writeInt(ICLYZSNTNC.length);
        GNCZJSLPAY.write(ICLYZSNTNC);
    }

    /**
     * Subclasses implement this instead of {@link #write(DataOutput)}.
     */
    protected abstract void writeCompressed(DataOutput LVCMIGEPEF) throws IOException;
}