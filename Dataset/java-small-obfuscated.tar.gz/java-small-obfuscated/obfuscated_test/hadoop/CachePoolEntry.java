/**
 * Describes a Cache Pool entry.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class CachePoolEntry {
    private final CachePoolInfo IQZFXSDIDA;

    private final CachePoolStats VIPGKGQPEN;

    public CachePoolEntry(CachePoolInfo VCOHMRMMFS, CachePoolStats JVGSCTEQDW) {
        this.IQZFXSDIDA = VCOHMRMMFS;
        this.VIPGKGQPEN = JVGSCTEQDW;
    }

    public CachePoolInfo getInfo() {
        return IQZFXSDIDA;
    }

    public CachePoolStats getStats() {
        return VIPGKGQPEN;
    }
}