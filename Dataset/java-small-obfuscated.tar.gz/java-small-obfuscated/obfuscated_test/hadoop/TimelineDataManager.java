/**
 * The class wrap over the timeline store and the ACLs manager. It does some non
 * trivial manipulation of the timeline data before putting or after getting it
 * from the timeline store, and checks the user's access to it.
 */
public class TimelineDataManager {
    private static final Log JVCFNXYXIN = LogFactory.getLog(TimelineDataManager.class);

    private TimelineStore FWTOKBHGNZ;

    private TimelineACLsManager QFOZCTTQZG;

    public TimelineDataManager(TimelineStore ABVSZOPIOR, TimelineACLsManager QHSXRSVUOG) {
        this.FWTOKBHGNZ = ABVSZOPIOR;
        this.QFOZCTTQZG = QHSXRSVUOG;
    }

    /**
     * Get the timeline entities that the given user have access to. The meaning
     * of each argument has been documented with
     * {@link TimelineReader#getEntities}.
     *
     * @see TimelineReader#getEntities
     */
    public TimelineEntities getEntities(String QZDEAHAJFZ, NameValuePair MZIDFSHIKZ, Collection<NameValuePair> RYEFUUSHAG, Long FYOSJFXUZI, Long AWQHQXVSDN, String TCWARZGTNB, Long RPUNGANWBY, Long MAMFZFYJBT, EnumSet<Field> MDLQOMLCDF, UserGroupInformation TQQMTCGSBY) throws IOException, YarnException {
        TimelineEntities ASBUJEZKQX = null;
        boolean SAIYWZAXUW = TimelineDataManager.extendFields(MDLQOMLCDF);
        ASBUJEZKQX = FWTOKBHGNZ.getEntities(QZDEAHAJFZ, MAMFZFYJBT, FYOSJFXUZI, AWQHQXVSDN, TCWARZGTNB, RPUNGANWBY, MZIDFSHIKZ, RYEFUUSHAG, MDLQOMLCDF);
        if (ASBUJEZKQX != null) {
            Iterator<TimelineEntity> MFZKTFRLQY = ASBUJEZKQX.getEntities().iterator();
            while (MFZKTFRLQY.hasNext()) {
                TimelineEntity CQJJIDLBBJ = MFZKTFRLQY.next();
                try {
                    // check ACLs
                    if (!QFOZCTTQZG.checkAccess(TQQMTCGSBY, CQJJIDLBBJ)) {
                        MFZKTFRLQY.remove();
                    } else {
                        // clean up system data
                        if (SAIYWZAXUW) {
                            CQJJIDLBBJ.setPrimaryFilters(null);
                        } else {
                            TimelineDataManager.cleanupOwnerInfo(CQJJIDLBBJ);
                        }
                    }
                } catch (YarnException e) {
                    TimelineDataManager.JVCFNXYXIN.error((("Error when verifying access for user " + TQQMTCGSBY) + " on the events of the timeline entity ") + new EntityIdentifier(CQJJIDLBBJ.getEntityId(), CQJJIDLBBJ.getEntityType()), e);
                    MFZKTFRLQY.remove();
                }
            } 
        }
        if (ASBUJEZKQX == null) {
            return new TimelineEntities();
        }
        return ASBUJEZKQX;
    }

    /**
     * Get the single timeline entity that the given user has access to. The
     * meaning of each argument has been documented with
     * {@link TimelineReader#getEntity}.
     *
     * @see TimelineReader#getEntity
     */
    public TimelineEntity getEntity(String BOQDOWIMDE, String UFIPKVMFLG, EnumSet<Field> RCPAAJCXZN, UserGroupInformation XSPPZWTIMC) throws IOException, YarnException {
        TimelineEntity EUUXEOORNQ = null;
        boolean HVROXWCUGQ = TimelineDataManager.extendFields(RCPAAJCXZN);
        EUUXEOORNQ = FWTOKBHGNZ.getEntity(UFIPKVMFLG, BOQDOWIMDE, RCPAAJCXZN);
        if (EUUXEOORNQ != null) {
            // check ACLs
            if (!QFOZCTTQZG.checkAccess(XSPPZWTIMC, EUUXEOORNQ)) {
                EUUXEOORNQ = null;
            } else {
                // clean up the system data
                if (HVROXWCUGQ) {
                    EUUXEOORNQ.setPrimaryFilters(null);
                } else {
                    TimelineDataManager.cleanupOwnerInfo(EUUXEOORNQ);
                }
            }
        }
        return EUUXEOORNQ;
    }

    /**
     * Get the events whose entities the given user has access to. The meaning of
     * each argument has been documented with
     * {@link TimelineReader#getEntityTimelines}.
     *
     * @see TimelineReader#getEntityTimelines
     */
    public TimelineEvents getEvents(String PAHZPKTIEQ, SortedSet<String> WYOBVOLIFT, SortedSet<String> EBUIUJPIIR, Long PXNMLEXJZA, Long DKQHETFQUY, Long RIQNOHHDOH, UserGroupInformation GLPKCRUNZK) throws IOException, YarnException {
        TimelineEvents FJROXATMLX = null;
        FJROXATMLX = FWTOKBHGNZ.getEntityTimelines(PAHZPKTIEQ, WYOBVOLIFT, RIQNOHHDOH, PXNMLEXJZA, DKQHETFQUY, EBUIUJPIIR);
        if (FJROXATMLX != null) {
            Iterator<TimelineEvents.EventsOfOneEntity> JNWPQPERQJ = FJROXATMLX.getAllEvents().iterator();
            while (JNWPQPERQJ.hasNext()) {
                TimelineEvents.EventsOfOneEntity VQDYJMRKEV = JNWPQPERQJ.next();
                try {
                    TimelineEntity VOOUACCIWM = FWTOKBHGNZ.getEntity(VQDYJMRKEV.getEntityId(), VQDYJMRKEV.getEntityType(), EnumSet.of(PRIMARY_FILTERS));
                    // check ACLs
                    if (!QFOZCTTQZG.checkAccess(GLPKCRUNZK, VOOUACCIWM)) {
                        JNWPQPERQJ.remove();
                    }
                } catch (Exception e) {
                    TimelineDataManager.JVCFNXYXIN.error((("Error when verifying access for user " + GLPKCRUNZK) + " on the events of the timeline entity ") + new EntityIdentifier(VQDYJMRKEV.getEntityId(), VQDYJMRKEV.getEntityType()), e);
                    JNWPQPERQJ.remove();
                }
            } 
        }
        if (FJROXATMLX == null) {
            return new TimelineEvents();
        }
        return FJROXATMLX;
    }

    /**
     * Store the timeline entities into the store and set the owner of them to the
     * given user.
     */
    public TimelinePutResponse postEntities(TimelineEntities WDUZODEWVT, UserGroupInformation VZOMEFUWYM) throws IOException, YarnException {
        if (WDUZODEWVT == null) {
            return new TimelinePutResponse();
        }
        List<EntityIdentifier> OCDEHBNPLZ = new ArrayList<EntityIdentifier>();
        TimelineEntities EKGRMBJFSF = new TimelineEntities();
        List<TimelinePutResponse.TimelinePutError> NIFAAXZVSS = new ArrayList<TimelinePutResponse.TimelinePutError>();
        for (TimelineEntity DARIXUOVEQ : WDUZODEWVT.getEntities()) {
            EntityIdentifier EOHBMBDIEJ = new EntityIdentifier(DARIXUOVEQ.getEntityId(), DARIXUOVEQ.getEntityType());
            // check if there is existing entity
            TimelineEntity HUGBFNKQIB = null;
            try {
                HUGBFNKQIB = FWTOKBHGNZ.getEntity(EOHBMBDIEJ.getId(), EOHBMBDIEJ.getType(), EnumSet.of(PRIMARY_FILTERS));
                if ((HUGBFNKQIB != null) && (!QFOZCTTQZG.checkAccess(VZOMEFUWYM, HUGBFNKQIB))) {
                    throw new YarnException(((("The timeline entity " + EOHBMBDIEJ) + " was not put by ") + VZOMEFUWYM) + " before");
                }
            } catch (Exception e) {
                // Skip the entity which already exists and was put by others
                TimelineDataManager.JVCFNXYXIN.error((("Skip the timeline entity: " + EOHBMBDIEJ) + ", because ") + e.getMessage());
                TimelinePutResponse.TimelinePutError DJDDIXHYUY = new TimelinePutResponse.TimelinePutError();
                DJDDIXHYUY.setEntityId(EOHBMBDIEJ.getId());
                DJDDIXHYUY.setEntityType(EOHBMBDIEJ.getType());
                DJDDIXHYUY.setErrorCode(ACCESS_DENIED);
                NIFAAXZVSS.add(DJDDIXHYUY);
                continue;
            }
            // inject owner information for the access check if this is the first
            // time to post the entity, in case it's the admin who is updating
            // the timeline data.
            try {
                if (HUGBFNKQIB == null) {
                    TimelineDataManager.injectOwnerInfo(DARIXUOVEQ, VZOMEFUWYM.getShortUserName());
                }
            } catch (YarnException e) {
                // Skip the entity which messes up the primary filter and record the
                // error
                TimelineDataManager.JVCFNXYXIN.error((("Skip the timeline entity: " + EOHBMBDIEJ) + ", because ") + e.getMessage());
                TimelinePutResponse.TimelinePutError JSVENGOAUG = new TimelinePutResponse.TimelinePutError();
                JSVENGOAUG.setEntityId(EOHBMBDIEJ.getId());
                JSVENGOAUG.setEntityType(EOHBMBDIEJ.getType());
                JSVENGOAUG.setErrorCode(SYSTEM_FILTER_CONFLICT);
                NIFAAXZVSS.add(JSVENGOAUG);
                continue;
            }
            OCDEHBNPLZ.add(EOHBMBDIEJ);
            EKGRMBJFSF.addEntity(DARIXUOVEQ);
            if (TimelineDataManager.JVCFNXYXIN.isDebugEnabled()) {
                TimelineDataManager.JVCFNXYXIN.debug((("Storing the entity " + EOHBMBDIEJ) + ", JSON-style content: ") + TimelineUtils.dumpTimelineRecordtoJSON(DARIXUOVEQ));
            }
        }
        if (TimelineDataManager.JVCFNXYXIN.isDebugEnabled()) {
            TimelineDataManager.JVCFNXYXIN.debug("Storing entities: " + CSV_JOINER.join(OCDEHBNPLZ));
        }
        TimelinePutResponse XXPSESBDKR = FWTOKBHGNZ.put(EKGRMBJFSF);
        // add the errors of timeline system filter key conflict
        XXPSESBDKR.addErrors(NIFAAXZVSS);
        return XXPSESBDKR;
    }

    private static boolean extendFields(EnumSet<Field> YHKSBLKFXF) {
        boolean KEGOWHQKZF = false;
        if ((YHKSBLKFXF != null) && (!YHKSBLKFXF.contains(PRIMARY_FILTERS))) {
            YHKSBLKFXF.add(PRIMARY_FILTERS);
            KEGOWHQKZF = true;
        }
        return KEGOWHQKZF;
    }

    private static void injectOwnerInfo(TimelineEntity NMCNEFTYIZ, String OAQJPGRHZY) throws YarnException {
        if ((NMCNEFTYIZ.getPrimaryFilters() != null) && NMCNEFTYIZ.getPrimaryFilters().containsKey(ENTITY_OWNER.toString())) {
            throw new YarnException("User should not use the timeline system filter key: " + SystemFilter.ENTITY_OWNER);
        }
        NMCNEFTYIZ.addPrimaryFilter(ENTITY_OWNER.toString(), OAQJPGRHZY);
    }

    private static void cleanupOwnerInfo(TimelineEntity BAXUKYNGCW) {
        if (BAXUKYNGCW.getPrimaryFilters() != null) {
            BAXUKYNGCW.getPrimaryFilters().remove(ENTITY_OWNER.toString());
        }
    }
}