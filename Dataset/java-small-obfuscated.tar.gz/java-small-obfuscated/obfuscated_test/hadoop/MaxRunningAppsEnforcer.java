/**
 * Handles tracking and enforcement for user and queue maxRunningApps
 * constraints
 */
public class MaxRunningAppsEnforcer {
    private static final Log SXEAQQOLSO = LogFactory.getLog(FairScheduler.class);

    private final FairScheduler HCIMLAFCPI;

    // Tracks the number of running applications by user.
    private final Map<String, Integer> NQJMUASDPS;

    @VisibleForTesting
    final ListMultimap<String, FSAppAttempt> XZNGSGTVFS;

    public MaxRunningAppsEnforcer(FairScheduler GQRWNPAXEF) {
        this.HCIMLAFCPI = GQRWNPAXEF;
        this.NQJMUASDPS = new HashMap<String, Integer>();
        this.XZNGSGTVFS = ArrayListMultimap.create();
    }

    /**
     * Checks whether making the application runnable would exceed any
     * maxRunningApps limits.
     */
    public boolean canAppBeRunnable(FSQueue JUFAVNSKOI, String QYKADSNHHH) {
        AllocationConfiguration FRHMWSZSYJ = HCIMLAFCPI.getAllocationConfiguration();
        Integer WHNEESFIEU = NQJMUASDPS.get(QYKADSNHHH);
        if (WHNEESFIEU == null) {
            WHNEESFIEU = 0;
        }
        if (WHNEESFIEU >= FRHMWSZSYJ.getUserMaxApps(QYKADSNHHH)) {
            return false;
        }
        // Check queue and all parent queues
        while (JUFAVNSKOI != null) {
            int CFNLFDQDOF = FRHMWSZSYJ.getQueueMaxApps(JUFAVNSKOI.getName());
            if (JUFAVNSKOI.getNumRunnableApps() >= CFNLFDQDOF) {
                return false;
            }
            JUFAVNSKOI = JUFAVNSKOI.getParent();
        } 
        return true;
    }

    /**
     * Tracks the given new runnable app for purposes of maintaining max running
     * app limits.
     */
    public void trackRunnableApp(FSAppAttempt PWDNZAMKCX) {
        String SHBZGWJMYX = PWDNZAMKCX.getUser();
        FSLeafQueue GIWRANWOTQ = PWDNZAMKCX.getQueue();
        // Increment running counts for all parent queues
        FSParentQueue QYVDPJFDYZ = GIWRANWOTQ.getParent();
        while (QYVDPJFDYZ != null) {
            QYVDPJFDYZ.incrementRunnableApps();
            QYVDPJFDYZ = QYVDPJFDYZ.getParent();
        } 
        Integer ZTLHSZYPIZ = NQJMUASDPS.get(SHBZGWJMYX);
        NQJMUASDPS.put(SHBZGWJMYX, (ZTLHSZYPIZ == null ? 0 : ZTLHSZYPIZ) + 1);
    }

    /**
     * Tracks the given new non runnable app so that it can be made runnable when
     * it would not violate max running app limits.
     */
    public void trackNonRunnableApp(FSAppAttempt BCRBFRQWHZ) {
        String LPLRPFGQXM = BCRBFRQWHZ.getUser();
        XZNGSGTVFS.put(LPLRPFGQXM, BCRBFRQWHZ);
    }

    /**
     * Checks to see whether any other applications runnable now that the given
     * application has been removed from the given queue.  And makes them so.
     *
     * Runs in O(n log(n)) where n is the number of queues that are under the
     * highest queue that went from having no slack to having slack.
     */
    public void updateRunnabilityOnAppRemoval(FSAppAttempt XQDRMILBPW, FSLeafQueue WQYRSMRIDT) {
        AllocationConfiguration UPPMGWCSNT = HCIMLAFCPI.getAllocationConfiguration();
        // childqueueX might have no pending apps itself, but if a queue higher up
        // in the hierarchy parentqueueY has a maxRunningApps set, an app completion
        // in childqueueX could allow an app in some other distant child of
        // parentqueueY to become runnable.
        // An app removal will only possibly allow another app to become runnable if
        // the queue was already at its max before the removal.
        // Thus we find the ancestor queue highest in the tree for which the app
        // that was at its maxRunningApps before the removal.
        FSQueue OODGOSQPRO = (WQYRSMRIDT.getNumRunnableApps() == (UPPMGWCSNT.getQueueMaxApps(WQYRSMRIDT.getName()) - 1)) ? WQYRSMRIDT : null;
        FSParentQueue UJWWQSAQJH = WQYRSMRIDT.getParent();
        while (UJWWQSAQJH != null) {
            if (UJWWQSAQJH.getNumRunnableApps() == (UPPMGWCSNT.getQueueMaxApps(UJWWQSAQJH.getName()) - 1)) {
                OODGOSQPRO = UJWWQSAQJH;
            }
            UJWWQSAQJH = UJWWQSAQJH.getParent();
        } 
        List<List<FSAppAttempt>> PBBSPKVOAC = new ArrayList<List<FSAppAttempt>>();
        // Compile lists of apps which may now be runnable
        // We gather lists instead of building a set of all non-runnable apps so
        // that this whole operation can be O(number of queues) instead of
        // O(number of apps)
        if (OODGOSQPRO != null) {
            gatherPossiblyRunnableAppLists(OODGOSQPRO, PBBSPKVOAC);
        }
        String WBGJMJNFXU = XQDRMILBPW.getUser();
        Integer XNNHOOXAFR = NQJMUASDPS.get(WBGJMJNFXU);
        if (XNNHOOXAFR == null) {
            XNNHOOXAFR = 0;
        }
        if (XNNHOOXAFR == (UPPMGWCSNT.getUserMaxApps(WBGJMJNFXU) - 1)) {
            List<FSAppAttempt> HDWDKEEBEE = XZNGSGTVFS.get(WBGJMJNFXU);
            if (HDWDKEEBEE != null) {
                PBBSPKVOAC.add(HDWDKEEBEE);
            }
        }
        // Scan through and check whether this means that any apps are now runnable
        Iterator<FSAppAttempt> GQHLZMVOJT = new MaxRunningAppsEnforcer.MultiListStartTimeIterator(PBBSPKVOAC);
        FSAppAttempt XRGKQVBTCV = null;
        List<FSAppAttempt> UJPXIJYKZT = new ArrayList<FSAppAttempt>();
        while (GQHLZMVOJT.hasNext()) {
            FSAppAttempt UYEAVEXWLS = GQHLZMVOJT.next();
            if (UYEAVEXWLS == XRGKQVBTCV) {
                continue;
            }
            if (canAppBeRunnable(UYEAVEXWLS.getQueue(), UYEAVEXWLS.getUser())) {
                trackRunnableApp(UYEAVEXWLS);
                FSAppAttempt JNSJUUSIEM = UYEAVEXWLS;
                UYEAVEXWLS.getQueue().getRunnableAppSchedulables().add(JNSJUUSIEM);
                UJPXIJYKZT.add(JNSJUUSIEM);
                // No more than one app per list will be able to be made runnable, so
                // we can stop looking after we've found that many
                if (UJPXIJYKZT.size() >= PBBSPKVOAC.size()) {
                    break;
                }
            }
            XRGKQVBTCV = UYEAVEXWLS;
        } 
        // We remove the apps from their pending lists afterwards so that we don't
        // pull them out from under the iterator.  If they are not in these lists
        // in the first place, there is a bug.
        for (FSAppAttempt HKOGGMZJWC : UJPXIJYKZT) {
            if (!HKOGGMZJWC.getQueue().getNonRunnableAppSchedulables().remove(HKOGGMZJWC)) {
                MaxRunningAppsEnforcer.SXEAQQOLSO.error((("Can't make app runnable that does not already exist in queue" + " as non-runnable: ") + HKOGGMZJWC) + ". This should never happen.");
            }
            if (!XZNGSGTVFS.remove(HKOGGMZJWC.getUser(), HKOGGMZJWC)) {
                MaxRunningAppsEnforcer.SXEAQQOLSO.error((("Waiting app " + HKOGGMZJWC) + " expected to be in ") + "usersNonRunnableApps, but was not. This should never happen.");
            }
        }
    }

    /**
     * Updates the relevant tracking variables after a runnable app with the given
     * queue and user has been removed.
     */
    public void untrackRunnableApp(FSAppAttempt TTENPKOQBK) {
        // Update usersRunnableApps
        String NJUPHKXAEX = TTENPKOQBK.getUser();
        int ILEACZMQIC = NQJMUASDPS.get(NJUPHKXAEX) - 1;
        if (ILEACZMQIC == 0) {
            NQJMUASDPS.remove(NJUPHKXAEX);
        } else {
            NQJMUASDPS.put(NJUPHKXAEX, ILEACZMQIC);
        }
        // Update runnable app bookkeeping for queues
        FSLeafQueue KKQQILOSRP = TTENPKOQBK.getQueue();
        FSParentQueue WRQWLPWEDH = KKQQILOSRP.getParent();
        while (WRQWLPWEDH != null) {
            WRQWLPWEDH.decrementRunnableApps();
            WRQWLPWEDH = WRQWLPWEDH.getParent();
        } 
    }

    /**
     * Stops tracking the given non-runnable app
     */
    public void untrackNonRunnableApp(FSAppAttempt TFQKFDIPPA) {
        XZNGSGTVFS.remove(TFQKFDIPPA.getUser(), TFQKFDIPPA);
    }

    /**
     * Traverses the queue hierarchy under the given queue to gather all lists
     * of non-runnable applications.
     */
    private void gatherPossiblyRunnableAppLists(FSQueue QQKWTCVCGD, List<List<FSAppAttempt>> VOWDKIDUPO) {
        if (QQKWTCVCGD.getNumRunnableApps() < HCIMLAFCPI.getAllocationConfiguration().getQueueMaxApps(QQKWTCVCGD.getName())) {
            if (QQKWTCVCGD instanceof FSLeafQueue) {
                VOWDKIDUPO.add(((FSLeafQueue) (QQKWTCVCGD)).getNonRunnableAppSchedulables());
            } else {
                for (FSQueue CZTSCUGPDN : QQKWTCVCGD.getChildQueues()) {
                    gatherPossiblyRunnableAppLists(CZTSCUGPDN, VOWDKIDUPO);
                }
            }
        }
    }

    /**
     * Takes a list of lists, each of which is ordered by start time, and returns
     * their elements in order of start time.
     *
     * We maintain positions in each of the lists.  Each next() call advances
     * the position in one of the lists.  We maintain a heap that orders lists
     * by the start time of the app in the current position in that list.
     * This allows us to pick which list to advance in O(log(num lists)) instead
     * of O(num lists) time.
     */
    static class MultiListStartTimeIterator implements Iterator<FSAppAttempt> {
        private List<FSAppAttempt>[] KDSCZIHKVY;

        private int[] FYSSGRTFSB;

        private PriorityQueue<MaxRunningAppsEnforcer.MultiListStartTimeIterator.IndexAndTime> SKJGZFVEFK;

        @SuppressWarnings("unchecked")
        public MultiListStartTimeIterator(List<List<FSAppAttempt>> appListList) {
            KDSCZIHKVY = appListList.toArray(new List[appListList.size()]);
            curPositionsInAppLists = new int[appLists.length];
            appListsByCurStartTime = new PriorityQueue<org.apache.hadoop.yarn.server.resourcemanager.scheduler.fair.IndexAndTime>();
            for (int i = 0; i < appLists.length; i++) {
                long time = (appLists[i].isEmpty()) ? Long.MAX_VALUE : appLists[i].get(0).getStartTime();
                appListsByCurStartTime.add(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.fair.IndexAndTime(i, time));
            }
        }

        @Override
        public boolean hasNext() {
            return (!SKJGZFVEFK.isEmpty()) && (SKJGZFVEFK.peek().HMRPXKXWKV != Long.MAX_VALUE);
        }

        @Override
        public FSAppAttempt next() {
            MaxRunningAppsEnforcer.MultiListStartTimeIterator.IndexAndTime indexAndTime = SKJGZFVEFK.remove();
            int nextListIndex = indexAndTime.QNHHHIRZMT;
            FSAppAttempt next = KDSCZIHKVY[nextListIndex].get(curPositionsInAppLists[nextListIndex]);
            curPositionsInAppLists[nextListIndex]++;
            if (curPositionsInAppLists[nextListIndex] < appLists[nextListIndex].size()) {
                indexAndTime.time = appLists[nextListIndex].get(curPositionsInAppLists[nextListIndex]).getStartTime();
            } else {
                indexAndTime.time = Long.MAX_VALUE;
            }
            appListsByCurStartTime.add(indexAndTime);
            return next;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Remove not supported");
        }

        private static class IndexAndTime implements Comparable<MaxRunningAppsEnforcer.MultiListStartTimeIterator.IndexAndTime> {
            public int QNHHHIRZMT;

            public long HMRPXKXWKV;

            public IndexAndTime(int index, long time) {
                this.QNHHHIRZMT = index;
                this.HMRPXKXWKV = time;
            }

            @Override
            public int compareTo(MaxRunningAppsEnforcer.MultiListStartTimeIterator.IndexAndTime o) {
                return HMRPXKXWKV < o.HMRPXKXWKV ? -1 : HMRPXKXWKV > o.HMRPXKXWKV ? 1 : 0;
            }

            @Override
            public boolean equals(Object o) {
                if (!(o instanceof MaxRunningAppsEnforcer.MultiListStartTimeIterator.IndexAndTime)) {
                    return false;
                }
                MaxRunningAppsEnforcer.MultiListStartTimeIterator.IndexAndTime other = ((MaxRunningAppsEnforcer.MultiListStartTimeIterator.IndexAndTime) (o));
                return other.HMRPXKXWKV == HMRPXKXWKV;
            }

            @Override
            public int hashCode() {
                return ((int) (HMRPXKXWKV));
            }
        }
    }
}