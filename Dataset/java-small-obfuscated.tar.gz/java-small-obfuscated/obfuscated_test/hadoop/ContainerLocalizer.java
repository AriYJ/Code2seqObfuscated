public class ContainerLocalizer {
    static final Log GKLZCHJFCS = LogFactory.getLog(ContainerLocalizer.class);

    public static final String PFFBKQUTLA = "filecache";

    public static final String DGSTDEHUOO = "appcache";

    public static final String LALVOKECDG = "usercache";

    public static final String SRKXYYHHXZ = "output";

    public static final String KSJKDADRWQ = "%s.tokens";

    public static final String QIQMYXWVRH = "work";

    private static final String UYRFNBDHME = "%s.app.cache.dirs";

    private static final String GOZPJRDXCF = "%s.user.cache.dirs";

    private static final FsPermission XBOVJWLXGE = new FsPermission(((short) (0710)));

    private final String UIOINGPWON;

    private final String FOZWGMAJGR;

    private final List<Path> FJBDGQVLGC;

    private final String RGWHCZDLBK;

    private final FileContext BRKEJCQGYI;

    private final Configuration GDKRRUNRJU;

    private final RecordFactory KBEYYSDNEI;

    private final Map<LocalResource, Future<Path>> ZLSMFOJCMQ;

    private final String YAQLQEHLZV;

    public ContainerLocalizer(FileContext RPEFWRZGCL, String QQSRDPHUWN, String SIQHMVATUU, String XRTDNNEYAJ, List<Path> HCYBHHAEUD, RecordFactory RITFKYPEOB) throws IOException {
        if (null == QQSRDPHUWN) {
            throw new IOException("Cannot initialize for null user");
        }
        if (null == XRTDNNEYAJ) {
            throw new IOException("Cannot initialize for null containerId");
        }
        this.BRKEJCQGYI = RPEFWRZGCL;
        this.UIOINGPWON = QQSRDPHUWN;
        this.FOZWGMAJGR = SIQHMVATUU;
        this.FJBDGQVLGC = HCYBHHAEUD;
        this.RGWHCZDLBK = XRTDNNEYAJ;
        this.KBEYYSDNEI = RITFKYPEOB;
        this.GDKRRUNRJU = new Configuration();
        this.YAQLQEHLZV = String.format(ContainerLocalizer.UYRFNBDHME, SIQHMVATUU);
        this.ZLSMFOJCMQ = new HashMap<LocalResource, Future<Path>>();
    }

    LocalizationProtocol getProxy(final InetSocketAddress JJLPMOUEYI) {
        YarnRPC FEJMZFYLMI = YarnRPC.create(GDKRRUNRJU);
        return ((LocalizationProtocol) (FEJMZFYLMI.getProxy(LocalizationProtocol.class, JJLPMOUEYI, GDKRRUNRJU)));
    }

    @SuppressWarnings("deprecation")
    public int runLocalization(final InetSocketAddress BYHBPKNLAI) throws IOException, InterruptedException {
        // load credentials
        ContainerLocalizer.initDirs(GDKRRUNRJU, UIOINGPWON, FOZWGMAJGR, BRKEJCQGYI, FJBDGQVLGC);
        final Credentials WLOACOAZQA = new Credentials();
        DataInputStream TFWNEQXFSF = null;
        try {
            // assume credentials in cwd
            // TODO: Fix
            Path CFBPEAQGOJ = new Path(String.format(ContainerLocalizer.KSJKDADRWQ, RGWHCZDLBK));
            TFWNEQXFSF = BRKEJCQGYI.open(CFBPEAQGOJ);
            WLOACOAZQA.readTokenStorageStream(TFWNEQXFSF);
            // Explicitly deleting token file.
            BRKEJCQGYI.delete(CFBPEAQGOJ, false);
        } finally {
            if (TFWNEQXFSF != null) {
                TFWNEQXFSF.close();
            }
        }
        // create localizer context
        UserGroupInformation YRMJCULVBE = UserGroupInformation.createRemoteUser(UIOINGPWON);
        YRMJCULVBE.addToken(WLOACOAZQA.getToken(KIND));
        final LocalizationProtocol GQWTEOZJWX = YRMJCULVBE.doAs(new PrivilegedAction<LocalizationProtocol>() {
            @Override
            public LocalizationProtocol run() {
                return getProxy(BYHBPKNLAI);
            }
        });
        // create user context
        UserGroupInformation WPBANROMSI = UserGroupInformation.createRemoteUser(UIOINGPWON);
        for (Token<? extends TokenIdentifier> HMJCVIYONE : WLOACOAZQA.getAllTokens()) {
            WPBANROMSI.addToken(HMJCVIYONE);
        }
        ExecutorService GSQPVYIHCW = null;
        try {
            GSQPVYIHCW = createDownloadThreadPool();
            CompletionService<Path> MDLFHJIHJV = createCompletionService(GSQPVYIHCW);
            localizeFiles(GQWTEOZJWX, MDLFHJIHJV, WPBANROMSI);
            return 0;
        } catch (Throwable e) {
            // Print traces to stdout so that they can be logged by the NM address
            // space.
            e.printStackTrace(System.out);
            return -1;
        } finally {
            try {
                if (GSQPVYIHCW != null) {
                    GSQPVYIHCW.shutdownNow();
                }
                LocalDirAllocator.removeContext(YAQLQEHLZV);
            } finally {
                closeFileSystems(WPBANROMSI);
            }
        }
    }

    ExecutorService createDownloadThreadPool() {
        return Executors.newSingleThreadExecutor(new com.google.common.util.concurrent.ThreadFactoryBuilder().setNameFormat("ContainerLocalizer Downloader").build());
    }

    CompletionService<Path> createCompletionService(ExecutorService OKCJNICFMH) {
        return new ExecutorCompletionService<Path>(OKCJNICFMH);
    }

    Callable<Path> download(Path VVEPTCRESL, LocalResource AIDUQFUBRX, UserGroupInformation LTZMQHGMOF) throws IOException {
        DiskChecker.checkDir(new File(VVEPTCRESL.toUri().getRawPath()));
        return new org.apache.hadoop.yarn.util.FSDownload(BRKEJCQGYI, LTZMQHGMOF, GDKRRUNRJU, VVEPTCRESL, AIDUQFUBRX);
    }

    static long getEstimatedSize(LocalResource ZICHDHSXYA) {
        if (ZICHDHSXYA.getSize() < 0) {
            return -1;
        }
        switch (ZICHDHSXYA.getType()) {
            case ARCHIVE :
            case PATTERN :
                return 5 * ZICHDHSXYA.getSize();
            case FILE :
            default :
                return ZICHDHSXYA.getSize();
        }
    }

    void sleep(int YGALLZZPIQ) throws InterruptedException {
        TimeUnit.SECONDS.sleep(YGALLZZPIQ);
    }

    protected void closeFileSystems(UserGroupInformation FMHDPPBXYN) {
        try {
            FileSystem.closeAllForUGI(FMHDPPBXYN);
        } catch (IOException e) {
            ContainerLocalizer.GKLZCHJFCS.warn("Failed to close filesystems: ", e);
        }
    }

    protected void localizeFiles(LocalizationProtocol USMAWFZIAU, CompletionService<Path> UMAMDBIKYU, UserGroupInformation EITZYMPJJE) throws IOException {
        while (true) {
            try {
                LocalizerStatus RURVFLEHCT = createStatus();
                LocalizerHeartbeatResponse JYALYSTMGB = USMAWFZIAU.heartbeat(RURVFLEHCT);
                switch (JYALYSTMGB.getLocalizerAction()) {
                    case LIVE :
                        List<ResourceLocalizationSpec> BPTTZUWRWT = JYALYSTMGB.getResourceSpecs();
                        for (ResourceLocalizationSpec PQEYNWWIGN : BPTTZUWRWT) {
                            if (!ZLSMFOJCMQ.containsKey(PQEYNWWIGN.getResource())) {
                                ZLSMFOJCMQ.put(PQEYNWWIGN.getResource(), UMAMDBIKYU.submit(download(new Path(PQEYNWWIGN.getDestinationDirectory().getFile()), PQEYNWWIGN.getResource(), EITZYMPJJE)));
                            }
                        }
                        break;
                    case DIE :
                        // killall running localizations
                        for (Future<Path> XKLJGECZLH : ZLSMFOJCMQ.values()) {
                            XKLJGECZLH.cancel(true);
                        }
                        RURVFLEHCT = createStatus();
                        // ignore response
                        try {
                            USMAWFZIAU.heartbeat(RURVFLEHCT);
                        } catch (YarnException e) {
                        }
                        return;
                }
                UMAMDBIKYU.poll(1000, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                return;
            } catch (YarnException e) {
                // TODO cleanup
                return;
            }
        } 
    }

    /**
     * Create the payload for the HeartBeat. Mainly the list of
     * {@link LocalResourceStatus}es
     *
     * @return a {@link LocalizerStatus} that can be sent via heartbeat.
     * @throws InterruptedException
     * 		
     */
    private LocalizerStatus createStatus() throws InterruptedException {
        final List<LocalResourceStatus> QXPVNMTYDO = new ArrayList<LocalResourceStatus>();
        // TODO: Synchronization??
        for (Iterator<LocalResource> BLESSTSUKF = ZLSMFOJCMQ.keySet().iterator(); BLESSTSUKF.hasNext();) {
            LocalResource IKESZAJXPM = BLESSTSUKF.next();
            LocalResourceStatus AXYLVCFYCU = KBEYYSDNEI.newRecordInstance(LocalResourceStatus.class);
            AXYLVCFYCU.setResource(IKESZAJXPM);
            Future<Path> MZTGUQJOBS = ZLSMFOJCMQ.get(IKESZAJXPM);
            if (MZTGUQJOBS.isDone()) {
                try {
                    Path IHXYAYSBOW = MZTGUQJOBS.get();
                    AXYLVCFYCU.setLocalPath(ConverterUtils.getYarnUrlFromPath(IHXYAYSBOW));
                    AXYLVCFYCU.setLocalSize(FileUtil.getDU(new File(IHXYAYSBOW.getParent().toUri())));
                    AXYLVCFYCU.setStatus(FETCH_SUCCESS);
                } catch (ExecutionException e) {
                    AXYLVCFYCU.setStatus(FETCH_FAILURE);
                    AXYLVCFYCU.setException(SerializedException.newInstance(e.getCause()));
                } catch (CancellationException e) {
                    AXYLVCFYCU.setStatus(FETCH_FAILURE);
                    AXYLVCFYCU.setException(SerializedException.newInstance(e));
                }
                // TODO shouldn't remove until ACK
                BLESSTSUKF.remove();
            } else {
                AXYLVCFYCU.setStatus(FETCH_PENDING);
            }
            QXPVNMTYDO.add(AXYLVCFYCU);
        }
        LocalizerStatus VESISPJDRM = KBEYYSDNEI.newRecordInstance(LocalizerStatus.class);
        VESISPJDRM.setLocalizerId(RGWHCZDLBK);
        VESISPJDRM.addAllResources(QXPVNMTYDO);
        return VESISPJDRM;
    }

    public static void main(String[] CPMAHSNDLS) throws Throwable {
        Thread.setDefaultUncaughtExceptionHandler(new YarnUncaughtExceptionHandler());
        // usage: $0 user appId locId host port app_log_dir user_dir [user_dir]*
        // let $x = $x/usercache for $local.dir
        // MKDIR $x/$user/appcache/$appid
        // MKDIR $x/$user/appcache/$appid/output
        // MKDIR $x/$user/appcache/$appid/filecache
        // LOAD $x/$user/appcache/$appid/appTokens
        try {
            String ZHERARAENJ = CPMAHSNDLS[0];
            String HPCIUDQPNG = CPMAHSNDLS[1];
            String YMWJHGZMHW = CPMAHSNDLS[2];
            InetSocketAddress DJREZNBVUF = new InetSocketAddress(CPMAHSNDLS[3], Integer.parseInt(CPMAHSNDLS[4]));
            String[] CRNDUZQHYJ = Arrays.copyOfRange(CPMAHSNDLS, 5, CPMAHSNDLS.length);
            ArrayList<Path> UUKRXAEYSR = new ArrayList<Path>(CRNDUZQHYJ.length);
            for (String PFHJHBWIAY : CRNDUZQHYJ) {
                UUKRXAEYSR.add(new Path(PFHJHBWIAY));
            }
            final String RBERSNVPPT = UserGroupInformation.getCurrentUser().getShortUserName();
            if (!ZHERARAENJ.equals(RBERSNVPPT)) {
                // TODO: fail localization
                ContainerLocalizer.GKLZCHJFCS.warn((("Localization running as " + RBERSNVPPT) + " not ") + ZHERARAENJ);
            }
            ContainerLocalizer TYBBJUZXXY = new ContainerLocalizer(FileContext.getLocalFSFileContext(), ZHERARAENJ, HPCIUDQPNG, YMWJHGZMHW, UUKRXAEYSR, RecordFactoryProvider.getRecordFactory(null));
            System.exit(TYBBJUZXXY.runLocalization(DJREZNBVUF));
        } catch (Throwable e) {
            // Print error to stdout so that LCE can use it.
            e.printStackTrace(System.out);
            throw e;
        }
    }

    private static void initDirs(Configuration QSPXYITSGN, String OHAEQGTSSJ, String LZWTZHTVZT, FileContext BOYDAIYWIC, List<Path> QPBUWHIPAK) throws IOException {
        if ((null == QPBUWHIPAK) || (0 == QPBUWHIPAK.size())) {
            throw new IOException("Cannot initialize without local dirs");
        }
        String[] VWKUGGBLTH = new String[QPBUWHIPAK.size()];
        String[] BYCDJVFBQC = new String[QPBUWHIPAK.size()];
        for (int AKMUQNUYVE = 0, DYAVUFTWFE = QPBUWHIPAK.size(); AKMUQNUYVE < DYAVUFTWFE; ++AKMUQNUYVE) {
            // $x/usercache/$user
            Path KJJJSFZJSA = BOYDAIYWIC.makeQualified(new Path(new Path(QPBUWHIPAK.get(AKMUQNUYVE), ContainerLocalizer.LALVOKECDG), OHAEQGTSSJ));
            // $x/usercache/$user/filecache
            Path QZVUSFFMEP = new Path(KJJJSFZJSA, ContainerLocalizer.PFFBKQUTLA);
            BYCDJVFBQC[AKMUQNUYVE] = QZVUSFFMEP.toString();
            ContainerLocalizer.createDir(BOYDAIYWIC, QZVUSFFMEP, ContainerLocalizer.XBOVJWLXGE, false);
            // $x/usercache/$user/appcache/$appId
            Path LJZZAYIKBJ = new Path(KJJJSFZJSA, new Path(ContainerLocalizer.DGSTDEHUOO, LZWTZHTVZT));
            // $x/usercache/$user/appcache/$appId/filecache
            Path JNAWKXGWEP = new Path(LJZZAYIKBJ, ContainerLocalizer.PFFBKQUTLA);
            VWKUGGBLTH[AKMUQNUYVE] = JNAWKXGWEP.toString();
            ContainerLocalizer.createDir(BOYDAIYWIC, JNAWKXGWEP, ContainerLocalizer.XBOVJWLXGE, false);
        }
        QSPXYITSGN.setStrings(String.format(ContainerLocalizer.UYRFNBDHME, LZWTZHTVZT), VWKUGGBLTH);
        QSPXYITSGN.setStrings(String.format(ContainerLocalizer.GOZPJRDXCF, OHAEQGTSSJ), BYCDJVFBQC);
    }

    private static void createDir(FileContext AYZQHTPOAD, Path DIYUWADMWT, FsPermission CZJBFWZLVG, boolean GRCFRCJMUM) throws IOException {
        AYZQHTPOAD.mkdir(DIYUWADMWT, CZJBFWZLVG, GRCFRCJMUM);
        if (!CZJBFWZLVG.equals(CZJBFWZLVG.applyUMask(AYZQHTPOAD.getUMask()))) {
            AYZQHTPOAD.setPermission(DIYUWADMWT, CZJBFWZLVG);
        }
    }
}