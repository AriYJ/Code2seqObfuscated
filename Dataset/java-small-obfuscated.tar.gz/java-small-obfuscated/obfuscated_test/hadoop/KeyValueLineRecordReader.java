/**
 * This class treats a line in the input as a key/value pair separated by a
 * separator character. The separator can be specified in config file
 * under the attribute name mapreduce.input.keyvaluelinerecordreader.key.value.separator. The default
 * separator is the tab character ('\t').
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class KeyValueLineRecordReader extends RecordReader<Text, Text> {
    public static final String YIYGKPDFUI = "mapreduce.input.keyvaluelinerecordreader.key.value.separator";

    private final LineRecordReader EGUXZVDMSP;

    private byte TYCVOZQHHF = ((byte) ('\t'));

    private Text PLZHFAMQNO;

    private Text OUUSELTOIK;

    private Text BOPMHWFCDD;

    public Class getKeyClass() {
        return Text.class;
    }

    public KeyValueLineRecordReader(Configuration FSNGGEMQRJ) throws IOException {
        EGUXZVDMSP = new LineRecordReader();
        String HLIUYERLUA = FSNGGEMQRJ.get(KeyValueLineRecordReader.YIYGKPDFUI, "\t");
        this.TYCVOZQHHF = ((byte) (HLIUYERLUA.charAt(0)));
    }

    public void initialize(InputSplit UNGJHBDLIB, TaskAttemptContext KVDLSHYFHX) throws IOException {
        EGUXZVDMSP.initialize(UNGJHBDLIB, KVDLSHYFHX);
    }

    public static int findSeparator(byte[] BGPFMTJWNH, int BUQMOSZBJO, int KUQJDTBVZA, byte NTJWOXMONQ) {
        for (int XEUWARLRMT = BUQMOSZBJO; XEUWARLRMT < (BUQMOSZBJO + KUQJDTBVZA); XEUWARLRMT++) {
            if (BGPFMTJWNH[XEUWARLRMT] == NTJWOXMONQ) {
                return XEUWARLRMT;
            }
        }
        return -1;
    }

    public static void setKeyValue(Text TMZNKSQPTK, Text JOZDNXNHSM, byte[] QLWYZHHLZT, int MCHORKOKWI, int TPECDIKPVI) {
        if (TPECDIKPVI == (-1)) {
            TMZNKSQPTK.set(QLWYZHHLZT, 0, MCHORKOKWI);
            JOZDNXNHSM.set("");
        } else {
            TMZNKSQPTK.set(QLWYZHHLZT, 0, TPECDIKPVI);
            JOZDNXNHSM.set(QLWYZHHLZT, TPECDIKPVI + 1, (MCHORKOKWI - TPECDIKPVI) - 1);
        }
    }

    /**
     * Read key/value pair in a line.
     */
    public synchronized boolean nextKeyValue() throws IOException {
        byte[] QSIIFXMKOR = null;
        int FFLWXNDBKD = -1;
        if (EGUXZVDMSP.nextKeyValue()) {
            PLZHFAMQNO = EGUXZVDMSP.getCurrentValue();
            QSIIFXMKOR = PLZHFAMQNO.getBytes();
            FFLWXNDBKD = PLZHFAMQNO.getLength();
        } else {
            return false;
        }
        if (QSIIFXMKOR == null)
            return false;

        if (OUUSELTOIK == null) {
            OUUSELTOIK = new Text();
        }
        if (BOPMHWFCDD == null) {
            BOPMHWFCDD = new Text();
        }
        int OCHINSZKHX = KeyValueLineRecordReader.findSeparator(QSIIFXMKOR, 0, FFLWXNDBKD, this.TYCVOZQHHF);
        KeyValueLineRecordReader.setKeyValue(OUUSELTOIK, BOPMHWFCDD, QSIIFXMKOR, FFLWXNDBKD, OCHINSZKHX);
        return true;
    }

    public Text getCurrentKey() {
        return OUUSELTOIK;
    }

    public Text getCurrentValue() {
        return BOPMHWFCDD;
    }

    public float getProgress() throws IOException {
        return EGUXZVDMSP.getProgress();
    }

    public synchronized void close() throws IOException {
        EGUXZVDMSP.close();
    }
}