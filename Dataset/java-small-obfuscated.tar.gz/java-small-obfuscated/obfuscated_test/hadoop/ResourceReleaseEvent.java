public class ResourceReleaseEvent extends ResourceEvent {
    private final ContainerId VAJAUGHXKD;

    public ResourceReleaseEvent(LocalResourceRequest PMKCWMULOT, ContainerId JENIEIXZMU) {
        super(PMKCWMULOT, RELEASE);
        this.VAJAUGHXKD = JENIEIXZMU;
    }

    public ContainerId getContainer() {
        return VAJAUGHXKD;
    }
}