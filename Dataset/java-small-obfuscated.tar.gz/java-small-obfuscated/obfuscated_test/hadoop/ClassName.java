/**
 * Represents a class name.
 */
public class ClassName extends DefaultAnonymizableDataType {
    public static final String VBOJSTILHH = "rumen.data-types.classname.preserve";

    private final String SLEFNYEPSN;

    public ClassName(String XWYEZPCFMH) {
        super();
        this.SLEFNYEPSN = XWYEZPCFMH;
    }

    @Override
    public String getValue() {
        return SLEFNYEPSN;
    }

    @Override
    protected String getPrefix() {
        return "class";
    }

    @Override
    protected boolean needsAnonymization(Configuration WVUZHXDHPD) {
        String[] OPOODZKQZU = WVUZHXDHPD.getStrings(ClassName.VBOJSTILHH);
        if (OPOODZKQZU != null) {
            // do a simple starts with check
            for (String MIIYAZADIL : OPOODZKQZU) {
                if (SLEFNYEPSN.startsWith(MIIYAZADIL)) {
                    return false;
                }
            }
        }
        return true;
    }
}