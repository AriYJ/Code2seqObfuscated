public class JobStartEvent extends JobEvent {
    long XLMJAXEGAI;

    public JobStartEvent(JobId OAIBVXBTFG) {
        this(OAIBVXBTFG, 0);
    }

    public JobStartEvent(JobId YLDXCJNXWT, long JMYAPQWKDA) {
        super(YLDXCJNXWT, JOB_START);
        this.XLMJAXEGAI = JMYAPQWKDA;
    }

    public long getRecoveredJobStartTime() {
        return XLMJAXEGAI;
    }
}