/**
 * A Writable for 2D arrays containing a matrix of instances of a class.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class TwoDArrayWritable implements Writable {
    private Class PFXKQFQODA;

    private Writable[][] UTVDNYFDOW;

    public TwoDArrayWritable(Class IOHVCXHKKK) {
        this.PFXKQFQODA = IOHVCXHKKK;
    }

    public TwoDArrayWritable(Class QFWXZTDWFT, Writable[][] NFDQQLUUKQ) {
        this(QFWXZTDWFT);
        this.UTVDNYFDOW = NFDQQLUUKQ;
    }

    public Object toArray() {
        int[] QURKCMMTNG = new int[]{ UTVDNYFDOW.length, 0 };
        Object CNALWNINRL = Array.newInstance(PFXKQFQODA, QURKCMMTNG);
        for (int PVBUFUSIGQ = 0; PVBUFUSIGQ < UTVDNYFDOW.length; PVBUFUSIGQ++) {
            Object EXTEAIUVDZ = Array.newInstance(PFXKQFQODA, UTVDNYFDOW[PVBUFUSIGQ].length);
            Array.set(CNALWNINRL, PVBUFUSIGQ, EXTEAIUVDZ);
            for (int DUTTQGRHFT = 0; DUTTQGRHFT < UTVDNYFDOW[PVBUFUSIGQ].length; DUTTQGRHFT++) {
                Array.set(EXTEAIUVDZ, DUTTQGRHFT, UTVDNYFDOW[PVBUFUSIGQ][DUTTQGRHFT]);
            }
        }
        return CNALWNINRL;
    }

    public void set(Writable[][] BRYKQEKQZD) {
        this.UTVDNYFDOW = BRYKQEKQZD;
    }

    public Writable[][] get() {
        return UTVDNYFDOW;
    }

    @Override
    public void readFields(DataInput CUZTOKCXOB) throws IOException {
        // construct matrix
        UTVDNYFDOW = new Writable[CUZTOKCXOB.readInt()][];
        for (int JYAQVKRGJP = 0; JYAQVKRGJP < UTVDNYFDOW.length; JYAQVKRGJP++) {
            UTVDNYFDOW[JYAQVKRGJP] = new Writable[CUZTOKCXOB.readInt()];
        }
        // construct values
        for (int LUMYDTZBNX = 0; LUMYDTZBNX < UTVDNYFDOW.length; LUMYDTZBNX++) {
            for (int ZUTBZISWWD = 0; ZUTBZISWWD < UTVDNYFDOW[LUMYDTZBNX].length; ZUTBZISWWD++) {
                Writable RSONXUVVKW;
                // construct value
                try {
                    RSONXUVVKW = ((Writable) (PFXKQFQODA.newInstance()));
                } catch (InstantiationException e) {
                    throw new RuntimeException(e.toString());
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e.toString());
                }
                RSONXUVVKW.readFields(CUZTOKCXOB);
                // read a value
                UTVDNYFDOW[LUMYDTZBNX][ZUTBZISWWD] = RSONXUVVKW;// store it in values

            }
        }
    }

    @Override
    public void write(DataOutput BLHIUEJZRQ) throws IOException {
        BLHIUEJZRQ.writeInt(UTVDNYFDOW.length);
        // write values
        for (int HRAVBKLPYD = 0; HRAVBKLPYD < UTVDNYFDOW.length; HRAVBKLPYD++) {
            BLHIUEJZRQ.writeInt(UTVDNYFDOW[HRAVBKLPYD].length);
        }
        for (int DBWMEFJCTX = 0; DBWMEFJCTX < UTVDNYFDOW.length; DBWMEFJCTX++) {
            for (int RRSRMFTCDR = 0; RRSRMFTCDR < UTVDNYFDOW[DBWMEFJCTX].length; RRSRMFTCDR++) {
                UTVDNYFDOW[DBWMEFJCTX][RRSRMFTCDR].write(BLHIUEJZRQ);
            }
        }
    }
}