/**
 * An abstract class to provide common implementation of the filesystem
 * counter group in both mapred and mapreduce packages.
 *
 * @param <C>
 * 		the type of the Counter for the group
 */
@InterfaceAudience.Private
public abstract class FileSystemCounterGroup<C extends Counter> implements CounterGroupBase<C> {
    static final int OOPRHWKCEO = 100;// intern/sanity check


    static final ConcurrentMap<String, String> SDUAOINZYH = Maps.newConcurrentMap();

    // C[] would need Array.newInstance which requires a Class<C> reference.
    // Just a few local casts probably worth not having to carry it around.
    private final Map<String, Object[]> LATOJZYMXS = new ConcurrentSkipListMap<String, Object[]>();

    private String FFGPOADRAH;

    private static final Joiner RUAWVMGZVZ = Joiner.on('_');

    private static final Joiner DXNYCFLVWQ = Joiner.on(": ");

    @InterfaceAudience.Private
    public static class FSCounter extends AbstractCounter {
        final String FKSZAXJNJI;

        final FileSystemCounter GMKKOAZKKY;

        private long ABTTVRBDJP;

        public FSCounter(String scheme, FileSystemCounter ref) {
            this.FKSZAXJNJI = scheme;
            GMKKOAZKKY = ref;
        }

        @Private
        public String getScheme() {
            return FKSZAXJNJI;
        }

        @Private
        public FileSystemCounter getFileSystemCounter() {
            return GMKKOAZKKY;
        }

        @Override
        public String getName() {
            return FileSystemCounterGroup.RUAWVMGZVZ.join(FKSZAXJNJI, GMKKOAZKKY.name());
        }

        @Override
        public String getDisplayName() {
            return FileSystemCounterGroup.DXNYCFLVWQ.join(FKSZAXJNJI, localizeCounterName(GMKKOAZKKY.name()));
        }

        protected String localizeCounterName(String counterName) {
            return ResourceBundles.getCounterName(FileSystemCounter.class.getName(), counterName, counterName);
        }

        @Override
        public long getValue() {
            return ABTTVRBDJP;
        }

        @Override
        public void setValue(long value) {
            this.ABTTVRBDJP = value;
        }

        @Override
        public void increment(long incr) {
            ABTTVRBDJP += incr;
        }

        @Override
        public void write(DataOutput out) throws IOException {
            assert false : "shouldn't be called";
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            assert false : "shouldn't be called";
        }

        @Override
        public Counter getUnderlyingCounter() {
            return this;
        }
    }

    @Override
    public String getName() {
        return FileSystemCounter.class.getName();
    }

    @Override
    public String getDisplayName() {
        if (FFGPOADRAH == null) {
            FFGPOADRAH = ResourceBundles.getCounterGroupName(getName(), "File System Counters");
        }
        return FFGPOADRAH;
    }

    @Override
    public void setDisplayName(String UITKAWYGIK) {
        this.displayName = UITKAWYGIK;
    }

    @Override
    public void addCounter(C WYNABNPNHN) {
        C RZQAUSZRPH;
        if (WYNABNPNHN instanceof FileSystemCounterGroup.FSCounter) {
            FileSystemCounterGroup.FSCounter AYWPBPKDEK = ((FileSystemCounterGroup.FSCounter) (WYNABNPNHN));
            RZQAUSZRPH = findCounter(AYWPBPKDEK.FKSZAXJNJI, AYWPBPKDEK.GMKKOAZKKY);
        } else {
            RZQAUSZRPH = findCounter(WYNABNPNHN.getName());
        }
        RZQAUSZRPH.setValue(WYNABNPNHN.getValue());
    }

    @Override
    public C addCounter(String JFMBLEWDYS, String NQQWOYJOYD, long BLRDQEXITW) {
        C EWQXNVKZYQ = findCounter(JFMBLEWDYS);
        EWQXNVKZYQ.setValue(BLRDQEXITW);
        return EWQXNVKZYQ;
    }

    // Parse generic counter name into [scheme, key]
    private String[] parseCounterName(String AUPIBCYWHN) {
        int MIQHQWKYLN = AUPIBCYWHN.indexOf('_');
        if (MIQHQWKYLN < 0) {
            throw new IllegalArgumentException("bad fs counter name");
        }
        return new String[]{ AUPIBCYWHN.substring(0, MIQHQWKYLN), AUPIBCYWHN.substring(MIQHQWKYLN + 1) };
    }

    @Override
    public C findCounter(String DXJVCXZQAO, String WLASVXUMZA) {
        return findCounter(DXJVCXZQAO);
    }

    @Override
    public C findCounter(String VSXDYEIWVU, boolean UOMXJIHJCO) {
        try {
            String[] ODLXCHITMF = parseCounterName(VSXDYEIWVU);
            return findCounter(ODLXCHITMF[0], FileSystemCounter.valueOf(ODLXCHITMF[1]));
        } catch (Exception e) {
            if (UOMXJIHJCO)
                throw new IllegalArgumentException(e);

            return null;
        }
    }

    @Override
    public C findCounter(String DLXGABASGM) {
        return findCounter(DLXGABASGM, true);
    }

    @SuppressWarnings("unchecked")
    public synchronized C findCounter(String YGOCLRYLXG, FileSystemCounter BDCQOLOCLY) {
        final String QJHOCFQSOZ = checkScheme(YGOCLRYLXG);
        Object[] ETSQKWLDPM = LATOJZYMXS.get(QJHOCFQSOZ);
        int PDPNMRBUJS = BDCQOLOCLY.ordinal();
        if (ETSQKWLDPM == null) {
            ETSQKWLDPM = new Object[FileSystemCounter.values().length];
            LATOJZYMXS.put(QJHOCFQSOZ, ETSQKWLDPM);
            ETSQKWLDPM[PDPNMRBUJS] = newCounter(QJHOCFQSOZ, BDCQOLOCLY);
        } else
            if (ETSQKWLDPM[PDPNMRBUJS] == null) {
                ETSQKWLDPM[PDPNMRBUJS] = newCounter(QJHOCFQSOZ, BDCQOLOCLY);
            }

        return ((C) (ETSQKWLDPM[PDPNMRBUJS]));
    }

    private String checkScheme(String AJGPVCPTUG) {
        String KKHYXFRNXY = AJGPVCPTUG.toUpperCase(Locale.US);
        String AEPQKDJXSR = FileSystemCounterGroup.SDUAOINZYH.putIfAbsent(KKHYXFRNXY, KKHYXFRNXY);
        if (FileSystemCounterGroup.SDUAOINZYH.size() > FileSystemCounterGroup.OOPRHWKCEO) {
            // mistakes or abuses
            throw new IllegalArgumentException((("too many schemes? " + FileSystemCounterGroup.SDUAOINZYH.size()) + " when process scheme: ") + AJGPVCPTUG);
        }
        return AEPQKDJXSR == null ? KKHYXFRNXY : AEPQKDJXSR;
    }

    /**
     * Abstract factory method to create a file system counter
     *
     * @param scheme
     * 		of the file system
     * @param key
     * 		the enum of the file system counter
     * @return a new file system counter
     */
    protected abstract C newCounter(String TEIYCWYDJS, FileSystemCounter IBULKYMOHC);

    @Override
    public int size() {
        int WJVRQZLXDO = 0;
        for (Object[] IRQAZSCEYK : LATOJZYMXS.values()) {
            WJVRQZLXDO += numSetCounters(IRQAZSCEYK);
        }
        return WJVRQZLXDO;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void incrAllCounters(CounterGroupBase<C> SYEJTGCUXD) {
        if (checkNotNull(SYEJTGCUXD.getUnderlyingGroup(), "other group") instanceof FileSystemCounterGroup<?>) {
            for (Counter KLCFMONEPI : SYEJTGCUXD) {
                FileSystemCounterGroup.FSCounter SXPJBOMMTZ = ((FileSystemCounterGroup.FSCounter) (((Counter) (KLCFMONEPI)).getUnderlyingCounter()));
                findCounter(SXPJBOMMTZ.FKSZAXJNJI, SXPJBOMMTZ.GMKKOAZKKY).increment(KLCFMONEPI.getValue());
            }
        }
    }

    /**
     * FileSystemGroup ::= #scheme (scheme #counter (key value)*)*
     */
    @Override
    public void write(DataOutput YTRSOQAKCA) throws IOException {
        WritableUtils.writeVInt(YTRSOQAKCA, LATOJZYMXS.size());// #scheme

        for (Map.Entry<String, Object[]> IMUQWHZWGM : LATOJZYMXS.entrySet()) {
            WritableUtils.writeString(YTRSOQAKCA, IMUQWHZWGM.getKey());// scheme

            // #counter for the above scheme
            WritableUtils.writeVInt(YTRSOQAKCA, numSetCounters(IMUQWHZWGM.getValue()));
            for (Object YOMZTIAFUN : IMUQWHZWGM.getValue()) {
                if (YOMZTIAFUN == null)
                    continue;

                @SuppressWarnings("unchecked")
                FileSystemCounterGroup.FSCounter ZZYJLINVFE = ((FileSystemCounterGroup.FSCounter) (((Counter) (YOMZTIAFUN)).getUnderlyingCounter()));
                WritableUtils.writeVInt(YTRSOQAKCA, ZZYJLINVFE.GMKKOAZKKY.ordinal());// key

                WritableUtils.writeVLong(YTRSOQAKCA, ZZYJLINVFE.getValue());// value

            }
        }
    }

    private int numSetCounters(Object[] EZLDOHOJZN) {
        int OHLUQIFTFZ = 0;
        for (Object DNGQRQTOWP : EZLDOHOJZN)
            if (DNGQRQTOWP != null)
                ++OHLUQIFTFZ;


        return OHLUQIFTFZ;
    }

    @Override
    public void readFields(DataInput FZSWCPMFPD) throws IOException {
        int TPJWVQKUGU = WritableUtils.readVInt(FZSWCPMFPD);// #scheme

        FileSystemCounter[] HXWMESYRSM = FileSystemCounter.values();
        for (int SRUFFTDTVW = 0; SRUFFTDTVW < TPJWVQKUGU; ++SRUFFTDTVW) {
            String LHCZIQGJZT = WritableUtils.readString(FZSWCPMFPD);// scheme

            int VSILCGZGBE = WritableUtils.readVInt(FZSWCPMFPD);// #counter

            for (int QCKXYRGIPK = 0; QCKXYRGIPK < VSILCGZGBE; ++QCKXYRGIPK) {
                // key
                findCounter(LHCZIQGJZT, HXWMESYRSM[WritableUtils.readVInt(FZSWCPMFPD)]).setValue(WritableUtils.readVLong(FZSWCPMFPD));// value

            }
        }
    }

    @Override
    public Iterator<C> iterator() {
        return new com.google.common.collect.AbstractIterator<C>() {
            Iterator<Object[]> KWQEUSGHSL = LATOJZYMXS.values().iterator();

            Object[] UIIWYFUOHJ = (KWQEUSGHSL.hasNext()) ? KWQEUSGHSL.next() : null;

            int STOGMYGVUI = 0;

            @Override
            protected C computeNext() {
                while (UIIWYFUOHJ != null) {
                    while (STOGMYGVUI < UIIWYFUOHJ.length) {
                        @SuppressWarnings("unchecked")
                        C BZLAYLSTFU = ((C) (UIIWYFUOHJ[STOGMYGVUI++]));
                        if (BZLAYLSTFU != null)
                            return BZLAYLSTFU;

                    } 
                    STOGMYGVUI = 0;
                    UIIWYFUOHJ = (KWQEUSGHSL.hasNext()) ? KWQEUSGHSL.next() : null;
                } 
                return endOfData();
            }
        };
    }

    @Override
    public synchronized boolean equals(Object BLKSTDWNOV) {
        if (BLKSTDWNOV instanceof CounterGroupBase<?>) {
            @SuppressWarnings("unchecked")
            CounterGroupBase<C> XRKEZOUPKL = ((CounterGroupBase<C>) (BLKSTDWNOV));
            return Iterators.elementsEqual(iterator(), XRKEZOUPKL.iterator());
        }
        return false;
    }

    @Override
    public synchronized int hashCode() {
        // need to be deep as counters is an array
        int HXDCHOYSRE = FileSystemCounter.class.hashCode();
        for (Object[] SXUPDZXKSM : LATOJZYMXS.values()) {
            if (SXUPDZXKSM != null)
                HXDCHOYSRE ^= Arrays.hashCode(SXUPDZXKSM);

        }
        return HXDCHOYSRE;
    }
}