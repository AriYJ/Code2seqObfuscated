public class TestConstructQuery extends TestCase {
    private String[] PFADMFPCNO = new String[]{ "id", "name", "value" };

    private String[] UPSWEJGDUM = new String[]{ null, null, null };

    private String FQLCCGODVN = "INSERT INTO hadoop_output (id,name,value) VALUES (?,?,?);";

    private String QDAQEDPDXT = "INSERT INTO hadoop_output VALUES (?,?,?);";

    private DBOutputFormat<DBWritable, NullWritable> PEMLEEGLPW = new DBOutputFormat<DBWritable, NullWritable>();

    public void testConstructQuery() {
        String CHCEVASGLE = PEMLEEGLPW.constructQuery("hadoop_output", PFADMFPCNO);
        assertEquals(FQLCCGODVN, CHCEVASGLE);
        CHCEVASGLE = PEMLEEGLPW.constructQuery("hadoop_output", UPSWEJGDUM);
        assertEquals(QDAQEDPDXT, CHCEVASGLE);
    }

    public void testSetOutput() throws IOException {
        JobConf CBRHYKNBYG = new JobConf();
        DBOutputFormat.setOutput(CBRHYKNBYG, "hadoop_output", PFADMFPCNO);
        DBConfiguration ZNDULBVYGW = new DBConfiguration(CBRHYKNBYG);
        String VKGXTWRTEL = PEMLEEGLPW.constructQuery(ZNDULBVYGW.getOutputTableName(), ZNDULBVYGW.getOutputFieldNames());
        assertEquals(FQLCCGODVN, VKGXTWRTEL);
        CBRHYKNBYG = new JobConf();
        ZNDULBVYGW = new DBConfiguration(CBRHYKNBYG);
        DBOutputFormat.setOutput(CBRHYKNBYG, "hadoop_output", UPSWEJGDUM.length);
        assertNull(ZNDULBVYGW.getOutputFieldNames());
        assertEquals(UPSWEJGDUM.length, ZNDULBVYGW.getOutputFieldCount());
        VKGXTWRTEL = PEMLEEGLPW.constructQuery(ZNDULBVYGW.getOutputTableName(), new String[ZNDULBVYGW.getOutputFieldCount()]);
        assertEquals(QDAQEDPDXT, VKGXTWRTEL);
    }
}