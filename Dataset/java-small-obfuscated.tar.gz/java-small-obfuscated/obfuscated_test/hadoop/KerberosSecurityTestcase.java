/**
 * KerberosSecurityTestcase provides a base class for using MiniKdc with other
 * testcases. KerberosSecurityTestcase starts the MiniKdc (@Before) before
 * running tests, and stop the MiniKdc (@After) after the testcases, using
 * default settings (working dir and kdc configurations).
 * <p>
 * Users can directly inherit this class and implement their own test functions
 * using the default settings, or override functions getTestDir() and
 * createMiniKdcConf() to provide new settings.
 */
public class KerberosSecurityTestcase {
    private MiniKdc EIGSJRQYVX;

    private File JLMDAOFQMO;

    private Properties GTAIGWQFJL;

    @Before
    public void startMiniKdc() throws Exception {
        createTestDir();
        createMiniKdcConf();
        EIGSJRQYVX = new MiniKdc(GTAIGWQFJL, JLMDAOFQMO);
        EIGSJRQYVX.start();
    }

    /**
     * Create a working directory, it should be the build directory. Under
     * this directory an ApacheDS working directory will be created, this
     * directory will be deleted when the MiniKdc stops.
     */
    public void createTestDir() {
        JLMDAOFQMO = new File(System.getProperty("test.dir", "target"));
    }

    /**
     * Create a Kdc configuration
     */
    public void createMiniKdcConf() {
        GTAIGWQFJL = MiniKdc.createConf();
    }

    @After
    public void stopMiniKdc() {
        if (EIGSJRQYVX != null) {
            EIGSJRQYVX.stop();
        }
    }

    public MiniKdc getKdc() {
        return EIGSJRQYVX;
    }

    public File getWorkDir() {
        return JLMDAOFQMO;
    }

    public Properties getConf() {
        return GTAIGWQFJL;
    }
}