/**
 * An input stream that decompresses from the BZip2 format (without the file
 * header chars) to be read as any other stream.
 *
 * <p>
 * The decompression requires large amounts of memory. Thus you should call the
 * {@link #close() close()} method as soon as possible, to force
 * <tt>CBZip2InputStream</tt> to release the allocated memory. See
 * {@link CBZip2OutputStream CBZip2OutputStream} for information about memory
 * usage.
 * </p>
 *
 * <p>
 * <tt>CBZip2InputStream</tt> reads bytes from the compressed source stream via
 * the single byte {@link java.io.InputStream#read() read()} method exclusively.
 * Thus you should consider to use a buffered source stream.
 * </p>
 *
 * <p>
 * This Ant code was enhanced so that it can de-compress blocks of bzip2 data.
 * Current position in the stream is an important statistic for Hadoop. For
 * example in LineRecordReader, we solely depend on the current position in the
 * stream to know about the progess. The notion of position becomes complicated
 * for compressed files. The Hadoop splitting is done in terms of compressed
 * file. But a compressed file deflates to a large amount of data. So we have
 * handled this problem in the following way.
 *
 * On object creation time, we find the next block start delimiter. Once such a
 * marker is found, the stream stops there (we discard any read compressed data
 * in this process) and the position is updated (i.e. the caller of this class
 * will find out the stream location). At this point we are ready for actual
 * reading (i.e. decompression) of data.
 *
 * The subsequent read calls give out data. The position is updated when the
 * caller of this class has read off the current block + 1 bytes. In between the
 * block reading, position is not updated. (We can only update the postion on
 * block boundaries).
 * </p>
 *
 * <p>
 * Instances of this class are not threadsafe.
 * </p>
 */
public class CBZip2InputStream extends InputStream implements BZip2Constants {
    public static final long ULXTMBZSNY = 0x314159265359L;// start of block


    public static final long WNGOEBCHHU = 0x177245385090L;// end of bzip2 stream


    private static final int AKVBKXYCKL = 48;

    READ_MODE HTIVKQNAYZ = READ_MODE.CONTINUOUS;

    // The variable records the current advertised position of the stream.
    private long KTNMACPRYP = 0L;

    // The following variable keep record of compressed bytes read.
    private long VFCPFNGKKN = 0L;

    private boolean DIAMSERRQC = false;

    private byte[] OXHGUOXEKT = new byte[1];

    /**
     * Index of the last char in the block, so the block size == last + 1.
     */
    private int FKVBSSEALQ;

    /**
     * Index in zptr[] of original string after sorting.
     */
    private int HOMOANOJZJ;

    /**
     * always: in the range 0 .. 9. The current block size is 100000 * this
     * number.
     */
    private int AQGNWWOARY;

    private boolean HWQBVMYEAJ = false;

    private long ZKBCOLNKQH;

    private long YGDYQAOAPU;

    private final CRC UKCCKKHMLA = new CRC();

    private int GHTPOTLPXF;

    private BufferedInputStream OXTCHPPCLF;

    private int DSKXCLYXGG = -1;

    /**
     * A state machine to keep track of current state of the de-coder
     */
    public enum STATE {

        EOF,
        START_BLOCK_STATE,
        RAND_PART_A_STATE,
        RAND_PART_B_STATE,
        RAND_PART_C_STATE,
        NO_RAND_PART_A_STATE,
        NO_RAND_PART_B_STATE,
        NO_RAND_PART_C_STATE,
        NO_PROCESS_STATE;}

    private CBZip2InputStream.STATE RVSUKIXCZM = CBZip2InputStream.STATE.START_BLOCK_STATE;

    private int RDUCDZAICW;

    private int JIPEQFPIQN;

    private int GCVVVXRGIL;

    private int RRKCPHLIBE;

    private boolean VNZOABRKNP = false;// used by skipToNextMarker


    private boolean TANTWSZJMQ = false;

    // Variables used by setup* methods exclusively
    private int IRIWXZJFDC;

    private int IDPKYLSUBF;

    private int JASPRKPFFO;

    private int ZTOJDBMFGB;

    private int PNSSZPTHHH;

    private int NWEPNZXWJE;

    private int HOTUVHSIND;

    private int SKIDZQQKZX;

    private char EEFLTBBZCV;

    /**
     * All memory intensive stuff. This field is initialized by initBlock().
     */
    private CBZip2InputStream.Data PEHVXUAULL;

    /**
     * This method reports the processed bytes so far. Please note that this
     * statistic is only updated on block boundaries and only when the stream is
     * initiated in BYBLOCK mode.
     */
    public long getProcessedByteCount() {
        return KTNMACPRYP;
    }

    /**
     * This method keeps track of raw processed compressed
     * bytes.
     *
     * @param count
     * 		count is the number of bytes to be
     * 		added to raw processed bytes
     */
    protected void updateProcessedByteCount(int BOOYPYPIOK) {
        this.VFCPFNGKKN += BOOYPYPIOK;
    }

    /**
     * This method is called by the client of this
     * class in case there are any corrections in
     * the stream position.  One common example is
     * when client of this code removes starting BZ
     * characters from the compressed stream.
     *
     * @param count
     * 		count bytes are added to the reported bytes
     */
    public void updateReportedByteCount(int USGLKQLDBQ) {
        this.KTNMACPRYP += USGLKQLDBQ;
        this.updateProcessedByteCount(USGLKQLDBQ);
    }

    /**
     * This method reads a Byte from the compressed stream. Whenever we need to
     * read from the underlying compressed stream, this method should be called
     * instead of directly calling the read method of the underlying compressed
     * stream. This method does important record keeping to have the statistic
     * that how many bytes have been read off the compressed stream.
     */
    private int readAByte(InputStream WEGAZSQPQB) throws IOException {
        int ABGSCJNULO = WEGAZSQPQB.read();
        if (ABGSCJNULO >= 0) {
            this.updateProcessedByteCount(1);
        }
        return ABGSCJNULO;
    }

    /**
     * This method tries to find the marker (passed to it as the first parameter)
     * in the stream.  It can find bit patterns of length <= 63 bits.  Specifically
     * this method is used in CBZip2InputStream to find the end of block (EOB)
     * delimiter in the stream, starting from the current position of the stream.
     * If marker is found, the stream position will be right after marker at the
     * end of this call.
     *
     * @param marker
     * 		The bit pattern to be found in the stream
     * @param markerBitLength
     * 		No of bits in the marker
     * @throws IOException
     * 		
     * @throws IllegalArgumentException
     * 		if marketBitLength is greater than 63
     */
    public boolean skipToNextMarker(long LTURWGEHWY, int NOGRWGAAXI) throws IOException, IllegalArgumentException {
        try {
            if (NOGRWGAAXI > 63) {
                throw new IllegalArgumentException("skipToNextMarker can not find patterns greater than 63 bits");
            }
            // pick next marketBitLength bits in the stream
            long FUUSQUIQXL = 0;
            FUUSQUIQXL = this.bsR(NOGRWGAAXI);
            if (FUUSQUIQXL == (-1)) {
                return false;
            }
            while (true) {
                if (FUUSQUIQXL == LTURWGEHWY) {
                    return true;
                } else {
                    FUUSQUIQXL = FUUSQUIQXL << 1;
                    FUUSQUIQXL = FUUSQUIQXL & ((1L << NOGRWGAAXI) - 1);
                    int SZMHKLSLMR = ((int) (this.bsR(1)));
                    if (SZMHKLSLMR != (-1)) {
                        FUUSQUIQXL = FUUSQUIQXL | SZMHKLSLMR;
                    } else
                        return false;

                }
            } 
        } catch (IOException ex) {
            return false;
        }
    }

    protected void reportCRCError() throws IOException {
        throw new IOException("crc error");
    }

    private void makeMaps() {
        final boolean[] QKCMMODMLT = this.PEHVXUAULL.TQIIMZWNJB;
        final byte[] TQZKDIGCEM = this.PEHVXUAULL.IKEQVDDELT;
        int XXPPBNGJLJ = 0;
        for (int ISLDQDOZIY = 0; ISLDQDOZIY < 256; ISLDQDOZIY++) {
            if (QKCMMODMLT[ISLDQDOZIY])
                TQZKDIGCEM[XXPPBNGJLJ++] = ((byte) (ISLDQDOZIY));

        }
        this.GHTPOTLPXF = XXPPBNGJLJ;
    }

    /**
     * Constructs a new CBZip2InputStream which decompresses bytes read from the
     * specified stream.
     *
     * <p>
     * Although BZip2 headers are marked with the magic <tt>"Bz"</tt> this
     * constructor expects the next byte in the stream to be the first one after
     * the magic. Thus callers have to skip the first two bytes. Otherwise this
     * constructor will throw an exception.
     * </p>
     *
     * @throws IOException
     * 		if the stream content is malformed or an I/O error occurs.
     * @throws NullPointerException
     * 		if <tt>in == null</tt>
     */
    public CBZip2InputStream(final InputStream NKWZNHJUJT, READ_MODE JBPNTNVOQQ) throws IOException {
        this(NKWZNHJUJT, JBPNTNVOQQ, false);
    }

    private CBZip2InputStream(final InputStream ZVXLJBGOIO, READ_MODE OYWYXZUFJN, boolean UUWCRXABUB) throws IOException {
        super();
        int OIYANATTVF = 0x39;// i.e 9

        this.AQGNWWOARY = OIYANATTVF - '0';
        this.OXTCHPPCLF = new BufferedInputStream(ZVXLJBGOIO, 1024 * 9);// >1 MB buffer

        this.HTIVKQNAYZ = OYWYXZUFJN;
        this.TANTWSZJMQ = UUWCRXABUB;
        if (OYWYXZUFJN == READ_MODE.CONTINUOUS) {
            RVSUKIXCZM = CBZip2InputStream.STATE.START_BLOCK_STATE;
            DIAMSERRQC = (ZVXLJBGOIO.available() == 0) ? true : false;
            if (!DIAMSERRQC) {
                init();
            }
        } else
            if (OYWYXZUFJN == READ_MODE.BYBLOCK) {
                this.RVSUKIXCZM = CBZip2InputStream.STATE.NO_PROCESS_STATE;
                VNZOABRKNP = this.skipToNextMarker(CBZip2InputStream.ULXTMBZSNY, CBZip2InputStream.AKVBKXYCKL);
                this.KTNMACPRYP = this.VFCPFNGKKN;
                if (!UUWCRXABUB) {
                    changeStateToProcessABlock();
                }
            }

    }

    /**
     * Returns the number of bytes between the current stream position
     * and the immediate next BZip2 block marker.
     *
     * @param in
     * 		The InputStream
     * @return long Number of bytes between current stream position and the
    next BZip2 block start marker.
     * @throws IOException
     * 		
     */
    public static long numberOfBytesTillNextMarker(final InputStream BFUFJMHZCY) throws IOException {
        CBZip2InputStream UMJFMAGIJQ = new CBZip2InputStream(BFUFJMHZCY, READ_MODE.BYBLOCK, true);
        return UMJFMAGIJQ.getProcessedByteCount();
    }

    public CBZip2InputStream(final InputStream OJQOOVKYCL) throws IOException {
        this(OJQOOVKYCL, CONTINUOUS);
    }

    private void changeStateToProcessABlock() throws IOException {
        if (VNZOABRKNP == true) {
            initBlock();
            setupBlock();
        } else {
            this.RVSUKIXCZM = CBZip2InputStream.STATE.EOF;
        }
    }

    @Override
    public int read() throws IOException {
        if (this.OXTCHPPCLF != null) {
            int CZJWXPYVTO = this.read(OXHGUOXEKT, 0, 1);
            int QUYWENEIPH = 0xff & OXHGUOXEKT[0];
            return CZJWXPYVTO > 0 ? QUYWENEIPH : CZJWXPYVTO;
        } else {
            throw new IOException("stream closed");
        }
    }

    /**
     * In CONTINOUS reading mode, this read method starts from the
     * start of the compressed stream and end at the end of file by
     * emitting un-compressed data.  In this mode stream positioning
     * is not announced and should be ignored.
     *
     * In BYBLOCK reading mode, this read method informs about the end
     * of a BZip2 block by returning EOB.  At this event, the compressed
     * stream position is also announced.  This announcement tells that
     * how much of the compressed stream has been de-compressed and read
     * out of this class.  In between EOB events, the stream position is
     * not updated.
     *
     * @throws IOException
     * 		if the stream content is malformed or an I/O error occurs.
     * @return int The return value greater than 0 are the bytes read.  A value
    of -1 means end of stream while -2 represents end of block
     */
    @Override
    public int read(final byte[] GRQAGEALFM, final int VXKMKCJDFF, final int VSCEGWUVWY) throws IOException {
        if (VXKMKCJDFF < 0) {
            throw new IndexOutOfBoundsException(("offs(" + VXKMKCJDFF) + ") < 0.");
        }
        if (VSCEGWUVWY < 0) {
            throw new IndexOutOfBoundsException(("len(" + VSCEGWUVWY) + ") < 0.");
        }
        if ((VXKMKCJDFF + VSCEGWUVWY) > GRQAGEALFM.length) {
            throw new IndexOutOfBoundsException(((((("offs(" + VXKMKCJDFF) + ") + len(") + VSCEGWUVWY) + ") > dest.length(") + GRQAGEALFM.length) + ").");
        }
        if (this.OXTCHPPCLF == null) {
            throw new IOException("stream closed");
        }
        if (DIAMSERRQC) {
            this.init();
            this.DIAMSERRQC = false;
        }
        if (TANTWSZJMQ) {
            changeStateToProcessABlock();
            TANTWSZJMQ = false;
        }
        final int HYQUHLFTIO = VXKMKCJDFF + VSCEGWUVWY;
        int SXKTKHHGNS = VXKMKCJDFF;
        int GLEYYWDDUD = 0;
        for (; (SXKTKHHGNS < HYQUHLFTIO) && ((GLEYYWDDUD = read0()) >= 0);) {
            GRQAGEALFM[SXKTKHHGNS++] = ((byte) (GLEYYWDDUD));
        }
        int BLWZDNWQMK = SXKTKHHGNS - VXKMKCJDFF;
        if (BLWZDNWQMK == 0) {
            // report 'end of block' or 'end of stream'
            BLWZDNWQMK = GLEYYWDDUD;
            VNZOABRKNP = this.skipToNextMarker(CBZip2InputStream.ULXTMBZSNY, CBZip2InputStream.AKVBKXYCKL);
            // Exactly when we are about to start a new block, we advertise the stream position.
            this.KTNMACPRYP = this.VFCPFNGKKN;
            changeStateToProcessABlock();
        }
        return BLWZDNWQMK;
    }

    private int read0() throws IOException {
        final int EPHWSOPUHN = this.DSKXCLYXGG;
        switch (this.RVSUKIXCZM) {
            case EOF :
                return END_OF_STREAM;// return -1

            case NO_PROCESS_STATE :
                return END_OF_BLOCK;// return -2

            case START_BLOCK_STATE :
                throw new IllegalStateException();
            case RAND_PART_A_STATE :
                throw new IllegalStateException();
            case RAND_PART_B_STATE :
                setupRandPartB();
                break;
            case RAND_PART_C_STATE :
                setupRandPartC();
                break;
            case NO_RAND_PART_A_STATE :
                throw new IllegalStateException();
            case NO_RAND_PART_B_STATE :
                setupNoRandPartB();
                break;
            case NO_RAND_PART_C_STATE :
                setupNoRandPartC();
                break;
            default :
                throw new IllegalStateException();
        }
        return EPHWSOPUHN;
    }

    private void init() throws IOException {
        int WRQFRQVDYC = this.readAByte(OXTCHPPCLF);
        if (WRQFRQVDYC != 'h') {
            throw new IOException((("Stream is not BZip2 formatted: expected 'h'" + " as first byte but got '") + ((char) (WRQFRQVDYC))) + "'");
        }
        int IBKHISMDCD = this.readAByte(OXTCHPPCLF);
        if ((IBKHISMDCD < '1') || (IBKHISMDCD > '9')) {
            throw new IOException(("Stream is not BZip2 formatted: illegal " + "blocksize ") + ((char) (IBKHISMDCD)));
        }
        this.AQGNWWOARY = IBKHISMDCD - '0';
        initBlock();
        setupBlock();
    }

    private void initBlock() throws IOException {
        if (this.HTIVKQNAYZ == READ_MODE.BYBLOCK) {
            // this.checkBlockIntegrity();
            this.RDUCDZAICW = bsGetInt();
            this.HWQBVMYEAJ = bsR(1) == 1;
            /**
             * Allocate data here instead in constructor, so we do not allocate
             * it if the input file is empty.
             */
            if (this.PEHVXUAULL == null) {
                this.PEHVXUAULL = new CBZip2InputStream.Data(this.AQGNWWOARY);
            }
            // currBlockNo++;
            getAndMoveToFrontDecode();
            this.UKCCKKHMLA.initialiseCRC();
            this.RVSUKIXCZM = CBZip2InputStream.STATE.START_BLOCK_STATE;
            return;
        }
        char CPKVNTFRYZ = bsGetUByte();
        char SFUNPSVAIP = bsGetUByte();
        char NEDIEFLWHW = bsGetUByte();
        char NAOGBTQFDU = bsGetUByte();
        char WLZLXZWXIR = bsGetUByte();
        char DCOXRAZADI = bsGetUByte();
        if ((((((CPKVNTFRYZ == 0x17) && (SFUNPSVAIP == 0x72)) && (NEDIEFLWHW == 0x45)) && (NAOGBTQFDU == 0x38)) && (WLZLXZWXIR == 0x50)) && (DCOXRAZADI == 0x90)) {
            complete();// end of file

        } else
            // 'Y'
            if ((((((CPKVNTFRYZ != 0x31)// '1'
             || (SFUNPSVAIP != 0x41))// ')'
             || (NEDIEFLWHW != 0x59))// 'Y'
             || (NAOGBTQFDU != 0x26))// '&'
             || (WLZLXZWXIR != 0x53))// 'S'
             || (DCOXRAZADI != 0x59)) {
                this.RVSUKIXCZM = CBZip2InputStream.STATE.EOF;
                throw new IOException("bad block header");
            } else {
                this.RDUCDZAICW = bsGetInt();
                this.HWQBVMYEAJ = bsR(1) == 1;
                /**
                 * Allocate data here instead in constructor, so we do not allocate
                 * it if the input file is empty.
                 */
                if (this.PEHVXUAULL == null) {
                    this.PEHVXUAULL = new CBZip2InputStream.Data(this.AQGNWWOARY);
                }
                // currBlockNo++;
                getAndMoveToFrontDecode();
                this.UKCCKKHMLA.initialiseCRC();
                this.RVSUKIXCZM = CBZip2InputStream.STATE.START_BLOCK_STATE;
            }

    }

    private void endBlock() throws IOException {
        this.GCVVVXRGIL = this.UKCCKKHMLA.getFinalCRC();
        // A bad CRC is considered a fatal error.
        if (this.RDUCDZAICW != this.GCVVVXRGIL) {
            // make next blocks readable without error
            // (repair feature, not yet documented, not tested)
            this.RRKCPHLIBE = (this.JIPEQFPIQN << 1) | (this.JIPEQFPIQN >>> 31);
            this.RRKCPHLIBE ^= this.RDUCDZAICW;
            reportCRCError();
        }
        this.RRKCPHLIBE = (this.RRKCPHLIBE << 1) | (this.RRKCPHLIBE >>> 31);
        this.RRKCPHLIBE ^= this.GCVVVXRGIL;
    }

    private void complete() throws IOException {
        this.JIPEQFPIQN = bsGetInt();
        this.RVSUKIXCZM = CBZip2InputStream.STATE.EOF;
        this.PEHVXUAULL = null;
        if (this.JIPEQFPIQN != this.RRKCPHLIBE) {
            reportCRCError();
        }
    }

    @Override
    public void close() throws IOException {
        InputStream GBRJIEOBYC = this.OXTCHPPCLF;
        if (GBRJIEOBYC != null) {
            try {
                if (GBRJIEOBYC != System.in) {
                    GBRJIEOBYC.close();
                }
            } finally {
                this.PEHVXUAULL = null;
                this.OXTCHPPCLF = null;
            }
        }
    }

    private long bsR(final long MYTSBJYRNI) throws IOException {
        long JGLVWASOUN = this.YGDYQAOAPU;
        long JJACQYHYRE = this.ZKBCOLNKQH;
        if (JGLVWASOUN < MYTSBJYRNI) {
            final InputStream EOVIXKEVUB = this.OXTCHPPCLF;
            do {
                int NFTQCAOYNL = readAByte(EOVIXKEVUB);
                if (NFTQCAOYNL < 0) {
                    throw new IOException("unexpected end of stream");
                }
                JJACQYHYRE = (JJACQYHYRE << 8) | NFTQCAOYNL;
                JGLVWASOUN += 8;
            } while (JGLVWASOUN < MYTSBJYRNI );
            this.ZKBCOLNKQH = JJACQYHYRE;
        }
        this.YGDYQAOAPU = JGLVWASOUN - MYTSBJYRNI;
        return (JJACQYHYRE >> (JGLVWASOUN - MYTSBJYRNI)) & ((1L << MYTSBJYRNI) - 1);
    }

    private boolean bsGetBit() throws IOException {
        long EQIMNGZCEO = this.YGDYQAOAPU;
        long YBNCTSOZQN = this.ZKBCOLNKQH;
        if (EQIMNGZCEO < 1) {
            int AGPGYPYVTV = this.readAByte(OXTCHPPCLF);
            if (AGPGYPYVTV < 0) {
                throw new IOException("unexpected end of stream");
            }
            YBNCTSOZQN = (YBNCTSOZQN << 8) | AGPGYPYVTV;
            EQIMNGZCEO += 8;
            this.ZKBCOLNKQH = YBNCTSOZQN;
        }
        this.YGDYQAOAPU = EQIMNGZCEO - 1;
        return ((YBNCTSOZQN >> (EQIMNGZCEO - 1)) & 1) != 0;
    }

    private char bsGetUByte() throws IOException {
        return ((char) (bsR(8)));
    }

    private int bsGetInt() throws IOException {
        return ((int) ((((((bsR(8) << 8) | bsR(8)) << 8) | bsR(8)) << 8) | bsR(8)));
    }

    /**
     * Called by createHuffmanDecodingTables() exclusively.
     */
    private static void hbCreateDecodeTables(final int[] ZDPMIOMUEB, final int[] ZLONZPDWTX, final int[] QRGHDAPRAH, final char[] OEWBXPEJUP, final int WABWFHEATE, final int BUEVVZDXPC, final int IGCUDJUKXH) {
        for (int BYSVDNIHID = WABWFHEATE, JVMZDSHKRM = 0; BYSVDNIHID <= BUEVVZDXPC; BYSVDNIHID++) {
            for (int CZMXUWMOXG = 0; CZMXUWMOXG < IGCUDJUKXH; CZMXUWMOXG++) {
                if (OEWBXPEJUP[CZMXUWMOXG] == BYSVDNIHID) {
                    QRGHDAPRAH[JVMZDSHKRM++] = CZMXUWMOXG;
                }
            }
        }
        for (int MRFGNXBQSG = MAX_CODE_LEN; (--MRFGNXBQSG) > 0;) {
            ZLONZPDWTX[MRFGNXBQSG] = 0;
            ZDPMIOMUEB[MRFGNXBQSG] = 0;
        }
        for (int OTRDVTJNUP = 0; OTRDVTJNUP < IGCUDJUKXH; OTRDVTJNUP++) {
            ZLONZPDWTX[OEWBXPEJUP[OTRDVTJNUP] + 1]++;
        }
        for (int CPNWBWLNGP = 1, KLMQXILBCJ = ZLONZPDWTX[0]; CPNWBWLNGP < MAX_CODE_LEN; CPNWBWLNGP++) {
            KLMQXILBCJ += ZLONZPDWTX[CPNWBWLNGP];
            ZLONZPDWTX[CPNWBWLNGP] = KLMQXILBCJ;
        }
        for (int WDYFWJVBLE = WABWFHEATE, SSIPLLGXGQ = 0, CJEQQTPSVQ = ZLONZPDWTX[WDYFWJVBLE]; WDYFWJVBLE <= BUEVVZDXPC; WDYFWJVBLE++) {
            final int SFAVUPOJES = ZLONZPDWTX[WDYFWJVBLE + 1];
            SSIPLLGXGQ += SFAVUPOJES - CJEQQTPSVQ;
            CJEQQTPSVQ = SFAVUPOJES;
            ZDPMIOMUEB[WDYFWJVBLE] = SSIPLLGXGQ - 1;
            SSIPLLGXGQ <<= 1;
        }
        for (int BSGYLFWMIC = WABWFHEATE + 1; BSGYLFWMIC <= BUEVVZDXPC; BSGYLFWMIC++) {
            ZLONZPDWTX[BSGYLFWMIC] = ((ZDPMIOMUEB[BSGYLFWMIC - 1] + 1) << 1) - ZLONZPDWTX[BSGYLFWMIC];
        }
    }

    private void recvDecodingTables() throws IOException {
        final CBZip2InputStream.Data QVPUERLBXZ = this.PEHVXUAULL;
        final boolean[] IZRFLBTDQR = QVPUERLBXZ.TQIIMZWNJB;
        final byte[] KGAYBHWMLW = QVPUERLBXZ.EWYGDNYIHO;
        final byte[] GJZSXDDYXM = QVPUERLBXZ.XUGTSTQELR;
        final byte[] BIZFZNZRKA = QVPUERLBXZ.URIRZFXCIG;
        int UGQKKQKXUH = 0;
        /* Receive the mapping table */
        for (int BKDNCHLMRX = 0; BKDNCHLMRX < 16; BKDNCHLMRX++) {
            if (bsGetBit()) {
                UGQKKQKXUH |= 1 << BKDNCHLMRX;
            }
        }
        for (int YOVGIKANZL = 256; (--YOVGIKANZL) >= 0;) {
            IZRFLBTDQR[YOVGIKANZL] = false;
        }
        for (int IQBAMSQDRE = 0; IQBAMSQDRE < 16; IQBAMSQDRE++) {
            if ((UGQKKQKXUH & (1 << IQBAMSQDRE)) != 0) {
                final int GXCDVFVIEO = IQBAMSQDRE << 4;
                for (int DZWUMBBILP = 0; DZWUMBBILP < 16; DZWUMBBILP++) {
                    if (bsGetBit()) {
                        IZRFLBTDQR[GXCDVFVIEO + DZWUMBBILP] = true;
                    }
                }
            }
        }
        makeMaps();
        final int FUNTJHQCXP = this.GHTPOTLPXF + 2;
        /* Now the selectors */
        final int NSACGYTDZY = ((int) (bsR(3)));
        final int IPWEPESUZH = ((int) (bsR(15)));
        for (int STZWMRHZEX = 0; STZWMRHZEX < IPWEPESUZH; STZWMRHZEX++) {
            int ZUFPGTDSTM = 0;
            while (bsGetBit()) {
                ZUFPGTDSTM++;
            } 
            BIZFZNZRKA[STZWMRHZEX] = ((byte) (ZUFPGTDSTM));
        }
        /* Undo the MTF values for the selectors. */
        for (int JEYJMGWGTE = NSACGYTDZY; (--JEYJMGWGTE) >= 0;) {
            KGAYBHWMLW[JEYJMGWGTE] = ((byte) (JEYJMGWGTE));
        }
        for (int UESFLRIRSG = 0; UESFLRIRSG < IPWEPESUZH; UESFLRIRSG++) {
            int OBRMXVPOPF = BIZFZNZRKA[UESFLRIRSG] & 0xff;
            final byte CGEFIOLFCG = KGAYBHWMLW[OBRMXVPOPF];
            while (OBRMXVPOPF > 0) {
                // nearly all times v is zero, 4 in most other cases
                KGAYBHWMLW[OBRMXVPOPF] = KGAYBHWMLW[OBRMXVPOPF - 1];
                OBRMXVPOPF--;
            } 
            KGAYBHWMLW[0] = CGEFIOLFCG;
            GJZSXDDYXM[UESFLRIRSG] = CGEFIOLFCG;
        }
        final char[][] FXUTRTCYXH = QVPUERLBXZ.YCFJKXDMMV;
        /* Now the coding tables */
        for (int ZTCLSSZCRZ = 0; ZTCLSSZCRZ < NSACGYTDZY; ZTCLSSZCRZ++) {
            int KMQZVBSNFI = ((int) (bsR(5)));
            final char[] XRDAWAPPHP = FXUTRTCYXH[ZTCLSSZCRZ];
            for (int ZFHSIKOUUY = 0; ZFHSIKOUUY < FUNTJHQCXP; ZFHSIKOUUY++) {
                while (bsGetBit()) {
                    KMQZVBSNFI += (bsGetBit()) ? -1 : 1;
                } 
                XRDAWAPPHP[ZFHSIKOUUY] = ((char) (KMQZVBSNFI));
            }
        }
        // finally create the Huffman tables
        createHuffmanDecodingTables(FUNTJHQCXP, NSACGYTDZY);
    }

    /**
     * Called by recvDecodingTables() exclusively.
     */
    private void createHuffmanDecodingTables(final int ENEZKMVQZZ, final int UVRAHJIXRL) {
        final CBZip2InputStream.Data RVFUIZSJIM = this.PEHVXUAULL;
        final char[][] QMLLLCSQGF = RVFUIZSJIM.YCFJKXDMMV;
        final int[] OKRSQRPCQI = RVFUIZSJIM.BUTAXXQISZ;
        final int[][] EUPODLVDQN = RVFUIZSJIM.ZDTYVUWVGG;
        final int[][] TSWJQMLAZR = RVFUIZSJIM.UMEXARCAMX;
        final int[][] ZGDWIUVDQW = RVFUIZSJIM.LRDPELOOVO;
        for (int CGTPNILVLM = 0; CGTPNILVLM < UVRAHJIXRL; CGTPNILVLM++) {
            int OYTQFSCDOL = 32;
            int WCBCKFONOE = 0;
            final char[] LSAJQWCYNT = QMLLLCSQGF[CGTPNILVLM];
            for (int YSDDAFPPUI = ENEZKMVQZZ; (--YSDDAFPPUI) >= 0;) {
                final char RZPEQEDJWG = LSAJQWCYNT[YSDDAFPPUI];
                if (RZPEQEDJWG > WCBCKFONOE) {
                    WCBCKFONOE = RZPEQEDJWG;
                }
                if (RZPEQEDJWG < OYTQFSCDOL) {
                    OYTQFSCDOL = RZPEQEDJWG;
                }
            }
            CBZip2InputStream.hbCreateDecodeTables(EUPODLVDQN[CGTPNILVLM], TSWJQMLAZR[CGTPNILVLM], ZGDWIUVDQW[CGTPNILVLM], QMLLLCSQGF[CGTPNILVLM], OYTQFSCDOL, WCBCKFONOE, ENEZKMVQZZ);
            OKRSQRPCQI[CGTPNILVLM] = OYTQFSCDOL;
        }
    }

    private void getAndMoveToFrontDecode() throws IOException {
        this.HOMOANOJZJ = ((int) (bsR(24)));
        recvDecodingTables();
        final InputStream INAMWBVEUN = this.OXTCHPPCLF;
        final CBZip2InputStream.Data HDBPLYEZAK = this.PEHVXUAULL;
        final byte[] XRYGALYMCS = HDBPLYEZAK.WKHBYQUXXS;
        final int[] PVGZTYRMMG = HDBPLYEZAK.VXZHAVROLE;
        final byte[] BGMOZOCURX = HDBPLYEZAK.XUGTSTQELR;
        final byte[] JUPKXAFKIU = HDBPLYEZAK.IKEQVDDELT;
        final char[] ISDRBZWYIA = HDBPLYEZAK.ULXCEIFYDE;
        final int[] MQBWTPCHXF = HDBPLYEZAK.BUTAXXQISZ;
        final int[][] NNPKDOTIHL = HDBPLYEZAK.ZDTYVUWVGG;
        final int[][] WTJTUSCIFI = HDBPLYEZAK.UMEXARCAMX;
        final int[][] IZRPMENDAY = HDBPLYEZAK.LRDPELOOVO;
        final int FUQKEGGXTK = this.AQGNWWOARY * 100000;
        /* Setting up the unzftab entries here is not strictly necessary, but it
        does save having to do it later in a separate pass, and so saves a
        block's worth of cache misses.
         */
        for (int EYYSZGLBOE = 256; (--EYYSZGLBOE) >= 0;) {
            ISDRBZWYIA[EYYSZGLBOE] = ((char) (EYYSZGLBOE));
            PVGZTYRMMG[EYYSZGLBOE] = 0;
        }
        int DLSKPRTWKB = 0;
        int ZZMBDRODSV = G_SIZE - 1;
        final int GFEYJBDYTP = this.GHTPOTLPXF + 1;
        int CJAKMKHSEP = getAndMoveToFrontDecode0(0);
        int VDDDXVGZFJ = ((int) (this.ZKBCOLNKQH));
        int FXOXDOHRAO = ((int) (this.YGDYQAOAPU));
        int LSRXLJTHSC = -1;
        int AHSCOOJWWO = BGMOZOCURX[DLSKPRTWKB] & 0xff;
        int[] SPHAIXMCZU = WTJTUSCIFI[AHSCOOJWWO];
        int[] NRXXOOIESO = NNPKDOTIHL[AHSCOOJWWO];
        int[] UHTSSDFKUM = IZRPMENDAY[AHSCOOJWWO];
        int OVUZUQBJTN = MQBWTPCHXF[AHSCOOJWWO];
        while (CJAKMKHSEP != GFEYJBDYTP) {
            if ((CJAKMKHSEP == RUNA) || (CJAKMKHSEP == RUNB)) {
                int GBBKKODURV = -1;
                for (int GRHZAOZGGD = 1; true; GRHZAOZGGD <<= 1) {
                    if (CJAKMKHSEP == RUNA) {
                        GBBKKODURV += GRHZAOZGGD;
                    } else
                        if (CJAKMKHSEP == RUNB) {
                            GBBKKODURV += GRHZAOZGGD << 1;
                        } else {
                            break;
                        }

                    if (ZZMBDRODSV == 0) {
                        ZZMBDRODSV = G_SIZE - 1;
                        AHSCOOJWWO = BGMOZOCURX[++DLSKPRTWKB] & 0xff;
                        SPHAIXMCZU = WTJTUSCIFI[AHSCOOJWWO];
                        NRXXOOIESO = NNPKDOTIHL[AHSCOOJWWO];
                        UHTSSDFKUM = IZRPMENDAY[AHSCOOJWWO];
                        OVUZUQBJTN = MQBWTPCHXF[AHSCOOJWWO];
                    } else {
                        ZZMBDRODSV--;
                    }
                    int IXSEIABFFN = OVUZUQBJTN;
                    while (FXOXDOHRAO < IXSEIABFFN) {
                        final int VLFNNCAMKQ = readAByte(INAMWBVEUN);
                        if (VLFNNCAMKQ >= 0) {
                            VDDDXVGZFJ = (VDDDXVGZFJ << 8) | VLFNNCAMKQ;
                            FXOXDOHRAO += 8;
                            continue;
                        } else {
                            throw new IOException("unexpected end of stream");
                        }
                    } 
                    long EQRCGXGSYI = (VDDDXVGZFJ >> (FXOXDOHRAO - IXSEIABFFN)) & ((1 << IXSEIABFFN) - 1);
                    FXOXDOHRAO -= IXSEIABFFN;
                    while (EQRCGXGSYI > NRXXOOIESO[IXSEIABFFN]) {
                        IXSEIABFFN++;
                        while (FXOXDOHRAO < 1) {
                            final int TGBUXRPXEM = readAByte(INAMWBVEUN);
                            if (TGBUXRPXEM >= 0) {
                                VDDDXVGZFJ = (VDDDXVGZFJ << 8) | TGBUXRPXEM;
                                FXOXDOHRAO += 8;
                                continue;
                            } else {
                                throw new IOException("unexpected end of stream");
                            }
                        } 
                        FXOXDOHRAO--;
                        EQRCGXGSYI = (EQRCGXGSYI << 1) | ((VDDDXVGZFJ >> FXOXDOHRAO) & 1);
                    } 
                    CJAKMKHSEP = UHTSSDFKUM[((int) (EQRCGXGSYI - SPHAIXMCZU[IXSEIABFFN]))];
                }
                final byte PAGTBLMGMW = JUPKXAFKIU[ISDRBZWYIA[0]];
                PVGZTYRMMG[PAGTBLMGMW & 0xff] += GBBKKODURV + 1;
                while ((GBBKKODURV--) >= 0) {
                    XRYGALYMCS[++LSRXLJTHSC] = PAGTBLMGMW;
                } 
                if (LSRXLJTHSC >= FUQKEGGXTK) {
                    throw new IOException("block overrun");
                }
            } else {
                if ((++LSRXLJTHSC) >= FUQKEGGXTK) {
                    throw new IOException("block overrun");
                }
                final char OPISUNLOGU = ISDRBZWYIA[CJAKMKHSEP - 1];
                PVGZTYRMMG[JUPKXAFKIU[OPISUNLOGU] & 0xff]++;
                XRYGALYMCS[LSRXLJTHSC] = JUPKXAFKIU[OPISUNLOGU];
                /* This loop is hammered during decompression, hence avoid
                native method call overhead of System.arraycopy for very
                small ranges to copy.
                 */
                if (CJAKMKHSEP <= 16) {
                    for (int ZWNXAPHEND = CJAKMKHSEP - 1; ZWNXAPHEND > 0;) {
                        ISDRBZWYIA[ZWNXAPHEND] = ISDRBZWYIA[--ZWNXAPHEND];
                    }
                } else {
                    System.arraycopy(ISDRBZWYIA, 0, ISDRBZWYIA, 1, CJAKMKHSEP - 1);
                }
                ISDRBZWYIA[0] = OPISUNLOGU;
                if (ZZMBDRODSV == 0) {
                    ZZMBDRODSV = G_SIZE - 1;
                    AHSCOOJWWO = BGMOZOCURX[++DLSKPRTWKB] & 0xff;
                    SPHAIXMCZU = WTJTUSCIFI[AHSCOOJWWO];
                    NRXXOOIESO = NNPKDOTIHL[AHSCOOJWWO];
                    UHTSSDFKUM = IZRPMENDAY[AHSCOOJWWO];
                    OVUZUQBJTN = MQBWTPCHXF[AHSCOOJWWO];
                } else {
                    ZZMBDRODSV--;
                }
                int EMQEJRFBDE = OVUZUQBJTN;
                while (FXOXDOHRAO < EMQEJRFBDE) {
                    final int PLLBTVEUXF = readAByte(INAMWBVEUN);
                    if (PLLBTVEUXF >= 0) {
                        VDDDXVGZFJ = (VDDDXVGZFJ << 8) | PLLBTVEUXF;
                        FXOXDOHRAO += 8;
                        continue;
                    } else {
                        throw new IOException("unexpected end of stream");
                    }
                } 
                int PZPTBRTHSR = (VDDDXVGZFJ >> (FXOXDOHRAO - EMQEJRFBDE)) & ((1 << EMQEJRFBDE) - 1);
                FXOXDOHRAO -= EMQEJRFBDE;
                while (PZPTBRTHSR > NRXXOOIESO[EMQEJRFBDE]) {
                    EMQEJRFBDE++;
                    while (FXOXDOHRAO < 1) {
                        final int RKNNKKHJVF = readAByte(INAMWBVEUN);
                        if (RKNNKKHJVF >= 0) {
                            VDDDXVGZFJ = (VDDDXVGZFJ << 8) | RKNNKKHJVF;
                            FXOXDOHRAO += 8;
                            continue;
                        } else {
                            throw new IOException("unexpected end of stream");
                        }
                    } 
                    FXOXDOHRAO--;
                    PZPTBRTHSR = (PZPTBRTHSR << 1) | ((VDDDXVGZFJ >> FXOXDOHRAO) & 1);
                } 
                CJAKMKHSEP = UHTSSDFKUM[PZPTBRTHSR - SPHAIXMCZU[EMQEJRFBDE]];
            }
        } 
        this.FKVBSSEALQ = LSRXLJTHSC;
        this.YGDYQAOAPU = FXOXDOHRAO;
        this.ZKBCOLNKQH = VDDDXVGZFJ;
    }

    private int getAndMoveToFrontDecode0(final int QNCXDXQJEB) throws IOException {
        final InputStream SDQDVLIECM = this.OXTCHPPCLF;
        final CBZip2InputStream.Data ODKGCNUXHA = this.PEHVXUAULL;
        final int CCYRCKQIHA = ODKGCNUXHA.XUGTSTQELR[QNCXDXQJEB] & 0xff;
        final int[] AVCUVILPTG = ODKGCNUXHA.ZDTYVUWVGG[CCYRCKQIHA];
        int UXCIZXAFGE = ODKGCNUXHA.BUTAXXQISZ[CCYRCKQIHA];
        int FDCPXQATPK = ((int) (bsR(UXCIZXAFGE)));
        int MRZCNESBHQ = ((int) (this.YGDYQAOAPU));
        int EOQTAGOFTD = ((int) (this.ZKBCOLNKQH));
        while (FDCPXQATPK > AVCUVILPTG[UXCIZXAFGE]) {
            UXCIZXAFGE++;
            while (MRZCNESBHQ < 1) {
                final int SEFYCNTCIP = readAByte(SDQDVLIECM);
                if (SEFYCNTCIP >= 0) {
                    EOQTAGOFTD = (EOQTAGOFTD << 8) | SEFYCNTCIP;
                    MRZCNESBHQ += 8;
                    continue;
                } else {
                    throw new IOException("unexpected end of stream");
                }
            } 
            MRZCNESBHQ--;
            FDCPXQATPK = (FDCPXQATPK << 1) | ((EOQTAGOFTD >> MRZCNESBHQ) & 1);
        } 
        this.YGDYQAOAPU = MRZCNESBHQ;
        this.ZKBCOLNKQH = EOQTAGOFTD;
        return ODKGCNUXHA.LRDPELOOVO[CCYRCKQIHA][FDCPXQATPK - ODKGCNUXHA.UMEXARCAMX[CCYRCKQIHA][UXCIZXAFGE]];
    }

    private void setupBlock() throws IOException {
        if (this.PEHVXUAULL == null) {
            return;
        }
        final int[] SBCAVZAIKC = this.PEHVXUAULL.LAWYYZYSAG;
        final int[] DNSENLUBOM = this.PEHVXUAULL.initTT(this.FKVBSSEALQ + 1);
        final byte[] IMCZGSXRRS = this.PEHVXUAULL.WKHBYQUXXS;
        SBCAVZAIKC[0] = 0;
        System.arraycopy(this.PEHVXUAULL.VXZHAVROLE, 0, SBCAVZAIKC, 1, 256);
        for (int RUKBAQNGWI = 1, TVDROQNBRX = SBCAVZAIKC[0]; RUKBAQNGWI <= 256; RUKBAQNGWI++) {
            TVDROQNBRX += SBCAVZAIKC[RUKBAQNGWI];
            SBCAVZAIKC[RUKBAQNGWI] = TVDROQNBRX;
        }
        for (int NYNBKORDOM = 0, GAAPDWSERI = this.FKVBSSEALQ; NYNBKORDOM <= GAAPDWSERI; NYNBKORDOM++) {
            DNSENLUBOM[SBCAVZAIKC[IMCZGSXRRS[NYNBKORDOM] & 0xff]++] = NYNBKORDOM;
        }
        if ((this.HOMOANOJZJ < 0) || (this.HOMOANOJZJ >= DNSENLUBOM.length)) {
            throw new IOException("stream corrupted");
        }
        this.SKIDZQQKZX = DNSENLUBOM[this.HOMOANOJZJ];
        this.IRIWXZJFDC = 0;
        this.ZTOJDBMFGB = 0;
        this.IDPKYLSUBF = 256;/* not a char and not EOF */

        if (this.HWQBVMYEAJ) {
            this.NWEPNZXWJE = 0;
            this.HOTUVHSIND = 0;
            setupRandPartA();
        } else {
            setupNoRandPartA();
        }
    }

    private void setupRandPartA() throws IOException {
        if (this.ZTOJDBMFGB <= this.FKVBSSEALQ) {
            this.JASPRKPFFO = this.IDPKYLSUBF;
            int MYROURGZPY = this.PEHVXUAULL.WKHBYQUXXS[this.SKIDZQQKZX] & 0xff;
            this.SKIDZQQKZX = this.PEHVXUAULL.YOAITTERQE[this.SKIDZQQKZX];
            if (this.NWEPNZXWJE == 0) {
                this.NWEPNZXWJE = BZip2Constants.rNums[this.HOTUVHSIND] - 1;
                if ((++this.HOTUVHSIND) == 512) {
                    this.HOTUVHSIND = 0;
                }
            } else {
                this.NWEPNZXWJE--;
            }
            this.IDPKYLSUBF = MYROURGZPY ^= (this.NWEPNZXWJE == 1) ? 1 : 0;
            this.ZTOJDBMFGB++;
            this.DSKXCLYXGG = MYROURGZPY;
            this.RVSUKIXCZM = CBZip2InputStream.STATE.RAND_PART_B_STATE;
            this.UKCCKKHMLA.updateCRC(MYROURGZPY);
        } else {
            endBlock();
            if (HTIVKQNAYZ == READ_MODE.CONTINUOUS) {
                initBlock();
                setupBlock();
            } else
                if (HTIVKQNAYZ == READ_MODE.BYBLOCK) {
                    this.RVSUKIXCZM = CBZip2InputStream.STATE.NO_PROCESS_STATE;
                }

        }
    }

    private void setupNoRandPartA() throws IOException {
        if (this.ZTOJDBMFGB <= this.FKVBSSEALQ) {
            this.JASPRKPFFO = this.IDPKYLSUBF;
            int NMTKDLHKPR = this.PEHVXUAULL.WKHBYQUXXS[this.SKIDZQQKZX] & 0xff;
            this.IDPKYLSUBF = NMTKDLHKPR;
            this.SKIDZQQKZX = this.PEHVXUAULL.YOAITTERQE[this.SKIDZQQKZX];
            this.ZTOJDBMFGB++;
            this.DSKXCLYXGG = NMTKDLHKPR;
            this.RVSUKIXCZM = CBZip2InputStream.STATE.NO_RAND_PART_B_STATE;
            this.UKCCKKHMLA.updateCRC(NMTKDLHKPR);
        } else {
            this.RVSUKIXCZM = CBZip2InputStream.STATE.NO_RAND_PART_A_STATE;
            endBlock();
            if (HTIVKQNAYZ == READ_MODE.CONTINUOUS) {
                initBlock();
                setupBlock();
            } else
                if (HTIVKQNAYZ == READ_MODE.BYBLOCK) {
                    this.RVSUKIXCZM = CBZip2InputStream.STATE.NO_PROCESS_STATE;
                }

        }
    }

    private void setupRandPartB() throws IOException {
        if (this.IDPKYLSUBF != this.JASPRKPFFO) {
            this.RVSUKIXCZM = CBZip2InputStream.STATE.RAND_PART_A_STATE;
            this.IRIWXZJFDC = 1;
            setupRandPartA();
        } else
            if ((++this.IRIWXZJFDC) >= 4) {
                this.EEFLTBBZCV = ((char) (this.PEHVXUAULL.WKHBYQUXXS[this.SKIDZQQKZX] & 0xff));
                this.SKIDZQQKZX = this.PEHVXUAULL.YOAITTERQE[this.SKIDZQQKZX];
                if (this.NWEPNZXWJE == 0) {
                    this.NWEPNZXWJE = BZip2Constants.rNums[this.HOTUVHSIND] - 1;
                    if ((++this.HOTUVHSIND) == 512) {
                        this.HOTUVHSIND = 0;
                    }
                } else {
                    this.NWEPNZXWJE--;
                }
                this.PNSSZPTHHH = 0;
                this.RVSUKIXCZM = CBZip2InputStream.STATE.RAND_PART_C_STATE;
                if (this.NWEPNZXWJE == 1) {
                    this.EEFLTBBZCV ^= 1;
                }
                setupRandPartC();
            } else {
                this.RVSUKIXCZM = CBZip2InputStream.STATE.RAND_PART_A_STATE;
                setupRandPartA();
            }

    }

    private void setupRandPartC() throws IOException {
        if (this.PNSSZPTHHH < this.EEFLTBBZCV) {
            this.DSKXCLYXGG = this.IDPKYLSUBF;
            this.UKCCKKHMLA.updateCRC(this.IDPKYLSUBF);
            this.PNSSZPTHHH++;
        } else {
            this.RVSUKIXCZM = CBZip2InputStream.STATE.RAND_PART_A_STATE;
            this.ZTOJDBMFGB++;
            this.IRIWXZJFDC = 0;
            setupRandPartA();
        }
    }

    private void setupNoRandPartB() throws IOException {
        if (this.IDPKYLSUBF != this.JASPRKPFFO) {
            this.IRIWXZJFDC = 1;
            setupNoRandPartA();
        } else
            if ((++this.IRIWXZJFDC) >= 4) {
                this.EEFLTBBZCV = ((char) (this.PEHVXUAULL.WKHBYQUXXS[this.SKIDZQQKZX] & 0xff));
                this.SKIDZQQKZX = this.PEHVXUAULL.YOAITTERQE[this.SKIDZQQKZX];
                this.PNSSZPTHHH = 0;
                setupNoRandPartC();
            } else {
                setupNoRandPartA();
            }

    }

    private void setupNoRandPartC() throws IOException {
        if (this.PNSSZPTHHH < this.EEFLTBBZCV) {
            int ZUIWTSRISO = this.IDPKYLSUBF;
            this.DSKXCLYXGG = ZUIWTSRISO;
            this.UKCCKKHMLA.updateCRC(ZUIWTSRISO);
            this.PNSSZPTHHH++;
            this.RVSUKIXCZM = CBZip2InputStream.STATE.NO_RAND_PART_C_STATE;
        } else {
            this.ZTOJDBMFGB++;
            this.IRIWXZJFDC = 0;
            setupNoRandPartA();
        }
    }

    private static final class Data extends Object {
        // (with blockSize 900k)
        final boolean[] TQIIMZWNJB = new boolean[256];// 256 byte


        final byte[] IKEQVDDELT = new byte[256];// 256 byte


        final byte[] XUGTSTQELR = new byte[MAX_SELECTORS];// 18002 byte


        final byte[] URIRZFXCIG = new byte[MAX_SELECTORS];// 18002 byte


        /**
         * Freq table collected to save a pass over the data during
         * decompression.
         */
        final int[] VXZHAVROLE = new int[256];// 1024 byte


        final int[][] ZDTYVUWVGG = new int[N_GROUPS][MAX_ALPHA_SIZE];// 6192 byte


        final int[][] UMEXARCAMX = new int[N_GROUPS][MAX_ALPHA_SIZE];// 6192 byte


        final int[][] LRDPELOOVO = new int[N_GROUPS][MAX_ALPHA_SIZE];// 6192 byte


        final int[] BUTAXXQISZ = new int[N_GROUPS];// 24 byte


        final int[] LAWYYZYSAG = new int[257];// 1028 byte


        final char[] ULXCEIFYDE = new char[256];// 512 byte


        final char[][] YCFJKXDMMV = new char[N_GROUPS][MAX_ALPHA_SIZE];// 3096


        // byte
        final byte[] EWYGDNYIHO = new byte[N_GROUPS];// 6 byte


        // ---------------
        // 60798 byte
        int[] YOAITTERQE;// 3600000 byte


        byte[] WKHBYQUXXS;// 900000 byte


        // ---------------
        // 4560782 byte
        // ===============
        Data(int blockSize100k) {
            super();
            this.WKHBYQUXXS = new byte[blockSize100k * BZip2Constants.baseBlockSize];
        }

        /**
         * Initializes the {@link #tt} array.
         *
         * This method is called when the required length of the array is known.
         * I don't initialize it at construction time to avoid unneccessary
         * memory allocation when compressing small files.
         */
        final int[] initTT(int length) {
            int[] ttShadow = this.YOAITTERQE;
            // tt.length should always be >= length, but theoretically
            // it can happen, if the compressor mixed small and large
            // blocks. Normally only the last block will be smaller
            // than others.
            if ((ttShadow == null) || (ttShadow.length < length)) {
                this.YOAITTERQE = ttShadow = new int[length];
            }
            return ttShadow;
        }
    }
}