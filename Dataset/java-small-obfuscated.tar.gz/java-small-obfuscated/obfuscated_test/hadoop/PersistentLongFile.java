/**
 * Class that represents a file on disk which persistently stores
 * a single <code>long</code> value. The file is updated atomically
 * and durably (i.e fsynced).
 */
@InterfaceAudience.Private
public class PersistentLongFile {
    private static final Log HGHYCGANIA = LogFactory.getLog(PersistentLongFile.class);

    private final File NTGYLIJFSS;

    private final long IXOOOVPZNP;

    private long YNMLJGVBOB;

    private boolean ZTVSPXGLEO = false;

    public PersistentLongFile(File FQMRDISBNI, long VAOXKAVACR) {
        this.NTGYLIJFSS = FQMRDISBNI;
        this.IXOOOVPZNP = VAOXKAVACR;
    }

    public long get() throws IOException {
        if (!ZTVSPXGLEO) {
            YNMLJGVBOB = PersistentLongFile.readFile(NTGYLIJFSS, IXOOOVPZNP);
            ZTVSPXGLEO = true;
        }
        return YNMLJGVBOB;
    }

    public void set(long VVZOIVDXXV) throws IOException {
        if ((YNMLJGVBOB != VVZOIVDXXV) || (!ZTVSPXGLEO)) {
            PersistentLongFile.writeFile(NTGYLIJFSS, VVZOIVDXXV);
        }
        YNMLJGVBOB = VVZOIVDXXV;
        ZTVSPXGLEO = true;
    }

    /**
     * Atomically write the given value to the given file, including fsyncing.
     *
     * @param file
     * 		destination file
     * @param val
     * 		value to write
     * @throws IOException
     * 		if the file cannot be written
     */
    public static void writeFile(File HQHDRZLKKP, long RIAMSQYYYP) throws IOException {
        AtomicFileOutputStream KXDJPOGVLQ = new AtomicFileOutputStream(HQHDRZLKKP);
        try {
            KXDJPOGVLQ.write(String.valueOf(RIAMSQYYYP).getBytes(UTF_8));
            KXDJPOGVLQ.write('\n');
            KXDJPOGVLQ.close();
            KXDJPOGVLQ = null;
        } finally {
            if (KXDJPOGVLQ != null) {
                KXDJPOGVLQ.abort();
            }
        }
    }

    public static long readFile(File ORWDVNYOXW, long UZMQMMGSHM) throws IOException {
        long EFQQAYAMAZ = UZMQMMGSHM;
        if (ORWDVNYOXW.exists()) {
            BufferedReader OXSPQLYIPX = new BufferedReader(new InputStreamReader(new FileInputStream(ORWDVNYOXW), Charsets.UTF_8));
            try {
                EFQQAYAMAZ = Long.parseLong(OXSPQLYIPX.readLine());
                OXSPQLYIPX.close();
                OXSPQLYIPX = null;
            } finally {
                IOUtils.cleanup(PersistentLongFile.HGHYCGANIA, OXSPQLYIPX);
            }
        }
        return EFQQAYAMAZ;
    }
}