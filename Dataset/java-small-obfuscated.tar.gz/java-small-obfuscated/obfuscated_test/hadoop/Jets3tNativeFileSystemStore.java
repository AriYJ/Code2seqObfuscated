@InterfaceAudience.Private
@InterfaceStability.Unstable
class Jets3tNativeFileSystemStore implements NativeFileSystemStore {
    private S3Service TRZTKBEKAS;

    private S3Bucket VWLIETDBUK;

    private long DGNTMFZMVB;

    private boolean JFFGFNGGQB;

    private long HSQGRGTXHL;

    static final long OJEXMHFQGZ = ((((long) (5)) * 1024) * 1024) * 1024;

    private String YQUUINRNIE;

    public static final Logger MOGEBBIINE = LoggerFactory.getLogger(Jets3tNativeFileSystemStore.class);

    @Override
    public void initialize(URI ROTCQFWHUF, Configuration RRKQXXKELP) throws IOException {
        S3Credentials WDRMQJPEVM = new S3Credentials();
        WDRMQJPEVM.initialize(ROTCQFWHUF, RRKQXXKELP);
        try {
            AWSCredentials YTZXJVXEVM = new AWSCredentials(WDRMQJPEVM.getAccessKey(), WDRMQJPEVM.getSecretAccessKey());
            this.TRZTKBEKAS = new org.jets3t.service.impl.rest.httpclient.RestS3Service(YTZXJVXEVM);
        } catch (S3ServiceException e) {
            handleException(e);
        }
        JFFGFNGGQB = RRKQXXKELP.getBoolean("fs.s3n.multipart.uploads.enabled", false);
        DGNTMFZMVB = Math.min(RRKQXXKELP.getLong("fs.s3n.multipart.uploads.block.size", (64 * 1024) * 1024), Jets3tNativeFileSystemStore.OJEXMHFQGZ);
        HSQGRGTXHL = Math.min(RRKQXXKELP.getLong("fs.s3n.multipart.copy.block.size", Jets3tNativeFileSystemStore.OJEXMHFQGZ), Jets3tNativeFileSystemStore.OJEXMHFQGZ);
        YQUUINRNIE = RRKQXXKELP.get("fs.s3n.server-side-encryption-algorithm");
        VWLIETDBUK = new S3Bucket(ROTCQFWHUF.getHost());
    }

    @Override
    public void storeFile(String IZDEZSVHRP, File CFKMRGWVYY, byte[] QXRYIFFVGS) throws IOException {
        if (JFFGFNGGQB && (CFKMRGWVYY.length() >= DGNTMFZMVB)) {
            storeLargeFile(IZDEZSVHRP, CFKMRGWVYY, QXRYIFFVGS);
            return;
        }
        BufferedInputStream TNFAJFRYFO = null;
        try {
            TNFAJFRYFO = new BufferedInputStream(new FileInputStream(CFKMRGWVYY));
            S3Object MZAOLNAMSA = new S3Object(IZDEZSVHRP);
            MZAOLNAMSA.setDataInputStream(TNFAJFRYFO);
            MZAOLNAMSA.setContentType("binary/octet-stream");
            MZAOLNAMSA.setContentLength(CFKMRGWVYY.length());
            MZAOLNAMSA.setServerSideEncryptionAlgorithm(YQUUINRNIE);
            if (QXRYIFFVGS != null) {
                MZAOLNAMSA.setMd5Hash(QXRYIFFVGS);
            }
            TRZTKBEKAS.putObject(VWLIETDBUK, MZAOLNAMSA);
        } catch (ServiceException e) {
            handleException(e, IZDEZSVHRP);
        } finally {
            IOUtils.closeStream(TNFAJFRYFO);
        }
    }

    public void storeLargeFile(String VMVJNQJTAE, File CDJUFIQUNG, byte[] GUZPKGIFLP) throws IOException {
        S3Object AZEBPEXCLV = new S3Object(VMVJNQJTAE);
        AZEBPEXCLV.setDataInputFile(CDJUFIQUNG);
        AZEBPEXCLV.setContentType("binary/octet-stream");
        AZEBPEXCLV.setContentLength(CDJUFIQUNG.length());
        AZEBPEXCLV.setServerSideEncryptionAlgorithm(YQUUINRNIE);
        if (GUZPKGIFLP != null) {
            AZEBPEXCLV.setMd5Hash(GUZPKGIFLP);
        }
        List<StorageObject> AMJUPHKHVB = new ArrayList<StorageObject>();
        AMJUPHKHVB.add(AZEBPEXCLV);
        MultipartUtils ZNPTRVRDZV = new MultipartUtils(DGNTMFZMVB);
        try {
            ZNPTRVRDZV.uploadObjects(VWLIETDBUK.getName(), TRZTKBEKAS, AMJUPHKHVB, null);
        } catch (Exception e) {
            handleException(e, VMVJNQJTAE);
        }
    }

    @Override
    public void storeEmptyFile(String GZRRWCRAAA) throws IOException {
        try {
            S3Object QZOTPUVTSC = new S3Object(GZRRWCRAAA);
            QZOTPUVTSC.setDataInputStream(new ByteArrayInputStream(new byte[0]));
            QZOTPUVTSC.setContentType("binary/octet-stream");
            QZOTPUVTSC.setContentLength(0);
            QZOTPUVTSC.setServerSideEncryptionAlgorithm(YQUUINRNIE);
            TRZTKBEKAS.putObject(VWLIETDBUK, QZOTPUVTSC);
        } catch (ServiceException e) {
            handleException(e, GZRRWCRAAA);
        }
    }

    @Override
    public FileMetadata retrieveMetadata(String GMZITDEOAX) throws IOException {
        StorageObject JFYFEJTYOY = null;
        try {
            Jets3tNativeFileSystemStore.MOGEBBIINE.debug("Getting metadata for key: {} from bucket: {}", GMZITDEOAX, VWLIETDBUK.getName());
            JFYFEJTYOY = TRZTKBEKAS.getObjectDetails(VWLIETDBUK.getName(), GMZITDEOAX);
            return new FileMetadata(GMZITDEOAX, JFYFEJTYOY.getContentLength(), JFYFEJTYOY.getLastModifiedDate().getTime());
        } catch (ServiceException e) {
            try {
                // process
                handleException(e, GMZITDEOAX);
                return null;
            } catch (FileNotFoundException fnfe) {
                // and downgrade missing files
                return null;
            }
        } finally {
            if (JFYFEJTYOY != null) {
                JFYFEJTYOY.closeDataInputStream();
            }
        }
    }

    /**
     *
     *
     * @param key
     * 		The key is the object name that is being retrieved from the S3 bucket
     * @return This method returns null if the key is not found
     * @throws IOException
     * 		
     */
    @Override
    public InputStream retrieve(String VENPLXLKRK) throws IOException {
        try {
            Jets3tNativeFileSystemStore.MOGEBBIINE.debug("Getting key: {} from bucket: {}", VENPLXLKRK, VWLIETDBUK.getName());
            S3Object PCREWJGWRM = TRZTKBEKAS.getObject(VWLIETDBUK.getName(), VENPLXLKRK);
            return PCREWJGWRM.getDataInputStream();
        } catch (ServiceException e) {
            handleException(e, VENPLXLKRK);
            return null;// return null if key not found

        }
    }

    /**
     *
     *
     * @param key
     * 		The key is the object name that is being retrieved from the S3 bucket
     * @return This method returns null if the key is not found
     * @throws IOException
     * 		
     */
    @Override
    public InputStream retrieve(String PDHJOGMEHW, long KVCHCXRUWO) throws IOException {
        try {
            Jets3tNativeFileSystemStore.MOGEBBIINE.debug("Getting key: {} from bucket: {} with byteRangeStart: {}", PDHJOGMEHW, VWLIETDBUK.getName(), KVCHCXRUWO);
            S3Object MICZPGAFSG = TRZTKBEKAS.getObject(VWLIETDBUK, PDHJOGMEHW, null, null, null, null, KVCHCXRUWO, null);
            return MICZPGAFSG.getDataInputStream();
        } catch (ServiceException e) {
            handleException(e, PDHJOGMEHW);
            return null;
        }
    }

    @Override
    public PartialListing list(String WGERVAKKXL, int FKPWKPLYQV) throws IOException {
        return list(WGERVAKKXL, FKPWKPLYQV, null, false);
    }

    @Override
    public PartialListing list(String AHKQEGANEV, int HBXVXKNYVP, String WSLNNGUUPJ, boolean VCAOCTCSQI) throws IOException {
        return list(AHKQEGANEV, VCAOCTCSQI ? null : NativeS3FileSystem.PATH_DELIMITER, HBXVXKNYVP, WSLNNGUUPJ);
    }

    /**
     * list objects
     *
     * @param prefix
     * 		prefix
     * @param delimiter
     * 		delimiter
     * @param maxListingLength
     * 		max no. of entries
     * @param priorLastKey
     * 		last key in any previous search
     * @return a list of matches
     * @throws IOException
     * 		on any reported failure
     */
    private PartialListing list(String UEROOSILXQ, String WUGQZUSDSD, int CTKPANCFSL, String LKIRJPBGFN) throws IOException {
        try {
            if ((!UEROOSILXQ.isEmpty()) && (!UEROOSILXQ.endsWith(NativeS3FileSystem.PATH_DELIMITER))) {
                UEROOSILXQ += NativeS3FileSystem.PATH_DELIMITER;
            }
            StorageObjectsChunk HYTHXXOGDY = TRZTKBEKAS.listObjectsChunked(VWLIETDBUK.getName(), UEROOSILXQ, WUGQZUSDSD, CTKPANCFSL, LKIRJPBGFN);
            FileMetadata[] QBODZJAKER = new FileMetadata[HYTHXXOGDY.getObjects().length];
            for (int WJIFDHZPPC = 0; WJIFDHZPPC < QBODZJAKER.length; WJIFDHZPPC++) {
                StorageObject YSZQXYCSNF = HYTHXXOGDY.getObjects()[WJIFDHZPPC];
                QBODZJAKER[WJIFDHZPPC] = new FileMetadata(YSZQXYCSNF.getKey(), YSZQXYCSNF.getContentLength(), YSZQXYCSNF.getLastModifiedDate().getTime());
            }
            return new PartialListing(HYTHXXOGDY.getPriorLastKey(), QBODZJAKER, HYTHXXOGDY.getCommonPrefixes());
        } catch (ServiceException e) {
            handleException(e, UEROOSILXQ);
            return null;// never returned - keep compiler happy

        }
    }

    @Override
    public void delete(String HQLFXTEWUD) throws IOException {
        try {
            Jets3tNativeFileSystemStore.MOGEBBIINE.debug("Deleting key: {} from bucket: {}", HQLFXTEWUD, VWLIETDBUK.getName());
            TRZTKBEKAS.deleteObject(VWLIETDBUK, HQLFXTEWUD);
        } catch (ServiceException e) {
            handleException(e, HQLFXTEWUD);
        }
    }

    public void rename(String MVCZLIVDWU, String HGLDXFKNLS) throws IOException {
        try {
            TRZTKBEKAS.renameObject(VWLIETDBUK.getName(), MVCZLIVDWU, new S3Object(HGLDXFKNLS));
        } catch (ServiceException e) {
            handleException(e, MVCZLIVDWU);
        }
    }

    @Override
    public void copy(String JKUGGZDSCG, String EDTOMFPIBS) throws IOException {
        try {
            if (Jets3tNativeFileSystemStore.MOGEBBIINE.isDebugEnabled()) {
                Jets3tNativeFileSystemStore.MOGEBBIINE.debug((((("Copying srcKey: " + JKUGGZDSCG) + "to dstKey: ") + EDTOMFPIBS) + "in bucket: ") + VWLIETDBUK.getName());
            }
            if (JFFGFNGGQB) {
                S3Object UQBALAJCKF = TRZTKBEKAS.getObjectDetails(VWLIETDBUK, JKUGGZDSCG, null, null, null, null);
                if ((HSQGRGTXHL > 0) && (UQBALAJCKF.getContentLength() > HSQGRGTXHL)) {
                    copyLargeFile(UQBALAJCKF, EDTOMFPIBS);
                    return;
                }
            }
            S3Object KQHQODNRRN = new S3Object(EDTOMFPIBS);
            KQHQODNRRN.setServerSideEncryptionAlgorithm(YQUUINRNIE);
            TRZTKBEKAS.copyObject(VWLIETDBUK.getName(), JKUGGZDSCG, VWLIETDBUK.getName(), KQHQODNRRN, false);
        } catch (ServiceException e) {
            handleException(e, JKUGGZDSCG);
        }
    }

    public void copyLargeFile(S3Object VXRONQXPGT, String XQVOATFDNN) throws IOException {
        try {
            long OWONRJTKZE = (VXRONQXPGT.getContentLength() / HSQGRGTXHL) + ((VXRONQXPGT.getContentLength() % HSQGRGTXHL) > 0 ? 1 : 0);
            MultipartUpload JBTVCMTZYL = TRZTKBEKAS.multipartStartUpload(VWLIETDBUK.getName(), XQVOATFDNN, VXRONQXPGT.getMetadataMap());
            List<MultipartPart> MAFBSVEFQH = new ArrayList<MultipartPart>();
            for (int ZAWJVYMHSI = 0; ZAWJVYMHSI < OWONRJTKZE; ZAWJVYMHSI++) {
                long WQKYAZOOTD = ZAWJVYMHSI * HSQGRGTXHL;
                long UHXSMJOBZU;
                if (ZAWJVYMHSI < (OWONRJTKZE - 1)) {
                    UHXSMJOBZU = HSQGRGTXHL;
                } else {
                    UHXSMJOBZU = VXRONQXPGT.getContentLength() % HSQGRGTXHL;
                    if (UHXSMJOBZU == 0) {
                        UHXSMJOBZU = HSQGRGTXHL;
                    }
                }
                MultipartPart ZTJQLICJXN = TRZTKBEKAS.multipartUploadPartCopy(JBTVCMTZYL, ZAWJVYMHSI + 1, VWLIETDBUK.getName(), VXRONQXPGT.getKey(), null, null, null, null, WQKYAZOOTD, (WQKYAZOOTD + UHXSMJOBZU) - 1, null);
                MAFBSVEFQH.add(ZTJQLICJXN);
            }
            Collections.reverse(MAFBSVEFQH);
            TRZTKBEKAS.multipartCompleteUpload(JBTVCMTZYL, MAFBSVEFQH);
        } catch (ServiceException e) {
            handleException(e, VXRONQXPGT.getKey());
        }
    }

    @Override
    public void purge(String IWZVEFFKUK) throws IOException {
        String FXYWLXVTFT = "";
        try {
            S3Object[] VABNNNBMNF = TRZTKBEKAS.listObjects(VWLIETDBUK.getName(), IWZVEFFKUK, null);
            for (S3Object GIGBFMLJDT : VABNNNBMNF) {
                FXYWLXVTFT = GIGBFMLJDT.getKey();
                TRZTKBEKAS.deleteObject(VWLIETDBUK, FXYWLXVTFT);
            }
        } catch (S3ServiceException e) {
            handleException(e, FXYWLXVTFT);
        }
    }

    @Override
    public void dump() throws IOException {
        StringBuilder MPYDIUUZEU = new StringBuilder("S3 Native Filesystem, ");
        MPYDIUUZEU.append(VWLIETDBUK.getName()).append("\n");
        try {
            S3Object[] ZMGVRXCLEN = TRZTKBEKAS.listObjects(VWLIETDBUK.getName());
            for (S3Object PMFQNWIDRG : ZMGVRXCLEN) {
                MPYDIUUZEU.append(PMFQNWIDRG.getKey()).append("\n");
            }
        } catch (S3ServiceException e) {
            handleException(e);
        }
        System.out.println(MPYDIUUZEU);
    }

    /**
     * Handle any service exception by translating it into an IOException
     *
     * @param e
     * 		exception
     * @throws IOException
     * 		exception -always
     */
    private void handleException(Exception TKTCAPRZSE) throws IOException {
        throw processException(TKTCAPRZSE, TKTCAPRZSE, "");
    }

    /**
     * Handle any service exception by translating it into an IOException
     *
     * @param e
     * 		exception
     * @param key
     * 		key sought from object store
     * @throws IOException
     * 		exception -always
     */
    private void handleException(Exception HQXTWTMACR, String NBEOULTTJM) throws IOException {
        throw processException(HQXTWTMACR, HQXTWTMACR, NBEOULTTJM);
    }

    /**
     * Handle any service exception by translating it into an IOException
     *
     * @param thrown
     * 		exception
     * @param original
     * 		original exception -thrown if no other translation could
     * 		be made
     * @param key
     * 		key sought from object store or "" for undefined
     * @return an exception to throw. If isProcessingCause==true this may be null.
     */
    private IOException processException(Throwable VCKWCAKHIL, Throwable FFRGBDHJDP, String VEISHRZYHL) {
        IOException VGJTNDOWKI;
        if (VCKWCAKHIL.getCause() != null) {
            // recurse down
            VGJTNDOWKI = processException(VCKWCAKHIL.getCause(), FFRGBDHJDP, VEISHRZYHL);
        } else
            if (VCKWCAKHIL instanceof HttpException) {
                // nested HttpException - examine error code and react
                HttpException MROTXMEYQD = ((HttpException) (VCKWCAKHIL));
                String EKOYPFDZUN = MROTXMEYQD.getResponseMessage();
                int MXKNTUQMVY = MROTXMEYQD.getResponseCode();
                String APDKWNRHQE = "s3n://" + VWLIETDBUK.getName();
                String HDEBYUNYRD = String.format("%s : %03d : %s", APDKWNRHQE, MXKNTUQMVY, EKOYPFDZUN);
                String UMFLRNGXER = (!VEISHRZYHL.isEmpty()) ? (APDKWNRHQE + "/") + VEISHRZYHL : HDEBYUNYRD;
                IOException OLLPQNCDLZ;
                switch (MXKNTUQMVY) {
                    case 404 :
                        VGJTNDOWKI = new FileNotFoundException(UMFLRNGXER);
                        break;
                    case 416 :
                        // invalid range
                        VGJTNDOWKI = new EOFException((FSExceptionMessages.CANNOT_SEEK_PAST_EOF + ": ") + UMFLRNGXER);
                        break;
                    case 403 :
                        // forbidden
                        VGJTNDOWKI = new AccessControlException(("Permission denied" + ": ") + UMFLRNGXER);
                        break;
                    default :
                        VGJTNDOWKI = new IOException(HDEBYUNYRD);
                }
                VGJTNDOWKI.initCause(VCKWCAKHIL);
            } else
                if (VCKWCAKHIL instanceof S3ServiceException) {
                    S3ServiceException GZABLIPVAO = ((S3ServiceException) (VCKWCAKHIL));
                    Jets3tNativeFileSystemStore.MOGEBBIINE.debug("S3ServiceException: {}: {} : {}", GZABLIPVAO.getS3ErrorCode(), GZABLIPVAO.getS3ErrorMessage(), GZABLIPVAO, GZABLIPVAO);
                    if ("InvalidRange".equals(GZABLIPVAO.getS3ErrorCode())) {
                        VGJTNDOWKI = new EOFException(FSExceptionMessages.CANNOT_SEEK_PAST_EOF);
                    } else {
                        VGJTNDOWKI = new S3Exception(GZABLIPVAO);
                    }
                } else
                    if (VCKWCAKHIL instanceof ServiceException) {
                        ServiceException CTSLKMJUUB = ((ServiceException) (VCKWCAKHIL));
                        Jets3tNativeFileSystemStore.MOGEBBIINE.debug("S3ServiceException: {}: {} : {}", CTSLKMJUUB.getErrorCode(), CTSLKMJUUB.toString(), CTSLKMJUUB, CTSLKMJUUB);
                        VGJTNDOWKI = new S3Exception(CTSLKMJUUB);
                    } else
                        if (VCKWCAKHIL instanceof IOException) {
                            VGJTNDOWKI = ((IOException) (VCKWCAKHIL));
                        } else {
                            // here there is no exception derived yet.
                            // this means no inner cause, and no translation made yet.
                            // convert the original to an IOException -rather than just the
                            // exception at the base of the tree
                            VGJTNDOWKI = new S3Exception(FFRGBDHJDP);
                        }




        return VGJTNDOWKI;
    }
}