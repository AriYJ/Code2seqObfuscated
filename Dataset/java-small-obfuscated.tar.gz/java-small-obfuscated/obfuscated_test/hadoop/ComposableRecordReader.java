/**
 * Additional operations required of a RecordReader to participate in a join.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public abstract class ComposableRecordReader<K extends WritableComparable<?>, V extends Writable> extends RecordReader<K, V> implements Comparable<ComposableRecordReader<K, ?>> {
    /**
     * Return the position in the collector this class occupies.
     */
    abstract int id();

    /**
     * Return the key this RecordReader would supply on a call to next(K,V)
     */
    abstract K key();

    /**
     * Clone the key at the head of this RecordReader into the object provided.
     */
    abstract void key(K BDDQXMAYTO) throws IOException;

    /**
     * Create instance of key.
     */
    abstract K createKey();

    /**
     * Create instance of value.
     */
    abstract V createValue();

    /**
     * Returns true if the stream is not empty, but provides no guarantee that
     * a call to next(K,V) will succeed.
     */
    abstract boolean hasNext();

    /**
     * Skip key-value pairs with keys less than or equal to the key provided.
     */
    abstract void skip(K DANUVSIZTU) throws IOException, InterruptedException;

    /**
     * While key-value pairs from this RecordReader match the given key, register
     * them with the JoinCollector provided.
     */
    @SuppressWarnings("unchecked")
    abstract void accept(CompositeRecordReader.JoinCollector VNMFOYKZOC, K GJKPRVESHI) throws IOException, InterruptedException;
}