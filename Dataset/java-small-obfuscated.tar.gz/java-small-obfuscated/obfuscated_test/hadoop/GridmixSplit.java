class GridmixSplit extends CombineFileSplit {
    private int VFGFIVTLFH;

    private int JIDOWJLSXO;

    private int EZJZEFLGNZ;

    private int DBQSLMKLQJ;

    private long PIXGWNIDDW;

    private long NKVBSBZWMZ;

    private long MBXOYIIFZB;

    private long LULTIMYHSS;

    private double[] MFCMYOLNNL = new double[0];

    private double[] REYVGIRJBQ = new double[0];

    // Spec for reduces id mod this
    private long[] CBNLBHLABU = new long[0];

    private long[] HAEATSBNTZ = new long[0];

    GridmixSplit() {
        super();
    }

    public GridmixSplit(CombineFileSplit PECQKZKSMX, int RRCKVDUPOY, int GGOTNBKXLC, long GJPWKQSWWC, long WCCECJRCJD, long AEHRRZJJLL, long KMGPRHAPML, double[] DQSIUHNAVY, double[] AMWVAESODA, long[] AOIJOOHAMX, long[] PHBXCUJZFH) throws IOException {
        super(PECQKZKSMX);
        this.VFGFIVTLFH = GGOTNBKXLC;
        this.EZJZEFLGNZ = RRCKVDUPOY;
        DBQSLMKLQJ = DQSIUHNAVY.length;
        this.PIXGWNIDDW = WCCECJRCJD;
        this.NKVBSBZWMZ = AEHRRZJJLL;
        this.MBXOYIIFZB = KMGPRHAPML;
        this.MFCMYOLNNL = DQSIUHNAVY;
        this.REYVGIRJBQ = AMWVAESODA;
        JIDOWJLSXO = AOIJOOHAMX.length;
        this.CBNLBHLABU = AOIJOOHAMX;
        this.HAEATSBNTZ = PHBXCUJZFH;
    }

    public int getId() {
        return VFGFIVTLFH;
    }

    public int getMapCount() {
        return EZJZEFLGNZ;
    }

    public long getInputRecords() {
        return PIXGWNIDDW;
    }

    public long[] getOutputBytes() {
        if (0 == DBQSLMKLQJ) {
            return new long[]{ NKVBSBZWMZ };
        }
        final long[] TBITJETVQN = new long[DBQSLMKLQJ];
        for (int JXFSXNDXYM = 0; JXFSXNDXYM < DBQSLMKLQJ; ++JXFSXNDXYM) {
            TBITJETVQN[JXFSXNDXYM] = Math.round(NKVBSBZWMZ * MFCMYOLNNL[JXFSXNDXYM]);
        }
        return TBITJETVQN;
    }

    public long[] getOutputRecords() {
        if (0 == DBQSLMKLQJ) {
            return new long[]{ MBXOYIIFZB };
        }
        final long[] NALVACIIEZ = new long[DBQSLMKLQJ];
        for (int FAELRIAKFD = 0; FAELRIAKFD < DBQSLMKLQJ; ++FAELRIAKFD) {
            NALVACIIEZ[FAELRIAKFD] = Math.round(MBXOYIIFZB * REYVGIRJBQ[FAELRIAKFD]);
        }
        return NALVACIIEZ;
    }

    public long getReduceBytes(int FJAKEYKDYS) {
        return CBNLBHLABU[FJAKEYKDYS];
    }

    public long getReduceRecords(int XADMOWXDQO) {
        return HAEATSBNTZ[XADMOWXDQO];
    }

    @Override
    public void write(DataOutput KAUGERMIBV) throws IOException {
        super.write(KAUGERMIBV);
        WritableUtils.writeVInt(KAUGERMIBV, VFGFIVTLFH);
        WritableUtils.writeVInt(KAUGERMIBV, EZJZEFLGNZ);
        WritableUtils.writeVLong(KAUGERMIBV, PIXGWNIDDW);
        WritableUtils.writeVLong(KAUGERMIBV, NKVBSBZWMZ);
        WritableUtils.writeVLong(KAUGERMIBV, MBXOYIIFZB);
        WritableUtils.writeVLong(KAUGERMIBV, LULTIMYHSS);
        WritableUtils.writeVInt(KAUGERMIBV, DBQSLMKLQJ);
        for (int PUNKPNGKOJ = 0; PUNKPNGKOJ < DBQSLMKLQJ; ++PUNKPNGKOJ) {
            KAUGERMIBV.writeDouble(MFCMYOLNNL[PUNKPNGKOJ]);
            KAUGERMIBV.writeDouble(REYVGIRJBQ[PUNKPNGKOJ]);
        }
        WritableUtils.writeVInt(KAUGERMIBV, JIDOWJLSXO);
        for (int COULDMXRLO = 0; COULDMXRLO < JIDOWJLSXO; ++COULDMXRLO) {
            WritableUtils.writeVLong(KAUGERMIBV, CBNLBHLABU[COULDMXRLO]);
            WritableUtils.writeVLong(KAUGERMIBV, HAEATSBNTZ[COULDMXRLO]);
        }
    }

    @Override
    public void readFields(DataInput DFWOHYNRPC) throws IOException {
        super.readFields(DFWOHYNRPC);
        VFGFIVTLFH = WritableUtils.readVInt(DFWOHYNRPC);
        EZJZEFLGNZ = WritableUtils.readVInt(DFWOHYNRPC);
        PIXGWNIDDW = WritableUtils.readVLong(DFWOHYNRPC);
        NKVBSBZWMZ = WritableUtils.readVLong(DFWOHYNRPC);
        MBXOYIIFZB = WritableUtils.readVLong(DFWOHYNRPC);
        LULTIMYHSS = WritableUtils.readVLong(DFWOHYNRPC);
        DBQSLMKLQJ = WritableUtils.readVInt(DFWOHYNRPC);
        if (MFCMYOLNNL.length < DBQSLMKLQJ) {
            MFCMYOLNNL = new double[DBQSLMKLQJ];
            REYVGIRJBQ = new double[DBQSLMKLQJ];
        }
        for (int GYLXLNDTUS = 0; GYLXLNDTUS < DBQSLMKLQJ; ++GYLXLNDTUS) {
            MFCMYOLNNL[GYLXLNDTUS] = DFWOHYNRPC.readDouble();
            REYVGIRJBQ[GYLXLNDTUS] = DFWOHYNRPC.readDouble();
        }
        JIDOWJLSXO = WritableUtils.readVInt(DFWOHYNRPC);
        if (CBNLBHLABU.length < JIDOWJLSXO) {
            CBNLBHLABU = new long[JIDOWJLSXO];
            HAEATSBNTZ = new long[JIDOWJLSXO];
        }
        for (int RSFETVVOCQ = 0; RSFETVVOCQ < JIDOWJLSXO; ++RSFETVVOCQ) {
            CBNLBHLABU[RSFETVVOCQ] = WritableUtils.readVLong(DFWOHYNRPC);
            HAEATSBNTZ[RSFETVVOCQ] = WritableUtils.readVLong(DFWOHYNRPC);
        }
    }
}