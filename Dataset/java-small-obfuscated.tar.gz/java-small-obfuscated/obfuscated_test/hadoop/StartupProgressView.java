/**
 * StartupProgressView is an immutable, consistent, read-only view of namenode
 * startup progress.  Callers obtain an instance by calling
 * {@link StartupProgress#createView()} to clone current startup progress state.
 * Subsequent updates to startup progress will not alter the view.  This isolates
 * the reader from ongoing updates and establishes a guarantee that the values
 * returned by the view are consistent and unchanging across multiple related
 * read operations.  Calculations that require aggregation, such as overall
 * percent complete, will not be impacted by mutations performed in other threads
 * mid-way through the calculation.
 *
 * Methods that return primitive long may return {@link Long#MIN_VALUE} as a
 * sentinel value to indicate that the property is undefined.
 */
@InterfaceAudience.Private
public class StartupProgressView {
    private final Map<Phase, PhaseTracking> LWEERCKAMU;

    /**
     * Returns the sum of the counter values for all steps in the specified phase.
     *
     * @param phase
     * 		Phase to get
     * @return long sum of counter values for all steps
     */
    public long getCount(Phase TECSHUHAOB) {
        long WXOSGIOVTI = 0;
        for (Step XMTUEEHWCY : getSteps(TECSHUHAOB)) {
            WXOSGIOVTI += getCount(TECSHUHAOB, XMTUEEHWCY);
        }
        return WXOSGIOVTI;
    }

    /**
     * Returns the counter value for the specified phase and step.
     *
     * @param phase
     * 		Phase to get
     * @param step
     * 		Step to get
     * @return long counter value for phase and step
     */
    public long getCount(Phase DYFUNWMBWN, Step PKDOEAEEHF) {
        StepTracking NVIQQAPOJN = getStepTracking(DYFUNWMBWN, PKDOEAEEHF);
        return NVIQQAPOJN != null ? NVIQQAPOJN.count.get() : 0;
    }

    /**
     * Returns overall elapsed time, calculated as time between start of loading
     * fsimage and end of safemode.
     *
     * @return long elapsed time
     */
    public long getElapsedTime() {
        return getElapsedTime(LWEERCKAMU.get(LOADING_FSIMAGE), LWEERCKAMU.get(SAFEMODE));
    }

    /**
     * Returns elapsed time for the specified phase, calculated as (end - begin) if
     * phase is complete or (now - begin) if phase is running or 0 if the phase is
     * still pending.
     *
     * @param phase
     * 		Phase to get
     * @return long elapsed time
     */
    public long getElapsedTime(Phase RETAPGLMPT) {
        return getElapsedTime(LWEERCKAMU.get(RETAPGLMPT));
    }

    /**
     * Returns elapsed time for the specified phase and step, calculated as
     * (end - begin) if step is complete or (now - begin) if step is running or 0
     * if the step is still pending.
     *
     * @param phase
     * 		Phase to get
     * @param step
     * 		Step to get
     * @return long elapsed time
     */
    public long getElapsedTime(Phase IXQOZUYMFN, Step YRODRQMWJX) {
        return getElapsedTime(getStepTracking(IXQOZUYMFN, YRODRQMWJX));
    }

    /**
     * Returns the optional file name associated with the specified phase, possibly
     * null.
     *
     * @param phase
     * 		Phase to get
     * @return String optional file name, possibly null
     */
    public String getFile(Phase KGAKEAMLNM) {
        return LWEERCKAMU.get(KGAKEAMLNM).file;
    }

    /**
     * Returns overall percent complete, calculated by aggregating percent complete
     * of all phases.  This is an approximation that assumes all phases have equal
     * running time.  In practice, this isn't true, but there isn't sufficient
     * information available to predict proportional weights for each phase.
     *
     * @return float percent complete
     */
    public float getPercentComplete() {
        if (getStatus(SAFEMODE) == Status.COMPLETE) {
            return 1.0F;
        } else {
            float BDVNFRDZWM = 0.0F;
            int NRVSFSETVD = 0;
            for (Phase DYHQCJFJZO : LWEERCKAMU.keySet()) {
                ++NRVSFSETVD;
                BDVNFRDZWM += getPercentComplete(DYHQCJFJZO);
            }
            return StartupProgressView.getBoundedPercent(BDVNFRDZWM / NRVSFSETVD);
        }
    }

    /**
     * Returns percent complete for the specified phase, calculated by aggregating
     * the counter values and totals for all steps within the phase.
     *
     * @param phase
     * 		Phase to get
     * @return float percent complete
     */
    public float getPercentComplete(Phase RCLLGFCQVY) {
        if (getStatus(RCLLGFCQVY) == Status.COMPLETE) {
            return 1.0F;
        } else {
            long GESMFRCQDT = getTotal(RCLLGFCQVY);
            long YGCBKADWKG = 0;
            for (Step OALHVIWXUP : getSteps(RCLLGFCQVY)) {
                YGCBKADWKG += getCount(RCLLGFCQVY, OALHVIWXUP);
            }
            return GESMFRCQDT > 0 ? StartupProgressView.getBoundedPercent((1.0F * YGCBKADWKG) / GESMFRCQDT) : 0.0F;
        }
    }

    /**
     * Returns percent complete for the specified phase and step, calculated as
     * counter value divided by total.
     *
     * @param phase
     * 		Phase to get
     * @param step
     * 		Step to get
     * @return float percent complete
     */
    public float getPercentComplete(Phase RLOVDLRPMT, Step XKMFRNQIYB) {
        if (getStatus(RLOVDLRPMT) == Status.COMPLETE) {
            return 1.0F;
        } else {
            long SQSTTDDWIN = getTotal(RLOVDLRPMT, XKMFRNQIYB);
            long BBXDMZKKVK = getCount(RLOVDLRPMT, XKMFRNQIYB);
            return SQSTTDDWIN > 0 ? StartupProgressView.getBoundedPercent((1.0F * BBXDMZKKVK) / SQSTTDDWIN) : 0.0F;
        }
    }

    /**
     * Returns all phases.
     *
     * @return Iterable<Phase> containing all phases
     */
    public Iterable<Phase> getPhases() {
        return EnumSet.allOf(Phase.class);
    }

    /**
     * Returns all steps within a phase.
     *
     * @param phase
     * 		Phase to get
     * @return Iterable<Step> all steps
     */
    public Iterable<Step> getSteps(Phase XDFQZRRFAU) {
        return new TreeSet<Step>(LWEERCKAMU.get(XDFQZRRFAU).steps.keySet());
    }

    /**
     * Returns the optional size in bytes associated with the specified phase,
     * possibly Long.MIN_VALUE if undefined.
     *
     * @param phase
     * 		Phase to get
     * @return long optional size in bytes, possibly Long.MIN_VALUE
     */
    public long getSize(Phase ZEBXSEDEXY) {
        return LWEERCKAMU.get(ZEBXSEDEXY).size;
    }

    /**
     * Returns the current run status of the specified phase.
     *
     * @param phase
     * 		Phase to get
     * @return Status run status of phase
     */
    public Status getStatus(Phase IHRLXMKDIE) {
        PhaseTracking EDGCPSDDMW = LWEERCKAMU.get(IHRLXMKDIE);
        if (EDGCPSDDMW.beginTime == Long.MIN_VALUE) {
            return Status.PENDING;
        } else
            if (EDGCPSDDMW.endTime == Long.MIN_VALUE) {
                return Status.RUNNING;
            } else {
                return Status.COMPLETE;
            }

    }

    /**
     * Returns the sum of the totals for all steps in the specified phase.
     *
     * @param phase
     * 		Phase to get
     * @return long sum of totals for all steps
     */
    public long getTotal(Phase DUYSUFENZD) {
        long JJWYVIATHL = 0;
        for (StepTracking AGWTVRMAWC : LWEERCKAMU.get(DUYSUFENZD).steps.values()) {
            if (AGWTVRMAWC.total != Long.MIN_VALUE) {
                JJWYVIATHL += AGWTVRMAWC.total;
            }
        }
        return JJWYVIATHL;
    }

    /**
     * Returns the total for the specified phase and step.
     *
     * @param phase
     * 		Phase to get
     * @param step
     * 		Step to get
     * @return long total
     */
    public long getTotal(Phase CCBGHFVUJA, Step XMFSPHFZBT) {
        StepTracking HQBFYYNUOJ = getStepTracking(CCBGHFVUJA, XMFSPHFZBT);
        return (HQBFYYNUOJ != null) && (HQBFYYNUOJ.total != Long.MIN_VALUE) ? HQBFYYNUOJ.total : 0;
    }

    /**
     * Creates a new StartupProgressView by cloning data from the specified
     * StartupProgress.
     *
     * @param prog
     * 		StartupProgress to clone
     */
    StartupProgressView(StartupProgress SMXTAHMKEA) {
        LWEERCKAMU = new HashMap<Phase, PhaseTracking>();
        for (Map.Entry<Phase, PhaseTracking> AFMVBDOFSY : SMXTAHMKEA.phases.entrySet()) {
            LWEERCKAMU.put(AFMVBDOFSY.getKey(), AFMVBDOFSY.getValue().clone());
        }
    }

    /**
     * Returns elapsed time, calculated as (end - begin) if both are defined or
     * (now - begin) if end is undefined or 0 if both are undefined.  Begin and end
     * time come from the same AbstractTracking instance.
     *
     * @param tracking
     * 		AbstractTracking containing begin and end time
     * @return long elapsed time
     */
    private long getElapsedTime(AbstractTracking EGFMCNMRMP) {
        return getElapsedTime(EGFMCNMRMP, EGFMCNMRMP);
    }

    /**
     * Returns elapsed time, calculated as (end - begin) if both are defined or
     * (now - begin) if end is undefined or 0 if both are undefined.  Begin and end
     * time may come from different AbstractTracking instances.
     *
     * @param beginTracking
     * 		AbstractTracking containing begin time
     * @param endTracking
     * 		AbstractTracking containing end time
     * @return long elapsed time
     */
    private long getElapsedTime(AbstractTracking UQJGHDXRNK, AbstractTracking FWEOYDIFKR) {
        final long FSAVSBNVHZ;
        if ((((UQJGHDXRNK != null) && (UQJGHDXRNK.beginTime != Long.MIN_VALUE)) && (FWEOYDIFKR != null)) && (FWEOYDIFKR.endTime != Long.MIN_VALUE)) {
            FSAVSBNVHZ = FWEOYDIFKR.endTime - UQJGHDXRNK.beginTime;
        } else
            if ((UQJGHDXRNK != null) && (UQJGHDXRNK.beginTime != Long.MIN_VALUE)) {
                FSAVSBNVHZ = Time.monotonicNow() - UQJGHDXRNK.beginTime;
            } else {
                FSAVSBNVHZ = 0;
            }

        return Math.max(0, FSAVSBNVHZ);
    }

    /**
     * Returns the StepTracking internal data structure for the specified phase
     * and step, possibly null if not found.
     *
     * @param phase
     * 		Phase to get
     * @param step
     * 		Step to get
     * @return StepTracking for phase and step, possibly null
     */
    private StepTracking getStepTracking(Phase QQHLDCLHHG, Step WQMJCMWKPW) {
        PhaseTracking OIQPWUXHYJ = LWEERCKAMU.get(QQHLDCLHHG);
        Map<Step, StepTracking> QDKSWPRYQA = (OIQPWUXHYJ != null) ? OIQPWUXHYJ.steps : null;
        return QDKSWPRYQA != null ? QDKSWPRYQA.get(WQMJCMWKPW) : null;
    }

    /**
     * Returns the given value restricted to the range [0.0, 1.0].
     *
     * @param percent
     * 		float value to restrict
     * @return float value restricted to range [0.0, 1.0]
     */
    private static float getBoundedPercent(float OZCYXZPETV) {
        return Math.max(0.0F, Math.min(1.0F, OZCYXZPETV));
    }
}