public class CMgrCompletedAppsEvent extends ContainerManagerEvent {
    private final List<ApplicationId> QIIKGOHHFO;

    private final CMgrCompletedAppsEvent.Reason CEOOFANVQV;

    public CMgrCompletedAppsEvent(List<ApplicationId> YQAMJILSAV, CMgrCompletedAppsEvent.Reason JRLQMDCTKM) {
        super(FINISH_APPS);
        this.QIIKGOHHFO = YQAMJILSAV;
        this.CEOOFANVQV = JRLQMDCTKM;
    }

    public List<ApplicationId> getAppsToCleanup() {
        return this.QIIKGOHHFO;
    }

    public CMgrCompletedAppsEvent.Reason getReason() {
        return CEOOFANVQV;
    }

    public static enum Reason {

        /**
         * Application is killed as NodeManager is shut down
         */
        ON_SHUTDOWN,
        /**
         * Application is killed by ResourceManager
         */
        BY_RESOURCEMANAGER;}
}