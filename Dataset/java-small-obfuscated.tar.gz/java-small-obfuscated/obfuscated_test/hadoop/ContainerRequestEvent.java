public class ContainerRequestEvent extends ContainerAllocatorEvent {
    private final Resource IYMTBTRANG;

    private final String[] WWBQDKNMYK;

    private final String[] TELIMPRSEY;

    private boolean LVLUHUBAPN = false;

    public ContainerRequestEvent(TaskAttemptId LWAVVAAIGG, Resource ZUQKVFTTEQ, String[] VNVQONALPW, String[] XZKRYYDSNX) {
        super(LWAVVAAIGG, CONTAINER_REQ);
        this.IYMTBTRANG = ZUQKVFTTEQ;
        this.WWBQDKNMYK = VNVQONALPW;
        this.TELIMPRSEY = XZKRYYDSNX;
    }

    ContainerRequestEvent(TaskAttemptId SUPNBWNCRV, Resource PSGGMXYCGF) {
        this(SUPNBWNCRV, PSGGMXYCGF, new String[0], new String[0]);
        this.LVLUHUBAPN = true;
    }

    public static ContainerRequestEvent createContainerRequestEventForFailedContainer(TaskAttemptId VNZJGNMCUO, Resource GZFEEIYUZK) {
        // ContainerRequest for failed events does not consider rack / node locality?
        return new ContainerRequestEvent(VNZJGNMCUO, GZFEEIYUZK);
    }

    public Resource getCapability() {
        return IYMTBTRANG;
    }

    public String[] getHosts() {
        return WWBQDKNMYK;
    }

    public String[] getRacks() {
        return TELIMPRSEY;
    }

    public boolean getEarlierAttemptFailed() {
        return LVLUHUBAPN;
    }
}