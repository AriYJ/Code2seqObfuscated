/**
 * <p>
 * The response sent by the <code>ResourceManager</code> to a client requesting
 * a list of {@link ContainerReport} for containers.
 * </p>
 *
 * <p>
 * The <code>ContainerReport</code> for each container includes the container
 * details.
 * </p>
 *
 * @see ContainerReport
 * @see ApplicationHistoryProtocol#getContainers(GetContainersRequest)
 */
@Public
@Unstable
public abstract class GetContainersResponse {
    @Public
    @Unstable
    public static GetContainersResponse newInstance(List<ContainerReport> JWAAHICLQB) {
        GetContainersResponse RBEHEQZPJW = Records.newRecord(GetContainersResponse.class);
        RBEHEQZPJW.setContainerList(JWAAHICLQB);
        return RBEHEQZPJW;
    }

    /**
     * Get a list of <code>ContainerReport</code> for all the containers of an
     * application attempt.
     *
     * @return a list of <code>ContainerReport</code> for all the containers of an
    application attempt
     */
    @Public
    @Unstable
    public abstract List<ContainerReport> getContainerList();

    /**
     * Set a list of <code>ContainerReport</code> for all the containers of an
     * application attempt.
     *
     * @param containers
     * 		a list of <code>ContainerReport</code> for all the containers of
     * 		an application attempt
     */
    @Public
    @Unstable
    public abstract void setContainerList(List<ContainerReport> GCBQCONXMQ);
}