@InterfaceAudience.Private
@InterfaceStability.Evolving
public class DSQuotaExceededException extends QuotaExceededException {
    protected static final long ZEAMFKANNA = 1L;

    public DSQuotaExceededException() {
    }

    public DSQuotaExceededException(String QVERABCQVJ) {
        super(QVERABCQVJ);
    }

    public DSQuotaExceededException(long IKROUDUUIO, long FBVACHJHEW) {
        super(IKROUDUUIO, FBVACHJHEW);
    }

    @Override
    public String getMessage() {
        String BDXSEBOVKH = super.getMessage();
        if (BDXSEBOVKH == null) {
            return (((((((("The DiskSpace quota" + (pathName == null ? "" : " of " + pathName)) + " is exceeded: quota = ") + quota) + " B = ") + long2String(quota, "B", 2)) + " but diskspace consumed = ") + count) + " B = ") + long2String(count, "B", 2);
        } else {
            return BDXSEBOVKH;
        }
    }
}