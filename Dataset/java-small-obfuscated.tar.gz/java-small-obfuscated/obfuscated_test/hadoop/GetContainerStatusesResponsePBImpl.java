@Private
@Unstable
public class GetContainerStatusesResponsePBImpl extends GetContainerStatusesResponse {
    GetContainerStatusesResponseProto CUDRUNNEWZ = GetContainerStatusesResponseProto.getDefaultInstance();

    Builder SVPZWBOAZY = null;

    boolean ONWKLHVXAZ = false;

    private List<ContainerStatus> UNKYATQVNC = null;

    private Map<ContainerId, SerializedException> LERBSXDERT = null;

    public GetContainerStatusesResponsePBImpl() {
        SVPZWBOAZY = GetContainerStatusesResponseProto.newBuilder();
    }

    public GetContainerStatusesResponsePBImpl(GetContainerStatusesResponseProto YLYSVABQMB) {
        this.CUDRUNNEWZ = YLYSVABQMB;
        ONWKLHVXAZ = true;
    }

    public GetContainerStatusesResponseProto getProto() {
        mergeLocalToProto();
        CUDRUNNEWZ = (ONWKLHVXAZ) ? CUDRUNNEWZ : SVPZWBOAZY.build();
        ONWKLHVXAZ = true;
        return CUDRUNNEWZ;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object CCRWUZZCLE) {
        if (CCRWUZZCLE == null)
            return false;

        if (CCRWUZZCLE.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(CCRWUZZCLE).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }

    private void mergeLocalToBuilder() {
        if (this.UNKYATQVNC != null) {
            addLocalContainerStatusesToProto();
        }
        if (this.LERBSXDERT != null) {
            addFailedRequestsToProto();
        }
    }

    private void mergeLocalToProto() {
        if (ONWKLHVXAZ)
            maybeInitBuilder();

        mergeLocalToBuilder();
        CUDRUNNEWZ = SVPZWBOAZY.build();
        ONWKLHVXAZ = true;
    }

    private void maybeInitBuilder() {
        if (ONWKLHVXAZ || (SVPZWBOAZY == null)) {
            SVPZWBOAZY = GetContainerStatusesResponseProto.newBuilder(CUDRUNNEWZ);
        }
        ONWKLHVXAZ = false;
    }

    private void addLocalContainerStatusesToProto() {
        maybeInitBuilder();
        SVPZWBOAZY.clearStatus();
        if (this.UNKYATQVNC == null)
            return;

        List<ContainerStatusProto> KTRYMLXAMD = new ArrayList<ContainerStatusProto>();
        for (ContainerStatus KPXZEJAWRO : UNKYATQVNC) {
            KTRYMLXAMD.add(convertToProtoFormat(KPXZEJAWRO));
        }
        SVPZWBOAZY.addAllStatus(KTRYMLXAMD);
    }

    private void addFailedRequestsToProto() {
        maybeInitBuilder();
        SVPZWBOAZY.clearFailedRequests();
        if (this.LERBSXDERT == null)
            return;

        List<ContainerExceptionMapProto> PADCGMZZJV = new ArrayList<ContainerExceptionMapProto>();
        for (Map.Entry<ContainerId, SerializedException> GTXJERUMIN : this.LERBSXDERT.entrySet()) {
            PADCGMZZJV.add(ContainerExceptionMapProto.newBuilder().setContainerId(convertToProtoFormat(GTXJERUMIN.getKey())).setException(convertToProtoFormat(GTXJERUMIN.getValue())).build());
        }
        SVPZWBOAZY.addAllFailedRequests(PADCGMZZJV);
    }

    private void initLocalContainerStatuses() {
        if (this.UNKYATQVNC != null) {
            return;
        }
        GetContainerStatusesResponseProtoOrBuilder CSZQIBQOEM = (ONWKLHVXAZ) ? CUDRUNNEWZ : SVPZWBOAZY;
        List<ContainerStatusProto> GZNLRZRITZ = CSZQIBQOEM.getStatusList();
        this.UNKYATQVNC = new ArrayList<ContainerStatus>();
        for (ContainerStatusProto YQQUELNEIW : GZNLRZRITZ) {
            this.UNKYATQVNC.add(convertFromProtoFormat(YQQUELNEIW));
        }
    }

    private void initFailedRequests() {
        if (this.LERBSXDERT != null) {
            return;
        }
        GetContainerStatusesResponseProtoOrBuilder KPHDSJTDOS = (ONWKLHVXAZ) ? CUDRUNNEWZ : SVPZWBOAZY;
        List<ContainerExceptionMapProto> CMPBCBCHAO = KPHDSJTDOS.getFailedRequestsList();
        this.LERBSXDERT = new HashMap<ContainerId, SerializedException>();
        for (ContainerExceptionMapProto QAPLBVZKVM : CMPBCBCHAO) {
            this.LERBSXDERT.put(convertFromProtoFormat(QAPLBVZKVM.getContainerId()), convertFromProtoFormat(QAPLBVZKVM.getException()));
        }
    }

    @Override
    public List<ContainerStatus> getContainerStatuses() {
        initLocalContainerStatuses();
        return this.UNKYATQVNC;
    }

    @Override
    public void setContainerStatuses(List<ContainerStatus> OWFVSGHLUP) {
        maybeInitBuilder();
        if (OWFVSGHLUP == null)
            SVPZWBOAZY.clearStatus();

        this.UNKYATQVNC = OWFVSGHLUP;
    }

    @Override
    public Map<ContainerId, SerializedException> getFailedRequests() {
        initFailedRequests();
        return this.LERBSXDERT;
    }

    @Override
    public void setFailedRequests(Map<ContainerId, SerializedException> EETIBFPBGQ) {
        maybeInitBuilder();
        if (EETIBFPBGQ == null)
            SVPZWBOAZY.clearFailedRequests();

        this.LERBSXDERT = EETIBFPBGQ;
    }

    private ContainerStatusPBImpl convertFromProtoFormat(ContainerStatusProto NQFSOTREAO) {
        return new ContainerStatusPBImpl(NQFSOTREAO);
    }

    private ContainerStatusProto convertToProtoFormat(ContainerStatus NFWJWXGKKP) {
        return ((ContainerStatusPBImpl) (NFWJWXGKKP)).getProto();
    }

    private ContainerIdPBImpl convertFromProtoFormat(ContainerIdProto MWBEOOZDRU) {
        return new ContainerIdPBImpl(MWBEOOZDRU);
    }

    private ContainerIdProto convertToProtoFormat(ContainerId FZECVCGZAT) {
        return ((ContainerIdPBImpl) (FZECVCGZAT)).getProto();
    }

    private SerializedExceptionPBImpl convertFromProtoFormat(SerializedExceptionProto KKADZFGUEL) {
        return new SerializedExceptionPBImpl(KKADZFGUEL);
    }

    private SerializedExceptionProto convertToProtoFormat(SerializedException UKXDEZFUNB) {
        return ((SerializedExceptionPBImpl) (UKXDEZFUNB)).getProto();
    }
}