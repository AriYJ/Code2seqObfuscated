public class NodesListManagerEvent extends AbstractEvent<NodesListManagerEventType> {
    private final RMNode VCVVNLUFRT;

    public NodesListManagerEvent(NodesListManagerEventType CYVSHZUGXN, RMNode NZJIZVTJJF) {
        super(CYVSHZUGXN);
        this.VCVVNLUFRT = NZJIZVTJJF;
    }

    public RMNode getNode() {
        return VCVVNLUFRT;
    }
}