/**
 * Deserialized for records that reads typed bytes.
 */
public class TypedBytesRecordOutput implements RecordOutput {
    private TypedBytesOutput QVFTPHRVPU;

    private TypedBytesRecordOutput() {
    }

    private void setTypedBytesOutput(TypedBytesOutput RXQYWYSHFM) {
        this.QVFTPHRVPU = RXQYWYSHFM;
    }

    private static ThreadLocal BXBEKWBIUO = new ThreadLocal() {
        protected synchronized Object initialValue() {
            return new TypedBytesRecordOutput();
        }
    };

    /**
     * Get a thread-local typed bytes record input for the supplied
     * {@link TypedBytesOutput}.
     *
     * @param out
     * 		typed bytes output object
     * @return typed bytes record output corresponding to the supplied
    {@link TypedBytesOutput}.
     */
    public static TypedBytesRecordOutput get(TypedBytesOutput YDEZMDYMNB) {
        TypedBytesRecordOutput KNUZMTUDVV = ((TypedBytesRecordOutput) (TypedBytesRecordOutput.BXBEKWBIUO.get()));
        KNUZMTUDVV.setTypedBytesOutput(YDEZMDYMNB);
        return KNUZMTUDVV;
    }

    /**
     * Get a thread-local typed bytes record output for the supplied
     * {@link DataOutput}.
     *
     * @param out
     * 		data output object
     * @return typed bytes record output corresponding to the supplied
    {@link DataOutput}.
     */
    public static TypedBytesRecordOutput get(DataOutput KSTTTCCIZP) {
        return TypedBytesRecordOutput.get(TypedBytesOutput.get(KSTTTCCIZP));
    }

    /**
     * Creates a new instance of TypedBytesRecordOutput.
     */
    public TypedBytesRecordOutput(TypedBytesOutput HYWYXHVEFB) {
        this.QVFTPHRVPU = HYWYXHVEFB;
    }

    /**
     * Creates a new instance of TypedBytesRecordOutput.
     */
    public TypedBytesRecordOutput(DataOutput PAWBXBOEKA) {
        this(new TypedBytesOutput(PAWBXBOEKA));
    }

    public void writeBool(boolean RYSYLPTZJH, String RAYFKOOXTP) throws IOException {
        QVFTPHRVPU.writeBool(RYSYLPTZJH);
    }

    public void writeBuffer(Buffer EIENAYLPQU, String GHRCGBWAQY) throws IOException {
        QVFTPHRVPU.writeBytes(EIENAYLPQU.get());
    }

    public void writeByte(byte NIBFJMUOUW, String EZMNZMNBGU) throws IOException {
        QVFTPHRVPU.writeByte(NIBFJMUOUW);
    }

    public void writeDouble(double QCZZDGVLFZ, String EGWIBTDZHV) throws IOException {
        QVFTPHRVPU.writeDouble(QCZZDGVLFZ);
    }

    public void writeFloat(float AYXSVLGLEQ, String VMRFCAZZHB) throws IOException {
        QVFTPHRVPU.writeFloat(AYXSVLGLEQ);
    }

    public void writeInt(int DOVMBQNOWV, String KSPNGANJSV) throws IOException {
        QVFTPHRVPU.writeInt(DOVMBQNOWV);
    }

    public void writeLong(long CIHZAUZKIZ, String LJMQNTGSII) throws IOException {
        QVFTPHRVPU.writeLong(CIHZAUZKIZ);
    }

    public void writeString(String HDCNKGWWMJ, String NRTAEYHIKU) throws IOException {
        QVFTPHRVPU.writeString(HDCNKGWWMJ);
    }

    public void startRecord(Record KQAWPXPFPR, String KNGGBSRCQQ) throws IOException {
        QVFTPHRVPU.writeListHeader();
    }

    public void startVector(ArrayList VPBUKNOPVI, String IJMKLSXLUA) throws IOException {
        QVFTPHRVPU.writeVectorHeader(VPBUKNOPVI.size());
    }

    public void startMap(TreeMap TIQUOSIDWW, String BXHKBKRSDW) throws IOException {
        QVFTPHRVPU.writeMapHeader(TIQUOSIDWW.size());
    }

    public void endRecord(Record NBPDPKRKIN, String PCWOESCOBR) throws IOException {
        QVFTPHRVPU.writeListFooter();
    }

    public void endVector(ArrayList ZUVORNUSFY, String FDEDHWUAYA) throws IOException {
    }

    public void endMap(TreeMap RCVHLSXAIH, String SFDTLBJHPI) throws IOException {
    }
}