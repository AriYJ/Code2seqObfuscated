public class JobCommitCompletedEvent extends JobEvent {
    public JobCommitCompletedEvent(JobId KIVQVRFOSX) {
        super(KIVQVRFOSX, JOB_COMMIT_COMPLETED);
    }
}