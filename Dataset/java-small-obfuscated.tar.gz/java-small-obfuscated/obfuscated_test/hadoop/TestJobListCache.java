public class TestJobListCache {
    @Test(timeout = 1000)
    public void testAddExisting() {
        JobListCache DYGIPZBKTR = new JobListCache(2, 1000);
        JobId JMEFPBZOCU = MRBuilderUtils.newJobId(1, 1, 1);
        HistoryFileInfo NZWDWLKWTO = Mockito.mock(HistoryFileInfo.class);
        Mockito.when(NZWDWLKWTO.getJobId()).thenReturn(JMEFPBZOCU);
        DYGIPZBKTR.addIfAbsent(NZWDWLKWTO);
        DYGIPZBKTR.addIfAbsent(NZWDWLKWTO);
        assertEquals("Incorrect number of cache entries", 1, DYGIPZBKTR.values().size());
    }

    @Test(timeout = 1000)
    public void testEviction() throws InterruptedException {
        int MPEDTFHERX = 2;
        JobListCache HNVPJKVCDP = new JobListCache(MPEDTFHERX, 1000);
        JobId YBFKUNOPLR = MRBuilderUtils.newJobId(1, 1, 1);
        HistoryFileInfo UVQQILFGIH = Mockito.mock(HistoryFileInfo.class);
        Mockito.when(UVQQILFGIH.getJobId()).thenReturn(YBFKUNOPLR);
        JobId MDRGHYXYKC = MRBuilderUtils.newJobId(2, 2, 2);
        HistoryFileInfo TIIJCRUDTD = Mockito.mock(HistoryFileInfo.class);
        Mockito.when(TIIJCRUDTD.getJobId()).thenReturn(MDRGHYXYKC);
        JobId FKBVDHNZFR = MRBuilderUtils.newJobId(3, 3, 3);
        HistoryFileInfo ZYVZUQGJMB = Mockito.mock(HistoryFileInfo.class);
        Mockito.when(ZYVZUQGJMB.getJobId()).thenReturn(FKBVDHNZFR);
        HNVPJKVCDP.addIfAbsent(UVQQILFGIH);
        HNVPJKVCDP.addIfAbsent(TIIJCRUDTD);
        HNVPJKVCDP.addIfAbsent(ZYVZUQGJMB);
        Collection<HistoryFileInfo> ECGUTMCXHG;
        for (int NMISAHZPIP = 0; NMISAHZPIP < 9; NMISAHZPIP++) {
            ECGUTMCXHG = HNVPJKVCDP.values();
            if (ECGUTMCXHG.size() > MPEDTFHERX) {
                Thread.sleep(100);
            } else {
                assertFalse("fileInfo1 should have been evicted", ECGUTMCXHG.contains(UVQQILFGIH));
                return;
            }
        }
        fail("JobListCache didn't delete the extra entry");
    }
}