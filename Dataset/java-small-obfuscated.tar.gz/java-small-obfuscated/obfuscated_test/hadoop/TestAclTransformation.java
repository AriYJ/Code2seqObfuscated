/**
 * Tests operations that modify ACLs.  All tests in this suite have been
 * cross-validated against Linux setfacl/getfacl to check for consistency of the
 * HDFS implementation.
 */
public class TestAclTransformation {
    private static final List<AclEntry> LPWFKDSSRM;

    static {
        LPWFKDSSRM = Lists.newArrayListWithCapacity(33);
        for (int i = 0; i < 33; ++i) {
            TestAclTransformation.LPWFKDSSRM.add(aclEntry(ACCESS, USER, "user" + i, ALL));
        }
    }

    @Test
    public void testFilterAclEntriesByAclSpec() throws AclException {
        List<AclEntry> RUKYOURWZI = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_WRITE)).add(aclEntry(ACCESS, USER, "diana", READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, GROUP, "sales", READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, "execs", READ_WRITE)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, READ)).build();
        List<AclEntry> SKAEMIWMYH = Lists.newArrayList(aclEntry(ACCESS, USER, "diana"), aclEntry(ACCESS, GROUP, "sales"));
        List<AclEntry> BNUYXGUYYT = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, GROUP, "execs", READ_WRITE)).add(aclEntry(ACCESS, MASK, READ_WRITE)).add(aclEntry(ACCESS, OTHER, READ)).build();
        assertEquals(BNUYXGUYYT, filterAclEntriesByAclSpec(RUKYOURWZI, SKAEMIWMYH));
    }

    @Test
    public void testFilterAclEntriesByAclSpecUnchanged() throws AclException {
        List<AclEntry> MAEABVRHCV = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", ALL)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, "sales", ALL)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> WCHPNSFVPZ = Lists.newArrayList(aclEntry(ACCESS, USER, "clark"), aclEntry(ACCESS, GROUP, "execs"));
        assertEquals(MAEABVRHCV, filterAclEntriesByAclSpec(MAEABVRHCV, WCHPNSFVPZ));
    }

    @Test
    public void testFilterAclEntriesByAclSpecAccessMaskCalculated() throws AclException {
        List<AclEntry> KTOPTCOSOP = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ_WRITE)).add(aclEntry(ACCESS, OTHER, READ)).build();
        List<AclEntry> ELINVMKSIM = Lists.newArrayList(aclEntry(ACCESS, USER, "diana"));
        List<AclEntry> TIWWAXEMXC = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).build();
        assertEquals(TIWWAXEMXC, filterAclEntriesByAclSpec(KTOPTCOSOP, ELINVMKSIM));
    }

    @Test
    public void testFilterAclEntriesByAclSpecDefaultMaskCalculated() throws AclException {
        List<AclEntry> WDIDKRAWLX = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, USER, "diana", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> JDKRHYYEGF = Lists.newArrayList(aclEntry(DEFAULT, USER, "diana"));
        List<AclEntry> RFKSUKDFZT = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(RFKSUKDFZT, filterAclEntriesByAclSpec(WDIDKRAWLX, JDKRHYYEGF));
    }

    @Test
    public void testFilterAclEntriesByAclSpecDefaultMaskPreserved() throws AclException {
        List<AclEntry> BUXIIFCIXT = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ_WRITE)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "diana", ALL)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> RVJNIKZWSM = Lists.newArrayList(aclEntry(ACCESS, USER, "diana"));
        List<AclEntry> ORGSBBKQEQ = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "diana", ALL)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(ORGSBBKQEQ, filterAclEntriesByAclSpec(BUXIIFCIXT, RVJNIKZWSM));
    }

    @Test
    public void testFilterAclEntriesByAclSpecAccessMaskPreserved() throws AclException {
        List<AclEntry> GUZLWRCCVC = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, USER, "diana", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> BCSUDFHSYL = Lists.newArrayList(aclEntry(DEFAULT, USER, "diana"));
        List<AclEntry> DSFFTHIQNM = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(DSFFTHIQNM, filterAclEntriesByAclSpec(GUZLWRCCVC, BCSUDFHSYL));
    }

    @Test
    public void testFilterAclEntriesByAclSpecAutomaticDefaultUser() throws AclException {
        List<AclEntry> RRJQTRYUGK = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, READ_WRITE)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> OHYZAEWAHK = Lists.newArrayList(aclEntry(DEFAULT, USER));
        List<AclEntry> CABGSIQIZQ = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(CABGSIQIZQ, filterAclEntriesByAclSpec(RRJQTRYUGK, OHYZAEWAHK));
    }

    @Test
    public void testFilterAclEntriesByAclSpecAutomaticDefaultGroup() throws AclException {
        List<AclEntry> IWQRDPGONW = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> GVYQVIUCBM = Lists.newArrayList(aclEntry(DEFAULT, GROUP));
        List<AclEntry> UIRIYNJVRT = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(UIRIYNJVRT, filterAclEntriesByAclSpec(IWQRDPGONW, GVYQVIUCBM));
    }

    @Test
    public void testFilterAclEntriesByAclSpecAutomaticDefaultOther() throws AclException {
        List<AclEntry> VRHKAPMVPQ = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> YBNPJBNLYH = Lists.newArrayList(aclEntry(DEFAULT, OTHER));
        List<AclEntry> FQKJSPFTSC = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, READ)).build();
        assertEquals(FQKJSPFTSC, filterAclEntriesByAclSpec(VRHKAPMVPQ, YBNPJBNLYH));
    }

    @Test
    public void testFilterAclEntriesByAclSpecEmptyAclSpec() throws AclException {
        List<AclEntry> FXAJCUSMQZ = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, READ)).build();
        List<AclEntry> SWUFPUBVGB = Lists.newArrayList();
        assertEquals(FXAJCUSMQZ, filterAclEntriesByAclSpec(FXAJCUSMQZ, SWUFPUBVGB));
    }

    @Test(expected = AclException.class)
    public void testFilterAclEntriesByAclSpecRemoveAccessMaskRequired() throws AclException {
        List<AclEntry> HVHMUINJCG = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> NORLCZPDZB = Lists.newArrayList(aclEntry(ACCESS, MASK));
        filterAclEntriesByAclSpec(HVHMUINJCG, NORLCZPDZB);
    }

    @Test(expected = AclException.class)
    public void testFilterAclEntriesByAclSpecRemoveDefaultMaskRequired() throws AclException {
        List<AclEntry> GMOXBOASKE = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> TCGTGZLKOU = Lists.newArrayList(aclEntry(DEFAULT, MASK));
        filterAclEntriesByAclSpec(GMOXBOASKE, TCGTGZLKOU);
    }

    @Test(expected = AclException.class)
    public void testFilterAclEntriesByAclSpecInputTooLarge() throws AclException {
        List<AclEntry> MCFISTEWHN = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        filterAclEntriesByAclSpec(MCFISTEWHN, TestAclTransformation.LPWFKDSSRM);
    }

    @Test
    public void testFilterDefaultAclEntries() throws AclException {
        List<AclEntry> RIENBSQLUF = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, "sales", READ_EXECUTE)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, GROUP, "sales", READ_EXECUTE)).add(aclEntry(DEFAULT, MASK, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, READ_EXECUTE)).build();
        List<AclEntry> VJVDILEGCR = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, "sales", READ_EXECUTE)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        assertEquals(VJVDILEGCR, filterDefaultAclEntries(RIENBSQLUF));
    }

    @Test
    public void testFilterDefaultAclEntriesUnchanged() throws AclException {
        List<AclEntry> OCUMTUUXSG = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", ALL)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, "sales", ALL)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        assertEquals(OCUMTUUXSG, filterDefaultAclEntries(OCUMTUUXSG));
    }

    @Test
    public void testMergeAclEntries() throws AclException {
        List<AclEntry> VWFBBAFXFP = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> OCIWLILZZD = Lists.newArrayList(aclEntry(ACCESS, USER, "bruce", ALL));
        List<AclEntry> RTXLVKGIXX = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", ALL)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        assertEquals(RTXLVKGIXX, mergeAclEntries(VWFBBAFXFP, OCIWLILZZD));
    }

    @Test
    public void testMergeAclEntriesUnchanged() throws AclException {
        List<AclEntry> RKLROKPGXU = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", ALL)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, "sales", ALL)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", ALL)).add(aclEntry(DEFAULT, GROUP, READ_EXECUTE)).add(aclEntry(DEFAULT, GROUP, "sales", ALL)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> DGDTGXIFNP = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "bruce", ALL), aclEntry(ACCESS, GROUP, READ_EXECUTE), aclEntry(ACCESS, GROUP, "sales", ALL), aclEntry(ACCESS, MASK, ALL), aclEntry(ACCESS, OTHER, NONE), aclEntry(DEFAULT, USER, ALL), aclEntry(DEFAULT, USER, "bruce", ALL), aclEntry(DEFAULT, GROUP, READ_EXECUTE), aclEntry(DEFAULT, GROUP, "sales", ALL), aclEntry(DEFAULT, MASK, ALL), aclEntry(DEFAULT, OTHER, NONE));
        assertEquals(RKLROKPGXU, mergeAclEntries(RKLROKPGXU, DGDTGXIFNP));
    }

    @Test
    public void testMergeAclEntriesMultipleNewBeforeExisting() throws AclException {
        List<AclEntry> LLFQBASLVB = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "diana", READ)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, MASK, READ_EXECUTE)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> XSITVDHLNM = Lists.newArrayList(aclEntry(ACCESS, USER, "bruce", READ_EXECUTE), aclEntry(ACCESS, USER, "clark", READ_EXECUTE), aclEntry(ACCESS, USER, "diana", READ_EXECUTE));
        List<AclEntry> JCPBMELSMA = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_EXECUTE)).add(aclEntry(ACCESS, USER, "clark", READ_EXECUTE)).add(aclEntry(ACCESS, USER, "diana", READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, MASK, READ_EXECUTE)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        assertEquals(JCPBMELSMA, mergeAclEntries(LLFQBASLVB, XSITVDHLNM));
    }

    @Test
    public void testMergeAclEntriesAccessMaskCalculated() throws AclException {
        List<AclEntry> PBTDBXQJKF = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).build();
        List<AclEntry> UXKABMBUTJ = Lists.newArrayList(aclEntry(ACCESS, USER, "bruce", READ_EXECUTE), aclEntry(ACCESS, USER, "diana", READ));
        List<AclEntry> LEUEKXOYOQ = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_EXECUTE)).add(aclEntry(ACCESS, USER, "diana", READ)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ_EXECUTE)).add(aclEntry(ACCESS, OTHER, READ)).build();
        assertEquals(LEUEKXOYOQ, mergeAclEntries(PBTDBXQJKF, UXKABMBUTJ));
    }

    @Test
    public void testMergeAclEntriesDefaultMaskCalculated() throws AclException {
        List<AclEntry> ZZHNOEJMSU = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> AUSCBVVHHP = Lists.newArrayList(aclEntry(DEFAULT, USER, "bruce", READ_WRITE), aclEntry(DEFAULT, USER, "diana", READ_EXECUTE));
        List<AclEntry> VDNTZGSGDC = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ_WRITE)).add(aclEntry(DEFAULT, USER, "diana", READ_EXECUTE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(VDNTZGSGDC, mergeAclEntries(ZZHNOEJMSU, AUSCBVVHHP));
    }

    @Test
    public void testMergeAclEntriesDefaultMaskPreserved() throws AclException {
        List<AclEntry> AOSYTAVOQH = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "diana", ALL)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> RAHSXRPTLX = Lists.newArrayList(aclEntry(ACCESS, USER, "diana", FsAction.READ_EXECUTE));
        List<AclEntry> JWLZSUOVAY = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "diana", READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ_EXECUTE)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "diana", ALL)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(JWLZSUOVAY, mergeAclEntries(AOSYTAVOQH, RAHSXRPTLX));
    }

    @Test
    public void testMergeAclEntriesAccessMaskPreserved() throws AclException {
        List<AclEntry> IJAUMJZIDU = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, USER, "diana", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> ITSIJKXKIN = Lists.newArrayList(aclEntry(DEFAULT, USER, "diana", READ_EXECUTE));
        List<AclEntry> GYWBAJMTFE = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, USER, "diana", READ_EXECUTE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ_EXECUTE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(GYWBAJMTFE, mergeAclEntries(IJAUMJZIDU, ITSIJKXKIN));
    }

    @Test
    public void testMergeAclEntriesAutomaticDefaultUser() throws AclException {
        List<AclEntry> DXCXRCNSYY = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).build();
        List<AclEntry> HXOIPBMXKU = Lists.newArrayList(aclEntry(DEFAULT, GROUP, READ_EXECUTE), aclEntry(DEFAULT, OTHER, READ));
        List<AclEntry> TXEEHOMTXV = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, GROUP, READ_EXECUTE)).add(aclEntry(DEFAULT, OTHER, READ)).build();
        assertEquals(TXEEHOMTXV, mergeAclEntries(DXCXRCNSYY, HXOIPBMXKU));
    }

    @Test
    public void testMergeAclEntriesAutomaticDefaultGroup() throws AclException {
        List<AclEntry> OHVQLPXSYQ = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).build();
        List<AclEntry> SHJTHIWKVA = Lists.newArrayList(aclEntry(DEFAULT, USER, READ_EXECUTE), aclEntry(DEFAULT, OTHER, READ));
        List<AclEntry> ICLBLBNXHA = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, READ_EXECUTE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, OTHER, READ)).build();
        assertEquals(ICLBLBNXHA, mergeAclEntries(OHVQLPXSYQ, SHJTHIWKVA));
    }

    @Test
    public void testMergeAclEntriesAutomaticDefaultOther() throws AclException {
        List<AclEntry> QWSCXBOOWI = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> QLDGBQHLPW = Lists.newArrayList(aclEntry(DEFAULT, USER, READ_EXECUTE), aclEntry(DEFAULT, GROUP, READ_EXECUTE));
        List<AclEntry> PAHENMMHKP = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, READ_EXECUTE)).add(aclEntry(DEFAULT, GROUP, READ_EXECUTE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(PAHENMMHKP, mergeAclEntries(QWSCXBOOWI, QLDGBQHLPW));
    }

    @Test
    public void testMergeAclEntriesProvidedAccessMask() throws AclException {
        List<AclEntry> ESCBDPDZRT = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> BRJTYAYQVX = Lists.newArrayList(aclEntry(ACCESS, USER, "bruce", READ_EXECUTE), aclEntry(ACCESS, MASK, ALL));
        List<AclEntry> EDBQNTYVQT = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        assertEquals(EDBQNTYVQT, mergeAclEntries(ESCBDPDZRT, BRJTYAYQVX));
    }

    @Test
    public void testMergeAclEntriesProvidedDefaultMask() throws AclException {
        List<AclEntry> PZBPANQGMA = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> NDKZZNRUIO = Lists.newArrayList(aclEntry(DEFAULT, USER, ALL), aclEntry(DEFAULT, GROUP, READ), aclEntry(DEFAULT, MASK, ALL), aclEntry(DEFAULT, OTHER, NONE));
        List<AclEntry> MJAAFRHYRW = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(MJAAFRHYRW, mergeAclEntries(PZBPANQGMA, NDKZZNRUIO));
    }

    @Test
    public void testMergeAclEntriesEmptyAclSpec() throws AclException {
        List<AclEntry> LUQXBETRPA = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, READ)).build();
        List<AclEntry> CRDYTBNRXF = Lists.newArrayList();
        assertEquals(LUQXBETRPA, mergeAclEntries(LUQXBETRPA, CRDYTBNRXF));
    }

    @Test(expected = AclException.class)
    public void testMergeAclEntriesInputTooLarge() throws AclException {
        List<AclEntry> DXULOBAMYB = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        mergeAclEntries(DXULOBAMYB, TestAclTransformation.LPWFKDSSRM);
    }

    @Test(expected = AclException.class)
    public void testMergeAclEntriesResultTooLarge() throws AclException {
        ImmutableList.Builder<AclEntry> GZXTTLSYNK = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL));
        for (int AUVPZWIIPN = 1; AUVPZWIIPN <= 28; ++AUVPZWIIPN) {
            GZXTTLSYNK.add(aclEntry(ACCESS, USER, "user" + AUVPZWIIPN, READ));
        }
        GZXTTLSYNK.add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, NONE));
        List<AclEntry> KSJUOINILA = GZXTTLSYNK.build();
        List<AclEntry> CZSLBJLVEZ = Lists.newArrayList(aclEntry(ACCESS, USER, "bruce", READ));
        mergeAclEntries(KSJUOINILA, CZSLBJLVEZ);
    }

    @Test(expected = AclException.class)
    public void testMergeAclEntriesDuplicateEntries() throws AclException {
        List<AclEntry> EGNRAQMQKK = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> ZTBJVXWFRK = Lists.newArrayList(aclEntry(ACCESS, USER, "bruce", ALL), aclEntry(ACCESS, USER, "diana", READ_WRITE), aclEntry(ACCESS, USER, "clark", READ), aclEntry(ACCESS, USER, "bruce", READ_EXECUTE));
        mergeAclEntries(EGNRAQMQKK, ZTBJVXWFRK);
    }

    @Test(expected = AclException.class)
    public void testMergeAclEntriesNamedMask() throws AclException {
        List<AclEntry> FJAXMVYZQK = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> MFVSKYQZOD = Lists.newArrayList(aclEntry(ACCESS, MASK, "bruce", READ_EXECUTE));
        mergeAclEntries(FJAXMVYZQK, MFVSKYQZOD);
    }

    @Test(expected = AclException.class)
    public void testMergeAclEntriesNamedOther() throws AclException {
        List<AclEntry> UBFYEQHQYA = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> LJKNTFRVMR = Lists.newArrayList(aclEntry(ACCESS, OTHER, "bruce", READ_EXECUTE));
        mergeAclEntries(UBFYEQHQYA, LJKNTFRVMR);
    }

    @Test
    public void testReplaceAclEntries() throws AclException {
        List<AclEntry> JYNUVQGGWQ = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", ALL)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> RNILNCDHQK = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "bruce", READ_WRITE), aclEntry(ACCESS, GROUP, READ_EXECUTE), aclEntry(ACCESS, GROUP, "sales", ALL), aclEntry(ACCESS, MASK, ALL), aclEntry(ACCESS, OTHER, NONE), aclEntry(DEFAULT, USER, ALL), aclEntry(DEFAULT, USER, "bruce", READ_WRITE), aclEntry(DEFAULT, GROUP, READ_EXECUTE), aclEntry(DEFAULT, GROUP, "sales", ALL), aclEntry(DEFAULT, MASK, ALL), aclEntry(DEFAULT, OTHER, NONE));
        List<AclEntry> YZBFCJDWOS = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, "sales", ALL)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ_EXECUTE)).add(aclEntry(DEFAULT, GROUP, "sales", ALL)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(YZBFCJDWOS, replaceAclEntries(JYNUVQGGWQ, RNILNCDHQK));
    }

    @Test
    public void testReplaceAclEntriesUnchanged() throws AclException {
        List<AclEntry> XAANXCMFJH = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", ALL)).add(aclEntry(ACCESS, GROUP, READ_EXECUTE)).add(aclEntry(ACCESS, GROUP, "sales", ALL)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", ALL)).add(aclEntry(DEFAULT, GROUP, READ_EXECUTE)).add(aclEntry(DEFAULT, GROUP, "sales", ALL)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> OFAOKLWDNV = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "bruce", ALL), aclEntry(ACCESS, GROUP, READ_EXECUTE), aclEntry(ACCESS, GROUP, "sales", ALL), aclEntry(ACCESS, MASK, ALL), aclEntry(ACCESS, OTHER, NONE), aclEntry(DEFAULT, USER, ALL), aclEntry(DEFAULT, USER, "bruce", ALL), aclEntry(DEFAULT, GROUP, READ_EXECUTE), aclEntry(DEFAULT, GROUP, "sales", ALL), aclEntry(DEFAULT, MASK, ALL), aclEntry(DEFAULT, OTHER, NONE));
        assertEquals(XAANXCMFJH, replaceAclEntries(XAANXCMFJH, OFAOKLWDNV));
    }

    @Test
    public void testReplaceAclEntriesAccessMaskCalculated() throws AclException {
        List<AclEntry> EIHRJBOKBS = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).build();
        List<AclEntry> PNPZZUDIEB = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "bruce", READ), aclEntry(ACCESS, USER, "diana", READ_WRITE), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, READ));
        List<AclEntry> GRQXTDHRNF = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ_WRITE)).add(aclEntry(ACCESS, OTHER, READ)).build();
        assertEquals(GRQXTDHRNF, replaceAclEntries(EIHRJBOKBS, PNPZZUDIEB));
    }

    @Test
    public void testReplaceAclEntriesDefaultMaskCalculated() throws AclException {
        List<AclEntry> VBKACDUWFX = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).build();
        List<AclEntry> QQBACQRALF = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, READ), aclEntry(DEFAULT, USER, ALL), aclEntry(DEFAULT, USER, "bruce", READ), aclEntry(DEFAULT, USER, "diana", READ_WRITE), aclEntry(DEFAULT, GROUP, ALL), aclEntry(DEFAULT, OTHER, READ));
        List<AclEntry> HZODBVPNZI = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, USER, "diana", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, ALL)).add(aclEntry(DEFAULT, MASK, ALL)).add(aclEntry(DEFAULT, OTHER, READ)).build();
        assertEquals(HZODBVPNZI, replaceAclEntries(VBKACDUWFX, QQBACQRALF));
    }

    @Test
    public void testReplaceAclEntriesDefaultMaskPreserved() throws AclException {
        List<AclEntry> QDZIFAJUSW = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ_WRITE)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "diana", ALL)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> DSXJELNRCA = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "bruce", READ), aclEntry(ACCESS, USER, "diana", READ_WRITE), aclEntry(ACCESS, GROUP, ALL), aclEntry(ACCESS, OTHER, READ));
        List<AclEntry> PKHMCVPNJS = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, ALL)).add(aclEntry(ACCESS, MASK, ALL)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "diana", ALL)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(PKHMCVPNJS, replaceAclEntries(QDZIFAJUSW, DSXJELNRCA));
    }

    @Test
    public void testReplaceAclEntriesAccessMaskPreserved() throws AclException {
        List<AclEntry> QYQWBWWSWO = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, USER, "diana", READ_WRITE)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        List<AclEntry> MDNQXVRNQG = Lists.newArrayList(aclEntry(DEFAULT, USER, ALL), aclEntry(DEFAULT, USER, "bruce", READ), aclEntry(DEFAULT, GROUP, READ), aclEntry(DEFAULT, OTHER, NONE));
        List<AclEntry> EUUDMMCCEC = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, USER, "bruce", READ)).add(aclEntry(ACCESS, USER, "diana", READ_WRITE)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, MASK, READ)).add(aclEntry(ACCESS, OTHER, READ)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(EUUDMMCCEC, replaceAclEntries(QYQWBWWSWO, MDNQXVRNQG));
    }

    @Test
    public void testReplaceAclEntriesAutomaticDefaultUser() throws AclException {
        List<AclEntry> XKXJXNDBXS = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> BIJXVPNQSN = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, NONE), aclEntry(DEFAULT, USER, "bruce", READ), aclEntry(DEFAULT, GROUP, READ_WRITE), aclEntry(DEFAULT, MASK, READ_WRITE), aclEntry(DEFAULT, OTHER, READ));
        List<AclEntry> FZYBHTSMQY = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ_WRITE)).add(aclEntry(DEFAULT, MASK, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, READ)).build();
        assertEquals(FZYBHTSMQY, replaceAclEntries(XKXJXNDBXS, BIJXVPNQSN));
    }

    @Test
    public void testReplaceAclEntriesAutomaticDefaultGroup() throws AclException {
        List<AclEntry> MBXJEHBCHL = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> WAFGSPHKDD = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, NONE), aclEntry(DEFAULT, USER, READ_WRITE), aclEntry(DEFAULT, USER, "bruce", READ), aclEntry(DEFAULT, MASK, READ), aclEntry(DEFAULT, OTHER, READ));
        List<AclEntry> MSNVRVGPFL = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, READ_WRITE)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, READ)).build();
        assertEquals(MSNVRVGPFL, replaceAclEntries(MBXJEHBCHL, WAFGSPHKDD));
    }

    @Test
    public void testReplaceAclEntriesAutomaticDefaultOther() throws AclException {
        List<AclEntry> IJPLUZJKKC = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> GHDYDVGNAV = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, NONE), aclEntry(DEFAULT, USER, READ_WRITE), aclEntry(DEFAULT, USER, "bruce", READ), aclEntry(DEFAULT, GROUP, READ_WRITE), aclEntry(DEFAULT, MASK, READ_WRITE));
        List<AclEntry> QZBUZQLZTT = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, READ_WRITE)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ_WRITE)).add(aclEntry(DEFAULT, MASK, READ_WRITE)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(QZBUZQLZTT, replaceAclEntries(IJPLUZJKKC, GHDYDVGNAV));
    }

    @Test
    public void testReplaceAclEntriesOnlyDefaults() throws AclException {
        List<AclEntry> MOWILBZKCW = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> JENWPVWEQR = Lists.newArrayList(aclEntry(DEFAULT, USER, "bruce", READ));
        List<AclEntry> OFFRBHFWNC = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).add(aclEntry(DEFAULT, USER, ALL)).add(aclEntry(DEFAULT, USER, "bruce", READ)).add(aclEntry(DEFAULT, GROUP, READ)).add(aclEntry(DEFAULT, MASK, READ)).add(aclEntry(DEFAULT, OTHER, NONE)).build();
        assertEquals(OFFRBHFWNC, replaceAclEntries(MOWILBZKCW, JENWPVWEQR));
    }

    @Test(expected = AclException.class)
    public void testReplaceAclEntriesInputTooLarge() throws AclException {
        List<AclEntry> QCGOHONARS = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        replaceAclEntries(QCGOHONARS, TestAclTransformation.LPWFKDSSRM);
    }

    @Test(expected = AclException.class)
    public void testReplaceAclEntriesResultTooLarge() throws AclException {
        List<AclEntry> IPNNCBDBTN = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> KMBDQBZPXI = Lists.newArrayListWithCapacity(32);
        KMBDQBZPXI.add(aclEntry(ACCESS, USER, ALL));
        for (int MQQJWLUXBU = 1; MQQJWLUXBU <= 29; ++MQQJWLUXBU) {
            KMBDQBZPXI.add(aclEntry(ACCESS, USER, "user" + MQQJWLUXBU, READ));
        }
        KMBDQBZPXI.add(aclEntry(ACCESS, GROUP, READ));
        KMBDQBZPXI.add(aclEntry(ACCESS, OTHER, NONE));
        // The ACL spec now has 32 entries.  Automatic mask calculation will push it
        // over the limit to 33.
        replaceAclEntries(IPNNCBDBTN, KMBDQBZPXI);
    }

    @Test(expected = AclException.class)
    public void testReplaceAclEntriesDuplicateEntries() throws AclException {
        List<AclEntry> WORZKZUENE = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> KDVPNGGBYM = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "bruce", ALL), aclEntry(ACCESS, USER, "diana", READ_WRITE), aclEntry(ACCESS, USER, "clark", READ), aclEntry(ACCESS, USER, "bruce", READ_EXECUTE), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, NONE));
        replaceAclEntries(WORZKZUENE, KDVPNGGBYM);
    }

    @Test(expected = AclException.class)
    public void testReplaceAclEntriesNamedMask() throws AclException {
        List<AclEntry> SZURUJVZNP = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> XFYQDJAFWE = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, NONE), aclEntry(ACCESS, MASK, "bruce", READ_EXECUTE));
        replaceAclEntries(SZURUJVZNP, XFYQDJAFWE);
    }

    @Test(expected = AclException.class)
    public void testReplaceAclEntriesNamedOther() throws AclException {
        List<AclEntry> WTMTNTOMAV = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> BQBWQGLFFF = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, GROUP, READ), aclEntry(ACCESS, OTHER, NONE), aclEntry(ACCESS, OTHER, "bruce", READ_EXECUTE));
        replaceAclEntries(WTMTNTOMAV, BQBWQGLFFF);
    }

    @Test(expected = AclException.class)
    public void testReplaceAclEntriesMissingUser() throws AclException {
        List<AclEntry> PUYKNIBRVA = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> IGAGZFVCJZ = Lists.newArrayList(aclEntry(ACCESS, USER, "bruce", READ_WRITE), aclEntry(ACCESS, GROUP, READ_EXECUTE), aclEntry(ACCESS, GROUP, "sales", ALL), aclEntry(ACCESS, MASK, ALL), aclEntry(ACCESS, OTHER, NONE));
        replaceAclEntries(PUYKNIBRVA, IGAGZFVCJZ);
    }

    @Test(expected = AclException.class)
    public void testReplaceAclEntriesMissingGroup() throws AclException {
        List<AclEntry> SYADUHIYMW = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> SGQIVTDQTJ = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "bruce", READ_WRITE), aclEntry(ACCESS, GROUP, "sales", ALL), aclEntry(ACCESS, MASK, ALL), aclEntry(ACCESS, OTHER, NONE));
        replaceAclEntries(SYADUHIYMW, SGQIVTDQTJ);
    }

    @Test(expected = AclException.class)
    public void testReplaceAclEntriesMissingOther() throws AclException {
        List<AclEntry> TZDJUPGPNK = new ImmutableList.Builder<AclEntry>().add(aclEntry(ACCESS, USER, ALL)).add(aclEntry(ACCESS, GROUP, READ)).add(aclEntry(ACCESS, OTHER, NONE)).build();
        List<AclEntry> RRUNXJUVHB = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "bruce", READ_WRITE), aclEntry(ACCESS, GROUP, READ_EXECUTE), aclEntry(ACCESS, GROUP, "sales", ALL), aclEntry(ACCESS, MASK, ALL));
        replaceAclEntries(TZDJUPGPNK, RRUNXJUVHB);
    }
}