@InterfaceAudience.LimitedPrivate({ "YARN", "MapReduce" })
public class FooterBlock extends HtmlBlock {
    @Override
    protected void render(Block UGHKJXCZEK) {
        UGHKJXCZEK.div("#footer.ui-widget")._();
    }
}