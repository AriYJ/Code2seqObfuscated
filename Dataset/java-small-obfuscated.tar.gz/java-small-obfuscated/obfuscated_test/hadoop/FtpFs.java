/**
 * The FtpFs implementation of AbstractFileSystem.
 * This impl delegates to the old FileSystem
 */
/* Evolving for a release,to be changed to Stable */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public class FtpFs extends DelegateToFileSystem {
    /**
     * This constructor has the signature needed by
     * {@link AbstractFileSystem#createFileSystem(URI, Configuration)}.
     *
     * @param theUri
     * 		which must be that of localFs
     * @param conf
     * 		
     * @throws IOException
     * 		
     * @throws URISyntaxException
     * 		
     */
    FtpFs(final URI XRYLLBSASK, final Configuration DIIAXUNKZJ) throws IOException, URISyntaxException {
        super(XRYLLBSASK, new FTPFileSystem(), DIIAXUNKZJ, FTP_SCHEME, true);
    }

    @Override
    public int getUriDefaultPort() {
        return FTP.DEFAULT_PORT;
    }

    @Override
    public FsServerDefaults getServerDefaults() throws IOException {
        return FtpConfigKeys.getServerDefaults();
    }
}