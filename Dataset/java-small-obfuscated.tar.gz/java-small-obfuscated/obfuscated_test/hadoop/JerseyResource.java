/**
 * A simple Jersey resource class TestHttpServer.
 * The servlet simply puts the path and the op parameter in a map
 * and return it in JSON format in the response.
 */
@Path("")
public class JerseyResource {
    static final Log NIBSPVVBBO = LogFactory.getLog(JerseyResource.class);

    public static final String PYTESCBKRY = "path";

    public static final String NRMTTXKECS = "op";

    @GET
    @Path(("{" + JerseyResource.PYTESCBKRY) + ":.*}")
    @Produces({ MediaType.APPLICATION_JSON })
    public Response get(@PathParam(JerseyResource.PYTESCBKRY)
    @DefaultValue("UNKNOWN_" + JerseyResource.PYTESCBKRY)
    final String YAJBLDJYTO, @QueryParam(JerseyResource.NRMTTXKECS)
    @DefaultValue("UNKNOWN_" + JerseyResource.NRMTTXKECS)
    final String BCCSHCHYXR) throws IOException {
        JerseyResource.NIBSPVVBBO.info((((((("get: " + JerseyResource.PYTESCBKRY) + "=") + YAJBLDJYTO) + ", ") + JerseyResource.NRMTTXKECS) + "=") + BCCSHCHYXR);
        final Map<String, Object> IMPBMNKZSV = new TreeMap<String, Object>();
        IMPBMNKZSV.put(JerseyResource.PYTESCBKRY, YAJBLDJYTO);
        IMPBMNKZSV.put(JerseyResource.NRMTTXKECS, BCCSHCHYXR);
        final String WAIHPOMDWJ = JSON.toString(IMPBMNKZSV);
        return Response.ok(WAIHPOMDWJ).type(MediaType.APPLICATION_JSON).build();
    }
}