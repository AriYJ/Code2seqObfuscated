public class TestChRootedFileSystem {
    FileSystem TTPJFIUAEJ;// The ChRoootedFs


    FileSystem BZVNPFDPAO;// 


    Path IYLTQNFUJS;

    FileSystemTestHelper MHNEIVPYOF;

    @Before
    public void setUp() throws Exception {
        // create the test root on local_fs
        Configuration RUXGKTSEMW = new Configuration();
        BZVNPFDPAO = FileSystem.getLocal(RUXGKTSEMW);
        MHNEIVPYOF = new FileSystemTestHelper();
        IYLTQNFUJS = MHNEIVPYOF.getAbsoluteTestRootPath(BZVNPFDPAO);
        // In case previous test was killed before cleanup
        BZVNPFDPAO.delete(IYLTQNFUJS, true);
        BZVNPFDPAO.mkdirs(IYLTQNFUJS);
        // ChRoot to the root of the testDirectory
        TTPJFIUAEJ = new ChRootedFileSystem(IYLTQNFUJS.toUri(), RUXGKTSEMW);
    }

    @After
    public void tearDown() throws Exception {
        BZVNPFDPAO.delete(IYLTQNFUJS, true);
    }

    @Test
    public void testURI() {
        URI AWMRMJXOCC = TTPJFIUAEJ.getUri();
        Assert.assertEquals(IYLTQNFUJS.toUri(), AWMRMJXOCC);
    }

    @Test
    public void testBasicPaths() {
        URI TIDDPSQJDK = TTPJFIUAEJ.getUri();
        Assert.assertEquals(IYLTQNFUJS.toUri(), TIDDPSQJDK);
        Assert.assertEquals(TTPJFIUAEJ.makeQualified(new Path(System.getProperty("user.home"))), TTPJFIUAEJ.getWorkingDirectory());
        Assert.assertEquals(TTPJFIUAEJ.makeQualified(new Path(System.getProperty("user.home"))), TTPJFIUAEJ.getHomeDirectory());
        /* ChRootedFs as its uri like file:///chrootRoot.
        This is questionable since path.makequalified(uri, path) ignores
        the pathPart of a uri. So our notion of chrooted URI is questionable.
        But if we were to fix Path#makeQualified() then  the next test should
         have been:

        Assert.assertEquals(
        new Path(chrootedTo + "/foo/bar").makeQualified(
        FsConstants.LOCAL_FS_URI, null),
        fSys.makeQualified(new Path( "/foo/bar")));
         */
        Assert.assertEquals(new Path("/foo/bar").makeQualified(LOCAL_FS_URI, null), TTPJFIUAEJ.makeQualified(new Path("/foo/bar")));
    }

    /**
     * Test modify operations (create, mkdir, delete, etc)
     *
     * Verify the operation via chrootedfs (ie fSys) and *also* via the
     *  target file system (ie fSysTarget) that has been chrooted.
     */
    @Test
    public void testCreateDelete() throws IOException {
        // Create file
        MHNEIVPYOF.createFile(TTPJFIUAEJ, "/foo");
        Assert.assertTrue(TTPJFIUAEJ.isFile(new Path("/foo")));
        Assert.assertTrue(BZVNPFDPAO.isFile(new Path(IYLTQNFUJS, "foo")));
        // Create file with recursive dir
        MHNEIVPYOF.createFile(TTPJFIUAEJ, "/newDir/foo");
        Assert.assertTrue(TTPJFIUAEJ.isFile(new Path("/newDir/foo")));
        Assert.assertTrue(BZVNPFDPAO.isFile(new Path(IYLTQNFUJS, "newDir/foo")));
        // Delete the created file
        Assert.assertTrue(TTPJFIUAEJ.delete(new Path("/newDir/foo"), false));
        Assert.assertFalse(TTPJFIUAEJ.exists(new Path("/newDir/foo")));
        Assert.assertFalse(BZVNPFDPAO.exists(new Path(IYLTQNFUJS, "newDir/foo")));
        // Create file with a 2 component dirs recursively
        MHNEIVPYOF.createFile(TTPJFIUAEJ, "/newDir/newDir2/foo");
        Assert.assertTrue(TTPJFIUAEJ.isFile(new Path("/newDir/newDir2/foo")));
        Assert.assertTrue(BZVNPFDPAO.isFile(new Path(IYLTQNFUJS, "newDir/newDir2/foo")));
        // Delete the created file
        Assert.assertTrue(TTPJFIUAEJ.delete(new Path("/newDir/newDir2/foo"), false));
        Assert.assertFalse(TTPJFIUAEJ.exists(new Path("/newDir/newDir2/foo")));
        Assert.assertFalse(BZVNPFDPAO.exists(new Path(IYLTQNFUJS, "newDir/newDir2/foo")));
    }

    @Test
    public void testMkdirDelete() throws IOException {
        TTPJFIUAEJ.mkdirs(MHNEIVPYOF.getTestRootPath(TTPJFIUAEJ, "/dirX"));
        Assert.assertTrue(TTPJFIUAEJ.isDirectory(new Path("/dirX")));
        Assert.assertTrue(BZVNPFDPAO.isDirectory(new Path(IYLTQNFUJS, "dirX")));
        TTPJFIUAEJ.mkdirs(MHNEIVPYOF.getTestRootPath(TTPJFIUAEJ, "/dirX/dirY"));
        Assert.assertTrue(TTPJFIUAEJ.isDirectory(new Path("/dirX/dirY")));
        Assert.assertTrue(BZVNPFDPAO.isDirectory(new Path(IYLTQNFUJS, "dirX/dirY")));
        // Delete the created dir
        Assert.assertTrue(TTPJFIUAEJ.delete(new Path("/dirX/dirY"), false));
        Assert.assertFalse(TTPJFIUAEJ.exists(new Path("/dirX/dirY")));
        Assert.assertFalse(BZVNPFDPAO.exists(new Path(IYLTQNFUJS, "dirX/dirY")));
        Assert.assertTrue(TTPJFIUAEJ.delete(new Path("/dirX"), false));
        Assert.assertFalse(TTPJFIUAEJ.exists(new Path("/dirX")));
        Assert.assertFalse(BZVNPFDPAO.exists(new Path(IYLTQNFUJS, "dirX")));
    }

    @Test
    public void testRename() throws IOException {
        // Rename a file
        MHNEIVPYOF.createFile(TTPJFIUAEJ, "/newDir/foo");
        TTPJFIUAEJ.rename(new Path("/newDir/foo"), new Path("/newDir/fooBar"));
        Assert.assertFalse(TTPJFIUAEJ.exists(new Path("/newDir/foo")));
        Assert.assertFalse(BZVNPFDPAO.exists(new Path(IYLTQNFUJS, "newDir/foo")));
        Assert.assertTrue(TTPJFIUAEJ.isFile(MHNEIVPYOF.getTestRootPath(TTPJFIUAEJ, "/newDir/fooBar")));
        Assert.assertTrue(BZVNPFDPAO.isFile(new Path(IYLTQNFUJS, "newDir/fooBar")));
        // Rename a dir
        TTPJFIUAEJ.mkdirs(new Path("/newDir/dirFoo"));
        TTPJFIUAEJ.rename(new Path("/newDir/dirFoo"), new Path("/newDir/dirFooBar"));
        Assert.assertFalse(TTPJFIUAEJ.exists(new Path("/newDir/dirFoo")));
        Assert.assertFalse(BZVNPFDPAO.exists(new Path(IYLTQNFUJS, "newDir/dirFoo")));
        Assert.assertTrue(TTPJFIUAEJ.isDirectory(MHNEIVPYOF.getTestRootPath(TTPJFIUAEJ, "/newDir/dirFooBar")));
        Assert.assertTrue(BZVNPFDPAO.isDirectory(new Path(IYLTQNFUJS, "newDir/dirFooBar")));
    }

    @Test
    public void testGetContentSummary() throws IOException {
        // GetContentSummary of a dir
        TTPJFIUAEJ.mkdirs(new Path("/newDir/dirFoo"));
        ContentSummary KLERCJISAW = TTPJFIUAEJ.getContentSummary(new Path("/newDir/dirFoo"));
        Assert.assertEquals(-1L, KLERCJISAW.getQuota());
        Assert.assertEquals(-1L, KLERCJISAW.getSpaceQuota());
    }

    /**
     * We would have liked renames across file system to fail but
     * Unfortunately there is not way to distinguish the two file systems
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testRenameAcrossFs() throws IOException {
        TTPJFIUAEJ.mkdirs(new Path("/newDir/dirFoo"));
        TTPJFIUAEJ.rename(new Path("/newDir/dirFoo"), new Path("file:///tmp/dirFooBar"));
        FileSystemTestHelper.isDir(TTPJFIUAEJ, new Path("/tmp/dirFooBar"));
    }

    @Test
    public void testList() throws IOException {
        FileStatus MKPXOAKRZZ = TTPJFIUAEJ.getFileStatus(new Path("/"));
        Assert.assertTrue(MKPXOAKRZZ.isDirectory());
        // should return the full path not the chrooted path
        Assert.assertEquals(MKPXOAKRZZ.getPath(), IYLTQNFUJS);
        // list on Slash
        FileStatus[] ANBKVKNEES = TTPJFIUAEJ.listStatus(new Path("/"));
        Assert.assertEquals(0, ANBKVKNEES.length);
        MHNEIVPYOF.createFile(TTPJFIUAEJ, "/foo");
        MHNEIVPYOF.createFile(TTPJFIUAEJ, "/bar");
        TTPJFIUAEJ.mkdirs(new Path("/dirX"));
        TTPJFIUAEJ.mkdirs(MHNEIVPYOF.getTestRootPath(TTPJFIUAEJ, "/dirY"));
        TTPJFIUAEJ.mkdirs(new Path("/dirX/dirXX"));
        ANBKVKNEES = TTPJFIUAEJ.listStatus(new Path("/"));
        Assert.assertEquals(4, ANBKVKNEES.length);// note 2 crc files

        // Note the the file status paths are the full paths on target
        MKPXOAKRZZ = FileSystemTestHelper.containsPath(new Path(IYLTQNFUJS, "foo"), ANBKVKNEES);
        Assert.assertNotNull(MKPXOAKRZZ);
        Assert.assertTrue(MKPXOAKRZZ.isFile());
        MKPXOAKRZZ = FileSystemTestHelper.containsPath(new Path(IYLTQNFUJS, "bar"), ANBKVKNEES);
        Assert.assertNotNull(MKPXOAKRZZ);
        Assert.assertTrue(MKPXOAKRZZ.isFile());
        MKPXOAKRZZ = FileSystemTestHelper.containsPath(new Path(IYLTQNFUJS, "dirX"), ANBKVKNEES);
        Assert.assertNotNull(MKPXOAKRZZ);
        Assert.assertTrue(MKPXOAKRZZ.isDirectory());
        MKPXOAKRZZ = FileSystemTestHelper.containsPath(new Path(IYLTQNFUJS, "dirY"), ANBKVKNEES);
        Assert.assertNotNull(MKPXOAKRZZ);
        Assert.assertTrue(MKPXOAKRZZ.isDirectory());
    }

    @Test
    public void testWorkingDirectory() throws Exception {
        // First we cd to our test root
        TTPJFIUAEJ.mkdirs(new Path("/testWd"));
        Path UZKSCKWMCT = new Path("/testWd");
        TTPJFIUAEJ.setWorkingDirectory(UZKSCKWMCT);
        Assert.assertEquals(UZKSCKWMCT, TTPJFIUAEJ.getWorkingDirectory());
        TTPJFIUAEJ.setWorkingDirectory(new Path("."));
        Assert.assertEquals(UZKSCKWMCT, TTPJFIUAEJ.getWorkingDirectory());
        TTPJFIUAEJ.setWorkingDirectory(new Path(".."));
        Assert.assertEquals(UZKSCKWMCT.getParent(), TTPJFIUAEJ.getWorkingDirectory());
        // cd using a relative path
        // Go back to our test root
        UZKSCKWMCT = new Path("/testWd");
        TTPJFIUAEJ.setWorkingDirectory(UZKSCKWMCT);
        Assert.assertEquals(UZKSCKWMCT, TTPJFIUAEJ.getWorkingDirectory());
        Path JYAIYIHXMQ = new Path("existingDir1");
        Path OJCNADZFDI = new Path(UZKSCKWMCT, "existingDir1");
        TTPJFIUAEJ.mkdirs(OJCNADZFDI);
        TTPJFIUAEJ.setWorkingDirectory(JYAIYIHXMQ);
        Assert.assertEquals(OJCNADZFDI, TTPJFIUAEJ.getWorkingDirectory());
        // cd using a absolute path
        OJCNADZFDI = new Path("/test/existingDir2");
        TTPJFIUAEJ.mkdirs(OJCNADZFDI);
        TTPJFIUAEJ.setWorkingDirectory(OJCNADZFDI);
        Assert.assertEquals(OJCNADZFDI, TTPJFIUAEJ.getWorkingDirectory());
        // Now open a file relative to the wd we just set above.
        Path DQZELATZPH = new Path(OJCNADZFDI, "foo");
        TTPJFIUAEJ.create(DQZELATZPH).close();
        TTPJFIUAEJ.open(new Path("foo")).close();
        // Now mkdir relative to the dir we cd'ed to
        TTPJFIUAEJ.mkdirs(new Path("newDir"));
        Assert.assertTrue(TTPJFIUAEJ.isDirectory(new Path(OJCNADZFDI, "newDir")));
        /* Filesystem impls (RawLocal and DistributedFileSystem do not check
        for existing of working dir
        absoluteDir = getTestRootPath(fSys, "nonexistingPath");
        try {
        fSys.setWorkingDirectory(absoluteDir);
        Assert.fail("cd to non existing dir should have failed");
        } catch (Exception e) {
        // Exception as expected
        }
         */
        // Try a URI
        final String EKDLUIFUJB = "file:///tmp/test";
        OJCNADZFDI = new Path(EKDLUIFUJB + "/existingDir");
        TTPJFIUAEJ.mkdirs(OJCNADZFDI);
        TTPJFIUAEJ.setWorkingDirectory(OJCNADZFDI);
        Assert.assertEquals(OJCNADZFDI, TTPJFIUAEJ.getWorkingDirectory());
    }

    /* Test resolvePath(p) */
    @Test
    public void testResolvePath() throws IOException {
        Assert.assertEquals(IYLTQNFUJS, TTPJFIUAEJ.resolvePath(new Path("/")));
        MHNEIVPYOF.createFile(TTPJFIUAEJ, "/foo");
        Assert.assertEquals(new Path(IYLTQNFUJS, "foo"), TTPJFIUAEJ.resolvePath(new Path("/foo")));
    }

    @Test(expected = FileNotFoundException.class)
    public void testResolvePathNonExisting() throws IOException {
        TTPJFIUAEJ.resolvePath(new Path("/nonExisting"));
    }

    @Test
    public void testDeleteOnExitPathHandling() throws IOException {
        Configuration KRZBTAZZWH = new Configuration();
        KRZBTAZZWH.setClass("fs.mockfs.impl", TestChRootedFileSystem.MockFileSystem.class, FileSystem.class);
        URI GTMFGUARCS = URI.create("mockfs://foo/a/b");
        ChRootedFileSystem ODINMTKCZC = new ChRootedFileSystem(GTMFGUARCS, KRZBTAZZWH);
        FileSystem PQCQUCNTSF = ((FilterFileSystem) (ODINMTKCZC.getRawFileSystem())).getRawFileSystem();
        // ensure delete propagates the correct path
        Path TZNJZSZCRA = new Path("/c");
        Path AUCKXXQNZJ = new Path("/a/b/c");
        ODINMTKCZC.delete(TZNJZSZCRA, false);
        verify(PQCQUCNTSF).delete(eq(AUCKXXQNZJ), eq(false));
        reset(PQCQUCNTSF);
        // fake that the path exists for deleteOnExit
        FileStatus XQNZYQKGVN = mock(FileStatus.class);
        when(PQCQUCNTSF.getFileStatus(eq(AUCKXXQNZJ))).thenReturn(XQNZYQKGVN);
        // ensure deleteOnExit propagates the correct path
        ODINMTKCZC.deleteOnExit(TZNJZSZCRA);
        ODINMTKCZC.close();
        verify(PQCQUCNTSF).delete(eq(AUCKXXQNZJ), eq(true));
    }

    @Test
    public void testURIEmptyPath() throws IOException {
        Configuration MAEQZFZUCY = new Configuration();
        MAEQZFZUCY.setClass("fs.mockfs.impl", TestChRootedFileSystem.MockFileSystem.class, FileSystem.class);
        URI JWLYZKECYH = URI.create("mockfs://foo");
        new ChRootedFileSystem(JWLYZKECYH, MAEQZFZUCY);
    }

    /**
     * Tests that ChRootedFileSystem delegates calls for every ACL method to the
     * underlying FileSystem with all Path arguments translated as required to
     * enforce chroot.
     */
    @Test
    public void testAclMethodsPathTranslation() throws IOException {
        Configuration LIIBNJQINV = new Configuration();
        LIIBNJQINV.setClass("fs.mockfs.impl", TestChRootedFileSystem.MockFileSystem.class, FileSystem.class);
        URI SASKZDMGRD = URI.create("mockfs://foo/a/b");
        ChRootedFileSystem DMMXXYKCFQ = new ChRootedFileSystem(SASKZDMGRD, LIIBNJQINV);
        FileSystem SDMJKJBSKQ = ((FilterFileSystem) (DMMXXYKCFQ.getRawFileSystem())).getRawFileSystem();
        Path NESKXIXWPH = new Path("/c");
        Path SKIHNLQWZK = new Path("/a/b/c");
        List<AclEntry> EPIACGVMHW = Collections.emptyList();
        DMMXXYKCFQ.modifyAclEntries(NESKXIXWPH, EPIACGVMHW);
        verify(SDMJKJBSKQ).modifyAclEntries(SKIHNLQWZK, EPIACGVMHW);
        DMMXXYKCFQ.removeAclEntries(NESKXIXWPH, EPIACGVMHW);
        verify(SDMJKJBSKQ).removeAclEntries(SKIHNLQWZK, EPIACGVMHW);
        DMMXXYKCFQ.removeDefaultAcl(NESKXIXWPH);
        verify(SDMJKJBSKQ).removeDefaultAcl(SKIHNLQWZK);
        DMMXXYKCFQ.removeAcl(NESKXIXWPH);
        verify(SDMJKJBSKQ).removeAcl(SKIHNLQWZK);
        DMMXXYKCFQ.setAcl(NESKXIXWPH, EPIACGVMHW);
        verify(SDMJKJBSKQ).setAcl(SKIHNLQWZK, EPIACGVMHW);
        DMMXXYKCFQ.getAclStatus(NESKXIXWPH);
        verify(SDMJKJBSKQ).getAclStatus(SKIHNLQWZK);
    }

    static class MockFileSystem extends FilterFileSystem {
        MockFileSystem() {
            super(mock(FileSystem.class));
        }

        @Override
        public void initialize(URI name, Configuration conf) throws IOException {
        }
    }
}