public class TestMRKeyFieldBasedComparator extends HadoopTestCase {
    Configuration WSQMFUUKDV;

    String DCNQKZUQIJ = "123 -123 005120 123.9 0.01 0.18 010 10.0 4444.1 011 011 234";

    String TJBLEAIVTT = "134 -12 005100 123.10 -1.01 0.19 02 10.1 4444";

    public TestMRKeyFieldBasedComparator() throws IOException {
        super(LOCAL_MR, LOCAL_FS, 1, 1);
        WSQMFUUKDV = createJobConf();
        WSQMFUUKDV.set(MAP_OUTPUT_KEY_FIELD_SEPERATOR, " ");
    }

    private void testComparator(String PNGCKFPIBM, int SENKELZWLM) throws Exception {
        String MOSTBYGTRL = System.getProperty("test.build.data", "/tmp");
        Path HEKDBOEIQI = new Path(MOSTBYGTRL, "test_cmp/in");
        Path EJYRKLDYOS = new Path(MOSTBYGTRL, "test_cmp/out");
        WSQMFUUKDV.set("mapreduce.partition.keycomparator.options", PNGCKFPIBM);
        WSQMFUUKDV.set("mapreduce.partition.keypartitioner.options", "-k1.1,1.1");
        WSQMFUUKDV.set(MAP_OUTPUT_KEY_FIELD_SEPERATOR, " ");
        Job XVHCPRTRPX = MapReduceTestUtil.createJob(WSQMFUUKDV, HEKDBOEIQI, EJYRKLDYOS, 1, 1, ((DCNQKZUQIJ + "\n") + TJBLEAIVTT) + "\n");
        XVHCPRTRPX.setMapperClass(InverseMapper.class);
        XVHCPRTRPX.setReducerClass(Reducer.class);
        XVHCPRTRPX.setOutputKeyClass(Text.class);
        XVHCPRTRPX.setOutputValueClass(LongWritable.class);
        XVHCPRTRPX.setSortComparatorClass(KeyFieldBasedComparator.class);
        XVHCPRTRPX.setPartitionerClass(KeyFieldBasedPartitioner.class);
        XVHCPRTRPX.waitForCompletion(true);
        assertTrue(XVHCPRTRPX.isSuccessful());
        // validate output
        Path[] LQPCBPBEQB = FileUtil.stat2Paths(getFileSystem().listStatus(EJYRKLDYOS, new Utils.OutputFileUtils.OutputFilesFilter()));
        if (LQPCBPBEQB.length > 0) {
            InputStream WFIIBDJRFL = getFileSystem().open(LQPCBPBEQB[0]);
            BufferedReader JZFLQTNCYE = new BufferedReader(new InputStreamReader(WFIIBDJRFL));
            String PWUTEMGYVU = JZFLQTNCYE.readLine();
            // make sure we get what we expect as the first line, and also
            // that we have two lines (both the lines must end up in the same
            // reducer since the partitioner takes the same key spec for all
            // lines
            if (SENKELZWLM == 1) {
                assertTrue(PWUTEMGYVU.startsWith(DCNQKZUQIJ));
            } else
                if (SENKELZWLM == 2) {
                    assertTrue(PWUTEMGYVU.startsWith(TJBLEAIVTT));
                }

            PWUTEMGYVU = JZFLQTNCYE.readLine();
            if (SENKELZWLM == 1) {
                assertTrue(PWUTEMGYVU.startsWith(TJBLEAIVTT));
            } else
                if (SENKELZWLM == 2) {
                    assertTrue(PWUTEMGYVU.startsWith(DCNQKZUQIJ));
                }

            JZFLQTNCYE.close();
        }
    }

    public void testBasicUnixComparator() throws Exception {
        testComparator("-k1,1n", 1);
        testComparator("-k2,2n", 1);
        testComparator("-k2.2,2n", 2);
        testComparator("-k3.4,3n", 2);
        testComparator("-k3.2,3.3n -k4,4n", 2);
        testComparator("-k3.2,3.3n -k4,4nr", 1);
        testComparator("-k2.4,2.4n", 2);
        testComparator("-k7,7", 1);
        testComparator("-k7,7n", 2);
        testComparator("-k8,8n", 1);
        testComparator("-k9,9", 2);
        testComparator("-k11,11", 2);
        testComparator("-k10,10", 2);
        testWithoutMRJob("-k9,9", 1);
        testWithoutMRJob("-k9n", 1);
    }

    byte[] VFAVJETBPK = DCNQKZUQIJ.getBytes();

    byte[] NSOXXQUTBA = TJBLEAIVTT.getBytes();

    public void testWithoutMRJob(String KBDBJJVWZQ, int WZICBPEPMK) throws Exception {
        KeyFieldBasedComparator<Void, Void> PRLHZJNQNV = new KeyFieldBasedComparator<Void, Void>();
        WSQMFUUKDV.set("mapreduce.partition.keycomparator.options", KBDBJJVWZQ);
        PRLHZJNQNV.setConf(WSQMFUUKDV);
        int ZQOYKEQEIO = PRLHZJNQNV.compare(VFAVJETBPK, 0, VFAVJETBPK.length, NSOXXQUTBA, 0, NSOXXQUTBA.length);
        if (((WZICBPEPMK >= 0) && (ZQOYKEQEIO < 0)) || ((WZICBPEPMK < 0) && (ZQOYKEQEIO >= 0)))
            fail();

    }
}