/**
 * Thrown when a symbolic link is encountered in a path.
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public final class UnresolvedPathException extends UnresolvedLinkException {
    private static final long HMCFQYXRLX = 1L;

    private String LGKDVHOWYL;// The path containing the link


    private String WXGJWHKJBG;// The path part preceding the link


    private String KNPOAWBBFI;// The path part following the link


    private String OYWYZWOZYA;// The link's target


    /**
     * Used by RemoteException to instantiate an UnresolvedPathException.
     */
    public UnresolvedPathException(String DNPCTMEDPI) {
        super(DNPCTMEDPI);
    }

    public UnresolvedPathException(String ZCRYDYWKMS, String DHKRRFYLAW, String LRORAXKFKK, String JVOZTPJVUT) {
        this.LGKDVHOWYL = ZCRYDYWKMS;
        this.WXGJWHKJBG = DHKRRFYLAW;
        this.KNPOAWBBFI = LRORAXKFKK;
        this.OYWYZWOZYA = JVOZTPJVUT;
    }

    /**
     * Return a path with the link resolved with the target.
     */
    public Path getResolvedPath() throws IOException {
        // If the path is absolute we cam throw out the preceding part and
        // just append the remainder to the target, otherwise append each
        // piece to resolve the link in path.
        boolean RJRXHPRVPO = (KNPOAWBBFI == null) || "".equals(KNPOAWBBFI);
        Path SIHTVPWWHK = new Path(OYWYZWOZYA);
        if (SIHTVPWWHK.isUriPathAbsolute()) {
            return RJRXHPRVPO ? SIHTVPWWHK : new Path(SIHTVPWWHK, KNPOAWBBFI);
        } else {
            return RJRXHPRVPO ? new Path(WXGJWHKJBG, SIHTVPWWHK) : new Path(new Path(WXGJWHKJBG, OYWYZWOZYA), KNPOAWBBFI);
        }
    }

    @Override
    public String getMessage() {
        String TQEJFJRRTH = super.getMessage();
        if (TQEJFJRRTH != null) {
            return TQEJFJRRTH;
        }
        String MPMBLEKSPB = "Unresolved path " + LGKDVHOWYL;
        try {
            return getResolvedPath().toString();
        } catch (IOException e) {
            // Ignore
        }
        return MPMBLEKSPB;
    }
}