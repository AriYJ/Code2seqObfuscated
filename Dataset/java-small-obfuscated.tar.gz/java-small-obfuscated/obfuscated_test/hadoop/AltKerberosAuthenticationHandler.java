/**
 * The {@link AltKerberosAuthenticationHandler} behaves exactly the same way as
 * the {@link KerberosAuthenticationHandler}, except that it allows for an
 * alternative form of authentication for browsers while still using Kerberos
 * for Java access.  This is an abstract class that should be subclassed
 * to allow a developer to implement their own custom authentication for browser
 * access.  The alternateAuthenticate method will be called whenever a request
 * comes from a browser.
 * <p/>
 */
public abstract class AltKerberosAuthenticationHandler extends KerberosAuthenticationHandler {
    /**
     * Constant that identifies the authentication mechanism.
     */
    public static final String PKJYMLHFIW = "alt-kerberos";

    /**
     * Constant for the configuration property that indicates which user agents
     * are not considered browsers (comma separated)
     */
    public static final String ZOSIFWYJNO = AltKerberosAuthenticationHandler.PKJYMLHFIW + ".non-browser.user-agents";

    private static final String TVDKJDZRTV = "java,curl,wget,perl";

    private String[] HJGKLVNHEA;

    /**
     * Returns the authentication type of the authentication handler,
     * 'alt-kerberos'.
     * <p/>
     *
     * @return the authentication type of the authentication handler,
    'alt-kerberos'.
     */
    @Override
    public String getType() {
        return AltKerberosAuthenticationHandler.PKJYMLHFIW;
    }

    @Override
    public void init(Properties OCACJFJKLL) throws ServletException {
        super.init(OCACJFJKLL);
        HJGKLVNHEA = OCACJFJKLL.getProperty(AltKerberosAuthenticationHandler.ZOSIFWYJNO, AltKerberosAuthenticationHandler.TVDKJDZRTV).split("\\W*,\\W*");
        for (int RVWRTMWINT = 0; RVWRTMWINT < HJGKLVNHEA.length; RVWRTMWINT++) {
            HJGKLVNHEA[RVWRTMWINT] = HJGKLVNHEA[RVWRTMWINT].toLowerCase();
        }
    }

    /**
     * It enforces the the Kerberos SPNEGO authentication sequence returning an
     * {@link AuthenticationToken} only after the Kerberos SPNEGO sequence has
     * completed successfully (in the case of Java access) and only after the
     * custom authentication implemented by the subclass in alternateAuthenticate
     * has completed successfully (in the case of browser access).
     * <p/>
     *
     * @param request
     * 		the HTTP client request.
     * @param response
     * 		the HTTP client response.
     * @return an authentication token if the request is authorized or null
     * @throws IOException
     * 		thrown if an IO error occurred
     * @throws AuthenticationException
     * 		thrown if an authentication error occurred
     */
    @Override
    public AuthenticationToken authenticate(HttpServletRequest IJDKEQLUDR, HttpServletResponse XMJBHOTBRM) throws IOException, AuthenticationException {
        AuthenticationToken GHRNLUGTHP;
        if (isBrowser(IJDKEQLUDR.getHeader("User-Agent"))) {
            GHRNLUGTHP = alternateAuthenticate(IJDKEQLUDR, XMJBHOTBRM);
        } else {
            GHRNLUGTHP = super.authenticate(IJDKEQLUDR, XMJBHOTBRM);
        }
        return GHRNLUGTHP;
    }

    /**
     * This method parses the User-Agent String and returns whether or not it
     * refers to a browser.  If its not a browser, then Kerberos authentication
     * will be used; if it is a browser, alternateAuthenticate from the subclass
     * will be used.
     * <p/>
     * A User-Agent String is considered to be a browser if it does not contain
     * any of the values from alt-kerberos.non-browser.user-agents; the default
     * behavior is to consider everything a browser unless it contains one of:
     * "java", "curl", "wget", or "perl".  Subclasses can optionally override
     * this method to use different behavior.
     *
     * @param userAgent
     * 		The User-Agent String, or null if there isn't one
     * @return true if the User-Agent String refers to a browser, false if not
     */
    protected boolean isBrowser(String ZANSUJZAMQ) {
        if (ZANSUJZAMQ == null) {
            return false;
        }
        ZANSUJZAMQ = ZANSUJZAMQ.toLowerCase();
        boolean PDUJXPWGUX = true;
        for (String UJXXDHXJYW : HJGKLVNHEA) {
            if (ZANSUJZAMQ.contains(UJXXDHXJYW)) {
                PDUJXPWGUX = false;
                break;
            }
        }
        return PDUJXPWGUX;
    }

    /**
     * Subclasses should implement this method to provide the custom
     * authentication to be used for browsers.
     *
     * @param request
     * 		the HTTP client request.
     * @param response
     * 		the HTTP client response.
     * @return an authentication token if the request is authorized, or null
     * @throws IOException
     * 		thrown if an IO error occurs
     * @throws AuthenticationException
     * 		thrown if an authentication error occurs
     */
    public abstract AuthenticationToken alternateAuthenticate(HttpServletRequest ISEAYNVWGY, HttpServletResponse WZEJFQTLLD) throws IOException, AuthenticationException;
}