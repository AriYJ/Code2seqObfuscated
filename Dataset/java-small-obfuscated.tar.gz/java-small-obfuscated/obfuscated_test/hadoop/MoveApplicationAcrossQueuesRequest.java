/**
 * <p>The request sent by the client to the <code>ResourceManager</code>
 * to move a submitted application to a different queue.</p>
 *
 * <p>The request includes the {@link ApplicationId} of the application to be
 * moved and the queue to place it in.</p>
 *
 * @see ApplicationClientProtocol#moveApplicationAcrossQueues(MoveApplicationAcrossQueuesRequest)
 */
@Public
@Unstable
public abstract class MoveApplicationAcrossQueuesRequest {
    public static MoveApplicationAcrossQueuesRequest newInstance(ApplicationId DICVUMWOMU, String XELLWROIZM) {
        MoveApplicationAcrossQueuesRequest PYWZUUNAFQ = Records.newRecord(MoveApplicationAcrossQueuesRequest.class);
        PYWZUUNAFQ.setApplicationId(DICVUMWOMU);
        PYWZUUNAFQ.setTargetQueue(XELLWROIZM);
        return PYWZUUNAFQ;
    }

    /**
     * Get the <code>ApplicationId</code> of the application to be moved.
     *
     * @return <code>ApplicationId</code> of the application to be moved
     */
    public abstract ApplicationId getApplicationId();

    /**
     * Set the <code>ApplicationId</code> of the application to be moved.
     *
     * @param appId
     * 		<code>ApplicationId</code> of the application to be moved
     */
    public abstract void setApplicationId(ApplicationId UPHLJHZAOC);

    /**
     * Get the queue to place the application in.
     *
     * @return the name of the queue to place the application in
     */
    public abstract String getTargetQueue();

    /**
     * Get the queue to place the application in.
     *
     * @param queue
     * 		the name of the queue to place the application in
     */
    public abstract void setTargetQueue(String SZDROPLCPI);
}