public class TestApplicationLimits {
    private static final Log RQVIOGHOZZ = LogFactory.getLog(TestApplicationLimits.class);

    static final int DZFFVQFHPU = 1024;

    LeafQueue QUUQDIWGMD;

    private final ResourceCalculator NOHLPGWLYD = new DefaultResourceCalculator();

    @Before
    public void setUp() throws IOException {
        CapacitySchedulerConfiguration DTINJKNOGI = new CapacitySchedulerConfiguration();
        YarnConfiguration NLOJQCOIWN = new YarnConfiguration();
        setupQueueConfiguration(DTINJKNOGI);
        CapacitySchedulerContext EWRTSEQYVC = mock(CapacitySchedulerContext.class);
        when(EWRTSEQYVC.getConfiguration()).thenReturn(DTINJKNOGI);
        when(EWRTSEQYVC.getConf()).thenReturn(NLOJQCOIWN);
        when(EWRTSEQYVC.getMinimumResourceCapability()).thenReturn(Resources.createResource(TestApplicationLimits.DZFFVQFHPU, 1));
        when(EWRTSEQYVC.getMaximumResourceCapability()).thenReturn(Resources.createResource(16 * TestApplicationLimits.DZFFVQFHPU, 32));
        when(EWRTSEQYVC.getClusterResource()).thenReturn(Resources.createResource((10 * 16) * TestApplicationLimits.DZFFVQFHPU, 10 * 32));
        when(EWRTSEQYVC.getApplicationComparator()).thenReturn(CapacityScheduler.applicationComparator);
        when(EWRTSEQYVC.getQueueComparator()).thenReturn(CapacityScheduler.queueComparator);
        when(EWRTSEQYVC.getResourceCalculator()).thenReturn(NOHLPGWLYD);
        RMContainerTokenSecretManager LXELQLCLHM = new RMContainerTokenSecretManager(NLOJQCOIWN);
        LXELQLCLHM.rollMasterKey();
        when(EWRTSEQYVC.getContainerTokenSecretManager()).thenReturn(LXELQLCLHM);
        Map<String, CSQueue> EVXIHHUTNT = new HashMap<String, CSQueue>();
        CSQueue NDFWTZJHZB = CapacityScheduler.parseQueue(EWRTSEQYVC, DTINJKNOGI, null, "root", EVXIHHUTNT, EVXIHHUTNT, spyHook);
        QUUQDIWGMD = spy(new LeafQueue(EWRTSEQYVC, TestApplicationLimits.MCSEJHXFAS, NDFWTZJHZB, null));
        // Stub out ACL checks
        doReturn(true).when(QUUQDIWGMD).hasAccess(any(QueueACL.class), any(UserGroupInformation.class));
        // Some default values
        doReturn(100).when(QUUQDIWGMD).getMaxApplications();
        doReturn(25).when(QUUQDIWGMD).getMaxApplicationsPerUser();
        doReturn(10).when(QUUQDIWGMD).getMaximumActiveApplications();
        doReturn(2).when(QUUQDIWGMD).getMaximumActiveApplicationsPerUser();
    }

    private static final String MCSEJHXFAS = "a";

    private static final String QKUKKNUWJN = "b";

    private void setupQueueConfiguration(CapacitySchedulerConfiguration DTRZSMTMTP) {
        // Define top-level queues
        DTRZSMTMTP.setQueues(ROOT, new String[]{ TestApplicationLimits.MCSEJHXFAS, TestApplicationLimits.QKUKKNUWJN });
        final String AOKIERUJCQ = (CapacitySchedulerConfiguration.ROOT + ".") + TestApplicationLimits.MCSEJHXFAS;
        DTRZSMTMTP.setCapacity(AOKIERUJCQ, 10);
        final String WFQMGPCTTZ = (CapacitySchedulerConfiguration.ROOT + ".") + TestApplicationLimits.QKUKKNUWJN;
        DTRZSMTMTP.setCapacity(WFQMGPCTTZ, 90);
        TestApplicationLimits.RQVIOGHOZZ.info("Setup top-level queues a and b");
    }

    private FiCaSchedulerApp getMockApplication(int WFMHYRFDWB, String NFMYNHTXLB) {
        FiCaSchedulerApp YHUDUBODOE = mock(FiCaSchedulerApp.class);
        ApplicationAttemptId RIGLGINQYV = TestUtils.getMockApplicationAttemptId(WFMHYRFDWB, 0);
        doReturn(RIGLGINQYV.getApplicationId()).when(YHUDUBODOE).getApplicationId();
        doReturn(RIGLGINQYV).when(YHUDUBODOE).getApplicationAttemptId();
        doReturn(NFMYNHTXLB).when(YHUDUBODOE).getUser();
        return YHUDUBODOE;
    }

    @Test
    public void testLimitsComputation() throws Exception {
        CapacitySchedulerConfiguration HGRYYNJUPY = new CapacitySchedulerConfiguration();
        setupQueueConfiguration(HGRYYNJUPY);
        YarnConfiguration OJDKAJFGBO = new YarnConfiguration();
        CapacitySchedulerContext NWISQFNLCT = mock(CapacitySchedulerContext.class);
        when(NWISQFNLCT.getConfiguration()).thenReturn(HGRYYNJUPY);
        when(NWISQFNLCT.getConf()).thenReturn(OJDKAJFGBO);
        when(NWISQFNLCT.getMinimumResourceCapability()).thenReturn(Resources.createResource(TestApplicationLimits.DZFFVQFHPU, 1));
        when(NWISQFNLCT.getMaximumResourceCapability()).thenReturn(Resources.createResource(16 * TestApplicationLimits.DZFFVQFHPU, 16));
        when(NWISQFNLCT.getApplicationComparator()).thenReturn(CapacityScheduler.applicationComparator);
        when(NWISQFNLCT.getQueueComparator()).thenReturn(CapacityScheduler.queueComparator);
        when(NWISQFNLCT.getResourceCalculator()).thenReturn(NOHLPGWLYD);
        // Say cluster has 100 nodes of 16G each
        Resource MFUCYUDLFX = Resources.createResource((100 * 16) * TestApplicationLimits.DZFFVQFHPU, 100 * 16);
        when(NWISQFNLCT.getClusterResource()).thenReturn(MFUCYUDLFX);
        Map<String, CSQueue> QQCJXSTNAB = new HashMap<String, CSQueue>();
        CSQueue WKTAWDDDLE = CapacityScheduler.parseQueue(NWISQFNLCT, HGRYYNJUPY, null, "root", QQCJXSTNAB, QQCJXSTNAB, spyHook);
        LeafQueue FOBIUOBYLN = ((LeafQueue) (QQCJXSTNAB.get(TestApplicationLimits.MCSEJHXFAS)));
        TestApplicationLimits.RQVIOGHOZZ.info(((("Queue 'A' -" + " maxActiveApplications=") + FOBIUOBYLN.getMaximumActiveApplications()) + " maxActiveApplicationsPerUser=") + FOBIUOBYLN.getMaximumActiveApplicationsPerUser());
        int XYVGGCCSZZ = Math.max(1, ((int) (Math.ceil(((((float) (MFUCYUDLFX.getMemory())) / (1 * TestApplicationLimits.DZFFVQFHPU)) * HGRYYNJUPY.getMaximumApplicationMasterResourcePerQueuePercent(FOBIUOBYLN.getQueuePath())) * FOBIUOBYLN.getAbsoluteMaximumCapacity()))));
        assertEquals(XYVGGCCSZZ, FOBIUOBYLN.getMaximumActiveApplications());
        int OLWNAZIEIW = Math.max(1, ((int) (Math.ceil(((((float) (MFUCYUDLFX.getMemory())) / (1 * TestApplicationLimits.DZFFVQFHPU)) * HGRYYNJUPY.getMaximumApplicationMasterResourcePercent()) * FOBIUOBYLN.getAbsoluteCapacity()))));
        assertEquals(((int) (Math.ceil((OLWNAZIEIW * (FOBIUOBYLN.getUserLimit() / 100.0F)) * FOBIUOBYLN.getUserLimitFactor()))), FOBIUOBYLN.getMaximumActiveApplicationsPerUser());
        assertEquals(((int) (MFUCYUDLFX.getMemory() * FOBIUOBYLN.getAbsoluteCapacity())), FOBIUOBYLN.getMetrics().getAvailableMB());
        // Add some nodes to the cluster & test new limits
        MFUCYUDLFX = Resources.createResource((120 * 16) * TestApplicationLimits.DZFFVQFHPU);
        WKTAWDDDLE.updateClusterResource(MFUCYUDLFX);
        XYVGGCCSZZ = Math.max(1, ((int) (Math.ceil(((((float) (MFUCYUDLFX.getMemory())) / (1 * TestApplicationLimits.DZFFVQFHPU)) * HGRYYNJUPY.getMaximumApplicationMasterResourcePerQueuePercent(FOBIUOBYLN.getQueuePath())) * FOBIUOBYLN.getAbsoluteMaximumCapacity()))));
        assertEquals(XYVGGCCSZZ, FOBIUOBYLN.getMaximumActiveApplications());
        OLWNAZIEIW = Math.max(1, ((int) (Math.ceil(((((float) (MFUCYUDLFX.getMemory())) / (1 * TestApplicationLimits.DZFFVQFHPU)) * HGRYYNJUPY.getMaximumApplicationMasterResourcePercent()) * FOBIUOBYLN.getAbsoluteCapacity()))));
        assertEquals(((int) (Math.ceil((OLWNAZIEIW * (FOBIUOBYLN.getUserLimit() / 100.0F)) * FOBIUOBYLN.getUserLimitFactor()))), FOBIUOBYLN.getMaximumActiveApplicationsPerUser());
        assertEquals(((int) (MFUCYUDLFX.getMemory() * FOBIUOBYLN.getAbsoluteCapacity())), FOBIUOBYLN.getMetrics().getAvailableMB());
        // should return -1 if per queue setting not set
        assertEquals(((int) (CapacitySchedulerConfiguration.UNDEFINED)), HGRYYNJUPY.getMaximumApplicationsPerQueue(FOBIUOBYLN.getQueuePath()));
        int NKCBAAFYPD = ((int) (CapacitySchedulerConfiguration.DEFAULT_MAXIMUM_SYSTEM_APPLICATIIONS * FOBIUOBYLN.getAbsoluteCapacity()));
        assertEquals(NKCBAAFYPD, FOBIUOBYLN.getMaxApplications());
        int TDGVLLVYRF = ((int) ((NKCBAAFYPD * (FOBIUOBYLN.getUserLimit() / 100.0F)) * FOBIUOBYLN.getUserLimitFactor()));
        assertEquals(TDGVLLVYRF, FOBIUOBYLN.getMaxApplicationsPerUser());
        // should default to global setting if per queue setting not set
        assertEquals(((long) (CapacitySchedulerConfiguration.DEFAULT_MAXIMUM_APPLICATIONMASTERS_RESOURCE_PERCENT)), ((long) (HGRYYNJUPY.getMaximumApplicationMasterResourcePerQueuePercent(FOBIUOBYLN.getQueuePath()))));
        // Change the per-queue max AM resources percentage.
        HGRYYNJUPY.setFloat(("yarn.scheduler.capacity." + FOBIUOBYLN.getQueuePath()) + ".maximum-am-resource-percent", 0.5F);
        // Re-create queues to get new configs.
        QQCJXSTNAB = new HashMap<String, CSQueue>();
        WKTAWDDDLE = CapacityScheduler.parseQueue(NWISQFNLCT, HGRYYNJUPY, null, "root", QQCJXSTNAB, QQCJXSTNAB, spyHook);
        MFUCYUDLFX = Resources.createResource((100 * 16) * TestApplicationLimits.DZFFVQFHPU);
        FOBIUOBYLN = ((LeafQueue) (QQCJXSTNAB.get(TestApplicationLimits.MCSEJHXFAS)));
        XYVGGCCSZZ = Math.max(1, ((int) (Math.ceil(((((float) (MFUCYUDLFX.getMemory())) / (1 * TestApplicationLimits.DZFFVQFHPU)) * HGRYYNJUPY.getMaximumApplicationMasterResourcePerQueuePercent(FOBIUOBYLN.getQueuePath())) * FOBIUOBYLN.getAbsoluteMaximumCapacity()))));
        assertEquals(((long) (0.5)), ((long) (HGRYYNJUPY.getMaximumApplicationMasterResourcePerQueuePercent(FOBIUOBYLN.getQueuePath()))));
        assertEquals(XYVGGCCSZZ, FOBIUOBYLN.getMaximumActiveApplications());
        // Change the per-queue max applications.
        HGRYYNJUPY.setInt(("yarn.scheduler.capacity." + FOBIUOBYLN.getQueuePath()) + ".maximum-applications", 9999);
        // Re-create queues to get new configs.
        QQCJXSTNAB = new HashMap<String, CSQueue>();
        WKTAWDDDLE = CapacityScheduler.parseQueue(NWISQFNLCT, HGRYYNJUPY, null, "root", QQCJXSTNAB, QQCJXSTNAB, spyHook);
        FOBIUOBYLN = ((LeafQueue) (QQCJXSTNAB.get(TestApplicationLimits.MCSEJHXFAS)));
        assertEquals(9999, ((int) (HGRYYNJUPY.getMaximumApplicationsPerQueue(FOBIUOBYLN.getQueuePath()))));
        assertEquals(9999, FOBIUOBYLN.getMaxApplications());
        TDGVLLVYRF = ((int) ((9999 * (FOBIUOBYLN.getUserLimit() / 100.0F)) * FOBIUOBYLN.getUserLimitFactor()));
        assertEquals(TDGVLLVYRF, FOBIUOBYLN.getMaxApplicationsPerUser());
    }

    @Test
    public void testActiveApplicationLimits() throws Exception {
        final String YEXQLJBKEN = "user_0";
        final String BNHJZYMABX = "user_1";
        int DRSGMDVRSO = 0;
        // Submit first application
        FiCaSchedulerApp QMHANXKFSM = getMockApplication(DRSGMDVRSO++, YEXQLJBKEN);
        QUUQDIWGMD.submitApplicationAttempt(QMHANXKFSM, YEXQLJBKEN);
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications(YEXQLJBKEN));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(YEXQLJBKEN));
        // Submit second application
        FiCaSchedulerApp XDFRIFYNAN = getMockApplication(DRSGMDVRSO++, YEXQLJBKEN);
        QUUQDIWGMD.submitApplicationAttempt(XDFRIFYNAN, YEXQLJBKEN);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(YEXQLJBKEN));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(YEXQLJBKEN));
        // Submit third application, should remain pending
        FiCaSchedulerApp VCQSVDGXWV = getMockApplication(DRSGMDVRSO++, YEXQLJBKEN);
        QUUQDIWGMD.submitApplicationAttempt(VCQSVDGXWV, YEXQLJBKEN);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(YEXQLJBKEN));
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications(YEXQLJBKEN));
        // Finish one application, app_2 should be activated
        QUUQDIWGMD.finishApplicationAttempt(QMHANXKFSM, TestApplicationLimits.MCSEJHXFAS);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(YEXQLJBKEN));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(YEXQLJBKEN));
        // Submit another one for user_0
        FiCaSchedulerApp JTQCCKGSFQ = getMockApplication(DRSGMDVRSO++, YEXQLJBKEN);
        QUUQDIWGMD.submitApplicationAttempt(JTQCCKGSFQ, YEXQLJBKEN);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(YEXQLJBKEN));
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications(YEXQLJBKEN));
        // Change queue limit to be smaller so 2 users can fill it up
        doReturn(3).when(QUUQDIWGMD).getMaximumActiveApplications();
        // Submit first app for user_1
        FiCaSchedulerApp UOPIGAJMBC = getMockApplication(DRSGMDVRSO++, BNHJZYMABX);
        QUUQDIWGMD.submitApplicationAttempt(UOPIGAJMBC, BNHJZYMABX);
        assertEquals(3, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(YEXQLJBKEN));
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications(YEXQLJBKEN));
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications(BNHJZYMABX));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(BNHJZYMABX));
        // Submit second app for user_1, should block due to queue-limit
        FiCaSchedulerApp RQEYKNYHAZ = getMockApplication(DRSGMDVRSO++, BNHJZYMABX);
        QUUQDIWGMD.submitApplicationAttempt(RQEYKNYHAZ, BNHJZYMABX);
        assertEquals(3, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(2, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(YEXQLJBKEN));
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications(YEXQLJBKEN));
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications(BNHJZYMABX));
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications(BNHJZYMABX));
        // Now finish one app of user_1 so app_5 should be activated
        QUUQDIWGMD.finishApplicationAttempt(UOPIGAJMBC, TestApplicationLimits.MCSEJHXFAS);
        assertEquals(3, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(YEXQLJBKEN));
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications(YEXQLJBKEN));
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications(BNHJZYMABX));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(BNHJZYMABX));
    }

    @Test
    public void testActiveLimitsWithKilledApps() throws Exception {
        final String XKNMOKRILF = "user_0";
        int UGDBFNPUMT = 0;
        // set max active to 2
        doReturn(2).when(QUUQDIWGMD).getMaximumActiveApplications();
        // Submit first application
        FiCaSchedulerApp DYSRJWISKA = getMockApplication(UGDBFNPUMT++, XKNMOKRILF);
        QUUQDIWGMD.submitApplicationAttempt(DYSRJWISKA, XKNMOKRILF);
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications(XKNMOKRILF));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(XKNMOKRILF));
        assertTrue(QUUQDIWGMD.activeApplications.contains(DYSRJWISKA));
        // Submit second application
        FiCaSchedulerApp XPWTVJGUIE = getMockApplication(UGDBFNPUMT++, XKNMOKRILF);
        QUUQDIWGMD.submitApplicationAttempt(XPWTVJGUIE, XKNMOKRILF);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(XKNMOKRILF));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(XKNMOKRILF));
        assertTrue(QUUQDIWGMD.activeApplications.contains(XPWTVJGUIE));
        // Submit third application, should remain pending
        FiCaSchedulerApp BGFUEMZJRB = getMockApplication(UGDBFNPUMT++, XKNMOKRILF);
        QUUQDIWGMD.submitApplicationAttempt(BGFUEMZJRB, XKNMOKRILF);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(XKNMOKRILF));
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications(XKNMOKRILF));
        assertTrue(QUUQDIWGMD.pendingApplications.contains(BGFUEMZJRB));
        // Submit fourth application, should remain pending
        FiCaSchedulerApp PJJPEUZQOG = getMockApplication(UGDBFNPUMT++, XKNMOKRILF);
        QUUQDIWGMD.submitApplicationAttempt(PJJPEUZQOG, XKNMOKRILF);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(2, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(XKNMOKRILF));
        assertEquals(2, QUUQDIWGMD.getNumPendingApplications(XKNMOKRILF));
        assertTrue(QUUQDIWGMD.pendingApplications.contains(PJJPEUZQOG));
        // Kill 3rd pending application
        QUUQDIWGMD.finishApplicationAttempt(BGFUEMZJRB, TestApplicationLimits.MCSEJHXFAS);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(XKNMOKRILF));
        assertEquals(1, QUUQDIWGMD.getNumPendingApplications(XKNMOKRILF));
        assertFalse(QUUQDIWGMD.pendingApplications.contains(BGFUEMZJRB));
        assertFalse(QUUQDIWGMD.activeApplications.contains(BGFUEMZJRB));
        // Finish 1st application, app_3 should become active
        QUUQDIWGMD.finishApplicationAttempt(DYSRJWISKA, TestApplicationLimits.MCSEJHXFAS);
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(2, QUUQDIWGMD.getNumActiveApplications(XKNMOKRILF));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(XKNMOKRILF));
        assertTrue(QUUQDIWGMD.activeApplications.contains(PJJPEUZQOG));
        assertFalse(QUUQDIWGMD.pendingApplications.contains(PJJPEUZQOG));
        assertFalse(QUUQDIWGMD.activeApplications.contains(DYSRJWISKA));
        // Finish 2nd application
        QUUQDIWGMD.finishApplicationAttempt(XPWTVJGUIE, TestApplicationLimits.MCSEJHXFAS);
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(1, QUUQDIWGMD.getNumActiveApplications(XKNMOKRILF));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(XKNMOKRILF));
        assertFalse(QUUQDIWGMD.activeApplications.contains(XPWTVJGUIE));
        // Finish 4th application
        QUUQDIWGMD.finishApplicationAttempt(PJJPEUZQOG, TestApplicationLimits.MCSEJHXFAS);
        assertEquals(0, QUUQDIWGMD.getNumActiveApplications());
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications());
        assertEquals(0, QUUQDIWGMD.getNumActiveApplications(XKNMOKRILF));
        assertEquals(0, QUUQDIWGMD.getNumPendingApplications(XKNMOKRILF));
        assertFalse(QUUQDIWGMD.activeApplications.contains(PJJPEUZQOG));
    }

    @Test
    public void testHeadroom() throws Exception {
        CapacitySchedulerConfiguration SMPRWIRWUG = new CapacitySchedulerConfiguration();
        SMPRWIRWUG.setUserLimit((CapacitySchedulerConfiguration.ROOT + ".") + TestApplicationLimits.MCSEJHXFAS, 25);
        setupQueueConfiguration(SMPRWIRWUG);
        YarnConfiguration ELHUMGNREM = new YarnConfiguration();
        CapacitySchedulerContext HWNFDECGDW = mock(CapacitySchedulerContext.class);
        when(HWNFDECGDW.getConfiguration()).thenReturn(SMPRWIRWUG);
        when(HWNFDECGDW.getConf()).thenReturn(ELHUMGNREM);
        when(HWNFDECGDW.getMinimumResourceCapability()).thenReturn(Resources.createResource(TestApplicationLimits.DZFFVQFHPU));
        when(HWNFDECGDW.getMaximumResourceCapability()).thenReturn(Resources.createResource(16 * TestApplicationLimits.DZFFVQFHPU));
        when(HWNFDECGDW.getApplicationComparator()).thenReturn(CapacityScheduler.applicationComparator);
        when(HWNFDECGDW.getQueueComparator()).thenReturn(CapacityScheduler.queueComparator);
        when(HWNFDECGDW.getResourceCalculator()).thenReturn(NOHLPGWLYD);
        // Say cluster has 100 nodes of 16G each
        Resource FYRVXWNPCS = Resources.createResource((100 * 16) * TestApplicationLimits.DZFFVQFHPU);
        when(HWNFDECGDW.getClusterResource()).thenReturn(FYRVXWNPCS);
        Map<String, CSQueue> PHWMRYTDKX = new HashMap<String, CSQueue>();
        CapacityScheduler.parseQueue(HWNFDECGDW, SMPRWIRWUG, null, "root", PHWMRYTDKX, PHWMRYTDKX, spyHook);
        // Manipulate queue 'a'
        LeafQueue QZLGSXVEEV = TestLeafQueue.stubLeafQueue(((LeafQueue) (PHWMRYTDKX.get(TestApplicationLimits.MCSEJHXFAS))));
        String FMDNNRXXBO = "host_0";
        String VKCJCQCATU = "rack_0";
        FiCaSchedulerNode TWKHHYUYFG = TestUtils.getMockNode(FMDNNRXXBO, VKCJCQCATU, 0, 16 * TestApplicationLimits.DZFFVQFHPU);
        final String TNPKWLNVXA = "user_0";
        final String IBPHNCCQLE = "user_1";
        RecordFactory JGCYIKPUOH = RecordFactoryProvider.getRecordFactory(null);
        RMContext NIVOUTYOPD = TestUtils.getMockRMContext();
        Priority ETJAXRBIGY = TestUtils.createMockPriority(1);
        // Submit first application with some resource-requests from user_0,
        // and check headroom
        final ApplicationAttemptId GTUGCSIGAD = TestUtils.getMockApplicationAttemptId(0, 0);
        FiCaSchedulerApp JGOCMNUYOO = spy(new FiCaSchedulerApp(GTUGCSIGAD, TNPKWLNVXA, QZLGSXVEEV, QZLGSXVEEV.getActiveUsersManager(), NIVOUTYOPD));
        QZLGSXVEEV.submitApplicationAttempt(JGOCMNUYOO, TNPKWLNVXA);
        List<ResourceRequest> NTIBZFTJXX = new ArrayList<ResourceRequest>();
        NTIBZFTJXX.add(TestUtils.createResourceRequest(ANY, 1 * TestApplicationLimits.DZFFVQFHPU, 2, true, ETJAXRBIGY, JGCYIKPUOH));
        JGOCMNUYOO.updateResourceRequests(NTIBZFTJXX);
        // Schedule to compute
        QZLGSXVEEV.assignContainers(FYRVXWNPCS, TWKHHYUYFG);
        Resource HWQKJKBZRF = Resources.createResource((10 * 16) * TestApplicationLimits.DZFFVQFHPU, 1);
        verify(JGOCMNUYOO).setHeadroom(eq(HWQKJKBZRF));
        // Submit second application from user_0, check headroom
        final ApplicationAttemptId EPKKGMOWSK = TestUtils.getMockApplicationAttemptId(1, 0);
        FiCaSchedulerApp EUYOQJMTTF = spy(new FiCaSchedulerApp(EPKKGMOWSK, TNPKWLNVXA, QZLGSXVEEV, QZLGSXVEEV.getActiveUsersManager(), NIVOUTYOPD));
        QZLGSXVEEV.submitApplicationAttempt(EUYOQJMTTF, TNPKWLNVXA);
        List<ResourceRequest> ECJNOHGRYS = new ArrayList<ResourceRequest>();
        ECJNOHGRYS.add(TestUtils.createResourceRequest(ANY, 1 * TestApplicationLimits.DZFFVQFHPU, 2, true, ETJAXRBIGY, JGCYIKPUOH));
        EUYOQJMTTF.updateResourceRequests(ECJNOHGRYS);
        // Schedule to compute
        QZLGSXVEEV.assignContainers(FYRVXWNPCS, TWKHHYUYFG);// Schedule to compute

        verify(JGOCMNUYOO, times(2)).setHeadroom(eq(HWQKJKBZRF));
        verify(EUYOQJMTTF).setHeadroom(eq(HWQKJKBZRF));// no change

        // Submit first application from user_1, check  for new headroom
        final ApplicationAttemptId MHHZODDPNQ = TestUtils.getMockApplicationAttemptId(2, 0);
        FiCaSchedulerApp MHUOBVXJER = spy(new FiCaSchedulerApp(MHHZODDPNQ, IBPHNCCQLE, QZLGSXVEEV, QZLGSXVEEV.getActiveUsersManager(), NIVOUTYOPD));
        QZLGSXVEEV.submitApplicationAttempt(MHUOBVXJER, IBPHNCCQLE);
        List<ResourceRequest> NYIZTBHGZE = new ArrayList<ResourceRequest>();
        NYIZTBHGZE.add(TestUtils.createResourceRequest(ANY, 1 * TestApplicationLimits.DZFFVQFHPU, 2, true, ETJAXRBIGY, JGCYIKPUOH));
        MHUOBVXJER.updateResourceRequests(NYIZTBHGZE);
        // Schedule to compute
        QZLGSXVEEV.assignContainers(FYRVXWNPCS, TWKHHYUYFG);// Schedule to compute

        HWQKJKBZRF = Resources.createResource(((10 * 16) * TestApplicationLimits.DZFFVQFHPU) / 2, 1);// changes

        verify(JGOCMNUYOO).setHeadroom(eq(HWQKJKBZRF));
        verify(EUYOQJMTTF).setHeadroom(eq(HWQKJKBZRF));
        verify(MHUOBVXJER).setHeadroom(eq(HWQKJKBZRF));
        // Now reduce cluster size and check for the smaller headroom
        FYRVXWNPCS = Resources.createResource((90 * 16) * TestApplicationLimits.DZFFVQFHPU);
        QZLGSXVEEV.assignContainers(FYRVXWNPCS, TWKHHYUYFG);// Schedule to compute

        HWQKJKBZRF = Resources.createResource(((9 * 16) * TestApplicationLimits.DZFFVQFHPU) / 2, 1);// changes

        verify(JGOCMNUYOO).setHeadroom(eq(HWQKJKBZRF));
        verify(EUYOQJMTTF).setHeadroom(eq(HWQKJKBZRF));
        verify(MHUOBVXJER).setHeadroom(eq(HWQKJKBZRF));
    }

    @After
    public void tearDown() {
    }
}