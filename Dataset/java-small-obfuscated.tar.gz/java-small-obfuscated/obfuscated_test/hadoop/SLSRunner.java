@Private
@Unstable
public class SLSRunner {
    // RM, Runner
    private ResourceManager UXYBSPFTMP;

    private static TaskRunner ALNGUXRCAL = new TaskRunner();

    private String[] KKNKGGKWVA;

    private Configuration DWXDIBYKNM;

    private Map<String, Integer> RMTDTBVLGJ;

    // NM simulator
    private HashMap<NodeId, NMSimulator> RGFTJPITMO;

    private int VNUSYLEBAH;

    private int WAFXRXNWCB;

    private String HSPPDYPLVL;

    // AM simulator
    private int GVBCMDJUQR;

    private Map<String, AMSimulator> UQSEEOXTGZ;

    private Set<String> RBAKWFADWL;

    private Map<String, Class> HRHZJWMCBO;

    private static int UDEAZLTAJD = 0;

    // metrics
    private String XPYTEAFGKM;

    private boolean WERDFFTYTX;

    private int FCEQULKMLR;

    private int AWVCVEMDDF;

    private int NEFRJMVPEI;

    // other simulation information
    private int IQZQEQQQPX;

    private long NQYZFKAUPG;

    public static final Map<String, Object> RIEHQVPABW = new HashMap<String, Object>();

    // logger
    public static final Logger UQRQGCMGTQ = Logger.getLogger(SLSRunner.class);

    // input traces, input-rumen or input-sls
    private boolean QPITZBZJWJ;

    public SLSRunner(boolean NZGXIWZPJG, String[] RYFJPLMSFG, String WXBTBFEUYV, String TLXFRDAVNI, Set<String> EPBKZIUOTZ, boolean DBYEPWPNOE) throws IOException, ClassNotFoundException {
        this.QPITZBZJWJ = NZGXIWZPJG;
        this.KKNKGGKWVA = RYFJPLMSFG.clone();
        this.HSPPDYPLVL = WXBTBFEUYV;
        this.RBAKWFADWL = EPBKZIUOTZ;
        this.WERDFFTYTX = DBYEPWPNOE;
        XPYTEAFGKM = TLXFRDAVNI;
        RGFTJPITMO = new HashMap<NodeId, NMSimulator>();
        RMTDTBVLGJ = new HashMap<String, Integer>();
        UQSEEOXTGZ = new HashMap<String, AMSimulator>();
        HRHZJWMCBO = new HashMap<String, Class>();
        // runner configuration
        DWXDIBYKNM = new Configuration(false);
        DWXDIBYKNM.addResource("sls-runner.xml");
        // runner
        int ABXNRCKISB = DWXDIBYKNM.getInt(RUNNER_POOL_SIZE, RUNNER_POOL_SIZE_DEFAULT);
        SLSRunner.ALNGUXRCAL.setQueueSize(ABXNRCKISB);
        // <AMType, Class> map
        for (Map.Entry TOJJEOYALT : DWXDIBYKNM) {
            String UVFPRKFMRD = TOJJEOYALT.getKey().toString();
            if (UVFPRKFMRD.startsWith(AM_TYPE)) {
                String AMSTJMFQQV = UVFPRKFMRD.substring(AM_TYPE.length());
                HRHZJWMCBO.put(AMSTJMFQQV, Class.forName(DWXDIBYKNM.get(UVFPRKFMRD)));
            }
        }
    }

    public void start() throws Exception {
        // start resource manager
        startRM();
        // start node managers
        startNM();
        // start application masters
        startAM();
        // set queue & tracked apps information
        ((org.apache.hadoop.yarn.sls.scheduler.SchedulerWrapper) (UXYBSPFTMP.getResourceScheduler())).setQueueSet(this.RMTDTBVLGJ.keySet());
        ((org.apache.hadoop.yarn.sls.scheduler.SchedulerWrapper) (UXYBSPFTMP.getResourceScheduler())).setTrackedAppSet(this.RBAKWFADWL);
        // print out simulation info
        printSimulationInfo();
        // blocked until all nodes RUNNING
        waitForNodesRunning();
        // starting the runner once everything is ready to go,
        SLSRunner.ALNGUXRCAL.start();
    }

    private void startRM() throws IOException, ClassNotFoundException {
        Configuration FUCAYACGSP = new YarnConfiguration();
        String GUHCCRNEAC = FUCAYACGSP.get(RM_SCHEDULER);
        // For CapacityScheduler we use a sub-classing instead of wrapping
        // to allow scheduler-specific invocations from monitors to work
        // this can be used for other schedulers as well if we care to
        // exercise/track behaviors that are not common to the scheduler api
        if (Class.forName(GUHCCRNEAC) == CapacityScheduler.class) {
            FUCAYACGSP.set(RM_SCHEDULER, SLSCapacityScheduler.class.getName());
        } else {
            FUCAYACGSP.set(RM_SCHEDULER, ResourceSchedulerWrapper.class.getName());
            FUCAYACGSP.set(SLSConfiguration.RM_SCHEDULER, GUHCCRNEAC);
        }
        FUCAYACGSP.set(METRICS_OUTPUT_DIR, XPYTEAFGKM);
        UXYBSPFTMP = new ResourceManager();
        UXYBSPFTMP.init(FUCAYACGSP);
        UXYBSPFTMP.start();
    }

    private void startNM() throws IOException, YarnException {
        // nm configuration
        VNUSYLEBAH = DWXDIBYKNM.getInt(NM_MEMORY_MB, NM_MEMORY_MB_DEFAULT);
        WAFXRXNWCB = DWXDIBYKNM.getInt(NM_VCORES, NM_VCORES_DEFAULT);
        int IOIAZVOPRU = DWXDIBYKNM.getInt(NM_HEARTBEAT_INTERVAL_MS, NM_HEARTBEAT_INTERVAL_MS_DEFAULT);
        // nm information (fetch from topology file, or from sls/rumen json file)
        Set<String> JDTYIQFFNC = new HashSet<String>();
        if (HSPPDYPLVL.isEmpty()) {
            if (QPITZBZJWJ) {
                for (String OGLYYCPLBX : KKNKGGKWVA) {
                    JDTYIQFFNC.addAll(SLSUtils.parseNodesFromSLSTrace(OGLYYCPLBX));
                }
            } else {
                for (String DWCVDOYGZL : KKNKGGKWVA) {
                    JDTYIQFFNC.addAll(SLSUtils.parseNodesFromRumenTrace(DWCVDOYGZL));
                }
            }
        } else {
            JDTYIQFFNC.addAll(SLSUtils.parseNodesFromNodeFile(HSPPDYPLVL));
        }
        // create NM simulators
        Random HKSZSBSDTJ = new Random();
        Set<String> SAGVQFCVWT = new HashSet<String>();
        for (String ZAXOUXMLDD : JDTYIQFFNC) {
            // we randomize the heartbeat start time from zero to 1 interval
            NMSimulator EGDOPHNXGF = new NMSimulator();
            EGDOPHNXGF.init(ZAXOUXMLDD, VNUSYLEBAH, WAFXRXNWCB, HKSZSBSDTJ.nextInt(IOIAZVOPRU), IOIAZVOPRU, UXYBSPFTMP);
            RGFTJPITMO.put(EGDOPHNXGF.getNode().getNodeID(), EGDOPHNXGF);
            SLSRunner.ALNGUXRCAL.schedule(EGDOPHNXGF);
            SAGVQFCVWT.add(EGDOPHNXGF.getNode().getRackName());
        }
        AWVCVEMDDF = SAGVQFCVWT.size();
        FCEQULKMLR = RGFTJPITMO.size();
    }

    private void waitForNodesRunning() throws InterruptedException {
        long HACUSMJBEI = System.currentTimeMillis();
        while (true) {
            int FTARPZIVYN = 0;
            for (RMNode WSGGYSMUCD : UXYBSPFTMP.getRMContext().getRMNodes().values()) {
                if (WSGGYSMUCD.getState() == NodeState.RUNNING) {
                    FTARPZIVYN++;
                }
            }
            if (FTARPZIVYN == FCEQULKMLR) {
                break;
            }
            SLSRunner.UQRQGCMGTQ.info(MessageFormat.format("SLSRunner is waiting for all " + "nodes RUNNING. {0} of {1} NMs initialized.", FTARPZIVYN, FCEQULKMLR));
            Thread.sleep(1000);
        } 
        SLSRunner.UQRQGCMGTQ.info(MessageFormat.format("SLSRunner takes {0} ms to launch all nodes.", System.currentTimeMillis() - HACUSMJBEI));
    }

    @SuppressWarnings("unchecked")
    private void startAM() throws IOException, YarnException {
        // application/container configuration
        int VNMQWCTTZM = DWXDIBYKNM.getInt(AM_HEARTBEAT_INTERVAL_MS, AM_HEARTBEAT_INTERVAL_MS_DEFAULT);
        int GIPLMGZXHR = DWXDIBYKNM.getInt(CONTAINER_MEMORY_MB, CONTAINER_MEMORY_MB_DEFAULT);
        int HPOOUMESBO = DWXDIBYKNM.getInt(CONTAINER_VCORES, CONTAINER_VCORES_DEFAULT);
        Resource DMPZJIMQSQ = BuilderUtils.newResource(GIPLMGZXHR, HPOOUMESBO);
        // application workload
        if (QPITZBZJWJ) {
            startAMFromSLSTraces(DMPZJIMQSQ, VNMQWCTTZM);
        } else {
            startAMFromRumenTraces(DMPZJIMQSQ, VNMQWCTTZM);
        }
        NEFRJMVPEI = UQSEEOXTGZ.size();
        SLSRunner.UDEAZLTAJD = NEFRJMVPEI;
    }

    /**
     * parse workload information from sls trace files
     */
    @SuppressWarnings("unchecked")
    private void startAMFromSLSTraces(Resource IUKWNATFLX, int LHNVEKDFPG) throws IOException {
        // parse from sls traces
        JsonFactory USZWFMXPFU = new JsonFactory();
        ObjectMapper RIKGNAWIEU = new ObjectMapper();
        for (String EQKVHLOURT : KKNKGGKWVA) {
            Reader VAFLIJYUOL = new FileReader(EQKVHLOURT);
            try {
                Iterator<Map> UQIZTLJDYQ = RIKGNAWIEU.readValues(USZWFMXPFU.createJsonParser(VAFLIJYUOL), Map.class);
                while (UQIZTLJDYQ.hasNext()) {
                    Map WLNZEGBLVK = UQIZTLJDYQ.next();
                    // load job information
                    long FPEEVWTNBX = Long.parseLong(WLNZEGBLVK.get("job.start.ms").toString());
                    long YLLDVXXTPJ = Long.parseLong(WLNZEGBLVK.get("job.end.ms").toString());
                    String CIAUFNDVQM = ((String) (WLNZEGBLVK.get("job.user")));
                    if (CIAUFNDVQM == null)
                        CIAUFNDVQM = "default";

                    String OROVXHXNTF = WLNZEGBLVK.get("job.queue.name").toString();
                    String UXLPCTSARY = WLNZEGBLVK.get("job.id").toString();
                    boolean QNLVJSAVAE = RBAKWFADWL.contains(UXLPCTSARY);
                    int KOZDBXNTFV = (RMTDTBVLGJ.containsKey(OROVXHXNTF)) ? RMTDTBVLGJ.get(OROVXHXNTF) : 0;
                    KOZDBXNTFV++;
                    RMTDTBVLGJ.put(OROVXHXNTF, KOZDBXNTFV);
                    // tasks
                    List YWPYWEMOYK = ((List) (WLNZEGBLVK.get("job.tasks")));
                    if ((YWPYWEMOYK == null) || (YWPYWEMOYK.size() == 0)) {
                        continue;
                    }
                    List<ContainerSimulator> OSHUEJOKXF = new ArrayList<ContainerSimulator>();
                    for (Object ERRUBOTNAD : YWPYWEMOYK) {
                        Map VFPGDIUFUK = ((Map) (ERRUBOTNAD));
                        String URTYILVEWK = VFPGDIUFUK.get("container.host").toString();
                        long DFYTQEVANM = Long.parseLong(VFPGDIUFUK.get("container.start.ms").toString());
                        long QOABVHLDSJ = Long.parseLong(VFPGDIUFUK.get("container.end.ms").toString());
                        long MOSBMZUEZZ = QOABVHLDSJ - DFYTQEVANM;
                        int ODBRYEZDUP = Integer.parseInt(VFPGDIUFUK.get("container.priority").toString());
                        String HWEYSELGOR = VFPGDIUFUK.get("container.type").toString();
                        OSHUEJOKXF.add(new ContainerSimulator(IUKWNATFLX, MOSBMZUEZZ, URTYILVEWK, ODBRYEZDUP, HWEYSELGOR));
                    }
                    // create a new AM
                    String PCIGBZCFPQ = WLNZEGBLVK.get("am.type").toString();
                    AMSimulator VJRFVLLCPT = ((AMSimulator) (ReflectionUtils.newInstance(HRHZJWMCBO.get(PCIGBZCFPQ), new Configuration())));
                    if (VJRFVLLCPT != null) {
                        VJRFVLLCPT.init(GVBCMDJUQR++, LHNVEKDFPG, OSHUEJOKXF, UXYBSPFTMP, this, FPEEVWTNBX, YLLDVXXTPJ, CIAUFNDVQM, OROVXHXNTF, QNLVJSAVAE, UXLPCTSARY);
                        SLSRunner.ALNGUXRCAL.schedule(VJRFVLLCPT);
                        NQYZFKAUPG = Math.max(NQYZFKAUPG, YLLDVXXTPJ);
                        IQZQEQQQPX += OSHUEJOKXF.size();
                        UQSEEOXTGZ.put(UXLPCTSARY, VJRFVLLCPT);
                    }
                } 
            } finally {
                VAFLIJYUOL.close();
            }
        }
    }

    /**
     * parse workload information from rumen trace files
     */
    @SuppressWarnings("unchecked")
    private void startAMFromRumenTraces(Resource PEGNZQTGRN, int UCGRHLHFOO) throws IOException {
        Configuration IRFSFQMIAQ = new Configuration();
        IRFSFQMIAQ.set("fs.defaultFS", "file:///");
        long SQGTPNXLSV = 0;
        for (String VTLAQCSYSO : KKNKGGKWVA) {
            File MTTERXJHLI = new File(VTLAQCSYSO);
            JobTraceReader VSNPGFIUNY = new JobTraceReader(new Path(MTTERXJHLI.getAbsolutePath()), IRFSFQMIAQ);
            try {
                LoggedJob SSERDCWWAC = null;
                while ((SSERDCWWAC = VSNPGFIUNY.getNext()) != null) {
                    // only support MapReduce currently
                    String XFSESWYXDH = "mapreduce";
                    String HWTENURDAX = (SSERDCWWAC.getUser() == null) ? "default" : SSERDCWWAC.getUser().getValue();
                    String BENONWXDTP = SSERDCWWAC.getQueue().getValue();
                    String LLJJXJRKHW = SSERDCWWAC.getJobID().toString();
                    long FKRMJTHFWM = SSERDCWWAC.getSubmitTime();
                    long YSMOVXVKUA = SSERDCWWAC.getFinishTime();
                    if (SQGTPNXLSV == 0) {
                        SQGTPNXLSV = FKRMJTHFWM;
                    }
                    FKRMJTHFWM -= SQGTPNXLSV;
                    YSMOVXVKUA -= SQGTPNXLSV;
                    if (FKRMJTHFWM < 0) {
                        SLSRunner.UQRQGCMGTQ.warn(("Warning: reset job " + LLJJXJRKHW) + " start time to 0.");
                        YSMOVXVKUA = YSMOVXVKUA - FKRMJTHFWM;
                        FKRMJTHFWM = 0;
                    }
                    boolean SDYPYELBVM = RBAKWFADWL.contains(LLJJXJRKHW);
                    int ESCEQZADKL = (RMTDTBVLGJ.containsKey(BENONWXDTP)) ? RMTDTBVLGJ.get(BENONWXDTP) : 0;
                    ESCEQZADKL++;
                    RMTDTBVLGJ.put(BENONWXDTP, ESCEQZADKL);
                    List<ContainerSimulator> WRZPMVBHAB = new ArrayList<ContainerSimulator>();
                    // map tasks
                    for (LoggedTask QTLQVETCNF : SSERDCWWAC.getMapTasks()) {
                        LoggedTaskAttempt JYEWEXPXQT = QTLQVETCNF.getAttempts().get(QTLQVETCNF.getAttempts().size() - 1);
                        String PKIMXPYXDN = JYEWEXPXQT.getHostName().getValue();
                        long FDVPDKUSPN = JYEWEXPXQT.getFinishTime() - JYEWEXPXQT.getStartTime();
                        WRZPMVBHAB.add(new ContainerSimulator(PEGNZQTGRN, FDVPDKUSPN, PKIMXPYXDN, 10, "map"));
                    }
                    // reduce tasks
                    for (LoggedTask BQGSVVRTAD : SSERDCWWAC.getReduceTasks()) {
                        LoggedTaskAttempt BGZRRSCNTR = BQGSVVRTAD.getAttempts().get(BQGSVVRTAD.getAttempts().size() - 1);
                        String PIGWUMORMC = BGZRRSCNTR.getHostName().getValue();
                        long UTARZBNUZN = BGZRRSCNTR.getFinishTime() - BGZRRSCNTR.getStartTime();
                        WRZPMVBHAB.add(new ContainerSimulator(PEGNZQTGRN, UTARZBNUZN, PIGWUMORMC, 20, "reduce"));
                    }
                    // create a new AM
                    AMSimulator RQUTHXNBJG = ((AMSimulator) (ReflectionUtils.newInstance(HRHZJWMCBO.get(XFSESWYXDH), IRFSFQMIAQ)));
                    if (RQUTHXNBJG != null) {
                        RQUTHXNBJG.init(GVBCMDJUQR++, UCGRHLHFOO, WRZPMVBHAB, UXYBSPFTMP, this, FKRMJTHFWM, YSMOVXVKUA, HWTENURDAX, BENONWXDTP, SDYPYELBVM, LLJJXJRKHW);
                        SLSRunner.ALNGUXRCAL.schedule(RQUTHXNBJG);
                        NQYZFKAUPG = Math.max(NQYZFKAUPG, YSMOVXVKUA);
                        IQZQEQQQPX += WRZPMVBHAB.size();
                        UQSEEOXTGZ.put(LLJJXJRKHW, RQUTHXNBJG);
                    }
                } 
            } finally {
                VSNPGFIUNY.close();
            }
        }
    }

    private void printSimulationInfo() {
        if (WERDFFTYTX) {
            // node
            SLSRunner.UQRQGCMGTQ.info("------------------------------------");
            SLSRunner.UQRQGCMGTQ.info(MessageFormat.format("# nodes = {0}, # racks = {1}, capacity " + "of each node {2} MB memory and {3} vcores.", FCEQULKMLR, AWVCVEMDDF, VNUSYLEBAH, WAFXRXNWCB));
            SLSRunner.UQRQGCMGTQ.info("------------------------------------");
            // job
            SLSRunner.UQRQGCMGTQ.info(MessageFormat.format("# applications = {0}, # total " + "tasks = {1}, average # tasks per application = {2}", NEFRJMVPEI, IQZQEQQQPX, ((int) (Math.ceil((IQZQEQQQPX + 0.0) / NEFRJMVPEI)))));
            SLSRunner.UQRQGCMGTQ.info("JobId\tQueue\tAMType\tDuration\t#Tasks");
            for (Map.Entry<String, AMSimulator> RWMACJVDXO : UQSEEOXTGZ.entrySet()) {
                AMSimulator VRHWKWQWCW = RWMACJVDXO.getValue();
                SLSRunner.UQRQGCMGTQ.info((((((((RWMACJVDXO.getKey() + "\t") + VRHWKWQWCW.getQueue()) + "\t") + VRHWKWQWCW.getAMType()) + "\t") + VRHWKWQWCW.getDuration()) + "\t") + VRHWKWQWCW.getNumTasks());
            }
            SLSRunner.UQRQGCMGTQ.info("------------------------------------");
            // queue
            SLSRunner.UQRQGCMGTQ.info(MessageFormat.format("number of queues = {0}  average " + "number of apps = {1}", RMTDTBVLGJ.size(), ((int) (Math.ceil((NEFRJMVPEI + 0.0) / RMTDTBVLGJ.size())))));
            SLSRunner.UQRQGCMGTQ.info("------------------------------------");
            // runtime
            SLSRunner.UQRQGCMGTQ.info(MessageFormat.format("estimated simulation time is {0}" + " seconds", ((long) (Math.ceil(NQYZFKAUPG / 1000.0)))));
            SLSRunner.UQRQGCMGTQ.info("------------------------------------");
        }
        // package these information in the simulateInfoMap used by other places
        SLSRunner.RIEHQVPABW.put("Number of racks", AWVCVEMDDF);
        SLSRunner.RIEHQVPABW.put("Number of nodes", FCEQULKMLR);
        SLSRunner.RIEHQVPABW.put("Node memory (MB)", VNUSYLEBAH);
        SLSRunner.RIEHQVPABW.put("Node VCores", WAFXRXNWCB);
        SLSRunner.RIEHQVPABW.put("Number of applications", NEFRJMVPEI);
        SLSRunner.RIEHQVPABW.put("Number of tasks", IQZQEQQQPX);
        SLSRunner.RIEHQVPABW.put("Average tasks per applicaion", ((int) (Math.ceil((IQZQEQQQPX + 0.0) / NEFRJMVPEI))));
        SLSRunner.RIEHQVPABW.put("Number of queues", RMTDTBVLGJ.size());
        SLSRunner.RIEHQVPABW.put("Average applications per queue", ((int) (Math.ceil((NEFRJMVPEI + 0.0) / RMTDTBVLGJ.size()))));
        SLSRunner.RIEHQVPABW.put("Estimated simulate time (s)", ((long) (Math.ceil(NQYZFKAUPG / 1000.0))));
    }

    public HashMap<NodeId, NMSimulator> getNmMap() {
        return RGFTJPITMO;
    }

    public static TaskRunner getRunner() {
        return SLSRunner.ALNGUXRCAL;
    }

    public static void decreaseRemainingApps() {
        SLSRunner.UDEAZLTAJD--;
        if (SLSRunner.UDEAZLTAJD == 0) {
            SLSRunner.UQRQGCMGTQ.info("SLSRunner tears down.");
            System.exit(0);
        }
    }

    public static void main(String[] LOJSJKMHQU) throws Exception {
        Options ZBZUHOLQSE = new Options();
        ZBZUHOLQSE.addOption("inputrumen", true, "input rumen files");
        ZBZUHOLQSE.addOption("inputsls", true, "input sls files");
        ZBZUHOLQSE.addOption("nodes", true, "input topology");
        ZBZUHOLQSE.addOption("output", true, "output directory");
        ZBZUHOLQSE.addOption("trackjobs", true, "jobs to be tracked during simulating");
        ZBZUHOLQSE.addOption("printsimulation", false, "print out simulation information");
        CommandLineParser MRVHTAKPWO = new GnuParser();
        CommandLine NNOZEJOESS = MRVHTAKPWO.parse(ZBZUHOLQSE, LOJSJKMHQU);
        String TVBOPCPHID = NNOZEJOESS.getOptionValue("inputrumen");
        String UKOTVUDBOF = NNOZEJOESS.getOptionValue("inputsls");
        String GZVPTGZTKC = NNOZEJOESS.getOptionValue("output");
        if (((TVBOPCPHID == null) && (UKOTVUDBOF == null)) || (GZVPTGZTKC == null)) {
            System.err.println();
            System.err.println("ERROR: Missing input or output file");
            System.err.println();
            System.err.println("Options: -inputrumen|-inputsls FILE,FILE... " + ("-output FILE [-nodes FILE] [-trackjobs JobId,JobId...] " + "[-printsimulation]"));
            System.err.println();
            System.exit(1);
        }
        File YBDICAYBCT = new File(GZVPTGZTKC);
        if ((!YBDICAYBCT.exists()) && (!YBDICAYBCT.mkdirs())) {
            System.err.println("ERROR: Cannot create output directory " + YBDICAYBCT.getAbsolutePath());
            System.exit(1);
        }
        Set<String> HHPJVJJUSX = new HashSet<String>();
        if (NNOZEJOESS.hasOption("trackjobs")) {
            String WFVHFXXQGQ = NNOZEJOESS.getOptionValue("trackjobs");
            String[] BASFJACDEH = WFVHFXXQGQ.split(",");
            HHPJVJJUSX.addAll(Arrays.asList(BASFJACDEH));
        }
        String FCSCGJAYAR = (NNOZEJOESS.hasOption("nodes")) ? NNOZEJOESS.getOptionValue("nodes") : "";
        boolean PIOWDWQPSX = UKOTVUDBOF != null;
        String[] SOYLLRZWJB = (PIOWDWQPSX) ? UKOTVUDBOF.split(",") : TVBOPCPHID.split(",");
        SLSRunner BMINJQDFHV = new SLSRunner(PIOWDWQPSX, SOYLLRZWJB, FCSCGJAYAR, GZVPTGZTKC, HHPJVJJUSX, NNOZEJOESS.hasOption("printsimulation"));
        BMINJQDFHV.start();
    }
}