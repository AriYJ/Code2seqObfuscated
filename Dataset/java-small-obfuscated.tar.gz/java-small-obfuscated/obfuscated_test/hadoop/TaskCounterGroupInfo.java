@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class TaskCounterGroupInfo {
    protected String VWZSUFDYXN;

    protected ArrayList<TaskCounterInfo> DEHMNWKCQR;

    public TaskCounterGroupInfo() {
    }

    public TaskCounterGroupInfo(String OBWWHOZDEK, CounterGroup HXULTJERLD) {
        this.VWZSUFDYXN = OBWWHOZDEK;
        this.DEHMNWKCQR = new ArrayList<TaskCounterInfo>();
        for (Counter JOEEVOMAUL : HXULTJERLD) {
            TaskCounterInfo JYGPZAFHAZ = new TaskCounterInfo(JOEEVOMAUL.getName(), JOEEVOMAUL.getValue());
            this.DEHMNWKCQR.add(JYGPZAFHAZ);
        }
    }
}