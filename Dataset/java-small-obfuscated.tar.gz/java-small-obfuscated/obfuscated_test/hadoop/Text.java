/**
 * This class stores text using standard UTF8 encoding.  It provides methods
 * to serialize, deserialize, and compare texts at byte level.  The type of
 * length is integer and is serialized using zero-compressed format.  <p>In
 * addition, it provides methods for string traversal without converting the
 * byte array to a string.  <p>Also includes utilities for
 * serializing/deserialing a string, coding/decoding a string, checking if a
 * byte array contains valid UTF8 code, calculating the length of an encoded
 * string.
 */
@Stringable
@InterfaceAudience.Public
@InterfaceStability.Stable
public class Text extends BinaryComparable implements WritableComparable<BinaryComparable> {
    private static ThreadLocal<CharsetEncoder> OUWGXJCTAL = new ThreadLocal<CharsetEncoder>() {
        @Override
        protected CharsetEncoder initialValue() {
            return Charset.forName("UTF-8").newEncoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
        }
    };

    private static ThreadLocal<CharsetDecoder> IFXPRQHYBD = new ThreadLocal<CharsetDecoder>() {
        @Override
        protected CharsetDecoder initialValue() {
            return Charset.forName("UTF-8").newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
        }
    };

    private static final byte[] TSMQKFHOWE = new byte[0];

    private byte[] NLYRAKKFQU;

    private int UJDMIEJBLJ;

    public Text() {
        NLYRAKKFQU = Text.TSMQKFHOWE;
    }

    /**
     * Construct from a string.
     */
    public Text(String EAQGLUMHWL) {
        set(EAQGLUMHWL);
    }

    /**
     * Construct from another text.
     */
    public Text(Text RIPXETWITK) {
        set(RIPXETWITK);
    }

    /**
     * Construct from a byte array.
     */
    public Text(byte[] SJDPSUXGXF) {
        set(SJDPSUXGXF);
    }

    /**
     * Get a copy of the bytes that is exactly the length of the data.
     * See {@link #getBytes()} for faster access to the underlying array.
     */
    public byte[] copyBytes() {
        byte[] LRINXMZNGJ = new byte[UJDMIEJBLJ];
        System.arraycopy(NLYRAKKFQU, 0, LRINXMZNGJ, 0, UJDMIEJBLJ);
        return LRINXMZNGJ;
    }

    /**
     * Returns the raw bytes; however, only data up to {@link #getLength()} is
     * valid. Please use {@link #copyBytes()} if you
     * need the returned array to be precisely the length of the data.
     */
    @Override
    public byte[] getBytes() {
        return NLYRAKKFQU;
    }

    /**
     * Returns the number of bytes in the byte array
     */
    @Override
    public int getLength() {
        return UJDMIEJBLJ;
    }

    /**
     * Returns the Unicode Scalar Value (32-bit integer value)
     * for the character at <code>position</code>. Note that this
     * method avoids using the converter or doing String instantiation
     *
     * @return the Unicode scalar value at position or -1
    if the position is invalid or points to a
    trailing byte
     */
    public int charAt(int QOEEPSNLCD) {
        if (QOEEPSNLCD > this.UJDMIEJBLJ)
            return -1;
        // too long

        if (QOEEPSNLCD < 0)
            return -1;
        // duh.

        ByteBuffer MKWUEYAUQB = ((ByteBuffer) (ByteBuffer.wrap(NLYRAKKFQU).position(QOEEPSNLCD)));
        return Text.bytesToCodePoint(MKWUEYAUQB.slice());
    }

    public int find(String HBMFPYHEUL) {
        return find(HBMFPYHEUL, 0);
    }

    /**
     * Finds any occurence of <code>what</code> in the backing
     * buffer, starting as position <code>start</code>. The starting
     * position is measured in bytes and the return value is in
     * terms of byte position in the buffer. The backing buffer is
     * not converted to a string for this operation.
     *
     * @return byte position of the first occurence of the search
    string in the UTF-8 buffer or -1 if not found
     */
    public int find(String GRTGWUJCPX, int MPSJMZGDXN) {
        try {
            ByteBuffer YCXGWTNNKQ = ByteBuffer.wrap(this.NLYRAKKFQU, 0, this.UJDMIEJBLJ);
            ByteBuffer EXCTQWEIAP = Text.encode(GRTGWUJCPX);
            byte WROHOWUYFG = EXCTQWEIAP.get();
            YCXGWTNNKQ.position(MPSJMZGDXN);
            while (YCXGWTNNKQ.hasRemaining()) {
                if (WROHOWUYFG == YCXGWTNNKQ.get()) {
                    // matching first byte
                    YCXGWTNNKQ.mark();// save position in loop

                    EXCTQWEIAP.mark();// save position in target

                    boolean HGBXJNZTZG = true;
                    int JXEKDPMQYR = YCXGWTNNKQ.position() - 1;
                    while (EXCTQWEIAP.hasRemaining()) {
                        if (!YCXGWTNNKQ.hasRemaining()) {
                            // src expired first
                            EXCTQWEIAP.reset();
                            YCXGWTNNKQ.reset();
                            HGBXJNZTZG = false;
                            break;
                        }
                        if (!(EXCTQWEIAP.get() == YCXGWTNNKQ.get())) {
                            EXCTQWEIAP.reset();
                            YCXGWTNNKQ.reset();
                            HGBXJNZTZG = false;
                            break;// no match

                        }
                    } 
                    if (HGBXJNZTZG)
                        return JXEKDPMQYR;

                }
            } 
            return -1;// not found

        } catch (CharacterCodingException e) {
            // can't get here
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * Set to contain the contents of a string.
     */
    public void set(String ASVMRYSFQP) {
        try {
            ByteBuffer JYNEBHWDYB = Text.encode(ASVMRYSFQP, true);
            NLYRAKKFQU = JYNEBHWDYB.array();
            UJDMIEJBLJ = JYNEBHWDYB.limit();
        } catch (CharacterCodingException e) {
            throw new RuntimeException("Should not have happened ", e);
        }
    }

    /**
     * Set to a utf8 byte array
     */
    public void set(byte[] VOQCCLUZSI) {
        set(VOQCCLUZSI, 0, VOQCCLUZSI.length);
    }

    /**
     * copy a text.
     */
    public void set(Text FKOPZRVZDX) {
        set(FKOPZRVZDX.getBytes(), 0, FKOPZRVZDX.getLength());
    }

    /**
     * Set the Text to range of bytes
     *
     * @param utf8
     * 		the data to copy from
     * @param start
     * 		the first position of the new string
     * @param len
     * 		the number of bytes of the new string
     */
    public void set(byte[] GGGJWOEHCX, int BKIDDSWZEF, int YNOWIORUXW) {
        setCapacity(YNOWIORUXW, false);
        System.arraycopy(GGGJWOEHCX, BKIDDSWZEF, NLYRAKKFQU, 0, YNOWIORUXW);
        this.UJDMIEJBLJ = YNOWIORUXW;
    }

    /**
     * Append a range of bytes to the end of the given text
     *
     * @param utf8
     * 		the data to copy from
     * @param start
     * 		the first position to append from utf8
     * @param len
     * 		the number of bytes to append
     */
    public void append(byte[] PWUFIIQXIW, int TGQJZFITCA, int NVOADJUUHW) {
        setCapacity(UJDMIEJBLJ + NVOADJUUHW, true);
        System.arraycopy(PWUFIIQXIW, TGQJZFITCA, NLYRAKKFQU, UJDMIEJBLJ, NVOADJUUHW);
        UJDMIEJBLJ += NVOADJUUHW;
    }

    /**
     * Clear the string to empty.
     *
     * <em>Note</em>: For performance reasons, this call does not clear the
     * underlying byte array that is retrievable via {@link #getBytes()}.
     * In order to free the byte-array memory, call {@link #set(byte[])}
     * with an empty byte array (For example, <code>new byte[0]</code>).
     */
    public void clear() {
        UJDMIEJBLJ = 0;
    }

    /* Sets the capacity of this Text object to <em>at least</em>
    <code>len</code> bytes. If the current buffer is longer,
    then the capacity and existing content of the buffer are
    unchanged. If <code>len</code> is larger
    than the current capacity, the Text object's capacity is
    increased to match.
    @param len the number of bytes we need
    @param keepData should the old data be kept
     */
    private void setCapacity(int VWNTHGTIYD, boolean MMRBCNYRFD) {
        if ((NLYRAKKFQU == null) || (NLYRAKKFQU.length < VWNTHGTIYD)) {
            if ((NLYRAKKFQU != null) && MMRBCNYRFD) {
                NLYRAKKFQU = Arrays.copyOf(NLYRAKKFQU, Math.max(VWNTHGTIYD, UJDMIEJBLJ << 1));
            } else {
                NLYRAKKFQU = new byte[VWNTHGTIYD];
            }
        }
    }

    /**
     * Convert text back to string
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        try {
            return Text.decode(NLYRAKKFQU, 0, UJDMIEJBLJ);
        } catch (CharacterCodingException e) {
            throw new RuntimeException("Should not have happened ", e);
        }
    }

    /**
     * deserialize
     */
    @Override
    public void readFields(DataInput XEQQNMSIPO) throws IOException {
        int TFXMYAQTYF = WritableUtils.readVInt(XEQQNMSIPO);
        readWithKnownLength(XEQQNMSIPO, TFXMYAQTYF);
    }

    public void readFields(DataInput YJUZBAZFQC, int KPPQBUPNLX) throws IOException {
        int SKVPGMCXSA = WritableUtils.readVInt(YJUZBAZFQC);
        if (SKVPGMCXSA < 0) {
            throw new IOException(("tried to deserialize " + SKVPGMCXSA) + " bytes of data!  newLength must be non-negative.");
        } else
            if (SKVPGMCXSA >= KPPQBUPNLX) {
                throw new IOException((("tried to deserialize " + SKVPGMCXSA) + " bytes of data, but maxLength = ") + KPPQBUPNLX);
            }

        readWithKnownLength(YJUZBAZFQC, SKVPGMCXSA);
    }

    /**
     * Skips over one Text in the input.
     */
    public static void skip(DataInput RYXVJGSXKY) throws IOException {
        int ESFXYVWEWZ = WritableUtils.readVInt(RYXVJGSXKY);
        WritableUtils.skipFully(RYXVJGSXKY, ESFXYVWEWZ);
    }

    /**
     * Read a Text object whose length is already known.
     * This allows creating Text from a stream which uses a different serialization
     * format.
     */
    public void readWithKnownLength(DataInput SPKQHEWMIJ, int SKMFXDPUOT) throws IOException {
        setCapacity(SKMFXDPUOT, false);
        SPKQHEWMIJ.readFully(NLYRAKKFQU, 0, SKMFXDPUOT);
        UJDMIEJBLJ = SKMFXDPUOT;
    }

    /**
     * serialize
     * write this object to out
     * length uses zero-compressed encoding
     *
     * @see Writable#write(DataOutput)
     */
    @Override
    public void write(DataOutput KFBZWIVGLF) throws IOException {
        WritableUtils.writeVInt(KFBZWIVGLF, UJDMIEJBLJ);
        KFBZWIVGLF.write(NLYRAKKFQU, 0, UJDMIEJBLJ);
    }

    public void write(DataOutput JEDIOOWYKK, int JPLGIPBWGB) throws IOException {
        if (UJDMIEJBLJ > JPLGIPBWGB) {
            throw new IOException((((("data was too long to write!  Expected " + "less than or equal to ") + JPLGIPBWGB) + " bytes, but got ") + UJDMIEJBLJ) + " bytes.");
        }
        WritableUtils.writeVInt(JEDIOOWYKK, UJDMIEJBLJ);
        JEDIOOWYKK.write(NLYRAKKFQU, 0, UJDMIEJBLJ);
    }

    /**
     * Returns true iff <code>o</code> is a Text with the same contents.
     */
    @Override
    public boolean equals(Object BLLOGCPCXH) {
        if (BLLOGCPCXH instanceof Text)
            return super.equals(BLLOGCPCXH);

        return false;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    /**
     * A WritableComparator optimized for Text keys.
     */
    public static class Comparator extends WritableComparator {
        public Comparator() {
            super(Text.class);
        }

        @Override
        public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
            int n1 = WritableUtils.decodeVIntSize(b1[s1]);
            int n2 = WritableUtils.decodeVIntSize(b2[s2]);
            return compareBytes(b1, s1 + n1, l1 - n1, b2, s2 + n2, l2 - n2);
        }
    }

    static {
        // register this comparator
        WritableComparator.define(Text.class, new Text.Comparator());
    }

    // / STATIC UTILITIES FROM HERE DOWN
    /**
     * Converts the provided byte array to a String using the
     * UTF-8 encoding. If the input is malformed,
     * replace by a default value.
     */
    public static String decode(byte[] NIGCRHWRZX) throws CharacterCodingException {
        return Text.decode(ByteBuffer.wrap(NIGCRHWRZX), true);
    }

    public static String decode(byte[] RYBXSPFSWZ, int LEKCSXIMBV, int IJHWWGUAFS) throws CharacterCodingException {
        return Text.decode(ByteBuffer.wrap(RYBXSPFSWZ, LEKCSXIMBV, IJHWWGUAFS), true);
    }

    /**
     * Converts the provided byte array to a String using the
     * UTF-8 encoding. If <code>replace</code> is true, then
     * malformed input is replaced with the
     * substitution character, which is U+FFFD. Otherwise the
     * method throws a MalformedInputException.
     */
    public static String decode(byte[] XDUMQTBJGS, int JWFNVZSWVA, int JSVRJHOUDT, boolean IXQSJZJYXF) throws CharacterCodingException {
        return Text.decode(ByteBuffer.wrap(XDUMQTBJGS, JWFNVZSWVA, JSVRJHOUDT), IXQSJZJYXF);
    }

    private static String decode(ByteBuffer TQTEBJOCOU, boolean CEQTAJQFNB) throws CharacterCodingException {
        CharsetDecoder FHTLGNMNRB = Text.IFXPRQHYBD.get();
        if (CEQTAJQFNB) {
            FHTLGNMNRB.onMalformedInput(CodingErrorAction.REPLACE);
            FHTLGNMNRB.onUnmappableCharacter(CodingErrorAction.REPLACE);
        }
        String UWSEUSIFBY = FHTLGNMNRB.decode(TQTEBJOCOU).toString();
        // set decoder back to its default value: REPORT
        if (CEQTAJQFNB) {
            FHTLGNMNRB.onMalformedInput(CodingErrorAction.REPORT);
            FHTLGNMNRB.onUnmappableCharacter(CodingErrorAction.REPORT);
        }
        return UWSEUSIFBY;
    }

    /**
     * Converts the provided String to bytes using the
     * UTF-8 encoding. If the input is malformed,
     * invalid chars are replaced by a default value.
     *
     * @return ByteBuffer: bytes stores at ByteBuffer.array()
    and length is ByteBuffer.limit()
     */
    public static ByteBuffer encode(String SMZGPIPVEB) throws CharacterCodingException {
        return Text.encode(SMZGPIPVEB, true);
    }

    /**
     * Converts the provided String to bytes using the
     * UTF-8 encoding. If <code>replace</code> is true, then
     * malformed input is replaced with the
     * substitution character, which is U+FFFD. Otherwise the
     * method throws a MalformedInputException.
     *
     * @return ByteBuffer: bytes stores at ByteBuffer.array()
    and length is ByteBuffer.limit()
     */
    public static ByteBuffer encode(String HZDDXDDDYA, boolean MKZMJKUHPQ) throws CharacterCodingException {
        CharsetEncoder SOGOGBJPNR = Text.OUWGXJCTAL.get();
        if (MKZMJKUHPQ) {
            SOGOGBJPNR.onMalformedInput(CodingErrorAction.REPLACE);
            SOGOGBJPNR.onUnmappableCharacter(CodingErrorAction.REPLACE);
        }
        ByteBuffer ACTGATTCJC = SOGOGBJPNR.encode(CharBuffer.wrap(HZDDXDDDYA.toCharArray()));
        if (MKZMJKUHPQ) {
            SOGOGBJPNR.onMalformedInput(CodingErrorAction.REPORT);
            SOGOGBJPNR.onUnmappableCharacter(CodingErrorAction.REPORT);
        }
        return ACTGATTCJC;
    }

    public static final int ZWBSSVGOLG = 1024 * 1024;

    /**
     * Read a UTF8 encoded string from in
     */
    public static String readString(DataInput OMQAKTBYBY) throws IOException {
        return Text.readString(OMQAKTBYBY, Integer.MAX_VALUE);
    }

    /**
     * Read a UTF8 encoded string with a maximum size
     */
    public static String readString(DataInput EEALJECBEJ, int IWACFVPGPZ) throws IOException {
        int NGEGVTXRCK = WritableUtils.readVIntInRange(EEALJECBEJ, 0, IWACFVPGPZ);
        byte[] BQGVOYMKMJ = new byte[NGEGVTXRCK];
        EEALJECBEJ.readFully(BQGVOYMKMJ, 0, NGEGVTXRCK);
        return Text.decode(BQGVOYMKMJ);
    }

    /**
     * Write a UTF8 encoded string to out
     */
    public static int writeString(DataOutput ZQAHMMSUAT, String IEGAKUDMLA) throws IOException {
        ByteBuffer HOPPULTEVX = Text.encode(IEGAKUDMLA);
        int NPULUTJTQQ = HOPPULTEVX.limit();
        WritableUtils.writeVInt(ZQAHMMSUAT, NPULUTJTQQ);
        ZQAHMMSUAT.write(HOPPULTEVX.array(), 0, NPULUTJTQQ);
        return NPULUTJTQQ;
    }

    /**
     * Write a UTF8 encoded string with a maximum size to out
     */
    public static int writeString(DataOutput RLUJKLIHAV, String GBXNXLNOUT, int BVFREUHPKJ) throws IOException {
        ByteBuffer DZTQCNYOKI = Text.encode(GBXNXLNOUT);
        int RNNXDHAVLY = DZTQCNYOKI.limit();
        if (RNNXDHAVLY > BVFREUHPKJ) {
            throw new IOException((((("string was too long to write!  Expected " + "less than or equal to ") + BVFREUHPKJ) + " bytes, but got ") + RNNXDHAVLY) + " bytes.");
        }
        WritableUtils.writeVInt(RLUJKLIHAV, RNNXDHAVLY);
        RLUJKLIHAV.write(DZTQCNYOKI.array(), 0, RNNXDHAVLY);
        return RNNXDHAVLY;
    }

    // //// states for validateUTF8
    private static final int LCIAJNEUFL = 0;

    private static final int WCHNSKOVUH = 1;

    private static final int NNEYFPFUQC = 2;

    /**
     * Check if a byte array contains valid utf-8
     *
     * @param utf8
     * 		byte array
     * @throws MalformedInputException
     * 		if the byte array contains invalid utf-8
     */
    public static void validateUTF8(byte[] DXEFBRMSSQ) throws MalformedInputException {
        Text.validateUTF8(DXEFBRMSSQ, 0, DXEFBRMSSQ.length);
    }

    /**
     * Check to see if a byte array is valid utf-8
     *
     * @param utf8
     * 		the array of bytes
     * @param start
     * 		the offset of the first byte in the array
     * @param len
     * 		the length of the byte sequence
     * @throws MalformedInputException
     * 		if the byte array contains invalid bytes
     */
    public static void validateUTF8(byte[] ZEFGTHHLKF, int GHAFJQXUGY, int IEMGJIXJLH) throws MalformedInputException {
        int MNYYDGQOQS = GHAFJQXUGY;
        int YTQCTJTMAV = 0;
        int BVECOMFUXH = 0;
        int HSGDTPHVZO = Text.LCIAJNEUFL;
        while (MNYYDGQOQS < (GHAFJQXUGY + IEMGJIXJLH)) {
            int VDDVPTADDH = ZEFGTHHLKF[MNYYDGQOQS] & 0xff;
            switch (HSGDTPHVZO) {
                case Text.LCIAJNEUFL :
                    YTQCTJTMAV = VDDVPTADDH;
                    BVECOMFUXH = Text.LAOUMGHDES[VDDVPTADDH];
                    switch (BVECOMFUXH) {
                        case 0 :
                            // check for ASCII
                            if (YTQCTJTMAV > 0x7f)
                                throw new MalformedInputException(MNYYDGQOQS);

                            break;
                        case 1 :
                            if ((YTQCTJTMAV < 0xc2) || (YTQCTJTMAV > 0xdf))
                                throw new MalformedInputException(MNYYDGQOQS);

                            HSGDTPHVZO = Text.WCHNSKOVUH;
                            break;
                        case 2 :
                            if ((YTQCTJTMAV < 0xe0) || (YTQCTJTMAV > 0xef))
                                throw new MalformedInputException(MNYYDGQOQS);

                            HSGDTPHVZO = Text.WCHNSKOVUH;
                            break;
                        case 3 :
                            if ((YTQCTJTMAV < 0xf0) || (YTQCTJTMAV > 0xf4))
                                throw new MalformedInputException(MNYYDGQOQS);

                            HSGDTPHVZO = Text.WCHNSKOVUH;
                            break;
                        default :
                            // too long! Longest valid UTF-8 is 4 bytes (lead + three)
                            // or if < 0 we got a trail byte in the lead byte position
                            throw new MalformedInputException(MNYYDGQOQS);
                    }// switch (length)

                    break;
                case Text.WCHNSKOVUH :
                    if ((YTQCTJTMAV == 0xf0) && (VDDVPTADDH < 0x90))
                        throw new MalformedInputException(MNYYDGQOQS);

                    if ((YTQCTJTMAV == 0xf4) && (VDDVPTADDH > 0x8f))
                        throw new MalformedInputException(MNYYDGQOQS);

                    if ((YTQCTJTMAV == 0xe0) && (VDDVPTADDH < 0xa0))
                        throw new MalformedInputException(MNYYDGQOQS);

                    if ((YTQCTJTMAV == 0xed) && (VDDVPTADDH > 0x9f))
                        throw new MalformedInputException(MNYYDGQOQS);

                    // falls through to regular trail-byte test!!
                case Text.NNEYFPFUQC :
                    if ((VDDVPTADDH < 0x80) || (VDDVPTADDH > 0xbf))
                        throw new MalformedInputException(MNYYDGQOQS);

                    if ((--BVECOMFUXH) == 0) {
                        HSGDTPHVZO = Text.LCIAJNEUFL;
                    } else {
                        HSGDTPHVZO = Text.NNEYFPFUQC;
                    }
                    break;
            }// switch (state)

            MNYYDGQOQS++;
        } 
    }

    /**
     * Magic numbers for UTF-8. These are the number of bytes
     * that <em>follow</em> a given lead byte. Trailing bytes
     * have the value -1. The values 4 and 5 are presented in
     * this table, even though valid UTF-8 cannot include the
     * five and six byte sequences.
     */
    static final int[] LAOUMGHDES = new int[]{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // trail bytes
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5 };

    /**
     * Returns the next code point at the current position in
     * the buffer. The buffer's position will be incremented.
     * Any mark set on this buffer will be changed by this method!
     */
    public static int bytesToCodePoint(ByteBuffer XFFNNKDFPQ) {
        XFFNNKDFPQ.mark();
        byte MXGREYYUKC = XFFNNKDFPQ.get();
        XFFNNKDFPQ.reset();
        int RJPZDUXUOO = Text.LAOUMGHDES[MXGREYYUKC & 0xff];
        if (RJPZDUXUOO < 0)
            return -1;
        // trailing byte!

        int MWPJRUVSQN = 0;
        switch (RJPZDUXUOO) {
            case 5 :
                MWPJRUVSQN += XFFNNKDFPQ.get() & 0xff;
                MWPJRUVSQN <<= 6;/* remember, illegal UTF-8 */

            case 4 :
                MWPJRUVSQN += XFFNNKDFPQ.get() & 0xff;
                MWPJRUVSQN <<= 6;/* remember, illegal UTF-8 */

            case 3 :
                MWPJRUVSQN += XFFNNKDFPQ.get() & 0xff;
                MWPJRUVSQN <<= 6;
            case 2 :
                MWPJRUVSQN += XFFNNKDFPQ.get() & 0xff;
                MWPJRUVSQN <<= 6;
            case 1 :
                MWPJRUVSQN += XFFNNKDFPQ.get() & 0xff;
                MWPJRUVSQN <<= 6;
            case 0 :
                MWPJRUVSQN += XFFNNKDFPQ.get() & 0xff;
        }
        MWPJRUVSQN -= Text.ZLVIELZVQN[RJPZDUXUOO];
        return MWPJRUVSQN;
    }

    static final int[] ZLVIELZVQN = new int[]{ 0x0, 0x3080, 0xe2080, 0x3c82080, 0xfa082080, 0x82082080 };

    /**
     * For the given string, returns the number of UTF-8 bytes
     * required to encode the string.
     *
     * @param string
     * 		text to encode
     * @return number of UTF-8 bytes required to encode
     */
    public static int utf8Length(String UJDMDPGGHT) {
        CharacterIterator CQIZCCBIFD = new StringCharacterIterator(UJDMDPGGHT);
        char PESEDLXQSZ = CQIZCCBIFD.first();
        int REEORIAHLI = 0;
        while (PESEDLXQSZ != CharacterIterator.DONE) {
            if ((PESEDLXQSZ >= 0xd800) && (PESEDLXQSZ < 0xdc00)) {
                // surrogate pair?
                char VOMAIYREOK = CQIZCCBIFD.next();
                if ((VOMAIYREOK > 0xdbff) && (VOMAIYREOK < 0xe000)) {
                    // valid pair
                    REEORIAHLI += 4;
                } else {
                    // invalid pair
                    REEORIAHLI += 3;
                    CQIZCCBIFD.previous();// rewind one

                }
            } else
                if (PESEDLXQSZ < 0x80) {
                    REEORIAHLI++;
                } else
                    if (PESEDLXQSZ < 0x800) {
                        REEORIAHLI += 2;
                    } else {
                        // ch < 0x10000, that is, the largest char value
                        REEORIAHLI += 3;
                    }


            PESEDLXQSZ = CQIZCCBIFD.next();
        } 
        return REEORIAHLI;
    }
}