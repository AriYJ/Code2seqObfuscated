/**
 * Node usage report.
 */
@Private
@Stable
public class NodeReport {
    private final Resource JQSSLZNOXS;

    private final int ZLEEBMUOGW;

    public NodeReport(Resource KEIFRBDRCY, int KKJMHVRWFO) {
        this.JQSSLZNOXS = KEIFRBDRCY;
        this.ZLEEBMUOGW = KKJMHVRWFO;
    }

    public Resource getUsedResources() {
        return JQSSLZNOXS;
    }

    public int getNumContainers() {
        return ZLEEBMUOGW;
    }
}