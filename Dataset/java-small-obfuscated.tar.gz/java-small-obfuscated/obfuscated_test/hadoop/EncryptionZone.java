/**
 * A simple class for representing an encryption zone. Presently an encryption
 * zone only has a path (the root of the encryption zone) and a key name.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class EncryptionZone {
    private final String ZAHSADHHZO;

    private final String OPHLWJALSZ;

    public EncryptionZone(String JGBNBGMIDK, String MQOVIIRUFJ) {
        this.ZAHSADHHZO = JGBNBGMIDK;
        this.OPHLWJALSZ = MQOVIIRUFJ;
    }

    public String getPath() {
        return ZAHSADHHZO;
    }

    public String getKeyName() {
        return OPHLWJALSZ;
    }

    @Override
    public int hashCode() {
        return new org.apache.commons.lang.builder.HashCodeBuilder(13, 31).append(ZAHSADHHZO).append(OPHLWJALSZ).toHashCode();
    }

    @Override
    public boolean equals(Object VAWZHCEXBO) {
        if (VAWZHCEXBO == null) {
            return false;
        }
        if (VAWZHCEXBO == this) {
            return true;
        }
        if (VAWZHCEXBO.getClass() != getClass()) {
            return false;
        }
        EncryptionZone GWWKRQRMNR = ((EncryptionZone) (VAWZHCEXBO));
        return new org.apache.commons.lang.builder.EqualsBuilder().append(ZAHSADHHZO, GWWKRQRMNR.ZAHSADHHZO).append(OPHLWJALSZ, GWWKRQRMNR.OPHLWJALSZ).isEquals();
    }

    @Override
    public String toString() {
        return ((("EncryptionZone [path=" + ZAHSADHHZO) + ", keyName=") + OPHLWJALSZ) + "]";
    }
}