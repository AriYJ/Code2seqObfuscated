public class TestWritableJobConf extends TestCase {
    private static final Configuration SHQISCFAZA = new Configuration();

    private <K> K serDeser(K DMIKDEZQCX) throws Exception {
        SerializationFactory JRWIJMSCKD = new SerializationFactory(TestWritableJobConf.SHQISCFAZA);
        Serializer<K> QOCUFQFPFC = JRWIJMSCKD.getSerializer(GenericsUtil.getClass(DMIKDEZQCX));
        Deserializer<K> VUUNOBABKQ = JRWIJMSCKD.getDeserializer(GenericsUtil.getClass(DMIKDEZQCX));
        DataOutputBuffer IPBSATYZVT = new DataOutputBuffer();
        QOCUFQFPFC.open(IPBSATYZVT);
        QOCUFQFPFC.serialize(DMIKDEZQCX);
        QOCUFQFPFC.close();
        DataInputBuffer DFKCNXRQGI = new DataInputBuffer();
        DFKCNXRQGI.reset(IPBSATYZVT.getData(), IPBSATYZVT.getLength());
        VUUNOBABKQ.open(DFKCNXRQGI);
        K EKXQKHOPMJ = VUUNOBABKQ.deserialize(null);
        VUUNOBABKQ.close();
        return EKXQKHOPMJ;
    }

    private void assertEquals(Configuration SSKMAVKBHE, Configuration KMFHDTYENL) {
        // We ignore deprecated keys because after deserializing, both the
        // deprecated and the non-deprecated versions of a config are set.
        // This is consistent with both the set and the get methods.
        Iterator<Map.Entry<String, String>> ZPQOMDQQKC = SSKMAVKBHE.iterator();
        Map<String, String> WLMKNKFIDR = new HashMap<String, String>();
        while (ZPQOMDQQKC.hasNext()) {
            Map.Entry<String, String> COTDWEBPWD = ZPQOMDQQKC.next();
            if (!Configuration.isDeprecated(COTDWEBPWD.getKey())) {
                WLMKNKFIDR.put(COTDWEBPWD.getKey(), COTDWEBPWD.getValue());
            }
        } 
        Iterator<Map.Entry<String, String>> KEQYUCAEAE = KMFHDTYENL.iterator();
        Map<String, String> VEPXIWWLQQ = new HashMap<String, String>();
        while (KEQYUCAEAE.hasNext()) {
            Map.Entry<String, String> KXDGFPIVBY = KEQYUCAEAE.next();
            if (!Configuration.isDeprecated(KXDGFPIVBY.getKey())) {
                VEPXIWWLQQ.put(KXDGFPIVBY.getKey(), KXDGFPIVBY.getValue());
            }
        } 
        assertEquals(WLMKNKFIDR, VEPXIWWLQQ);
    }

    public void testEmptyConfiguration() throws Exception {
        JobConf EJWPXHXYXW = new JobConf();
        Configuration UQVBFJBWWI = serDeser(EJWPXHXYXW);
        assertEquals(EJWPXHXYXW, UQVBFJBWWI);
    }

    public void testNonEmptyConfiguration() throws Exception {
        JobConf DLHSTBXVBD = new JobConf();
        DLHSTBXVBD.set("a", "A");
        DLHSTBXVBD.set("b", "B");
        Configuration WYCOQTDXYA = serDeser(DLHSTBXVBD);
        assertEquals(DLHSTBXVBD, WYCOQTDXYA);
    }

    public void testConfigurationWithDefaults() throws Exception {
        JobConf JDOXZJLCRU = new JobConf(false);
        JDOXZJLCRU.set("a", "A");
        JDOXZJLCRU.set("b", "B");
        Configuration MJYHFHAADW = serDeser(JDOXZJLCRU);
        assertEquals(JDOXZJLCRU, MJYHFHAADW);
    }
}