public class TestRMRestart {
    private static final File BRZHGXZEJD = new File(System.getProperty("test.build.data", "/tmp"), "decommision");

    private File PXXVTEATFT = new File((TestRMRestart.BRZHGXZEJD + File.separator) + "hostFile.txt");

    private YarnConfiguration NGGDLBOOKG;

    // Fake rmAddr for token-renewal
    private static InetSocketAddress JYDWNVRJVO;

    @Before
    public void setup() throws UnknownHostException {
        Logger LCXDCKTZBJ = LogManager.getRootLogger();
        LCXDCKTZBJ.setLevel(Level.DEBUG);
        NGGDLBOOKG = new YarnConfiguration();
        UserGroupInformation.setConfiguration(NGGDLBOOKG);
        NGGDLBOOKG.set(RECOVERY_ENABLED, "true");
        NGGDLBOOKG.set(RM_STORE, MemoryRMStateStore.class.getName());
        TestRMRestart.JYDWNVRJVO = new InetSocketAddress("localhost", 8032);
        Assert.assertTrue(YarnConfiguration.DEFAULT_RM_AM_MAX_ATTEMPTS > 1);
    }

    @After
    public void tearDown() {
        TestRMRestart.BRZHGXZEJD.delete();
    }

    @SuppressWarnings("rawtypes")
    @Test(timeout = 180000)
    public void testRMRestart() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, DEFAULT_RM_AM_MAX_ATTEMPTS);
        MemoryRMStateStore SBBBDFLTGQ = new MemoryRMStateStore();
        SBBBDFLTGQ.init(NGGDLBOOKG);
        RMState IFXHWKDURS = SBBBDFLTGQ.getState();
        Map<ApplicationId, ApplicationState> AMISTHSSOP = IFXHWKDURS.getApplicationState();
        // PHASE 1: create state in an RM
        // start RM
        MockRM NQYLQUXNAR = new MockRM(NGGDLBOOKG, SBBBDFLTGQ);
        // start like normal because state is empty
        NQYLQUXNAR.start();
        MockNM CONGOELUAS = new MockNM("127.0.0.1:1234", 15120, NQYLQUXNAR.getResourceTrackerService());
        MockNM TTQQHUTUEM = new MockNM("127.0.0.2:5678", 15120, NQYLQUXNAR.getResourceTrackerService());
        CONGOELUAS.registerNode();
        TTQQHUTUEM.registerNode();// nm2 will not heartbeat with RM1

        // create app that will finish and the final state should be saved.
        RMApp JVHCGCQJGK = NQYLQUXNAR.submitApp(200);
        RMAppAttempt HQHUZZEGRW = JVHCGCQJGK.getCurrentAppAttempt();
        // spot check that app is saved
        Assert.assertEquals(1, AMISTHSSOP.size());
        CONGOELUAS.nodeHeartbeat(true);
        MockAM WGUQZJRAMY = NQYLQUXNAR.sendAMLaunched(HQHUZZEGRW.getAppAttemptId());
        WGUQZJRAMY.registerAppAttempt();
        finishApplicationMaster(JVHCGCQJGK, NQYLQUXNAR, CONGOELUAS, WGUQZJRAMY);
        // create app that gets launched and does allocate before RM restart
        RMApp UHVZWAWNSJ = NQYLQUXNAR.submitApp(200);
        // assert app1 info is saved
        ApplicationState FTQQTQEWCO = AMISTHSSOP.get(UHVZWAWNSJ.getApplicationId());
        Assert.assertNotNull(FTQQTQEWCO);
        Assert.assertEquals(0, FTQQTQEWCO.getAttemptCount());
        Assert.assertEquals(FTQQTQEWCO.getApplicationSubmissionContext().getApplicationId(), UHVZWAWNSJ.getApplicationSubmissionContext().getApplicationId());
        // kick the scheduling to allocate AM container
        CONGOELUAS.nodeHeartbeat(true);
        // assert app1 attempt is saved
        RMAppAttempt TTBVHJBSHN = UHVZWAWNSJ.getCurrentAppAttempt();
        ApplicationAttemptId PHQGGUJJXM = TTBVHJBSHN.getAppAttemptId();
        NQYLQUXNAR.waitForState(PHQGGUJJXM, ALLOCATED);
        Assert.assertEquals(1, FTQQTQEWCO.getAttemptCount());
        ApplicationAttemptState CTJAENBONV = FTQQTQEWCO.getAttempt(PHQGGUJJXM);
        Assert.assertNotNull(CTJAENBONV);
        Assert.assertEquals(BuilderUtils.newContainerId(PHQGGUJJXM, 1), CTJAENBONV.getMasterContainer().getId());
        // launch the AM
        MockAM CUWYNLBMQP = NQYLQUXNAR.sendAMLaunched(TTBVHJBSHN.getAppAttemptId());
        CUWYNLBMQP.registerAppAttempt();
        // AM request for containers
        CUWYNLBMQP.allocate("127.0.0.1", 1000, 1, new ArrayList<ContainerId>());
        // kick the scheduler
        CONGOELUAS.nodeHeartbeat(true);
        List<Container> EPJFDCOLET = CUWYNLBMQP.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers();
        while (EPJFDCOLET.size() == 0) {
            CONGOELUAS.nodeHeartbeat(true);
            EPJFDCOLET.addAll(CUWYNLBMQP.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers());
            Thread.sleep(500);
        } 
        // create app that does not get launched by RM before RM restart
        RMApp LNYEOWIVCI = NQYLQUXNAR.submitApp(200);
        // assert app2 info is saved
        FTQQTQEWCO = AMISTHSSOP.get(LNYEOWIVCI.getApplicationId());
        Assert.assertNotNull(FTQQTQEWCO);
        Assert.assertEquals(0, FTQQTQEWCO.getAttemptCount());
        Assert.assertEquals(FTQQTQEWCO.getApplicationSubmissionContext().getApplicationId(), LNYEOWIVCI.getApplicationSubmissionContext().getApplicationId());
        // create unmanaged app
        RMApp CMLQMZWZYI = NQYLQUXNAR.submitApp(200, "someApp", "someUser", null, true, null, NGGDLBOOKG.getInt(RM_AM_MAX_ATTEMPTS, DEFAULT_RM_AM_MAX_ATTEMPTS), null);
        ApplicationAttemptId ADHSJEFNUW = CMLQMZWZYI.getCurrentAppAttempt().getAppAttemptId();
        // assert appUnmanaged info is saved
        ApplicationId GKNHSKALOT = CMLQMZWZYI.getApplicationId();
        FTQQTQEWCO = AMISTHSSOP.get(GKNHSKALOT);
        Assert.assertNotNull(FTQQTQEWCO);
        // wait for attempt to reach LAUNCHED state
        NQYLQUXNAR.waitForState(ADHSJEFNUW, LAUNCHED);
        NQYLQUXNAR.waitForState(GKNHSKALOT, ACCEPTED);
        // assert unmanaged attempt info is saved
        Assert.assertEquals(1, FTQQTQEWCO.getAttemptCount());
        Assert.assertEquals(FTQQTQEWCO.getApplicationSubmissionContext().getApplicationId(), CMLQMZWZYI.getApplicationSubmissionContext().getApplicationId());
        // PHASE 2: create new RM and start from old state
        // create new RM to represent restart and recover state
        MockRM QYRTPMMNUZ = new MockRM(NGGDLBOOKG, SBBBDFLTGQ);
        // start new RM
        QYRTPMMNUZ.start();
        // change NM to point to new RM
        CONGOELUAS.setResourceTrackerService(QYRTPMMNUZ.getResourceTrackerService());
        TTQQHUTUEM.setResourceTrackerService(QYRTPMMNUZ.getResourceTrackerService());
        // verify load of old state
        // 4 apps are loaded.
        // FINISHED app and attempt is also loaded back.
        // Unmanaged app state is still loaded back but it cannot be restarted by
        // the RM. this will change with work preserving RM restart in which AMs/NMs
        // are not rebooted.
        Assert.assertEquals(4, QYRTPMMNUZ.getRMContext().getRMApps().size());
        // check that earlier finished app and attempt is also loaded back and move
        // to finished state.
        QYRTPMMNUZ.waitForState(JVHCGCQJGK.getApplicationId(), FINISHED);
        QYRTPMMNUZ.waitForState(WGUQZJRAMY.getApplicationAttemptId(), RMAppAttemptState.FINISHED);
        // verify correct number of attempts and other data
        RMApp BSCOKNJSJW = QYRTPMMNUZ.getRMContext().getRMApps().get(UHVZWAWNSJ.getApplicationId());
        Assert.assertNotNull(BSCOKNJSJW);
        Assert.assertEquals(1, BSCOKNJSJW.getAppAttempts().size());
        Assert.assertEquals(UHVZWAWNSJ.getApplicationSubmissionContext().getApplicationId(), BSCOKNJSJW.getApplicationSubmissionContext().getApplicationId());
        RMApp WPOHTTBZNL = QYRTPMMNUZ.getRMContext().getRMApps().get(LNYEOWIVCI.getApplicationId());
        Assert.assertNotNull(WPOHTTBZNL);
        // Assert.assertEquals(0, loadedApp2.getAppAttempts().size());
        Assert.assertEquals(LNYEOWIVCI.getApplicationSubmissionContext().getApplicationId(), WPOHTTBZNL.getApplicationSubmissionContext().getApplicationId());
        // verify state machine kicked into expected states
        QYRTPMMNUZ.waitForState(BSCOKNJSJW.getApplicationId(), ACCEPTED);
        QYRTPMMNUZ.waitForState(WPOHTTBZNL.getApplicationId(), ACCEPTED);
        // verify attempts for apps
        // The app for which AM was started will wait for previous am
        // container finish event to arrive. However for an application for which
        // no am container was running will start new application attempt.
        Assert.assertEquals(1, BSCOKNJSJW.getAppAttempts().size());
        Assert.assertEquals(1, WPOHTTBZNL.getAppAttempts().size());
        // verify old AM is not accepted
        // change running AM to talk to new RM
        CUWYNLBMQP.setAMRMProtocol(QYRTPMMNUZ.getApplicationMasterService(), QYRTPMMNUZ.getRMContext());
        AllocateResponse LFLEAPCISS = CUWYNLBMQP.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>());
        Assert.assertEquals(AM_SHUTDOWN, LFLEAPCISS.getAMCommand());
        // NM should be rebooted on heartbeat, even first heartbeat for nm2
        NodeHeartbeatResponse MQZSWBEFNI = CONGOELUAS.nodeHeartbeat(true);
        Assert.assertEquals(RESYNC, MQZSWBEFNI.getNodeAction());
        MQZSWBEFNI = TTQQHUTUEM.nodeHeartbeat(true);
        Assert.assertEquals(RESYNC, MQZSWBEFNI.getNodeAction());
        // new NM to represent NM re-register
        CONGOELUAS = new MockNM("127.0.0.1:1234", 15120, QYRTPMMNUZ.getResourceTrackerService());
        TTQQHUTUEM = new MockNM("127.0.0.2:5678", 15120, QYRTPMMNUZ.getResourceTrackerService());
        NMContainerStatus DXIWRRAVRG = TestRMRestart.createNMContainerStatus(BSCOKNJSJW.getCurrentAppAttempt().getAppAttemptId(), 1, COMPLETE);
        CONGOELUAS.registerNode(Arrays.asList(DXIWRRAVRG), null);
        TTQQHUTUEM.registerNode();
        QYRTPMMNUZ.waitForState(BSCOKNJSJW.getApplicationId(), ACCEPTED);
        // wait for the 2nd attempt to be started.
        int WEWPSBOYKY = 0;
        while ((BSCOKNJSJW.getAppAttempts().size() != 2) && ((WEWPSBOYKY++) < 40)) {
            Thread.sleep(200);
        } 
        // verify no more reboot response sent
        MQZSWBEFNI = CONGOELUAS.nodeHeartbeat(true);
        Assert.assertTrue(NodeAction.RESYNC != MQZSWBEFNI.getNodeAction());
        MQZSWBEFNI = TTQQHUTUEM.nodeHeartbeat(true);
        Assert.assertTrue(NodeAction.RESYNC != MQZSWBEFNI.getNodeAction());
        // assert app1 attempt is saved
        TTBVHJBSHN = BSCOKNJSJW.getCurrentAppAttempt();
        PHQGGUJJXM = TTBVHJBSHN.getAppAttemptId();
        QYRTPMMNUZ.waitForState(PHQGGUJJXM, ALLOCATED);
        FTQQTQEWCO = AMISTHSSOP.get(BSCOKNJSJW.getApplicationId());
        CTJAENBONV = FTQQTQEWCO.getAttempt(PHQGGUJJXM);
        Assert.assertNotNull(CTJAENBONV);
        Assert.assertEquals(BuilderUtils.newContainerId(PHQGGUJJXM, 1), CTJAENBONV.getMasterContainer().getId());
        // Nodes on which the AM's run
        MockNM BUTWRTZBPG = CONGOELUAS;
        if (CTJAENBONV.getMasterContainer().getNodeId().toString().contains("127.0.0.2")) {
            BUTWRTZBPG = TTQQHUTUEM;
        }
        // assert app2 attempt is saved
        RMAppAttempt TUPDTXYPLA = WPOHTTBZNL.getCurrentAppAttempt();
        ApplicationAttemptId POTWOIGZAE = TUPDTXYPLA.getAppAttemptId();
        QYRTPMMNUZ.waitForState(POTWOIGZAE, ALLOCATED);
        FTQQTQEWCO = AMISTHSSOP.get(WPOHTTBZNL.getApplicationId());
        CTJAENBONV = FTQQTQEWCO.getAttempt(POTWOIGZAE);
        Assert.assertNotNull(CTJAENBONV);
        Assert.assertEquals(BuilderUtils.newContainerId(POTWOIGZAE, 1), CTJAENBONV.getMasterContainer().getId());
        MockNM KIHRVVUWQT = CONGOELUAS;
        if (CTJAENBONV.getMasterContainer().getNodeId().toString().contains("127.0.0.2")) {
            KIHRVVUWQT = TTQQHUTUEM;
        }
        // start the AM's
        CUWYNLBMQP = QYRTPMMNUZ.sendAMLaunched(TTBVHJBSHN.getAppAttemptId());
        CUWYNLBMQP.registerAppAttempt();
        MockAM PCKPQDXJLY = QYRTPMMNUZ.sendAMLaunched(TUPDTXYPLA.getAppAttemptId());
        PCKPQDXJLY.registerAppAttempt();
        // request for containers
        CUWYNLBMQP.allocate("127.0.0.1", 1000, 3, new ArrayList<ContainerId>());
        PCKPQDXJLY.allocate("127.0.0.2", 1000, 1, new ArrayList<ContainerId>());
        // verify container allocate continues to work
        CONGOELUAS.nodeHeartbeat(true);
        TTQQHUTUEM.nodeHeartbeat(true);
        EPJFDCOLET = CUWYNLBMQP.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers();
        while (EPJFDCOLET.size() == 0) {
            CONGOELUAS.nodeHeartbeat(true);
            TTQQHUTUEM.nodeHeartbeat(true);
            EPJFDCOLET.addAll(CUWYNLBMQP.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers());
            Thread.sleep(500);
        } 
        // finish the AMs
        finishApplicationMaster(BSCOKNJSJW, QYRTPMMNUZ, BUTWRTZBPG, CUWYNLBMQP);
        finishApplicationMaster(WPOHTTBZNL, QYRTPMMNUZ, KIHRVVUWQT, PCKPQDXJLY);
        // stop RM's
        QYRTPMMNUZ.stop();
        NQYLQUXNAR.stop();
        // completed apps are not removed immediately after app finish
        // And finished app is also loaded back.
        Assert.assertEquals(4, AMISTHSSOP.size());
    }

    @Test(timeout = 60000)
    public void testRMRestartAppRunningAMFailed() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, DEFAULT_RM_AM_MAX_ATTEMPTS);
        MemoryRMStateStore OVRQQFXZSL = new MemoryRMStateStore();
        OVRQQFXZSL.init(NGGDLBOOKG);
        RMState LMYILGXPNO = OVRQQFXZSL.getState();
        Map<ApplicationId, ApplicationState> RRAKGTTDVF = LMYILGXPNO.getApplicationState();
        // start RM
        MockRM PSVRHMDLYK = new MockRM(NGGDLBOOKG, OVRQQFXZSL);
        PSVRHMDLYK.start();
        MockNM DAUQMNNPRE = new MockNM("127.0.0.1:1234", 15120, PSVRHMDLYK.getResourceTrackerService());
        DAUQMNNPRE.registerNode();
        // create app and launch the AM
        RMApp HFYXQJKUSA = PSVRHMDLYK.submitApp(200);
        MockAM KTUDKXJEIF = launchAM(HFYXQJKUSA, PSVRHMDLYK, DAUQMNNPRE);
        // fail the AM by sending CONTAINER_FINISHED event without registering.
        DAUQMNNPRE.nodeHeartbeat(KTUDKXJEIF.getApplicationAttemptId(), 1, COMPLETE);
        KTUDKXJEIF.waitForState(FAILED);
        ApplicationState OISICDKNCM = RRAKGTTDVF.get(HFYXQJKUSA.getApplicationId());
        // assert the AM failed state is saved.
        Assert.assertEquals(FAILED, OISICDKNCM.getAttempt(KTUDKXJEIF.getApplicationAttemptId()).getState());
        // assert app state has not been saved.
        Assert.assertNull(RRAKGTTDVF.get(HFYXQJKUSA.getApplicationId()).getState());
        // new AM started but not registered, app still stays at ACCECPTED state.
        PSVRHMDLYK.waitForState(HFYXQJKUSA.getApplicationId(), ACCEPTED);
        // start new RM
        MockRM FOUPCBQJAC = new MockRM(NGGDLBOOKG, OVRQQFXZSL);
        FOUPCBQJAC.start();
        // assert the previous AM state is loaded back on RM recovery.
        FOUPCBQJAC.waitForState(KTUDKXJEIF.getApplicationAttemptId(), FAILED);
        PSVRHMDLYK.stop();
        FOUPCBQJAC.stop();
    }

    @Test(timeout = 60000)
    public void testRMRestartWaitForPreviousAMToFinish() throws Exception {
        // testing 3 cases
        // After RM restarts
        // 1) New application attempt is not started until previous AM container
        // finish event is reported back to RM as a part of nm registration.
        // 2) If previous AM container finish event is never reported back (i.e.
        // node manager on which this AM container was running also went down) in
        // that case AMLivenessMonitor should time out previous attempt and start
        // new attempt.
        // 3) If all the stored attempts had finished then new attempt should
        // be started immediately.
        YarnConfiguration FDEXFYDMTA = new YarnConfiguration(this.NGGDLBOOKG);
        FDEXFYDMTA.setInt(RM_AM_MAX_ATTEMPTS, 40);
        MemoryRMStateStore ISGVUMOLTH = new MemoryRMStateStore();
        ISGVUMOLTH.init(FDEXFYDMTA);
        RMState MXPMAXZEVJ = ISGVUMOLTH.getState();
        Map<ApplicationId, ApplicationState> YPHAXLLBIJ = MXPMAXZEVJ.getApplicationState();
        // start RM
        final MockRM EFWXLDQLRA = new MockRM(FDEXFYDMTA, ISGVUMOLTH);
        EFWXLDQLRA.start();
        MockNM EFJLIMUVCQ = new MockNM("127.0.0.1:1234", 16382, EFWXLDQLRA.getResourceTrackerService());
        EFJLIMUVCQ.registerNode();
        // submitting app
        RMApp XEXOIPIICD = EFWXLDQLRA.submitApp(200);
        EFWXLDQLRA.waitForState(XEXOIPIICD.getApplicationId(), ACCEPTED);
        MockAM QSQTTVNNEM = launchAM(XEXOIPIICD, EFWXLDQLRA, EFJLIMUVCQ);
        EFJLIMUVCQ.nodeHeartbeat(QSQTTVNNEM.getApplicationAttemptId(), 1, COMPLETE);
        // Fail first AM.
        QSQTTVNNEM.waitForState(FAILED);
        // launch another AM.
        MockAM UDAQWALNUS = launchAM(XEXOIPIICD, EFWXLDQLRA, EFJLIMUVCQ);
        Assert.assertEquals(1, YPHAXLLBIJ.size());
        Assert.assertEquals(XEXOIPIICD.getState(), RUNNING);
        Assert.assertEquals(XEXOIPIICD.getAppAttempts().get(XEXOIPIICD.getCurrentAppAttempt().getAppAttemptId()).getAppAttemptState(), RMAppAttemptState.RUNNING);
        // start new RM.
        MockRM PNPXXLMYAL = null;
        PNPXXLMYAL = new MockRM(FDEXFYDMTA, ISGVUMOLTH);
        PNPXXLMYAL.start();
        EFJLIMUVCQ.setResourceTrackerService(PNPXXLMYAL.getResourceTrackerService());
        NodeHeartbeatResponse QXOTGIXAHO = EFJLIMUVCQ.nodeHeartbeat(true);
        Assert.assertEquals(RESYNC, QXOTGIXAHO.getNodeAction());
        RMApp NOXPLTQGLU = PNPXXLMYAL.getRMContext().getRMApps().get(XEXOIPIICD.getApplicationId());
        // application should be in ACCEPTED state
        PNPXXLMYAL.waitForState(XEXOIPIICD.getApplicationId(), ACCEPTED);
        Assert.assertEquals(ACCEPTED, NOXPLTQGLU.getState());
        // new attempt should not be started
        Assert.assertEquals(2, NOXPLTQGLU.getAppAttempts().size());
        // am1 attempt should be in FAILED state where as am2 attempt should be in
        // LAUNCHED state
        PNPXXLMYAL.waitForState(QSQTTVNNEM.getApplicationAttemptId(), FAILED);
        PNPXXLMYAL.waitForState(UDAQWALNUS.getApplicationAttemptId(), LAUNCHED);
        Assert.assertEquals(FAILED, NOXPLTQGLU.getAppAttempts().get(QSQTTVNNEM.getApplicationAttemptId()).getAppAttemptState());
        Assert.assertEquals(LAUNCHED, NOXPLTQGLU.getAppAttempts().get(UDAQWALNUS.getApplicationAttemptId()).getAppAttemptState());
        NMContainerStatus FFJANUNFFM = TestRMRestart.createNMContainerStatus(UDAQWALNUS.getApplicationAttemptId(), 1, COMPLETE);
        EFJLIMUVCQ.registerNode(Arrays.asList(FFJANUNFFM), null);
        PNPXXLMYAL.waitForState(UDAQWALNUS.getApplicationAttemptId(), FAILED);
        launchAM(NOXPLTQGLU, PNPXXLMYAL, EFJLIMUVCQ);
        Assert.assertEquals(3, NOXPLTQGLU.getAppAttempts().size());
        PNPXXLMYAL.waitForState(NOXPLTQGLU.getCurrentAppAttempt().getAppAttemptId(), RMAppAttemptState.RUNNING);
        // Now restart RM ...
        // Setting AMLivelinessMonitor interval to be 10 Secs.
        FDEXFYDMTA.setInt(RM_AM_EXPIRY_INTERVAL_MS, 10000);
        MockRM ROQGXPQPGA = null;
        ROQGXPQPGA = new MockRM(FDEXFYDMTA, ISGVUMOLTH);
        ROQGXPQPGA.start();
        // Wait for RM to process all the events as a part of rm recovery.
        EFJLIMUVCQ.setResourceTrackerService(ROQGXPQPGA.getResourceTrackerService());
        NOXPLTQGLU = ROQGXPQPGA.getRMContext().getRMApps().get(XEXOIPIICD.getApplicationId());
        // application should be in ACCEPTED state
        ROQGXPQPGA.waitForState(XEXOIPIICD.getApplicationId(), ACCEPTED);
        Assert.assertEquals(NOXPLTQGLU.getState(), ACCEPTED);
        // new attempt should not be started
        Assert.assertEquals(3, NOXPLTQGLU.getAppAttempts().size());
        // am1 and am2 attempts should be in FAILED state where as am3 should be
        // in LAUNCHED state
        ROQGXPQPGA.waitForState(QSQTTVNNEM.getApplicationAttemptId(), FAILED);
        ROQGXPQPGA.waitForState(UDAQWALNUS.getApplicationAttemptId(), FAILED);
        ApplicationAttemptId EHQTUUPEFA = NOXPLTQGLU.getCurrentAppAttempt().getAppAttemptId();
        ROQGXPQPGA.waitForState(EHQTUUPEFA, LAUNCHED);
        Assert.assertEquals(FAILED, NOXPLTQGLU.getAppAttempts().get(QSQTTVNNEM.getApplicationAttemptId()).getAppAttemptState());
        Assert.assertEquals(FAILED, NOXPLTQGLU.getAppAttempts().get(UDAQWALNUS.getApplicationAttemptId()).getAppAttemptState());
        Assert.assertEquals(LAUNCHED, NOXPLTQGLU.getAppAttempts().get(EHQTUUPEFA).getAppAttemptState());
        ROQGXPQPGA.waitForState(EHQTUUPEFA, FAILED);
        ROQGXPQPGA.waitForState(NOXPLTQGLU.getApplicationId(), ACCEPTED);
        Assert.assertEquals(4, NOXPLTQGLU.getAppAttempts().size());
        Assert.assertEquals(FAILED, NOXPLTQGLU.getAppAttempts().get(EHQTUUPEFA).getAppAttemptState());
        EHQTUUPEFA = NOXPLTQGLU.getCurrentAppAttempt().getAppAttemptId();
        // The 4th attempt has started but is not yet saved into RMStateStore
        // It will be saved only when we launch AM.
        // submitting app but not starting AM for it.
        RMApp XFOSEYEIQW = ROQGXPQPGA.submitApp(200);
        ROQGXPQPGA.waitForState(XFOSEYEIQW.getApplicationId(), ACCEPTED);
        Assert.assertEquals(1, XFOSEYEIQW.getAppAttempts().size());
        Assert.assertEquals(0, ISGVUMOLTH.getState().getApplicationState().get(XFOSEYEIQW.getApplicationId()).getAttemptCount());
        MockRM UIWNBMDYYV = null;
        UIWNBMDYYV = new MockRM(FDEXFYDMTA, ISGVUMOLTH);
        UIWNBMDYYV.start();
        NOXPLTQGLU = UIWNBMDYYV.getRMContext().getRMApps().get(XEXOIPIICD.getApplicationId());
        UIWNBMDYYV.waitForState(NOXPLTQGLU.getApplicationId(), ACCEPTED);
        // wait for the attempt to be created.
        int YYEUXXUCYJ = 0;
        while ((NOXPLTQGLU.getAppAttempts().size() != 2) && ((YYEUXXUCYJ++) < 40)) {
            Thread.sleep(200);
        } 
        Assert.assertEquals(4, NOXPLTQGLU.getAppAttempts().size());
        Assert.assertEquals(ACCEPTED, NOXPLTQGLU.getState());
        UIWNBMDYYV.waitForState(EHQTUUPEFA, SCHEDULED);
        Assert.assertEquals(SCHEDULED, NOXPLTQGLU.getAppAttempts().get(EHQTUUPEFA).getAppAttemptState());
        // The initial application for which an AM was not started should be in
        // ACCEPTED state with one application attempt started.
        XFOSEYEIQW = UIWNBMDYYV.getRMContext().getRMApps().get(XFOSEYEIQW.getApplicationId());
        UIWNBMDYYV.waitForState(XFOSEYEIQW.getApplicationId(), ACCEPTED);
        Assert.assertEquals(ACCEPTED, XFOSEYEIQW.getState());
        Assert.assertEquals(1, XFOSEYEIQW.getAppAttempts().size());
        UIWNBMDYYV.waitForState(XFOSEYEIQW.getCurrentAppAttempt().getAppAttemptId(), SCHEDULED);
        Assert.assertEquals(SCHEDULED, XFOSEYEIQW.getCurrentAppAttempt().getAppAttemptState());
    }

    // Test RM restarts after previous attempt succeeded and was saved into state
    // store but before the RMAppAttempt notifies RMApp that it has succeeded. On
    // recovery, RMAppAttempt should send the AttemptFinished event to RMApp so
    // that RMApp can recover its state.
    @Test(timeout = 60000)
    public void testRMRestartWaitForPreviousSucceededAttempt() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, 2);
        MemoryRMStateStore HKDWBUEVMR = new MemoryRMStateStore() {
            int OTQBUJNHBZ = 0;

            @Override
            public void updateApplicationStateInternal(ApplicationId RYVFVYCMXV, ApplicationStateData MDEBCUUBKB) throws Exception {
                if (OTQBUJNHBZ == 0) {
                    // do nothing; simulate app final state is not saved.
                    LOG.info(RYVFVYCMXV + " final state is not saved.");
                    OTQBUJNHBZ++;
                } else {
                    super.updateApplicationStateInternal(RYVFVYCMXV, MDEBCUUBKB);
                }
            }
        };
        HKDWBUEVMR.init(NGGDLBOOKG);
        RMState DHYIACXUIT = HKDWBUEVMR.getState();
        Map<ApplicationId, ApplicationState> DIGAAMDGNL = DHYIACXUIT.getApplicationState();
        // start RM
        MockRM HIJYUXPVTR = new MockRM(NGGDLBOOKG, HKDWBUEVMR);
        HIJYUXPVTR.start();
        MockNM AORHFYVIJI = HIJYUXPVTR.registerNode("127.0.0.1:1234", 15120);
        RMApp ARZNSAWWMI = HIJYUXPVTR.submitApp(200);
        MockAM ULRMEKTZIH = MockRM.launchAndRegisterAM(ARZNSAWWMI, HIJYUXPVTR, AORHFYVIJI);
        FinishApplicationMasterRequest YMOTIFROBG = FinishApplicationMasterRequest.newInstance(SUCCEEDED, "", "");
        ULRMEKTZIH.unregisterAppAttempt(YMOTIFROBG, true);
        ULRMEKTZIH.waitForState(FINISHING);
        // app final state is not saved. This guarantees that RMApp cannot be
        // recovered via its own saved state, but only via the event notification
        // from the RMAppAttempt on recovery.
        Assert.assertNull(DIGAAMDGNL.get(ARZNSAWWMI.getApplicationId()).getState());
        // start RM
        MockRM MGTJTJPZTE = new MockRM(NGGDLBOOKG, HKDWBUEVMR);
        AORHFYVIJI.setResourceTrackerService(MGTJTJPZTE.getResourceTrackerService());
        MGTJTJPZTE.start();
        MGTJTJPZTE.waitForState(ARZNSAWWMI.getCurrentAppAttempt().getAppAttemptId(), RMAppAttemptState.FINISHED);
        MGTJTJPZTE.waitForState(ARZNSAWWMI.getApplicationId(), FINISHED);
        // app final state is saved via the finish event from attempt.
        Assert.assertEquals(FINISHED, DIGAAMDGNL.get(ARZNSAWWMI.getApplicationId()).getState());
    }

    @Test(timeout = 60000)
    public void testRMRestartFailedApp() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, 1);
        MemoryRMStateStore FLRXMTZCPB = new MemoryRMStateStore();
        FLRXMTZCPB.init(NGGDLBOOKG);
        RMState SZDYYNMJDD = FLRXMTZCPB.getState();
        Map<ApplicationId, ApplicationState> QGYHOXEWEV = SZDYYNMJDD.getApplicationState();
        // start RM
        MockRM UHPEKTDZDR = new MockRM(NGGDLBOOKG, FLRXMTZCPB);
        UHPEKTDZDR.start();
        MockNM XKCUEDPXHE = new MockNM("127.0.0.1:1234", 15120, UHPEKTDZDR.getResourceTrackerService());
        XKCUEDPXHE.registerNode();
        // create app and launch the AM
        RMApp WIQVDFKOZA = UHPEKTDZDR.submitApp(200);
        MockAM MHUZIUPFZN = launchAM(WIQVDFKOZA, UHPEKTDZDR, XKCUEDPXHE);
        // fail the AM by sending CONTAINER_FINISHED event without registering.
        XKCUEDPXHE.nodeHeartbeat(MHUZIUPFZN.getApplicationAttemptId(), 1, COMPLETE);
        MHUZIUPFZN.waitForState(FAILED);
        UHPEKTDZDR.waitForState(WIQVDFKOZA.getApplicationId(), RMAppState.FAILED);
        // assert the app/attempt failed state is saved.
        ApplicationState SSGWUVLOST = QGYHOXEWEV.get(WIQVDFKOZA.getApplicationId());
        Assert.assertEquals(RMAppState.FAILED, SSGWUVLOST.getState());
        Assert.assertEquals(FAILED, SSGWUVLOST.getAttempt(MHUZIUPFZN.getApplicationAttemptId()).getState());
        // start new RM
        MockRM CRFZICLEJU = new MockRM(NGGDLBOOKG, FLRXMTZCPB);
        CRFZICLEJU.start();
        RMApp JYQVWZERNJ = CRFZICLEJU.getRMContext().getRMApps().get(WIQVDFKOZA.getApplicationId());
        CRFZICLEJU.waitForState(WIQVDFKOZA.getApplicationId(), RMAppState.FAILED);
        CRFZICLEJU.waitForState(MHUZIUPFZN.getApplicationAttemptId(), FAILED);
        // no new attempt is created.
        Assert.assertEquals(1, JYQVWZERNJ.getAppAttempts().size());
        verifyAppReportAfterRMRestart(WIQVDFKOZA, CRFZICLEJU);
        Assert.assertTrue(WIQVDFKOZA.getDiagnostics().toString().contains("Failing the application."));
        // failed diagnostics from attempt is lost because the diagnostics from
        // attempt is not yet available by the time app is saving the app state.
        UHPEKTDZDR.stop();
        CRFZICLEJU.stop();
    }

    @Test(timeout = 60000)
    public void testRMRestartKilledApp() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, DEFAULT_RM_AM_MAX_ATTEMPTS);
        MemoryRMStateStore XGMSZRCLGJ = new MemoryRMStateStore();
        XGMSZRCLGJ.init(NGGDLBOOKG);
        RMState LOEYKTYVOR = XGMSZRCLGJ.getState();
        Map<ApplicationId, ApplicationState> LGVMCZLRNP = LOEYKTYVOR.getApplicationState();
        // start RM
        MockRM LLDNKCKQWQ = new MockRM(NGGDLBOOKG, XGMSZRCLGJ);
        LLDNKCKQWQ.start();
        MockNM LGGRYQLBCO = new MockNM("127.0.0.1:1234", 15120, LLDNKCKQWQ.getResourceTrackerService());
        LGGRYQLBCO.registerNode();
        // create app and launch the AM
        RMApp ZPDJWGJRWU = LLDNKCKQWQ.submitApp(200);
        MockAM EMHXZGLCVR = launchAM(ZPDJWGJRWU, LLDNKCKQWQ, LGGRYQLBCO);
        // kill the app.
        LLDNKCKQWQ.killApp(ZPDJWGJRWU.getApplicationId());
        LLDNKCKQWQ.waitForState(ZPDJWGJRWU.getApplicationId(), KILLED);
        LLDNKCKQWQ.waitForState(EMHXZGLCVR.getApplicationAttemptId(), RMAppAttemptState.KILLED);
        // killed state is saved.
        ApplicationState ZPNZLYGQVL = LGVMCZLRNP.get(ZPDJWGJRWU.getApplicationId());
        Assert.assertEquals(KILLED, ZPNZLYGQVL.getState());
        Assert.assertEquals(RMAppAttemptState.KILLED, ZPNZLYGQVL.getAttempt(EMHXZGLCVR.getApplicationAttemptId()).getState());
        // restart rm
        MockRM SCRKPRKDDO = new MockRM(NGGDLBOOKG, XGMSZRCLGJ);
        SCRKPRKDDO.start();
        RMApp BCMUCFOZXS = SCRKPRKDDO.getRMContext().getRMApps().get(ZPDJWGJRWU.getApplicationId());
        SCRKPRKDDO.waitForState(ZPDJWGJRWU.getApplicationId(), KILLED);
        SCRKPRKDDO.waitForState(EMHXZGLCVR.getApplicationAttemptId(), RMAppAttemptState.KILLED);
        // no new attempt is created.
        Assert.assertEquals(1, BCMUCFOZXS.getAppAttempts().size());
        ApplicationReport DFZWDIZHKY = verifyAppReportAfterRMRestart(ZPDJWGJRWU, SCRKPRKDDO);
        Assert.assertEquals(ZPDJWGJRWU.getDiagnostics().toString(), DFZWDIZHKY.getDiagnostics());
        LLDNKCKQWQ.stop();
        SCRKPRKDDO.stop();
    }

    @Test(timeout = 60000)
    public void testRMRestartKilledAppWithNoAttempts() throws Exception {
        MemoryRMStateStore JQRPAFTDMK = new MemoryRMStateStore() {
            @Override
            public synchronized void storeApplicationAttemptStateInternal(ApplicationAttemptId BNKMLXQOBF, ApplicationAttemptStateData ZAFVRNGWJL) throws Exception {
                // ignore attempt saving request.
            }

            @Override
            public synchronized void updateApplicationAttemptStateInternal(ApplicationAttemptId JOZWOBXUKQ, ApplicationAttemptStateData UOCTGSMNDM) throws Exception {
                // ignore attempt saving request.
            }
        };
        JQRPAFTDMK.init(NGGDLBOOKG);
        // start RM
        MockRM AEITEFRFJN = new MockRM(NGGDLBOOKG, JQRPAFTDMK);
        AEITEFRFJN.start();
        // create app
        RMApp DZTMGXMWFD = AEITEFRFJN.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", -1, null, "MAPREDUCE", false);
        // kill the app.
        AEITEFRFJN.killApp(DZTMGXMWFD.getApplicationId());
        AEITEFRFJN.waitForState(DZTMGXMWFD.getApplicationId(), KILLED);
        // restart rm
        MockRM NBZNLCDMOP = new MockRM(NGGDLBOOKG, JQRPAFTDMK);
        NBZNLCDMOP.start();
        RMApp KAWDLABDXL = NBZNLCDMOP.getRMContext().getRMApps().get(DZTMGXMWFD.getApplicationId());
        NBZNLCDMOP.waitForState(KAWDLABDXL.getApplicationId(), KILLED);
        Assert.assertTrue(KAWDLABDXL.getAppAttempts().size() == 0);
    }

    @Test(timeout = 60000)
    public void testRMRestartSucceededApp() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, DEFAULT_RM_AM_MAX_ATTEMPTS);
        MemoryRMStateStore RJBCWSNXRK = new MemoryRMStateStore();
        RJBCWSNXRK.init(NGGDLBOOKG);
        RMState SPQRFVIWPZ = RJBCWSNXRK.getState();
        Map<ApplicationId, ApplicationState> RBFGCXBIRR = SPQRFVIWPZ.getApplicationState();
        // start RM
        MockRM DXHVCARPXX = new MockRM(NGGDLBOOKG, RJBCWSNXRK);
        DXHVCARPXX.start();
        MockNM OESGNXDAZA = new MockNM("127.0.0.1:1234", 15120, DXHVCARPXX.getResourceTrackerService());
        OESGNXDAZA.registerNode();
        // create an app and finish the app.
        RMApp VVQMZOPRYQ = DXHVCARPXX.submitApp(200);
        MockAM HZOXJOVEPS = launchAM(VVQMZOPRYQ, DXHVCARPXX, OESGNXDAZA);
        // unregister am
        FinishApplicationMasterRequest AZEBLXAWEF = FinishApplicationMasterRequest.newInstance(SUCCEEDED, "diagnostics", "trackingUrl");
        finishApplicationMaster(VVQMZOPRYQ, DXHVCARPXX, OESGNXDAZA, HZOXJOVEPS, AZEBLXAWEF);
        // check the state store about the unregistered info.
        ApplicationState XONUYSTDAE = RBFGCXBIRR.get(VVQMZOPRYQ.getApplicationId());
        ApplicationAttemptState DRXXEBYKZX = XONUYSTDAE.getAttempt(HZOXJOVEPS.getApplicationAttemptId());
        Assert.assertEquals("diagnostics", DRXXEBYKZX.getDiagnostics());
        Assert.assertEquals(SUCCEEDED, DRXXEBYKZX.getFinalApplicationStatus());
        Assert.assertEquals("trackingUrl", DRXXEBYKZX.getFinalTrackingUrl());
        Assert.assertEquals(VVQMZOPRYQ.getFinishTime(), XONUYSTDAE.getFinishTime());
        // restart rm
        MockRM IIAXVXIAJQ = new MockRM(NGGDLBOOKG, RJBCWSNXRK);
        IIAXVXIAJQ.start();
        // verify application report returns the same app info as the app info
        // before RM restarts.
        ApplicationReport DGNTZNVCGN = verifyAppReportAfterRMRestart(VVQMZOPRYQ, IIAXVXIAJQ);
        Assert.assertEquals(SUCCEEDED, DGNTZNVCGN.getFinalApplicationStatus());
        Assert.assertEquals("trackingUrl", DGNTZNVCGN.getOriginalTrackingUrl());
        DXHVCARPXX.stop();
        IIAXVXIAJQ.stop();
    }

    @Test(timeout = 60000)
    public void testRMRestartGetApplicationList() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, 1);
        MemoryRMStateStore LVOCNSHWEC = new MemoryRMStateStore();
        LVOCNSHWEC.init(NGGDLBOOKG);
        // start RM
        MockRM YOOEIAMHRM = new MockRM(NGGDLBOOKG, LVOCNSHWEC);
        YOOEIAMHRM.start();
        MockNM UBUDIRTIZZ = new MockNM("127.0.0.1:1234", 15120, YOOEIAMHRM.getResourceTrackerService());
        UBUDIRTIZZ.registerNode();
        // a succeeded app.
        RMApp VMIMOPWUWG = YOOEIAMHRM.submitApp(200, "name", "user", null, false, "default", 1, null, "myType");
        MockAM OSWJZOHYKA = launchAM(VMIMOPWUWG, YOOEIAMHRM, UBUDIRTIZZ);
        finishApplicationMaster(VMIMOPWUWG, YOOEIAMHRM, UBUDIRTIZZ, OSWJZOHYKA);
        // a failed app.
        RMApp AFSBIPHCZW = YOOEIAMHRM.submitApp(200, "name", "user", null, false, "default", 1, null, "myType");
        MockAM QDDPWNTUBD = launchAM(AFSBIPHCZW, YOOEIAMHRM, UBUDIRTIZZ);
        // fail the AM by sending CONTAINER_FINISHED event without registering.
        UBUDIRTIZZ.nodeHeartbeat(QDDPWNTUBD.getApplicationAttemptId(), 1, COMPLETE);
        QDDPWNTUBD.waitForState(FAILED);
        YOOEIAMHRM.waitForState(AFSBIPHCZW.getApplicationId(), RMAppState.FAILED);
        // a killed app.
        RMApp PWOMCIMSOJ = YOOEIAMHRM.submitApp(200, "name", "user", null, false, "default", 1, null, "myType");
        MockAM JEHZJOTRFJ = launchAM(PWOMCIMSOJ, YOOEIAMHRM, UBUDIRTIZZ);
        YOOEIAMHRM.killApp(PWOMCIMSOJ.getApplicationId());
        YOOEIAMHRM.waitForState(PWOMCIMSOJ.getApplicationId(), KILLED);
        YOOEIAMHRM.waitForState(JEHZJOTRFJ.getApplicationAttemptId(), RMAppAttemptState.KILLED);
        // restart rm
        MockRM QCCLMKFIXM = new MockRM(NGGDLBOOKG, LVOCNSHWEC) {
            @Override
            protected RMAppManager createRMAppManager() {
                return spy(super.createRMAppManager());
            }
        };
        QCCLMKFIXM.start();
        GetApplicationsRequest IQSSXQBSIK = GetApplicationsRequest.newInstance(EnumSet.of(YarnApplicationState.FINISHED, YarnApplicationState.KILLED, YarnApplicationState.FAILED));
        GetApplicationsResponse XADGPUFBTX = QCCLMKFIXM.getClientRMService().getApplications(IQSSXQBSIK);
        List<ApplicationReport> XJOCYCOGFD = XADGPUFBTX.getApplicationList();
        // assert all applications exist according to application state after RM
        // restarts.
        boolean EFKYYDKGJY = false;
        boolean JGHYUZDHYZ = false;
        boolean WFUCVTBFPL = false;
        for (ApplicationReport FVAENXKEKY : XJOCYCOGFD) {
            if (FVAENXKEKY.getApplicationId().equals(VMIMOPWUWG.getApplicationId())) {
                Assert.assertEquals(YarnApplicationState.FINISHED, FVAENXKEKY.getYarnApplicationState());
                EFKYYDKGJY = true;
            }
            if (FVAENXKEKY.getApplicationId().equals(AFSBIPHCZW.getApplicationId())) {
                Assert.assertEquals(YarnApplicationState.FAILED, FVAENXKEKY.getYarnApplicationState());
                JGHYUZDHYZ = true;
            }
            if (FVAENXKEKY.getApplicationId().equals(PWOMCIMSOJ.getApplicationId())) {
                Assert.assertEquals(YarnApplicationState.KILLED, FVAENXKEKY.getYarnApplicationState());
                WFUCVTBFPL = true;
            }
        }
        Assert.assertTrue((EFKYYDKGJY && JGHYUZDHYZ) && WFUCVTBFPL);
        // assert all applications exist according to application type after RM
        // restarts.
        Set<String> JBYXMUVAGH = new HashSet<String>();
        JBYXMUVAGH.add("myType");
        GetApplicationsRequest WBAQILEKLF = GetApplicationsRequest.newInstance(JBYXMUVAGH);
        GetApplicationsResponse BRMSOCDQOB = QCCLMKFIXM.getClientRMService().getApplications(WBAQILEKLF);
        List<ApplicationReport> OSUHTUHPNE = BRMSOCDQOB.getApplicationList();
        Assert.assertTrue(3 == OSUHTUHPNE.size());
        // check application summary is logged for the completed apps after RM restart.
        verify(QCCLMKFIXM.getRMAppManager(), times(3)).logApplicationSummary(isA(ApplicationId.class));
        YOOEIAMHRM.stop();
        QCCLMKFIXM.stop();
    }

    private MockAM launchAM(RMApp RTCABPEHYH, MockRM FNNGFMSEGW, MockNM YKROERJVFB) throws Exception {
        RMAppAttempt PEGRULPROE = RTCABPEHYH.getCurrentAppAttempt();
        YKROERJVFB.nodeHeartbeat(true);
        MockAM AWRIFDQSGZ = FNNGFMSEGW.sendAMLaunched(PEGRULPROE.getAppAttemptId());
        AWRIFDQSGZ.registerAppAttempt();
        FNNGFMSEGW.waitForState(RTCABPEHYH.getApplicationId(), RUNNING);
        return AWRIFDQSGZ;
    }

    private ApplicationReport verifyAppReportAfterRMRestart(RMApp RYLPEGFPMI, MockRM IHCLNPNAXL) throws Exception {
        GetApplicationReportRequest CSGQRPKPID = GetApplicationReportRequest.newInstance(RYLPEGFPMI.getApplicationId());
        GetApplicationReportResponse QGORRDKHCG = IHCLNPNAXL.getClientRMService().getApplicationReport(CSGQRPKPID);
        ApplicationReport FBLZAKHXEH = QGORRDKHCG.getApplicationReport();
        Assert.assertEquals(RYLPEGFPMI.getStartTime(), FBLZAKHXEH.getStartTime());
        Assert.assertEquals(RYLPEGFPMI.getFinishTime(), FBLZAKHXEH.getFinishTime());
        Assert.assertEquals(RYLPEGFPMI.createApplicationState(), FBLZAKHXEH.getYarnApplicationState());
        Assert.assertTrue(1 == FBLZAKHXEH.getProgress());
        return QGORRDKHCG.getApplicationReport();
    }

    private void finishApplicationMaster(RMApp CMWCVMCUTJ, MockRM ORWTAQPLMJ, MockNM ILTDUODXYW, MockAM JZGNYQWRTZ) throws Exception {
        final FinishApplicationMasterRequest SLOARDOUGD = FinishApplicationMasterRequest.newInstance(SUCCEEDED, "", "");
        finishApplicationMaster(CMWCVMCUTJ, ORWTAQPLMJ, ILTDUODXYW, JZGNYQWRTZ, SLOARDOUGD);
    }

    private void finishApplicationMaster(RMApp ZBXBEWNNLC, MockRM PBNHJUFZOT, MockNM AXSLEEFTWN, MockAM LCADQHZUES, FinishApplicationMasterRequest RRURMDEOWW) throws Exception {
        RMState NAKTAKVHJB = ((MemoryRMStateStore) (PBNHJUFZOT.getRMContext().getStateStore())).getState();
        Map<ApplicationId, ApplicationState> YNWJQDVVXS = NAKTAKVHJB.getApplicationState();
        LCADQHZUES.unregisterAppAttempt(RRURMDEOWW, true);
        LCADQHZUES.waitForState(FINISHING);
        AXSLEEFTWN.nodeHeartbeat(LCADQHZUES.getApplicationAttemptId(), 1, COMPLETE);
        LCADQHZUES.waitForState(RMAppAttemptState.FINISHED);
        PBNHJUFZOT.waitForState(ZBXBEWNNLC.getApplicationId(), FINISHED);
        // check that app/attempt is saved with the final state
        ApplicationState QLMNSNMITY = YNWJQDVVXS.get(ZBXBEWNNLC.getApplicationId());
        Assert.assertEquals(FINISHED, QLMNSNMITY.getState());
        Assert.assertEquals(RMAppAttemptState.FINISHED, QLMNSNMITY.getAttempt(LCADQHZUES.getApplicationAttemptId()).getState());
    }

    @Test(timeout = 60000)
    public void testRMRestartOnMaxAppAttempts() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, DEFAULT_RM_AM_MAX_ATTEMPTS);
        MemoryRMStateStore LPHNXUXTKK = new MemoryRMStateStore();
        LPHNXUXTKK.init(NGGDLBOOKG);
        RMState PKQHJFLACI = LPHNXUXTKK.getState();
        Map<ApplicationId, ApplicationState> YZQIGUXAQJ = PKQHJFLACI.getApplicationState();
        MockRM DUHMPWKOBZ = new MockRM(NGGDLBOOKG, LPHNXUXTKK);
        DUHMPWKOBZ.start();
        MockNM UWSDQLIRQB = new MockNM("127.0.0.1:1234", 15120, DUHMPWKOBZ.getResourceTrackerService());
        UWSDQLIRQB.registerNode();
        // submit an app with maxAppAttempts equals to 1
        RMApp ICQYGKWZZY = DUHMPWKOBZ.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", 1, null);
        // submit an app with maxAppAttempts equals to -1
        RMApp NALIWXKZTJ = DUHMPWKOBZ.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", -1, null);
        // assert app1 info is saved
        ApplicationState MMDMGCHPFN = YZQIGUXAQJ.get(ICQYGKWZZY.getApplicationId());
        Assert.assertNotNull(MMDMGCHPFN);
        Assert.assertEquals(0, MMDMGCHPFN.getAttemptCount());
        Assert.assertEquals(MMDMGCHPFN.getApplicationSubmissionContext().getApplicationId(), ICQYGKWZZY.getApplicationSubmissionContext().getApplicationId());
        // Allocate the AM
        UWSDQLIRQB.nodeHeartbeat(true);
        RMAppAttempt RDHXRRFEGZ = ICQYGKWZZY.getCurrentAppAttempt();
        ApplicationAttemptId YIMRENLUIU = RDHXRRFEGZ.getAppAttemptId();
        DUHMPWKOBZ.waitForState(YIMRENLUIU, ALLOCATED);
        Assert.assertEquals(1, MMDMGCHPFN.getAttemptCount());
        ApplicationAttemptState UJOOLJSVKY = MMDMGCHPFN.getAttempt(YIMRENLUIU);
        Assert.assertNotNull(UJOOLJSVKY);
        Assert.assertEquals(BuilderUtils.newContainerId(YIMRENLUIU, 1), UJOOLJSVKY.getMasterContainer().getId());
        // Setting AMLivelinessMonitor interval to be 3 Secs.
        NGGDLBOOKG.setInt(RM_AM_EXPIRY_INTERVAL_MS, 3000);
        // start new RM
        MockRM BLJMGLVFHW = new MockRM(NGGDLBOOKG, LPHNXUXTKK);
        BLJMGLVFHW.start();
        // verify that maxAppAttempts is set to global value
        Assert.assertEquals(2, BLJMGLVFHW.getRMContext().getRMApps().get(NALIWXKZTJ.getApplicationId()).getMaxAppAttempts());
        // app1 and app2 are loaded back, but app1 failed because it's
        // hitting max-retry.
        Assert.assertEquals(2, BLJMGLVFHW.getRMContext().getRMApps().size());
        BLJMGLVFHW.waitForState(ICQYGKWZZY.getApplicationId(), RMAppState.FAILED);
        BLJMGLVFHW.waitForState(NALIWXKZTJ.getApplicationId(), ACCEPTED);
        // app1 failed state is saved in state store. app2 final saved state is not
        // determined yet.
        Assert.assertEquals(RMAppState.FAILED, YZQIGUXAQJ.get(ICQYGKWZZY.getApplicationId()).getState());
        Assert.assertNull(YZQIGUXAQJ.get(NALIWXKZTJ.getApplicationId()).getState());
        // stop the RM
        DUHMPWKOBZ.stop();
        BLJMGLVFHW.stop();
    }

    @Test(timeout = 60000)
    public void testDelegationTokenRestoredInDelegationTokenRenewer() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, 2);
        NGGDLBOOKG.set(HADOOP_SECURITY_AUTHENTICATION, "kerberos");
        UserGroupInformation.setConfiguration(NGGDLBOOKG);
        MemoryRMStateStore ZGAQOHGXWJ = new MemoryRMStateStore();
        ZGAQOHGXWJ.init(NGGDLBOOKG);
        RMState QIRGHQVHEQ = ZGAQOHGXWJ.getState();
        Map<ApplicationId, ApplicationState> LMXZTNHCMT = QIRGHQVHEQ.getApplicationState();
        MockRM ORNZUMWHPF = new TestRMRestart.TestSecurityMockRM(NGGDLBOOKG, ZGAQOHGXWJ);
        ORNZUMWHPF.start();
        HashSet<Token<RMDelegationTokenIdentifier>> CXTZQCFRIG = new HashSet<Token<RMDelegationTokenIdentifier>>();
        // create an empty credential
        Credentials ZEBRRIZPSA = new Credentials();
        // create tokens and add into credential
        Text XLCKRINJPU = new Text("user1");
        RMDelegationTokenIdentifier WLIDOERIRF = new RMDelegationTokenIdentifier(XLCKRINJPU, new Text("renewer1"), XLCKRINJPU);
        Token<RMDelegationTokenIdentifier> EDYXUMNZFK = new Token<RMDelegationTokenIdentifier>(WLIDOERIRF, ORNZUMWHPF.getRMContext().getRMDelegationTokenSecretManager());
        SecurityUtil.setTokenService(EDYXUMNZFK, TestRMRestart.JYDWNVRJVO);
        ZEBRRIZPSA.addToken(XLCKRINJPU, EDYXUMNZFK);
        CXTZQCFRIG.add(EDYXUMNZFK);
        Text RYUGSPHMLQ = new Text("user2");
        RMDelegationTokenIdentifier YCSDJJZEVJ = new RMDelegationTokenIdentifier(RYUGSPHMLQ, new Text("renewer2"), RYUGSPHMLQ);
        Token<RMDelegationTokenIdentifier> WCCPSBXIOK = new Token<RMDelegationTokenIdentifier>(YCSDJJZEVJ, ORNZUMWHPF.getRMContext().getRMDelegationTokenSecretManager());
        SecurityUtil.setTokenService(WCCPSBXIOK, TestRMRestart.JYDWNVRJVO);
        ZEBRRIZPSA.addToken(RYUGSPHMLQ, WCCPSBXIOK);
        CXTZQCFRIG.add(WCCPSBXIOK);
        // submit an app with customized credential
        RMApp WHPHOABETI = ORNZUMWHPF.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", 1, ZEBRRIZPSA);
        // assert app info is saved
        ApplicationState ZSMJPWAKQZ = LMXZTNHCMT.get(WHPHOABETI.getApplicationId());
        Assert.assertNotNull(ZSMJPWAKQZ);
        // assert delegation tokens exist in rm1 DelegationTokenRenewr
        Assert.assertEquals(CXTZQCFRIG, ORNZUMWHPF.getRMContext().getDelegationTokenRenewer().getDelegationTokens());
        // assert delegation tokens are saved
        DataOutputBuffer TITABYTTTE = new DataOutputBuffer();
        ZEBRRIZPSA.writeTokenStorageToStream(TITABYTTTE);
        ByteBuffer GUHRRCGOCL = ByteBuffer.wrap(TITABYTTTE.getData(), 0, TITABYTTTE.getLength());
        GUHRRCGOCL.rewind();
        Assert.assertEquals(GUHRRCGOCL, ZSMJPWAKQZ.getApplicationSubmissionContext().getAMContainerSpec().getTokens());
        // start new RM
        MockRM XMQUWWOQRX = new TestRMRestart.TestSecurityMockRM(NGGDLBOOKG, ZGAQOHGXWJ);
        XMQUWWOQRX.start();
        // Need to wait for a while as now token renewal happens on another thread
        // and is asynchronous in nature.
        waitForTokensToBeRenewed(XMQUWWOQRX);
        // verify tokens are properly populated back to rm2 DelegationTokenRenewer
        Assert.assertEquals(CXTZQCFRIG, XMQUWWOQRX.getRMContext().getDelegationTokenRenewer().getDelegationTokens());
        // stop the RM
        ORNZUMWHPF.stop();
        XMQUWWOQRX.stop();
    }

    private void waitForTokensToBeRenewed(MockRM BTKRCCTXBY) throws Exception {
        int SGGOZLWHXI = 20;
        boolean GXSLSGCKFI = true;
        while (((SGGOZLWHXI--) > 0) && GXSLSGCKFI) {
            GXSLSGCKFI = false;
            for (RMApp GIDEGYTQIB : BTKRCCTXBY.getRMContext().getRMApps().values()) {
                if (GIDEGYTQIB.getState() == RMAppState.NEW) {
                    Thread.sleep(1000);
                    GXSLSGCKFI = true;
                    break;
                }
            }
        } 
    }

    @Test(timeout = 60000)
    public void testAppAttemptTokensRestoredOnRMRestart() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, 2);
        NGGDLBOOKG.set(HADOOP_SECURITY_AUTHENTICATION, "kerberos");
        UserGroupInformation.setConfiguration(NGGDLBOOKG);
        MemoryRMStateStore ICAQPPHVUZ = new MemoryRMStateStore();
        ICAQPPHVUZ.init(NGGDLBOOKG);
        RMState UFRKPACCEX = ICAQPPHVUZ.getState();
        Map<ApplicationId, ApplicationState> FISYDBJWMT = UFRKPACCEX.getApplicationState();
        MockRM MQJNUPHPPL = new TestRMRestart.TestSecurityMockRM(NGGDLBOOKG, ICAQPPHVUZ);
        MQJNUPHPPL.start();
        MockNM SKYZTXFGRC = new MockNM("0.0.0.0:4321", 15120, MQJNUPHPPL.getResourceTrackerService());
        SKYZTXFGRC.registerNode();
        // submit an app
        RMApp RDYNJPNPLS = MQJNUPHPPL.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), "default");
        // assert app info is saved
        ApplicationState DSCRVSHVCL = FISYDBJWMT.get(RDYNJPNPLS.getApplicationId());
        Assert.assertNotNull(DSCRVSHVCL);
        // Allocate the AM
        SKYZTXFGRC.nodeHeartbeat(true);
        RMAppAttempt OMPPJNPBBI = RDYNJPNPLS.getCurrentAppAttempt();
        ApplicationAttemptId WVHKPJTJMX = OMPPJNPBBI.getAppAttemptId();
        MQJNUPHPPL.waitForState(WVHKPJTJMX, ALLOCATED);
        // assert attempt info is saved
        ApplicationAttemptState CGNLLXKUDK = DSCRVSHVCL.getAttempt(WVHKPJTJMX);
        Assert.assertNotNull(CGNLLXKUDK);
        Assert.assertEquals(BuilderUtils.newContainerId(WVHKPJTJMX, 1), CGNLLXKUDK.getMasterContainer().getId());
        // the clientTokenMasterKey that are generated when
        // RMAppAttempt is created,
        byte[] CXOUXZAERV = OMPPJNPBBI.getClientTokenMasterKey().getEncoded();
        // assert application credentials are saved
        Credentials OSDJWZJETW = CGNLLXKUDK.getAppAttemptCredentials();
        Assert.assertArrayEquals("client token master key not saved", CXOUXZAERV, OSDJWZJETW.getSecretKey(AM_CLIENT_TOKEN_MASTER_KEY_NAME));
        // start new RM
        MockRM OIROWGICLL = new TestRMRestart.TestSecurityMockRM(NGGDLBOOKG, ICAQPPHVUZ);
        OIROWGICLL.start();
        RMApp OQJKRSYMJV = OIROWGICLL.getRMContext().getRMApps().get(RDYNJPNPLS.getApplicationId());
        RMAppAttempt PXSYSRFOVD = OQJKRSYMJV.getRMAppAttempt(WVHKPJTJMX);
        // assert loaded attempt recovered
        Assert.assertNotNull(PXSYSRFOVD);
        // assert client token master key is recovered back to api-versioned
        // client token master key
        Assert.assertEquals("client token master key not restored", OMPPJNPBBI.getClientTokenMasterKey(), PXSYSRFOVD.getClientTokenMasterKey());
        // assert ClientTokenSecretManager also knows about the key
        Assert.assertArrayEquals(CXOUXZAERV, OIROWGICLL.getClientToAMTokenSecretManager().getMasterKey(WVHKPJTJMX).getEncoded());
        // assert AMRMTokenSecretManager also knows about the AMRMToken password
        Token<AMRMTokenIdentifier> OOAATWNLCQ = PXSYSRFOVD.getAMRMToken();
        Assert.assertArrayEquals(OOAATWNLCQ.getPassword(), OIROWGICLL.getRMContext().getAMRMTokenSecretManager().retrievePassword(OOAATWNLCQ.decodeIdentifier()));
        MQJNUPHPPL.stop();
        OIROWGICLL.stop();
    }

    @Test(timeout = 60000)
    public void testRMDelegationTokenRestoredOnRMRestart() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, 2);
        NGGDLBOOKG.set(HADOOP_SECURITY_AUTHENTICATION, "kerberos");
        NGGDLBOOKG.set(RM_ADDRESS, "localhost:8032");
        UserGroupInformation.setConfiguration(NGGDLBOOKG);
        MemoryRMStateStore VIFEQSHUXT = new MemoryRMStateStore();
        VIFEQSHUXT.init(NGGDLBOOKG);
        RMState DTZHGVQCIO = VIFEQSHUXT.getState();
        Map<ApplicationId, ApplicationState> PZRHUKURXG = DTZHGVQCIO.getApplicationState();
        Map<RMDelegationTokenIdentifier, Long> XQIFOWNPRL = DTZHGVQCIO.getRMDTSecretManagerState().getTokenState();
        Set<DelegationKey> KJDSCUAUUO = DTZHGVQCIO.getRMDTSecretManagerState().getMasterKeyState();
        MockRM GINGEBKHLH = new TestRMRestart.TestSecurityMockRM(NGGDLBOOKG, VIFEQSHUXT);
        GINGEBKHLH.start();
        // create an empty credential
        Credentials BJNCLOQMDQ = new Credentials();
        // request a token and add into credential
        GetDelegationTokenRequest IZJHKOJDAY = GetDelegationTokenRequest.newInstance("renewer1");
        UserGroupInformation.getCurrentUser().setAuthenticationMethod(AuthMethod.KERBEROS);
        GetDelegationTokenResponse AWVAUJDTIG = GINGEBKHLH.getClientRMService().getDelegationToken(IZJHKOJDAY);
        org.apache.hadoop.yarn.api.records.Token PHAMTEYPLQ = AWVAUJDTIG.getRMDelegationToken();
        Token<RMDelegationTokenIdentifier> RWDEGRTCOA = ConverterUtils.convertFromYarn(PHAMTEYPLQ, TestRMRestart.JYDWNVRJVO);
        RMDelegationTokenIdentifier MATBNJLUBM = RWDEGRTCOA.decodeIdentifier();
        HashSet<RMDelegationTokenIdentifier> UWBHWVXZNE = new HashSet<RMDelegationTokenIdentifier>();
        BJNCLOQMDQ.addToken(RWDEGRTCOA.getService(), RWDEGRTCOA);
        UWBHWVXZNE.add(MATBNJLUBM);
        // submit an app with customized credential
        RMApp XMHDTLCLOX = GINGEBKHLH.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", 1, BJNCLOQMDQ);
        // assert app info is saved
        ApplicationState XGEWBLHCKB = PZRHUKURXG.get(XMHDTLCLOX.getApplicationId());
        Assert.assertNotNull(XGEWBLHCKB);
        // assert all master keys are saved
        Set<DelegationKey> ADVXXEBFIU = GINGEBKHLH.getRMContext().getRMDelegationTokenSecretManager().getAllMasterKeys();
        Assert.assertEquals(ADVXXEBFIU, KJDSCUAUUO);
        // assert all tokens are saved
        Map<RMDelegationTokenIdentifier, Long> BFMKJJUHIW = GINGEBKHLH.getRMContext().getRMDelegationTokenSecretManager().getAllTokens();
        Assert.assertEquals(UWBHWVXZNE, BFMKJJUHIW.keySet());
        Assert.assertEquals(BFMKJJUHIW, XQIFOWNPRL);
        // assert sequence number is saved
        Assert.assertEquals(GINGEBKHLH.getRMContext().getRMDelegationTokenSecretManager().getLatestDTSequenceNumber(), DTZHGVQCIO.getRMDTSecretManagerState().getDTSequenceNumber());
        // request one more token
        GetDelegationTokenRequest IJOWEZFBNN = GetDelegationTokenRequest.newInstance("renewer2");
        GetDelegationTokenResponse OXCUYKWAER = GINGEBKHLH.getClientRMService().getDelegationToken(IJOWEZFBNN);
        org.apache.hadoop.yarn.api.records.Token MWBBQWPGLN = OXCUYKWAER.getRMDelegationToken();
        Token<RMDelegationTokenIdentifier> OWPMKZVWBI = ConverterUtils.convertFromYarn(MWBBQWPGLN, TestRMRestart.JYDWNVRJVO);
        RMDelegationTokenIdentifier NOZIYGGTKB = OWPMKZVWBI.decodeIdentifier();
        // cancel token2
        try {
            GINGEBKHLH.getRMContext().getRMDelegationTokenSecretManager().cancelToken(OWPMKZVWBI, UserGroupInformation.getCurrentUser().getUserName());
        } catch (Exception e) {
            Assert.fail();
        }
        // Assert the token which has the latest delegationTokenSequenceNumber is removed
        Assert.assertEquals(GINGEBKHLH.getRMContext().getRMDelegationTokenSecretManager().getLatestDTSequenceNumber(), NOZIYGGTKB.getSequenceNumber());
        Assert.assertFalse(XQIFOWNPRL.containsKey(NOZIYGGTKB));
        // start new RM
        MockRM RCBRFLDTKX = new TestRMRestart.TestSecurityMockRM(NGGDLBOOKG, VIFEQSHUXT);
        RCBRFLDTKX.start();
        // assert master keys and tokens are populated back to DTSecretManager
        Map<RMDelegationTokenIdentifier, Long> ZCBEUEBPDW = RCBRFLDTKX.getRMContext().getRMDelegationTokenSecretManager().getAllTokens();
        Assert.assertEquals(ZCBEUEBPDW.keySet(), BFMKJJUHIW.keySet());
        // rm2 has its own master keys when it starts, we use containsAll here
        Assert.assertTrue(RCBRFLDTKX.getRMContext().getRMDelegationTokenSecretManager().getAllMasterKeys().containsAll(ADVXXEBFIU));
        // assert sequenceNumber is properly recovered,
        // even though the token which has max sequenceNumber is not stored
        Assert.assertEquals(GINGEBKHLH.getRMContext().getRMDelegationTokenSecretManager().getLatestDTSequenceNumber(), RCBRFLDTKX.getRMContext().getRMDelegationTokenSecretManager().getLatestDTSequenceNumber());
        // renewDate before renewing
        Long ZAZIPGPWAM = ZCBEUEBPDW.get(MATBNJLUBM);
        try {
            // Sleep for one millisecond to make sure renewDataAfterRenew is greater
            Thread.sleep(1);
            // renew recovered token
            RCBRFLDTKX.getRMContext().getRMDelegationTokenSecretManager().renewToken(RWDEGRTCOA, "renewer1");
        } catch (Exception e) {
            Assert.fail();
        }
        ZCBEUEBPDW = RCBRFLDTKX.getRMContext().getRMDelegationTokenSecretManager().getAllTokens();
        Long TFEHHEPKVR = ZCBEUEBPDW.get(MATBNJLUBM);
        // assert token is renewed
        Assert.assertTrue(TFEHHEPKVR > ZAZIPGPWAM);
        // assert new token is added into state store
        Assert.assertTrue(XQIFOWNPRL.containsValue(TFEHHEPKVR));
        // assert old token is removed from state store
        Assert.assertFalse(XQIFOWNPRL.containsValue(ZAZIPGPWAM));
        try {
            RCBRFLDTKX.getRMContext().getRMDelegationTokenSecretManager().cancelToken(RWDEGRTCOA, UserGroupInformation.getCurrentUser().getUserName());
        } catch (Exception e) {
            Assert.fail();
        }
        // assert token is removed from state after its cancelled
        ZCBEUEBPDW = RCBRFLDTKX.getRMContext().getRMDelegationTokenSecretManager().getAllTokens();
        Assert.assertFalse(ZCBEUEBPDW.containsKey(MATBNJLUBM));
        Assert.assertFalse(XQIFOWNPRL.containsKey(MATBNJLUBM));
        // stop the RM
        GINGEBKHLH.stop();
        RCBRFLDTKX.stop();
    }

    // This is to test submit an application to the new RM with the old delegation
    // token got from previous RM.
    @Test(timeout = 60000)
    public void testAppSubmissionWithOldDelegationTokenAfterRMRestart() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, 2);
        NGGDLBOOKG.set(HADOOP_SECURITY_AUTHENTICATION, "kerberos");
        NGGDLBOOKG.set(RM_ADDRESS, "localhost:8032");
        UserGroupInformation.setConfiguration(NGGDLBOOKG);
        MemoryRMStateStore VPKOIMLSHH = new MemoryRMStateStore();
        VPKOIMLSHH.init(NGGDLBOOKG);
        MockRM FFTEOETNBV = new TestRMRestart.TestSecurityMockRM(NGGDLBOOKG, VPKOIMLSHH);
        FFTEOETNBV.start();
        GetDelegationTokenRequest HTRGUZWEAQ = GetDelegationTokenRequest.newInstance("renewer1");
        UserGroupInformation.getCurrentUser().setAuthenticationMethod(AuthMethod.KERBEROS);
        GetDelegationTokenResponse FMNRMLHICW = FFTEOETNBV.getClientRMService().getDelegationToken(HTRGUZWEAQ);
        Token<RMDelegationTokenIdentifier> VYNVQLAUYR = ConverterUtils.convertFromYarn(FMNRMLHICW.getRMDelegationToken(), TestRMRestart.JYDWNVRJVO);
        // start new RM
        MockRM UHVQCXGHLF = new TestRMRestart.TestSecurityMockRM(NGGDLBOOKG, VPKOIMLSHH);
        UHVQCXGHLF.start();
        // submit an app with the old delegation token got from previous RM.
        Credentials JXEWUSFZIP = new Credentials();
        JXEWUSFZIP.addToken(VYNVQLAUYR.getService(), VYNVQLAUYR);
        RMApp VATXQXECQQ = UHVQCXGHLF.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", 1, JXEWUSFZIP);
        UHVQCXGHLF.waitForState(VATXQXECQQ.getApplicationId(), ACCEPTED);
    }

    @Test(timeout = 60000)
    public void testRMStateStoreDispatcherDrainedOnRMStop() throws Exception {
        MemoryRMStateStore BWHMHWCMTJ = new MemoryRMStateStore() {
            volatile boolean TFAZOSGODQ = true;

            @Override
            public void serviceStop() throws Exception {
                // Unblock app saving request.
                TFAZOSGODQ = false;
                super.serviceStop();
            }

            @Override
            protected void handleStoreEvent(RMStateStoreEvent HBIFVPIMGD) {
                // Block app saving request.
                while (TFAZOSGODQ);
                super.handleStoreEvent(HBIFVPIMGD);
            }
        };
        BWHMHWCMTJ.init(NGGDLBOOKG);
        // start RM
        final MockRM TQFUUTXAHX = new MockRM(NGGDLBOOKG, BWHMHWCMTJ);
        TQFUUTXAHX.start();
        // create apps.
        final ArrayList<RMApp> KPFYIACGAC = new ArrayList<RMApp>();
        final int WIKQFEUWYB = 5;
        for (int OVMKBVNEUI = 0; OVMKBVNEUI < WIKQFEUWYB; OVMKBVNEUI++) {
            RMApp VAMBINXHXQ = TQFUUTXAHX.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", -1, null, "MAPREDUCE", false);
            KPFYIACGAC.add(VAMBINXHXQ);
            TQFUUTXAHX.waitForState(VAMBINXHXQ.getApplicationId(), NEW_SAVING);
        }
        // all apps's saving request are now enqueued to RMStateStore's dispatcher
        // queue, and will be processed once rm.stop() is called.
        // Nothing exist in state store before stop is called.
        Map<ApplicationId, ApplicationState> ICPKYTEJGP = BWHMHWCMTJ.getState().getApplicationState();
        Assert.assertTrue(ICPKYTEJGP.size() == 0);
        // stop rm
        TQFUUTXAHX.stop();
        // Assert app info is still saved even if stop is called with pending saving
        // request on dispatcher.
        for (RMApp GXPDTOHKQO : KPFYIACGAC) {
            ApplicationState IUDUMYZNQB = ICPKYTEJGP.get(GXPDTOHKQO.getApplicationId());
            Assert.assertNotNull(IUDUMYZNQB);
            Assert.assertEquals(0, IUDUMYZNQB.getAttemptCount());
            Assert.assertEquals(IUDUMYZNQB.getApplicationSubmissionContext().getApplicationId(), GXPDTOHKQO.getApplicationSubmissionContext().getApplicationId());
        }
        Assert.assertTrue(ICPKYTEJGP.size() == WIKQFEUWYB);
    }

    @Test(timeout = 60000)
    public void testFinishedAppRemovalAfterRMRestart() throws Exception {
        MemoryRMStateStore XBFMWTMNFQ = new MemoryRMStateStore();
        NGGDLBOOKG.setInt(RM_MAX_COMPLETED_APPLICATIONS, 1);
        XBFMWTMNFQ.init(NGGDLBOOKG);
        RMState LRSETMTPWW = XBFMWTMNFQ.getState();
        // start RM
        MockRM DNNUUMFKYY = new MockRM(NGGDLBOOKG, XBFMWTMNFQ);
        DNNUUMFKYY.start();
        MockNM JUTXLOEPND = new MockNM("127.0.0.1:1234", 15120, DNNUUMFKYY.getResourceTrackerService());
        JUTXLOEPND.registerNode();
        // create an app and finish the app.
        RMApp FVMWHYFSSF = DNNUUMFKYY.submitApp(200);
        MockAM HWRUSCKZCX = launchAM(FVMWHYFSSF, DNNUUMFKYY, JUTXLOEPND);
        finishApplicationMaster(FVMWHYFSSF, DNNUUMFKYY, JUTXLOEPND, HWRUSCKZCX);
        MockRM TNRVRNKQIY = new MockRM(NGGDLBOOKG, XBFMWTMNFQ);
        TNRVRNKQIY.start();
        JUTXLOEPND.setResourceTrackerService(TNRVRNKQIY.getResourceTrackerService());
        JUTXLOEPND = TNRVRNKQIY.registerNode("127.0.0.1:1234", 15120);
        Map<ApplicationId, ApplicationState> ZAHEWZFQTI = LRSETMTPWW.getApplicationState();
        // app0 exits in both state store and rmContext
        Assert.assertEquals(FINISHED, ZAHEWZFQTI.get(FVMWHYFSSF.getApplicationId()).getState());
        TNRVRNKQIY.waitForState(FVMWHYFSSF.getApplicationId(), FINISHED);
        // create one more app and finish the app.
        RMApp UZGHUPUYHH = TNRVRNKQIY.submitApp(200);
        MockAM LPREGXROSB = launchAM(UZGHUPUYHH, TNRVRNKQIY, JUTXLOEPND);
        finishApplicationMaster(UZGHUPUYHH, TNRVRNKQIY, JUTXLOEPND, LPREGXROSB);
        // the first app0 get kicked out from both rmContext and state store
        Assert.assertNull(TNRVRNKQIY.getRMContext().getRMApps().get(FVMWHYFSSF.getApplicationId()));
        Assert.assertNull(ZAHEWZFQTI.get(FVMWHYFSSF.getApplicationId()));
        DNNUUMFKYY.stop();
        TNRVRNKQIY.stop();
    }

    // This is to test RM does not get hang on shutdown.
    @Test(timeout = 10000)
    public void testRMShutdown() throws Exception {
        MemoryRMStateStore HYHJRRFLCM = new MemoryRMStateStore() {
            @Override
            public synchronized void checkVersion() throws Exception {
                throw new Exception("Invalid version.");
            }
        };
        // start RM
        HYHJRRFLCM.init(NGGDLBOOKG);
        MockRM GZNGUYIZIH = null;
        try {
            GZNGUYIZIH = new MockRM(NGGDLBOOKG, HYHJRRFLCM);
            GZNGUYIZIH.start();
            Assert.fail();
        } catch (Exception e) {
            Assert.assertTrue(e.getMessage().contains("Invalid version."));
        }
        Assert.assertTrue(GZNGUYIZIH.getServiceState() == STATE.STOPPED);
    }

    // This is to test Killing application should be able to wait until app
    // reaches killed state and also check that attempt state is saved before app
    // state is saved.
    @Test(timeout = 60000)
    public void testClientRetryOnKillingApplication() throws Exception {
        MemoryRMStateStore DHVGXGVVPO = new TestRMRestart.TestMemoryRMStateStore();
        DHVGXGVVPO.init(NGGDLBOOKG);
        // start RM
        MockRM GKPLJNMXNH = new MockRM(NGGDLBOOKG, DHVGXGVVPO);
        GKPLJNMXNH.start();
        MockNM LNMAEZONLO = new MockNM("127.0.0.1:1234", 15120, GKPLJNMXNH.getResourceTrackerService());
        LNMAEZONLO.registerNode();
        RMApp VFGSZJVJUY = GKPLJNMXNH.submitApp(200, "name", "user", null, false, "default", 1, null, "myType");
        MockAM JUVMRCRBTQ = launchAM(VFGSZJVJUY, GKPLJNMXNH, LNMAEZONLO);
        KillApplicationResponse TNYFJDNHUI;
        int RMKENHIWGL = 0;
        while (true) {
            TNYFJDNHUI = GKPLJNMXNH.killApp(VFGSZJVJUY.getApplicationId());
            if (TNYFJDNHUI.getIsKillCompleted()) {
                break;
            }
            Thread.sleep(100);
            RMKENHIWGL++;
        } 
        // we expect at least 2 calls for killApp as the first killApp always return
        // false.
        Assert.assertTrue(RMKENHIWGL >= 1);
        GKPLJNMXNH.waitForState(JUVMRCRBTQ.getApplicationAttemptId(), RMAppAttemptState.KILLED);
        GKPLJNMXNH.waitForState(VFGSZJVJUY.getApplicationId(), KILLED);
        Assert.assertEquals(1, ((TestRMRestart.TestMemoryRMStateStore) (DHVGXGVVPO)).RDRUTCEISR);
        Assert.assertEquals(2, ((TestRMRestart.TestMemoryRMStateStore) (DHVGXGVVPO)).QCQKBROIKO);
    }

    @SuppressWarnings("resource")
    @Test(timeout = 60000)
    public void testQueueMetricsOnRMRestart() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, DEFAULT_RM_AM_MAX_ATTEMPTS);
        MemoryRMStateStore YEZSCNZKOT = new MemoryRMStateStore();
        YEZSCNZKOT.init(NGGDLBOOKG);
        // PHASE 1: create state in an RM
        // start RM
        MockRM YISXPTPMKY = new MockRM(NGGDLBOOKG, YEZSCNZKOT);
        YISXPTPMKY.start();
        MockNM CWEYASHZVZ = new MockNM("127.0.0.1:1234", 15120, YISXPTPMKY.getResourceTrackerService());
        CWEYASHZVZ.registerNode();
        QueueMetrics EUKYLKHNRC = YISXPTPMKY.getResourceScheduler().getRootQueueMetrics();
        resetQueueMetrics(EUKYLKHNRC);
        assertQueueMetrics(EUKYLKHNRC, 0, 0, 0, 0);
        // create app that gets launched and does allocate before RM restart
        RMApp NDSBGRZCGG = YISXPTPMKY.submitApp(200);
        // Need to wait first for AppAttempt to be started (RMAppState.ACCEPTED)
        // and then for it to reach RMAppAttemptState.SCHEDULED
        // inorder to ensure appsPending metric is incremented
        YISXPTPMKY.waitForState(NDSBGRZCGG.getApplicationId(), ACCEPTED);
        RMAppAttempt SAKJJHHMRS = NDSBGRZCGG.getCurrentAppAttempt();
        ApplicationAttemptId UZHWVKHMVO = SAKJJHHMRS.getAppAttemptId();
        YISXPTPMKY.waitForState(UZHWVKHMVO, SCHEDULED);
        assertQueueMetrics(EUKYLKHNRC, 1, 1, 0, 0);
        CWEYASHZVZ.nodeHeartbeat(true);
        YISXPTPMKY.waitForState(UZHWVKHMVO, ALLOCATED);
        MockAM DFZGHXXSJF = YISXPTPMKY.sendAMLaunched(SAKJJHHMRS.getAppAttemptId());
        DFZGHXXSJF.registerAppAttempt();
        DFZGHXXSJF.allocate("127.0.0.1", 1000, 1, new ArrayList<ContainerId>());
        CWEYASHZVZ.nodeHeartbeat(true);
        List<Container> TODGXQSMOW = DFZGHXXSJF.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers();
        while (TODGXQSMOW.size() == 0) {
            CWEYASHZVZ.nodeHeartbeat(true);
            TODGXQSMOW.addAll(DFZGHXXSJF.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers());
            Thread.sleep(500);
        } 
        assertQueueMetrics(EUKYLKHNRC, 1, 0, 1, 0);
        // PHASE 2: create new RM and start from old state
        // create new RM to represent restart and recover state
        MockRM UERCIDZYHI = new MockRM(NGGDLBOOKG, YEZSCNZKOT);
        QueueMetrics LYUSCAKCBL = UERCIDZYHI.getResourceScheduler().getRootQueueMetrics();
        resetQueueMetrics(LYUSCAKCBL);
        assertQueueMetrics(LYUSCAKCBL, 0, 0, 0, 0);
        UERCIDZYHI.start();
        CWEYASHZVZ.setResourceTrackerService(UERCIDZYHI.getResourceTrackerService());
        // recover app
        RMApp GTKTZOEEXS = UERCIDZYHI.getRMContext().getRMApps().get(NDSBGRZCGG.getApplicationId());
        DFZGHXXSJF.setAMRMProtocol(UERCIDZYHI.getApplicationMasterService(), UERCIDZYHI.getRMContext());
        DFZGHXXSJF.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>());
        CWEYASHZVZ.nodeHeartbeat(true);
        CWEYASHZVZ = new MockNM("127.0.0.1:1234", 15120, UERCIDZYHI.getResourceTrackerService());
        NMContainerStatus OBDTJMKHAC = TestRMRestart.createNMContainerStatus(GTKTZOEEXS.getCurrentAppAttempt().getAppAttemptId(), 1, COMPLETE);
        CWEYASHZVZ.registerNode(Arrays.asList(OBDTJMKHAC), null);
        while (GTKTZOEEXS.getAppAttempts().size() != 2) {
            Thread.sleep(200);
        } 
        SAKJJHHMRS = GTKTZOEEXS.getCurrentAppAttempt();
        UZHWVKHMVO = SAKJJHHMRS.getAppAttemptId();
        UERCIDZYHI.waitForState(UZHWVKHMVO, SCHEDULED);
        assertQueueMetrics(LYUSCAKCBL, 1, 1, 0, 0);
        CWEYASHZVZ.nodeHeartbeat(true);
        UERCIDZYHI.waitForState(UZHWVKHMVO, ALLOCATED);
        assertQueueMetrics(LYUSCAKCBL, 1, 0, 1, 0);
        DFZGHXXSJF = UERCIDZYHI.sendAMLaunched(SAKJJHHMRS.getAppAttemptId());
        DFZGHXXSJF.registerAppAttempt();
        DFZGHXXSJF.allocate("127.0.0.1", 1000, 3, new ArrayList<ContainerId>());
        CWEYASHZVZ.nodeHeartbeat(true);
        TODGXQSMOW = DFZGHXXSJF.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers();
        while (TODGXQSMOW.size() == 0) {
            CWEYASHZVZ.nodeHeartbeat(true);
            TODGXQSMOW.addAll(DFZGHXXSJF.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers());
            Thread.sleep(500);
        } 
        // finish the AMs
        finishApplicationMaster(GTKTZOEEXS, UERCIDZYHI, CWEYASHZVZ, DFZGHXXSJF);
        assertQueueMetrics(LYUSCAKCBL, 1, 0, 0, 1);
        // stop RM's
        UERCIDZYHI.stop();
        YISXPTPMKY.stop();
    }

    // The metrics has some carry-on value from the previous RM, because the
    // test case is in-memory, for the same queue name (e.g. root), there's
    // always a singleton QueueMetrics object.
    private int FPOWYNBLGE = 0;

    private int RDMONKSJHL = 0;

    private int DNEDLDZRBA = 0;

    private int ANCBAMENRM = 0;

    private void resetQueueMetrics(QueueMetrics ZGHTOYQMIB) {
        FPOWYNBLGE = ZGHTOYQMIB.getAppsSubmitted();
        RDMONKSJHL = ZGHTOYQMIB.getAppsPending();
        DNEDLDZRBA = ZGHTOYQMIB.getAppsRunning();
        ANCBAMENRM = ZGHTOYQMIB.getAppsCompleted();
    }

    private void assertQueueMetrics(QueueMetrics UWRYUBFGYB, int TFXLOXPZAK, int UEWCCCFSYC, int TRVZKKKCVO, int NALDDRSUIH) {
        Assert.assertEquals(UWRYUBFGYB.getAppsSubmitted(), TFXLOXPZAK + FPOWYNBLGE);
        Assert.assertEquals(UWRYUBFGYB.getAppsPending(), UEWCCCFSYC + RDMONKSJHL);
        Assert.assertEquals(UWRYUBFGYB.getAppsRunning(), TRVZKKKCVO + DNEDLDZRBA);
        Assert.assertEquals(UWRYUBFGYB.getAppsCompleted(), NALDDRSUIH + ANCBAMENRM);
    }

    @Test(timeout = 60000)
    public void testDecomissionedNMsMetricsOnRMRestart() throws Exception {
        YarnConfiguration NNEGGYGSTT = new YarnConfiguration();
        NNEGGYGSTT.set(RM_NODES_EXCLUDE_FILE_PATH, PXXVTEATFT.getAbsolutePath());
        writeToHostsFile("");
        MockRM MHEKYJNSPI = new MockRM(NNEGGYGSTT);
        MHEKYJNSPI.start();
        MHEKYJNSPI.registerNode("localhost:1234", 8000);
        MHEKYJNSPI.registerNode("host2:1234", 8000);
        Assert.assertEquals(0, ClusterMetrics.getMetrics().getNumDecommisionedNMs());
        String BFGIDHANYS = NetUtils.normalizeHostName("localhost");
        // Add 2 hosts to exclude list.
        writeToHostsFile("host2", BFGIDHANYS);
        // refresh nodes
        MHEKYJNSPI.getNodesListManager().refreshNodes(NNEGGYGSTT);
        Assert.assertEquals(2, ClusterMetrics.getMetrics().getNumDecommisionedNMs());
        // restart RM.
        MockRM SHUWUSHAIB = new MockRM(NNEGGYGSTT);
        SHUWUSHAIB.start();
        Assert.assertEquals(2, ClusterMetrics.getMetrics().getNumDecommisionedNMs());
        MHEKYJNSPI.stop();
        SHUWUSHAIB.stop();
    }

    // Test Delegation token is renewed synchronously so that recover events
    // can be processed before any other external incoming events, specifically
    // the ContainerFinished event on NM re-registraton.
    @Test(timeout = 20000)
    public void testSynchronouslyRenewDTOnRecovery() throws Exception {
        NGGDLBOOKG.setInt(RM_AM_MAX_ATTEMPTS, 2);
        NGGDLBOOKG.set(HADOOP_SECURITY_AUTHENTICATION, "kerberos");
        MemoryRMStateStore GLPNCCADPS = new MemoryRMStateStore();
        GLPNCCADPS.init(NGGDLBOOKG);
        // start RM
        MockRM ACFMDRJDDU = new MockRM(NGGDLBOOKG, GLPNCCADPS);
        ACFMDRJDDU.start();
        final MockNM NUEJWWKOOS = new MockNM("127.0.0.1:1234", 15120, ACFMDRJDDU.getResourceTrackerService());
        NUEJWWKOOS.registerNode();
        RMApp FINHBWIYVI = ACFMDRJDDU.submitApp(200);
        final MockAM IQYXMKFQWU = MockRM.launchAndRegisterAM(FINHBWIYVI, ACFMDRJDDU, NUEJWWKOOS);
        MockRM JQFPRZMNSC = new MockRM(NGGDLBOOKG, GLPNCCADPS) {
            @Override
            protected ResourceTrackerService createResourceTrackerService() {
                return new ResourceTrackerService(this.rmContext, this.nodesListManager, this.nmLivelinessMonitor, this.rmContext.getContainerTokenSecretManager(), this.rmContext.getNMTokenSecretManager()) {
                    @Override
                    protected void serviceStart() throws Exception {
                        // send the container_finished event as soon as the
                        // ResourceTrackerService is started.
                        super.serviceStart();
                        NUEJWWKOOS.setResourceTrackerService(getResourceTrackerService());
                        NMContainerStatus WDARYMAION = TestRMRestart.createNMContainerStatus(IQYXMKFQWU.getApplicationAttemptId(), 1, COMPLETE);
                        NUEJWWKOOS.registerNode(Arrays.asList(WDARYMAION), null);
                    }
                };
            }
        };
        // Re-start RM
        JQFPRZMNSC.start();
        // wait for the 2nd attempt to be started.
        RMApp NAQGFYTSDX = JQFPRZMNSC.getRMContext().getRMApps().get(FINHBWIYVI.getApplicationId());
        int LXYGIBVKLP = 0;
        while ((NAQGFYTSDX.getAppAttempts().size() != 2) && ((LXYGIBVKLP++) < 40)) {
            Thread.sleep(200);
        } 
        MockAM KRWLAPTVLO = MockRM.launchAndRegisterAM(NAQGFYTSDX, JQFPRZMNSC, NUEJWWKOOS);
        MockRM.finishAMAndVerifyAppState(NAQGFYTSDX, JQFPRZMNSC, NUEJWWKOOS, KRWLAPTVLO);
    }

    private void writeToHostsFile(String... ZKKFOERNEB) throws IOException {
        if (!PXXVTEATFT.exists()) {
            TestRMRestart.BRZHGXZEJD.mkdirs();
            PXXVTEATFT.createNewFile();
        }
        FileOutputStream MRZEOFMIWM = null;
        try {
            MRZEOFMIWM = new FileOutputStream(PXXVTEATFT);
            for (int HZKAXCWURO = 0; HZKAXCWURO < ZKKFOERNEB.length; HZKAXCWURO++) {
                MRZEOFMIWM.write(ZKKFOERNEB[HZKAXCWURO].getBytes());
                MRZEOFMIWM.write(System.getProperty("line.separator").getBytes());
            }
        } finally {
            if (MRZEOFMIWM != null) {
                IOUtils.closeStream(MRZEOFMIWM);
                MRZEOFMIWM = null;
            }
        }
    }

    public static NMContainerStatus createNMContainerStatus(ApplicationAttemptId RKPRPCPHJS, int UZAAGXEQUK, ContainerState USRQOSRDVB) {
        ContainerId GMRTZIOMHW = ContainerId.newInstance(RKPRPCPHJS, UZAAGXEQUK);
        NMContainerStatus MAIWLTLVDW = NMContainerStatus.newInstance(GMRTZIOMHW, USRQOSRDVB, Resource.newInstance(1024, 1), "recover container", 0, Priority.newInstance(0), 0);
        return MAIWLTLVDW;
    }

    public class TestMemoryRMStateStore extends MemoryRMStateStore {
        int PTDFLUDBEQ = 0;

        public int QCQKBROIKO = 0;

        public int RDRUTCEISR = 0;

        @Override
        public void updateApplicationStateInternal(ApplicationId appId, ApplicationStateData appStateData) throws Exception {
            QCQKBROIKO = ++PTDFLUDBEQ;
            super.updateApplicationStateInternal(appId, appStateData);
        }

        @Override
        public synchronized void updateApplicationAttemptStateInternal(ApplicationAttemptId attemptId, ApplicationAttemptStateData attemptStateData) throws Exception {
            RDRUTCEISR = ++PTDFLUDBEQ;
            super.updateApplicationAttemptStateInternal(attemptId, attemptStateData);
        }
    }

    public static class TestSecurityMockRM extends MockRM {
        public TestSecurityMockRM(Configuration conf, RMStateStore store) {
            super(conf, store);
        }

        @Override
        public void init(Configuration conf) {
            // reset localServiceAddress.
            Renewer.setSecretManager(null, null);
            super.init(conf);
        }

        @Override
        protected ClientRMService createClientRMService() {
            return new ClientRMService(getRMContext(), getResourceScheduler(), rmAppManager, applicationACLsManager, null, getRMContext().getRMDelegationTokenSecretManager()) {
                @Override
                protected void serviceStart() throws Exception {
                    // do nothing
                }

                @Override
                protected void serviceStop() throws Exception {
                    // do nothing
                }
            };
        }

        @Override
        protected void doSecureLogin() throws IOException {
            // Do nothing.
        }
    }
}