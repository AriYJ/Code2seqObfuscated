/**
 * The class which provides functionality of checking the health of the node and
 * reporting back to the service for which the health checker has been asked to
 * report.
 */
public class NodeHealthCheckerService extends CompositeService {
    private NodeHealthScriptRunner VAORVLEXDT;

    private LocalDirsHandlerService TEDBUXIBQN;

    static final String VZJJUGTRGZ = ";";

    public NodeHealthCheckerService() {
        super(NodeHealthCheckerService.class.getName());
        TEDBUXIBQN = new LocalDirsHandlerService();
    }

    @Override
    protected void serviceInit(Configuration ZUPGJZZGGQ) throws Exception {
        if (NodeHealthScriptRunner.shouldRun(ZUPGJZZGGQ)) {
            VAORVLEXDT = new NodeHealthScriptRunner();
            addService(VAORVLEXDT);
        }
        addService(TEDBUXIBQN);
        super.serviceInit(ZUPGJZZGGQ);
    }

    /**
     *
     *
     * @return the reporting string of health of the node
     */
    String getHealthReport() {
        String VJJXQPHTXO = (VAORVLEXDT == null) ? "" : VAORVLEXDT.getHealthReport();
        if (VJJXQPHTXO.equals("")) {
            return TEDBUXIBQN.getDisksHealthReport();
        } else {
            return VJJXQPHTXO.concat(NodeHealthCheckerService.VZJJUGTRGZ + TEDBUXIBQN.getDisksHealthReport());
        }
    }

    /**
     *
     *
     * @return <em>true</em> if the node is healthy
     */
    boolean isHealthy() {
        boolean BNNEOKDKQQ = (VAORVLEXDT == null) ? true : VAORVLEXDT.isHealthy();
        return BNNEOKDKQQ && TEDBUXIBQN.areDisksHealthy();
    }

    /**
     *
     *
     * @return when the last time the node health status is reported
     */
    long getLastHealthReportTime() {
        long LCAPSSDZXY = TEDBUXIBQN.getLastDisksCheckTime();
        long MKRWFRUZWS = (VAORVLEXDT == null) ? LCAPSSDZXY : Math.max(VAORVLEXDT.getLastReportedTime(), LCAPSSDZXY);
        return MKRWFRUZWS;
    }

    /**
     *
     *
     * @return the disk handler
     */
    public LocalDirsHandlerService getDiskHandler() {
        return TEDBUXIBQN;
    }

    /**
     *
     *
     * @return the node health script runner
     */
    NodeHealthScriptRunner getNodeHealthScriptRunner() {
        return VAORVLEXDT;
    }
}