public class TestBestEffortLongFile {
    private static final File IGIPDSHSHH = new File((MiniDFSCluster.getBaseDirectory() + File.separatorChar) + "TestBestEffortLongFile");

    @Before
    public void cleanup() {
        if (TestBestEffortLongFile.IGIPDSHSHH.exists()) {
            assertTrue(TestBestEffortLongFile.IGIPDSHSHH.delete());
        }
        TestBestEffortLongFile.IGIPDSHSHH.getParentFile().mkdirs();
    }

    @Test
    public void testGetSet() throws IOException {
        BestEffortLongFile GTWMBUJJHJ = new BestEffortLongFile(TestBestEffortLongFile.IGIPDSHSHH, 12345L);
        try {
            // Before the file exists, should return default.
            assertEquals(12345L, GTWMBUJJHJ.get());
            // And first access should open it.
            assertTrue(TestBestEffortLongFile.IGIPDSHSHH.exists());
            Random GLLRGBPJBV = new Random();
            for (int VUGBWGXLRU = 0; VUGBWGXLRU < 100; VUGBWGXLRU++) {
                long CONKBLNLBP = GLLRGBPJBV.nextLong();
                // Changing the value should be reflected in the next get() call.
                GTWMBUJJHJ.set(CONKBLNLBP);
                assertEquals(CONKBLNLBP, GTWMBUJJHJ.get());
                // And should be reflected in a new instance (ie it actually got
                // written to the file)
                BestEffortLongFile POTKPVHPXU = new BestEffortLongFile(TestBestEffortLongFile.IGIPDSHSHH, 999L);
                try {
                    assertEquals(CONKBLNLBP, POTKPVHPXU.get());
                } finally {
                    IOUtils.closeStream(POTKPVHPXU);
                }
            }
        } finally {
            IOUtils.closeStream(GTWMBUJJHJ);
        }
    }

    @Test
    public void testTruncatedFileReturnsDefault() throws IOException {
        assertTrue(TestBestEffortLongFile.IGIPDSHSHH.createNewFile());
        assertEquals(0, TestBestEffortLongFile.IGIPDSHSHH.length());
        BestEffortLongFile XJPVAUCBMR = new BestEffortLongFile(TestBestEffortLongFile.IGIPDSHSHH, 12345L);
        try {
            assertEquals(12345L, XJPVAUCBMR.get());
        } finally {
            XJPVAUCBMR.close();
        }
    }
}