/**
 * <p>The response sent by the <code>ResourceManager</code> to a client
 * requesting cluster metrics.<p>
 *
 * @see YarnClusterMetrics
 * @see ApplicationClientProtocol#getClusterMetrics(GetClusterMetricsRequest)
 */
@Public
@Stable
public abstract class GetClusterMetricsResponse {
    @Private
    @Unstable
    public static GetClusterMetricsResponse newInstance(YarnClusterMetrics XZADNPZRHO) {
        GetClusterMetricsResponse UKQJMYAJQI = Records.newRecord(GetClusterMetricsResponse.class);
        UKQJMYAJQI.setClusterMetrics(XZADNPZRHO);
        return UKQJMYAJQI;
    }

    /**
     * Get the <code>YarnClusterMetrics</code> for the cluster.
     *
     * @return <code>YarnClusterMetrics</code> for the cluster
     */
    @Public
    @Stable
    public abstract YarnClusterMetrics getClusterMetrics();

    @Private
    @Unstable
    public abstract void setClusterMetrics(YarnClusterMetrics IXXYUTCYBJ);
}