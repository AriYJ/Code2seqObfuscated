public class WebAppProxy extends AbstractService {
    public static final String CXZNMSUABO = "AppUrlFetcher";

    public static final String BHVKQPWFNN = "IsSecurityEnabled";

    public static final String EVUJLGQYSW = "proxyHost";

    private static final Log LDINLUTPUE = LogFactory.getLog(WebAppProxy.class);

    private HttpServer2 NSZOREECUN = null;

    private String GZZYIKADVL = null;

    private int KZNLTVLLPF = 0;

    private AccessControlList AERFWARBRC = null;

    private AppReportFetcher SFZRSEJRYL = null;

    private boolean BHZVFIWLMB = false;

    private String PTQKKHFVSN = null;

    public WebAppProxy() {
        super(WebAppProxy.class.getName());
    }

    @Override
    protected void serviceInit(Configuration JWRBPJDKRQ) throws Exception {
        String HBODSRPKHV = JWRBPJDKRQ.get(HADOOP_SECURITY_AUTHENTICATION);
        if ((HBODSRPKHV == null) || "simple".equals(HBODSRPKHV)) {
            BHZVFIWLMB = false;
        } else
            if ("kerberos".equals(HBODSRPKHV)) {
                BHZVFIWLMB = true;
            } else {
                WebAppProxy.LDINLUTPUE.warn((("Unrecongized attribute value for " + CommonConfigurationKeys.HADOOP_SECURITY_AUTHENTICATION) + " of ") + HBODSRPKHV);
            }

        String RNSAZAMJGV = WebAppUtils.getProxyHostAndPort(JWRBPJDKRQ);
        String[] AZLHHDGHZL = RNSAZAMJGV.split(":");
        PTQKKHFVSN = AZLHHDGHZL[0];
        SFZRSEJRYL = new AppReportFetcher(JWRBPJDKRQ);
        GZZYIKADVL = JWRBPJDKRQ.get(PROXY_ADDRESS);
        if ((GZZYIKADVL == null) || GZZYIKADVL.isEmpty()) {
            throw new YarnRuntimeException(YarnConfiguration.PROXY_ADDRESS + " is not set so the proxy will not run.");
        }
        WebAppProxy.LDINLUTPUE.info("Instantiating Proxy at " + GZZYIKADVL);
        String[] YBGGLJTKAD = StringUtils.split(GZZYIKADVL, ':');
        KZNLTVLLPF = 0;
        if (YBGGLJTKAD.length == 2) {
            GZZYIKADVL = YBGGLJTKAD[0];
            KZNLTVLLPF = Integer.parseInt(YBGGLJTKAD[1]);
        }
        AERFWARBRC = new AccessControlList(JWRBPJDKRQ.get(YARN_ADMIN_ACL, DEFAULT_YARN_ADMIN_ACL));
        super.serviceInit(JWRBPJDKRQ);
    }

    @Override
    protected void serviceStart() throws Exception {
        try {
            Configuration MVJIMKSTOH = getConfig();
            HttpServer2.Builder FAHADRFGPU = new HttpServer2.Builder().setName("proxy").addEndpoint(java.net.URI.create(((WebAppUtils.getHttpSchemePrefix(MVJIMKSTOH) + GZZYIKADVL) + ":") + KZNLTVLLPF)).setFindPort(KZNLTVLLPF == 0).setConf(getConfig()).setACL(AERFWARBRC);
            if (YarnConfiguration.useHttps(MVJIMKSTOH)) {
                WebAppUtils.loadSslConfiguration(FAHADRFGPU);
            }
            NSZOREECUN = FAHADRFGPU.build();
            NSZOREECUN.addServlet(PROXY_SERVLET_NAME, PROXY_PATH_SPEC, WebAppProxyServlet.class);
            NSZOREECUN.setAttribute(WebAppProxy.CXZNMSUABO, SFZRSEJRYL);
            NSZOREECUN.setAttribute(WebAppProxy.BHVKQPWFNN, BHZVFIWLMB);
            NSZOREECUN.setAttribute(WebAppProxy.EVUJLGQYSW, PTQKKHFVSN);
            NSZOREECUN.start();
        } catch (IOException e) {
            WebAppProxy.LDINLUTPUE.fatal("Could not start proxy web server", e);
            throw new YarnRuntimeException("Could not start proxy web server", e);
        }
        super.serviceStart();
    }

    @Override
    protected void serviceStop() throws Exception {
        if (NSZOREECUN != null) {
            try {
                NSZOREECUN.stop();
            } catch (Exception e) {
                WebAppProxy.LDINLUTPUE.fatal("Error stopping proxy web server", e);
                throw new YarnRuntimeException("Error stopping proxy web server", e);
            }
        }
        if (this.SFZRSEJRYL != null) {
            this.SFZRSEJRYL.stop();
        }
        super.serviceStop();
    }

    public void join() {
        if (NSZOREECUN != null) {
            try {
                NSZOREECUN.join();
            } catch (InterruptedException e) {
            }
        }
    }

    @VisibleForTesting
    String getBindAddress() {
        return (GZZYIKADVL + ":") + KZNLTVLLPF;
    }
}