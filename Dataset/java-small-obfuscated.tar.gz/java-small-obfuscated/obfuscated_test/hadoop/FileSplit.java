/**
 * A section of an input file.  Returned by {@link InputFormat#getSplits(JobContext)} and passed to
 * {@link InputFormat#createRecordReader(InputSplit,TaskAttemptContext)}.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class FileSplit extends InputSplit implements Writable {
    private Path BDXSQCEGTI;

    private long PLJCWVXAIZ;

    private long DMJMRLLMPP;

    private String[] MFLYAANHTB;

    private SplitLocationInfo[] DHYWZYFHAD;

    public FileSplit() {
    }

    /**
     * Constructs a split with host information
     *
     * @param file
     * 		the file name
     * @param start
     * 		the position of the first byte in the file to process
     * @param length
     * 		the number of bytes in the file to process
     * @param hosts
     * 		the list of hosts containing the block, possibly null
     */
    public FileSplit(Path FBUDXYDMAP, long FRPZNBBZMK, long ZMCUGYYZPM, String[] XPSQUUWJAI) {
        this.BDXSQCEGTI = FBUDXYDMAP;
        this.PLJCWVXAIZ = FRPZNBBZMK;
        this.DMJMRLLMPP = ZMCUGYYZPM;
        this.MFLYAANHTB = XPSQUUWJAI;
    }

    /**
     * Constructs a split with host and cached-blocks information
     *
     * @param file
     * 		the file name
     * @param start
     * 		the position of the first byte in the file to process
     * @param length
     * 		the number of bytes in the file to process
     * @param hosts
     * 		the list of hosts containing the block
     * @param inMemoryHosts
     * 		the list of hosts containing the block in memory
     */
    public FileSplit(Path UDMYMHCXOT, long OLKGRVVCNY, long AOSQRUPOGT, String[] LKKLTTTNQX, String[] SOSFBVMECX) {
        this(UDMYMHCXOT, OLKGRVVCNY, AOSQRUPOGT, LKKLTTTNQX);
        DHYWZYFHAD = new SplitLocationInfo[LKKLTTTNQX.length];
        for (int BKKJRLSUES = 0; BKKJRLSUES < LKKLTTTNQX.length; BKKJRLSUES++) {
            // because N will be tiny, scanning is probably faster than a HashSet
            boolean BOFOURRGNW = false;
            for (String ILTBBUVOXP : SOSFBVMECX) {
                if (ILTBBUVOXP.equals(LKKLTTTNQX[BKKJRLSUES])) {
                    BOFOURRGNW = true;
                    break;
                }
            }
            DHYWZYFHAD[BKKJRLSUES] = new SplitLocationInfo(LKKLTTTNQX[BKKJRLSUES], BOFOURRGNW);
        }
    }

    /**
     * The file containing this split's data.
     */
    public Path getPath() {
        return BDXSQCEGTI;
    }

    /**
     * The position of the first byte in the file to process.
     */
    public long getStart() {
        return PLJCWVXAIZ;
    }

    /**
     * The number of bytes in the file to process.
     */
    @Override
    public long getLength() {
        return DMJMRLLMPP;
    }

    @Override
    public String toString() {
        return (((BDXSQCEGTI + ":") + PLJCWVXAIZ) + "+") + DMJMRLLMPP;
    }

    // //////////////////////////////////////////
    // Writable methods
    // //////////////////////////////////////////
    @Override
    public void write(DataOutput RXCORPIYFF) throws IOException {
        Text.writeString(RXCORPIYFF, BDXSQCEGTI.toString());
        RXCORPIYFF.writeLong(PLJCWVXAIZ);
        RXCORPIYFF.writeLong(DMJMRLLMPP);
    }

    @Override
    public void readFields(DataInput JYFZYEXEYJ) throws IOException {
        BDXSQCEGTI = new Path(Text.readString(JYFZYEXEYJ));
        PLJCWVXAIZ = JYFZYEXEYJ.readLong();
        DMJMRLLMPP = JYFZYEXEYJ.readLong();
        MFLYAANHTB = null;
    }

    @Override
    public String[] getLocations() throws IOException {
        if (this.MFLYAANHTB == null) {
            return new String[]{  };
        } else {
            return this.MFLYAANHTB;
        }
    }

    @Override
    @Evolving
    public SplitLocationInfo[] getLocationInfo() throws IOException {
        return DHYWZYFHAD;
    }
}