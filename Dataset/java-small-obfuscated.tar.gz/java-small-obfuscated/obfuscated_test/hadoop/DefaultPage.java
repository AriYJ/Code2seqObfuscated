@InterfaceAudience.LimitedPrivate({ "YARN", "MapReduce" })
public class DefaultPage extends TextPage {
    static final Joiner IGLEYVMPGS = Joiner.on(", ");

    @Override
    public void render() {
        puts("Request URI: ", request().getRequestURI());
        puts("Query parameters:");
        @SuppressWarnings("unchecked")
        Map<String, String[]> DFRWGTUNGW = request().getParameterMap();
        for (Map.Entry<String, String[]> KUNUVYOAEB : DFRWGTUNGW.entrySet()) {
            puts("  ", KUNUVYOAEB.getKey(), "=", DefaultPage.IGLEYVMPGS.join(KUNUVYOAEB.getValue()));
        }
        puts("More parameters:");
        for (Map.Entry<String, String> KJEABISHMB : moreParams().entrySet()) {
            puts("  ", KJEABISHMB.getKey(), "=", KJEABISHMB.getValue());
        }
        puts("Path info: ", request().getPathInfo());
        puts("Path translated: ", request().getPathTranslated());
        puts("Auth type: ", request().getAuthType());
        puts("Remote address: " + request().getRemoteAddr());
        puts("Remote user: ", request().getRemoteUser());
        puts("Servlet attributes:");
        @SuppressWarnings("unchecked")
        Enumeration<String> DKLEDAPINQ = request().getAttributeNames();
        while (DKLEDAPINQ.hasMoreElements()) {
            String PVSCJMXWBV = DKLEDAPINQ.nextElement();
            puts("  ", PVSCJMXWBV, "=", request().getAttribute(PVSCJMXWBV));
        } 
        puts("Headers:");
        @SuppressWarnings("unchecked")
        Enumeration<String> TPXIBTVEEG = request().getHeaderNames();
        while (TPXIBTVEEG.hasMoreElements()) {
            String ZJCQNDZCEA = TPXIBTVEEG.nextElement();
            puts("  ", ZJCQNDZCEA, "=", request().getHeader(ZJCQNDZCEA));
        } 
    }
}