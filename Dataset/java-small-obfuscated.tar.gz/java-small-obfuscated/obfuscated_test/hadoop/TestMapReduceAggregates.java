public class TestMapReduceAggregates extends TestCase {
    private static NumberFormat ZYBNEKMCDG = NumberFormat.getInstance();

    static {
        TestMapReduceAggregates.ZYBNEKMCDG.setMinimumIntegerDigits(4);
        TestMapReduceAggregates.ZYBNEKMCDG.setGroupingUsed(false);
    }

    public void testAggregates() throws Exception {
        TestMapReduceAggregates.launch();
    }

    public static void launch() throws Exception {
        Configuration ZNFITGYMPF = new Configuration();
        FileSystem OHLOFRWCCK = FileSystem.get(ZNFITGYMPF);
        int UQXIUIQVUG = 20;
        Path KBVCABOYRK = new Path("build/test/output_for_aggregates_test");
        Path JQSGUXPCQB = new Path("build/test/input_for_aggregates_test");
        String PMKKMGDJWV = "input.txt";
        OHLOFRWCCK.delete(JQSGUXPCQB, true);
        OHLOFRWCCK.mkdirs(JQSGUXPCQB);
        OHLOFRWCCK.delete(KBVCABOYRK, true);
        StringBuffer JBUBZLKNJT = new StringBuffer();
        StringBuffer EENSAIBMYU = new StringBuffer();
        EENSAIBMYU.append("max\t19\n");
        EENSAIBMYU.append("min\t1\n");
        FSDataOutputStream MVRIEDXNXJ = OHLOFRWCCK.create(new Path(JQSGUXPCQB, PMKKMGDJWV));
        for (int HOTKDLLBSE = 1; HOTKDLLBSE < UQXIUIQVUG; HOTKDLLBSE++) {
            EENSAIBMYU.append("count_").append(TestMapReduceAggregates.ZYBNEKMCDG.format(HOTKDLLBSE));
            EENSAIBMYU.append("\t").append(HOTKDLLBSE).append("\n");
            JBUBZLKNJT.append(TestMapReduceAggregates.ZYBNEKMCDG.format(HOTKDLLBSE));
            for (int WSSJXBLESO = 1; WSSJXBLESO < HOTKDLLBSE; WSSJXBLESO++) {
                JBUBZLKNJT.append(" ").append(TestMapReduceAggregates.ZYBNEKMCDG.format(HOTKDLLBSE));
            }
            JBUBZLKNJT.append("\n");
        }
        EENSAIBMYU.append("value_as_string_max\t9\n");
        EENSAIBMYU.append("value_as_string_min\t1\n");
        EENSAIBMYU.append("uniq_count\t15\n");
        MVRIEDXNXJ.write(JBUBZLKNJT.toString().getBytes("utf-8"));
        MVRIEDXNXJ.close();
        System.out.println("inputData:");
        System.out.println(JBUBZLKNJT.toString());
        ZNFITGYMPF.setInt(DESCRIPTOR_NUM, 1);
        ZNFITGYMPF.set(ValueAggregatorJobBase.DESCRIPTOR + ".0", "UserDefined,org.apache.hadoop.mapreduce.lib.aggregate.AggregatorTests");
        ZNFITGYMPF.setLong(MAX_NUM_UNIQUE_VALUES, 14);
        Job EQXVXUEBWV = Job.getInstance(ZNFITGYMPF);
        FileInputFormat.setInputPaths(EQXVXUEBWV, JQSGUXPCQB);
        EQXVXUEBWV.setInputFormatClass(TextInputFormat.class);
        FileOutputFormat.setOutputPath(EQXVXUEBWV, KBVCABOYRK);
        EQXVXUEBWV.setOutputFormatClass(TextOutputFormat.class);
        EQXVXUEBWV.setMapOutputKeyClass(Text.class);
        EQXVXUEBWV.setMapOutputValueClass(Text.class);
        EQXVXUEBWV.setOutputKeyClass(Text.class);
        EQXVXUEBWV.setOutputValueClass(Text.class);
        EQXVXUEBWV.setNumReduceTasks(1);
        EQXVXUEBWV.setMapperClass(ValueAggregatorMapper.class);
        EQXVXUEBWV.setReducerClass(ValueAggregatorReducer.class);
        EQXVXUEBWV.setCombinerClass(ValueAggregatorCombiner.class);
        EQXVXUEBWV.waitForCompletion(true);
        assertTrue(EQXVXUEBWV.isSuccessful());
        // 
        // Finally, we compare the reconstructed answer key with the
        // original one.  Remember, we need to ignore zero-count items
        // in the original key.
        // 
        String GZQYWIYIKK = MapReduceTestUtil.readOutput(KBVCABOYRK, ZNFITGYMPF);
        System.out.println("full out data:");
        System.out.println(GZQYWIYIKK.toString());
        GZQYWIYIKK = GZQYWIYIKK.substring(0, EENSAIBMYU.toString().length());
        assertEquals(EENSAIBMYU.toString(), GZQYWIYIKK);
        OHLOFRWCCK.delete(KBVCABOYRK, true);
        OHLOFRWCCK.delete(JQSGUXPCQB, true);
    }

    /**
     * Launches all the tasks in order.
     */
    public static void main(String[] FTLOSJTYSU) throws Exception {
        TestMapReduceAggregates.launch();
    }
}