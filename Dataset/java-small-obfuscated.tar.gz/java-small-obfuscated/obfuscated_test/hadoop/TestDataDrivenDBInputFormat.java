/**
 * Test aspects of DataDrivenDBInputFormat
 */
public class TestDataDrivenDBInputFormat extends HadoopTestCase {
    private static final Log ORNSLEGYUW = LogFactory.getLog(TestDataDrivenDBInputFormat.class);

    private static final String TRNBSKWWEW = "dddbif";

    private static final String CQTLHNAITW = "jdbc:hsqldb:hsql://localhost/" + TestDataDrivenDBInputFormat.TRNBSKWWEW;

    private static final String LSXFDXEEEX = "org.hsqldb.jdbc.JDBCDriver";

    private Server AQEEXTYWKZ;

    private Connection LNWUHSCPXA;

    private static final String JAJZYCEZLD;

    public TestDataDrivenDBInputFormat() throws IOException {
        super(LOCAL_MR, LOCAL_FS, 1, 1);
    }

    static {
        JAJZYCEZLD = System.getProperty("test.build.data", "/tmp") + "/dddbifout";
    }

    private void startHsqldbServer() {
        if (null == AQEEXTYWKZ) {
            AQEEXTYWKZ = new Server();
            AQEEXTYWKZ.setDatabasePath(0, (System.getProperty("test.build.data", "/tmp") + "/") + TestDataDrivenDBInputFormat.TRNBSKWWEW);
            AQEEXTYWKZ.setDatabaseName(0, TestDataDrivenDBInputFormat.TRNBSKWWEW);
            AQEEXTYWKZ.start();
        }
    }

    private void createConnection(String QWONHICEKM, String JGYJTRXOVD) throws Exception {
        Class.forName(QWONHICEKM);
        LNWUHSCPXA = DriverManager.getConnection(JGYJTRXOVD);
        LNWUHSCPXA.setAutoCommit(false);
    }

    private void shutdown() {
        try {
            LNWUHSCPXA.commit();
            LNWUHSCPXA.close();
            LNWUHSCPXA = null;
        } catch (Throwable ex) {
            TestDataDrivenDBInputFormat.ORNSLEGYUW.warn("Exception occurred while closing connection :" + StringUtils.stringifyException(ex));
        } finally {
            try {
                if (AQEEXTYWKZ != null) {
                    AQEEXTYWKZ.shutdown();
                }
            } catch (Throwable ex) {
                TestDataDrivenDBInputFormat.ORNSLEGYUW.warn("Exception occurred while shutting down HSQLDB :" + StringUtils.stringifyException(ex));
            }
            AQEEXTYWKZ = null;
        }
    }

    private void initialize(String YXYHFRVAJH, String MWOPDBHFES) throws Exception {
        startHsqldbServer();
        createConnection(YXYHFRVAJH, MWOPDBHFES);
    }

    public void setUp() throws Exception {
        initialize(TestDataDrivenDBInputFormat.LSXFDXEEEX, TestDataDrivenDBInputFormat.CQTLHNAITW);
        super.setUp();
    }

    public void tearDown() throws Exception {
        super.tearDown();
        shutdown();
    }

    public static class DateCol implements WritableComparable , DBWritable {
        Date KVXEEOZRWZ;

        public String toString() {
            return KVXEEOZRWZ.toString();
        }

        public void readFields(ResultSet rs) throws SQLException {
            KVXEEOZRWZ = rs.getDate(1);
        }

        public void write(PreparedStatement ps) {
            // not needed.
        }

        public void readFields(DataInput in) throws IOException {
            long v = in.readLong();
            KVXEEOZRWZ = new Date(v);
        }

        public void write(DataOutput out) throws IOException {
            out.writeLong(KVXEEOZRWZ.getTime());
        }

        @Override
        public int hashCode() {
            return ((int) (KVXEEOZRWZ.getTime()));
        }

        @Override
        public int compareTo(Object o) {
            if (o instanceof TestDataDrivenDBInputFormat.DateCol) {
                Long v = Long.valueOf(KVXEEOZRWZ.getTime());
                Long other = Long.valueOf(((TestDataDrivenDBInputFormat.DateCol) (o)).KVXEEOZRWZ.getTime());
                return v.compareTo(other);
            } else {
                return -1;
            }
        }
    }

    public static class ValMapper extends Mapper<Object, Object, Object, NullWritable> {
        public void map(Object k, Object v, Context c) throws IOException, InterruptedException {
            c.write(v, NullWritable.get());
        }
    }

    public void testDateSplits() throws Exception {
        Statement EQQEMZTWUN = LNWUHSCPXA.createStatement();
        final String KALEETJZRE = "datetable";
        final String ZCRKEPGDKD = "foo";
        try {
            // delete the table if it already exists.
            EQQEMZTWUN.executeUpdate("DROP TABLE " + KALEETJZRE);
        } catch (SQLException e) {
        }
        // Create the table.
        EQQEMZTWUN.executeUpdate(((("CREATE TABLE " + KALEETJZRE) + "(") + ZCRKEPGDKD) + " DATE)");
        EQQEMZTWUN.executeUpdate(("INSERT INTO " + KALEETJZRE) + " VALUES('2010-04-01')");
        EQQEMZTWUN.executeUpdate(("INSERT INTO " + KALEETJZRE) + " VALUES('2010-04-02')");
        EQQEMZTWUN.executeUpdate(("INSERT INTO " + KALEETJZRE) + " VALUES('2010-05-01')");
        EQQEMZTWUN.executeUpdate(("INSERT INTO " + KALEETJZRE) + " VALUES('2011-04-01')");
        // commit this tx.
        LNWUHSCPXA.commit();
        Configuration YOLSKLAFAM = new Configuration();
        YOLSKLAFAM.set("fs.defaultFS", "file:///");
        FileSystem XYRWKKBEMU = FileSystem.getLocal(YOLSKLAFAM);
        XYRWKKBEMU.delete(new Path(TestDataDrivenDBInputFormat.JAJZYCEZLD), true);
        // now do a dd import
        Job GDAQUUHYFJ = Job.getInstance(YOLSKLAFAM);
        GDAQUUHYFJ.setMapperClass(TestDataDrivenDBInputFormat.ValMapper.class);
        GDAQUUHYFJ.setReducerClass(Reducer.class);
        GDAQUUHYFJ.setMapOutputKeyClass(TestDataDrivenDBInputFormat.DateCol.class);
        GDAQUUHYFJ.setMapOutputValueClass(NullWritable.class);
        GDAQUUHYFJ.setOutputKeyClass(TestDataDrivenDBInputFormat.DateCol.class);
        GDAQUUHYFJ.setOutputValueClass(NullWritable.class);
        GDAQUUHYFJ.setNumReduceTasks(1);
        GDAQUUHYFJ.getConfiguration().setInt("mapreduce.map.tasks", 2);
        FileOutputFormat.setOutputPath(GDAQUUHYFJ, new Path(TestDataDrivenDBInputFormat.JAJZYCEZLD));
        DBConfiguration.configureDB(GDAQUUHYFJ.getConfiguration(), TestDataDrivenDBInputFormat.LSXFDXEEEX, TestDataDrivenDBInputFormat.CQTLHNAITW, null, null);
        DataDrivenDBInputFormat.setInput(GDAQUUHYFJ, TestDataDrivenDBInputFormat.DateCol.class, KALEETJZRE, null, ZCRKEPGDKD, ZCRKEPGDKD);
        boolean BLRUARJWVM = GDAQUUHYFJ.waitForCompletion(true);
        assertTrue("job failed", BLRUARJWVM);
        // Check to see that we imported as much as we thought we did.
        assertEquals("Did not get all the records", 4, GDAQUUHYFJ.getCounters().findCounter(TaskCounter.REDUCE_OUTPUT_RECORDS).getValue());
    }
}