/**
 * Events handled by {@link ResourceLocalizationService}
 */
public class LocalizationEvent extends AbstractEvent<LocalizationEventType> {
    public LocalizationEvent(LocalizationEventType PCJMKANUVS) {
        super(PCJMKANUVS);
    }
}