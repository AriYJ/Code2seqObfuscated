public class TestDiskspaceQuotaUpdate {
    private static final int SJAKWACIGP = 1024;

    private static final short LDPWJCQORX = 4;

    static final long NMUEJLALOL = 0L;

    private static final Path ODJHZJUZMN = new Path("/TestQuotaUpdate");

    private Configuration WSYBYFVDFI;

    private MiniDFSCluster ABIGAUXRPZ;

    private FSDirectory UTHNEQHZTW;

    private DistributedFileSystem QDIPRJRPRK;

    @Before
    public void setUp() throws Exception {
        WSYBYFVDFI = new Configuration();
        WSYBYFVDFI.setLong(DFS_BLOCK_SIZE_KEY, TestDiskspaceQuotaUpdate.SJAKWACIGP);
        ABIGAUXRPZ = new MiniDFSCluster.Builder(WSYBYFVDFI).numDataNodes(TestDiskspaceQuotaUpdate.LDPWJCQORX).build();
        ABIGAUXRPZ.waitActive();
        UTHNEQHZTW = ABIGAUXRPZ.getNamesystem().getFSDirectory();
        QDIPRJRPRK = ABIGAUXRPZ.getFileSystem();
    }

    @After
    public void tearDown() throws Exception {
        if (ABIGAUXRPZ != null) {
            ABIGAUXRPZ.shutdown();
        }
    }

    /**
     * Test if the quota can be correctly updated for create file
     */
    @Test(timeout = 60000)
    public void testQuotaUpdateWithFileCreate() throws Exception {
        final Path GFNMEKGRNY = new Path(TestDiskspaceQuotaUpdate.ODJHZJUZMN, "foo");
        Path VAPQHEPFMK = new Path(GFNMEKGRNY, "created_file.data");
        QDIPRJRPRK.mkdirs(GFNMEKGRNY);
        QDIPRJRPRK.setQuota(GFNMEKGRNY, Long.MAX_VALUE - 1, Long.MAX_VALUE - 1);
        long HXTROQQQOX = (TestDiskspaceQuotaUpdate.SJAKWACIGP * 2) + (TestDiskspaceQuotaUpdate.SJAKWACIGP / 2);
        DFSTestUtil.createFile(QDIPRJRPRK, VAPQHEPFMK, TestDiskspaceQuotaUpdate.SJAKWACIGP / 16, HXTROQQQOX, TestDiskspaceQuotaUpdate.SJAKWACIGP, TestDiskspaceQuotaUpdate.LDPWJCQORX, TestDiskspaceQuotaUpdate.NMUEJLALOL);
        INode AJDVWOCCAI = UTHNEQHZTW.getINode4Write(GFNMEKGRNY.toString());
        assertTrue(AJDVWOCCAI.isDirectory());
        assertTrue(AJDVWOCCAI.isQuotaSet());
        Quota.Counts ATUJVBZDGV = AJDVWOCCAI.asDirectory().getDirectoryWithQuotaFeature().getSpaceConsumed();
        assertEquals(2, ATUJVBZDGV.get(NAMESPACE));
        assertEquals(HXTROQQQOX * TestDiskspaceQuotaUpdate.LDPWJCQORX, ATUJVBZDGV.get(DISKSPACE));
    }

    /**
     * Test if the quota can be correctly updated for append
     */
    @Test(timeout = 60000)
    public void testUpdateQuotaForAppend() throws Exception {
        final Path QJPTRLWLLC = new Path(TestDiskspaceQuotaUpdate.ODJHZJUZMN, "foo");
        final Path JEGXEHWPLZ = new Path(QJPTRLWLLC, "bar");
        long ORQGKSRBEL = TestDiskspaceQuotaUpdate.SJAKWACIGP;
        DFSTestUtil.createFile(QDIPRJRPRK, JEGXEHWPLZ, ORQGKSRBEL, TestDiskspaceQuotaUpdate.LDPWJCQORX, TestDiskspaceQuotaUpdate.NMUEJLALOL);
        QDIPRJRPRK.setQuota(QJPTRLWLLC, Long.MAX_VALUE - 1, Long.MAX_VALUE - 1);
        // append half of the block data, the previous file length is at block
        // boundary
        DFSTestUtil.appendFile(QDIPRJRPRK, JEGXEHWPLZ, TestDiskspaceQuotaUpdate.SJAKWACIGP / 2);
        ORQGKSRBEL += TestDiskspaceQuotaUpdate.SJAKWACIGP / 2;
        INodeDirectory BRPXSBMORY = UTHNEQHZTW.getINode4Write(QJPTRLWLLC.toString()).asDirectory();
        assertTrue(BRPXSBMORY.isQuotaSet());
        Quota.Counts ICLRIDXVVM = BRPXSBMORY.getDirectoryWithQuotaFeature().getSpaceConsumed();
        long XRUUZPADJF = ICLRIDXVVM.get(NAMESPACE);
        long AHGSVCLAQW = ICLRIDXVVM.get(DISKSPACE);
        assertEquals(2, XRUUZPADJF);// foo and bar

        assertEquals(ORQGKSRBEL * TestDiskspaceQuotaUpdate.LDPWJCQORX, AHGSVCLAQW);
        ContentSummary WMNFFJHLUF = QDIPRJRPRK.getContentSummary(QJPTRLWLLC);
        assertEquals(WMNFFJHLUF.getSpaceConsumed(), AHGSVCLAQW);
        // append another block, the previous file length is not at block boundary
        DFSTestUtil.appendFile(QDIPRJRPRK, JEGXEHWPLZ, TestDiskspaceQuotaUpdate.SJAKWACIGP);
        ORQGKSRBEL += TestDiskspaceQuotaUpdate.SJAKWACIGP;
        ICLRIDXVVM = BRPXSBMORY.getDirectoryWithQuotaFeature().getSpaceConsumed();
        XRUUZPADJF = ICLRIDXVVM.get(NAMESPACE);
        AHGSVCLAQW = ICLRIDXVVM.get(DISKSPACE);
        assertEquals(2, XRUUZPADJF);// foo and bar

        assertEquals(ORQGKSRBEL * TestDiskspaceQuotaUpdate.LDPWJCQORX, AHGSVCLAQW);
        WMNFFJHLUF = QDIPRJRPRK.getContentSummary(QJPTRLWLLC);
        assertEquals(WMNFFJHLUF.getSpaceConsumed(), AHGSVCLAQW);
        // append several blocks
        DFSTestUtil.appendFile(QDIPRJRPRK, JEGXEHWPLZ, (TestDiskspaceQuotaUpdate.SJAKWACIGP * 3) + (TestDiskspaceQuotaUpdate.SJAKWACIGP / 8));
        ORQGKSRBEL += (TestDiskspaceQuotaUpdate.SJAKWACIGP * 3) + (TestDiskspaceQuotaUpdate.SJAKWACIGP / 8);
        ICLRIDXVVM = BRPXSBMORY.getDirectoryWithQuotaFeature().getSpaceConsumed();
        XRUUZPADJF = ICLRIDXVVM.get(NAMESPACE);
        AHGSVCLAQW = ICLRIDXVVM.get(DISKSPACE);
        assertEquals(2, XRUUZPADJF);// foo and bar

        assertEquals(ORQGKSRBEL * TestDiskspaceQuotaUpdate.LDPWJCQORX, AHGSVCLAQW);
        WMNFFJHLUF = QDIPRJRPRK.getContentSummary(QJPTRLWLLC);
        assertEquals(WMNFFJHLUF.getSpaceConsumed(), AHGSVCLAQW);
    }

    /**
     * Test if the quota can be correctly updated when file length is updated
     * through fsync
     */
    @Test(timeout = 60000)
    public void testUpdateQuotaForFSync() throws Exception {
        final Path KVUBEDUKYE = new Path("/foo");
        final Path COKVTONVRH = new Path(KVUBEDUKYE, "bar");
        DFSTestUtil.createFile(QDIPRJRPRK, COKVTONVRH, TestDiskspaceQuotaUpdate.SJAKWACIGP, TestDiskspaceQuotaUpdate.LDPWJCQORX, 0L);
        QDIPRJRPRK.setQuota(KVUBEDUKYE, Long.MAX_VALUE - 1, Long.MAX_VALUE - 1);
        FSDataOutputStream IWAZNYARBU = QDIPRJRPRK.append(COKVTONVRH);
        IWAZNYARBU.write(new byte[TestDiskspaceQuotaUpdate.SJAKWACIGP / 4]);
        ((DFSOutputStream) (IWAZNYARBU.getWrappedStream())).hsync(EnumSet.of(UPDATE_LENGTH));
        INodeDirectory CATDDFLYBZ = UTHNEQHZTW.getINode4Write(KVUBEDUKYE.toString()).asDirectory();
        Quota.Counts JYLZTHRTFW = CATDDFLYBZ.getDirectoryWithQuotaFeature().getSpaceConsumed();
        long YBTRCVZSGF = JYLZTHRTFW.get(NAMESPACE);
        long BNBJLNDGIU = JYLZTHRTFW.get(DISKSPACE);
        assertEquals(2, YBTRCVZSGF);// foo and bar

        assertEquals((TestDiskspaceQuotaUpdate.SJAKWACIGP * 2) * TestDiskspaceQuotaUpdate.LDPWJCQORX, BNBJLNDGIU);// file is under construction

        IWAZNYARBU.write(new byte[TestDiskspaceQuotaUpdate.SJAKWACIGP / 4]);
        IWAZNYARBU.close();
        CATDDFLYBZ = UTHNEQHZTW.getINode4Write(KVUBEDUKYE.toString()).asDirectory();
        JYLZTHRTFW = CATDDFLYBZ.getDirectoryWithQuotaFeature().getSpaceConsumed();
        YBTRCVZSGF = JYLZTHRTFW.get(NAMESPACE);
        BNBJLNDGIU = JYLZTHRTFW.get(DISKSPACE);
        assertEquals(2, YBTRCVZSGF);
        assertEquals((TestDiskspaceQuotaUpdate.SJAKWACIGP + (TestDiskspaceQuotaUpdate.SJAKWACIGP / 2)) * TestDiskspaceQuotaUpdate.LDPWJCQORX, BNBJLNDGIU);
        // append another block
        DFSTestUtil.appendFile(QDIPRJRPRK, COKVTONVRH, TestDiskspaceQuotaUpdate.SJAKWACIGP);
        JYLZTHRTFW = CATDDFLYBZ.getDirectoryWithQuotaFeature().getSpaceConsumed();
        YBTRCVZSGF = JYLZTHRTFW.get(NAMESPACE);
        BNBJLNDGIU = JYLZTHRTFW.get(DISKSPACE);
        assertEquals(2, YBTRCVZSGF);// foo and bar

        assertEquals(((TestDiskspaceQuotaUpdate.SJAKWACIGP * 2) + (TestDiskspaceQuotaUpdate.SJAKWACIGP / 2)) * TestDiskspaceQuotaUpdate.LDPWJCQORX, BNBJLNDGIU);
    }
}