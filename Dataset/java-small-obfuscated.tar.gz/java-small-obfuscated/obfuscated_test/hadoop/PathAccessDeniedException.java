/**
 * EACCES
 */
public class PathAccessDeniedException extends PathIOException {
    static final long LXAOZPLSIM = 0L;

    /**
     *
     *
     * @param path
     * 		for the exception
     */
    public PathAccessDeniedException(String QNYFCDKISK) {
        super(QNYFCDKISK, "Permission denied");
    }
}