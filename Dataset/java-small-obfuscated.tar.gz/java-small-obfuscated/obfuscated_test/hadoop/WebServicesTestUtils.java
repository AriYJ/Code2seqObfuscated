public class WebServicesTestUtils {
    public static long getXmlLong(Element BULWGRFBYS, String ROUEGJXBLV) {
        String TPEXKMBASV = WebServicesTestUtils.getXmlString(BULWGRFBYS, ROUEGJXBLV);
        return Long.parseLong(TPEXKMBASV);
    }

    public static int getXmlInt(Element BGLOSOCCWC, String XDRVZDNJZY) {
        String PECDJNXHJN = WebServicesTestUtils.getXmlString(BGLOSOCCWC, XDRVZDNJZY);
        return Integer.parseInt(PECDJNXHJN);
    }

    public static Boolean getXmlBoolean(Element DFQCREUOCD, String SOXVOSZZPD) {
        String ZHLSZZRRBR = WebServicesTestUtils.getXmlString(DFQCREUOCD, SOXVOSZZPD);
        return Boolean.parseBoolean(ZHLSZZRRBR);
    }

    public static float getXmlFloat(Element YPFGAQQZOC, String BODZGKNTWF) {
        String QEXXURISFJ = WebServicesTestUtils.getXmlString(YPFGAQQZOC, BODZGKNTWF);
        return Float.parseFloat(QEXXURISFJ);
    }

    public static String getXmlString(Element TCXINGOUKU, String DXSQPVBPTC) {
        NodeList RUKYXDJBAN = TCXINGOUKU.getElementsByTagName(DXSQPVBPTC);
        Element PJHVYKBHPC = ((Element) (RUKYXDJBAN.item(0)));
        if (PJHVYKBHPC == null) {
            return null;
        }
        Node ZFECLXNIZH = PJHVYKBHPC.getFirstChild();
        // handle empty <key></key>
        if (ZFECLXNIZH == null) {
            return "";
        }
        String OOUKIBPAZE = ZFECLXNIZH.getNodeValue();
        if (OOUKIBPAZE == null) {
            return "";
        }
        return OOUKIBPAZE;
    }

    public static String getXmlAttrString(Element ZABBXMENHN, String XSJDIRQPXB) {
        Attr TMCRCVAHPU = ZABBXMENHN.getAttributeNode(XSJDIRQPXB);
        if (TMCRCVAHPU != null) {
            return TMCRCVAHPU.getValue();
        }
        return null;
    }

    public static void checkStringMatch(String HWRFECABTL, String XNBSDWGEZX, String WEUYVNZIFC) {
        assertTrue((((HWRFECABTL + " doesn't match, got: ") + WEUYVNZIFC) + " expected: ") + XNBSDWGEZX, WEUYVNZIFC.matches(XNBSDWGEZX));
    }

    public static void checkStringContains(String GVXRGCXTII, String EFBZVWPTSG, String OGTZWHNVZK) {
        assertTrue((((GVXRGCXTII + " doesn't contain expected string, got: ") + OGTZWHNVZK) + " expected: ") + EFBZVWPTSG, OGTZWHNVZK.contains(EFBZVWPTSG));
    }

    public static void checkStringEqual(String SORWJXNTRQ, String NWMVZTNTRR, String EIJPZUVJDQ) {
        assertTrue((((SORWJXNTRQ + " is not equal, got: ") + EIJPZUVJDQ) + " expected: ") + NWMVZTNTRR, EIJPZUVJDQ.equals(NWMVZTNTRR));
    }
}