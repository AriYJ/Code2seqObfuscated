/**
 * A base class for the servlets in DFS.
 */
abstract class DfsServlet extends HttpServlet {
    /**
     * For java.io.Serializable
     */
    private static final long QKECUQKKKQ = 1L;

    static final Log XJGVRHAOYR = LogFactory.getLog(DfsServlet.class.getCanonicalName());

    /**
     * Write the object to XML format
     */
    protected void writeXml(Exception EVUWPKEFNR, String EFAZXPTLOQ, XMLOutputter ISZXPNARXW) throws IOException {
        ISZXPNARXW.startTag(RemoteException.class.getSimpleName());
        ISZXPNARXW.attribute("path", EFAZXPTLOQ);
        if (EVUWPKEFNR instanceof RemoteException) {
            ISZXPNARXW.attribute("class", ((RemoteException) (EVUWPKEFNR)).getClassName());
        } else {
            ISZXPNARXW.attribute("class", EVUWPKEFNR.getClass().getName());
        }
        String XOMYMQNIVI = EVUWPKEFNR.getLocalizedMessage();
        int NRMMCOKNUI = XOMYMQNIVI.indexOf("\n");
        if (NRMMCOKNUI >= 0) {
            XOMYMQNIVI = XOMYMQNIVI.substring(0, NRMMCOKNUI);
        }
        ISZXPNARXW.attribute("message", XOMYMQNIVI.substring(XOMYMQNIVI.indexOf(":") + 1).trim());
        ISZXPNARXW.endTag();
    }

    /**
     * Create a {@link NameNode} proxy from the current {@link ServletContext}.
     */
    protected ClientProtocol createNameNodeProxy() throws IOException {
        ServletContext PLEXRVSUEP = getServletContext();
        // if we are running in the Name Node, use it directly rather than via
        // rpc
        NameNode VZLXEEQYKF = NameNodeHttpServer.getNameNodeFromContext(PLEXRVSUEP);
        if (VZLXEEQYKF != null) {
            return VZLXEEQYKF.getRpcServer();
        }
        InetSocketAddress KWUECYFCWT = NameNodeHttpServer.getNameNodeAddressFromContext(PLEXRVSUEP);
        Configuration UJWYQRMLZE = new org.apache.hadoop.hdfs.HdfsConfiguration(NameNodeHttpServer.getConfFromContext(PLEXRVSUEP));
        return org.apache.hadoop.hdfs.NameNodeProxies.createProxy(UJWYQRMLZE, NameNode.getUri(KWUECYFCWT), ClientProtocol.class).getProxy();
    }

    protected UserGroupInformation getUGI(HttpServletRequest MKGITEQFKZ, Configuration UHSSMJTJOJ) throws IOException {
        return JspHelper.getUGI(getServletContext(), MKGITEQFKZ, UHSSMJTJOJ);
    }
}