public class NodePage extends NMView {
    private static final long NZIMPHXTGV = 1024 * 1024;

    @Override
    protected void commonPreHead(HTML<_> PVPZIBFUQF) {
        super.commonPreHead(PVPZIBFUQF);
        set(initID(ACCORDION, "nav"), "{autoHeight:false, active:1}");
    }

    @Override
    protected Class<? extends SubView> content() {
        return NodePage.NodeBlock.class;
    }

    public static class NodeBlock extends HtmlBlock {
        private final Context OZTLESJXSY;

        private final ResourceView WMHZBEJJTD;

        @Inject
        public NodeBlock(Context context, ResourceView resourceView) {
            this.OZTLESJXSY = context;
            this.WMHZBEJJTD = resourceView;
        }

        @Override
        protected void render(Block html) {
            NodeInfo info = new NodeInfo(this.OZTLESJXSY, this.WMHZBEJJTD);
            info("NodeManager information")._("Total Vmem allocated for Containers", org.apache.hadoop.util.StringUtils.byteDesc(info.getTotalVmemAllocated() * NodePage.NZIMPHXTGV))._("Vmem enforcement enabled", info.isVmemCheckEnabled())._("Total Pmem allocated for Container", org.apache.hadoop.util.StringUtils.byteDesc(info.getTotalPmemAllocated() * NodePage.NZIMPHXTGV))._("Pmem enforcement enabled", info.isPmemCheckEnabled())._("Total VCores allocated for Containers", String.valueOf(info.getTotalVCoresAllocated()))._("NodeHealthyStatus", info.getHealthStatus())._("LastNodeHealthTime", new java.util.Date(info.getLastNodeUpdateTime()))._("NodeHealthReport", info.getHealthReport())._("Node Manager Version:", (info.getNMBuildVersion() + " on ") + info.getNMVersionBuiltOn())._("Hadoop Version:", (info.getHadoopBuildVersion() + " on ") + info.getHadoopVersionBuiltOn());
            html._(InfoBlock.class);
        }
    }
}