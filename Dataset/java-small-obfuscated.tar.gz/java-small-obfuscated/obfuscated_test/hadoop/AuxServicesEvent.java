public class AuxServicesEvent extends AbstractEvent<AuxServicesEventType> {
    private final String AOGGMJRAGP;

    private final String IFYEQYKAZX;

    private final ByteBuffer BJHHYBEXFU;

    private final ApplicationId EBXULIOCPL;

    private final Container PZQAOJSXYL;

    public AuxServicesEvent(AuxServicesEventType YZJCYFCLDR, ApplicationId OKFKMQNREV) {
        this(YZJCYFCLDR, null, OKFKMQNREV, null, null);
    }

    public AuxServicesEvent(AuxServicesEventType MZRKCUYWNJ, Container IWMLASZOOO) {
        this(MZRKCUYWNJ, null, IWMLASZOOO.getContainerId().getApplicationAttemptId().getApplicationId(), null, null, IWMLASZOOO);
    }

    public AuxServicesEvent(AuxServicesEventType FFVVQYDWNK, String AFGGSBZGWS, ApplicationId IDQBIXWVTU, String NOHJHHVIXR, ByteBuffer HHOISLZBBE) {
        this(FFVVQYDWNK, AFGGSBZGWS, IDQBIXWVTU, NOHJHHVIXR, HHOISLZBBE, null);
    }

    public AuxServicesEvent(AuxServicesEventType TOXUOJBXHG, String BLDOMZYCIT, ApplicationId SHDAEGNJQU, String FLNXLWPPWV, ByteBuffer NXFDEEHOTV, Container PHBHOMGINL) {
        super(TOXUOJBXHG);
        this.AOGGMJRAGP = BLDOMZYCIT;
        this.EBXULIOCPL = SHDAEGNJQU;
        this.IFYEQYKAZX = FLNXLWPPWV;
        this.BJHHYBEXFU = NXFDEEHOTV;
        this.PZQAOJSXYL = PHBHOMGINL;
    }

    public String getServiceID() {
        return IFYEQYKAZX;
    }

    public ByteBuffer getServiceData() {
        return BJHHYBEXFU;
    }

    public String getUser() {
        return AOGGMJRAGP;
    }

    public ApplicationId getApplicationID() {
        return EBXULIOCPL;
    }

    public Container getContainer() {
        return PZQAOJSXYL;
    }
}