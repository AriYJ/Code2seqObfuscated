public class TestBlockManager {
    private DatanodeStorageInfo[] VNTNDTHVEY;

    private List<DatanodeDescriptor> SWHPEKGKBN;

    private List<DatanodeDescriptor> AMUMLLUIUX;

    private List<DatanodeDescriptor> GBOURRRBKV;

    /**
     * Some of these tests exercise code which has some randomness involved -
     * ie even if there's a bug, they may pass because the random node selection
     * chooses the correct result.
     *
     * Since they're true unit tests and run quickly, we loop them a number
     * of times trying to trigger the incorrect behavior.
     */
    private static final int DCMUKBENYB = 30;

    private static final int ZZHBDBVGXI = 64 * 1024;

    private Configuration KWNTUSICXM;

    private FSNamesystem FYMXGUKAHL;

    private BlockManager SEXVQUWFSV;

    @Before
    public void setupMockCluster() throws IOException {
        KWNTUSICXM = new HdfsConfiguration();
        KWNTUSICXM.set(NET_TOPOLOGY_SCRIPT_FILE_NAME_KEY, "need to set a dummy value here so it assumes a multi-rack cluster");
        FYMXGUKAHL = Mockito.mock(FSNamesystem.class);
        Mockito.doReturn(true).when(FYMXGUKAHL).hasWriteLock();
        SEXVQUWFSV = new BlockManager(FYMXGUKAHL, FYMXGUKAHL, KWNTUSICXM);
        final String[] EHDUHRDRDI = new String[]{ "/rackA", "/rackA", "/rackA", "/rackB", "/rackB", "/rackB" };
        VNTNDTHVEY = DFSTestUtil.createDatanodeStorageInfos(EHDUHRDRDI);
        SWHPEKGKBN = Arrays.asList(DFSTestUtil.toDatanodeDescriptor(VNTNDTHVEY));
        AMUMLLUIUX = SWHPEKGKBN.subList(0, 3);
        GBOURRRBKV = SWHPEKGKBN.subList(3, 6);
    }

    private void addNodes(Iterable<DatanodeDescriptor> KBKBSUTOLV) {
        NetworkTopology MJJAULFFXC = SEXVQUWFSV.getDatanodeManager().getNetworkTopology();
        // construct network topology
        for (DatanodeDescriptor YZKKSEAOHG : KBKBSUTOLV) {
            MJJAULFFXC.add(YZKKSEAOHG);
            YZKKSEAOHG.getStorageInfos()[0].setUtilizationForTesting((2 * HdfsConstants.MIN_BLOCKS_FOR_WRITE) * TestBlockManager.ZZHBDBVGXI, 0L, (2 * HdfsConstants.MIN_BLOCKS_FOR_WRITE) * TestBlockManager.ZZHBDBVGXI, 0L);
            YZKKSEAOHG.updateHeartbeat(BlockManagerTestUtil.getStorageReportsForDatanode(YZKKSEAOHG), 0L, 0L, 0, 0);
            SEXVQUWFSV.getDatanodeManager().checkIfClusterIsNowMultiRack(YZKKSEAOHG);
        }
    }

    private void removeNode(DatanodeDescriptor CUFNLMXRDS) {
        NetworkTopology PMQIZYUMXO = SEXVQUWFSV.getDatanodeManager().getNetworkTopology();
        PMQIZYUMXO.remove(CUFNLMXRDS);
        SEXVQUWFSV.removeBlocksAssociatedTo(CUFNLMXRDS);
    }

    /**
     * Test that replication of under-replicated blocks is detected
     * and basically works
     */
    @Test
    public void testBasicReplication() throws Exception {
        addNodes(SWHPEKGKBN);
        for (int DOAKGQDTOY = 0; DOAKGQDTOY < TestBlockManager.DCMUKBENYB; DOAKGQDTOY++) {
            doBasicTest(DOAKGQDTOY);
        }
    }

    private void doBasicTest(int GNQZIHOFHV) {
        List<DatanodeStorageInfo> JVQFPPSJWS = getStorages(0, 1);
        List<DatanodeDescriptor> ALTVLIQSQE = getNodes(JVQFPPSJWS);
        BlockInfo IGZSGRDNFS = addBlockOnNodes(GNQZIHOFHV, ALTVLIQSQE);
        DatanodeStorageInfo[] WALQILNFBQ = scheduleSingleReplication(IGZSGRDNFS);
        assertEquals(2, WALQILNFBQ.length);
        assertTrue(("Source of replication should be one of the nodes the block " + "was on. Was: ") + WALQILNFBQ[0], JVQFPPSJWS.contains(WALQILNFBQ[0]));
        assertTrue(("Destination of replication should be on the other rack. " + "Was: ") + WALQILNFBQ[1], GBOURRRBKV.contains(WALQILNFBQ[1].getDatanodeDescriptor()));
    }

    /**
     * Regression test for HDFS-1480
     * - Cluster has 2 racks, A and B, each with three nodes.
     * - Block initially written on A1, A2, B1
     * - Admin decommissions two of these nodes (let's say A1 and A2 but it doesn't matter)
     * - Re-replication should respect rack policy
     */
    @Test
    public void testTwoOfThreeNodesDecommissioned() throws Exception {
        addNodes(SWHPEKGKBN);
        for (int LWUYNDHLXJ = 0; LWUYNDHLXJ < TestBlockManager.DCMUKBENYB; LWUYNDHLXJ++) {
            doTestTwoOfThreeNodesDecommissioned(LWUYNDHLXJ);
        }
    }

    private void doTestTwoOfThreeNodesDecommissioned(int HCDQMHDSAE) throws Exception {
        // Block originally on A1, A2, B1
        List<DatanodeStorageInfo> TTUWYZGBHQ = getStorages(0, 1, 3);
        List<DatanodeDescriptor> UMFXUZAFRC = getNodes(TTUWYZGBHQ);
        BlockInfo WGWVQACAIV = addBlockOnNodes(HCDQMHDSAE, UMFXUZAFRC);
        // Decommission two of the nodes (A1, A2)
        List<DatanodeDescriptor> YGXORHJQZX = startDecommission(0, 1);
        DatanodeStorageInfo[] PMHIGYYJOO = scheduleSingleReplication(WGWVQACAIV);
        assertTrue(("Source of replication should be one of the nodes the block " + "was on. Was: ") + PMHIGYYJOO[0], TTUWYZGBHQ.contains(PMHIGYYJOO[0]));
        assertEquals("Should have three targets", 3, PMHIGYYJOO.length);
        boolean DHZGBHHWGI = false;
        for (int KFNMGYBHGL = 1; KFNMGYBHGL < PMHIGYYJOO.length; KFNMGYBHGL++) {
            DatanodeDescriptor CJLRWOYYAQ = PMHIGYYJOO[KFNMGYBHGL].getDatanodeDescriptor();
            if (AMUMLLUIUX.contains(CJLRWOYYAQ)) {
                DHZGBHHWGI = true;
            }
            assertFalse(YGXORHJQZX.contains(CJLRWOYYAQ));
            assertFalse(UMFXUZAFRC.contains(CJLRWOYYAQ));
        }
        assertTrue("Should have at least one target on rack A. Pipeline: " + com.google.common.base.Joiner.on(",").join(PMHIGYYJOO), DHZGBHHWGI);
    }

    /**
     * Test what happens when a block is on three nodes, and all three of those
     * nodes are decommissioned. It should properly re-replicate to three new
     * nodes.
     */
    @Test
    public void testAllNodesHoldingReplicasDecommissioned() throws Exception {
        addNodes(SWHPEKGKBN);
        for (int WMTPVYAMAJ = 0; WMTPVYAMAJ < TestBlockManager.DCMUKBENYB; WMTPVYAMAJ++) {
            doTestAllNodesHoldingReplicasDecommissioned(WMTPVYAMAJ);
        }
    }

    private void doTestAllNodesHoldingReplicasDecommissioned(int NSIIECVGDM) throws Exception {
        // Block originally on A1, A2, B1
        List<DatanodeStorageInfo> UYVMKFDITC = getStorages(0, 1, 3);
        List<DatanodeDescriptor> ZEASNLPJFH = getNodes(UYVMKFDITC);
        BlockInfo KYHICAJWIC = addBlockOnNodes(NSIIECVGDM, ZEASNLPJFH);
        // Decommission all of the nodes
        List<DatanodeDescriptor> WYMGNMQNKU = startDecommission(0, 1, 3);
        DatanodeStorageInfo[] WYIBUCJWHM = scheduleSingleReplication(KYHICAJWIC);
        assertTrue(("Source of replication should be one of the nodes the block " + "was on. Was: ") + WYIBUCJWHM[0], UYVMKFDITC.contains(WYIBUCJWHM[0]));
        assertEquals("Should have three targets", 4, WYIBUCJWHM.length);
        boolean YMBTPCIDZJ = false;
        boolean IMINMDPZJI = false;
        for (int QMZSLCGOMU = 1; QMZSLCGOMU < WYIBUCJWHM.length; QMZSLCGOMU++) {
            DatanodeDescriptor GIBGUQVMKV = WYIBUCJWHM[QMZSLCGOMU].getDatanodeDescriptor();
            if (AMUMLLUIUX.contains(GIBGUQVMKV)) {
                YMBTPCIDZJ = true;
            } else
                if (GBOURRRBKV.contains(GIBGUQVMKV)) {
                    IMINMDPZJI = true;
                }

            assertFalse(WYMGNMQNKU.contains(GIBGUQVMKV));
            assertFalse(ZEASNLPJFH.contains(GIBGUQVMKV));
        }
        assertTrue("Should have at least one target on rack A. Pipeline: " + com.google.common.base.Joiner.on(",").join(WYIBUCJWHM), YMBTPCIDZJ);
        assertTrue("Should have at least one target on rack B. Pipeline: " + com.google.common.base.Joiner.on(",").join(WYIBUCJWHM), IMINMDPZJI);
    }

    /**
     * Test what happens when there are two racks, and an entire rack is
     * decommissioned.
     *
     * Since the cluster is multi-rack, it will consider the block
     * under-replicated rather than create a third replica on the
     * same rack. Adding a new node on a third rack should cause re-replication
     * to that node.
     */
    @Test
    public void testOneOfTwoRacksDecommissioned() throws Exception {
        addNodes(SWHPEKGKBN);
        for (int VBCJPBHRXK = 0; VBCJPBHRXK < TestBlockManager.DCMUKBENYB; VBCJPBHRXK++) {
            doTestOneOfTwoRacksDecommissioned(VBCJPBHRXK);
        }
    }

    private void doTestOneOfTwoRacksDecommissioned(int ARCPZDPWJY) throws Exception {
        // Block originally on A1, A2, B1
        List<DatanodeStorageInfo> DHGUWFWGOO = getStorages(0, 1, 3);
        List<DatanodeDescriptor> UOEVMOQYDP = getNodes(DHGUWFWGOO);
        BlockInfo GHXYRWISVM = addBlockOnNodes(ARCPZDPWJY, UOEVMOQYDP);
        // Decommission all of the nodes in rack A
        List<DatanodeDescriptor> PPOJPNOVXI = startDecommission(0, 1, 2);
        DatanodeStorageInfo[] SNDZZORHTK = scheduleSingleReplication(GHXYRWISVM);
        assertTrue(("Source of replication should be one of the nodes the block " + "was on. Was: ") + SNDZZORHTK[0], DHGUWFWGOO.contains(SNDZZORHTK[0]));
        assertEquals("Should have three targets", 3, SNDZZORHTK.length);
        boolean LOYILBBGGI = false;
        for (int NZZWMYAPJR = 1; NZZWMYAPJR < SNDZZORHTK.length; NZZWMYAPJR++) {
            DatanodeDescriptor MIDAOIBPUN = SNDZZORHTK[NZZWMYAPJR].getDatanodeDescriptor();
            if (GBOURRRBKV.contains(MIDAOIBPUN)) {
                LOYILBBGGI = true;
            }
            assertFalse(PPOJPNOVXI.contains(MIDAOIBPUN));
            assertFalse(UOEVMOQYDP.contains(MIDAOIBPUN));
        }
        assertTrue("Should have at least one target on rack B. Pipeline: " + com.google.common.base.Joiner.on(",").join(SNDZZORHTK), LOYILBBGGI);
        // Mark the block as received on the target nodes in the pipeline
        fulfillPipeline(GHXYRWISVM, SNDZZORHTK);
        // the block is still under-replicated. Add a new node. This should allow
        // the third off-rack replica.
        DatanodeDescriptor JKUQMMSFQK = DFSTestUtil.getDatanodeDescriptor("7.7.7.7", "/rackC");
        JKUQMMSFQK.updateStorage(new DatanodeStorage(DatanodeStorage.generateUuid()));
        addNodes(ImmutableList.of(JKUQMMSFQK));
        try {
            DatanodeStorageInfo[] NEDJXYBTMA = scheduleSingleReplication(GHXYRWISVM);
            assertEquals(2, NEDJXYBTMA.length);
            assertEquals(JKUQMMSFQK, NEDJXYBTMA[1].getDatanodeDescriptor());
        } finally {
            removeNode(JKUQMMSFQK);
        }
    }

    /**
     * Unit test version of testSufficientlyReplBlocksUsesNewRack from
     * {@link TestBlocksWithNotEnoughRacks}.
     */
    @Test
    public void testSufficientlyReplBlocksUsesNewRack() throws Exception {
        addNodes(SWHPEKGKBN);
        for (int HWCORKSURL = 0; HWCORKSURL < TestBlockManager.DCMUKBENYB; HWCORKSURL++) {
            doTestSufficientlyReplBlocksUsesNewRack(HWCORKSURL);
        }
    }

    private void doTestSufficientlyReplBlocksUsesNewRack(int SNYDTLLALT) {
        // Originally on only nodes in rack A.
        List<DatanodeDescriptor> UHWTQIJLEH = AMUMLLUIUX;
        BlockInfo XJVEWRWKEN = addBlockOnNodes(SNYDTLLALT, UHWTQIJLEH);
        DatanodeStorageInfo[] IDRUCIOEON = scheduleSingleReplication(XJVEWRWKEN);
        assertEquals(2, IDRUCIOEON.length);// single new copy

        assertTrue(("Source of replication should be one of the nodes the block " + "was on. Was: ") + IDRUCIOEON[0], UHWTQIJLEH.contains(IDRUCIOEON[0].getDatanodeDescriptor()));
        assertTrue(("Destination of replication should be on the other rack. " + "Was: ") + IDRUCIOEON[1], GBOURRRBKV.contains(IDRUCIOEON[1].getDatanodeDescriptor()));
    }

    @Test
    public void testBlocksAreNotUnderreplicatedInSingleRack() throws Exception {
        List<DatanodeDescriptor> OIKJTEGBEW = ImmutableList.of(BlockManagerTestUtil.getDatanodeDescriptor("1.1.1.1", "/rackA", true), BlockManagerTestUtil.getDatanodeDescriptor("2.2.2.2", "/rackA", true), BlockManagerTestUtil.getDatanodeDescriptor("3.3.3.3", "/rackA", true), BlockManagerTestUtil.getDatanodeDescriptor("4.4.4.4", "/rackA", true), BlockManagerTestUtil.getDatanodeDescriptor("5.5.5.5", "/rackA", true), BlockManagerTestUtil.getDatanodeDescriptor("6.6.6.6", "/rackA", true));
        addNodes(OIKJTEGBEW);
        List<DatanodeDescriptor> LKAPWQBITX = OIKJTEGBEW.subList(0, 3);
        for (int YPZLJLGGLG = 0; YPZLJLGGLG < TestBlockManager.DCMUKBENYB; YPZLJLGGLG++) {
            doTestSingleRackClusterIsSufficientlyReplicated(YPZLJLGGLG, LKAPWQBITX);
        }
    }

    private void doTestSingleRackClusterIsSufficientlyReplicated(int JDEUTLGRBZ, List<DatanodeDescriptor> WNDZXZOAFD) throws Exception {
        assertEquals(0, SEXVQUWFSV.numOfUnderReplicatedBlocks());
        addBlockOnNodes(JDEUTLGRBZ, WNDZXZOAFD);
        SEXVQUWFSV.processMisReplicatedBlocks();
        assertEquals(0, SEXVQUWFSV.numOfUnderReplicatedBlocks());
    }

    /**
     * Tell the block manager that replication is completed for the given
     * pipeline.
     */
    private void fulfillPipeline(BlockInfo KBIBAHFDFN, DatanodeStorageInfo[] XMHRLLNXWG) throws IOException {
        for (int LWNSRLHHRU = 1; LWNSRLHHRU < XMHRLLNXWG.length; LWNSRLHHRU++) {
            DatanodeStorageInfo AMCVMMLFJO = XMHRLLNXWG[LWNSRLHHRU];
            SEXVQUWFSV.addBlock(AMCVMMLFJO, KBIBAHFDFN, null);
            KBIBAHFDFN.addStorage(AMCVMMLFJO);
        }
    }

    private BlockInfo blockOnNodes(long SLNWWHOSDM, List<DatanodeDescriptor> OANKCIEMXL) {
        Block KTZDNKAVJM = new Block(SLNWWHOSDM);
        BlockInfo VGYJNKZVGX = new BlockInfo(KTZDNKAVJM, 3);
        for (DatanodeDescriptor DSSPLNIAQD : OANKCIEMXL) {
            for (DatanodeStorageInfo FTBOYDNJZN : DSSPLNIAQD.getStorageInfos()) {
                VGYJNKZVGX.addStorage(FTBOYDNJZN);
            }
        }
        return VGYJNKZVGX;
    }

    private List<DatanodeDescriptor> getNodes(int... LNUCSOFQNP) {
        List<DatanodeDescriptor> EGFIYNZMAW = Lists.newArrayList();
        for (int IHKVSYGGCF : LNUCSOFQNP) {
            EGFIYNZMAW.add(SWHPEKGKBN.get(IHKVSYGGCF));
        }
        return EGFIYNZMAW;
    }

    private List<DatanodeDescriptor> getNodes(List<DatanodeStorageInfo> IMIZSWJLWX) {
        List<DatanodeDescriptor> ZFYTSGNBEV = Lists.newArrayList();
        for (DatanodeStorageInfo QYHHGHNXSB : IMIZSWJLWX) {
            ZFYTSGNBEV.add(QYHHGHNXSB.getDatanodeDescriptor());
        }
        return ZFYTSGNBEV;
    }

    private List<DatanodeStorageInfo> getStorages(int... DBNHHPFOTR) {
        List<DatanodeStorageInfo> PEUNKUEPYD = Lists.newArrayList();
        for (int BPOEVTJSGP : DBNHHPFOTR) {
            PEUNKUEPYD.add(VNTNDTHVEY[BPOEVTJSGP]);
        }
        return PEUNKUEPYD;
    }

    private List<DatanodeDescriptor> startDecommission(int... PWGVYVIDHM) {
        List<DatanodeDescriptor> SAXILBSNUW = getNodes(PWGVYVIDHM);
        for (DatanodeDescriptor CIJDRPDUQC : SAXILBSNUW) {
            CIJDRPDUQC.startDecommission();
        }
        return SAXILBSNUW;
    }

    private BlockInfo addBlockOnNodes(long OFLIPZJFEZ, List<DatanodeDescriptor> IYOFWXPMQE) {
        BlockCollection PNNDRMTNWD = Mockito.mock(BlockCollection.class);
        Mockito.doReturn(((short) (3))).when(PNNDRMTNWD).getBlockReplication();
        BlockInfo WGTZEPCIXS = blockOnNodes(OFLIPZJFEZ, IYOFWXPMQE);
        SEXVQUWFSV.blocksMap.addBlockCollection(WGTZEPCIXS, PNNDRMTNWD);
        return WGTZEPCIXS;
    }

    private DatanodeStorageInfo[] scheduleSingleReplication(Block QUYOLJRMDT) {
        // list for priority 1
        List<Block> XGGFCLDPEY = new ArrayList<Block>();
        XGGFCLDPEY.add(QUYOLJRMDT);
        // list of lists for each priority
        List<List<Block>> KRQBZVTXQJ = new ArrayList<List<Block>>();
        KRQBZVTXQJ.add(new ArrayList<Block>());// for priority 0

        KRQBZVTXQJ.add(XGGFCLDPEY);// for priority 1

        assertEquals("Block not initially pending replication", 0, SEXVQUWFSV.pendingReplications.getNumReplicas(QUYOLJRMDT));
        assertEquals("computeReplicationWork should indicate replication is needed", 1, SEXVQUWFSV.computeReplicationWorkForBlocks(KRQBZVTXQJ));
        assertTrue("replication is pending after work is computed", SEXVQUWFSV.pendingReplications.getNumReplicas(QUYOLJRMDT) > 0);
        LinkedListMultimap<DatanodeStorageInfo, BlockTargetPair> YJRHZBJWZZ = getAllPendingReplications();
        assertEquals(1, YJRHZBJWZZ.size());
        Map.Entry<DatanodeStorageInfo, BlockTargetPair> LUSUQWQKEB = YJRHZBJWZZ.entries().iterator().next();
        DatanodeStorageInfo[] LIBSRWQTXR = LUSUQWQKEB.getValue().targets;
        DatanodeStorageInfo[] WOBOMCUYFK = new DatanodeStorageInfo[1 + LIBSRWQTXR.length];
        WOBOMCUYFK[0] = LUSUQWQKEB.getKey();
        System.arraycopy(LIBSRWQTXR, 0, WOBOMCUYFK, 1, LIBSRWQTXR.length);
        return WOBOMCUYFK;
    }

    private LinkedListMultimap<DatanodeStorageInfo, BlockTargetPair> getAllPendingReplications() {
        LinkedListMultimap<DatanodeStorageInfo, BlockTargetPair> YQBRKBMLKN = LinkedListMultimap.create();
        for (DatanodeDescriptor PANYAWFAMR : SWHPEKGKBN) {
            List<BlockTargetPair> BDCZKONSTF = PANYAWFAMR.getReplicationCommand(10);
            if (BDCZKONSTF != null) {
                for (DatanodeStorageInfo SPEWELJQBW : PANYAWFAMR.getStorageInfos()) {
                    YQBRKBMLKN.putAll(SPEWELJQBW, BDCZKONSTF);
                }
            }
        }
        return YQBRKBMLKN;
    }

    /**
     * Test that a source node for a highest-priority replication is chosen even if all available
     * source nodes have reached their replication limits.
     */
    @Test
    public void testHighestPriReplSrcChosenDespiteMaxReplLimit() throws Exception {
        SEXVQUWFSV.maxReplicationStreams = 0;
        SEXVQUWFSV.replicationStreamsHardLimit = 1;
        long VBHXPZKSWZ = 42;
        // arbitrary
        Block TQLHOFDOYI = new Block(VBHXPZKSWZ, 0, 0);
        List<DatanodeDescriptor> TGPIOEUIBT = getNodes(0, 1);
        // Add the block to the first node.
        addBlockOnNodes(VBHXPZKSWZ, TGPIOEUIBT.subList(0, 1));
        List<DatanodeDescriptor> KZYQSQTTJK = new LinkedList<DatanodeDescriptor>();
        List<DatanodeStorageInfo> WWXBVRSLCZ = new LinkedList<DatanodeStorageInfo>();
        assertNotNull("Chooses source node for a highest-priority replication" + (" even if all available source nodes have reached their replication" + " limits below the hard limit."), SEXVQUWFSV.chooseSourceDatanode(TQLHOFDOYI, KZYQSQTTJK, WWXBVRSLCZ, new NumberReplicas(), QUEUE_HIGHEST_PRIORITY));
        assertNull("Does not choose a source node for a less-than-highest-priority" + (" replication since all available source nodes have reached" + " their replication limits."), SEXVQUWFSV.chooseSourceDatanode(TQLHOFDOYI, KZYQSQTTJK, WWXBVRSLCZ, new NumberReplicas(), QUEUE_VERY_UNDER_REPLICATED));
        // Increase the replication count to test replication count > hard limit
        DatanodeStorageInfo[] WHVLICAOHU = new DatanodeStorageInfo[]{ TGPIOEUIBT.get(1).getStorageInfos()[0] };
        TGPIOEUIBT.get(0).addBlockToBeReplicated(TQLHOFDOYI, WHVLICAOHU);
        assertNull("Does not choose a source node for a highest-priority" + " replication when all available nodes exceed the hard limit.", SEXVQUWFSV.chooseSourceDatanode(TQLHOFDOYI, KZYQSQTTJK, WWXBVRSLCZ, new NumberReplicas(), QUEUE_HIGHEST_PRIORITY));
    }

    @Test
    public void testSafeModeIBR() throws Exception {
        DatanodeDescriptor TJNEPSYRPQ = spy(SWHPEKGKBN.get(0));
        DatanodeStorageInfo ZLISBXFFBE = TJNEPSYRPQ.getStorageInfos()[0];
        // TODO: Needs to be fixed. DatanodeUuid is not storageID.
        TJNEPSYRPQ.setDatanodeUuidForTesting(ZLISBXFFBE.getStorageID());
        TJNEPSYRPQ.isAlive = true;
        DatanodeRegistration EHKEOKBWMG = new DatanodeRegistration(TJNEPSYRPQ, null, null, "");
        // pretend to be in safemode
        doReturn(true).when(FYMXGUKAHL).isInStartupSafeMode();
        // register new node
        SEXVQUWFSV.getDatanodeManager().registerDatanode(EHKEOKBWMG);
        SEXVQUWFSV.getDatanodeManager().addDatanode(TJNEPSYRPQ);// swap in spy

        assertEquals(TJNEPSYRPQ, SEXVQUWFSV.getDatanodeManager().getDatanode(TJNEPSYRPQ));
        assertEquals(0, ZLISBXFFBE.getBlockReportCount());
        // send block report, should be processed
        reset(TJNEPSYRPQ);
        SEXVQUWFSV.processReport(TJNEPSYRPQ, new DatanodeStorage(ZLISBXFFBE.getStorageID()), new BlockListAsLongs(null, null));
        assertEquals(1, ZLISBXFFBE.getBlockReportCount());
        // send block report again, should NOT be processed
        reset(TJNEPSYRPQ);
        SEXVQUWFSV.processReport(TJNEPSYRPQ, new DatanodeStorage(ZLISBXFFBE.getStorageID()), new BlockListAsLongs(null, null));
        assertEquals(1, ZLISBXFFBE.getBlockReportCount());
        // re-register as if node restarted, should update existing node
        SEXVQUWFSV.getDatanodeManager().removeDatanode(TJNEPSYRPQ);
        reset(TJNEPSYRPQ);
        SEXVQUWFSV.getDatanodeManager().registerDatanode(EHKEOKBWMG);
        verify(TJNEPSYRPQ).updateRegInfo(EHKEOKBWMG);
        assertEquals(0, ZLISBXFFBE.getBlockReportCount());// ready for report again

        // send block report, should be processed after restart
        reset(TJNEPSYRPQ);
        SEXVQUWFSV.processReport(TJNEPSYRPQ, new DatanodeStorage(ZLISBXFFBE.getStorageID()), new BlockListAsLongs(null, null));
        assertEquals(1, ZLISBXFFBE.getBlockReportCount());
    }

    @Test
    public void testSafeModeIBRAfterIncremental() throws Exception {
        DatanodeDescriptor BJLPHOLRJC = spy(SWHPEKGKBN.get(0));
        DatanodeStorageInfo VWRSCVIVHS = BJLPHOLRJC.getStorageInfos()[0];
        // TODO: Needs to be fixed. DatanodeUuid is not storageID.
        BJLPHOLRJC.setDatanodeUuidForTesting(VWRSCVIVHS.getStorageID());
        BJLPHOLRJC.isAlive = true;
        DatanodeRegistration RKFGTBIJNO = new DatanodeRegistration(BJLPHOLRJC, null, null, "");
        // pretend to be in safemode
        doReturn(true).when(FYMXGUKAHL).isInStartupSafeMode();
        // register new node
        SEXVQUWFSV.getDatanodeManager().registerDatanode(RKFGTBIJNO);
        SEXVQUWFSV.getDatanodeManager().addDatanode(BJLPHOLRJC);// swap in spy

        assertEquals(BJLPHOLRJC, SEXVQUWFSV.getDatanodeManager().getDatanode(BJLPHOLRJC));
        assertEquals(0, VWRSCVIVHS.getBlockReportCount());
        // send block report while pretending to already have blocks
        reset(BJLPHOLRJC);
        doReturn(1).when(BJLPHOLRJC).numBlocks();
        SEXVQUWFSV.processReport(BJLPHOLRJC, new DatanodeStorage(VWRSCVIVHS.getStorageID()), new BlockListAsLongs(null, null));
        assertEquals(1, VWRSCVIVHS.getBlockReportCount());
    }
}