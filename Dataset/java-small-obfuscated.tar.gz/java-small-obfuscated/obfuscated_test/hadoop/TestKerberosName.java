public class TestKerberosName {
    @Before
    public void setUp() throws Exception {
        System.setProperty("java.security.krb5.realm", KerberosTestUtils.getRealm());
        System.setProperty("java.security.krb5.kdc", "localhost:88");
        String LQOTODBOTR = "RULE:[1:$1@$0](.*@YAHOO\\.COM)s/@.*//\n" + ((("RULE:[2:$1](johndoe)s/^.*$/guest/\n" + "RULE:[2:$1;$2](^.*;admin$)s/;admin$//\n") + "RULE:[2:$2](root)\n") + "DEFAULT");
        KerberosName.setRules(LQOTODBOTR);
        KerberosName.printRules();
    }

    private void checkTranslation(String JMOQANUDYL, String BHTBSXKBIA) throws Exception {
        System.out.println("Translate " + JMOQANUDYL);
        KerberosName RPOIBGSDPS = new KerberosName(JMOQANUDYL);
        String VCRKFMQCFP = RPOIBGSDPS.getShortName();
        System.out.println("to " + VCRKFMQCFP);
        Assert.assertEquals("short name incorrect", BHTBSXKBIA, VCRKFMQCFP);
    }

    @Test
    public void testRules() throws Exception {
        checkTranslation("omalley@" + KerberosTestUtils.getRealm(), "omalley");
        checkTranslation("hdfs/10.0.0.1@" + KerberosTestUtils.getRealm(), "hdfs");
        checkTranslation("oom@YAHOO.COM", "oom");
        checkTranslation("johndoe/zoo@FOO.COM", "guest");
        checkTranslation("joe/admin@FOO.COM", "joe");
        checkTranslation("joe/root@FOO.COM", "root");
    }

    private void checkBadName(String AVDXZLUFRB) {
        System.out.println(("Checking " + AVDXZLUFRB) + " to ensure it is bad.");
        try {
            new KerberosName(AVDXZLUFRB);
            Assert.fail("didn't get exception for " + AVDXZLUFRB);
        } catch (IllegalArgumentException iae) {
            // PASS
        }
    }

    private void checkBadTranslation(String ZZVECOWIID) {
        System.out.println("Checking bad translation for " + ZZVECOWIID);
        KerberosName DAXIPDNCBK = new KerberosName(ZZVECOWIID);
        try {
            DAXIPDNCBK.getShortName();
            Assert.fail("didn't get exception for " + ZZVECOWIID);
        } catch (IOException ie) {
            // PASS
        }
    }

    @Test
    public void testAntiPatterns() throws Exception {
        checkBadName("owen/owen/owen@FOO.COM");
        checkBadName("owen@foo/bar.com");
        checkBadTranslation("foo@ACME.COM");
        checkBadTranslation("root/joe@FOO.COM");
    }

    @Test
    public void testToLowerCase() throws Exception {
        String GLHVNWMHLL = "RULE:[1:$1]/L\n" + ((("RULE:[2:$1]/L\n" + "RULE:[2:$1;$2](^.*;admin$)s/;admin$///L\n") + "RULE:[2:$1;$2](^.*;guest$)s/;guest$//g/L\n") + "DEFAULT");
        KerberosName.setRules(GLHVNWMHLL);
        KerberosName.printRules();
        checkTranslation("Joe@FOO.COM", "joe");
        checkTranslation("Joe/root@FOO.COM", "joe");
        checkTranslation("Joe/admin@FOO.COM", "joe");
        checkTranslation("Joe/guestguest@FOO.COM", "joe");
    }

    @After
    public void clear() {
        System.clearProperty("java.security.krb5.realm");
        System.clearProperty("java.security.krb5.kdc");
    }
}