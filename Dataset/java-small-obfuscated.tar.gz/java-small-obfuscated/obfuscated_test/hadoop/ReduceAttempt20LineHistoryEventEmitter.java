public class ReduceAttempt20LineHistoryEventEmitter extends TaskAttempt20LineEventEmitter {
    static List<SingleEventEmitter> HBCLZNJQVW = new LinkedList<SingleEventEmitter>();

    static List<SingleEventEmitter> XYZDHXFTZP = new LinkedList<SingleEventEmitter>();

    static {
        ReduceAttempt20LineHistoryEventEmitter.HBCLZNJQVW.addAll(taskEventNonFinalSEEs);
        ReduceAttempt20LineHistoryEventEmitter.XYZDHXFTZP.add(new ReduceAttempt20LineHistoryEventEmitter.ReduceAttemptFinishedEventEmitter());
    }

    ReduceAttempt20LineHistoryEventEmitter() {
        super();
    }

    private static class ReduceAttemptFinishedEventEmitter extends SingleEventEmitter {
        HistoryEvent maybeEmitEvent(ParsedLine line, String taskAttemptIDName, HistoryEventEmitter thatg) {
            if (taskAttemptIDName == null) {
                return null;
            }
            TaskAttemptID taskAttemptID = TaskAttemptID.forName(taskAttemptIDName);
            String finishTime = line.get("FINISH_TIME");
            String status = line.get("TASK_STATUS");
            if (((finishTime != null) && (status != null)) && status.equalsIgnoreCase("success")) {
                String hostName = line.get("HOSTNAME");
                String counters = line.get("COUNTERS");
                String state = line.get("STATE_STRING");
                String shuffleFinish = line.get("SHUFFLE_FINISHED");
                String sortFinish = line.get("SORT_FINISHED");
                if ((((finishTime != null) && (shuffleFinish != null)) && (sortFinish != null)) && "success".equalsIgnoreCase(status)) {
                    ReduceAttempt20LineHistoryEventEmitter that = ((ReduceAttempt20LineHistoryEventEmitter) (thatg));
                    return new org.apache.hadoop.mapreduce.jobhistory.ReduceAttemptFinishedEvent(taskAttemptID, that.originalTaskType, status, Long.parseLong(shuffleFinish), Long.parseLong(sortFinish), Long.parseLong(finishTime), hostName, -1, null, state, maybeParseCounters(counters), null);
                }
            }
            return null;
        }
    }

    @Override
    List<SingleEventEmitter> finalSEEs() {
        return ReduceAttempt20LineHistoryEventEmitter.XYZDHXFTZP;
    }

    @Override
    List<SingleEventEmitter> nonFinalSEEs() {
        return ReduceAttempt20LineHistoryEventEmitter.HBCLZNJQVW;
    }
}