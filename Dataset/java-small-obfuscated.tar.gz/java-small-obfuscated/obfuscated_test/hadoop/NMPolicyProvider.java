/**
 * {@link PolicyProvider} for YARN NodeManager protocols.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class NMPolicyProvider extends PolicyProvider {
    private static final Service[] YGUJQUVAZP = new Service[]{ new Service(YarnConfiguration.YARN_SECURITY_SERVICE_AUTHORIZATION_CONTAINER_MANAGEMENT_PROTOCOL, ContainerManagementProtocolPB.class), new Service(YarnConfiguration.YARN_SECURITY_SERVICE_AUTHORIZATION_RESOURCE_LOCALIZER, LocalizationProtocolPB.class) };

    @Override
    public Service[] getServices() {
        return NMPolicyProvider.YGUJQUVAZP;
    }
}