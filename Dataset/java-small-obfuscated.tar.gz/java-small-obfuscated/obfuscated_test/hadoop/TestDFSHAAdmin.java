public class TestDFSHAAdmin {
    private static final Log IAXWDDUBHK = LogFactory.getLog(TestDFSHAAdmin.class);

    private DFSHAAdmin JSHZPLVRUL;

    private final ByteArrayOutputStream ULVXZXIPCC = new ByteArrayOutputStream();

    private final ByteArrayOutputStream UNNVIZXZWS = new ByteArrayOutputStream();

    private String HPFRDARRDB;

    private String XZBPTYMBIU;

    private HAServiceProtocol ZVGITCSTEK;

    private ZKFCProtocol IFSKQBLGSZ;

    private static final String NHPANNSJUQ = "ns1";

    private static final HAServiceStatus IOTOLLDFEO = new HAServiceStatus(org.apache.hadoop.ha.HAServiceProtocol.HAServiceState.STANDBY).setReadyToBecomeActive();

    private final ArgumentCaptor<StateChangeRequestInfo> UHOPPJTGVP = ArgumentCaptor.forClass(StateChangeRequestInfo.class);

    private static final String STMRJUCVZZ = "1.2.3.1";

    private static final String DAMDMNSERN = "1.2.3.2";

    // Fencer shell commands that always return true and false respectively
    // on Unix.
    private static final String JENFCGVALZ = "shell(true)";

    private static final String GSUPJVRVSB = "shell(false)";

    // Fencer shell commands that always return true and false respectively
    // on Windows. Lacking POSIX 'true' and 'false' commands we use the DOS
    // commands 'rem' and 'help.exe'.
    private static final String XFKJKHYVND = "shell(rem)";

    private static final String BCLGKDWLVW = "shell(help.exe /? >NUL)";

    private HdfsConfiguration getHAConf() {
        HdfsConfiguration OSCSEUXYOC = new HdfsConfiguration();
        OSCSEUXYOC.set(DFS_NAMESERVICES, TestDFSHAAdmin.NHPANNSJUQ);
        OSCSEUXYOC.set(DFS_NAMESERVICE_ID, TestDFSHAAdmin.NHPANNSJUQ);
        OSCSEUXYOC.set(DFSUtil.addKeySuffixes(DFS_HA_NAMENODES_KEY_PREFIX, TestDFSHAAdmin.NHPANNSJUQ), "nn1,nn2");
        OSCSEUXYOC.set(DFS_HA_NAMENODE_ID_KEY, "nn1");
        OSCSEUXYOC.set(DFSUtil.addKeySuffixes(DFS_NAMENODE_RPC_ADDRESS_KEY, TestDFSHAAdmin.NHPANNSJUQ, "nn1"), TestDFSHAAdmin.STMRJUCVZZ + ":12345");
        OSCSEUXYOC.set(DFSUtil.addKeySuffixes(DFS_NAMENODE_RPC_ADDRESS_KEY, TestDFSHAAdmin.NHPANNSJUQ, "nn2"), TestDFSHAAdmin.DAMDMNSERN + ":12345");
        return OSCSEUXYOC;
    }

    public static String getFencerTrueCommand() {
        return Shell.WINDOWS ? TestDFSHAAdmin.XFKJKHYVND : TestDFSHAAdmin.JENFCGVALZ;
    }

    public static String getFencerFalseCommand() {
        return Shell.WINDOWS ? TestDFSHAAdmin.BCLGKDWLVW : TestDFSHAAdmin.GSUPJVRVSB;
    }

    @Before
    public void setup() throws IOException {
        ZVGITCSTEK = MockitoUtil.mockProtocol(HAServiceProtocol.class);
        IFSKQBLGSZ = MockitoUtil.mockProtocol(ZKFCProtocol.class);
        JSHZPLVRUL = new DFSHAAdmin() {
            @Override
            protected HAServiceTarget resolveTarget(String NFNKYOMKPR) {
                HAServiceTarget KOZIRIQGOC = super.resolveTarget(NFNKYOMKPR);
                HAServiceTarget YSBPHFIBZW = Mockito.spy(KOZIRIQGOC);
                // OVerride the target to return our mock protocol
                try {
                    Mockito.doReturn(ZVGITCSTEK).when(YSBPHFIBZW).getProxy(Mockito.<Configuration>any(), Mockito.anyInt());
                    Mockito.doReturn(IFSKQBLGSZ).when(YSBPHFIBZW).getZKFCProxy(Mockito.<Configuration>any(), Mockito.anyInt());
                } catch (IOException e) {
                    throw new AssertionError(e);// mock setup doesn't really throw

                }
                return YSBPHFIBZW;
            }
        };
        JSHZPLVRUL.setConf(getHAConf());
        JSHZPLVRUL.setErrOut(new PrintStream(ULVXZXIPCC));
        JSHZPLVRUL.setOut(new PrintStream(UNNVIZXZWS));
    }

    private void assertOutputContains(String LLKYAKJSZO) {
        if ((!HPFRDARRDB.contains(LLKYAKJSZO)) && (!XZBPTYMBIU.contains(LLKYAKJSZO))) {
            fail((((("Expected output to contain '" + LLKYAKJSZO) + "\' but err_output was:\n") + HPFRDARRDB) + "\n and output was: \n") + XZBPTYMBIU);
        }
    }

    @Test
    public void testNameserviceOption() throws Exception {
        assertEquals(-1, runTool("-ns"));
        assertOutputContains("Missing nameservice ID");
        assertEquals(-1, runTool("-ns", "ns1"));
        assertOutputContains("Missing command");
        // "ns1" isn't defined but we check this lazily and help doesn't use the ns
        assertEquals(0, runTool("-ns", "ns1", "-help", "transitionToActive"));
        assertOutputContains("Transitions the service into Active");
    }

    @Test
    public void testNamenodeResolution() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        assertEquals(0, runTool("-getServiceState", "nn1"));
        Mockito.verify(ZVGITCSTEK).getServiceStatus();
        assertEquals(-1, runTool("-getServiceState", "undefined"));
        assertOutputContains("Unable to determine service address for namenode 'undefined'");
    }

    @Test
    public void testHelp() throws Exception {
        assertEquals(0, runTool("-help"));
        assertEquals(0, runTool("-help", "transitionToActive"));
        assertOutputContains("Transitions the service into Active");
    }

    @Test
    public void testTransitionToActive() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        assertEquals(0, runTool("-transitionToActive", "nn1"));
        Mockito.verify(ZVGITCSTEK).transitionToActive(UHOPPJTGVP.capture());
        assertEquals(RequestSource.REQUEST_BY_USER, UHOPPJTGVP.getValue().getSource());
    }

    /**
     * Test that, if automatic HA is enabled, none of the mutative operations
     * will succeed, unless the -forcemanual flag is specified.
     *
     * @throws Exception
     * 		
     */
    @Test
    public void testMutativeOperationsWithAutoHaEnabled() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        // Turn on auto-HA in the config
        HdfsConfiguration WDLUMEINQH = getHAConf();
        WDLUMEINQH.setBoolean(DFS_HA_AUTO_FAILOVER_ENABLED_KEY, true);
        WDLUMEINQH.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(WDLUMEINQH);
        // Should fail without the forcemanual flag
        assertEquals(-1, runTool("-transitionToActive", "nn1"));
        assertTrue(HPFRDARRDB.contains("Refusing to manually manage"));
        assertEquals(-1, runTool("-transitionToStandby", "nn1"));
        assertTrue(HPFRDARRDB.contains("Refusing to manually manage"));
        Mockito.verify(ZVGITCSTEK, Mockito.never()).transitionToActive(anyReqInfo());
        Mockito.verify(ZVGITCSTEK, Mockito.never()).transitionToStandby(anyReqInfo());
        // Force flag should bypass the check and change the request source
        // for the RPC
        TestDFSHAAdmin.setupConfirmationOnSystemIn();
        assertEquals(0, runTool("-transitionToActive", "-forcemanual", "nn1"));
        TestDFSHAAdmin.setupConfirmationOnSystemIn();
        assertEquals(0, runTool("-transitionToStandby", "-forcemanual", "nn1"));
        Mockito.verify(ZVGITCSTEK, Mockito.times(1)).transitionToActive(UHOPPJTGVP.capture());
        Mockito.verify(ZVGITCSTEK, Mockito.times(1)).transitionToStandby(UHOPPJTGVP.capture());
        // All of the RPCs should have had the "force" source
        for (StateChangeRequestInfo GZFUAAWKWR : UHOPPJTGVP.getAllValues()) {
            assertEquals(RequestSource.REQUEST_BY_USER_FORCED, GZFUAAWKWR.getSource());
        }
    }

    /**
     * Setup System.in with a stream that feeds a "yes" answer on the
     * next prompt.
     */
    private static void setupConfirmationOnSystemIn() {
        // Answer "yes" to the prompt about transition to active
        System.setIn(new ByteArrayInputStream("yes\n".getBytes()));
    }

    /**
     * Test that, even if automatic HA is enabled, the monitoring operations
     * still function correctly.
     */
    @Test
    public void testMonitoringOperationsWithAutoHaEnabled() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        // Turn on auto-HA
        HdfsConfiguration UKGMRUGNLN = getHAConf();
        UKGMRUGNLN.setBoolean(DFS_HA_AUTO_FAILOVER_ENABLED_KEY, true);
        JSHZPLVRUL.setConf(UKGMRUGNLN);
        assertEquals(0, runTool("-checkHealth", "nn1"));
        Mockito.verify(ZVGITCSTEK).monitorHealth();
        assertEquals(0, runTool("-getServiceState", "nn1"));
        Mockito.verify(ZVGITCSTEK).getServiceStatus();
    }

    @Test
    public void testTransitionToStandby() throws Exception {
        assertEquals(0, runTool("-transitionToStandby", "nn1"));
        Mockito.verify(ZVGITCSTEK).transitionToStandby(anyReqInfo());
    }

    @Test
    public void testFailoverWithNoFencerConfigured() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        assertEquals(-1, runTool("-failover", "nn1", "nn2"));
    }

    @Test
    public void testFailoverWithFencerConfigured() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        HdfsConfiguration HXRYMRXOTF = getHAConf();
        HXRYMRXOTF.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(HXRYMRXOTF);
        assertEquals(0, runTool("-failover", "nn1", "nn2"));
    }

    @Test
    public void testFailoverWithFencerAndNameservice() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        HdfsConfiguration RUMXPSDADT = getHAConf();
        RUMXPSDADT.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(RUMXPSDADT);
        assertEquals(0, runTool("-ns", "ns1", "-failover", "nn1", "nn2"));
    }

    @Test
    public void testFailoverWithFencerConfiguredAndForce() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        HdfsConfiguration OIXUQHGKQN = getHAConf();
        OIXUQHGKQN.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(OIXUQHGKQN);
        assertEquals(0, runTool("-failover", "nn1", "nn2", "--forcefence"));
    }

    @Test
    public void testFailoverWithForceActive() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        HdfsConfiguration QNDLPRPFGV = getHAConf();
        QNDLPRPFGV.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(QNDLPRPFGV);
        assertEquals(0, runTool("-failover", "nn1", "nn2", "--forceactive"));
    }

    @Test
    public void testFailoverWithInvalidFenceArg() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        HdfsConfiguration GMEERQOFGF = getHAConf();
        GMEERQOFGF.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(GMEERQOFGF);
        assertEquals(-1, runTool("-failover", "nn1", "nn2", "notforcefence"));
    }

    @Test
    public void testFailoverWithFenceButNoFencer() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        assertEquals(-1, runTool("-failover", "nn1", "nn2", "--forcefence"));
    }

    @Test
    public void testFailoverWithFenceAndBadFencer() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        HdfsConfiguration ZSBVSGSKTL = getHAConf();
        ZSBVSGSKTL.set(DFS_HA_FENCE_METHODS_KEY, "foobar!");
        JSHZPLVRUL.setConf(ZSBVSGSKTL);
        assertEquals(-1, runTool("-failover", "nn1", "nn2", "--forcefence"));
    }

    @Test
    public void testFailoverWithAutoHa() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        // Turn on auto-HA in the config
        HdfsConfiguration ZQVVIEOPRO = getHAConf();
        ZQVVIEOPRO.setBoolean(DFS_HA_AUTO_FAILOVER_ENABLED_KEY, true);
        ZQVVIEOPRO.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(ZQVVIEOPRO);
        assertEquals(0, runTool("-failover", "nn1", "nn2"));
        Mockito.verify(IFSKQBLGSZ).gracefulFailover();
    }

    @Test
    public void testForceFenceOptionListedBeforeArgs() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        HdfsConfiguration ZEWNZOIARU = getHAConf();
        ZEWNZOIARU.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(ZEWNZOIARU);
        assertEquals(0, runTool("-failover", "--forcefence", "nn1", "nn2"));
    }

    @Test
    public void testGetServiceStatus() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        assertEquals(0, runTool("-getServiceState", "nn1"));
        Mockito.verify(ZVGITCSTEK).getServiceStatus();
    }

    @Test
    public void testCheckHealth() throws Exception {
        assertEquals(0, runTool("-checkHealth", "nn1"));
        Mockito.verify(ZVGITCSTEK).monitorHealth();
        Mockito.doThrow(new org.apache.hadoop.ha.HealthCheckFailedException("fake health check failure")).when(ZVGITCSTEK).monitorHealth();
        assertEquals(-1, runTool("-checkHealth", "nn1"));
        assertOutputContains("Health check failed: fake health check failure");
    }

    /**
     * Test that the fencing configuration can be overridden per-nameservice
     * or per-namenode
     */
    @Test
    public void testFencingConfigPerNameNode() throws Exception {
        Mockito.doReturn(TestDFSHAAdmin.IOTOLLDFEO).when(ZVGITCSTEK).getServiceStatus();
        final String KRQGXXEQNW = (DFSConfigKeys.DFS_HA_FENCE_METHODS_KEY + ".") + TestDFSHAAdmin.NHPANNSJUQ;
        final String YFUSWQPNZC = KRQGXXEQNW + ".nn1";
        HdfsConfiguration AELQPTVVJT = getHAConf();
        // Set the default fencer to succeed
        AELQPTVVJT.set(DFS_HA_FENCE_METHODS_KEY, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(AELQPTVVJT);
        assertEquals(0, runTool("-failover", "nn1", "nn2", "--forcefence"));
        // Set the NN-specific fencer to fail. Should fail to fence.
        AELQPTVVJT.set(YFUSWQPNZC, TestDFSHAAdmin.getFencerFalseCommand());
        JSHZPLVRUL.setConf(AELQPTVVJT);
        assertEquals(-1, runTool("-failover", "nn1", "nn2", "--forcefence"));
        AELQPTVVJT.unset(YFUSWQPNZC);
        // Set an NS-specific fencer to fail. Should fail.
        AELQPTVVJT.set(KRQGXXEQNW, TestDFSHAAdmin.getFencerFalseCommand());
        JSHZPLVRUL.setConf(AELQPTVVJT);
        assertEquals(-1, runTool("-failover", "nn1", "nn2", "--forcefence"));
        // Set the NS-specific fencer to succeed. Should succeed
        AELQPTVVJT.set(KRQGXXEQNW, TestDFSHAAdmin.getFencerTrueCommand());
        JSHZPLVRUL.setConf(AELQPTVVJT);
        assertEquals(0, runTool("-failover", "nn1", "nn2", "--forcefence"));
    }

    private Object runTool(String... JDDDXXEJQE) throws Exception {
        ULVXZXIPCC.reset();
        UNNVIZXZWS.reset();
        TestDFSHAAdmin.IAXWDDUBHK.info("Running: DFSHAAdmin " + com.google.common.base.Joiner.on(" ").join(JDDDXXEJQE));
        int MJWFHBLZAC = JSHZPLVRUL.run(JDDDXXEJQE);
        HPFRDARRDB = new String(ULVXZXIPCC.toByteArray(), Charsets.UTF_8);
        XZBPTYMBIU = new String(UNNVIZXZWS.toByteArray(), Charsets.UTF_8);
        TestDFSHAAdmin.IAXWDDUBHK.info((("Err_output:\n" + HPFRDARRDB) + "\nOutput:\n") + XZBPTYMBIU);
        return MJWFHBLZAC;
    }

    private StateChangeRequestInfo anyReqInfo() {
        return Mockito.any();
    }
}