public class TestFifoScheduler {
    private static final Log FGONSSNRZQ = LogFactory.getLog(TestFifoScheduler.class);

    private final int YYEESZXDNO = 1024;

    private static YarnConfiguration CRNOYZRGHV;

    @BeforeClass
    public static void setup() {
        TestFifoScheduler.CRNOYZRGHV = new YarnConfiguration();
        TestFifoScheduler.CRNOYZRGHV.setClass(RM_SCHEDULER, FifoScheduler.class, ResourceScheduler.class);
    }

    @Test(timeout = 30000)
    public void testConfValidation() throws Exception {
        FifoScheduler PTYOEBVXKY = new FifoScheduler();
        Configuration EFDZWLMNSN = new YarnConfiguration();
        EFDZWLMNSN.setInt(RM_SCHEDULER_MINIMUM_ALLOCATION_MB, 2048);
        EFDZWLMNSN.setInt(RM_SCHEDULER_MAXIMUM_ALLOCATION_MB, 1024);
        try {
            PTYOEBVXKY.serviceInit(EFDZWLMNSN);
            fail("Exception is expected because the min memory allocation is" + " larger than the max memory allocation.");
        } catch (YarnRuntimeException e) {
            // Exception is expected.
            assertTrue("The thrown exception is not the expected one.", e.getMessage().startsWith("Invalid resource scheduler memory"));
        }
    }

    @Test
    public void testAllocateContainerOnNodeWithoutOffSwitchSpecified() throws Exception {
        Logger GBOBNDGZZH = LogManager.getRootLogger();
        GBOBNDGZZH.setLevel(Level.DEBUG);
        MockRM IFVDDVUYII = new MockRM(TestFifoScheduler.CRNOYZRGHV);
        IFVDDVUYII.start();
        MockNM FHBBSDJVAF = IFVDDVUYII.registerNode("127.0.0.1:1234", 6 * YYEESZXDNO);
        RMApp PJIVWINLWY = IFVDDVUYII.submitApp(2048);
        // kick the scheduling, 2 GB given to AM1, remaining 4GB on nm1
        FHBBSDJVAF.nodeHeartbeat(true);
        RMAppAttempt ZDNMZGSRZZ = PJIVWINLWY.getCurrentAppAttempt();
        MockAM HKMMFFQOUJ = IFVDDVUYII.sendAMLaunched(ZDNMZGSRZZ.getAppAttemptId());
        HKMMFFQOUJ.registerAppAttempt();
        // add request for containers
        List<ResourceRequest> VRKBWTHGZC = new ArrayList<ResourceRequest>();
        VRKBWTHGZC.add(HKMMFFQOUJ.createResourceReq("127.0.0.1", 1 * YYEESZXDNO, 1, 1));
        VRKBWTHGZC.add(HKMMFFQOUJ.createResourceReq("/default-rack", 1 * YYEESZXDNO, 1, 1));
        HKMMFFQOUJ.allocate(VRKBWTHGZC, null);// send the request

        try {
            // kick the schedule
            FHBBSDJVAF.nodeHeartbeat(true);
        } catch (NullPointerException e) {
            Assert.fail("NPE when allocating container on node but " + "forget to set off-switch request should be handled");
        }
    }

    @Test
    public void test() throws Exception {
        Logger ZCQCAPPGDP = LogManager.getRootLogger();
        ZCQCAPPGDP.setLevel(Level.DEBUG);
        MockRM JKBTONFDMT = new MockRM(TestFifoScheduler.CRNOYZRGHV);
        JKBTONFDMT.start();
        MockNM YSXLRKEMFJ = JKBTONFDMT.registerNode("127.0.0.1:1234", 6 * YYEESZXDNO);
        MockNM FPBTRGMALR = JKBTONFDMT.registerNode("127.0.0.2:5678", 4 * YYEESZXDNO);
        RMApp GNJWFXCGSL = JKBTONFDMT.submitApp(2048);
        // kick the scheduling, 2 GB given to AM1, remaining 4GB on nm1
        YSXLRKEMFJ.nodeHeartbeat(true);
        RMAppAttempt FZFFFPBBGK = GNJWFXCGSL.getCurrentAppAttempt();
        MockAM PWLBXWEVTV = JKBTONFDMT.sendAMLaunched(FZFFFPBBGK.getAppAttemptId());
        PWLBXWEVTV.registerAppAttempt();
        SchedulerNodeReport BTKUHFRIPU = JKBTONFDMT.getResourceScheduler().getNodeReport(YSXLRKEMFJ.getNodeId());
        Assert.assertEquals(2 * YYEESZXDNO, BTKUHFRIPU.getUsedResource().getMemory());
        RMApp QLKRADUIHR = JKBTONFDMT.submitApp(2048);
        // kick the scheduling, 2GB given to AM, remaining 2 GB on nm2
        FPBTRGMALR.nodeHeartbeat(true);
        RMAppAttempt PKKVGRJRSB = QLKRADUIHR.getCurrentAppAttempt();
        MockAM RLBOZYUGVW = JKBTONFDMT.sendAMLaunched(PKKVGRJRSB.getAppAttemptId());
        RLBOZYUGVW.registerAppAttempt();
        SchedulerNodeReport LSIORBCZKH = JKBTONFDMT.getResourceScheduler().getNodeReport(FPBTRGMALR.getNodeId());
        Assert.assertEquals(2 * YYEESZXDNO, LSIORBCZKH.getUsedResource().getMemory());
        // add request for containers
        PWLBXWEVTV.addRequests(new String[]{ "127.0.0.1", "127.0.0.2" }, YYEESZXDNO, 1, 1);
        AllocateResponse RCILOODWKL = PWLBXWEVTV.schedule();// send the request

        // add request for containers
        RLBOZYUGVW.addRequests(new String[]{ "127.0.0.1", "127.0.0.2" }, 3 * YYEESZXDNO, 0, 1);
        AllocateResponse KCTBMUEZAD = RLBOZYUGVW.schedule();// send the request

        // kick the scheduler, 1 GB and 3 GB given to AM1 and AM2, remaining 0
        YSXLRKEMFJ.nodeHeartbeat(true);
        while (RCILOODWKL.getAllocatedContainers().size() < 1) {
            TestFifoScheduler.FGONSSNRZQ.info("Waiting for containers to be created for app 1...");
            Thread.sleep(1000);
            RCILOODWKL = PWLBXWEVTV.schedule();
        } 
        while (KCTBMUEZAD.getAllocatedContainers().size() < 1) {
            TestFifoScheduler.FGONSSNRZQ.info("Waiting for containers to be created for app 2...");
            Thread.sleep(1000);
            KCTBMUEZAD = RLBOZYUGVW.schedule();
        } 
        // kick the scheduler, nothing given remaining 2 GB.
        FPBTRGMALR.nodeHeartbeat(true);
        List<Container> MKYICLLMEX = RCILOODWKL.getAllocatedContainers();
        Assert.assertEquals(1, MKYICLLMEX.size());
        Assert.assertEquals(1 * YYEESZXDNO, MKYICLLMEX.get(0).getResource().getMemory());
        Assert.assertEquals(YSXLRKEMFJ.getNodeId(), MKYICLLMEX.get(0).getNodeId());
        List<Container> OXVXJHOKXE = KCTBMUEZAD.getAllocatedContainers();
        Assert.assertEquals(1, OXVXJHOKXE.size());
        Assert.assertEquals(3 * YYEESZXDNO, OXVXJHOKXE.get(0).getResource().getMemory());
        Assert.assertEquals(YSXLRKEMFJ.getNodeId(), OXVXJHOKXE.get(0).getNodeId());
        BTKUHFRIPU = JKBTONFDMT.getResourceScheduler().getNodeReport(YSXLRKEMFJ.getNodeId());
        LSIORBCZKH = JKBTONFDMT.getResourceScheduler().getNodeReport(FPBTRGMALR.getNodeId());
        Assert.assertEquals(0, BTKUHFRIPU.getAvailableResource().getMemory());
        Assert.assertEquals(2 * YYEESZXDNO, LSIORBCZKH.getAvailableResource().getMemory());
        Assert.assertEquals(6 * YYEESZXDNO, BTKUHFRIPU.getUsedResource().getMemory());
        Assert.assertEquals(2 * YYEESZXDNO, LSIORBCZKH.getUsedResource().getMemory());
        Container BTXJEALUIH = MKYICLLMEX.get(0);
        Assert.assertEquals(YYEESZXDNO, BTXJEALUIH.getResource().getMemory());
        ContainerStatus TIFLIMTZQO = BuilderUtils.newContainerStatus(BTXJEALUIH.getId(), COMPLETE, "", 0);
        YSXLRKEMFJ.containerStatus(TIFLIMTZQO);
        int TUMGRVLMJT = 0;
        while ((FZFFFPBBGK.getJustFinishedContainers().size() < 1) && ((TUMGRVLMJT++) != 20)) {
            TestFifoScheduler.FGONSSNRZQ.info(("Waiting for containers to be finished for app 1... Tried " + TUMGRVLMJT) + " times already..");
            Thread.sleep(1000);
        } 
        Assert.assertEquals(1, FZFFFPBBGK.getJustFinishedContainers().size());
        Assert.assertEquals(1, PWLBXWEVTV.schedule().getCompletedContainersStatuses().size());
        BTKUHFRIPU = JKBTONFDMT.getResourceScheduler().getNodeReport(YSXLRKEMFJ.getNodeId());
        Assert.assertEquals(5 * YYEESZXDNO, BTKUHFRIPU.getUsedResource().getMemory());
        JKBTONFDMT.stop();
    }

    @Test
    public void testNodeUpdateBeforeAppAttemptInit() throws Exception {
        FifoScheduler LCOFJRDNCK = new FifoScheduler();
        MockRM EGGGSTRELJ = new MockRM(TestFifoScheduler.CRNOYZRGHV);
        LCOFJRDNCK.setRMContext(EGGGSTRELJ.getRMContext());
        LCOFJRDNCK.init(TestFifoScheduler.CRNOYZRGHV);
        LCOFJRDNCK.start();
        LCOFJRDNCK.reinitialize(TestFifoScheduler.CRNOYZRGHV, EGGGSTRELJ.getRMContext());
        RMNode CFILIQIKPX = MockNodes.newNodeInfo(1, Resources.createResource(1024, 4), 1, "127.0.0.1");
        LCOFJRDNCK.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(CFILIQIKPX));
        ApplicationId ZIANPVBAHM = ApplicationId.newInstance(0, 1);
        LCOFJRDNCK.addApplication(ZIANPVBAHM, "queue1", "user1", false);
        NodeUpdateSchedulerEvent REUXJZKGUJ = new NodeUpdateSchedulerEvent(CFILIQIKPX);
        try {
            LCOFJRDNCK.handle(REUXJZKGUJ);
        } catch (NullPointerException e) {
            Assert.fail();
        }
        ApplicationAttemptId IALBWADMMF = ApplicationAttemptId.newInstance(ZIANPVBAHM, 1);
        LCOFJRDNCK.addApplicationAttempt(IALBWADMMF, false, false);
        EGGGSTRELJ.stop();
    }

    private void testMinimumAllocation(YarnConfiguration ZYAGLTSTCS, int BJJDXCSAFA) throws Exception {
        MockRM TPSMAFUQCJ = new MockRM(ZYAGLTSTCS);
        TPSMAFUQCJ.start();
        // Register node1
        MockNM BXFVZEAFQP = TPSMAFUQCJ.registerNode("127.0.0.1:1234", 6 * YYEESZXDNO);
        // Submit an application
        RMApp VXKFZJUWGJ = TPSMAFUQCJ.submitApp(BJJDXCSAFA);
        // kick the scheduling
        BXFVZEAFQP.nodeHeartbeat(true);
        RMAppAttempt GKRVJKGXWD = VXKFZJUWGJ.getCurrentAppAttempt();
        MockAM FYPSPDTDBW = TPSMAFUQCJ.sendAMLaunched(GKRVJKGXWD.getAppAttemptId());
        FYPSPDTDBW.registerAppAttempt();
        SchedulerNodeReport NJSOIBTJZU = TPSMAFUQCJ.getResourceScheduler().getNodeReport(BXFVZEAFQP.getNodeId());
        int SCIDCGSMNC = ZYAGLTSTCS.getInt(RM_SCHEDULER_MINIMUM_ALLOCATION_MB, DEFAULT_RM_SCHEDULER_MINIMUM_ALLOCATION_MB);
        Assert.assertEquals(SCIDCGSMNC, NJSOIBTJZU.getUsedResource().getMemory());
        TPSMAFUQCJ.stop();
    }

    @Test
    public void testDefaultMinimumAllocation() throws Exception {
        // Test with something lesser than default
        testMinimumAllocation(new YarnConfiguration(TestFifoScheduler.CRNOYZRGHV), YarnConfiguration.DEFAULT_RM_SCHEDULER_MINIMUM_ALLOCATION_MB / 2);
    }

    @Test
    public void testNonDefaultMinimumAllocation() throws Exception {
        // Set custom min-alloc to test tweaking it
        int VSXVOBRUZX = 1536;
        YarnConfiguration LFVYHCDQXI = new YarnConfiguration(TestFifoScheduler.CRNOYZRGHV);
        LFVYHCDQXI.setInt(RM_SCHEDULER_MINIMUM_ALLOCATION_MB, VSXVOBRUZX);
        LFVYHCDQXI.setInt(RM_SCHEDULER_MAXIMUM_ALLOCATION_MB, VSXVOBRUZX * 10);
        // Test for something lesser than this.
        testMinimumAllocation(LFVYHCDQXI, VSXVOBRUZX / 2);
    }

    @Test(timeout = 50000)
    public void testReconnectedNode() throws Exception {
        CapacitySchedulerConfiguration ODBLHFSKCJ = new CapacitySchedulerConfiguration();
        ODBLHFSKCJ.setQueues("default", new String[]{ "default" });
        ODBLHFSKCJ.setCapacity("default", 100);
        FifoScheduler BRWJUYZVBD = new FifoScheduler();
        BRWJUYZVBD.init(ODBLHFSKCJ);
        BRWJUYZVBD.start();
        // mock rmContext to avoid NPE.
        RMContext ZNQTGVKDOK = mock(RMContext.class);
        BRWJUYZVBD.reinitialize(ODBLHFSKCJ, null);
        BRWJUYZVBD.setRMContext(ZNQTGVKDOK);
        RMNode YUUYCYKMKW = MockNodes.newNodeInfo(0, MockNodes.newResource(4 * YYEESZXDNO), 1, "127.0.0.2");
        RMNode MEFLLEISJL = MockNodes.newNodeInfo(0, MockNodes.newResource(2 * YYEESZXDNO), 2, "127.0.0.3");
        BRWJUYZVBD.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(YUUYCYKMKW));
        BRWJUYZVBD.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(MEFLLEISJL));
        BRWJUYZVBD.handle(new NodeUpdateSchedulerEvent(YUUYCYKMKW));
        Assert.assertEquals(6 * YYEESZXDNO, BRWJUYZVBD.getRootQueueMetrics().getAvailableMB());
        // reconnect n1 with downgraded memory
        YUUYCYKMKW = MockNodes.newNodeInfo(0, MockNodes.newResource(2 * YYEESZXDNO), 1, "127.0.0.2");
        BRWJUYZVBD.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeRemovedSchedulerEvent(YUUYCYKMKW));
        BRWJUYZVBD.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(YUUYCYKMKW));
        BRWJUYZVBD.handle(new NodeUpdateSchedulerEvent(YUUYCYKMKW));
        Assert.assertEquals(4 * YYEESZXDNO, BRWJUYZVBD.getRootQueueMetrics().getAvailableMB());
        BRWJUYZVBD.stop();
    }

    @Test(timeout = 50000)
    public void testBlackListNodes() throws Exception {
        Configuration OTQCPBTUAS = new Configuration();
        OTQCPBTUAS.setClass(RM_SCHEDULER, FifoScheduler.class, ResourceScheduler.class);
        MockRM OHWIEOVBPH = new MockRM(OTQCPBTUAS);
        OHWIEOVBPH.start();
        FifoScheduler HTHQWOKNMH = ((FifoScheduler) (OHWIEOVBPH.getResourceScheduler()));
        int MELTXKVISG = 0;
        int CSBVMRBORZ = 1;
        // Add 4 nodes in 2 racks
        // host_0_0 in rack0
        String XTIWKDKQTB = "127.0.0.1";
        RMNode SKJLQSKBTF = MockNodes.newNodeInfo(MELTXKVISG, MockNodes.newResource(4 * YYEESZXDNO), 1, XTIWKDKQTB);
        HTHQWOKNMH.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(SKJLQSKBTF));
        // host_0_1 in rack0
        String XGQFZITFTF = "127.0.0.2";
        RMNode QKKFVHZOUJ = MockNodes.newNodeInfo(MELTXKVISG, MockNodes.newResource(4 * YYEESZXDNO), 1, XGQFZITFTF);
        HTHQWOKNMH.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(QKKFVHZOUJ));
        // host_1_0 in rack1
        String UGESGHWZJO = "127.0.0.3";
        RMNode VAPVYOIUKQ = MockNodes.newNodeInfo(CSBVMRBORZ, MockNodes.newResource(4 * YYEESZXDNO), 1, UGESGHWZJO);
        HTHQWOKNMH.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(VAPVYOIUKQ));
        // host_1_1 in rack1
        String PRZRDBNESZ = "127.0.0.4";
        RMNode VWJLTOJWKZ = MockNodes.newNodeInfo(CSBVMRBORZ, MockNodes.newResource(4 * YYEESZXDNO), 1, PRZRDBNESZ);
        HTHQWOKNMH.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(VWJLTOJWKZ));
        // Add one application
        ApplicationId ACJDDQAAYI = BuilderUtils.newApplicationId(100, 1);
        ApplicationAttemptId TADWWEEMMB = BuilderUtils.newApplicationAttemptId(ACJDDQAAYI, 1);
        SchedulerEvent ZODBRNATWI = new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.AppAddedSchedulerEvent(ACJDDQAAYI, "queue", "user");
        HTHQWOKNMH.handle(ZODBRNATWI);
        SchedulerEvent XTCSYAIXDO = new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.AppAttemptAddedSchedulerEvent(TADWWEEMMB, false);
        HTHQWOKNMH.handle(XTCSYAIXDO);
        List<ContainerId> QEETMWAMWL = new ArrayList<ContainerId>();
        List<ResourceRequest> JWIRTRRODS = new ArrayList<ResourceRequest>();
        // Allow rack-locality for rack_1, but blacklist host_1_0
        // Set up resource requests
        // Ask for a 1 GB container for app 1
        List<ResourceRequest> GQSWXSRHMA = new ArrayList<ResourceRequest>();
        GQSWXSRHMA.add(BuilderUtils.newResourceRequest(BuilderUtils.newPriority(0), "rack1", BuilderUtils.newResource(YYEESZXDNO, 1), 1));
        GQSWXSRHMA.add(BuilderUtils.newResourceRequest(BuilderUtils.newPriority(0), ANY, BuilderUtils.newResource(YYEESZXDNO, 1), 1));
        HTHQWOKNMH.allocate(TADWWEEMMB, GQSWXSRHMA, QEETMWAMWL, Collections.singletonList(UGESGHWZJO), null);
        // Trigger container assignment
        HTHQWOKNMH.handle(new NodeUpdateSchedulerEvent(VAPVYOIUKQ));
        // Get the allocation for the application and verify no allocation on blacklist node
        Allocation KEWFYNKECV = HTHQWOKNMH.allocate(TADWWEEMMB, JWIRTRRODS, QEETMWAMWL, null, null);
        Assert.assertEquals("allocation1", 0, KEWFYNKECV.getContainers().size());
        // verify host_1_1 can get allocated as not in blacklist
        HTHQWOKNMH.handle(new NodeUpdateSchedulerEvent(VWJLTOJWKZ));
        Allocation XRKPUYHJUL = HTHQWOKNMH.allocate(TADWWEEMMB, JWIRTRRODS, QEETMWAMWL, null, null);
        Assert.assertEquals("allocation2", 1, XRKPUYHJUL.getContainers().size());
        List<Container> ZVZCBMCEBD = XRKPUYHJUL.getContainers();
        for (Container UZOMUMNUPR : ZVZCBMCEBD) {
            Assert.assertEquals("Container is allocated on n4", UZOMUMNUPR.getNodeId(), VWJLTOJWKZ.getNodeID());
        }
        // Ask for a 1 GB container again for app 1
        List<ResourceRequest> KXKQNJTMJQ = new ArrayList<ResourceRequest>();
        // this time, rack0 is also in blacklist, so only host_1_1 is available to
        // be assigned
        KXKQNJTMJQ.add(BuilderUtils.newResourceRequest(BuilderUtils.newPriority(0), ANY, BuilderUtils.newResource(YYEESZXDNO, 1), 1));
        HTHQWOKNMH.allocate(TADWWEEMMB, KXKQNJTMJQ, QEETMWAMWL, Collections.singletonList("rack0"), null);
        // verify n1 is not qualified to be allocated
        HTHQWOKNMH.handle(new NodeUpdateSchedulerEvent(SKJLQSKBTF));
        Allocation LLTYJFVIPW = HTHQWOKNMH.allocate(TADWWEEMMB, JWIRTRRODS, QEETMWAMWL, null, null);
        Assert.assertEquals("allocation3", 0, LLTYJFVIPW.getContainers().size());
        // verify n2 is not qualified to be allocated
        HTHQWOKNMH.handle(new NodeUpdateSchedulerEvent(QKKFVHZOUJ));
        Allocation QPPIKWMKXK = HTHQWOKNMH.allocate(TADWWEEMMB, JWIRTRRODS, QEETMWAMWL, null, null);
        Assert.assertEquals("allocation4", 0, QPPIKWMKXK.getContainers().size());
        // verify n3 is not qualified to be allocated
        HTHQWOKNMH.handle(new NodeUpdateSchedulerEvent(VAPVYOIUKQ));
        Allocation IZZDZQVZXC = HTHQWOKNMH.allocate(TADWWEEMMB, JWIRTRRODS, QEETMWAMWL, null, null);
        Assert.assertEquals("allocation5", 0, IZZDZQVZXC.getContainers().size());
        HTHQWOKNMH.handle(new NodeUpdateSchedulerEvent(VWJLTOJWKZ));
        Allocation BBPDCMJZYP = HTHQWOKNMH.allocate(TADWWEEMMB, JWIRTRRODS, QEETMWAMWL, null, null);
        Assert.assertEquals("allocation6", 1, BBPDCMJZYP.getContainers().size());
        ZVZCBMCEBD = BBPDCMJZYP.getContainers();
        for (Container MGBPXWRULI : ZVZCBMCEBD) {
            Assert.assertEquals("Container is allocated on n4", MGBPXWRULI.getNodeId(), VWJLTOJWKZ.getNodeID());
        }
        OHWIEOVBPH.stop();
    }

    @Test(timeout = 50000)
    public void testHeadroom() throws Exception {
        Configuration ZWJXQDWCPB = new Configuration();
        ZWJXQDWCPB.setClass(RM_SCHEDULER, FifoScheduler.class, ResourceScheduler.class);
        MockRM UDIPHDQJEV = new MockRM(ZWJXQDWCPB);
        UDIPHDQJEV.start();
        FifoScheduler BAAUSFVPWY = ((FifoScheduler) (UDIPHDQJEV.getResourceScheduler()));
        // Add a node
        RMNode OUWHCNDMUQ = MockNodes.newNodeInfo(0, MockNodes.newResource(4 * YYEESZXDNO), 1, "127.0.0.2");
        BAAUSFVPWY.handle(new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.NodeAddedSchedulerEvent(OUWHCNDMUQ));
        // Add two applications
        ApplicationId YKHYPYUOYR = BuilderUtils.newApplicationId(100, 1);
        ApplicationAttemptId VTVYVFFGUW = BuilderUtils.newApplicationAttemptId(YKHYPYUOYR, 1);
        SchedulerEvent CBGIHFQENH = new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.AppAddedSchedulerEvent(YKHYPYUOYR, "queue", "user");
        BAAUSFVPWY.handle(CBGIHFQENH);
        SchedulerEvent EUVGRFHCYQ = new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.AppAttemptAddedSchedulerEvent(VTVYVFFGUW, false);
        BAAUSFVPWY.handle(EUVGRFHCYQ);
        ApplicationId OOTQNKTQNN = BuilderUtils.newApplicationId(200, 2);
        ApplicationAttemptId QYTJJLEQFV = BuilderUtils.newApplicationAttemptId(OOTQNKTQNN, 1);
        SchedulerEvent HNCMGTFZVE = new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.AppAddedSchedulerEvent(OOTQNKTQNN, "queue", "user");
        BAAUSFVPWY.handle(HNCMGTFZVE);
        SchedulerEvent YOTZRJHERP = new org.apache.hadoop.yarn.server.resourcemanager.scheduler.event.AppAttemptAddedSchedulerEvent(QYTJJLEQFV, false);
        BAAUSFVPWY.handle(YOTZRJHERP);
        List<ContainerId> MHWEKPZQJH = new ArrayList<ContainerId>();
        List<ResourceRequest> ZDQZTNNXJQ = new ArrayList<ResourceRequest>();
        // Set up resource requests
        // Ask for a 1 GB container for app 1
        List<ResourceRequest> BVPDFTMCYT = new ArrayList<ResourceRequest>();
        BVPDFTMCYT.add(BuilderUtils.newResourceRequest(BuilderUtils.newPriority(0), ANY, BuilderUtils.newResource(YYEESZXDNO, 1), 1));
        BAAUSFVPWY.allocate(VTVYVFFGUW, BVPDFTMCYT, MHWEKPZQJH, null, null);
        // Ask for a 2 GB container for app 2
        List<ResourceRequest> JWMFCRRYFA = new ArrayList<ResourceRequest>();
        JWMFCRRYFA.add(BuilderUtils.newResourceRequest(BuilderUtils.newPriority(0), ANY, BuilderUtils.newResource(2 * YYEESZXDNO, 1), 1));
        BAAUSFVPWY.allocate(QYTJJLEQFV, JWMFCRRYFA, MHWEKPZQJH, null, null);
        // Trigger container assignment
        BAAUSFVPWY.handle(new NodeUpdateSchedulerEvent(OUWHCNDMUQ));
        // Get the allocation for the applications and verify headroom
        Allocation TUNLKSIADH = BAAUSFVPWY.allocate(VTVYVFFGUW, ZDQZTNNXJQ, MHWEKPZQJH, null, null);
        Assert.assertEquals("Allocation headroom", 1 * YYEESZXDNO, TUNLKSIADH.getResourceLimit().getMemory());
        Allocation UPFAPXNLHZ = BAAUSFVPWY.allocate(QYTJJLEQFV, ZDQZTNNXJQ, MHWEKPZQJH, null, null);
        Assert.assertEquals("Allocation headroom", 1 * YYEESZXDNO, UPFAPXNLHZ.getResourceLimit().getMemory());
        UDIPHDQJEV.stop();
    }

    public static void main(String[] BZEOISHFYO) throws Exception {
        TestFifoScheduler TKKVQAXZAQ = new TestFifoScheduler();
        TKKVQAXZAQ.test();
        TKKVQAXZAQ.testDefaultMinimumAllocation();
        TKKVQAXZAQ.testNonDefaultMinimumAllocation();
        TKKVQAXZAQ.testReconnectedNode();
    }
}