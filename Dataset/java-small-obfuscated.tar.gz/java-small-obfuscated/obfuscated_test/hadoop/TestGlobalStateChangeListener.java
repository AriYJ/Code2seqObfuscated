/**
 * Test global state changes. It is critical for all tests to clean up the
 * global listener afterwards to avoid interfering with follow-on tests.
 *
 * One listener, {@link #listener} is defined which is automatically
 * unregistered on cleanup. All other listeners must be unregistered in the
 * finally clauses of the tests.
 */
public class TestGlobalStateChangeListener extends ServiceAssert {
    BreakableStateChangeListener IEDJPFGORT = new BreakableStateChangeListener("listener");

    private void register() {
        register(IEDJPFGORT);
    }

    private boolean unregister() {
        return unregister(IEDJPFGORT);
    }

    private void register(ServiceStateChangeListener WTEWEFLJLC) {
        AbstractService.registerGlobalListener(WTEWEFLJLC);
    }

    private boolean unregister(ServiceStateChangeListener ENOJYCASJQ) {
        return AbstractService.unregisterGlobalListener(ENOJYCASJQ);
    }

    /**
     * After every test case reset the list of global listeners.
     */
    @After
    public void cleanup() {
        AbstractService.resetGlobalListeners();
    }

    /**
     * Assert that the last state of the listener is that the test expected.
     *
     * @param breakable
     * 		a breakable listener
     * @param state
     * 		the expected state
     */
    public void assertListenerState(BreakableStateChangeListener IQDQZGXCJS, Service.STATE KRICFVUNVD) {
        assertEquals("Wrong state in " + IQDQZGXCJS, KRICFVUNVD, IQDQZGXCJS.getLastState());
    }

    /**
     * Assert that the number of state change notifications matches expectations.
     *
     * @param breakable
     * 		the listener
     * @param count
     * 		the expected count.
     */
    public void assertListenerEventCount(BreakableStateChangeListener KJIOJEZYPS, int RVQZTVGQAA) {
        assertEquals("Wrong event count in " + KJIOJEZYPS, RVQZTVGQAA, KJIOJEZYPS.getEventCount());
    }

    /**
     * Test that register/unregister works
     */
    @Test
    public void testRegisterListener() {
        register();
        assertTrue("listener not registered", unregister());
    }

    /**
     * Test that double registration results in one registration only.
     */
    @Test
    public void testRegisterListenerTwice() {
        register();
        register();
        assertTrue("listener not registered", unregister());
        // there should be no listener to unregister the second time
        assertFalse("listener double registered", unregister());
    }

    /**
     * Test that the {@link BreakableStateChangeListener} is picking up
     * the state changes and that its last event field is as expected.
     */
    @Test
    public void testEventHistory() {
        register();
        BreakableService WZSHAMIHVM = new BreakableService();
        assertListenerState(IEDJPFGORT, NOTINITED);
        assertEquals(0, IEDJPFGORT.getEventCount());
        WZSHAMIHVM.init(new Configuration());
        assertListenerState(IEDJPFGORT, INITED);
        assertSame(WZSHAMIHVM, IEDJPFGORT.getLastService());
        assertListenerEventCount(IEDJPFGORT, 1);
        WZSHAMIHVM.start();
        assertListenerState(IEDJPFGORT, STARTED);
        assertListenerEventCount(IEDJPFGORT, 2);
        WZSHAMIHVM.stop();
        assertListenerState(IEDJPFGORT, STOPPED);
        assertListenerEventCount(IEDJPFGORT, 3);
    }

    /**
     * This test triggers a failure in the listener - the expectation is that the
     * service has already reached it's desired state, purely because the
     * notifications take place afterwards.
     */
    @Test
    public void testListenerFailure() {
        IEDJPFGORT.setFailingState(INITED);
        register();
        BreakableStateChangeListener ZUDTWREQMG = new BreakableStateChangeListener();
        register(ZUDTWREQMG);
        BreakableService IPKBIHNECP = new BreakableService();
        IPKBIHNECP.init(new Configuration());
        // expected notifications to fail
        // still should record its invocation
        assertListenerState(IEDJPFGORT, INITED);
        assertListenerEventCount(IEDJPFGORT, 1);
        // and second listener didn't get notified of anything
        assertListenerEventCount(ZUDTWREQMG, 0);
        // service should still consider itself started
        assertServiceStateInited(IPKBIHNECP);
        IPKBIHNECP.start();
        IPKBIHNECP.stop();
    }

    /**
     * Create a chain of listeners and set one in the middle to fail; verify that
     * those in front got called, and those after did not.
     */
    @Test
    public void testListenerChain() {
        // create and register the listeners
        LoggingStateChangeListener RXXMZCYBYQ = new LoggingStateChangeListener();
        register(RXXMZCYBYQ);
        BreakableStateChangeListener GFTSJIHYBS = new BreakableStateChangeListener("l0");
        register(GFTSJIHYBS);
        IEDJPFGORT.setFailingState(STARTED);
        register();
        BreakableStateChangeListener KTZTKHNKRW = new BreakableStateChangeListener("l3");
        register(KTZTKHNKRW);
        // create and init a service.
        BreakableService QFZSXQIBFP = new BreakableService();
        QFZSXQIBFP.init(new Configuration());
        assertServiceStateInited(QFZSXQIBFP);
        assertListenerState(GFTSJIHYBS, INITED);
        assertListenerState(IEDJPFGORT, INITED);
        assertListenerState(KTZTKHNKRW, INITED);
        QFZSXQIBFP.start();
        // expect that listener l1 and the failing listener are in start, but
        // not the final one
        assertServiceStateStarted(QFZSXQIBFP);
        assertListenerState(GFTSJIHYBS, STARTED);
        assertListenerEventCount(GFTSJIHYBS, 2);
        assertListenerState(IEDJPFGORT, STARTED);
        assertListenerEventCount(IEDJPFGORT, 2);
        // this is the listener that is not expected to have been invoked
        assertListenerState(KTZTKHNKRW, INITED);
        assertListenerEventCount(KTZTKHNKRW, 1);
        // stop the service
        QFZSXQIBFP.stop();
        // listeners are all updated
        assertListenerEventCount(GFTSJIHYBS, 3);
        assertListenerEventCount(IEDJPFGORT, 3);
        assertListenerEventCount(KTZTKHNKRW, 2);
        // can all be unregistered in any order
        unregister(RXXMZCYBYQ);
        unregister(GFTSJIHYBS);
        unregister(KTZTKHNKRW);
        // check that the listeners are all unregistered, even
        // though they were registered in a different order.
        // rather than do this by doing unregister checks, a new service is created
        QFZSXQIBFP = new BreakableService();
        // this service is initialized
        QFZSXQIBFP.init(new Configuration());
        // it is asserted that the event count has not changed for the unregistered
        // listeners
        assertListenerEventCount(GFTSJIHYBS, 3);
        assertListenerEventCount(KTZTKHNKRW, 2);
        // except for the one listener that was not unregistered, which
        // has incremented by one
        assertListenerEventCount(IEDJPFGORT, 4);
    }
}