/**
 * A utility to easily test threaded/synchronized code.
 * Utility works by letting you add threads that do some work to a
 * test context object, and then lets you kick them all off to stress test
 * your parallel code.
 *
 * Also propagates thread exceptions back to the runner, to let you verify.
 *
 * An example:
 *
 * <code>
 *  final AtomicInteger threadsRun = new AtomicInteger();
 *
 *  TestContext ctx = new TestContext();
 *  // Add 3 threads to test.
 *  for (int i = 0; i < 3; i++) {
 *    ctx.addThread(new TestingThread(ctx) {
 *
 * @unknown public void doWork() throws Exception {
threadsRun.incrementAndGet();
}
});
}
ctx.startThreads();
// Set a timeout period for threads to complete.
ctx.waitFor(30000);
assertEquals(3, threadsRun.get());
</code>

For repetitive actions, use the {@link MultithreadedTestUtil.RepeatingThread}
instead.

(More examples can be found in {@link TestMultithreadedTestUtil})
 */
public abstract class MultithreadedTestUtil {
    public static final Log AAUXKWHGDD = LogFactory.getLog(MultithreadedTestUtil.class);

    /**
     * TestContext is used to setup the multithreaded test runner.
     * It lets you add threads, run them, wait upon or stop them.
     */
    public static class TestContext {
        private Throwable HHZPOFSWES = null;

        private boolean OALCYHIUQD = false;

        private Set<MultithreadedTestUtil.TestingThread> UOKMFRYVGP = new HashSet<MultithreadedTestUtil.TestingThread>();

        private Set<MultithreadedTestUtil.TestingThread> IJPFKXZOLX = new HashSet<MultithreadedTestUtil.TestingThread>();

        /**
         * Check if the context can run threads.
         * Can't if its been stopped and contains an error.
         *
         * @return true if it can run, false if it can't.
         */
        public synchronized boolean shouldRun() {
            return (!OALCYHIUQD) && (HHZPOFSWES == null);
        }

        /**
         * Add a thread to the context for running.
         * Threads can be of type {@link MultithreadedTestUtil.TestingThread}
         * or {@link MultithreadedTestUtil.RepeatingTestThread}
         * or other custom derivatives of the former.
         *
         * @param t
         * 		the thread to add for running.
         */
        public void addThread(MultithreadedTestUtil.TestingThread t) {
            UOKMFRYVGP.add(t);
        }

        /**
         * Starts all test threads that have been added so far.
         */
        public void startThreads() {
            for (MultithreadedTestUtil.TestingThread t : UOKMFRYVGP) {
                t.start();
            }
        }

        /**
         * Waits for threads to finish or error out.
         *
         * @param millis
         * 		the number of milliseconds to wait
         * 		for threads to complete.
         * @throws Exception
         * 		if one or more of the threads
         * 		have thrown up an error.
         */
        public synchronized void waitFor(long millis) throws Exception {
            long endTime = Time.now() + millis;
            while (shouldRun() && (IJPFKXZOLX.size() < UOKMFRYVGP.size())) {
                long left = endTime - Time.now();
                if (left <= 0)
                    break;

                checkException();
                wait(left);
            } 
            checkException();
        }

        /**
         * Checks for thread exceptions, and if they've occurred
         * throws them as RuntimeExceptions in a deferred manner.
         */
        public synchronized void checkException() throws Exception {
            if (HHZPOFSWES != null) {
                throw new RuntimeException("Deferred", HHZPOFSWES);
            }
        }

        /**
         * Called by {@link MultithreadedTestUtil.TestingThread}s to signal
         * a failed thread.
         *
         * @param t
         * 		the thread that failed.
         */
        public synchronized void threadFailed(Throwable t) {
            if (HHZPOFSWES == null)
                HHZPOFSWES = t;

            MultithreadedTestUtil.AAUXKWHGDD.error("Failed!", HHZPOFSWES);
            notify();
        }

        /**
         * Called by {@link MultithreadedTestUtil.TestingThread}s to signal
         * a successful completion.
         *
         * @param t
         * 		the thread that finished.
         */
        public synchronized void threadDone(MultithreadedTestUtil.TestingThread t) {
            IJPFKXZOLX.add(t);
            notify();
        }

        /**
         * Returns after stopping all threads by joining them back.
         *
         * @throws Exception
         * 		in case a thread terminated with a failure.
         */
        public void stop() throws Exception {
            synchronized(this) {
                OALCYHIUQD = true;
            }
            for (MultithreadedTestUtil.TestingThread t : UOKMFRYVGP) {
                t.join();
            }
            checkException();
        }

        public Iterable<? extends Thread> getTestThreads() {
            return UOKMFRYVGP;
        }
    }

    /**
     * A thread that can be added to a test context, and properly
     * passes exceptions through.
     */
    public static abstract class TestingThread extends Thread {
        protected final MultithreadedTestUtil.TestContext WZIEETNAXC;

        protected boolean ZLDWCSGLSN;

        public TestingThread(MultithreadedTestUtil.TestContext ctx) {
            this.WZIEETNAXC = ctx;
        }

        @Override
        public void run() {
            try {
                doWork();
            } catch (Throwable t) {
                WZIEETNAXC.threadFailed(t);
            }
            WZIEETNAXC.threadDone(this);
        }

        /**
         * User method to add any code to test thread behavior of.
         *
         * @throws Exception
         * 		throw an exception if a failure has occurred.
         */
        public abstract void doWork() throws Exception;

        protected void stopTestThread() {
            this.ZLDWCSGLSN = true;
        }
    }

    /**
     * A test thread that performs a repeating operation.
     */
    public static abstract class RepeatingTestThread extends MultithreadedTestUtil.TestingThread {
        public RepeatingTestThread(MultithreadedTestUtil.TestContext ctx) {
            super(ctx);
        }

        /**
         * Repeats a given user action until the context is asked to stop
         * or meets an error.
         */
        @Override
        public final void doWork() throws Exception {
            while (WZIEETNAXC.shouldRun() && (!ZLDWCSGLSN)) {
                doAnAction();
            } 
        }

        /**
         * User method for any code to test repeating behavior of (as threads).
         *
         * @throws Exception
         * 		throw an exception if a failure has occured.
         */
        public abstract void doAnAction() throws Exception;
    }
}