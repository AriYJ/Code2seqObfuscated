/**
 * Before all tests, a MiniDFSCluster is spun up.
 * Before each test, mock refresh handlers are created and registered.
 * After each test, the mock handlers are unregistered.
 * After all tests, the cluster is spun down.
 */
public class TestGenericRefresh {
    private static MiniDFSCluster TGTWTQEBVR;

    private static Configuration IEVCBKKIOG;

    private static RefreshHandler VKGPIFWIYM;

    private static RefreshHandler GENWHLPEJB;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        TestGenericRefresh.IEVCBKKIOG = new Configuration();
        TestGenericRefresh.IEVCBKKIOG.set("hadoop.security.authorization", "true");
        FileSystem.setDefaultUri(TestGenericRefresh.IEVCBKKIOG, "hdfs://localhost:0");
        TestGenericRefresh.TGTWTQEBVR = new MiniDFSCluster.Builder(TestGenericRefresh.IEVCBKKIOG).build();
        TestGenericRefresh.TGTWTQEBVR.waitActive();
    }

    @AfterClass
    public static void tearDownBeforeClass() throws Exception {
        if (TestGenericRefresh.TGTWTQEBVR != null) {
            TestGenericRefresh.TGTWTQEBVR.shutdown();
        }
    }

    @Before
    public void setUp() throws Exception {
        // Register Handlers, first one just sends an ok response
        TestGenericRefresh.VKGPIFWIYM = Mockito.mock(RefreshHandler.class);
        Mockito.stub(TestGenericRefresh.VKGPIFWIYM.handleRefresh(Mockito.anyString(), Mockito.any(String[].class))).toReturn(RefreshResponse.successResponse());
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("firstHandler", TestGenericRefresh.VKGPIFWIYM);
        // Second handler has conditional response for testing args
        TestGenericRefresh.GENWHLPEJB = Mockito.mock(RefreshHandler.class);
        Mockito.stub(TestGenericRefresh.GENWHLPEJB.handleRefresh("secondHandler", new String[]{ "one", "two" })).toReturn(new RefreshResponse(3, "three"));
        Mockito.stub(TestGenericRefresh.GENWHLPEJB.handleRefresh("secondHandler", new String[]{ "one" })).toReturn(new RefreshResponse(2, "two"));
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("secondHandler", TestGenericRefresh.GENWHLPEJB);
    }

    @After
    public void tearDown() throws Exception {
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().unregisterAll("firstHandler");
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().unregisterAll("secondHandler");
    }

    @Test
    public void testInvalidCommand() throws Exception {
        DFSAdmin FIZFLKMWZJ = new DFSAdmin(TestGenericRefresh.IEVCBKKIOG);
        String[] HWYMXWLJDW = new String[]{ "-refresh", "nn" };
        int RPPNPCZIBR = FIZFLKMWZJ.run(HWYMXWLJDW);
        assertEquals("DFSAdmin should fail due to bad args", -1, RPPNPCZIBR);
    }

    @Test
    public void testInvalidIdentifier() throws Exception {
        DFSAdmin VEHDEQNYJA = new DFSAdmin(TestGenericRefresh.IEVCBKKIOG);
        String[] XHPMDQSZOP = new String[]{ "-refresh", "localhost:" + TestGenericRefresh.TGTWTQEBVR.getNameNodePort(), "unregisteredIdentity" };
        int PQHFDAMPCR = VEHDEQNYJA.run(XHPMDQSZOP);
        assertEquals("DFSAdmin should fail due to no handler registered", -1, PQHFDAMPCR);
    }

    @Test
    public void testValidIdentifier() throws Exception {
        DFSAdmin FVABDKJXXY = new DFSAdmin(TestGenericRefresh.IEVCBKKIOG);
        String[] YLZLUMVQYC = new String[]{ "-refresh", "localhost:" + TestGenericRefresh.TGTWTQEBVR.getNameNodePort(), "firstHandler" };
        int DHANKDFAGZ = FVABDKJXXY.run(YLZLUMVQYC);
        assertEquals("DFSAdmin should succeed", 0, DHANKDFAGZ);
        Mockito.verify(TestGenericRefresh.VKGPIFWIYM).handleRefresh("firstHandler", new String[]{  });
        // Second handler was never called
        Mockito.verify(TestGenericRefresh.GENWHLPEJB, Mockito.never()).handleRefresh(Mockito.anyString(), Mockito.any(String[].class));
    }

    @Test
    public void testVariableArgs() throws Exception {
        DFSAdmin VWETGFUOKP = new DFSAdmin(TestGenericRefresh.IEVCBKKIOG);
        String[] ZWIRBFYJPL = new String[]{ "-refresh", "localhost:" + TestGenericRefresh.TGTWTQEBVR.getNameNodePort(), "secondHandler", "one" };
        int JADYYQINVN = VWETGFUOKP.run(ZWIRBFYJPL);
        assertEquals("DFSAdmin should return 2", 2, JADYYQINVN);
        JADYYQINVN = VWETGFUOKP.run(new String[]{ "-refresh", "localhost:" + TestGenericRefresh.TGTWTQEBVR.getNameNodePort(), "secondHandler", "one", "two" });
        assertEquals("DFSAdmin should now return 3", 3, JADYYQINVN);
        Mockito.verify(TestGenericRefresh.GENWHLPEJB).handleRefresh("secondHandler", new String[]{ "one" });
        Mockito.verify(TestGenericRefresh.GENWHLPEJB).handleRefresh("secondHandler", new String[]{ "one", "two" });
    }

    @Test
    public void testUnregistration() throws Exception {
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().unregisterAll("firstHandler");
        // And now this should fail
        DFSAdmin JDERORDFTR = new DFSAdmin(TestGenericRefresh.IEVCBKKIOG);
        String[] SMUDGJMRDB = new String[]{ "-refresh", "localhost:" + TestGenericRefresh.TGTWTQEBVR.getNameNodePort(), "firstHandler" };
        int VIRQBNYRYN = JDERORDFTR.run(SMUDGJMRDB);
        assertEquals("DFSAdmin should return -1", -1, VIRQBNYRYN);
    }

    @Test
    public void testUnregistrationReturnValue() {
        RefreshHandler ETOWIEBYTF = Mockito.mock(RefreshHandler.class);
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("test", ETOWIEBYTF);
        boolean BAISNDLPTZ = org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().unregister("test", ETOWIEBYTF);
        assertTrue(BAISNDLPTZ);
    }

    @Test
    public void testMultipleRegistration() throws Exception {
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("sharedId", TestGenericRefresh.VKGPIFWIYM);
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("sharedId", TestGenericRefresh.GENWHLPEJB);
        // this should trigger both
        DFSAdmin PYAEOYZWSQ = new DFSAdmin(TestGenericRefresh.IEVCBKKIOG);
        String[] HQYMVMDOMY = new String[]{ "-refresh", "localhost:" + TestGenericRefresh.TGTWTQEBVR.getNameNodePort(), "sharedId", "one" };
        int XRWPVLUBCP = PYAEOYZWSQ.run(HQYMVMDOMY);
        assertEquals(-1, XRWPVLUBCP);// -1 because one of the responses is unregistered

        // verify we called both
        Mockito.verify(TestGenericRefresh.VKGPIFWIYM).handleRefresh("sharedId", new String[]{ "one" });
        Mockito.verify(TestGenericRefresh.GENWHLPEJB).handleRefresh("sharedId", new String[]{ "one" });
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().unregisterAll("sharedId");
    }

    @Test
    public void testMultipleReturnCodeMerging() throws Exception {
        // Two handlers which return two non-zero values
        RefreshHandler GGLTPOAPIV = Mockito.mock(RefreshHandler.class);
        Mockito.stub(GGLTPOAPIV.handleRefresh(Mockito.anyString(), Mockito.any(String[].class))).toReturn(new RefreshResponse(23, "Twenty Three"));
        RefreshHandler CRUNFYBJED = Mockito.mock(RefreshHandler.class);
        Mockito.stub(CRUNFYBJED.handleRefresh(Mockito.anyString(), Mockito.any(String[].class))).toReturn(new RefreshResponse(10, "Ten"));
        // Then registered to the same ID
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("shared", GGLTPOAPIV);
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("shared", CRUNFYBJED);
        // We refresh both
        DFSAdmin CLMIWWYLYS = new DFSAdmin(TestGenericRefresh.IEVCBKKIOG);
        String[] GQGHBUSVAR = new String[]{ "-refresh", "localhost:" + TestGenericRefresh.TGTWTQEBVR.getNameNodePort(), "shared" };
        int EVQAVLJOGG = CLMIWWYLYS.run(GQGHBUSVAR);
        assertEquals(-1, EVQAVLJOGG);// We get -1 because of our logic for melding non-zero return codes

        // Verify we called both
        Mockito.verify(GGLTPOAPIV).handleRefresh("shared", new String[]{  });
        Mockito.verify(CRUNFYBJED).handleRefresh("shared", new String[]{  });
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().unregisterAll("shared");
    }

    @Test
    public void testExceptionResultsInNormalError() throws Exception {
        // In this test, we ensure that all handlers are called even if we throw an exception in one
        RefreshHandler WIMOQJXQBO = Mockito.mock(RefreshHandler.class);
        Mockito.stub(WIMOQJXQBO.handleRefresh(Mockito.anyString(), Mockito.any(String[].class))).toThrow(new RuntimeException("Exceptional Handler Throws Exception"));
        RefreshHandler NGYPKBBJZO = Mockito.mock(RefreshHandler.class);
        Mockito.stub(NGYPKBBJZO.handleRefresh(Mockito.anyString(), Mockito.any(String[].class))).toThrow(new RuntimeException("More Exceptions"));
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("exceptional", WIMOQJXQBO);
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().register("exceptional", NGYPKBBJZO);
        DFSAdmin IEZUPQPUON = new DFSAdmin(TestGenericRefresh.IEVCBKKIOG);
        String[] EJLYYQWDHS = new String[]{ "-refresh", "localhost:" + TestGenericRefresh.TGTWTQEBVR.getNameNodePort(), "exceptional" };
        int MWHXJLQGMK = IEZUPQPUON.run(EJLYYQWDHS);
        assertEquals(-1, MWHXJLQGMK);// Exceptions result in a -1

        Mockito.verify(WIMOQJXQBO).handleRefresh("exceptional", new String[]{  });
        Mockito.verify(NGYPKBBJZO).handleRefresh("exceptional", new String[]{  });
        org.apache.hadoop.ipc.RefreshRegistry.defaultRegistry().unregisterAll("exceptional");
    }
}