public class ContainerLaunch implements Callable<Integer> {
    private static final Log DAPHWHWVHA = LogFactory.getLog(ContainerLaunch.class);

    public static final String GGCWIWLHEQ = Shell.appendScriptExtension("launch_container");

    public static final String WSSVQSOIHJ = "container_tokens";

    private static final String ZBIWRXJDVU = "%s.pid";

    private static final String XNEDFOAVPP = ".exitcode";

    protected final Dispatcher CHIZQISUYQ;

    protected final ContainerExecutor UTDNRGWEXJ;

    private final Application BSUJJUROAD;

    protected final Container RPSDWYOKAU;

    private final Configuration QQLXCCVDMZ;

    private final Context BJSZQGBBOG;

    private final ContainerManagerImpl UJCYCVRBTS;

    protected AtomicBoolean CTTTRQLBAW = new AtomicBoolean(false);

    protected AtomicBoolean HHEJFFEZSL = new AtomicBoolean(false);

    private long WHENPTRSKY = 250;

    private long XEVNWLCYQR = 2000;

    protected Path QCNIATWJBS = null;

    private final LocalDirsHandlerService RKOMQZEUVR;

    public ContainerLaunch(Context UUILVXIQSC, Configuration UIQBYTDOWU, Dispatcher UESGLOMNKP, ContainerExecutor XFHPHORDOH, Application OMTFXYYKKJ, Container JUWEKUPVQS, LocalDirsHandlerService PLSVIUEGKX, ContainerManagerImpl OKLUDLMOCY) {
        this.BJSZQGBBOG = UUILVXIQSC;
        this.QQLXCCVDMZ = UIQBYTDOWU;
        this.BSUJJUROAD = OMTFXYYKKJ;
        this.UTDNRGWEXJ = XFHPHORDOH;
        this.RPSDWYOKAU = JUWEKUPVQS;
        this.CHIZQISUYQ = UESGLOMNKP;
        this.RKOMQZEUVR = PLSVIUEGKX;
        this.UJCYCVRBTS = OKLUDLMOCY;
        this.WHENPTRSKY = QQLXCCVDMZ.getLong(NM_SLEEP_DELAY_BEFORE_SIGKILL_MS, DEFAULT_NM_SLEEP_DELAY_BEFORE_SIGKILL_MS);
        this.XEVNWLCYQR = QQLXCCVDMZ.getLong(NM_PROCESS_KILL_WAIT_MS, DEFAULT_NM_PROCESS_KILL_WAIT_MS);
    }

    @VisibleForTesting
    public static String expandEnvironment(String QDPKKZCRFT, Path AYIOEKWMWM) {
        QDPKKZCRFT = QDPKKZCRFT.replace(LOG_DIR_EXPANSION_VAR, AYIOEKWMWM.toString());
        QDPKKZCRFT = QDPKKZCRFT.replace(CLASS_PATH_SEPARATOR, File.pathSeparator);
        // replace parameter expansion marker. e.g. {{VAR}} on Windows is replaced
        // as %VAR% and on Linux replaced as "$VAR"
        if (Shell.WINDOWS) {
            QDPKKZCRFT = QDPKKZCRFT.replaceAll("(\\{\\{)|(\\}\\})", "%");
        } else {
            QDPKKZCRFT = QDPKKZCRFT.replace(PARAMETER_EXPANSION_LEFT, "$");
            QDPKKZCRFT = QDPKKZCRFT.replace(PARAMETER_EXPANSION_RIGHT, "");
        }
        return QDPKKZCRFT;
    }

    // dispatcher not typed
    @Override
    @SuppressWarnings("unchecked")
    public Integer call() {
        final ContainerLaunchContext OXWJOPZCOR = RPSDWYOKAU.getLaunchContext();
        Map<Path, List<String>> LONCXCRIRN = null;
        ContainerId BYTGPRHRXC = RPSDWYOKAU.getContainerId();
        String CVNNSJTSWR = ConverterUtils.toString(BYTGPRHRXC);
        final List<String> HQQBFRWFQS = OXWJOPZCOR.getCommands();
        int ZFUESJPKZI = -1;
        // CONTAINER_KILLED_ON_REQUEST should not be missed if the container
        // is already at KILLING
        if (RPSDWYOKAU.getContainerState() == ContainerState.KILLING) {
            CHIZQISUYQ.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerExitEvent(BYTGPRHRXC, ContainerEventType.CONTAINER_KILLED_ON_REQUEST, Shell.WINDOWS ? FORCE_KILLED.getExitCode() : TERMINATED.getExitCode(), "Container terminated before launch."));
            return 0;
        }
        try {
            LONCXCRIRN = RPSDWYOKAU.getLocalizedResources();
            if (LONCXCRIRN == null) {
                throw RPCUtil.getRemoteException((("Unable to get local resources when Container " + BYTGPRHRXC) + " is at ") + RPSDWYOKAU.getContainerState());
            }
            final String CTWFYOZHMJ = RPSDWYOKAU.getUser();
            // /////////////////////////// Variable expansion
            // Before the container script gets written out.
            List<String> SGKFCMPBMO = new ArrayList<String>(HQQBFRWFQS.size());
            String FPPLDCMNHK = BSUJJUROAD.getAppId().toString();
            String RQICJSNUPZ = ContainerLaunch.getRelativeContainerLogDir(FPPLDCMNHK, CVNNSJTSWR);
            Path VFATVOHTRH = RKOMQZEUVR.getLogPathForWrite(RQICJSNUPZ, false);
            for (String AOFFNMXFRG : HQQBFRWFQS) {
                // TODO: Should we instead work via symlinks without this grammar?
                SGKFCMPBMO.add(ContainerLaunch.expandEnvironment(AOFFNMXFRG, VFATVOHTRH));
            }
            OXWJOPZCOR.setCommands(SGKFCMPBMO);
            Map<String, String> EHSXXWFJRA = OXWJOPZCOR.getEnvironment();
            // Make a copy of env to iterate & do variable expansion
            for (Map.Entry<String, String> XNHEUKCDCF : EHSXXWFJRA.entrySet()) {
                String KCVEKJGGIY = XNHEUKCDCF.getValue();
                KCVEKJGGIY = ContainerLaunch.expandEnvironment(KCVEKJGGIY, VFATVOHTRH);
                XNHEUKCDCF.setValue(KCVEKJGGIY);
            }
            // /////////////////////////// End of variable expansion
            FileContext SNMCUWYHDG = FileContext.getLocalFSFileContext();
            Path EXELWONFDO = RKOMQZEUVR.getLocalPathForWrite((getContainerPrivateDir(FPPLDCMNHK, CVNNSJTSWR) + Path.SEPARATOR) + ContainerLaunch.GGCWIWLHEQ);
            Path ZOYIJMLZFY = RKOMQZEUVR.getLocalPathForWrite((getContainerPrivateDir(FPPLDCMNHK, CVNNSJTSWR) + Path.SEPARATOR) + String.format(TOKEN_FILE_NAME_FMT, CVNNSJTSWR));
            DataOutputStream QEJIVPTRRL = null;
            DataOutputStream OLVIYMSAFW = null;
            // Select the working directory for the container
            Path GSILRBUNPX = RKOMQZEUVR.getLocalPathForWrite((((((((ContainerLocalizer.USERCACHE + Path.SEPARATOR) + CTWFYOZHMJ) + Path.SEPARATOR) + ContainerLocalizer.APPCACHE) + Path.SEPARATOR) + FPPLDCMNHK) + Path.SEPARATOR) + CVNNSJTSWR, SIZE_UNKNOWN, false);
            String LILYLASAKQ = getPidFileSubpath(FPPLDCMNHK, CVNNSJTSWR);
            // pid file should be in nm private dir so that it is not
            // accessible by users
            QCNIATWJBS = RKOMQZEUVR.getLocalPathForWrite(LILYLASAKQ);
            List<String> UTTRPTVDOY = RKOMQZEUVR.getLocalDirs();
            List<String> UESXXAXVQH = RKOMQZEUVR.getLogDirs();
            List<String> CCGHSLYIQY = new ArrayList<String>();
            for (String RPYUFTVWJX : UESXXAXVQH) {
                CCGHSLYIQY.add((RPYUFTVWJX + Path.SEPARATOR) + RQICJSNUPZ);
            }
            if (!RKOMQZEUVR.areDisksHealthy()) {
                ZFUESJPKZI = ContainerExitStatus.DISKS_FAILED;
                throw new IOException("Most of the disks failed. " + RKOMQZEUVR.getDisksHealthReport());
            }
            try {
                // /////////// Write out the container-script in the nmPrivate space.
                List<Path> XFTIBNSQJW = new ArrayList<Path>(UTTRPTVDOY.size());
                for (String RXGXLHQIDL : UTTRPTVDOY) {
                    Path GMEIRMDMUW = new Path(RXGXLHQIDL, ContainerLocalizer.USERCACHE);
                    Path NPZXDTESAE = new Path(GMEIRMDMUW, CTWFYOZHMJ);
                    Path PAGGMTRLEH = new Path(NPZXDTESAE, ContainerLocalizer.APPCACHE);
                    XFTIBNSQJW.add(new Path(PAGGMTRLEH, FPPLDCMNHK));
                }
                QEJIVPTRRL = SNMCUWYHDG.create(EXELWONFDO, EnumSet.of(CREATE, OVERWRITE));
                // Set the token location too.
                EHSXXWFJRA.put(CONTAINER_TOKEN_FILE_ENV_NAME, new Path(GSILRBUNPX, ContainerLaunch.WSSVQSOIHJ).toUri().getPath());
                // Sanitize the container's environment
                sanitizeEnv(EHSXXWFJRA, GSILRBUNPX, XFTIBNSQJW, CCGHSLYIQY, LONCXCRIRN);
                // Write out the environment
                ContainerLaunch.writeLaunchEnv(QEJIVPTRRL, EHSXXWFJRA, LONCXCRIRN, OXWJOPZCOR.getCommands());
                // /////////// End of writing out container-script
                // /////////// Write out the container-tokens in the nmPrivate space.
                OLVIYMSAFW = SNMCUWYHDG.create(ZOYIJMLZFY, EnumSet.of(CREATE, OVERWRITE));
                Credentials FDWQQJRHIA = RPSDWYOKAU.getCredentials();
                FDWQQJRHIA.writeTokenStorageToStream(OLVIYMSAFW);
                // /////////// End of writing out container-tokens
            } finally {
                IOUtils.cleanup(ContainerLaunch.DAPHWHWVHA, QEJIVPTRRL, OLVIYMSAFW);
            }
            // LaunchContainer is a blocking call. We are here almost means the
            // container is launched, so send out the event.
            CHIZQISUYQ.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerEvent(BYTGPRHRXC, ContainerEventType.CONTAINER_LAUNCHED));
            BJSZQGBBOG.getNMStateStore().storeContainerLaunched(BYTGPRHRXC);
            // Check if the container is signalled to be killed.
            if (!CTTTRQLBAW.compareAndSet(false, true)) {
                ContainerLaunch.DAPHWHWVHA.info((("Container " + CVNNSJTSWR) + " not launched as ") + "cleanup already called");
                ZFUESJPKZI = TERMINATED.getExitCode();
            } else {
                UTDNRGWEXJ.activateContainer(BYTGPRHRXC, QCNIATWJBS);
                ZFUESJPKZI = UTDNRGWEXJ.launchContainer(RPSDWYOKAU, EXELWONFDO, ZOYIJMLZFY, CTWFYOZHMJ, FPPLDCMNHK, GSILRBUNPX, UTTRPTVDOY, UESXXAXVQH);
            }
        } catch (Throwable e) {
            ContainerLaunch.DAPHWHWVHA.warn("Failed to launch container.", e);
            CHIZQISUYQ.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerExitEvent(BYTGPRHRXC, ContainerEventType.CONTAINER_EXITED_WITH_FAILURE, ZFUESJPKZI, e.getMessage()));
            return ZFUESJPKZI;
        } finally {
            HHEJFFEZSL.set(true);
            UTDNRGWEXJ.deactivateContainer(BYTGPRHRXC);
            try {
                BJSZQGBBOG.getNMStateStore().storeContainerCompleted(BYTGPRHRXC, ZFUESJPKZI);
            } catch (IOException e) {
                ContainerLaunch.DAPHWHWVHA.error("Unable to set exit code for container " + BYTGPRHRXC);
            }
        }
        if (ContainerLaunch.DAPHWHWVHA.isDebugEnabled()) {
            ContainerLaunch.DAPHWHWVHA.debug((("Container " + CVNNSJTSWR) + " completed with exit code ") + ZFUESJPKZI);
        }
        if ((ZFUESJPKZI == FORCE_KILLED.getExitCode()) || (ZFUESJPKZI == TERMINATED.getExitCode())) {
            // If the process was killed, Send container_cleanedup_after_kill and
            // just break out of this method.
            CHIZQISUYQ.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerExitEvent(BYTGPRHRXC, ContainerEventType.CONTAINER_KILLED_ON_REQUEST, ZFUESJPKZI, "Container exited with a non-zero exit code " + ZFUESJPKZI));
            return ZFUESJPKZI;
        }
        if (ZFUESJPKZI != 0) {
            ContainerLaunch.DAPHWHWVHA.warn("Container exited with a non-zero exit code " + ZFUESJPKZI);
            this.CHIZQISUYQ.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerExitEvent(BYTGPRHRXC, ContainerEventType.CONTAINER_EXITED_WITH_FAILURE, ZFUESJPKZI, "Container exited with a non-zero exit code " + ZFUESJPKZI));
            return ZFUESJPKZI;
        }
        ContainerLaunch.DAPHWHWVHA.info(("Container " + CVNNSJTSWR) + " succeeded ");
        CHIZQISUYQ.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerEvent(BYTGPRHRXC, ContainerEventType.CONTAINER_EXITED_WITH_SUCCESS));
        return 0;
    }

    protected String getPidFileSubpath(String WKDTELTNER, String LDUWNAXRGQ) {
        return (getContainerPrivateDir(WKDTELTNER, LDUWNAXRGQ) + Path.SEPARATOR) + String.format(ContainerLaunch.ZBIWRXJDVU, LDUWNAXRGQ);
    }

    /**
     * Cleanup the container.
     * Cancels the launch if launch has not started yet or signals
     * the executor to not execute the process if not already done so.
     * Also, sends a SIGTERM followed by a SIGKILL to the process if
     * the process id is available.
     *
     * @throws IOException
     * 		
     */
    // dispatcher not typed
    @SuppressWarnings("unchecked")
    public void cleanupContainer() throws IOException {
        ContainerId LIVQHPNXGN = RPSDWYOKAU.getContainerId();
        String QKRNQRUWCP = ConverterUtils.toString(LIVQHPNXGN);
        ContainerLaunch.DAPHWHWVHA.info("Cleaning up container " + QKRNQRUWCP);
        try {
            BJSZQGBBOG.getNMStateStore().storeContainerKilled(LIVQHPNXGN);
        } catch (IOException e) {
            ContainerLaunch.DAPHWHWVHA.error(("Unable to mark container " + LIVQHPNXGN) + " killed in store", e);
        }
        // launch flag will be set to true if process already launched
        boolean HOBREZBZZV = !CTTTRQLBAW.compareAndSet(false, true);
        if (!HOBREZBZZV) {
            ContainerLaunch.DAPHWHWVHA.info((("Container " + QKRNQRUWCP) + " not launched.") + " No cleanup needed to be done");
            return;
        }
        ContainerLaunch.DAPHWHWVHA.debug(("Marking container " + QKRNQRUWCP) + " as inactive");
        // this should ensure that if the container process has not launched
        // by this time, it will never be launched
        UTDNRGWEXJ.deactivateContainer(LIVQHPNXGN);
        if (ContainerLaunch.DAPHWHWVHA.isDebugEnabled()) {
            ContainerLaunch.DAPHWHWVHA.debug(((("Getting pid for container " + QKRNQRUWCP) + " to kill") + " from pid file ") + (QCNIATWJBS != null ? QCNIATWJBS.toString() : "null"));
        }
        // however the container process may have already started
        try {
            // get process id from pid file if available
            // else if shell is still active, get it from the shell
            String GZMXMEIPLP = null;
            if (QCNIATWJBS != null) {
                GZMXMEIPLP = getContainerPid(QCNIATWJBS);
            }
            // kill process
            if (GZMXMEIPLP != null) {
                String ECLIFHUCKM = RPSDWYOKAU.getUser();
                ContainerLaunch.DAPHWHWVHA.debug((((("Sending signal to pid " + GZMXMEIPLP) + " as user ") + ECLIFHUCKM) + " for container ") + QKRNQRUWCP);
                final Signal BYGFCIERRJ = (WHENPTRSKY > 0) ? Signal.TERM : Signal.KILL;
                boolean QRHHQAVZLR = UTDNRGWEXJ.signalContainer(ECLIFHUCKM, GZMXMEIPLP, BYGFCIERRJ);
                ContainerLaunch.DAPHWHWVHA.debug((((((((("Sent signal " + BYGFCIERRJ) + " to pid ") + GZMXMEIPLP) + " as user ") + ECLIFHUCKM) + " for container ") + QKRNQRUWCP) + ", result=") + (QRHHQAVZLR ? "success" : "failed"));
                if (WHENPTRSKY > 0) {
                    new org.apache.hadoop.yarn.server.nodemanager.ContainerExecutor.DelayedProcessKiller(RPSDWYOKAU, ECLIFHUCKM, GZMXMEIPLP, WHENPTRSKY, Signal.KILL, UTDNRGWEXJ).start();
                }
            }
        } catch (Exception e) {
            String DLBIHLSJGE = (("Exception when trying to cleanup container " + QKRNQRUWCP) + ": ") + StringUtils.stringifyException(e);
            ContainerLaunch.DAPHWHWVHA.warn(DLBIHLSJGE);
            CHIZQISUYQ.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerDiagnosticsUpdateEvent(LIVQHPNXGN, DLBIHLSJGE));
        } finally {
            // cleanup pid file if present
            if (QCNIATWJBS != null) {
                FileContext RCLJZEURHM = FileContext.getLocalFSFileContext();
                RCLJZEURHM.delete(QCNIATWJBS, false);
                RCLJZEURHM.delete(QCNIATWJBS.suffix(ContainerLaunch.XNEDFOAVPP), false);
            }
        }
    }

    /**
     * Loop through for a time-bounded interval waiting to
     * read the process id from a file generated by a running process.
     *
     * @param pidFilePath
     * 		File from which to read the process id
     * @return Process ID
     * @throws Exception
     * 		
     */
    private String getContainerPid(Path DEICWZAKMX) throws Exception {
        String WRZVKLZFCA = ConverterUtils.toString(RPSDWYOKAU.getContainerId());
        String OEVDDWBVHD = null;
        ContainerLaunch.DAPHWHWVHA.debug((("Accessing pid for container " + WRZVKLZFCA) + " from pid file ") + DEICWZAKMX);
        int NDYIQHVIXO = 0;
        final int QEFGLSUKNG = 100;
        // loop waiting for pid file to show up
        // until either the completed flag is set which means something bad
        // happened or our timer expires in which case we admit defeat
        while (!HHEJFFEZSL.get()) {
            OEVDDWBVHD = ProcessIdFileReader.getProcessId(DEICWZAKMX);
            if (OEVDDWBVHD != null) {
                ContainerLaunch.DAPHWHWVHA.debug((("Got pid " + OEVDDWBVHD) + " for container ") + WRZVKLZFCA);
                break;
            } else
                if ((NDYIQHVIXO * QEFGLSUKNG) > XEVNWLCYQR) {
                    ContainerLaunch.DAPHWHWVHA.info(((("Could not get pid for " + WRZVKLZFCA) + ". Waited for ") + XEVNWLCYQR) + " ms.");
                    break;
                } else {
                    ++NDYIQHVIXO;
                    Thread.sleep(QEFGLSUKNG);
                }

        } 
        return OEVDDWBVHD;
    }

    public static String getRelativeContainerLogDir(String JKCNNYIKYU, String KKFRCSFRHM) {
        return (JKCNNYIKYU + Path.SEPARATOR) + KKFRCSFRHM;
    }

    private String getContainerPrivateDir(String TBPXCEEHLW, String NRVTOEWAXZ) {
        return ((getAppPrivateDir(TBPXCEEHLW) + Path.SEPARATOR) + NRVTOEWAXZ) + Path.SEPARATOR;
    }

    private String getAppPrivateDir(String KVDDUTGYXW) {
        return (ResourceLocalizationService.NM_PRIVATE_DIR + Path.SEPARATOR) + KVDDUTGYXW;
    }

    Context getContext() {
        return BJSZQGBBOG;
    }

    @VisibleForTesting
    static abstract class ShellScriptBuilder {
        public static ContainerLaunch.ShellScriptBuilder create() {
            return Shell.WINDOWS ? new ContainerLaunch.WindowsShellScriptBuilder() : new ContainerLaunch.UnixShellScriptBuilder();
        }

        private static final String LZLUVVUQIR = System.getProperty("line.separator");

        private final StringBuilder RSZKEYVATB = new StringBuilder();

        public abstract void command(List<String> command) throws IOException;

        public abstract void env(String key, String value) throws IOException;

        public final void symlink(Path src, Path dst) throws IOException {
            if (!src.isAbsolute()) {
                throw new IOException("Source must be absolute");
            }
            if (dst.isAbsolute()) {
                throw new IOException("Destination must be relative");
            }
            if (dst.toUri().getPath().indexOf('/') != (-1)) {
                mkdir(dst.getParent());
            }
            link(src, dst);
        }

        @Override
        public String toString() {
            return RSZKEYVATB.toString();
        }

        public final void write(PrintStream out) throws IOException {
            out.append(RSZKEYVATB);
        }

        protected final void line(String... command) {
            for (String s : command) {
                RSZKEYVATB.append(s);
            }
            RSZKEYVATB.append(ContainerLaunch.ShellScriptBuilder.LZLUVVUQIR);
        }

        protected abstract void link(Path src, Path dst) throws IOException;

        protected abstract void mkdir(Path path) throws IOException;
    }

    private static final class UnixShellScriptBuilder extends ContainerLaunch.ShellScriptBuilder {
        private void errorCheck() {
            line("hadoop_shell_errorcode=$?");
            line("if [ $hadoop_shell_errorcode -ne 0 ]");
            line("then");
            line("  exit $hadoop_shell_errorcode");
            line("fi");
        }

        public UnixShellScriptBuilder() {
            line("#!/bin/bash");
            line();
        }

        @Override
        public void command(List<String> command) {
            line("exec /bin/bash -c \"", StringUtils.join(" ", command), "\"");
            errorCheck();
        }

        @Override
        public void env(String key, String value) {
            line("export ", key, "=\"", value, "\"");
        }

        @Override
        protected void link(Path src, Path dst) throws IOException {
            line("ln -sf \"", src.toUri().getPath(), "\" \"", dst.toString(), "\"");
            errorCheck();
        }

        @Override
        protected void mkdir(Path path) {
            line("mkdir -p ", path.toString());
            errorCheck();
        }
    }

    private static final class WindowsShellScriptBuilder extends ContainerLaunch.ShellScriptBuilder {
        private void errorCheck() {
            line("@if %errorlevel% neq 0 exit /b %errorlevel%");
        }

        private void lineWithLenCheck(String... commands) throws IOException {
            Shell.checkWindowsCommandLineLength(commands);
            line(commands);
        }

        public WindowsShellScriptBuilder() {
            line("@setlocal");
            line();
        }

        @Override
        public void command(List<String> command) throws IOException {
            lineWithLenCheck("@call ", StringUtils.join(" ", command));
            errorCheck();
        }

        @Override
        public void env(String key, String value) throws IOException {
            lineWithLenCheck("@set ", key, "=", value);
            errorCheck();
        }

        @Override
        protected void link(Path src, Path dst) throws IOException {
            File srcFile = new File(src.toUri().getPath());
            String srcFileStr = srcFile.getPath();
            String dstFileStr = new File(dst.toString()).getPath();
            // If not on Java7+ on Windows, then copy file instead of symlinking.
            // See also FileUtil#symLink for full explanation.
            if ((!Shell.isJava7OrAbove()) && srcFile.isFile()) {
                lineWithLenCheck(String.format("@copy \"%s\" \"%s\"", srcFileStr, dstFileStr));
                errorCheck();
            } else {
                lineWithLenCheck(String.format("@%s symlink \"%s\" \"%s\"", WINUTILS, dstFileStr, srcFileStr));
                errorCheck();
            }
        }

        @Override
        protected void mkdir(Path path) throws IOException {
            lineWithLenCheck(String.format("@if not exist \"%s\" mkdir \"%s\"", path.toString(), path.toString()));
            errorCheck();
        }
    }

    private static void putEnvIfNotNull(Map<String, String> URQPSDMEHJ, String YDLINYXOOM, String LNQUCHEEPC) {
        if (LNQUCHEEPC != null) {
            URQPSDMEHJ.put(YDLINYXOOM, LNQUCHEEPC);
        }
    }

    private static void putEnvIfAbsent(Map<String, String> GCHZJDHSCC, String SAOCNTNBDE) {
        if (GCHZJDHSCC.get(SAOCNTNBDE) == null) {
            ContainerLaunch.putEnvIfNotNull(GCHZJDHSCC, SAOCNTNBDE, System.getenv(SAOCNTNBDE));
        }
    }

    public void sanitizeEnv(Map<String, String> ZJUHUDZKOT, Path IQCDEUSDWY, List<Path> MWHUAHSRAV, List<String> PJETYOBJOY, Map<Path, List<String>> UIGCJFFCVB) throws IOException {
        /**
         * Non-modifiable environment variables
         */
        ZJUHUDZKOT.put(CONTAINER_ID.name(), RPSDWYOKAU.getContainerId().toString());
        ZJUHUDZKOT.put(NM_PORT.name(), String.valueOf(this.BJSZQGBBOG.getNodeId().getPort()));
        ZJUHUDZKOT.put(NM_HOST.name(), this.BJSZQGBBOG.getNodeId().getHost());
        ZJUHUDZKOT.put(NM_HTTP_PORT.name(), String.valueOf(this.BJSZQGBBOG.getHttpPort()));
        ZJUHUDZKOT.put(LOCAL_DIRS.name(), StringUtils.join(",", MWHUAHSRAV));
        ZJUHUDZKOT.put(LOG_DIRS.name(), StringUtils.join(",", PJETYOBJOY));
        ZJUHUDZKOT.put(USER.name(), RPSDWYOKAU.getUser());
        ZJUHUDZKOT.put(LOGNAME.name(), RPSDWYOKAU.getUser());
        ZJUHUDZKOT.put(HOME.name(), QQLXCCVDMZ.get(NM_USER_HOME_DIR, DEFAULT_NM_USER_HOME_DIR));
        ZJUHUDZKOT.put(PWD.name(), IQCDEUSDWY.toString());
        ContainerLaunch.putEnvIfNotNull(ZJUHUDZKOT, HADOOP_CONF_DIR.name(), System.getenv(HADOOP_CONF_DIR.name()));
        if (!Shell.WINDOWS) {
            ZJUHUDZKOT.put("JVM_PID", "$$");
        }
        /**
         * Modifiable environment variables
         */
        // allow containers to override these variables
        String[] WDGFDTCHZO = QQLXCCVDMZ.get(YarnConfiguration.NM_ENV_WHITELIST, YarnConfiguration.DEFAULT_NM_ENV_WHITELIST).split(",");
        for (String FCBOVLWQEW : WDGFDTCHZO) {
            ContainerLaunch.putEnvIfAbsent(ZJUHUDZKOT, FCBOVLWQEW.trim());
        }
        // variables here will be forced in, even if the container has specified them.
        Apps.setEnvFromInputString(ZJUHUDZKOT, QQLXCCVDMZ.get(NM_ADMIN_USER_ENV, DEFAULT_NM_ADMIN_USER_ENV), File.pathSeparator);
        // TODO: Remove Windows check and use this approach on all platforms after
        // additional testing.  See YARN-358.
        if (Shell.WINDOWS) {
            String YAYZCTUKVN = ZJUHUDZKOT.get(CLASSPATH.name());
            if ((YAYZCTUKVN != null) && (!YAYZCTUKVN.isEmpty())) {
                StringBuilder KJUMOGJOVS = new StringBuilder(YAYZCTUKVN);
                // Localized resources do not exist at the desired paths yet, because the
                // container launch script has not run to create symlinks yet.  This
                // means that FileUtil.createJarWithClassPath can't automatically expand
                // wildcards to separate classpath entries for each file in the manifest.
                // To resolve this, append classpath entries explicitly for each
                // resource.
                for (Map.Entry<Path, List<String>> MCTTAGTNCE : UIGCJFFCVB.entrySet()) {
                    boolean UGMQLPAWGE = new File(MCTTAGTNCE.getKey().toUri().getPath()).isDirectory();
                    for (String EXEEOOLJRM : MCTTAGTNCE.getValue()) {
                        // Append resource.
                        KJUMOGJOVS.append(File.pathSeparator).append(IQCDEUSDWY.toString()).append(SEPARATOR).append(EXEEOOLJRM);
                        // FileUtil.createJarWithClassPath must use File.toURI to convert
                        // each file to a URI to write into the manifest's classpath.  For
                        // directories, the classpath must have a trailing '/', but
                        // File.toURI only appends the trailing '/' if it is a directory that
                        // already exists.  To resolve this, add the classpath entries with
                        // explicit trailing '/' here for any localized resource that targets
                        // a directory.  Then, FileUtil.createJarWithClassPath will guarantee
                        // that the resulting entry in the manifest's classpath will have a
                        // trailing '/', and thus refer to a directory instead of a file.
                        if (UGMQLPAWGE) {
                            KJUMOGJOVS.append(SEPARATOR);
                        }
                    }
                }
                // When the container launches, it takes the parent process's environment
                // and then adds/overwrites with the entries from the container launch
                // context.  Do the same thing here for correct substitution of
                // environment variables in the classpath jar manifest.
                Map<String, String> VLEYVMEDXQ = new HashMap<String, String>(System.getenv());
                VLEYVMEDXQ.putAll(ZJUHUDZKOT);
                String VTOMTWRHEC = FileUtil.createJarWithClassPath(KJUMOGJOVS.toString(), IQCDEUSDWY, VLEYVMEDXQ);
                ZJUHUDZKOT.put(CLASSPATH.name(), VTOMTWRHEC);
            }
        }
        // put AuxiliaryService data to environment
        for (Map.Entry<String, ByteBuffer> FAYTAKQGFR : UJCYCVRBTS.getAuxServiceMetaData().entrySet()) {
            AuxiliaryServiceHelper.setServiceDataIntoEnv(FAYTAKQGFR.getKey(), FAYTAKQGFR.getValue(), ZJUHUDZKOT);
        }
    }

    static void writeLaunchEnv(OutputStream GPRTYZXLAT, Map<String, String> NKXJAIINDI, Map<Path, List<String>> ADPEJMYLMY, List<String> TAYDBTPLMD) throws IOException {
        ContainerLaunch.ShellScriptBuilder ALAWQJOKXT = ContainerLaunch.ShellScriptBuilder.create();
        if (NKXJAIINDI != null) {
            for (Map.Entry<String, String> YAACTODEUD : NKXJAIINDI.entrySet()) {
                ALAWQJOKXT.env(YAACTODEUD.getKey().toString(), YAACTODEUD.getValue().toString());
            }
        }
        if (ADPEJMYLMY != null) {
            for (Map.Entry<Path, List<String>> EPETVVOASL : ADPEJMYLMY.entrySet()) {
                for (String KVKOCOTVSH : EPETVVOASL.getValue()) {
                    ALAWQJOKXT.symlink(EPETVVOASL.getKey(), new Path(KVKOCOTVSH));
                }
            }
        }
        ALAWQJOKXT.command(TAYDBTPLMD);
        PrintStream XHFQZRNDOG = null;
        try {
            XHFQZRNDOG = new PrintStream(GPRTYZXLAT);
            ALAWQJOKXT.write(XHFQZRNDOG);
        } finally {
            if (GPRTYZXLAT != null) {
                GPRTYZXLAT.close();
            }
        }
    }

    public static String getExitCodeFile(String PTCZGIPIOR) {
        return PTCZGIPIOR + ContainerLaunch.XNEDFOAVPP;
    }
}