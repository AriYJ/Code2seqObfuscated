/**
 * Store the summary of a content (a directory or a file).
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class ContentSummary implements Writable {
    private long YMSDXIEYCJ;

    private long VDMTTMTLGG;

    private long HLLVIGTSFK;

    private long OSWCTCSKSV;

    private long ZUZIQETDBO;

    private long OCVHIJIZRE;

    /**
     * Constructor
     */
    public ContentSummary() {
    }

    /**
     * Constructor
     */
    public ContentSummary(long KMKCKPLIQU, long MMTPLFITTZ, long LHKTCIKQUZ) {
        this(KMKCKPLIQU, MMTPLFITTZ, LHKTCIKQUZ, -1L, KMKCKPLIQU, -1L);
    }

    /**
     * Constructor
     */
    public ContentSummary(long BEXRCOSRUX, long FOWGRKTLXA, long PDXRTKKJWO, long JJJYVENCHF, long RFTOMMMYXT, long GRJLCCLGXF) {
        this.YMSDXIEYCJ = BEXRCOSRUX;
        this.VDMTTMTLGG = FOWGRKTLXA;
        this.HLLVIGTSFK = PDXRTKKJWO;
        this.OSWCTCSKSV = JJJYVENCHF;
        this.ZUZIQETDBO = RFTOMMMYXT;
        this.OCVHIJIZRE = GRJLCCLGXF;
    }

    /**
     *
     *
     * @return the length
     */
    public long getLength() {
        return YMSDXIEYCJ;
    }

    /**
     *
     *
     * @return the directory count
     */
    public long getDirectoryCount() {
        return HLLVIGTSFK;
    }

    /**
     *
     *
     * @return the file count
     */
    public long getFileCount() {
        return VDMTTMTLGG;
    }

    /**
     * Return the directory quota
     */
    public long getQuota() {
        return OSWCTCSKSV;
    }

    /**
     * Retuns (disk) space consumed
     */
    public long getSpaceConsumed() {
        return ZUZIQETDBO;
    }

    /**
     * Returns (disk) space quota
     */
    public long getSpaceQuota() {
        return OCVHIJIZRE;
    }

    @Override
    @InterfaceAudience.Private
    public void write(DataOutput QQZEELNDEL) throws IOException {
        QQZEELNDEL.writeLong(YMSDXIEYCJ);
        QQZEELNDEL.writeLong(VDMTTMTLGG);
        QQZEELNDEL.writeLong(HLLVIGTSFK);
        QQZEELNDEL.writeLong(OSWCTCSKSV);
        QQZEELNDEL.writeLong(ZUZIQETDBO);
        QQZEELNDEL.writeLong(OCVHIJIZRE);
    }

    @Override
    @InterfaceAudience.Private
    public void readFields(DataInput JNMHDRHIXZ) throws IOException {
        this.YMSDXIEYCJ = JNMHDRHIXZ.readLong();
        this.VDMTTMTLGG = JNMHDRHIXZ.readLong();
        this.HLLVIGTSFK = JNMHDRHIXZ.readLong();
        this.OSWCTCSKSV = JNMHDRHIXZ.readLong();
        this.ZUZIQETDBO = JNMHDRHIXZ.readLong();
        this.OCVHIJIZRE = JNMHDRHIXZ.readLong();
    }

    /**
     * Output format:
     * <----12----> <----12----> <-------18------->
     *    DIR_COUNT   FILE_COUNT       CONTENT_SIZE FILE_NAME
     */
    private static final String FLFKNCITYX = "%12s %12s %18s ";

    /**
     * Output format:
     * <----12----> <----15----> <----15----> <----15----> <----12----> <----12----> <-------18------->
     *    QUOTA   REMAINING_QUATA SPACE_QUOTA SPACE_QUOTA_REM DIR_COUNT   FILE_COUNT   CONTENT_SIZE     FILE_NAME
     */
    private static final String ICHNWKUXID = "%12s %15s ";

    private static final String GBTRMYXJPB = "%15s %15s ";

    /**
     * The header string
     */
    private static final String KZCQEBKIYQ = String.format(ContentSummary.FLFKNCITYX.replace('d', 's'), "directories", "files", "bytes");

    private static final String QWWGOCOGZQ = String.format(ContentSummary.ICHNWKUXID + ContentSummary.GBTRMYXJPB, "name quota", "rem name quota", "space quota", "rem space quota") + ContentSummary.KZCQEBKIYQ;

    /**
     * Return the header of the output.
     * if qOption is false, output directory count, file count, and content size;
     * if qOption is true, output quota and remaining quota as well.
     *
     * @param qOption
     * 		a flag indicating if quota needs to be printed or not
     * @return the header of the output
     */
    public static String getHeader(boolean WAHWMLXVYB) {
        return WAHWMLXVYB ? ContentSummary.QWWGOCOGZQ : ContentSummary.KZCQEBKIYQ;
    }

    @Override
    public String toString() {
        return toString(true);
    }

    /**
     * Return the string representation of the object in the output format.
     * if qOption is false, output directory count, file count, and content size;
     * if qOption is true, output quota and remaining quota as well.
     *
     * @param qOption
     * 		a flag indicating if quota needs to be printed or not
     * @return the string representation of the object
     */
    public String toString(boolean CYXSQIBBIQ) {
        return toString(CYXSQIBBIQ, false);
    }

    /**
     * Return the string representation of the object in the output format.
     * if qOption is false, output directory count, file count, and content size;
     * if qOption is true, output quota and remaining quota as well.
     * if hOption is false file sizes are returned in bytes
     * if hOption is true file sizes are returned in human readable
     *
     * @param qOption
     * 		a flag indicating if quota needs to be printed or not
     * @param hOption
     * 		a flag indicating if human readable output if to be used
     * @return the string representation of the object
     */
    public String toString(boolean TIBYHFLSLR, boolean LATSMYBIOD) {
        String UYKSTNDBYA = "";
        if (TIBYHFLSLR) {
            String JKPDWIVIJE = "none";
            String RZEXQGTGYL = "inf";
            String WRRMGGTOQY = "none";
            String SIKVJJGXZR = "inf";
            if (OSWCTCSKSV > 0) {
                JKPDWIVIJE = formatSize(OSWCTCSKSV, LATSMYBIOD);
                RZEXQGTGYL = formatSize(OSWCTCSKSV - (HLLVIGTSFK + VDMTTMTLGG), LATSMYBIOD);
            }
            if (OCVHIJIZRE > 0) {
                WRRMGGTOQY = formatSize(OCVHIJIZRE, LATSMYBIOD);
                SIKVJJGXZR = formatSize(OCVHIJIZRE - ZUZIQETDBO, LATSMYBIOD);
            }
            UYKSTNDBYA = String.format(ContentSummary.ICHNWKUXID + ContentSummary.GBTRMYXJPB, JKPDWIVIJE, RZEXQGTGYL, WRRMGGTOQY, SIKVJJGXZR);
        }
        return UYKSTNDBYA + String.format(ContentSummary.FLFKNCITYX, formatSize(HLLVIGTSFK, LATSMYBIOD), formatSize(VDMTTMTLGG, LATSMYBIOD), formatSize(YMSDXIEYCJ, LATSMYBIOD));
    }

    /**
     * Formats a size to be human readable or in bytes
     *
     * @param size
     * 		value to be formatted
     * @param humanReadable
     * 		flag indicating human readable or not
     * @return String representation of the size
     */
    private String formatSize(long HMGUQGGDVM, boolean KOVOPKXVCB) {
        return KOVOPKXVCB ? TraditionalBinaryPrefix.long2String(HMGUQGGDVM, "", 1) : String.valueOf(HMGUQGGDVM);
    }
}