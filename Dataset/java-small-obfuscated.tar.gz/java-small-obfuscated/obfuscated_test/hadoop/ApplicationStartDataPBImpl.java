public class ApplicationStartDataPBImpl extends ApplicationStartData {
    ApplicationStartDataProto HQKECTHBBK = ApplicationStartDataProto.getDefaultInstance();

    Builder EHBFLQYPVX = null;

    boolean RFLOJYYQIK = false;

    private ApplicationId SOFRNQUMVA;

    public ApplicationStartDataPBImpl() {
        EHBFLQYPVX = ApplicationStartDataProto.newBuilder();
    }

    public ApplicationStartDataPBImpl(ApplicationStartDataProto KWXVZHDEPQ) {
        this.HQKECTHBBK = KWXVZHDEPQ;
        RFLOJYYQIK = true;
    }

    @Override
    public ApplicationId getApplicationId() {
        if (this.SOFRNQUMVA != null) {
            return this.SOFRNQUMVA;
        }
        ApplicationStartDataProtoOrBuilder RTZKRKKVZU = (RFLOJYYQIK) ? HQKECTHBBK : EHBFLQYPVX;
        if (!RTZKRKKVZU.hasApplicationId()) {
            return null;
        }
        this.SOFRNQUMVA = convertFromProtoFormat(RTZKRKKVZU.getApplicationId());
        return this.SOFRNQUMVA;
    }

    @Override
    public void setApplicationId(ApplicationId LBNRLVYVMF) {
        maybeInitBuilder();
        if (LBNRLVYVMF == null) {
            EHBFLQYPVX.clearApplicationId();
        }
        this.SOFRNQUMVA = LBNRLVYVMF;
    }

    @Override
    public String getApplicationName() {
        ApplicationStartDataProtoOrBuilder TDJOYQJPZS = (RFLOJYYQIK) ? HQKECTHBBK : EHBFLQYPVX;
        if (!TDJOYQJPZS.hasApplicationName()) {
            return null;
        }
        return TDJOYQJPZS.getApplicationName();
    }

    @Override
    public void setApplicationName(String CHTGYXDYBT) {
        maybeInitBuilder();
        if (CHTGYXDYBT == null) {
            EHBFLQYPVX.clearApplicationName();
            return;
        }
        EHBFLQYPVX.setApplicationName(CHTGYXDYBT);
    }

    @Override
    public String getApplicationType() {
        ApplicationStartDataProtoOrBuilder QXGHSBHPYJ = (RFLOJYYQIK) ? HQKECTHBBK : EHBFLQYPVX;
        if (!QXGHSBHPYJ.hasApplicationType()) {
            return null;
        }
        return QXGHSBHPYJ.getApplicationType();
    }

    @Override
    public void setApplicationType(String JVHJZJXZYF) {
        maybeInitBuilder();
        if (JVHJZJXZYF == null) {
            EHBFLQYPVX.clearApplicationType();
            return;
        }
        EHBFLQYPVX.setApplicationType(JVHJZJXZYF);
    }

    @Override
    public String getUser() {
        ApplicationStartDataProtoOrBuilder VVEXKMZGGL = (RFLOJYYQIK) ? HQKECTHBBK : EHBFLQYPVX;
        if (!VVEXKMZGGL.hasUser()) {
            return null;
        }
        return VVEXKMZGGL.getUser();
    }

    @Override
    public void setUser(String XCRIZKCVAF) {
        maybeInitBuilder();
        if (XCRIZKCVAF == null) {
            EHBFLQYPVX.clearUser();
            return;
        }
        EHBFLQYPVX.setUser(XCRIZKCVAF);
    }

    @Override
    public String getQueue() {
        ApplicationStartDataProtoOrBuilder QGXQRGFGSC = (RFLOJYYQIK) ? HQKECTHBBK : EHBFLQYPVX;
        if (!QGXQRGFGSC.hasQueue()) {
            return null;
        }
        return QGXQRGFGSC.getQueue();
    }

    @Override
    public void setQueue(String CSIIXMZYGQ) {
        maybeInitBuilder();
        if (CSIIXMZYGQ == null) {
            EHBFLQYPVX.clearQueue();
            return;
        }
        EHBFLQYPVX.setQueue(CSIIXMZYGQ);
    }

    @Override
    public long getSubmitTime() {
        ApplicationStartDataProtoOrBuilder GAICEALMKT = (RFLOJYYQIK) ? HQKECTHBBK : EHBFLQYPVX;
        return GAICEALMKT.getSubmitTime();
    }

    @Override
    public void setSubmitTime(long YLWVLZBMBZ) {
        maybeInitBuilder();
        EHBFLQYPVX.setSubmitTime(YLWVLZBMBZ);
    }

    @Override
    public long getStartTime() {
        ApplicationStartDataProtoOrBuilder NQEZITOKVH = (RFLOJYYQIK) ? HQKECTHBBK : EHBFLQYPVX;
        return NQEZITOKVH.getStartTime();
    }

    @Override
    public void setStartTime(long HXMCBEGSKU) {
        maybeInitBuilder();
        EHBFLQYPVX.setStartTime(HXMCBEGSKU);
    }

    public ApplicationStartDataProto getProto() {
        mergeLocalToProto();
        HQKECTHBBK = (RFLOJYYQIK) ? HQKECTHBBK : EHBFLQYPVX.build();
        RFLOJYYQIK = true;
        return HQKECTHBBK;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object EMCDNLFGYJ) {
        if (EMCDNLFGYJ == null)
            return false;

        if (EMCDNLFGYJ.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(EMCDNLFGYJ).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }

    private void mergeLocalToBuilder() {
        if ((this.SOFRNQUMVA != null) && (!((ApplicationIdPBImpl) (this.SOFRNQUMVA)).getProto().equals(EHBFLQYPVX.getApplicationId()))) {
            EHBFLQYPVX.setApplicationId(convertToProtoFormat(this.SOFRNQUMVA));
        }
    }

    private void mergeLocalToProto() {
        if (RFLOJYYQIK) {
            maybeInitBuilder();
        }
        mergeLocalToBuilder();
        HQKECTHBBK = EHBFLQYPVX.build();
        RFLOJYYQIK = true;
    }

    private void maybeInitBuilder() {
        if (RFLOJYYQIK || (EHBFLQYPVX == null)) {
            EHBFLQYPVX = ApplicationStartDataProto.newBuilder(HQKECTHBBK);
        }
        RFLOJYYQIK = false;
    }

    private ApplicationIdProto convertToProtoFormat(ApplicationId CVVIXBVAQJ) {
        return ((ApplicationIdPBImpl) (CVVIXBVAQJ)).getProto();
    }

    private ApplicationIdPBImpl convertFromProtoFormat(ApplicationIdProto QKJHUODMUG) {
        return new ApplicationIdPBImpl(QKJHUODMUG);
    }
}