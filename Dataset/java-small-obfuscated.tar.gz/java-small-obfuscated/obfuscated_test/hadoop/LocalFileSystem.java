/**
 * **************************************************************
 * Implement the FileSystem API for the checksumed local filesystem.
 *
 * ***************************************************************
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LocalFileSystem extends ChecksumFileSystem {
    static final URI KBRSGDBPHI = URI.create("file:///");

    private static Random QPETQLOMBG = new Random();

    public LocalFileSystem() {
        this(new RawLocalFileSystem());
    }

    @Override
    public void initialize(URI DWRPIHPKQP, Configuration CEFJHENRAC) throws IOException {
        if (fs.getConf() == null) {
            fs.initialize(DWRPIHPKQP, CEFJHENRAC);
        }
        String RVJMKKTGWD = DWRPIHPKQP.getScheme();
        if (!RVJMKKTGWD.equals(fs.getUri().getScheme())) {
            swapScheme = RVJMKKTGWD;
        }
    }

    /**
     * Return the protocol scheme for the FileSystem.
     * <p/>
     *
     * @return <code>file</code>
     */
    @Override
    public String getScheme() {
        return "file";
    }

    public FileSystem getRaw() {
        return getRawFileSystem();
    }

    public LocalFileSystem(FileSystem YTLXIZNYLP) {
        super(YTLXIZNYLP);
    }

    /**
     * Convert a path to a File.
     */
    public File pathToFile(Path OSYORWDOZZ) {
        return ((RawLocalFileSystem) (fs)).pathToFile(OSYORWDOZZ);
    }

    @Override
    public void copyFromLocalFile(boolean RZXBWEQCAK, Path BBGLGRDZZE, Path OXCTOLFZYI) throws IOException {
        FileUtil.copy(this, BBGLGRDZZE, this, OXCTOLFZYI, RZXBWEQCAK, getConf());
    }

    @Override
    public void copyToLocalFile(boolean IEUFXTRRJT, Path IBTSLDBIZH, Path TNCRRBTGXW) throws IOException {
        FileUtil.copy(this, IBTSLDBIZH, this, TNCRRBTGXW, IEUFXTRRJT, getConf());
    }

    /**
     * Moves files to a bad file directory on the same device, so that their
     * storage will not be reused.
     */
    @Override
    public boolean reportChecksumFailure(Path GWWTLRELNM, FSDataInputStream UIPAQNAGZX, long VYJZSLIOXC, FSDataInputStream MSAFZWNGDR, long IZUERQGOWE) {
        try {
            // canonicalize f
            File XFUUUCHVUQ = ((RawLocalFileSystem) (fs)).pathToFile(GWWTLRELNM).getCanonicalFile();
            // find highest writable parent dir of f on the same device
            String CAPEZYCAHI = new DF(XFUUUCHVUQ, getConf()).getMount();
            File YRVEKAFEGO = XFUUUCHVUQ.getParentFile();
            File BTHPCVAUNK = null;
            while (((YRVEKAFEGO != null) && FileUtil.canWrite(YRVEKAFEGO)) && YRVEKAFEGO.toString().startsWith(CAPEZYCAHI)) {
                BTHPCVAUNK = YRVEKAFEGO;
                YRVEKAFEGO = YRVEKAFEGO.getParentFile();
            } 
            if (BTHPCVAUNK == null) {
                throw new IOException("not able to find the highest writable parent dir");
            }
            // move the file there
            File YIIOKKKWOI = new File(BTHPCVAUNK, "bad_files");
            if (!YIIOKKKWOI.mkdirs()) {
                if (!YIIOKKKWOI.isDirectory()) {
                    throw new IOException("Mkdirs failed to create " + YIIOKKKWOI.toString());
                }
            }
            String PDNLYSZHRE = "." + LocalFileSystem.QPETQLOMBG.nextInt();
            File VCGOQTHVLW = new File(YIIOKKKWOI, XFUUUCHVUQ.getName() + PDNLYSZHRE);
            LOG.warn((("Moving bad file " + XFUUUCHVUQ) + " to ") + VCGOQTHVLW);
            UIPAQNAGZX.close();
            // close it first
            boolean WIFONXRVUK = XFUUUCHVUQ.renameTo(VCGOQTHVLW);
            // rename it
            if (!WIFONXRVUK) {
                LOG.warn("Ignoring failure of renameTo");
            }
            // move checksum file too
            File AVXTGYCLHM = ((RawLocalFileSystem) (fs)).pathToFile(getChecksumFile(GWWTLRELNM));
            // close the stream before rename to release the file handle
            MSAFZWNGDR.close();
            WIFONXRVUK = AVXTGYCLHM.renameTo(new File(YIIOKKKWOI, AVXTGYCLHM.getName() + PDNLYSZHRE));
            if (!WIFONXRVUK) {
                LOG.warn("Ignoring failure of renameTo");
            }
        } catch (IOException e) {
            LOG.warn((("Error moving bad file " + GWWTLRELNM) + ": ") + e);
        }
        return false;
    }

    @Override
    public boolean supportsSymlinks() {
        return true;
    }

    @Override
    public void createSymlink(Path HVBEKJLAEP, Path FIWYOWMLVS, boolean GRZISIPGDI) throws IOException {
        fs.createSymlink(HVBEKJLAEP, FIWYOWMLVS, GRZISIPGDI);
    }

    @Override
    public FileStatus getFileLinkStatus(final Path OJVAOPWHYF) throws IOException {
        return fs.getFileLinkStatus(OJVAOPWHYF);
    }

    @Override
    public Path getLinkTarget(Path XQBAVRRINX) throws IOException {
        return fs.getLinkTarget(XQBAVRRINX);
    }
}