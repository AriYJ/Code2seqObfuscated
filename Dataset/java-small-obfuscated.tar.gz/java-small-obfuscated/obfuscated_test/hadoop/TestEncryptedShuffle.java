public class TestEncryptedShuffle {
    private static final String TKBQWGBBMI = (System.getProperty("test.build.dir", "target/test-dir") + "/") + TestEncryptedShuffle.class.getSimpleName();

    private String KNPCOUXPQQ;

    @BeforeClass
    public static void setUp() throws Exception {
        File DVQEXKPPSD = new File(TestEncryptedShuffle.TKBQWGBBMI);
        FileUtil.fullyDelete(DVQEXKPPSD);
        DVQEXKPPSD.mkdirs();
    }

    @Before
    public void createCustomYarnClasspath() throws Exception {
        KNPCOUXPQQ = KeyStoreTestUtil.getClasspathDir(TestEncryptedShuffle.class);
        new File(KNPCOUXPQQ, "core-site.xml").delete();
    }

    @After
    public void cleanUpMiniClusterSpecialConfig() throws Exception {
        new File(KNPCOUXPQQ, "core-site.xml").delete();
        String WFGOXQREUD = new File(TestEncryptedShuffle.TKBQWGBBMI).getAbsolutePath();
        KeyStoreTestUtil.cleanupSSLConfig(WFGOXQREUD, KNPCOUXPQQ);
    }

    private MiniDFSCluster GDEJAMKFNH = null;

    private MiniMRClientCluster PFIFXMOZPR = null;

    private void startCluster(Configuration DVDCRYDHHO) throws Exception {
        if (System.getProperty("hadoop.log.dir") == null) {
            System.setProperty("hadoop.log.dir", "target/test-dir");
        }
        DVDCRYDHHO.set("dfs.block.access.token.enable", "false");
        DVDCRYDHHO.set("dfs.permissions", "true");
        DVDCRYDHHO.set("hadoop.security.authentication", "simple");
        String QNMKWUZVZN = (DVDCRYDHHO.get(YARN_APPLICATION_CLASSPATH, StringUtils.join(",", DEFAULT_YARN_CROSS_PLATFORM_APPLICATION_CLASSPATH)) + File.pathSeparator) + KNPCOUXPQQ;
        DVDCRYDHHO.set(YARN_APPLICATION_CLASSPATH, QNMKWUZVZN);
        GDEJAMKFNH = new MiniDFSCluster.Builder(DVDCRYDHHO).build();
        FileSystem CXZXVWUEJP = GDEJAMKFNH.getFileSystem();
        CXZXVWUEJP.mkdirs(new Path("/tmp"));
        CXZXVWUEJP.mkdirs(new Path("/user"));
        CXZXVWUEJP.mkdirs(new Path("/hadoop/mapred/system"));
        CXZXVWUEJP.setPermission(new Path("/tmp"), FsPermission.valueOf("-rwxrwxrwx"));
        CXZXVWUEJP.setPermission(new Path("/user"), FsPermission.valueOf("-rwxrwxrwx"));
        CXZXVWUEJP.setPermission(new Path("/hadoop/mapred/system"), FsPermission.valueOf("-rwx------"));
        FileSystem.setDefaultUri(DVDCRYDHHO, CXZXVWUEJP.getUri());
        PFIFXMOZPR = MiniMRClientClusterFactory.create(this.getClass(), 1, DVDCRYDHHO);
        // so the minicluster conf is avail to the containers.
        Writer VXBEWNFQRO = new FileWriter(KNPCOUXPQQ + "/core-site.xml");
        PFIFXMOZPR.getConfig().writeXml(VXBEWNFQRO);
        VXBEWNFQRO.close();
    }

    private void stopCluster() throws Exception {
        if (PFIFXMOZPR != null) {
            PFIFXMOZPR.stop();
        }
        if (GDEJAMKFNH != null) {
            GDEJAMKFNH.shutdown();
        }
    }

    protected JobConf getJobConf() throws IOException {
        return new JobConf(PFIFXMOZPR.getConfig());
    }

    private void encryptedShuffleWithCerts(boolean DLSWVQDREN) throws Exception {
        try {
            Configuration OANFZQYMHQ = new Configuration();
            String BZTUPCULDX = new File(TestEncryptedShuffle.TKBQWGBBMI).getAbsolutePath();
            String DKKOZQAPHM = KeyStoreTestUtil.getClasspathDir(TestEncryptedShuffle.class);
            KeyStoreTestUtil.setupSSLConfig(BZTUPCULDX, DKKOZQAPHM, OANFZQYMHQ, DLSWVQDREN);
            OANFZQYMHQ.setBoolean(SHUFFLE_SSL_ENABLED_KEY, true);
            startCluster(OANFZQYMHQ);
            FileSystem GHEQHVEZQD = FileSystem.get(getJobConf());
            Path CJEGKOFDUL = new Path("input");
            GHEQHVEZQD.mkdirs(CJEGKOFDUL);
            Writer UQLECQQHAZ = new OutputStreamWriter(GHEQHVEZQD.create(new Path(CJEGKOFDUL, "data.txt")));
            UQLECQQHAZ.write("hello");
            UQLECQQHAZ.close();
            Path EZDSNHOSSV = new Path("output", "output");
            JobConf BZZRCTFPIS = new JobConf(getJobConf());
            BZZRCTFPIS.setInt("mapred.map.tasks", 1);
            BZZRCTFPIS.setInt("mapred.map.max.attempts", 1);
            BZZRCTFPIS.setInt("mapred.reduce.max.attempts", 1);
            BZZRCTFPIS.set("mapred.input.dir", CJEGKOFDUL.toString());
            BZZRCTFPIS.set("mapred.output.dir", EZDSNHOSSV.toString());
            JobClient ULYRSPWCZK = new JobClient(BZZRCTFPIS);
            RunningJob MBLXZTQAIK = ULYRSPWCZK.submitJob(BZZRCTFPIS);
            MBLXZTQAIK.waitForCompletion();
            Assert.assertTrue(MBLXZTQAIK.isComplete());
            Assert.assertTrue(MBLXZTQAIK.isSuccessful());
        } finally {
            stopCluster();
        }
    }

    @Test
    public void encryptedShuffleWithClientCerts() throws Exception {
        encryptedShuffleWithCerts(true);
    }

    @Test
    public void encryptedShuffleWithoutClientCerts() throws Exception {
        encryptedShuffleWithCerts(false);
    }
}