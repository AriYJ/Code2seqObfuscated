/**
 * A metrics sink that writes to a file
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class FileSink implements Closeable , MetricsSink {
    private static final String DBHZPNTMKB = "filename";

    private PrintWriter JYRCFHEIIQ;

    @Override
    public void init(SubsetConfiguration EJLACUZFZC) {
        String RFMEYQTIDL = EJLACUZFZC.getString(FileSink.DBHZPNTMKB);
        try {
            JYRCFHEIIQ = (RFMEYQTIDL == null) ? new PrintWriter(System.out) : new PrintWriter(new FileWriter(new File(RFMEYQTIDL), true));
        } catch (Exception e) {
            throw new MetricsException("Error creating " + RFMEYQTIDL, e);
        }
    }

    @Override
    public void putMetrics(MetricsRecord WNCJLLGDHW) {
        JYRCFHEIIQ.print(WNCJLLGDHW.timestamp());
        JYRCFHEIIQ.print(" ");
        JYRCFHEIIQ.print(WNCJLLGDHW.context());
        JYRCFHEIIQ.print(".");
        JYRCFHEIIQ.print(WNCJLLGDHW.name());
        String IVOAVBSTIC = ": ";
        for (MetricsTag PCQOZCJAZS : WNCJLLGDHW.tags()) {
            JYRCFHEIIQ.print(IVOAVBSTIC);
            IVOAVBSTIC = ", ";
            JYRCFHEIIQ.print(PCQOZCJAZS.name());
            JYRCFHEIIQ.print("=");
            JYRCFHEIIQ.print(PCQOZCJAZS.value());
        }
        for (AbstractMetric PHXSZOUWFT : WNCJLLGDHW.metrics()) {
            JYRCFHEIIQ.print(IVOAVBSTIC);
            IVOAVBSTIC = ", ";
            JYRCFHEIIQ.print(PHXSZOUWFT.name());
            JYRCFHEIIQ.print("=");
            JYRCFHEIIQ.print(PHXSZOUWFT.value());
        }
        JYRCFHEIIQ.println();
    }

    @Override
    public void flush() {
        JYRCFHEIIQ.flush();
    }

    @Override
    public void close() throws IOException {
        JYRCFHEIIQ.close();
    }
}