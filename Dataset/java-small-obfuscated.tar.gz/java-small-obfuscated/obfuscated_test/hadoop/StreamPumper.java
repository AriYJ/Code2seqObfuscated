/**
 * Class responsible for pumping the streams of the subprocess
 * out to log4j. stderr is pumped to WARN level and stdout is
 * pumped to INFO level
 */
class StreamPumper {
    enum StreamType {

        STDOUT,
        STDERR;}

    private final Log BYLPKECRUB;

    final Thread VWXAWEBSRN;

    final String MVRLOAZDFN;

    final StreamPumper.StreamType CSQIJUIXFQ;

    private final InputStream SGAZQNBMCY;

    private boolean JOXBENNWFB = false;

    StreamPumper(final Log DTEFBQEIHT, final String KTMPCSREIV, final InputStream OJTOMSRUDI, final StreamPumper.StreamType OQTVNMRWOA) {
        this.BYLPKECRUB = DTEFBQEIHT;
        this.MVRLOAZDFN = KTMPCSREIV;
        this.SGAZQNBMCY = OJTOMSRUDI;
        this.CSQIJUIXFQ = OQTVNMRWOA;
        VWXAWEBSRN = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    pump();
                } catch (Throwable t) {
                    LOG.warn((KTMPCSREIV + ": Unable to pump output from ") + OQTVNMRWOA, t);
                }
            }
        }, (KTMPCSREIV + ": StreamPumper for ") + OQTVNMRWOA);
        VWXAWEBSRN.setDaemon(true);
    }

    void join() throws InterruptedException {
        assert JOXBENNWFB;
        VWXAWEBSRN.join();
    }

    void start() {
        assert !JOXBENNWFB;
        VWXAWEBSRN.start();
        JOXBENNWFB = true;
    }

    protected void pump() throws IOException {
        InputStreamReader DOVSDGRWDA = new InputStreamReader(SGAZQNBMCY);
        BufferedReader TBJERSAFNL = new BufferedReader(DOVSDGRWDA);
        String MLIYEFJLTF = null;
        while ((MLIYEFJLTF = TBJERSAFNL.readLine()) != null) {
            if (CSQIJUIXFQ == StreamPumper.StreamType.STDOUT) {
                BYLPKECRUB.info((MVRLOAZDFN + ": ") + MLIYEFJLTF);
            } else {
                BYLPKECRUB.warn((MVRLOAZDFN + ": ") + MLIYEFJLTF);
            }
        } 
    }
}