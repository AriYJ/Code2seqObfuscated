public class TestDirectoryCollection {
    private static final File LRXSDPGUOP = new File("target", TestDirectoryCollection.class.getName()).getAbsoluteFile();

    private static final File XHGFJVZCQG = new File(TestDirectoryCollection.LRXSDPGUOP, "testfile");

    @BeforeClass
    public static void setup() throws IOException {
        TestDirectoryCollection.LRXSDPGUOP.mkdirs();
        TestDirectoryCollection.XHGFJVZCQG.createNewFile();
    }

    @AfterClass
    public static void teardown() {
        FileUtil.fullyDelete(TestDirectoryCollection.LRXSDPGUOP);
    }

    @Test
    public void testConcurrentAccess() throws IOException {
        // Initialize DirectoryCollection with a file instead of a directory
        Configuration WIKGXTMLBX = new Configuration();
        String[] VDUNZZJHVH = new String[]{ TestDirectoryCollection.XHGFJVZCQG.getPath() };
        DirectoryCollection BEDDTJJNFA = new DirectoryCollection(VDUNZZJHVH, WIKGXTMLBX.getFloat(NM_MAX_PER_DISK_UTILIZATION_PERCENTAGE, DEFAULT_NM_MAX_PER_DISK_UTILIZATION_PERCENTAGE));
        // Create an iterator before checkDirs is called to reliable test case
        List<String> UDWGIEWOBO = BEDDTJJNFA.getGoodDirs();
        ListIterator<String> PDHBQWSGSA = UDWGIEWOBO.listIterator();
        // DiskErrorException will invalidate iterator of non-concurrent
        // collections. ConcurrentModificationException will be thrown upon next
        // use of the iterator.
        Assert.assertTrue("checkDirs did not remove test file from directory list", BEDDTJJNFA.checkDirs());
        // Verify no ConcurrentModification is thrown
        PDHBQWSGSA.next();
    }

    @Test
    public void testCreateDirectories() throws IOException {
        Configuration AZEGDXAXBU = new Configuration();
        AZEGDXAXBU.set(FS_PERMISSIONS_UMASK_KEY, "077");
        FileContext JPAIIAXDRG = FileContext.getLocalFSFileContext(AZEGDXAXBU);
        String HKPPVCPBFZ = new File(TestDirectoryCollection.LRXSDPGUOP, "dirA").getPath();
        String JLPKYUIQHD = new File(HKPPVCPBFZ, "dirB").getPath();
        String ZLNZGEIZUM = new File(TestDirectoryCollection.LRXSDPGUOP, "dirC").getPath();
        Path CTKTXLZPZR = new Path(ZLNZGEIZUM);
        FsPermission XSYSXYBPBW = new FsPermission(((short) (0710)));
        JPAIIAXDRG.mkdir(CTKTXLZPZR, null, true);
        JPAIIAXDRG.setPermission(CTKTXLZPZR, XSYSXYBPBW);
        String[] QFDCEQBXAS = new String[]{ HKPPVCPBFZ, JLPKYUIQHD, ZLNZGEIZUM };
        DirectoryCollection MTNULQFRHF = new DirectoryCollection(QFDCEQBXAS, AZEGDXAXBU.getFloat(NM_MAX_PER_DISK_UTILIZATION_PERCENTAGE, DEFAULT_NM_MAX_PER_DISK_UTILIZATION_PERCENTAGE));
        FsPermission VYGCYZCFBZ = FsPermission.getDefault().applyUMask(new FsPermission(((short) (FsPermission.DEFAULT_UMASK))));
        boolean KBLMEXLTTS = MTNULQFRHF.createNonExistentDirs(JPAIIAXDRG, VYGCYZCFBZ);
        Assert.assertTrue(KBLMEXLTTS);
        FileStatus UYNLOJUIEN = JPAIIAXDRG.getFileStatus(new Path(HKPPVCPBFZ));
        Assert.assertEquals("local dir parent not created with proper permissions", VYGCYZCFBZ, UYNLOJUIEN.getPermission());
        UYNLOJUIEN = JPAIIAXDRG.getFileStatus(new Path(JLPKYUIQHD));
        Assert.assertEquals("local dir not created with proper permissions", VYGCYZCFBZ, UYNLOJUIEN.getPermission());
        UYNLOJUIEN = JPAIIAXDRG.getFileStatus(CTKTXLZPZR);
        Assert.assertEquals("existing local directory permissions modified", XSYSXYBPBW, UYNLOJUIEN.getPermission());
    }

    @Test
    public void testDiskSpaceUtilizationLimit() throws IOException {
        String LJRBPJDLMO = new File(TestDirectoryCollection.LRXSDPGUOP, "dirA").getPath();
        String[] JBTIAFQCNZ = new String[]{ LJRBPJDLMO };
        DirectoryCollection DUXUZLLKDV = new DirectoryCollection(JBTIAFQCNZ, 0.0F);
        DUXUZLLKDV.checkDirs();
        Assert.assertEquals(0, DUXUZLLKDV.getGoodDirs().size());
        Assert.assertEquals(1, DUXUZLLKDV.getFailedDirs().size());
        DUXUZLLKDV = new DirectoryCollection(JBTIAFQCNZ, 100.0F);
        DUXUZLLKDV.checkDirs();
        Assert.assertEquals(1, DUXUZLLKDV.getGoodDirs().size());
        Assert.assertEquals(0, DUXUZLLKDV.getFailedDirs().size());
        DUXUZLLKDV = new DirectoryCollection(JBTIAFQCNZ, TestDirectoryCollection.LRXSDPGUOP.getTotalSpace() / (1024 * 1024));
        DUXUZLLKDV.checkDirs();
        Assert.assertEquals(0, DUXUZLLKDV.getGoodDirs().size());
        Assert.assertEquals(1, DUXUZLLKDV.getFailedDirs().size());
        DUXUZLLKDV = new DirectoryCollection(JBTIAFQCNZ, 100.0F, 0);
        DUXUZLLKDV.checkDirs();
        Assert.assertEquals(1, DUXUZLLKDV.getGoodDirs().size());
        Assert.assertEquals(0, DUXUZLLKDV.getFailedDirs().size());
    }

    @Test
    public void testDiskLimitsCutoffSetters() {
        String[] PDEXSFBULI = new String[]{ "dir" };
        DirectoryCollection BEPAUMCHGM = new DirectoryCollection(PDEXSFBULI, 0.0F, 100);
        float ECAKWWQTNY = 57.5F;
        float VJLWCMPORA = 0.1F;
        BEPAUMCHGM.setDiskUtilizationPercentageCutoff(ECAKWWQTNY);
        Assert.assertEquals(ECAKWWQTNY, BEPAUMCHGM.getDiskUtilizationPercentageCutoff(), VJLWCMPORA);
        ECAKWWQTNY = -57.5F;
        BEPAUMCHGM.setDiskUtilizationPercentageCutoff(ECAKWWQTNY);
        Assert.assertEquals(0.0F, BEPAUMCHGM.getDiskUtilizationPercentageCutoff(), VJLWCMPORA);
        ECAKWWQTNY = 157.5F;
        BEPAUMCHGM.setDiskUtilizationPercentageCutoff(ECAKWWQTNY);
        Assert.assertEquals(100.0F, BEPAUMCHGM.getDiskUtilizationPercentageCutoff(), VJLWCMPORA);
        long NBRSHMEEWM = 57;
        BEPAUMCHGM.setDiskUtilizationSpaceCutoff(NBRSHMEEWM);
        Assert.assertEquals(NBRSHMEEWM, BEPAUMCHGM.getDiskUtilizationSpaceCutoff());
        NBRSHMEEWM = -57;
        BEPAUMCHGM.setDiskUtilizationSpaceCutoff(NBRSHMEEWM);
        Assert.assertEquals(0, BEPAUMCHGM.getDiskUtilizationSpaceCutoff());
    }

    @Test
    public void testConstructors() {
        String[] JKYPHARMID = new String[]{ "dir" };
        float DPVKCJLSIH = 0.1F;
        DirectoryCollection IVHIJZLUWK = new DirectoryCollection(JKYPHARMID);
        Assert.assertEquals(100.0F, IVHIJZLUWK.getDiskUtilizationPercentageCutoff(), DPVKCJLSIH);
        Assert.assertEquals(0, IVHIJZLUWK.getDiskUtilizationSpaceCutoff());
        IVHIJZLUWK = new DirectoryCollection(JKYPHARMID, 57.5F);
        Assert.assertEquals(57.5F, IVHIJZLUWK.getDiskUtilizationPercentageCutoff(), DPVKCJLSIH);
        Assert.assertEquals(0, IVHIJZLUWK.getDiskUtilizationSpaceCutoff());
        IVHIJZLUWK = new DirectoryCollection(JKYPHARMID, 57);
        Assert.assertEquals(100.0F, IVHIJZLUWK.getDiskUtilizationPercentageCutoff(), DPVKCJLSIH);
        Assert.assertEquals(57, IVHIJZLUWK.getDiskUtilizationSpaceCutoff());
        IVHIJZLUWK = new DirectoryCollection(JKYPHARMID, 57.5F, 67);
        Assert.assertEquals(57.5F, IVHIJZLUWK.getDiskUtilizationPercentageCutoff(), DPVKCJLSIH);
        Assert.assertEquals(67, IVHIJZLUWK.getDiskUtilizationSpaceCutoff());
        IVHIJZLUWK = new DirectoryCollection(JKYPHARMID, -57.5F, -67);
        Assert.assertEquals(0.0F, IVHIJZLUWK.getDiskUtilizationPercentageCutoff(), DPVKCJLSIH);
        Assert.assertEquals(0, IVHIJZLUWK.getDiskUtilizationSpaceCutoff());
        IVHIJZLUWK = new DirectoryCollection(JKYPHARMID, 157.5F, -67);
        Assert.assertEquals(100.0F, IVHIJZLUWK.getDiskUtilizationPercentageCutoff(), DPVKCJLSIH);
        Assert.assertEquals(0, IVHIJZLUWK.getDiskUtilizationSpaceCutoff());
    }
}