public class LocalizationProtocolPBClientImpl implements Closeable , LocalizationProtocol {
    private LocalizationProtocolPB LVUSEPZUAW;

    public LocalizationProtocolPBClientImpl(long DMZSVZILKU, InetSocketAddress MORAJGNHUY, Configuration ZGAPIYZOVW) throws IOException {
        RPC.setProtocolEngine(ZGAPIYZOVW, LocalizationProtocolPB.class, ProtobufRpcEngine.class);
        LVUSEPZUAW = ((LocalizationProtocolPB) (RPC.getProxy(LocalizationProtocolPB.class, DMZSVZILKU, MORAJGNHUY, ZGAPIYZOVW)));
    }

    @Override
    public void close() {
        if (this.LVUSEPZUAW != null) {
            RPC.stopProxy(this.LVUSEPZUAW);
        }
    }

    @Override
    public LocalizerHeartbeatResponse heartbeat(LocalizerStatus SROLRLGJJI) throws IOException, YarnException {
        LocalizerStatusProto DMJDLGMSPR = ((org.apache.hadoop.yarn.server.nodemanager.api.protocolrecords.impl.pb.LocalizerStatusPBImpl) (SROLRLGJJI)).getProto();
        try {
            return new org.apache.hadoop.yarn.server.nodemanager.api.protocolrecords.impl.pb.LocalizerHeartbeatResponsePBImpl(LVUSEPZUAW.heartbeat(null, DMJDLGMSPR));
        } catch (ServiceException e) {
            RPCUtil.unwrapAndThrowException(e);
            return null;
        }
    }
}