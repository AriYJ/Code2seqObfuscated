/**
 * Represents an application attempt, and the resources that the attempt is
 * using.
 */
@Evolving
@LimitedPrivate("yarn")
public class SchedulerAppReport {
    private final Collection<RMContainer> XINRQYGZVF;

    private final Collection<RMContainer> RMIIVCILRX;

    private final boolean SCDYNYFSMO;

    public SchedulerAppReport(SchedulerApplicationAttempt XYMVWQEIXW) {
        this.XINRQYGZVF = XYMVWQEIXW.getLiveContainers();
        this.RMIIVCILRX = XYMVWQEIXW.getReservedContainers();
        this.SCDYNYFSMO = XYMVWQEIXW.isPending();
    }

    /**
     * Get the list of live containers
     *
     * @return All of the live containers
     */
    public Collection<RMContainer> getLiveContainers() {
        return XINRQYGZVF;
    }

    /**
     * Get the list of reserved containers
     *
     * @return All of the reserved containers.
     */
    public Collection<RMContainer> getReservedContainers() {
        return RMIIVCILRX;
    }

    /**
     * Is this application pending?
     *
     * @return true if it is else false.
     */
    public boolean isPending() {
        return SCDYNYFSMO;
    }
}