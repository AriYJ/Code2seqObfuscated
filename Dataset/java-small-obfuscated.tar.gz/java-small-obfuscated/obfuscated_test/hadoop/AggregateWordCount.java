/**
 * This is an example Aggregated Hadoop Map/Reduce application. It reads the
 * text input files, breaks each line into words and counts them. The output is
 * a locally sorted list of words and the count of how often they occurred.
 *
 * To run: bin/hadoop jar hadoop-*-examples.jar aggregatewordcount
 * <i>in-dir</i> <i>out-dir</i> <i>numOfReducers</i> textinputformat
 */
public class AggregateWordCount {
    public static class WordCountPlugInClass extends ValueAggregatorBaseDescriptor {
        @Override
        public ArrayList<Map.Entry<Text, Text>> generateKeyValPairs(Object key, Object val) {
            String countType = LONG_VALUE_SUM;
            ArrayList<Map.Entry<Text, Text>> retv = new ArrayList<Map.Entry<Text, Text>>();
            String line = val.toString();
            StringTokenizer itr = new StringTokenizer(line);
            while (itr.hasMoreTokens()) {
                Map.Entry<Text, Text> e = generateEntry(countType, itr.nextToken(), ONE);
                if (e != null) {
                    retv.add(e);
                }
            } 
            return retv;
        }
    }

    /**
     * The main driver for word count map/reduce program. Invoke this method to
     * submit the map/reduce job.
     *
     * @throws IOException
     * 		When there is communication problems with the job tracker.
     */
    @SuppressWarnings("unchecked")
    public static void main(String[] EEHILKAWFO) throws IOException, ClassNotFoundException, InterruptedException {
        Job JCJFLGHRRW = ValueAggregatorJob.createValueAggregatorJob(EEHILKAWFO, new Class[]{ AggregateWordCount.WordCountPlugInClass.class });
        JCJFLGHRRW.setJarByClass(AggregateWordCount.class);
        int OLFPKXNJIU = (JCJFLGHRRW.waitForCompletion(true)) ? 0 : 1;
        System.exit(OLFPKXNJIU);
    }
}