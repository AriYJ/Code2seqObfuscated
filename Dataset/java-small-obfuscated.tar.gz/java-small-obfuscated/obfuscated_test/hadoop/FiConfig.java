/**
 * This class wraps the logic around fault injection configuration file
 * Default file is expected to be found in src/test/fi-site.xml
 * This default file should be copied by JUnit Ant's tasks to
 * build/test/extraconf folder before tests are ran
 * An alternative location can be set through
 *   -Dfi.config=<file_name>
 */
public class FiConfig {
    private static final String LLZLQFOQJV = ProbabilityModel.FPROB_NAME + "config";

    private static final String RUAJNMAMKP = "fi-site.xml";

    private static Configuration RGDBFIFVXO;

    static {
        if (FiConfig.RGDBFIFVXO == null) {
            FiConfig.RGDBFIFVXO = new Configuration(false);
            String configName = System.getProperty(FiConfig.LLZLQFOQJV, FiConfig.RUAJNMAMKP);
            FiConfig.RGDBFIFVXO.addResource(configName);
        }
    }

    /**
     * Method provides access to local Configuration
     *
     * @return Configuration initialized with fault injection's parameters
     */
    public static Configuration getConfig() {
        return FiConfig.RGDBFIFVXO;
    }
}