public class TestRefreshUserMappings {
    private MiniDFSCluster CWFEZTRNQM;

    Configuration YCZQYIRGSW;

    private static final long DEOIUEIZMK = 1;

    private String MNHIHNEZXB = null;

    public static class MockUnixGroupsMapping implements GroupMappingServiceProvider {
        private int UORJLKJQHJ = 0;

        @Override
        public List<String> getGroups(String user) throws IOException {
            System.out.println("Getting groups in MockUnixGroupsMapping");
            String g1 = user + ((10 * UORJLKJQHJ) + 1);
            String g2 = user + ((10 * UORJLKJQHJ) + 2);
            List<String> l = new ArrayList<String>(2);
            l.add(g1);
            l.add(g2);
            UORJLKJQHJ++;
            return l;
        }

        @Override
        public void cacheGroupsRefresh() throws IOException {
            System.out.println("Refreshing groups in MockUnixGroupsMapping");
        }

        @Override
        public void cacheGroupsAdd(List<String> groups) throws IOException {
        }
    }

    @Before
    public void setUp() throws Exception {
        YCZQYIRGSW = new Configuration();
        YCZQYIRGSW.setClass("hadoop.security.group.mapping", TestRefreshUserMappings.MockUnixGroupsMapping.class, GroupMappingServiceProvider.class);
        YCZQYIRGSW.setLong("hadoop.security.groups.cache.secs", TestRefreshUserMappings.DEOIUEIZMK);
        Groups.getUserToGroupsMappingService(YCZQYIRGSW);
        FileSystem.setDefaultUri(YCZQYIRGSW, "hdfs://localhost:" + "0");
        CWFEZTRNQM = new MiniDFSCluster.Builder(YCZQYIRGSW).build();
        CWFEZTRNQM.waitActive();
    }

    @After
    public void tearDown() throws Exception {
        if (CWFEZTRNQM != null) {
            CWFEZTRNQM.shutdown();
        }
        if (MNHIHNEZXB != null) {
            File GIFMPVJRJO = new File(MNHIHNEZXB);
            GIFMPVJRJO.delete();
        }
    }

    @Test
    public void testGroupMappingRefresh() throws Exception {
        DFSAdmin SDKHMNALZY = new DFSAdmin(YCZQYIRGSW);
        String[] SEPKBBXFPT = new String[]{ "-refreshUserToGroupsMappings" };
        Groups IIPRJHFKGL = Groups.getUserToGroupsMappingService(YCZQYIRGSW);
        String XJAAGLMCJJ = UserGroupInformation.getCurrentUser().getUserName();
        System.out.println("first attempt:");
        List<String> JHRRLTOPRD = IIPRJHFKGL.getGroups(XJAAGLMCJJ);
        String[] YWWTYLYYKC = new String[JHRRLTOPRD.size()];
        JHRRLTOPRD.toArray(YWWTYLYYKC);
        System.out.println(Arrays.toString(YWWTYLYYKC));
        System.out.println("second attempt, should be same:");
        List<String> OIHXDZKWFY = IIPRJHFKGL.getGroups(XJAAGLMCJJ);
        OIHXDZKWFY.toArray(YWWTYLYYKC);
        System.out.println(Arrays.toString(YWWTYLYYKC));
        for (int RVOXUCTRDH = 0; RVOXUCTRDH < OIHXDZKWFY.size(); RVOXUCTRDH++) {
            assertEquals("Should be same group ", JHRRLTOPRD.get(RVOXUCTRDH), OIHXDZKWFY.get(RVOXUCTRDH));
        }
        SDKHMNALZY.run(SEPKBBXFPT);
        System.out.println("third attempt(after refresh command), should be different:");
        List<String> VJBSQHQTVO = IIPRJHFKGL.getGroups(XJAAGLMCJJ);
        VJBSQHQTVO.toArray(YWWTYLYYKC);
        System.out.println(Arrays.toString(YWWTYLYYKC));
        for (int LIBBOPWHFE = 0; LIBBOPWHFE < VJBSQHQTVO.size(); LIBBOPWHFE++) {
            assertFalse((("Should be different group: " + JHRRLTOPRD.get(LIBBOPWHFE)) + " and ") + VJBSQHQTVO.get(LIBBOPWHFE), JHRRLTOPRD.get(LIBBOPWHFE).equals(VJBSQHQTVO.get(LIBBOPWHFE)));
        }
        // test time out
        Thread.sleep(TestRefreshUserMappings.DEOIUEIZMK * 1100);
        System.out.println("fourth attempt(after timeout), should be different:");
        List<String> ITQZPHJDOY = IIPRJHFKGL.getGroups(XJAAGLMCJJ);
        ITQZPHJDOY.toArray(YWWTYLYYKC);
        System.out.println(Arrays.toString(YWWTYLYYKC));
        for (int CELSSCLGHV = 0; CELSSCLGHV < ITQZPHJDOY.size(); CELSSCLGHV++) {
            assertFalse("Should be different group ", VJBSQHQTVO.get(CELSSCLGHV).equals(ITQZPHJDOY.get(CELSSCLGHV)));
        }
    }

    @Test
    public void testRefreshSuperUserGroupsConfiguration() throws Exception {
        final String EKMICEZWBO = "super_user";
        final String[] DXWQQVSYFK = new String[]{ "gr1", "gr2" };
        final String[] JMSECYLLHT = new String[]{ "gr3", "gr4" };
        // keys in conf
        String GIXMXKDUCB = org.apache.hadoop.security.authorize.DefaultImpersonationProvider.getTestProvider().getProxySuperuserGroupConfKey(EKMICEZWBO);
        String AFKXGBJEUT = org.apache.hadoop.security.authorize.DefaultImpersonationProvider.getTestProvider().getProxySuperuserIpConfKey(EKMICEZWBO);
        YCZQYIRGSW.set(GIXMXKDUCB, "gr3,gr4,gr5");// superuser can proxy for this group

        YCZQYIRGSW.set(AFKXGBJEUT, "127.0.0.1");
        ProxyUsers.refreshSuperUserGroupsConfiguration(YCZQYIRGSW);
        UserGroupInformation TUAMFKUPJD = mock(UserGroupInformation.class);
        UserGroupInformation KBHNZFUINY = mock(UserGroupInformation.class);
        UserGroupInformation XYYLJUTITJ = mock(UserGroupInformation.class);
        when(TUAMFKUPJD.getRealUser()).thenReturn(XYYLJUTITJ);
        when(KBHNZFUINY.getRealUser()).thenReturn(XYYLJUTITJ);
        when(XYYLJUTITJ.getShortUserName()).thenReturn(EKMICEZWBO);// super user

        when(XYYLJUTITJ.getUserName()).thenReturn(EKMICEZWBO + "L");// super user

        when(TUAMFKUPJD.getShortUserName()).thenReturn("user1");
        when(KBHNZFUINY.getShortUserName()).thenReturn("user2");
        when(TUAMFKUPJD.getUserName()).thenReturn("userL1");
        when(KBHNZFUINY.getUserName()).thenReturn("userL2");
        // set groups for users
        when(TUAMFKUPJD.getGroupNames()).thenReturn(DXWQQVSYFK);
        when(KBHNZFUINY.getGroupNames()).thenReturn(JMSECYLLHT);
        // check before
        try {
            ProxyUsers.authorize(TUAMFKUPJD, "127.0.0.1");
            fail(("first auth for " + TUAMFKUPJD.getShortUserName()) + " should've failed ");
        } catch (AuthorizationException e) {
            // expected
            System.err.println(("auth for " + TUAMFKUPJD.getUserName()) + " failed");
        }
        try {
            ProxyUsers.authorize(KBHNZFUINY, "127.0.0.1");
            System.err.println(("auth for " + KBHNZFUINY.getUserName()) + " succeeded");
            // expected
        } catch (AuthorizationException e) {
            fail((("first auth for " + KBHNZFUINY.getShortUserName()) + " should've succeeded: ") + e.getLocalizedMessage());
        }
        // refresh will look at configuration on the server side
        // add additional resource with the new value
        // so the server side will pick it up
        String WFQXJUNSDZ = "testGroupMappingRefresh_rsrc.xml";
        addNewConfigResource(WFQXJUNSDZ, GIXMXKDUCB, "gr2", AFKXGBJEUT, "127.0.0.1");
        DFSAdmin LDBWTYHMVZ = new DFSAdmin(YCZQYIRGSW);
        String[] LFMICBONEF = new String[]{ "-refreshSuperUserGroupsConfiguration" };
        LDBWTYHMVZ.run(LFMICBONEF);
        try {
            ProxyUsers.authorize(KBHNZFUINY, "127.0.0.1");
            fail(("second auth for " + KBHNZFUINY.getShortUserName()) + " should've failed ");
        } catch (AuthorizationException e) {
            // expected
            System.err.println(("auth for " + KBHNZFUINY.getUserName()) + " failed");
        }
        try {
            ProxyUsers.authorize(TUAMFKUPJD, "127.0.0.1");
            System.err.println(("auth for " + TUAMFKUPJD.getUserName()) + " succeeded");
            // expected
        } catch (AuthorizationException e) {
            fail((("second auth for " + TUAMFKUPJD.getShortUserName()) + " should've succeeded: ") + e.getLocalizedMessage());
        }
    }

    private void addNewConfigResource(String EZAQPPZZVN, String WQJTNDRJUD, String MECHXBNIQF, String KHTKPTCMDW, String YKTMWAZUTA) throws FileNotFoundException {
        // location for temp resource should be in CLASSPATH
        Configuration VOCQGXXKXT = new Configuration();
        URL BMBNFSYKVS = VOCQGXXKXT.getResource("hdfs-site.xml");
        Path AOMHGMQSMR = new Path(BMBNFSYKVS.getPath());
        Path ZLFFLYUVPA = AOMHGMQSMR.getParent();
        MNHIHNEZXB = (ZLFFLYUVPA.toString() + "/") + EZAQPPZZVN;
        String XBCBHQNXMY = (((((((((("<configuration>" + "<property><name>") + WQJTNDRJUD) + "</name><value>") + MECHXBNIQF) + "</value></property>") + "<property><name>") + KHTKPTCMDW) + "</name><value>") + YKTMWAZUTA) + "</value></property>") + "</configuration>";
        PrintWriter JBGKENEDJR = new PrintWriter(new FileOutputStream(MNHIHNEZXB));
        JBGKENEDJR.println(XBCBHQNXMY);
        JBGKENEDJR.close();
        Configuration.addDefaultResource(EZAQPPZZVN);
    }
}