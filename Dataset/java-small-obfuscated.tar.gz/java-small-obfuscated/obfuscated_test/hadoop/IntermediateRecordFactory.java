/**
 * Factory passing reduce specification as its last record.
 */
class IntermediateRecordFactory extends RecordFactory {
    private final Spec UWYXXSEAXM;

    private final RecordFactory AOEKXGIYQC;

    private final int EIXEWNWWRG;

    private final long NOTKQDTHBU;

    private boolean DGJVXTVXMQ = false;

    private long LRZVNQMQSC = 0L;

    /**
     *
     *
     * @param targetBytes
     * 		Expected byte count.
     * @param targetRecords
     * 		Expected record count; will emit spec records after
     * 		this boundary is passed.
     * @param partition
     * 		Reduce to which records are emitted.
     * @param spec
     * 		Specification to emit.
     * @param conf
     * 		Unused.
     */
    public IntermediateRecordFactory(long OSZGNSMMED, long GNQFOMEZWU, int HXSZXSFBZZ, GridmixKey.Spec SPGPETYEBF, Configuration RXYBMQXLEA) {
        this(new AvgRecordFactory(OSZGNSMMED, GNQFOMEZWU, RXYBMQXLEA), HXSZXSFBZZ, GNQFOMEZWU, SPGPETYEBF, RXYBMQXLEA);
    }

    /**
     *
     *
     * @param factory
     * 		Factory from which byte/record counts are obtained.
     * @param partition
     * 		Reduce to which records are emitted.
     * @param targetRecords
     * 		Expected record count; will emit spec records after
     * 		this boundary is passed.
     * @param spec
     * 		Specification to emit.
     * @param conf
     * 		Unused.
     */
    public IntermediateRecordFactory(RecordFactory WXFXOUKNHZ, int SSVTYBUWQI, long HKIOQGEMWZ, GridmixKey.Spec QWLTIBCSOE, Configuration LOVOATZNQZ) {
        this.UWYXXSEAXM = QWLTIBCSOE;
        this.AOEKXGIYQC = WXFXOUKNHZ;
        this.EIXEWNWWRG = SSVTYBUWQI;
        this.NOTKQDTHBU = HKIOQGEMWZ;
    }

    @Override
    public boolean next(GridmixKey RXFRWENOOM, GridmixRecord XBPDKEVZSW) throws IOException {
        assert RXFRWENOOM != null;
        final boolean QNYHQSEVYT = AOEKXGIYQC.next(RXFRWENOOM, XBPDKEVZSW);
        ++LRZVNQMQSC;
        if (QNYHQSEVYT) {
            if (LRZVNQMQSC < NOTKQDTHBU) {
                RXFRWENOOM.setType(DATA);
            } else {
                final int KEYDZAKXDY = RXFRWENOOM.getSize();
                RXFRWENOOM.setType(REDUCE_SPEC);
                UWYXXSEAXM.rec_in = LRZVNQMQSC;
                RXFRWENOOM.setSpec(UWYXXSEAXM);
                XBPDKEVZSW.setSize(XBPDKEVZSW.getSize() - (RXFRWENOOM.getSize() - KEYDZAKXDY));
                // reset counters
                LRZVNQMQSC = 0L;
                UWYXXSEAXM.bytes_out = 0L;
                UWYXXSEAXM.rec_out = 0L;
                DGJVXTVXMQ = true;
            }
        } else
            if (!DGJVXTVXMQ) {
                // ensure spec emitted
                RXFRWENOOM.setType(REDUCE_SPEC);
                RXFRWENOOM.setPartition(EIXEWNWWRG);
                RXFRWENOOM.setSize(0);
                XBPDKEVZSW.setSize(0);
                UWYXXSEAXM.rec_in = 0L;
                RXFRWENOOM.setSpec(UWYXXSEAXM);
                DGJVXTVXMQ = true;
                return true;
            }

        RXFRWENOOM.setPartition(EIXEWNWWRG);
        return QNYHQSEVYT;
    }

    @Override
    public float getProgress() throws IOException {
        return AOEKXGIYQC.getProgress();
    }

    @Override
    public void close() throws IOException {
        AOEKXGIYQC.close();
    }
}