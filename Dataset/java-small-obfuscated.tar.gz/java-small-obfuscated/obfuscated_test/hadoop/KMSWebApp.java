@InterfaceAudience.Private
public class KMSWebApp implements ServletContextListener {
    private static final String HDWFGGDVHV = "kms-log4j.properties";

    private static final String BWNKZEEXYP = "hadoop.kms.";

    private static final String QHRWSEEHXV = KMSWebApp.BWNKZEEXYP + "admin.calls.meter";

    private static final String PIHPHHJAIH = KMSWebApp.BWNKZEEXYP + "key.calls.meter";

    private static final String OYCJCPVEZH = KMSWebApp.BWNKZEEXYP + "invalid.calls.meter";

    private static final String TRCNDKJARN = KMSWebApp.BWNKZEEXYP + "unauthorized.calls.meter";

    private static final String HHYSIJMRPJ = KMSWebApp.BWNKZEEXYP + "unauthenticated.calls.meter";

    private static final String BHHVIKBWUU = KMSWebApp.BWNKZEEXYP + "generate_eek.calls.meter";

    private static final String XIOKKOQXYA = KMSWebApp.BWNKZEEXYP + "decrypt_eek.calls.meter";

    private static Logger QSEMAKQWGN;

    private static MetricRegistry JLTBCQVEPB;

    private JmxReporter EDXTEVVAFY;

    private static Configuration EKJPAZKUEI;

    private static KMSACLs BDEZNUKTPC;

    private static Meter QJQLBGWSKP;

    private static Meter IKYIQKNSBN;

    private static Meter IZCUAZAXNU;

    private static Meter DIGZSDTANT;

    private static Meter UJDDCBGFZD;

    private static Meter DZEDFOAUZN;

    private static Meter ZNPPWAKZJT;

    private static KMSAudit XLOPWDFWND;

    private static KeyProviderCryptoExtension YULMHNUYKO;

    static {
        SLF4JBridgeHandler.removeHandlersForRootLogger();
        SLF4JBridgeHandler.install();
    }

    private void initLogging(String HKUECQKFDG) {
        if (System.getProperty("log4j.configuration") == null) {
            System.setProperty("log4j.defaultInitOverride", "true");
            boolean ZPPKEYWIKZ = true;
            File MYVRMXWIIN = new File(HKUECQKFDG, KMSWebApp.HDWFGGDVHV).getAbsoluteFile();
            if (MYVRMXWIIN.exists()) {
                PropertyConfigurator.configureAndWatch(MYVRMXWIIN.getPath(), 1000);
                ZPPKEYWIKZ = false;
            } else {
                ClassLoader CNJEEIBPLX = Thread.currentThread().getContextClassLoader();
                URL QJBYHAWRQT = CNJEEIBPLX.getResource(KMSWebApp.HDWFGGDVHV);
                if (QJBYHAWRQT != null) {
                    PropertyConfigurator.configure(QJBYHAWRQT);
                }
            }
            KMSWebApp.QSEMAKQWGN = LoggerFactory.getLogger(KMSWebApp.class);
            KMSWebApp.QSEMAKQWGN.debug("KMS log starting");
            if (ZPPKEYWIKZ) {
                KMSWebApp.QSEMAKQWGN.warn("Log4j configuration file '{}' not found", KMSWebApp.HDWFGGDVHV);
                KMSWebApp.QSEMAKQWGN.warn("Logging with INFO level to standard output");
            }
        } else {
            KMSWebApp.QSEMAKQWGN = LoggerFactory.getLogger(KMSWebApp.class);
        }
    }

    @Override
    public void contextInitialized(ServletContextEvent EVMYFHKDHH) {
        try {
            String AGIDBYSSNL = System.getProperty(KMS_CONFIG_DIR);
            if (AGIDBYSSNL == null) {
                throw new RuntimeException(("System property '" + KMSConfiguration.KMS_CONFIG_DIR) + "' not defined");
            }
            KMSWebApp.EKJPAZKUEI = KMSConfiguration.getKMSConf();
            initLogging(AGIDBYSSNL);
            KMSWebApp.QSEMAKQWGN.info("-------------------------------------------------------------");
            KMSWebApp.QSEMAKQWGN.info("  Java runtime version : {}", System.getProperty("java.runtime.version"));
            KMSWebApp.QSEMAKQWGN.info("  KMS Hadoop Version: " + VersionInfo.getVersion());
            KMSWebApp.QSEMAKQWGN.info("-------------------------------------------------------------");
            KMSWebApp.BDEZNUKTPC = new KMSACLs();
            KMSWebApp.BDEZNUKTPC.startReloader();
            KMSWebApp.JLTBCQVEPB = new MetricRegistry();
            EDXTEVVAFY = JmxReporter.forRegistry(KMSWebApp.JLTBCQVEPB).build();
            EDXTEVVAFY.start();
            KMSWebApp.DZEDFOAUZN = KMSWebApp.JLTBCQVEPB.register(KMSWebApp.BHHVIKBWUU, new Meter());
            KMSWebApp.UJDDCBGFZD = KMSWebApp.JLTBCQVEPB.register(KMSWebApp.XIOKKOQXYA, new Meter());
            KMSWebApp.QJQLBGWSKP = KMSWebApp.JLTBCQVEPB.register(KMSWebApp.QHRWSEEHXV, new Meter());
            KMSWebApp.IKYIQKNSBN = KMSWebApp.JLTBCQVEPB.register(KMSWebApp.PIHPHHJAIH, new Meter());
            KMSWebApp.ZNPPWAKZJT = KMSWebApp.JLTBCQVEPB.register(KMSWebApp.OYCJCPVEZH, new Meter());
            KMSWebApp.IZCUAZAXNU = KMSWebApp.JLTBCQVEPB.register(KMSWebApp.TRCNDKJARN, new Meter());
            KMSWebApp.DIGZSDTANT = KMSWebApp.JLTBCQVEPB.register(KMSWebApp.HHYSIJMRPJ, new Meter());
            KMSWebApp.XLOPWDFWND = new KMSAudit(KMSWebApp.EKJPAZKUEI.getLong(KMS_AUDIT_AGGREGATION_DELAY, KMS_AUDIT_AGGREGATION_DELAY_DEFAULT));
            // this is required for the the JMXJsonServlet to work properly.
            // the JMXJsonServlet is behind the authentication filter,
            // thus the '*' ACL.
            EVMYFHKDHH.getServletContext().setAttribute(HttpServer2.CONF_CONTEXT_ATTRIBUTE, KMSWebApp.EKJPAZKUEI);
            EVMYFHKDHH.getServletContext().setAttribute(HttpServer2.ADMINS_ACL, new AccessControlList(AccessControlList.WILDCARD_ACL_VALUE));
            // intializing the KeyProvider
            List<KeyProvider> XPKVFZARPY = KeyProviderFactory.getProviders(KMSWebApp.EKJPAZKUEI);
            if (XPKVFZARPY.isEmpty()) {
                throw new IllegalStateException("No KeyProvider has been defined");
            }
            if (XPKVFZARPY.size() > 1) {
                KMSWebApp.QSEMAKQWGN.warn("There is more than one KeyProvider configured '{}', using " + "the first provider", KMSWebApp.EKJPAZKUEI.get(KEY_PROVIDER_PATH));
            }
            KeyProvider OIGISPRAXW = XPKVFZARPY.get(0);
            if (KMSWebApp.EKJPAZKUEI.getBoolean(KEY_CACHE_ENABLE, KEY_CACHE_ENABLE_DEFAULT)) {
                long CXYRKDNJUT = KMSWebApp.EKJPAZKUEI.getLong(KEY_CACHE_TIMEOUT_KEY, KEY_CACHE_TIMEOUT_DEFAULT);
                long RSUSMERUUJ = KMSWebApp.EKJPAZKUEI.getLong(CURR_KEY_CACHE_TIMEOUT_KEY, CURR_KEY_CACHE_TIMEOUT_DEFAULT);
                OIGISPRAXW = new org.apache.hadoop.crypto.key.CachingKeyProvider(OIGISPRAXW, CXYRKDNJUT, RSUSMERUUJ);
            }
            KMSWebApp.QSEMAKQWGN.info("Initialized KeyProvider " + OIGISPRAXW);
            KMSWebApp.YULMHNUYKO = KeyProviderCryptoExtension.createKeyProviderCryptoExtension(OIGISPRAXW);
            KMSWebApp.YULMHNUYKO = new EagerKeyGeneratorKeyProviderCryptoExtension(KMSWebApp.EKJPAZKUEI, KMSWebApp.YULMHNUYKO);
            KMSWebApp.QSEMAKQWGN.info("Initialized KeyProviderCryptoExtension " + KMSWebApp.YULMHNUYKO);
            final int PJRYFUDQPU = KMSWebApp.EKJPAZKUEI.getInt(DEFAULT_BITLENGTH_NAME, DEFAULT_BITLENGTH);
            KMSWebApp.QSEMAKQWGN.info("Default key bitlength is {}", PJRYFUDQPU);
            KMSWebApp.QSEMAKQWGN.info("KMS Started");
        } catch (Throwable ex) {
            System.out.println();
            System.out.println("ERROR: Hadoop KMS could not be started");
            System.out.println();
            System.out.println("REASON: " + ex.toString());
            System.out.println();
            System.out.println("Stacktrace:");
            System.out.println("---------------------------------------------------");
            ex.printStackTrace(System.out);
            System.out.println("---------------------------------------------------");
            System.out.println();
            System.exit(1);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent DQINNRRMSH) {
        KMSWebApp.XLOPWDFWND.shutdown();
        KMSWebApp.BDEZNUKTPC.stopReloader();
        EDXTEVVAFY.stop();
        EDXTEVVAFY.close();
        KMSWebApp.JLTBCQVEPB = null;
        KMSWebApp.QSEMAKQWGN.info("KMS Stopped");
    }

    public static Configuration getConfiguration() {
        return new Configuration(KMSWebApp.EKJPAZKUEI);
    }

    public static KMSACLs getACLs() {
        return KMSWebApp.BDEZNUKTPC;
    }

    public static Meter getAdminCallsMeter() {
        return KMSWebApp.QJQLBGWSKP;
    }

    public static Meter getKeyCallsMeter() {
        return KMSWebApp.IKYIQKNSBN;
    }

    public static Meter getInvalidCallsMeter() {
        return KMSWebApp.ZNPPWAKZJT;
    }

    public static Meter getGenerateEEKCallsMeter() {
        return KMSWebApp.DZEDFOAUZN;
    }

    public static Meter getDecryptEEKCallsMeter() {
        return KMSWebApp.UJDDCBGFZD;
    }

    public static Meter getUnauthorizedCallsMeter() {
        return KMSWebApp.IZCUAZAXNU;
    }

    public static Meter getUnauthenticatedCallsMeter() {
        return KMSWebApp.DIGZSDTANT;
    }

    public static KeyProviderCryptoExtension getKeyProvider() {
        return KMSWebApp.YULMHNUYKO;
    }

    public static KMSAudit getKMSAudit() {
        return KMSWebApp.XLOPWDFWND;
    }
}