/**
 * Class to store CLI Test Comparators Data
 */
public class ComparatorData {
    private String AVCYAPSUQR = null;

    private String CVRTLCYRAS = null;

    private boolean PWBVYNOVZK = false;

    private int KIMXHNTFDS = 0;

    private String HLNEEMECYT = null;

    public ComparatorData() {
    }

    /**
     *
     *
     * @return the expectedOutput
     */
    public String getExpectedOutput() {
        return AVCYAPSUQR;
    }

    /**
     *
     *
     * @param expectedOutput
     * 		the expectedOutput to set
     */
    public void setExpectedOutput(String FBRRBTADWT) {
        this.AVCYAPSUQR = FBRRBTADWT;
    }

    /**
     *
     *
     * @return the actualOutput
     */
    public String getActualOutput() {
        return CVRTLCYRAS;
    }

    /**
     *
     *
     * @param actualOutput
     * 		the actualOutput to set
     */
    public void setActualOutput(String NDWDDVAMVU) {
        this.CVRTLCYRAS = NDWDDVAMVU;
    }

    /**
     *
     *
     * @return the testResult
     */
    public boolean getTestResult() {
        return PWBVYNOVZK;
    }

    /**
     *
     *
     * @param testResult
     * 		the testResult to set
     */
    public void setTestResult(boolean VOXTBJFDII) {
        this.PWBVYNOVZK = VOXTBJFDII;
    }

    /**
     *
     *
     * @return the exitCode
     */
    public int getExitCode() {
        return KIMXHNTFDS;
    }

    /**
     *
     *
     * @param exitCode
     * 		the exitCode to set
     */
    public void setExitCode(int QDVHYDLKCG) {
        this.KIMXHNTFDS = QDVHYDLKCG;
    }

    /**
     *
     *
     * @return the comparatorType
     */
    public String getComparatorType() {
        return HLNEEMECYT;
    }

    /**
     *
     *
     * @param comparatorType
     * 		the comparatorType to set
     */
    public void setComparatorType(String DQQNKFVIYO) {
        this.HLNEEMECYT = DQQNKFVIYO;
    }
}