/**
 * This is a generic input stream for verifying checksums for
 * data before it is read by a user.
 */
@InterfaceAudience.LimitedPrivate({ "HDFS" })
@InterfaceStability.Unstable
public abstract class FSInputChecker extends FSInputStream {
    public static final Log VHUSPNNJNH = LogFactory.getLog(FSInputChecker.class);

    /**
     * The file name from which data is read from
     */
    protected Path EZRXUAZIQC;

    private Checksum BOZSVZHJNF;

    private boolean BOWBJACOXR = true;

    private int TYFGPMTHVI;// data bytes for checksum (eg 512)


    private byte[] DLSRRBCNCQ;// buffer for non-chunk-aligned reading


    private byte[] MAEOILKLFE;

    private IntBuffer UKAYQWQAHX;// wrapper on checksum buffer


    private int GQYQSUDAPE;// the position of the reader inside buf


    private int OANLWAXCGR;// the number of bytes currently in buf


    private int WERDVSSXXO;

    // cached file position
    // this should always be a multiple of maxChunkSize
    private long PNMSJQFESD = 0;

    // Number of checksum chunks that can be read at once into a user
    // buffer. Chosen by benchmarks - higher values do not reduce
    // CPU usage. The size of the data reads made to the underlying stream
    // will be CHUNKS_PER_READ * maxChunkSize.
    private static final int WWDGGYGWAX = 32;

    protected static final int TDSUCATSWS = 4;// 32-bit checksum


    /**
     * Constructor
     *
     * @param file
     * 		The name of the file to be read
     * @param numOfRetries
     * 		Number of read retries when ChecksumError occurs
     */
    protected FSInputChecker(Path IUMDMTRXVF, int XVSMONAPXY) {
        this.EZRXUAZIQC = IUMDMTRXVF;
        this.WERDVSSXXO = XVSMONAPXY;
    }

    /**
     * Constructor
     *
     * @param file
     * 		The name of the file to be read
     * @param numOfRetries
     * 		Number of read retries when ChecksumError occurs
     * @param sum
     * 		the type of Checksum engine
     * @param chunkSize
     * 		maximun chunk size
     * @param checksumSize
     * 		the number byte of each checksum
     */
    protected FSInputChecker(Path XQUJQQZZCI, int WHCNXHJXZE, boolean BCBZLCAMJN, Checksum OKNXBCOFRD, int PGSSUGILCP, int RUZAUWVLHG) {
        this(XQUJQQZZCI, WHCNXHJXZE);
        set(BCBZLCAMJN, OKNXBCOFRD, PGSSUGILCP, RUZAUWVLHG);
    }

    /**
     * Reads in checksum chunks into <code>buf</code> at <code>offset</code>
     * and checksum into <code>checksum</code>.
     * Since checksums can be disabled, there are two cases implementors need
     * to worry about:
     *
     *  (a) needChecksum() will return false:
     *     - len can be any positive value
     *     - checksum will be null
     *     Implementors should simply pass through to the underlying data stream.
     * or
     *  (b) needChecksum() will return true:
     *    - len >= maxChunkSize
     *    - checksum.length is a multiple of CHECKSUM_SIZE
     *    Implementors should read an integer number of data chunks into
     *    buf. The amount read should be bounded by len or by
     *    checksum.length / CHECKSUM_SIZE * maxChunkSize. Note that len may
     *    be a value that is not a multiple of maxChunkSize, in which case
     *    the implementation may return less than len.
     *
     * The method is used for implementing read, therefore, it should be optimized
     * for sequential reading.
     *
     * @param pos
     * 		chunkPos
     * @param buf
     * 		desitination buffer
     * @param offset
     * 		offset in buf at which to store data
     * @param len
     * 		maximum number of bytes to read
     * @param checksum
     * 		the data buffer into which to write checksums
     * @return number of bytes read
     */
    protected abstract int readChunk(long XOLVVUUTRT, byte[] MCACCKFSAM, int SNSOSUCTLL, int STDYJHNBUE, byte[] SSXRUWJWBY) throws IOException;

    /**
     * Return position of beginning of chunk containing pos.
     *
     * @param pos
     * 		a postion in the file
     * @return the starting position of the chunk which contains the byte
     */
    protected abstract long getChunkPosition(long RNIJRBCRZK);

    /**
     * Return true if there is a need for checksum verification
     */
    protected synchronized boolean needChecksum() {
        return BOWBJACOXR && (BOZSVZHJNF != null);
    }

    /**
     * Read one checksum-verified byte
     *
     * @return the next byte of data, or <code>-1</code> if the end of the
    stream is reached.
     * @exception IOException  if an I/O error occurs.
     */
    @Override
    public synchronized int read() throws IOException {
        if (GQYQSUDAPE >= OANLWAXCGR) {
            fill();
            if (GQYQSUDAPE >= OANLWAXCGR) {
                return -1;
            }
        }
        return DLSRRBCNCQ[GQYQSUDAPE++] & 0xff;
    }

    /**
     * Read checksum verified bytes from this byte-input stream into
     * the specified byte array, starting at the given offset.
     *
     * <p> This method implements the general contract of the corresponding
     * <code>{@link InputStream#read(byte[], int, int) read}</code> method of
     * the <code>{@link InputStream}</code> class.  As an additional
     * convenience, it attempts to read as many bytes as possible by repeatedly
     * invoking the <code>read</code> method of the underlying stream.  This
     * iterated <code>read</code> continues until one of the following
     * conditions becomes true: <ul>
     *
     *   <li> The specified number of bytes have been read,
     *
     *   <li> The <code>read</code> method of the underlying stream returns
     *   <code>-1</code>, indicating end-of-file.
     *
     * </ul> If the first <code>read</code> on the underlying stream returns
     * <code>-1</code> to indicate end-of-file then this method returns
     * <code>-1</code>.  Otherwise this method returns the number of bytes
     * actually read.
     *
     * @param b
     * 		destination buffer.
     * @param off
     * 		offset at which to start storing bytes.
     * @param len
     * 		maximum number of bytes to read.
     * @return the number of bytes read, or <code>-1</code> if the end of
    the stream has been reached.
     * @exception IOException  if an I/O error occurs.
    ChecksumException if any checksum error occurs
     */
    @Override
    public synchronized int read(byte[] WGSYEDSKLO, int QGFCVAVHUX, int BNTRLOWREU) throws IOException {
        // parameter check
        if ((((QGFCVAVHUX | BNTRLOWREU) | (QGFCVAVHUX + BNTRLOWREU)) | (WGSYEDSKLO.length - (QGFCVAVHUX + BNTRLOWREU))) < 0) {
            throw new IndexOutOfBoundsException();
        } else
            if (BNTRLOWREU == 0) {
                return 0;
            }

        int FPOJOAIBVW = 0;
        for (; ;) {
            int YDNZMQRJJT = read1(WGSYEDSKLO, QGFCVAVHUX + FPOJOAIBVW, BNTRLOWREU - FPOJOAIBVW);
            if (YDNZMQRJJT <= 0)
                return FPOJOAIBVW == 0 ? YDNZMQRJJT : FPOJOAIBVW;

            FPOJOAIBVW += YDNZMQRJJT;
            if (FPOJOAIBVW >= BNTRLOWREU)
                return FPOJOAIBVW;

        }
    }

    /**
     * Fills the buffer with a chunk data.
     * No mark is supported.
     * This method assumes that all data in the buffer has already been read in,
     * hence pos > count.
     */
    private void fill() throws IOException {
        assert GQYQSUDAPE >= OANLWAXCGR;
        // fill internal buffer
        OANLWAXCGR = readChecksumChunk(DLSRRBCNCQ, 0, TYFGPMTHVI);
        if (OANLWAXCGR < 0)
            OANLWAXCGR = 0;

    }

    /* Read characters into a portion of an array, reading from the underlying
    stream at most once if necessary.
     */
    private int read1(byte[] WEOMBCGBQQ, int YBFFFXIQEH, int SNXWISIVTJ) throws IOException {
        int INOMFVAEXE = OANLWAXCGR - GQYQSUDAPE;
        if (INOMFVAEXE <= 0) {
            if (SNXWISIVTJ >= TYFGPMTHVI) {
                // read a chunk to user buffer directly; avoid one copy
                int VMIYIZLPCJ = readChecksumChunk(WEOMBCGBQQ, YBFFFXIQEH, SNXWISIVTJ);
                return VMIYIZLPCJ;
            } else {
                // read a chunk into the local buffer
                fill();
                if (OANLWAXCGR <= 0) {
                    return -1;
                } else {
                    INOMFVAEXE = OANLWAXCGR;
                }
            }
        }
        // copy content of the local buffer to the user buffer
        int OWLXLAYJIS = (INOMFVAEXE < SNXWISIVTJ) ? INOMFVAEXE : SNXWISIVTJ;
        System.arraycopy(DLSRRBCNCQ, GQYQSUDAPE, WEOMBCGBQQ, YBFFFXIQEH, OWLXLAYJIS);
        GQYQSUDAPE += OWLXLAYJIS;
        return OWLXLAYJIS;
    }

    /* Read up one or more checksum chunk to array <i>b</i> at pos <i>off</i>
    It requires at least one checksum chunk boundary
    in between <cur_pos, cur_pos+len> 
    and it stops reading at the last boundary or at the end of the stream;
    Otherwise an IllegalArgumentException is thrown.
    This makes sure that all data read are checksum verified.

    @param b   the buffer into which the data is read.
    @param off the start offset in array <code>b</code>
               at which the data is written.
    @param len the maximum number of bytes to read.
    @return    the total number of bytes read into the buffer, or
               <code>-1</code> if there is no more data because the end of
               the stream has been reached.
    @throws IOException if an I/O error occurs.
     */
    private int readChecksumChunk(byte[] VFTBMRHMHG, final int VCGUFPNEHU, final int XGCBBHXTYK) throws IOException {
        // invalidate buffer
        OANLWAXCGR = GQYQSUDAPE = 0;
        int ZMKVAPDNFN = 0;
        boolean EVMZHOQEIR = true;
        int LNYXGXGILC = WERDVSSXXO;
        do {
            LNYXGXGILC--;
            try {
                ZMKVAPDNFN = readChunk(PNMSJQFESD, VFTBMRHMHG, VCGUFPNEHU, XGCBBHXTYK, MAEOILKLFE);
                if (ZMKVAPDNFN > 0) {
                    if (needChecksum()) {
                        verifySums(VFTBMRHMHG, VCGUFPNEHU, ZMKVAPDNFN);
                    }
                    PNMSJQFESD += ZMKVAPDNFN;
                }
                EVMZHOQEIR = false;
            } catch (ChecksumException ce) {
                FSInputChecker.VHUSPNNJNH.info((((("Found checksum error: b[" + VCGUFPNEHU) + ", ") + (VCGUFPNEHU + ZMKVAPDNFN)) + "]=") + StringUtils.byteToHexString(VFTBMRHMHG, VCGUFPNEHU, VCGUFPNEHU + ZMKVAPDNFN), ce);
                if (LNYXGXGILC == 0) {
                    throw ce;
                }
                // try a new replica
                if (seekToNewSource(PNMSJQFESD)) {
                    // Since at least one of the sources is different,
                    // the read might succeed, so we'll retry.
                    seek(PNMSJQFESD);
                } else {
                    // Neither the data stream nor the checksum stream are being read
                    // from different sources, meaning we'll still get a checksum error
                    // if we try to do the read again.  We throw an exception instead.
                    throw ce;
                }
            }
        } while (EVMZHOQEIR );
        return ZMKVAPDNFN;
    }

    private void verifySums(final byte[] XVWELLYLXW, final int CEHDDJVTVJ, int YOCDFAKGCB) throws ChecksumException {
        int UQBTXOFMUM = YOCDFAKGCB;
        int ZGLWCCYZGU = 0;
        UKAYQWQAHX.rewind();
        UKAYQWQAHX.limit(((YOCDFAKGCB - 1) / TYFGPMTHVI) + 1);
        while (UQBTXOFMUM > 0) {
            BOZSVZHJNF.update(XVWELLYLXW, CEHDDJVTVJ + ZGLWCCYZGU, Math.min(UQBTXOFMUM, TYFGPMTHVI));
            int ABKJSPSIPU = UKAYQWQAHX.get();
            int TXFGYBBNIH = ((int) (BOZSVZHJNF.getValue()));
            BOZSVZHJNF.reset();
            if (ABKJSPSIPU != TXFGYBBNIH) {
                long QTAYWJFNZQ = PNMSJQFESD + ZGLWCCYZGU;
                throw new ChecksumException((((((("Checksum error: " + EZRXUAZIQC) + " at ") + QTAYWJFNZQ) + " exp: ") + ABKJSPSIPU) + " got: ") + TXFGYBBNIH, QTAYWJFNZQ);
            }
            UQBTXOFMUM -= TYFGPMTHVI;
            ZGLWCCYZGU += TYFGPMTHVI;
        } 
    }

    /**
     * Convert a checksum byte array to a long
     * This is deprecated since 0.22 since it is no longer in use
     * by this class.
     */
    @Deprecated
    public static long checksum2long(byte[] TMKIRZQKWM) {
        long UVOSUXGJFW = 0L;
        for (int VPLSQLLKEL = 0; VPLSQLLKEL < TMKIRZQKWM.length; VPLSQLLKEL++) {
            UVOSUXGJFW |= (0xffL & ((long) (TMKIRZQKWM[VPLSQLLKEL]))) << (((TMKIRZQKWM.length - VPLSQLLKEL) - 1) * 8);
        }
        return UVOSUXGJFW;
    }

    @Override
    public synchronized long getPos() throws IOException {
        return PNMSJQFESD - Math.max(0L, OANLWAXCGR - GQYQSUDAPE);
    }

    @Override
    public synchronized int available() throws IOException {
        return Math.max(0, OANLWAXCGR - GQYQSUDAPE);
    }

    /**
     * Skips over and discards <code>n</code> bytes of data from the
     * input stream.
     *
     * <p>This method may skip more bytes than are remaining in the backing
     * file. This produces no exception and the number of bytes skipped
     * may include some number of bytes that were beyond the EOF of the
     * backing file. Attempting to read from the stream after skipping past
     * the end will result in -1 indicating the end of the file.
     *
     * <p>If <code>n</code> is negative, no bytes are skipped.
     *
     * @param n
     * 		the number of bytes to be skipped.
     * @return the actual number of bytes skipped.
     * @exception IOException  if an I/O error occurs.
    ChecksumException if the chunk to skip to is corrupted
     */
    @Override
    public synchronized long skip(long RFAINYAJXB) throws IOException {
        if (RFAINYAJXB <= 0) {
            return 0;
        }
        seek(getPos() + RFAINYAJXB);
        return RFAINYAJXB;
    }

    /**
     * Seek to the given position in the stream.
     * The next read() will be from that position.
     *
     * <p>This method may seek past the end of the file.
     * This produces no exception and an attempt to read from
     * the stream will result in -1 indicating the end of the file.
     *
     * @param pos
     * 		the postion to seek to.
     * @exception IOException  if an I/O error occurs.
    ChecksumException if the chunk to seek to is corrupted
     */
    @Override
    public synchronized void seek(long COQSJVWSAY) throws IOException {
        if (COQSJVWSAY < 0) {
            throw new EOFException(FSExceptionMessages.NEGATIVE_SEEK);
        }
        // optimize: check if the pos is in the buffer
        long LRHFNQUBME = PNMSJQFESD - this.OANLWAXCGR;
        if ((COQSJVWSAY >= LRHFNQUBME) && (COQSJVWSAY < PNMSJQFESD)) {
            this.GQYQSUDAPE = ((int) (COQSJVWSAY - LRHFNQUBME));
            return;
        }
        // reset the current state
        resetState();
        // seek to a checksum boundary
        PNMSJQFESD = getChunkPosition(COQSJVWSAY);
        // scan to the desired position
        int YYXESLYEXM = ((int) (COQSJVWSAY - PNMSJQFESD));
        if (YYXESLYEXM > 0) {
            FSInputChecker.readFully(this, new byte[YYXESLYEXM], 0, YYXESLYEXM);
        }
    }

    /**
     * A utility function that tries to read up to <code>len</code> bytes from
     * <code>stm</code>
     *
     * @param stm
     * 		an input stream
     * @param buf
     * 		destiniation buffer
     * @param offset
     * 		offset at which to store data
     * @param len
     * 		number of bytes to read
     * @return actual number of bytes read
     * @throws IOException
     * 		if there is any IO error
     */
    protected static int readFully(InputStream TCTOLBURZC, byte[] WHPNNLXVQM, int JXRQWPZLRT, int OOSUAFRDPP) throws IOException {
        int PUHGTSSJFA = 0;
        for (; ;) {
            int SDRKFZFSSD = TCTOLBURZC.read(WHPNNLXVQM, JXRQWPZLRT + PUHGTSSJFA, OOSUAFRDPP - PUHGTSSJFA);
            if (SDRKFZFSSD <= 0)
                return PUHGTSSJFA == 0 ? SDRKFZFSSD : PUHGTSSJFA;

            PUHGTSSJFA += SDRKFZFSSD;
            if (PUHGTSSJFA >= OOSUAFRDPP)
                return PUHGTSSJFA;

        }
    }

    /**
     * Set the checksum related parameters
     *
     * @param verifyChecksum
     * 		whether to verify checksum
     * @param sum
     * 		which type of checksum to use
     * @param maxChunkSize
     * 		maximun chunk size
     * @param checksumSize
     * 		checksum size
     */
    protected synchronized final void set(boolean CTOEPABAHI, Checksum ISXOPCOREN, int KQEUEUFRJM, int NCVIYOIZKO) {
        // The code makes assumptions that checksums are always 32-bit.
        assert ((!CTOEPABAHI) || (ISXOPCOREN == null)) || (NCVIYOIZKO == FSInputChecker.TDSUCATSWS);
        this.TYFGPMTHVI = KQEUEUFRJM;
        this.BOWBJACOXR = CTOEPABAHI;
        this.BOZSVZHJNF = ISXOPCOREN;
        this.DLSRRBCNCQ = new byte[KQEUEUFRJM];
        // The size of the checksum array here determines how much we can
        // read in a single call to readChunk
        this.MAEOILKLFE = new byte[FSInputChecker.WWDGGYGWAX * NCVIYOIZKO];
        this.UKAYQWQAHX = ByteBuffer.wrap(MAEOILKLFE).asIntBuffer();
        this.OANLWAXCGR = 0;
        this.GQYQSUDAPE = 0;
    }

    @Override
    public final boolean markSupported() {
        return false;
    }

    @Override
    public final void mark(int VJYIRJFHMP) {
    }

    @Override
    public final void reset() throws IOException {
        throw new IOException("mark/reset not supported");
    }

    /* reset this FSInputChecker's state */
    private void resetState() {
        // invalidate buffer
        OANLWAXCGR = 0;
        GQYQSUDAPE = 0;
        // reset Checksum
        if (BOZSVZHJNF != null) {
            BOZSVZHJNF.reset();
        }
    }
}