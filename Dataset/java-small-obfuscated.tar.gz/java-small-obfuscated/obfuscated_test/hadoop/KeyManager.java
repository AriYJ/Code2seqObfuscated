/**
 * The class provides utilities for key and token management.
 */
@InterfaceAudience.Private
public class KeyManager implements Closeable , DataEncryptionKeyFactory {
    private static final Log XAYVISRVLQ = LogFactory.getLog(KeyManager.class);

    private final NamenodeProtocol XTNSTNHQVQ;

    private final boolean WKJTSTKLVT;

    private final boolean WXYQLKNUOH;

    private boolean GJPXGAMPON;

    private final BlockTokenSecretManager UIEAZDHNNK;

    private final KeyManager.BlockKeyUpdater YYCOWOVTGY;

    private DataEncryptionKey PNXELDRQZB;

    public KeyManager(String TEMODLJXSC, NamenodeProtocol NHVWUCOVFL, boolean LWWICOWXNL, Configuration HHKNLUKKEK) throws IOException {
        this.XTNSTNHQVQ = NHVWUCOVFL;
        this.WXYQLKNUOH = LWWICOWXNL;
        final ExportedBlockKeys BTVXRZJJEE = NHVWUCOVFL.getBlockKeys();
        this.WKJTSTKLVT = BTVXRZJJEE.isBlockTokenEnabled();
        if (WKJTSTKLVT) {
            long CCNXZEKWSY = BTVXRZJJEE.getKeyUpdateInterval();
            long NLGEYOMSEC = BTVXRZJJEE.getTokenLifetime();
            KeyManager.XAYVISRVLQ.info((("Block token params received from NN: update interval=" + StringUtils.formatTime(CCNXZEKWSY)) + ", token lifetime=") + StringUtils.formatTime(NLGEYOMSEC));
            String OHBJOFUWJI = HHKNLUKKEK.get(DFS_DATA_ENCRYPTION_ALGORITHM_KEY);
            this.UIEAZDHNNK = new BlockTokenSecretManager(CCNXZEKWSY, NLGEYOMSEC, TEMODLJXSC, OHBJOFUWJI);
            this.UIEAZDHNNK.addKeys(BTVXRZJJEE);
            // sync block keys with NN more frequently than NN updates its block keys
            this.YYCOWOVTGY = new KeyManager.BlockKeyUpdater(CCNXZEKWSY / 4);
            this.GJPXGAMPON = true;
        } else {
            this.UIEAZDHNNK = null;
            this.YYCOWOVTGY = null;
        }
    }

    public void startBlockKeyUpdater() {
        if (YYCOWOVTGY != null) {
            YYCOWOVTGY.WZYMNWKBZZ.start();
        }
    }

    /**
     * Get an access token for a block.
     */
    public Token<BlockTokenIdentifier> getAccessToken(ExtendedBlock GTDOFYHQIA) throws IOException {
        if (!WKJTSTKLVT) {
            return BlockTokenSecretManager.DUMMY_TOKEN;
        } else {
            if (!GJPXGAMPON) {
                throw new IOException("Cannot get access token since BlockKeyUpdater is not running");
            }
            return UIEAZDHNNK.generateToken(null, GTDOFYHQIA, EnumSet.of(REPLACE, COPY));
        }
    }

    @Override
    public DataEncryptionKey newDataEncryptionKey() {
        if (WXYQLKNUOH) {
            synchronized(this) {
                if (PNXELDRQZB == null) {
                    PNXELDRQZB = UIEAZDHNNK.generateDataEncryptionKey();
                }
                return PNXELDRQZB;
            }
        } else {
            return null;
        }
    }

    @Override
    public void close() {
        GJPXGAMPON = false;
        try {
            if (YYCOWOVTGY != null) {
                YYCOWOVTGY.WZYMNWKBZZ.interrupt();
            }
        } catch (Exception e) {
            KeyManager.XAYVISRVLQ.warn("Exception shutting down access key updater thread", e);
        }
    }

    /**
     * Periodically updates access keys.
     */
    class BlockKeyUpdater implements Closeable , Runnable {
        private final Daemon WZYMNWKBZZ = new Daemon(this);

        private final long XLGDOIUQLD;

        BlockKeyUpdater(final long sleepInterval) {
            this.XLGDOIUQLD = sleepInterval;
            KeyManager.XAYVISRVLQ.info("Update block keys every " + StringUtils.formatTime(sleepInterval));
        }

        @Override
        public void run() {
            try {
                while (GJPXGAMPON) {
                    try {
                        UIEAZDHNNK.addKeys(XTNSTNHQVQ.getBlockKeys());
                    } catch (IOException e) {
                        KeyManager.XAYVISRVLQ.error("Failed to set keys", e);
                    }
                    Thread.sleep(XLGDOIUQLD);
                } 
            } catch (InterruptedException e) {
                KeyManager.XAYVISRVLQ.debug("InterruptedException in block key updater thread", e);
            } catch (Throwable e) {
                KeyManager.XAYVISRVLQ.error("Exception in block key updater thread", e);
                GJPXGAMPON = false;
            }
        }

        @Override
        public void close() throws IOException {
            try {
                WZYMNWKBZZ.interrupt();
            } catch (Exception e) {
                KeyManager.XAYVISRVLQ.warn("Exception shutting down key updater thread", e);
            }
        }
    }
}