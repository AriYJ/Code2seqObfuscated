/**
 * Tests ACL APIs via WebHDFS.
 */
public class TestWebHDFSAcl extends FSAclBaseTest {
    @BeforeClass
    public static void init() throws Exception {
        conf = WebHdfsTestUtil.createConf();
        conf.setBoolean(DFS_NAMENODE_ACLS_ENABLED_KEY, true);
        cluster = new org.apache.hadoop.hdfs.MiniDFSCluster.Builder(conf).numDataNodes(1).build();
        cluster.waitActive();
    }

    /**
     * We need to skip this test on WebHDFS, because WebHDFS currently cannot
     * resolve symlinks.
     */
    @Override
    @Test
    @Ignore
    public void testDefaultAclNewSymlinkIntermediate() {
    }

    /**
     * Overridden to provide a WebHdfsFileSystem wrapper for the super-user.
     *
     * @return WebHdfsFileSystem for super-user
     * @throws Exception
     * 		if creation fails
     */
    @Override
    protected WebHdfsFileSystem createFileSystem() throws Exception {
        return WebHdfsTestUtil.getWebHdfsFileSystem(conf, SCHEME);
    }

    /**
     * Overridden to provide a WebHdfsFileSystem wrapper for a specific user.
     *
     * @param user
     * 		UserGroupInformation specific user
     * @return WebHdfsFileSystem for specific user
     * @throws Exception
     * 		if creation fails
     */
    @Override
    protected WebHdfsFileSystem createFileSystem(UserGroupInformation LFXNJUGGWT) throws Exception {
        return WebHdfsTestUtil.getWebHdfsFileSystemAs(LFXNJUGGWT, conf, SCHEME);
    }
}