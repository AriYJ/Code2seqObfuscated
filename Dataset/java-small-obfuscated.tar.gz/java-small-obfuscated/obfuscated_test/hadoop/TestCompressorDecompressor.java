/**
 * Test for pairs:
 * <pre>
 * SnappyCompressor/SnappyDecompressor
 * Lz4Compressor/Lz4Decompressor
 * BuiltInZlibDeflater/new BuiltInZlibInflater
 *
 *
 * Note: we can't use ZlibCompressor/ZlibDecompressor here
 * because his constructor can throw exception (if native libraries not found)
 * For ZlibCompressor/ZlibDecompressor pair testing used {@code TestZlibCompressorDecompressor}
 *
 * </pre>
 */
public class TestCompressorDecompressor {
    private static final Random JYNSCOXJLR = new Random(12345L);

    @Test
    public void testCompressorDecompressor() {
        // no more for this data
        int SWVIOPTZVW = 44 * 1024;
        byte[] UBUSAIJVUF = TestCompressorDecompressor.generate(SWVIOPTZVW);
        try {
            CompressDecompressTester.of(UBUSAIJVUF).withCompressDecompressPair(new org.apache.hadoop.io.compress.snappy.SnappyCompressor(), new org.apache.hadoop.io.compress.snappy.SnappyDecompressor()).withCompressDecompressPair(new org.apache.hadoop.io.compress.lz4.Lz4Compressor(), new org.apache.hadoop.io.compress.lz4.Lz4Decompressor()).withCompressDecompressPair(new org.apache.hadoop.io.compress.zlib.BuiltInZlibDeflater(), new org.apache.hadoop.io.compress.zlib.BuiltInZlibInflater()).withTestCases(com.google.common.collect.ImmutableSet.of(CompressionTestStrategy.COMPRESS_DECOMPRESS_SINGLE_BLOCK, CompressionTestStrategy.COMPRESS_DECOMPRESS_BLOCK, CompressionTestStrategy.COMPRESS_DECOMPRESS_ERRORS, CompressionTestStrategy.COMPRESS_DECOMPRESS_WITH_EMPTY_STREAM)).test();
        } catch (Exception ex) {
            fail("testCompressorDecompressor error !!!" + ex);
        }
    }

    @Test
    public void testCompressorDecompressorWithExeedBufferLimit() {
        int PCKIEBJEUY = 100 * 1024;
        byte[] RWLSBRRVDZ = TestCompressorDecompressor.generate(PCKIEBJEUY);
        try {
            CompressDecompressTester.of(RWLSBRRVDZ).withCompressDecompressPair(new org.apache.hadoop.io.compress.snappy.SnappyCompressor(PCKIEBJEUY + (PCKIEBJEUY / 2)), new org.apache.hadoop.io.compress.snappy.SnappyDecompressor(PCKIEBJEUY + (PCKIEBJEUY / 2))).withCompressDecompressPair(new org.apache.hadoop.io.compress.lz4.Lz4Compressor(PCKIEBJEUY), new org.apache.hadoop.io.compress.lz4.Lz4Decompressor(PCKIEBJEUY)).withTestCases(com.google.common.collect.ImmutableSet.of(CompressionTestStrategy.COMPRESS_DECOMPRESS_SINGLE_BLOCK, CompressionTestStrategy.COMPRESS_DECOMPRESS_BLOCK, CompressionTestStrategy.COMPRESS_DECOMPRESS_ERRORS, CompressionTestStrategy.COMPRESS_DECOMPRESS_WITH_EMPTY_STREAM)).test();
        } catch (Exception ex) {
            fail("testCompressorDecompressorWithExeedBufferLimit error !!!" + ex);
        }
    }

    public static byte[] generate(int SMONCSORSL) {
        byte[] CMSZKWFJRR = new byte[SMONCSORSL];
        for (int WZNWDCTQTN = 0; WZNWDCTQTN < SMONCSORSL; WZNWDCTQTN++)
            CMSZKWFJRR[WZNWDCTQTN] = ((byte) (TestCompressorDecompressor.JYNSCOXJLR.nextInt(16)));

        return CMSZKWFJRR;
    }
}