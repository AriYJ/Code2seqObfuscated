public class TestJobClient {
    static final String COFYFEOTAW = new File("target", TestJobClient.class.getSimpleName()).getAbsolutePath();

    @After
    public void tearDown() {
        FileUtil.fullyDelete(new File(TestJobClient.COFYFEOTAW));
    }

    @Test
    public void testGetClusterStatusWithLocalJobRunner() throws Exception {
        Configuration TCGSCSEWMJ = new Configuration();
        TCGSCSEWMJ.set(JT_IPC_ADDRESS, LOCAL_FRAMEWORK_NAME);
        TCGSCSEWMJ.set(FRAMEWORK_NAME, LOCAL_FRAMEWORK_NAME);
        JobClient VLZLDBYVCX = new JobClient(TCGSCSEWMJ);
        ClusterStatus XJMEZYALIL = VLZLDBYVCX.getClusterStatus(true);
        Collection<String> JGNERTDVKS = XJMEZYALIL.getActiveTrackerNames();
        Assert.assertEquals(0, JGNERTDVKS.size());
        int QSQMMVGONU = XJMEZYALIL.getBlacklistedTrackers();
        Assert.assertEquals(0, QSQMMVGONU);
        Collection<BlackListInfo> KWRYARHDRL = XJMEZYALIL.getBlackListedTrackersInfo();
        Assert.assertEquals(0, KWRYARHDRL.size());
    }

    @Test(timeout = 10000)
    public void testIsJobDirValid() throws IOException {
        Configuration NANPBBZFRI = new Configuration();
        FileSystem ZVGPNUKCVX = FileSystem.getLocal(NANPBBZFRI);
        Path AVTGSVQBWM = new Path(TestJobClient.COFYFEOTAW);
        ZVGPNUKCVX.mkdirs(AVTGSVQBWM);
        Assert.assertFalse(JobClient.isJobDirValid(AVTGSVQBWM, ZVGPNUKCVX));
        Path FLRPKSLRSJ = new Path(AVTGSVQBWM, "job.xml");
        Path DOXLARHTOX = new Path(AVTGSVQBWM, "job.split");
        ZVGPNUKCVX.create(FLRPKSLRSJ);
        ZVGPNUKCVX.create(DOXLARHTOX);
        Assert.assertTrue(JobClient.isJobDirValid(AVTGSVQBWM, ZVGPNUKCVX));
        ZVGPNUKCVX.delete(FLRPKSLRSJ, true);
        ZVGPNUKCVX.delete(DOXLARHTOX, true);
    }

    @Test(timeout = 10000)
    public void testGetStagingAreaDir() throws IOException, InterruptedException {
        Configuration EOYRUVELCS = new Configuration();
        JobClient WSCHMTITMG = new JobClient(EOYRUVELCS);
        Assert.assertTrue("Mismatch in paths", WSCHMTITMG.getClusterHandle().getStagingAreaDir().toString().equals(WSCHMTITMG.getStagingAreaDir().toString()));
    }
}