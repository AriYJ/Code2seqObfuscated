/**
 * This class is the home for file permissions related commands.
 * Moved to this separate class since FsShell is getting too large.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class FsShellPermissions extends FsCommand {
    static Log INXLZEBHNR = FsShell.LOG;

    /**
     * Register the permission related commands with the factory
     *
     * @param factory
     * 		the command factory
     */
    public static void registerCommands(CommandFactory OCTLUHYAVD) {
        OCTLUHYAVD.addClass(FsShellPermissions.Chmod.class, "-chmod");
        OCTLUHYAVD.addClass(FsShellPermissions.Chown.class, "-chown");
        OCTLUHYAVD.addClass(FsShellPermissions.Chgrp.class, "-chgrp");
    }

    /**
     * The pattern is almost as flexible as mode allowed by chmod shell command.
     * The main restriction is that we recognize only rwxXt. To reduce errors we
     * also enforce octal mode specifications of either 3 digits without a sticky
     * bit setting or four digits with a sticky bit setting.
     */
    public static class Chmod extends FsShellPermissions {
        public static final String YIKTGCFUGV = "chmod";

        public static final String QZJKSMQEIJ = "[-R] <MODE[,MODE]... | OCTALMODE> PATH...";

        public static final String NGRVXJQSLP = "Changes permissions of a file. " + (((((((((("This works similar to the shell\'s chmod command with a few exceptions.\n" + "-R: modifies the files recursively. This is the only option") + " currently supported.\n") + "<MODE>: Mode is the same as mode used for the shell's command. ") + "The only letters recognized are \'rwxXt\', e.g. +t,a+r,g-w,+rwx,o=r.\n") + "<OCTALMODE>: Mode specifed in 3 or 4 digits. If 4 digits, the first ") + "may be 1 or 0 to turn the sticky bit on or off, respectively.  Unlike ") + "the shell command, it is not possible to specify only part of the ") + "mode, e.g. 754 is same as u=rwx,g=rx,o=r.\n\n") + "If none of 'augo' is specified, 'a' is assumed and unlike the ") + "shell command, no umask is applied.");

        protected ChmodParser ZNOHCZRAGX;

        @Override
        protected void processOptions(LinkedList<String> args) throws IOException {
            CommandFormat cf = new CommandFormat(2, Integer.MAX_VALUE, "R", null);
            cf.parse(args);
            setRecursive(cf.getOpt("R"));
            String modeStr = args.removeFirst();
            try {
                ZNOHCZRAGX = new ChmodParser(modeStr);
            } catch (IllegalArgumentException iea) {
                // TODO: remove "chmod : " so it's not doubled up in output, but it's
                // here for backwards compatibility...
                throw new IllegalArgumentException(("chmod : mode '" + modeStr) + "' does not match the expected pattern.");
            }
        }

        @Override
        protected void processPath(PathData item) throws IOException {
            short newperms = ZNOHCZRAGX.applyNewPermission(item.stat);
            if (item.stat.getPermission().toShort() != newperms) {
                try {
                    item.fs.setPermission(item.path, new FsPermission(newperms));
                } catch (IOException e) {
                    FsShellPermissions.INXLZEBHNR.debug("Error changing permissions of " + item, e);
                    throw new IOException((("changing permissions of '" + item) + "': ") + e.getMessage());
                }
            }
        }
    }

    // used by chown/chgrp
    private static String XCQHYEDJDT = (Shell.WINDOWS) ? "[-_./@a-zA-Z0-9 ]" : "[-_./@a-zA-Z0-9]";

    /**
     * Used to change owner and/or group of files
     */
    public static class Chown extends FsShellPermissions {
        public static final String EINPTHBZXR = "chown";

        public static final String KKCGMHHGFC = "[-R] [OWNER][:[GROUP]] PATH...";

        public static final String IXNWCAKACA = (((((("Changes owner and group of a file. " + (((((("This is similar to the shell\'s chown command with a few exceptions.\n" + "-R: modifies the files recursively. This is the only option ") + "currently supported.\n\n") + "If only the owner or group is specified, then only the owner or ") + "group is modified. ") + "The owner and group names may only consist of digits, alphabet, ") + "and any of ")) + FsShellPermissions.XCQHYEDJDT) + ". The names are case sensitive.\n\n") + "WARNING: Avoid using '.' to separate user name and group though ") + "Linux allows it. If user names have dots in them and you are ") + "using local file system, you might see surprising results since ") + "the shell command 'chown' is used for local files.";

        // /allows only "allowedChars" above in names for owner and group
        private static final Pattern AVFAFLEARM = Pattern.compile(((("^\\s*(" + FsShellPermissions.XCQHYEDJDT) + "+)?([:](") + FsShellPermissions.XCQHYEDJDT) + "*))?\\s*$");

        protected String DUNRFKNRZA = null;

        protected String HAUBKIAEJX = null;

        @Override
        protected void processOptions(LinkedList<String> args) throws IOException {
            CommandFormat cf = new CommandFormat(2, Integer.MAX_VALUE, "R");
            cf.parse(args);
            setRecursive(cf.getOpt("R"));
            parseOwnerGroup(args.removeFirst());
        }

        /**
         * Parse the first argument into an owner and group
         *
         * @param ownerStr
         * 		string describing new ownership
         */
        protected void parseOwnerGroup(String ownerStr) {
            Matcher matcher = FsShellPermissions.Chown.AVFAFLEARM.matcher(ownerStr);
            if (!matcher.matches()) {
                throw new IllegalArgumentException(("'" + ownerStr) + "' does not match expected pattern for [owner][:group].");
            }
            DUNRFKNRZA = matcher.group(1);
            HAUBKIAEJX = matcher.group(3);
            if ((HAUBKIAEJX != null) && (HAUBKIAEJX.length() == 0)) {
                HAUBKIAEJX = null;
            }
            if ((DUNRFKNRZA == null) && (HAUBKIAEJX == null)) {
                throw new IllegalArgumentException(("'" + ownerStr) + "' does not specify owner or group.");
            }
        }

        @Override
        protected void processPath(PathData item) throws IOException {
            // Should we do case insensitive match?
            String newOwner = ((DUNRFKNRZA == null) || DUNRFKNRZA.equals(item.stat.getOwner())) ? null : DUNRFKNRZA;
            String newGroup = ((HAUBKIAEJX == null) || HAUBKIAEJX.equals(item.stat.getGroup())) ? null : HAUBKIAEJX;
            if ((newOwner != null) || (newGroup != null)) {
                try {
                    item.fs.setOwner(item.path, newOwner, newGroup);
                } catch (IOException e) {
                    FsShellPermissions.INXLZEBHNR.debug("Error changing ownership of " + item, e);
                    throw new IOException((("changing ownership of '" + item) + "': ") + e.getMessage());
                }
            }
        }
    }

    /**
     * Used to change group of files
     */
    public static class Chgrp extends FsShellPermissions.Chown {
        public static final String HVUINLWESL = "chgrp";

        public static final String NGUONFSAYU = "[-R] GROUP PATH...";

        public static final String JCMFUJSXCI = "This is equivalent to -chown ... :GROUP ...";

        private static final Pattern KFCMFSGAKI = Pattern.compile(("^\\s*(" + FsShellPermissions.XCQHYEDJDT) + "+)\\s*$");

        @Override
        protected void parseOwnerGroup(String groupStr) {
            Matcher matcher = FsShellPermissions.Chgrp.KFCMFSGAKI.matcher(groupStr);
            if (!matcher.matches()) {
                throw new IllegalArgumentException(("'" + groupStr) + "' does not match expected pattern for group");
            }
            DUNRFKNRZA = null;
            HAUBKIAEJX = matcher.group(1);
        }
    }
}