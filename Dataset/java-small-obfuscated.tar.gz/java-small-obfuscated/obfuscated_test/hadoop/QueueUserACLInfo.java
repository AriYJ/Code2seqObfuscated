/**
 * <p><code>QueueUserACLInfo</code> provides information {@link QueueACL} for
 * the given user.</p>
 *
 * @see QueueACL
 * @see ApplicationClientProtocol#getQueueUserAcls(org.apache.hadoop.yarn.api.protocolrecords.GetQueueUserAclsInfoRequest)
 */
@Public
@Stable
public abstract class QueueUserACLInfo {
    @Private
    @Unstable
    public static QueueUserACLInfo newInstance(String OPAFNFPYGU, List<QueueACL> BZLWMUQVIZ) {
        QueueUserACLInfo OQDYOCMBWR = Records.newRecord(QueueUserACLInfo.class);
        OQDYOCMBWR.setQueueName(OPAFNFPYGU);
        OQDYOCMBWR.setUserAcls(BZLWMUQVIZ);
        return OQDYOCMBWR;
    }

    /**
     * Get the <em>queue name</em> of the queue.
     *
     * @return <em>queue name</em> of the queue
     */
    @Public
    @Stable
    public abstract String getQueueName();

    @Private
    @Unstable
    public abstract void setQueueName(String BTPAKBCVVX);

    /**
     * Get the list of <code>QueueACL</code> for the given user.
     *
     * @return list of <code>QueueACL</code> for the given user
     */
    @Public
    @Stable
    public abstract List<QueueACL> getUserAcls();

    @Private
    @Unstable
    public abstract void setUserAcls(List<QueueACL> CJECIVGJFU);
}