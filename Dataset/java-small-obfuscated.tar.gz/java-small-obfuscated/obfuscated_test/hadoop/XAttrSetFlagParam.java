public class XAttrSetFlagParam extends EnumSetParam<XAttrSetFlag> {
    /**
     * Parameter name.
     */
    public static final String FAEIQXUNCD = "flag";

    /**
     * Default parameter value.
     */
    public static final String SLBMXCGTVT = "";

    private static final Domain<XAttrSetFlag> RWREIUCBCN = new Domain<XAttrSetFlag>(XAttrSetFlagParam.FAEIQXUNCD, XAttrSetFlag.class);

    public XAttrSetFlagParam(final EnumSet<XAttrSetFlag> TYPHTSDUPN) {
        super(XAttrSetFlagParam.RWREIUCBCN, TYPHTSDUPN);
    }

    /**
     * Constructor.
     *
     * @param str
     * 		a string representation of the parameter value.
     */
    public XAttrSetFlagParam(final String OBNOJMQUSA) {
        super(XAttrSetFlagParam.RWREIUCBCN, XAttrSetFlagParam.RWREIUCBCN.parse(OBNOJMQUSA));
    }

    @Override
    public String getName() {
        return XAttrSetFlagParam.FAEIQXUNCD;
    }

    public EnumSet<XAttrSetFlag> getFlag() {
        return getValue();
    }
}