public class TestJobSummary {
    private static final Log IBBXCJTDYA = LogFactory.getLog(TestJobSummary.class);

    private JobSummary RZRFRNEPRO = new JobSummary();

    @Before
    public void before() {
        JobId ARKYHQRVPH = mock(JobId.class);
        when(ARKYHQRVPH.toString()).thenReturn("testJobId");
        RZRFRNEPRO.setJobId(ARKYHQRVPH);
        RZRFRNEPRO.setJobSubmitTime(2);
        RZRFRNEPRO.setJobLaunchTime(3);
        RZRFRNEPRO.setFirstMapTaskLaunchTime(4);
        RZRFRNEPRO.setFirstReduceTaskLaunchTime(5);
        RZRFRNEPRO.setJobFinishTime(6);
        RZRFRNEPRO.setNumFinishedMaps(1);
        RZRFRNEPRO.setNumFailedMaps(0);
        RZRFRNEPRO.setNumFinishedReduces(1);
        RZRFRNEPRO.setNumFailedReduces(0);
        RZRFRNEPRO.setUser("testUser");
        RZRFRNEPRO.setQueue("testQueue");
        RZRFRNEPRO.setJobStatus("testJobStatus");
        RZRFRNEPRO.setMapSlotSeconds(7);
        RZRFRNEPRO.setReduceSlotSeconds(8);
        RZRFRNEPRO.setJobName("testName");
    }

    @Test
    public void testEscapeJobSummary() {
        // verify newlines are escaped
        RZRFRNEPRO.setJobName("aa\rbb\ncc\r\ndd");
        String VPMGNJXQHC = RZRFRNEPRO.getJobSummaryString();
        TestJobSummary.IBBXCJTDYA.info("summary: " + VPMGNJXQHC);
        Assert.assertFalse(VPMGNJXQHC.contains("\r"));
        Assert.assertFalse(VPMGNJXQHC.contains("\n"));
        Assert.assertTrue(VPMGNJXQHC.contains("aa\\rbb\\ncc\\r\\ndd"));
    }
}