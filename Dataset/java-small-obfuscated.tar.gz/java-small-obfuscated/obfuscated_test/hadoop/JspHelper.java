@InterfaceAudience.Private
public class JspHelper {
    public static final String AMHSNBBOBY = "current.conf";

    public static final String POOOYYKXOY = DelegationParam.NAME;

    public static final String AMERWKDLIT = "nnaddr";

    private static final Log SKRKCHYSGS = LogFactory.getLog(JspHelper.class);

    /**
     * Private constructor for preventing creating JspHelper object.
     */
    private JspHelper() {
    }

    private static String getDefaultWebUserName(Configuration OQHDZBIUVU) throws IOException {
        String SINAHOALKI = OQHDZBIUVU.get(HADOOP_HTTP_STATIC_USER, DEFAULT_HADOOP_HTTP_STATIC_USER);
        if ((SINAHOALKI == null) || (SINAHOALKI.length() == 0)) {
            throw new IOException("Cannot determine UGI from request or conf");
        }
        return SINAHOALKI;
    }

    private static InetSocketAddress getNNServiceAddress(ServletContext TQPSILKUAT, HttpServletRequest HCIIHGAGEE) {
        String ZTTPWSWBEV = HCIIHGAGEE.getParameter(JspHelper.AMERWKDLIT);
        InetSocketAddress YOYAFYBSHY = null;
        if (ZTTPWSWBEV != null) {
            YOYAFYBSHY = NetUtils.createSocketAddr(ZTTPWSWBEV);
        } else
            if (TQPSILKUAT != null) {
                YOYAFYBSHY = NameNodeHttpServer.getNameNodeAddressFromContext(TQPSILKUAT);
            }

        if (YOYAFYBSHY != null) {
            return YOYAFYBSHY;
        }
        return null;
    }

    /**
     * Same as getUGI(null, request, conf).
     */
    public static UserGroupInformation getUGI(HttpServletRequest JQZCELVFAQ, Configuration XCJUPEAGIP) throws IOException {
        return JspHelper.getUGI(null, JQZCELVFAQ, XCJUPEAGIP);
    }

    /**
     * Same as getUGI(context, request, conf, KERBEROS_SSL, true).
     */
    public static UserGroupInformation getUGI(ServletContext ZVIMVKTFNG, HttpServletRequest HILCCHTHUY, Configuration EOJAHMYIZV) throws IOException {
        return JspHelper.getUGI(ZVIMVKTFNG, HILCCHTHUY, EOJAHMYIZV, KERBEROS_SSL, true);
    }

    /**
     * Get {@link UserGroupInformation} and possibly the delegation token out of
     * the request.
     *
     * @param context
     * 		the ServletContext that is serving this request.
     * @param request
     * 		the http request
     * @param conf
     * 		configuration
     * @param secureAuthMethod
     * 		the AuthenticationMethod used in secure mode.
     * @param tryUgiParameter
     * 		Should it try the ugi parameter?
     * @return a new user from the request
     * @throws AccessControlException
     * 		if the request has no token
     */
    public static UserGroupInformation getUGI(ServletContext FNLAQSNQOC, HttpServletRequest CLNUOHBFZR, Configuration GFQUYQFXIE, final AuthenticationMethod EEPLBMTLEJ, final boolean XLJBAFLICR) throws IOException {
        UserGroupInformation WTHTSJOVDA = null;
        final String BNOMVTIQSD = JspHelper.getUsernameFromQuery(CLNUOHBFZR, XLJBAFLICR);
        final String HTGYYMYZBS = CLNUOHBFZR.getParameter(NAME);
        final String BUXZNWZFKZ;
        if (UserGroupInformation.isSecurityEnabled()) {
            BUXZNWZFKZ = CLNUOHBFZR.getRemoteUser();
            final String YECKXGKLXL = CLNUOHBFZR.getParameter(JspHelper.POOOYYKXOY);
            if (YECKXGKLXL != null) {
                // Token-based connections need only verify the effective user, and
                // disallow proxying to different user.  Proxy authorization checks
                // are not required since the checks apply to issuing a token.
                WTHTSJOVDA = JspHelper.getTokenUGI(FNLAQSNQOC, CLNUOHBFZR, YECKXGKLXL, GFQUYQFXIE);
                JspHelper.checkUsername(WTHTSJOVDA.getShortUserName(), BNOMVTIQSD);
                JspHelper.checkUsername(WTHTSJOVDA.getShortUserName(), HTGYYMYZBS);
            } else
                if (BUXZNWZFKZ == null) {
                    throw new IOException("Security enabled but user not authenticated by filter");
                }

        } else {
            // Security's not on, pull from url or use default web user
            BUXZNWZFKZ = (BNOMVTIQSD == null) ? JspHelper.getDefaultWebUserName(GFQUYQFXIE)// not specified in request
             : BNOMVTIQSD;
        }
        if (WTHTSJOVDA == null) {
            // security is off, or there's no token
            WTHTSJOVDA = UserGroupInformation.createRemoteUser(BUXZNWZFKZ);
            JspHelper.checkUsername(WTHTSJOVDA.getShortUserName(), BNOMVTIQSD);
            if (UserGroupInformation.isSecurityEnabled()) {
                // This is not necessarily true, could have been auth'ed by user-facing
                // filter
                WTHTSJOVDA.setAuthenticationMethod(EEPLBMTLEJ);
            }
            if (HTGYYMYZBS != null) {
                // create and attempt to authorize a proxy user
                WTHTSJOVDA = UserGroupInformation.createProxyUser(HTGYYMYZBS, WTHTSJOVDA);
                ProxyUsers.authorize(WTHTSJOVDA, JspHelper.getRemoteAddr(CLNUOHBFZR));
            }
        }
        if (JspHelper.SKRKCHYSGS.isDebugEnabled())
            JspHelper.SKRKCHYSGS.debug("getUGI is returning: " + WTHTSJOVDA.getShortUserName());

        return WTHTSJOVDA;
    }

    private static UserGroupInformation getTokenUGI(ServletContext CSVIAYPRAY, HttpServletRequest XETAUVHCJA, String SGFRURDNUW, Configuration YOBGUPRPOG) throws IOException {
        final Token<DelegationTokenIdentifier> CFNTGWIXQS = new Token<DelegationTokenIdentifier>();
        CFNTGWIXQS.decodeFromUrlString(SGFRURDNUW);
        InetSocketAddress XCUYCWKTGV = JspHelper.getNNServiceAddress(CSVIAYPRAY, XETAUVHCJA);
        if (XCUYCWKTGV != null) {
            SecurityUtil.setTokenService(CFNTGWIXQS, XCUYCWKTGV);
            CFNTGWIXQS.setKind(HDFS_DELEGATION_KIND);
        }
        ByteArrayInputStream CRODKNIAND = new ByteArrayInputStream(CFNTGWIXQS.getIdentifier());
        DataInputStream GXYCRVRWKQ = new DataInputStream(CRODKNIAND);
        DelegationTokenIdentifier BFLSPSDAPB = new DelegationTokenIdentifier();
        BFLSPSDAPB.readFields(GXYCRVRWKQ);
        if (CSVIAYPRAY != null) {
            final NameNode LYTKDYVZHN = NameNodeHttpServer.getNameNodeFromContext(CSVIAYPRAY);
            if (LYTKDYVZHN != null) {
                // Verify the token.
                LYTKDYVZHN.getNamesystem().verifyToken(BFLSPSDAPB, CFNTGWIXQS.getPassword());
            }
        }
        UserGroupInformation KQQCSOUYNP = BFLSPSDAPB.getUser();
        KQQCSOUYNP.addToken(CFNTGWIXQS);
        return KQQCSOUYNP;
    }

    // honor the X-Forwarded-For header set by a configured set of trusted
    // proxy servers.  allows audit logging and proxy user checks to work
    // via an http proxy
    public static String getRemoteAddr(HttpServletRequest ZOLKAKIBJD) {
        String KCVVGOIZDH = ZOLKAKIBJD.getRemoteAddr();
        String EUNHWVRQUQ = ZOLKAKIBJD.getHeader("X-Forwarded-For");
        if ((EUNHWVRQUQ != null) && ProxyServers.isProxyServer(KCVVGOIZDH)) {
            final String ZLSVLIBYCU = EUNHWVRQUQ.split(",")[0].trim();
            if (!ZLSVLIBYCU.isEmpty()) {
                KCVVGOIZDH = ZLSVLIBYCU;
            }
        }
        return KCVVGOIZDH;
    }

    /**
     * Expected user name should be a short name.
     */
    private static void checkUsername(final String ZHSXFXECEB, final String TANUZIDPOG) throws IOException {
        if ((ZHSXFXECEB == null) && (TANUZIDPOG != null)) {
            throw new IOException("Usernames not matched: expecting null but name=" + TANUZIDPOG);
        }
        if (TANUZIDPOG == null) {
            // name is optional, null is okay
            return;
        }
        KerberosName KGBBOBODFN = new KerberosName(TANUZIDPOG);
        String ZLGCUSDPVP = KGBBOBODFN.getShortName();
        if (!ZLGCUSDPVP.equals(ZHSXFXECEB)) {
            throw new IOException((("Usernames not matched: name=" + ZLGCUSDPVP) + " != expected=") + ZHSXFXECEB);
        }
    }

    private static String getUsernameFromQuery(final HttpServletRequest IQJEVKSLJZ, final boolean NKKILDWVTN) {
        String RSLPKQZOIX = IQJEVKSLJZ.getParameter(UserParam.NAME);
        if ((RSLPKQZOIX == null) && NKKILDWVTN) {
            // try ugi parameter
            final String MCBYXXEDGD = IQJEVKSLJZ.getParameter("ugi");
            if (MCBYXXEDGD != null) {
                RSLPKQZOIX = MCBYXXEDGD.split(",")[0];
            }
        }
        return RSLPKQZOIX;
    }
}