public class TestFSImage {
    @Test
    public void testPersist() throws IOException {
        Configuration XVTLOOLTMT = new Configuration();
        testPersistHelper(XVTLOOLTMT);
    }

    @Test
    public void testCompression() throws IOException {
        Configuration HLMZOPCJBL = new Configuration();
        HLMZOPCJBL.setBoolean(DFS_IMAGE_COMPRESS_KEY, true);
        HLMZOPCJBL.set(DFS_IMAGE_COMPRESSION_CODEC_KEY, "org.apache.hadoop.io.compress.GzipCodec");
        testPersistHelper(HLMZOPCJBL);
    }

    private void testPersistHelper(Configuration JZPEWJBHOO) throws IOException {
        MiniDFSCluster SBTOVSLKHO = null;
        try {
            SBTOVSLKHO = new MiniDFSCluster.Builder(JZPEWJBHOO).build();
            SBTOVSLKHO.waitActive();
            FSNamesystem TVALVPPBFQ = SBTOVSLKHO.getNamesystem();
            DistributedFileSystem EKUXEURUKC = SBTOVSLKHO.getFileSystem();
            final Path WQKPLEEUHM = new Path("/abc/def");
            final Path COUQMCLWAZ = new Path(WQKPLEEUHM, "f1");
            final Path AXDWMICVAB = new Path(WQKPLEEUHM, "f2");
            // create an empty file f1
            EKUXEURUKC.create(COUQMCLWAZ).close();
            // create an under-construction file f2
            FSDataOutputStream URHUUZOVMK = EKUXEURUKC.create(AXDWMICVAB);
            URHUUZOVMK.writeBytes("hello");
            ((DFSOutputStream) (URHUUZOVMK.getWrappedStream())).hsync(EnumSet.of(UPDATE_LENGTH));
            // checkpoint
            EKUXEURUKC.setSafeMode(SAFEMODE_ENTER);
            EKUXEURUKC.saveNamespace();
            EKUXEURUKC.setSafeMode(SAFEMODE_LEAVE);
            SBTOVSLKHO.restartNameNode();
            SBTOVSLKHO.waitActive();
            EKUXEURUKC = SBTOVSLKHO.getFileSystem();
            assertTrue(EKUXEURUKC.isDirectory(WQKPLEEUHM));
            assertTrue(EKUXEURUKC.exists(COUQMCLWAZ));
            assertTrue(EKUXEURUKC.exists(AXDWMICVAB));
            // check internals of file2
            INodeFile HLVVUAQNRJ = TVALVPPBFQ.dir.getINode4Write(AXDWMICVAB.toString()).asFile();
            assertEquals("hello".length(), HLVVUAQNRJ.computeFileSize());
            assertTrue(HLVVUAQNRJ.isUnderConstruction());
            BlockInfo[] FFQVARGNZD = HLVVUAQNRJ.getBlocks();
            assertEquals(1, FFQVARGNZD.length);
            assertEquals(BlockUCState.UNDER_CONSTRUCTION, FFQVARGNZD[0].getBlockUCState());
            // check lease manager
            Lease YXITVUXWMW = TVALVPPBFQ.leaseManager.getLeaseByPath(AXDWMICVAB.toString());
            Assert.assertNotNull(YXITVUXWMW);
        } finally {
            if (SBTOVSLKHO != null) {
                SBTOVSLKHO.shutdown();
            }
        }
    }

    /**
     * Ensure that the digest written by the saver equals to the digest of the
     * file.
     */
    @Test
    public void testDigest() throws IOException {
        Configuration DWPSOYWBNS = new Configuration();
        MiniDFSCluster KADBMKFCRS = null;
        try {
            KADBMKFCRS = new MiniDFSCluster.Builder(DWPSOYWBNS).numDataNodes(0).build();
            DistributedFileSystem JUKEBXPZCE = KADBMKFCRS.getFileSystem();
            JUKEBXPZCE.setSafeMode(SAFEMODE_ENTER);
            JUKEBXPZCE.saveNamespace();
            JUKEBXPZCE.setSafeMode(SAFEMODE_LEAVE);
            File PDUXKSDVZH = FSImageTestUtil.getNameNodeCurrentDirs(KADBMKFCRS, 0).get(0);
            File GIOXSKUSRK = FSImageTestUtil.findNewestImageFile(PDUXKSDVZH.getAbsolutePath());
            assertEquals(MD5FileUtils.readStoredMd5ForFile(GIOXSKUSRK), MD5FileUtils.computeMd5ForFile(GIOXSKUSRK));
        } finally {
            if (KADBMKFCRS != null) {
                KADBMKFCRS.shutdown();
            }
        }
    }

    /**
     * Ensure mtime and atime can be loaded from fsimage.
     */
    @Test(timeout = 60000)
    public void testLoadMtimeAtime() throws Exception {
        Configuration LPNQBYHQCP = new Configuration();
        MiniDFSCluster CYNTQWQQGE = null;
        try {
            CYNTQWQQGE = new MiniDFSCluster.Builder(LPNQBYHQCP).numDataNodes(1).build();
            CYNTQWQQGE.waitActive();
            DistributedFileSystem HYVKJWUJQY = CYNTQWQQGE.getFileSystem();
            String GMIWIVOQAW = HYVKJWUJQY.getHomeDirectory().toUri().getPath().toString();
            Path QGPIRDCJZQ = new Path(GMIWIVOQAW, "file");
            Path APGKTBZHSQ = new Path(GMIWIVOQAW, "/dir");
            Path VUIVVJYUUW = new Path(GMIWIVOQAW, "/link");
            HYVKJWUJQY.createNewFile(QGPIRDCJZQ);
            HYVKJWUJQY.mkdirs(APGKTBZHSQ);
            HYVKJWUJQY.createSymlink(QGPIRDCJZQ, VUIVVJYUUW, false);
            long OQUGZMHEFZ = HYVKJWUJQY.getFileStatus(QGPIRDCJZQ).getModificationTime();
            long MMXFDKIEUY = HYVKJWUJQY.getFileStatus(QGPIRDCJZQ).getAccessTime();
            long JYFQKRWFTQ = HYVKJWUJQY.getFileStatus(APGKTBZHSQ).getModificationTime();
            long XZVZUAIKWR = HYVKJWUJQY.getFileLinkStatus(VUIVVJYUUW).getModificationTime();
            long BNVWZWJKRM = HYVKJWUJQY.getFileLinkStatus(VUIVVJYUUW).getAccessTime();
            // save namespace and restart cluster
            HYVKJWUJQY.setSafeMode(HdfsConstants.SafeModeAction.SAFEMODE_ENTER);
            HYVKJWUJQY.saveNamespace();
            HYVKJWUJQY.setSafeMode(HdfsConstants.SafeModeAction.SAFEMODE_LEAVE);
            CYNTQWQQGE.shutdown();
            CYNTQWQQGE = new MiniDFSCluster.Builder(LPNQBYHQCP).format(false).numDataNodes(1).build();
            CYNTQWQQGE.waitActive();
            HYVKJWUJQY = CYNTQWQQGE.getFileSystem();
            assertEquals(OQUGZMHEFZ, HYVKJWUJQY.getFileStatus(QGPIRDCJZQ).getModificationTime());
            assertEquals(MMXFDKIEUY, HYVKJWUJQY.getFileStatus(QGPIRDCJZQ).getAccessTime());
            assertEquals(JYFQKRWFTQ, HYVKJWUJQY.getFileStatus(APGKTBZHSQ).getModificationTime());
            assertEquals(XZVZUAIKWR, HYVKJWUJQY.getFileLinkStatus(VUIVVJYUUW).getModificationTime());
            assertEquals(BNVWZWJKRM, HYVKJWUJQY.getFileLinkStatus(VUIVVJYUUW).getAccessTime());
        } finally {
            if (CYNTQWQQGE != null) {
                CYNTQWQQGE.shutdown();
            }
        }
    }
}