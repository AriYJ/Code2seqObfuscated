/**
 * This test case tests the symlink creation
 * utility provided by distributed caching
 */
public class TestSymLink {
    String IBWAHWPAZI = "/testing-streaming/input.txt";

    String ZDQDZDECVE = "/testing-streaming/out";

    String MVNLFBRBUS = "/testing-streaming/cache.txt";

    String RPKMVNNCTW = "check to see if we can read this none reduce";

    String WATEBOBMAD = TestStreaming.XARGS_CAT;

    String WCENUCZBCS = TestStreaming.CAT;

    String IZMTMAQEUE = "testlink\n";

    String UFXPWYGNLV = "This is just the cache string";

    StreamJob VMYBAQTXGR;

    @Test(timeout = 120000)
    public void testSymLink() throws Exception {
        boolean TGHGGPWLLY = false;
        MiniMRCluster FVUBIENTAP = null;
        MiniDFSCluster TSPAZUDULD = null;
        try {
            Configuration CHUVNVJKVB = new Configuration();
            TSPAZUDULD = new MiniDFSCluster.Builder(CHUVNVJKVB).build();
            FileSystem WDWMTBZMEI = TSPAZUDULD.getFileSystem();
            String MBVCWBJQAO = WDWMTBZMEI.getUri().toString();
            FVUBIENTAP = new MiniMRCluster(1, MBVCWBJQAO, 3);
            List<String> CEMAIKDHUP = new ArrayList<String>();
            for (Map.Entry<String, String> ORJPMMTDQQ : FVUBIENTAP.createJobConf()) {
                CEMAIKDHUP.add("-jobconf");
                CEMAIKDHUP.add((ORJPMMTDQQ.getKey() + "=") + ORJPMMTDQQ.getValue());
            }
            // During tests, the default Configuration will use a local mapred
            // So don't specify -config or -cluster
            String[] NAZTIEEBQK = new String[]{ "-input", IBWAHWPAZI, "-output", ZDQDZDECVE, "-mapper", WATEBOBMAD, "-reducer", WCENUCZBCS, "-jobconf", "stream.tmpdir=" + System.getProperty("test.build.data", "/tmp"), "-jobconf", (((((((JobConf.MAPRED_MAP_TASK_JAVA_OPTS + "=") + "-Dcontrib.name=") + System.getProperty("contrib.name")) + " ") + "-Dbuild.test=") + System.getProperty("build.test")) + " ") + CHUVNVJKVB.get(MAPRED_MAP_TASK_JAVA_OPTS, CHUVNVJKVB.get(MAPRED_TASK_JAVA_OPTS, "")), "-jobconf", (((((((JobConf.MAPRED_REDUCE_TASK_JAVA_OPTS + "=") + "-Dcontrib.name=") + System.getProperty("contrib.name")) + " ") + "-Dbuild.test=") + System.getProperty("build.test")) + " ") + CHUVNVJKVB.get(MAPRED_REDUCE_TASK_JAVA_OPTS, CHUVNVJKVB.get(MAPRED_TASK_JAVA_OPTS, "")), "-cacheFile", (WDWMTBZMEI.getUri() + MVNLFBRBUS) + "#testlink", "-jobconf", "mapred.jar=" + TestStreaming.STREAMING_JAR };
            for (String VMVMCYHIFP : NAZTIEEBQK) {
                CEMAIKDHUP.add(VMVMCYHIFP);
            }
            NAZTIEEBQK = CEMAIKDHUP.toArray(new String[CEMAIKDHUP.size()]);
            WDWMTBZMEI.delete(new Path(ZDQDZDECVE), true);
            DataOutputStream QCXSEDXDNZ = WDWMTBZMEI.create(new Path(IBWAHWPAZI));
            QCXSEDXDNZ.writeBytes(IZMTMAQEUE);
            QCXSEDXDNZ.close();
            QCXSEDXDNZ = WDWMTBZMEI.create(new Path(MVNLFBRBUS));
            QCXSEDXDNZ.writeBytes(UFXPWYGNLV);
            QCXSEDXDNZ.close();
            VMYBAQTXGR = new StreamJob(NAZTIEEBQK, TGHGGPWLLY);
            VMYBAQTXGR.go();
            WDWMTBZMEI = TSPAZUDULD.getFileSystem();
            String QRAUIPEAYA = null;
            Path[] WMMCWEKALT = FileUtil.stat2Paths(WDWMTBZMEI.listStatus(new Path(ZDQDZDECVE), new Utils.OutputFileUtils.OutputFilesFilter()));
            for (int FWNNGOZYCF = 0; FWNNGOZYCF < WMMCWEKALT.length; FWNNGOZYCF++) {
                System.out.println(WMMCWEKALT[FWNNGOZYCF].toString());
                BufferedReader GJJTOPSPOY = new BufferedReader(new InputStreamReader(WDWMTBZMEI.open(WMMCWEKALT[FWNNGOZYCF])));
                QRAUIPEAYA = GJJTOPSPOY.readLine();
                System.out.println(QRAUIPEAYA);
            }
            assertEquals(UFXPWYGNLV + "\t", QRAUIPEAYA);
        } finally {
            if (TSPAZUDULD != null) {
                TSPAZUDULD.shutdown();
            }
            if (FVUBIENTAP != null) {
                FVUBIENTAP.shutdown();
            }
        }
    }

    public static void main(String[] DRINQTBXYB) throws Exception {
        new TestStreaming().testCommandLine();
    }
}