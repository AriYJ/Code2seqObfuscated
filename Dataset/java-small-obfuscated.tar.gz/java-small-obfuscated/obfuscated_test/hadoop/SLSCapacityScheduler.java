@Private
@Unstable
public class SLSCapacityScheduler extends CapacityScheduler implements Configurable , SchedulerWrapper {
    private static final String DNFQZGUEXM = System.getProperty("line.separator");

    private static final int NWNCDCWMYX = 60;

    private ScheduledExecutorService SSFZCHGYPJ;

    // counters for scheduler allocate/handle operations
    private Counter SQQXJLKTBG;

    private Counter ABLOIDOCMG;

    private Map<SchedulerEventType, Counter> AXVPNMVVDI;

    // Timers for scheduler allocate/handle operations
    private Timer KYVZAGXYMH;

    private Timer FFDJHPCOLR;

    private Map<SchedulerEventType, Timer> TBCJBMFTDS;

    private List<Histogram> XMURHOEUEY;

    private Map<Histogram, Timer> SJVLHUGBZC;

    private Lock TBYTAPDBAU;

    private Lock DVTBWQCMBQ;

    private Configuration DGPJKXBAQW;

    private Map<ApplicationAttemptId, String> IGWAHNOOCI = new ConcurrentHashMap<ApplicationAttemptId, String>();

    private BufferedWriter SGAEZMGPJB;

    // Priority of the ResourceSchedulerWrapper shutdown hook.
    public static final int SWIDANHNSG = 30;

    // web app
    private SLSWebApp KEBEIPGBER;

    private Map<ContainerId, Resource> PNNZZJFZPX = new ConcurrentHashMap<ContainerId, Resource>();

    // metrics
    private MetricRegistry ZZYEOJUKUV;

    private SchedulerMetrics RIAWKTOJNB;

    private boolean JQRZYRNGPE;

    private String LKADITZRAJ;

    private BufferedWriter JKRVANPEIQ;

    private boolean AOIUCPDLQM = false;

    private static Map<Class, Class> MFAOQHNBVN = new HashMap<Class, Class>();

    static {
        SLSCapacityScheduler.MFAOQHNBVN.put(FairScheduler.class, FairSchedulerMetrics.class);
        SLSCapacityScheduler.MFAOQHNBVN.put(FifoScheduler.class, FifoSchedulerMetrics.class);
        SLSCapacityScheduler.MFAOQHNBVN.put(CapacityScheduler.class, CapacitySchedulerMetrics.class);
    }

    // must set by outside
    private Set<String> BBSZFEXKFR;

    private Set<String> UWKONSDXYJ;

    public final Logger KMYWHLKZVJ = Logger.getLogger(SLSCapacityScheduler.class);

    public SLSCapacityScheduler() {
        TBYTAPDBAU = new ReentrantLock();
        DVTBWQCMBQ = new ReentrantLock();
    }

    @Override
    public void setConf(Configuration KKWRGOJBLS) {
        this.DGPJKXBAQW = KKWRGOJBLS;
        super.setConf(KKWRGOJBLS);
        // start metrics
        JQRZYRNGPE = KKWRGOJBLS.getBoolean(METRICS_SWITCH, true);
        if (JQRZYRNGPE) {
            try {
                initMetrics();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        org.apache.hadoop.util.ShutdownHookManager.get().addShutdownHook(new Runnable() {
            @Override
            public void run() {
                try {
                    if (JKRVANPEIQ != null) {
                        JKRVANPEIQ.write("]");
                        JKRVANPEIQ.close();
                    }
                    if (KEBEIPGBER != null) {
                        KEBEIPGBER.stop();
                    }
                    tearDown();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, SLSCapacityScheduler.SWIDANHNSG);
    }

    @Override
    public Allocation allocate(ApplicationAttemptId HIQYTOXAJA, List<ResourceRequest> ASIVBLIUNU, List<ContainerId> WEEHKRCBGU, List<String> QOONHQYIAW, List<String> ZMCCNRZPDV) {
        if (JQRZYRNGPE) {
            final Timer.Context NPCJSBSFVL = KYVZAGXYMH.time();
            Allocation MUFNIFKEKQ = null;
            try {
                MUFNIFKEKQ = super.allocate(HIQYTOXAJA, ASIVBLIUNU, WEEHKRCBGU, QOONHQYIAW, ZMCCNRZPDV);
                return MUFNIFKEKQ;
            } finally {
                NPCJSBSFVL.stop();
                SQQXJLKTBG.inc();
                try {
                    updateQueueWithAllocateRequest(MUFNIFKEKQ, HIQYTOXAJA, ASIVBLIUNU, WEEHKRCBGU);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            return super.allocate(HIQYTOXAJA, ASIVBLIUNU, WEEHKRCBGU, QOONHQYIAW, ZMCCNRZPDV);
        }
    }

    @Override
    public void handle(SchedulerEvent JHMCDVWJXQ) {
        // metrics off
        if (!JQRZYRNGPE) {
            super.handle(JHMCDVWJXQ);
            return;
        }
        if (!AOIUCPDLQM)
            AOIUCPDLQM = true;

        // metrics on
        Timer.Context TXGRVUTEZF = null;
        Timer.Context XXTSMPQIRN = null;
        NodeUpdateSchedulerEventWrapper JADGWXRSXQ;
        try {
            // if (schedulerEvent instanceof NodeUpdateSchedulerEvent) {
            if ((JHMCDVWJXQ.getType() == SchedulerEventType.NODE_UPDATE) && (JHMCDVWJXQ instanceof NodeUpdateSchedulerEvent)) {
                JADGWXRSXQ = new NodeUpdateSchedulerEventWrapper(((NodeUpdateSchedulerEvent) (JHMCDVWJXQ)));
                JHMCDVWJXQ = JADGWXRSXQ;
                updateQueueWithNodeUpdate(JADGWXRSXQ);
            } else
                if ((JHMCDVWJXQ.getType() == SchedulerEventType.APP_ATTEMPT_REMOVED) && (JHMCDVWJXQ instanceof AppAttemptRemovedSchedulerEvent)) {
                    // check if having AM Container, update resource usage information
                    AppAttemptRemovedSchedulerEvent EBEYHURDLH = ((AppAttemptRemovedSchedulerEvent) (JHMCDVWJXQ));
                    ApplicationAttemptId JPCXWFVNZB = EBEYHURDLH.getApplicationAttemptID();
                    String LJSEHBDETJ = IGWAHNOOCI.get(JPCXWFVNZB);
                    SchedulerAppReport HVWVXFCJXG = super.getSchedulerAppInfo(JPCXWFVNZB);
                    if (!HVWVXFCJXG.getLiveContainers().isEmpty()) {
                        // have 0 or 1
                        // should have one container which is AM container
                        RMContainer DGMUJHAFNO = HVWVXFCJXG.getLiveContainers().iterator().next();
                        updateQueueMetrics(LJSEHBDETJ, DGMUJHAFNO.getContainer().getResource().getMemory(), DGMUJHAFNO.getContainer().getResource().getVirtualCores());
                    }
                }

            TXGRVUTEZF = FFDJHPCOLR.time();
            XXTSMPQIRN = TBCJBMFTDS.get(JHMCDVWJXQ.getType()).time();
            super.handle(JHMCDVWJXQ);
        } finally {
            if (TXGRVUTEZF != null)
                TXGRVUTEZF.stop();

            if (XXTSMPQIRN != null)
                XXTSMPQIRN.stop();

            ABLOIDOCMG.inc();
            AXVPNMVVDI.get(JHMCDVWJXQ.getType()).inc();
            if ((JHMCDVWJXQ.getType() == SchedulerEventType.APP_ATTEMPT_REMOVED) && (JHMCDVWJXQ instanceof AppAttemptRemovedSchedulerEvent)) {
                SLSRunner.decreaseRemainingApps();
                AppAttemptRemovedSchedulerEvent RCLNJVRDHZ = ((AppAttemptRemovedSchedulerEvent) (JHMCDVWJXQ));
                ApplicationAttemptId WELRKFCHQK = RCLNJVRDHZ.getApplicationAttemptID();
                IGWAHNOOCI.remove(RCLNJVRDHZ.getApplicationAttemptID());
            } else
                if ((JHMCDVWJXQ.getType() == SchedulerEventType.APP_ATTEMPT_ADDED) && (JHMCDVWJXQ instanceof AppAttemptAddedSchedulerEvent)) {
                    AppAttemptAddedSchedulerEvent LABTYLXHVB = ((AppAttemptAddedSchedulerEvent) (JHMCDVWJXQ));
                    SchedulerApplication QPYVFTSIIB = applications.get(LABTYLXHVB.getApplicationAttemptId().getApplicationId());
                    IGWAHNOOCI.put(LABTYLXHVB.getApplicationAttemptId(), QPYVFTSIIB.getQueue().getQueueName());
                }

        }
    }

    private void updateQueueWithNodeUpdate(NodeUpdateSchedulerEventWrapper OOPPGKKQIK) {
        RMNodeWrapper LBXJRFKRFZ = ((RMNodeWrapper) (OOPPGKKQIK.getRMNode()));
        List<UpdatedContainerInfo> JPXNTTLONM = LBXJRFKRFZ.getContainerUpdates();
        for (UpdatedContainerInfo NCFMHXXIEW : JPXNTTLONM) {
            for (ContainerStatus WODBCWPZYM : NCFMHXXIEW.getCompletedContainers()) {
                ContainerId PHWJQXUUEZ = WODBCWPZYM.getContainerId();
                SchedulerAppReport FLKUYCWRPJ = super.getSchedulerAppInfo(PHWJQXUUEZ.getApplicationAttemptId());
                if (FLKUYCWRPJ == null) {
                    // this happens for the AM container
                    // The app have already removed when the NM sends the release
                    // information.
                    continue;
                }
                String AFMRXKLTQK = IGWAHNOOCI.get(PHWJQXUUEZ.getApplicationAttemptId());
                int MVJIRQWLDA = 0;
                int QKVBRVUJPV = 0;
                if (WODBCWPZYM.getExitStatus() == ContainerExitStatus.SUCCESS) {
                    for (RMContainer RHXABXHQAO : FLKUYCWRPJ.getLiveContainers()) {
                        if (RHXABXHQAO.getContainerId() == PHWJQXUUEZ) {
                            MVJIRQWLDA += RHXABXHQAO.getContainer().getResource().getMemory();
                            QKVBRVUJPV += RHXABXHQAO.getContainer().getResource().getVirtualCores();
                            break;
                        }
                    }
                } else
                    if (WODBCWPZYM.getExitStatus() == ContainerExitStatus.ABORTED) {
                        if (PNNZZJFZPX.containsKey(PHWJQXUUEZ)) {
                            Resource NQERGTICNB = PNNZZJFZPX.get(PHWJQXUUEZ);
                            MVJIRQWLDA += NQERGTICNB.getMemory();
                            QKVBRVUJPV += NQERGTICNB.getVirtualCores();
                            PNNZZJFZPX.remove(PHWJQXUUEZ);
                        }
                    }

                // update queue counters
                updateQueueMetrics(AFMRXKLTQK, MVJIRQWLDA, QKVBRVUJPV);
            }
        }
    }

    private void updateQueueWithAllocateRequest(Allocation IURYODDCYH, ApplicationAttemptId ZDCTSSESOD, List<ResourceRequest> DHFEIDUPAP, List<ContainerId> VBUUNUGUOJ) throws IOException {
        // update queue information
        Resource VMZMEXSJHQ = Resources.createResource(0, 0);
        Resource GPBZEUTCKK = Resources.createResource(0, 0);
        String TKJBBIJKLT = IGWAHNOOCI.get(ZDCTSSESOD);
        // container requested
        for (ResourceRequest LPRQYRNFVQ : DHFEIDUPAP) {
            if (LPRQYRNFVQ.getResourceName().equals(ANY)) {
                Resources.addTo(VMZMEXSJHQ, Resources.multiply(LPRQYRNFVQ.getCapability(), LPRQYRNFVQ.getNumContainers()));
            }
        }
        // container allocated
        for (Container CVAVGUZTBD : IURYODDCYH.getContainers()) {
            Resources.addTo(GPBZEUTCKK, CVAVGUZTBD.getResource());
            Resources.subtractFrom(VMZMEXSJHQ, CVAVGUZTBD.getResource());
        }
        // container released from AM
        SchedulerAppReport QZYYGTBCGV = super.getSchedulerAppInfo(ZDCTSSESOD);
        for (ContainerId UMFGKMADSU : VBUUNUGUOJ) {
            Container ROOVUPJBIR = null;
            for (RMContainer LOATWSOMES : QZYYGTBCGV.getLiveContainers()) {
                if (LOATWSOMES.getContainerId().equals(UMFGKMADSU)) {
                    ROOVUPJBIR = LOATWSOMES.getContainer();
                    break;
                }
            }
            if (ROOVUPJBIR != null) {
                // released allocated containers
                Resources.subtractFrom(GPBZEUTCKK, ROOVUPJBIR.getResource());
            } else {
                for (RMContainer DLQEQMHRSL : QZYYGTBCGV.getReservedContainers()) {
                    if (DLQEQMHRSL.getContainerId().equals(UMFGKMADSU)) {
                        ROOVUPJBIR = DLQEQMHRSL.getContainer();
                        break;
                    }
                }
                if (ROOVUPJBIR != null) {
                    // released reserved containers
                    Resources.subtractFrom(VMZMEXSJHQ, ROOVUPJBIR.getResource());
                }
            }
        }
        // containers released/preemption from scheduler
        Set<ContainerId> BQEMSWSZLE = new HashSet<ContainerId>();
        if (IURYODDCYH.getContainerPreemptions() != null) {
            BQEMSWSZLE.addAll(IURYODDCYH.getContainerPreemptions());
        }
        if (IURYODDCYH.getStrictContainerPreemptions() != null) {
            BQEMSWSZLE.addAll(IURYODDCYH.getStrictContainerPreemptions());
        }
        if (!BQEMSWSZLE.isEmpty()) {
            for (ContainerId LWNJVLJGSN : BQEMSWSZLE) {
                if (!PNNZZJFZPX.containsKey(LWNJVLJGSN)) {
                    Container CIFGVTMSNX = null;
                    for (RMContainer ZRXZSSAUQD : QZYYGTBCGV.getLiveContainers()) {
                        if (ZRXZSSAUQD.getContainerId().equals(LWNJVLJGSN)) {
                            CIFGVTMSNX = ZRXZSSAUQD.getContainer();
                            break;
                        }
                    }
                    if (CIFGVTMSNX != null) {
                        PNNZZJFZPX.put(LWNJVLJGSN, CIFGVTMSNX.getResource());
                    }
                }
            }
        }
        // update metrics
        SortedMap<String, Counter> GZWYTGHTRU = ZZYEOJUKUV.getCounters();
        String[] XKJJRFHEWG = new String[]{ ("counter.queue." + TKJBBIJKLT) + ".pending.memory", ("counter.queue." + TKJBBIJKLT) + ".pending.cores", ("counter.queue." + TKJBBIJKLT) + ".allocated.memory", ("counter.queue." + TKJBBIJKLT) + ".allocated.cores" };
        int[] ORBHAHLYZR = new int[]{ VMZMEXSJHQ.getMemory(), VMZMEXSJHQ.getVirtualCores(), GPBZEUTCKK.getMemory(), GPBZEUTCKK.getVirtualCores() };
        for (int QBIWTOQIEC = XKJJRFHEWG.length - 1; QBIWTOQIEC >= 0; QBIWTOQIEC--) {
            if (!GZWYTGHTRU.containsKey(XKJJRFHEWG[QBIWTOQIEC])) {
                ZZYEOJUKUV.counter(XKJJRFHEWG[QBIWTOQIEC]);
                GZWYTGHTRU = ZZYEOJUKUV.getCounters();
            }
            GZWYTGHTRU.get(XKJJRFHEWG[QBIWTOQIEC]).inc(ORBHAHLYZR[QBIWTOQIEC]);
        }
        DVTBWQCMBQ.lock();
        try {
            if (!RIAWKTOJNB.isTracked(TKJBBIJKLT)) {
                RIAWKTOJNB.trackQueue(TKJBBIJKLT);
            }
        } finally {
            DVTBWQCMBQ.unlock();
        }
    }

    private void tearDown() throws IOException {
        // close job runtime writer
        if (SGAEZMGPJB != null) {
            SGAEZMGPJB.close();
        }
        // shut pool
        if (SSFZCHGYPJ != null)
            SSFZCHGYPJ.shutdown();

    }

    @SuppressWarnings("unchecked")
    private void initMetrics() throws Exception {
        ZZYEOJUKUV = new MetricRegistry();
        // configuration
        LKADITZRAJ = DGPJKXBAQW.get(METRICS_OUTPUT_DIR);
        int SSNBKKXNHY = DGPJKXBAQW.getInt(METRICS_WEB_ADDRESS_PORT, METRICS_WEB_ADDRESS_PORT_DEFAULT);
        // create SchedulerMetrics for current scheduler
        String YVXYDZBCYI = DGPJKXBAQW.get(CapacityScheduler.class.getName());
        Class ZNIYXCEOMW = (YVXYDZBCYI == null) ? SLSCapacityScheduler.MFAOQHNBVN.get(CapacityScheduler.class) : Class.forName(YVXYDZBCYI);
        RIAWKTOJNB = ((SchedulerMetrics) (ReflectionUtils.newInstance(ZNIYXCEOMW, new Configuration())));
        RIAWKTOJNB.init(this, ZZYEOJUKUV);
        // register various metrics
        registerJvmMetrics();
        registerClusterResourceMetrics();
        registerContainerAppNumMetrics();
        registerSchedulerMetrics();
        // .csv output
        initMetricsCSVOutput();
        // start web app to provide real-time tracking
        KEBEIPGBER = new SLSWebApp(this, SSNBKKXNHY);
        KEBEIPGBER.start();
        // a thread to update histogram timer
        SSFZCHGYPJ = new ScheduledThreadPoolExecutor(2);
        SSFZCHGYPJ.scheduleAtFixedRate(new SLSCapacityScheduler.HistogramsRunnable(), 0, 1000, TimeUnit.MILLISECONDS);
        // a thread to output metrics for real-tiem tracking
        SSFZCHGYPJ.scheduleAtFixedRate(new SLSCapacityScheduler.MetricsLogRunnable(), 0, 1000, TimeUnit.MILLISECONDS);
        // application running information
        SGAEZMGPJB = new BufferedWriter(new FileWriter(LKADITZRAJ + "/jobruntime.csv"));
        SGAEZMGPJB.write(("JobID,real_start_time,real_end_time," + "simulate_start_time,simulate_end_time") + SLSCapacityScheduler.DNFQZGUEXM);
        SGAEZMGPJB.flush();
    }

    private void registerJvmMetrics() {
        // add JVM gauges
        ZZYEOJUKUV.register("variable.jvm.free.memory", new com.codahale.metrics.Gauge<Long>() {
            @Override
            public Long getValue() {
                return Runtime.getRuntime().freeMemory();
            }
        });
        ZZYEOJUKUV.register("variable.jvm.max.memory", new com.codahale.metrics.Gauge<Long>() {
            @Override
            public Long getValue() {
                return Runtime.getRuntime().maxMemory();
            }
        });
        ZZYEOJUKUV.register("variable.jvm.total.memory", new com.codahale.metrics.Gauge<Long>() {
            @Override
            public Long getValue() {
                return Runtime.getRuntime().totalMemory();
            }
        });
    }

    private void registerClusterResourceMetrics() {
        ZZYEOJUKUV.register("variable.cluster.allocated.memory", new com.codahale.metrics.Gauge<Integer>() {
            @Override
            public Integer getValue() {
                if (getRootQueueMetrics() == null) {
                    return 0;
                } else {
                    return getRootQueueMetrics().getAllocatedMB();
                }
            }
        });
        ZZYEOJUKUV.register("variable.cluster.allocated.vcores", new com.codahale.metrics.Gauge<Integer>() {
            @Override
            public Integer getValue() {
                if (getRootQueueMetrics() == null) {
                    return 0;
                } else {
                    return getRootQueueMetrics().getAllocatedVirtualCores();
                }
            }
        });
        ZZYEOJUKUV.register("variable.cluster.available.memory", new com.codahale.metrics.Gauge<Integer>() {
            @Override
            public Integer getValue() {
                if (getRootQueueMetrics() == null) {
                    return 0;
                } else {
                    return getRootQueueMetrics().getAvailableMB();
                }
            }
        });
        ZZYEOJUKUV.register("variable.cluster.available.vcores", new com.codahale.metrics.Gauge<Integer>() {
            @Override
            public Integer getValue() {
                if (getRootQueueMetrics() == null) {
                    return 0;
                } else {
                    return getRootQueueMetrics().getAvailableVirtualCores();
                }
            }
        });
    }

    private void registerContainerAppNumMetrics() {
        ZZYEOJUKUV.register("variable.running.application", new com.codahale.metrics.Gauge<Integer>() {
            @Override
            public Integer getValue() {
                if (getRootQueueMetrics() == null) {
                    return 0;
                } else {
                    return getRootQueueMetrics().getAppsRunning();
                }
            }
        });
        ZZYEOJUKUV.register("variable.running.container", new com.codahale.metrics.Gauge<Integer>() {
            @Override
            public Integer getValue() {
                if (getRootQueueMetrics() == null) {
                    return 0;
                } else {
                    return getRootQueueMetrics().getAllocatedContainers();
                }
            }
        });
    }

    private void registerSchedulerMetrics() {
        TBYTAPDBAU.lock();
        try {
            // counters for scheduler operations
            SQQXJLKTBG = ZZYEOJUKUV.counter("counter.scheduler.operation.allocate");
            ABLOIDOCMG = ZZYEOJUKUV.counter("counter.scheduler.operation.handle");
            AXVPNMVVDI = new HashMap<SchedulerEventType, Counter>();
            for (SchedulerEventType XGNDWGMDZF : SchedulerEventType.values()) {
                Counter KYNEFQAREF = ZZYEOJUKUV.counter("counter.scheduler.operation.handle." + XGNDWGMDZF);
                AXVPNMVVDI.put(XGNDWGMDZF, KYNEFQAREF);
            }
            // timers for scheduler operations
            int BRMAYYZOJT = DGPJKXBAQW.getInt(METRICS_TIMER_WINDOW_SIZE, METRICS_TIMER_WINDOW_SIZE_DEFAULT);
            KYVZAGXYMH = new Timer(new SlidingWindowReservoir(BRMAYYZOJT));
            FFDJHPCOLR = new Timer(new SlidingWindowReservoir(BRMAYYZOJT));
            TBCJBMFTDS = new HashMap<SchedulerEventType, Timer>();
            for (SchedulerEventType EEVCOTWGXZ : SchedulerEventType.values()) {
                Timer BLFTBJCQCX = new Timer(new SlidingWindowReservoir(BRMAYYZOJT));
                TBCJBMFTDS.put(EEVCOTWGXZ, BLFTBJCQCX);
            }
            // histogram for scheduler operations (Samplers)
            XMURHOEUEY = new ArrayList<Histogram>();
            SJVLHUGBZC = new HashMap<Histogram, Timer>();
            Histogram GRYYEBGHPW = new Histogram(new SlidingWindowReservoir(SLSCapacityScheduler.NWNCDCWMYX));
            ZZYEOJUKUV.register("sampler.scheduler.operation.allocate.timecost", GRYYEBGHPW);
            XMURHOEUEY.add(GRYYEBGHPW);
            SJVLHUGBZC.put(GRYYEBGHPW, KYVZAGXYMH);
            Histogram ZOUTKYFBAM = new Histogram(new SlidingWindowReservoir(SLSCapacityScheduler.NWNCDCWMYX));
            ZZYEOJUKUV.register("sampler.scheduler.operation.handle.timecost", ZOUTKYFBAM);
            XMURHOEUEY.add(ZOUTKYFBAM);
            SJVLHUGBZC.put(ZOUTKYFBAM, FFDJHPCOLR);
            for (SchedulerEventType TZNSMNFZZQ : SchedulerEventType.values()) {
                Histogram AUAWBERAPZ = new Histogram(new SlidingWindowReservoir(SLSCapacityScheduler.NWNCDCWMYX));
                ZZYEOJUKUV.register(("sampler.scheduler.operation.handle." + TZNSMNFZZQ) + ".timecost", AUAWBERAPZ);
                XMURHOEUEY.add(AUAWBERAPZ);
                SJVLHUGBZC.put(AUAWBERAPZ, TBCJBMFTDS.get(TZNSMNFZZQ));
            }
        } finally {
            TBYTAPDBAU.unlock();
        }
    }

    private void initMetricsCSVOutput() {
        int YZLDUZYCDJ = DGPJKXBAQW.getInt(METRICS_RECORD_INTERVAL_MS, METRICS_RECORD_INTERVAL_MS_DEFAULT);
        File XFHAEODKGG = new File(LKADITZRAJ + "/metrics");
        if ((!XFHAEODKGG.exists()) && (!XFHAEODKGG.mkdirs())) {
            KMYWHLKZVJ.error("Cannot create directory " + XFHAEODKGG.getAbsoluteFile());
        }
        final CsvReporter FSYKEUEYIL = CsvReporter.forRegistry(ZZYEOJUKUV).formatFor(java.util.Locale.US).convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).build(new File(LKADITZRAJ + "/metrics"));
        FSYKEUEYIL.start(YZLDUZYCDJ, TimeUnit.MILLISECONDS);
    }

    class HistogramsRunnable implements Runnable {
        @Override
        public void run() {
            TBYTAPDBAU.lock();
            try {
                for (Histogram histogram : XMURHOEUEY) {
                    Timer timer = SJVLHUGBZC.get(histogram);
                    histogram.update(((int) (timer.getSnapshot().getMean())));
                }
            } finally {
                TBYTAPDBAU.unlock();
            }
        }
    }

    class MetricsLogRunnable implements Runnable {
        private boolean TSDJIEOWRS = true;

        public MetricsLogRunnable() {
            try {
                JKRVANPEIQ = new BufferedWriter(new FileWriter(LKADITZRAJ + "/realtimetrack.json"));
                JKRVANPEIQ.write("[");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            if (AOIUCPDLQM) {
                // all WebApp to get real tracking json
                String metrics = KEBEIPGBER.generateRealTimeTrackingMetrics();
                // output
                try {
                    if (TSDJIEOWRS) {
                        JKRVANPEIQ.write(metrics + SLSCapacityScheduler.DNFQZGUEXM);
                        TSDJIEOWRS = false;
                    } else {
                        JKRVANPEIQ.write(("," + metrics) + SLSCapacityScheduler.DNFQZGUEXM);
                    }
                    JKRVANPEIQ.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // the following functions are used by AMSimulator
    public void addAMRuntime(ApplicationId DGZPOJZUAU, long HYFDDSQVGI, long JMVDNIDIXV, long FTFEXRAGBV, long EZPYDDHRDH) {
        if (JQRZYRNGPE) {
            try {
                // write job runtime information
                StringBuilder XTEJZKCWVO = new StringBuilder();
                XTEJZKCWVO.append(DGZPOJZUAU).append(",").append(HYFDDSQVGI).append(",").append(JMVDNIDIXV).append(",").append(FTFEXRAGBV).append(",").append(EZPYDDHRDH);
                SGAEZMGPJB.write(XTEJZKCWVO.toString() + SLSCapacityScheduler.DNFQZGUEXM);
                SGAEZMGPJB.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateQueueMetrics(String UNRRXIXNVF, int OIRMPNJARR, int IDPTPHLUOJ) {
        // update queue counters
        SortedMap<String, Counter> IGIVJFKKWY = ZZYEOJUKUV.getCounters();
        if (OIRMPNJARR != 0) {
            String HRQCMUOXZC = ("counter.queue." + UNRRXIXNVF) + ".allocated.memory";
            if (!IGIVJFKKWY.containsKey(HRQCMUOXZC)) {
                ZZYEOJUKUV.counter(HRQCMUOXZC);
                IGIVJFKKWY = ZZYEOJUKUV.getCounters();
            }
            IGIVJFKKWY.get(HRQCMUOXZC).inc(-OIRMPNJARR);
        }
        if (IDPTPHLUOJ != 0) {
            String GRBAMUWSHO = ("counter.queue." + UNRRXIXNVF) + ".allocated.cores";
            if (!IGIVJFKKWY.containsKey(GRBAMUWSHO)) {
                ZZYEOJUKUV.counter(GRBAMUWSHO);
                IGIVJFKKWY = ZZYEOJUKUV.getCounters();
            }
            IGIVJFKKWY.get(GRBAMUWSHO).inc(-IDPTPHLUOJ);
        }
    }

    public void setQueueSet(Set<String> ZDEXTQJDNR) {
        this.BBSZFEXKFR = ZDEXTQJDNR;
    }

    public Set<String> getQueueSet() {
        return this.BBSZFEXKFR;
    }

    public void setTrackedAppSet(Set<String> YCPMYWINHV) {
        this.UWKONSDXYJ = YCPMYWINHV;
    }

    public Set<String> getTrackedAppSet() {
        return this.UWKONSDXYJ;
    }

    public MetricRegistry getMetrics() {
        return ZZYEOJUKUV;
    }

    public SchedulerMetrics getSchedulerMetrics() {
        return RIAWKTOJNB;
    }

    // API open to out classes
    public void addTrackedApp(ApplicationAttemptId NERXRYJCOM, String WJYAWZMWMM) {
        if (JQRZYRNGPE) {
            RIAWKTOJNB.trackApp(NERXRYJCOM, WJYAWZMWMM);
        }
    }

    public void removeTrackedApp(ApplicationAttemptId IHTSAAVSXQ, String UCKBGNOHLY) {
        if (JQRZYRNGPE) {
            RIAWKTOJNB.untrackApp(IHTSAAVSXQ, UCKBGNOHLY);
        }
    }

    @Override
    public Configuration getConf() {
        return DGPJKXBAQW;
    }
}