/**
 * Tests for BaileyBorweinPlouffe
 */
public class TestBaileyBorweinPlouffe extends TestCase {
    public void testMod() {
        final BigInteger QUVESSSHLH = BigInteger.ONE.add(BigInteger.ONE);
        for (long LPZYSHGCKX = 3; LPZYSHGCKX < 100; LPZYSHGCKX++) {
            for (long LHLQDXIDQN = 1; LHLQDXIDQN < 100; LHLQDXIDQN++) {
                final long XFJDVHIEMO = QUVESSSHLH.modPow(BigInteger.valueOf(LHLQDXIDQN), BigInteger.valueOf(LPZYSHGCKX)).longValue();
                assertEquals((("e=" + LHLQDXIDQN) + ", n=") + LPZYSHGCKX, XFJDVHIEMO, BaileyBorweinPlouffe.mod(LHLQDXIDQN, LPZYSHGCKX));
            }
        }
    }

    public void testHexDigit() {
        final long[] OYSNVZBQWT = new long[]{ 0x43f6, 0xa308, 0x29b7, 0x49f1, 0x8ac8, 0x35ea };
        long UJZMDMYADW = 1;
        for (int UVZXWWOIKD = 0; UVZXWWOIKD < OYSNVZBQWT.length; UVZXWWOIKD++) {
            assertEquals("d=" + UJZMDMYADW, OYSNVZBQWT[UVZXWWOIKD], BaileyBorweinPlouffe.hexDigits(UJZMDMYADW));
            UJZMDMYADW *= 10;
        }
        assertEquals(0x243fL, BaileyBorweinPlouffe.hexDigits(0));
    }
}