public class MRClientProtocolPBServiceImpl implements MRClientProtocolPB {
    private MRClientProtocol UJFRTSYEOE;

    public MRClientProtocolPBServiceImpl(MRClientProtocol GBZIBJUREN) {
        this.UJFRTSYEOE = GBZIBJUREN;
    }

    @Override
    public GetJobReportResponseProto getJobReport(RpcController RCCTPVLMSR, GetJobReportRequestProto DVCGCDLGIC) throws ServiceException {
        GetJobReportRequestPBImpl ARHPMZJDUD = new GetJobReportRequestPBImpl(DVCGCDLGIC);
        try {
            GetJobReportResponse DQWSSUZTVN = UJFRTSYEOE.getJobReport(ARHPMZJDUD);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetJobReportResponsePBImpl) (DQWSSUZTVN)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public GetTaskReportResponseProto getTaskReport(RpcController QWOIKCFFWK, GetTaskReportRequestProto JGAXWSEBXW) throws ServiceException {
        GetTaskReportRequest FFDCJJWUWH = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetTaskReportRequestPBImpl(JGAXWSEBXW);
        try {
            GetTaskReportResponse KENKDNHICI = UJFRTSYEOE.getTaskReport(FFDCJJWUWH);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetTaskReportResponsePBImpl) (KENKDNHICI)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public GetTaskAttemptReportResponseProto getTaskAttemptReport(RpcController ZUPZOBONYW, GetTaskAttemptReportRequestProto YWNUFQFNCP) throws ServiceException {
        GetTaskAttemptReportRequest OXEJTEGASL = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetTaskAttemptReportRequestPBImpl(YWNUFQFNCP);
        try {
            GetTaskAttemptReportResponse UKKIVKDESW = UJFRTSYEOE.getTaskAttemptReport(OXEJTEGASL);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetTaskAttemptReportResponsePBImpl) (UKKIVKDESW)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public GetCountersResponseProto getCounters(RpcController PLSAJARVSD, GetCountersRequestProto SKPIPOJXYS) throws ServiceException {
        GetCountersRequest QQDDPXXBSZ = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetCountersRequestPBImpl(SKPIPOJXYS);
        try {
            GetCountersResponse QHSNLLCXNC = UJFRTSYEOE.getCounters(QQDDPXXBSZ);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetCountersResponsePBImpl) (QHSNLLCXNC)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public GetTaskAttemptCompletionEventsResponseProto getTaskAttemptCompletionEvents(RpcController PSDVTYGLAI, GetTaskAttemptCompletionEventsRequestProto VMVCSFBDVK) throws ServiceException {
        GetTaskAttemptCompletionEventsRequest SVLNQAJYCH = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetTaskAttemptCompletionEventsRequestPBImpl(VMVCSFBDVK);
        try {
            GetTaskAttemptCompletionEventsResponse TEERGCTUPZ = UJFRTSYEOE.getTaskAttemptCompletionEvents(SVLNQAJYCH);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetTaskAttemptCompletionEventsResponsePBImpl) (TEERGCTUPZ)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public GetTaskReportsResponseProto getTaskReports(RpcController KJXPOXTNSU, GetTaskReportsRequestProto QZKKFAKKCN) throws ServiceException {
        GetTaskReportsRequest ONFWGKXJSN = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetTaskReportsRequestPBImpl(QZKKFAKKCN);
        try {
            GetTaskReportsResponse RABPNPVSNW = UJFRTSYEOE.getTaskReports(ONFWGKXJSN);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetTaskReportsResponsePBImpl) (RABPNPVSNW)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public GetDiagnosticsResponseProto getDiagnostics(RpcController KYOTCNOQSD, GetDiagnosticsRequestProto RWOMIEJUHJ) throws ServiceException {
        GetDiagnosticsRequest DMVRPNPGJJ = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetDiagnosticsRequestPBImpl(RWOMIEJUHJ);
        try {
            GetDiagnosticsResponse ZAIHOTIEEH = UJFRTSYEOE.getDiagnostics(DMVRPNPGJJ);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetDiagnosticsResponsePBImpl) (ZAIHOTIEEH)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public GetDelegationTokenResponseProto getDelegationToken(RpcController JWPJAHZEPL, GetDelegationTokenRequestProto EKTQSXNZHV) throws ServiceException {
        GetDelegationTokenRequest DYDJZHLTAY = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetDelegationTokenRequestPBImpl(EKTQSXNZHV);
        try {
            GetDelegationTokenResponse ATMAJFVGRC = UJFRTSYEOE.getDelegationToken(DYDJZHLTAY);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.GetDelegationTokenResponsePBImpl) (ATMAJFVGRC)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public KillJobResponseProto killJob(RpcController BHFMRBXRQO, KillJobRequestProto AWIZDJKVJX) throws ServiceException {
        KillJobRequest KKJEHVMIZO = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.KillJobRequestPBImpl(AWIZDJKVJX);
        try {
            KillJobResponse MDRXQCOUKE = UJFRTSYEOE.killJob(KKJEHVMIZO);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.KillJobResponsePBImpl) (MDRXQCOUKE)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public KillTaskResponseProto killTask(RpcController MJOIWFHKNF, KillTaskRequestProto TYPYDFFARI) throws ServiceException {
        KillTaskRequest GHSQJSSDDY = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.KillTaskRequestPBImpl(TYPYDFFARI);
        try {
            KillTaskResponse WZNZQWCNNC = UJFRTSYEOE.killTask(GHSQJSSDDY);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.KillTaskResponsePBImpl) (WZNZQWCNNC)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public KillTaskAttemptResponseProto killTaskAttempt(RpcController DSCSDIKGXR, KillTaskAttemptRequestProto VDKYIMCYEX) throws ServiceException {
        KillTaskAttemptRequest GCVMQFYUXU = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.KillTaskAttemptRequestPBImpl(VDKYIMCYEX);
        try {
            KillTaskAttemptResponse MQJCGUMRIK = UJFRTSYEOE.killTaskAttempt(GCVMQFYUXU);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.KillTaskAttemptResponsePBImpl) (MQJCGUMRIK)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public FailTaskAttemptResponseProto failTaskAttempt(RpcController TRRNTUJZXM, FailTaskAttemptRequestProto VWJIUTJXXC) throws ServiceException {
        FailTaskAttemptRequest OZGLQWASES = new org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.FailTaskAttemptRequestPBImpl(VWJIUTJXXC);
        try {
            FailTaskAttemptResponse OBEVJJSFOQ = UJFRTSYEOE.failTaskAttempt(OZGLQWASES);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.FailTaskAttemptResponsePBImpl) (OBEVJJSFOQ)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public RenewDelegationTokenResponseProto renewDelegationToken(RpcController JFTAYUFXAT, RenewDelegationTokenRequestProto VILQIAKLFH) throws ServiceException {
        RenewDelegationTokenRequestPBImpl EIQBLHHIXP = new RenewDelegationTokenRequestPBImpl(VILQIAKLFH);
        try {
            RenewDelegationTokenResponse PPJVEAWGSO = UJFRTSYEOE.renewDelegationToken(EIQBLHHIXP);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.RenewDelegationTokenResponsePBImpl) (PPJVEAWGSO)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    public CancelDelegationTokenResponseProto cancelDelegationToken(RpcController WRDRVRDEEH, CancelDelegationTokenRequestProto AHUINGXJSO) throws ServiceException {
        CancelDelegationTokenRequestPBImpl CECKUFXXCY = new CancelDelegationTokenRequestPBImpl(AHUINGXJSO);
        try {
            CancelDelegationTokenResponse LRTBTAZLZE = UJFRTSYEOE.cancelDelegationToken(CECKUFXXCY);
            return ((org.apache.hadoop.mapreduce.v2.api.protocolrecords.impl.pb.CancelDelegationTokenResponsePBImpl) (LRTBTAZLZE)).getProto();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
    }
}