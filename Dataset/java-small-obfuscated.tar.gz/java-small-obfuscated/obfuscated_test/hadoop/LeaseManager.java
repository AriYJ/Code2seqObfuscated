/**
 * LeaseManager does the lease housekeeping for writing on files.
 * This class also provides useful static methods for lease recovery.
 *
 * Lease Recovery Algorithm
 * 1) Namenode retrieves lease information
 * 2) For each file f in the lease, consider the last block b of f
 * 2.1) Get the datanodes which contains b
 * 2.2) Assign one of the datanodes as the primary datanode p
 *
 * 2.3) p obtains a new generation stamp from the namenode
 * 2.4) p gets the block info from each datanode
 * 2.5) p computes the minimum block length
 * 2.6) p updates the datanodes, which have a valid generation stamp,
 *      with the new generation stamp and the minimum block length
 * 2.7) p acknowledges the namenode the update results
 *
 * 2.8) Namenode updates the BlockInfo
 * 2.9) Namenode removes f from the lease
 *      and removes the lease once all files have been removed
 * 2.10) Namenode commit changes to edit log
 */
@InterfaceAudience.Private
public class LeaseManager {
    public static final Log UKYZZOGVWF = LogFactory.getLog(LeaseManager.class);

    private final FSNamesystem VAMRNFWDXE;

    private long KBGMHIYHNI = HdfsConstants.LEASE_SOFTLIMIT_PERIOD;

    private long DTAIEKSZGW = HdfsConstants.LEASE_HARDLIMIT_PERIOD;

    // 
    // Used for handling lock-leases
    // Mapping: leaseHolder -> Lease
    // 
    private final SortedMap<String, LeaseManager.Lease> OGTPNXZKVN = new TreeMap<String, LeaseManager.Lease>();

    // Set of: Lease
    private final SortedSet<LeaseManager.Lease> VWPSWAZSYH = new TreeSet<LeaseManager.Lease>();

    // 
    // Map path names to leases. It is protected by the sortedLeases lock.
    // The map stores pathnames in lexicographical order.
    // 
    private final SortedMap<String, LeaseManager.Lease> JJJANFKNZD = new TreeMap<String, LeaseManager.Lease>();

    private Daemon HFWFHOMGQP;

    private volatile boolean XQHADVQJSM;

    LeaseManager(FSNamesystem PKUZEDQPMG) {
        this.VAMRNFWDXE = PKUZEDQPMG;
    }

    LeaseManager.Lease getLease(String EMSWJMLNZM) {
        return OGTPNXZKVN.get(EMSWJMLNZM);
    }

    SortedSet<LeaseManager.Lease> getSortedLeases() {
        return VWPSWAZSYH;
    }

    /**
     *
     *
     * @return the lease containing src
     */
    public LeaseManager.Lease getLeaseByPath(String JWYEWUUMPA) {
        return JJJANFKNZD.get(JWYEWUUMPA);
    }

    /**
     *
     *
     * @return the number of leases currently in the system
     */
    public synchronized int countLease() {
        return VWPSWAZSYH.size();
    }

    /**
     *
     *
     * @return the number of paths contained in all leases
     */
    synchronized int countPath() {
        int JCSXDCVNHM = 0;
        for (LeaseManager.Lease XKNIDPQZUJ : VWPSWAZSYH) {
            JCSXDCVNHM += XKNIDPQZUJ.getPaths().size();
        }
        return JCSXDCVNHM;
    }

    /**
     * Adds (or re-adds) the lease for the specified file.
     */
    synchronized LeaseManager.Lease addLease(String BFUZLEFPWP, String FYEVAMLIIP) {
        LeaseManager.Lease HTXMABYLRE = getLease(BFUZLEFPWP);
        if (HTXMABYLRE == null) {
            HTXMABYLRE = new LeaseManager.Lease(BFUZLEFPWP);
            OGTPNXZKVN.put(BFUZLEFPWP, HTXMABYLRE);
            VWPSWAZSYH.add(HTXMABYLRE);
        } else {
            renewLease(HTXMABYLRE);
        }
        JJJANFKNZD.put(FYEVAMLIIP, HTXMABYLRE);
        HTXMABYLRE.ODXTUDGPFC.add(FYEVAMLIIP);
        return HTXMABYLRE;
    }

    /**
     * Remove the specified lease and src.
     */
    synchronized void removeLease(LeaseManager.Lease JPEZISRFPL, String LTSSXNUWOK) {
        JJJANFKNZD.remove(LTSSXNUWOK);
        if (!JPEZISRFPL.removePath(LTSSXNUWOK)) {
            if (LeaseManager.UKYZZOGVWF.isDebugEnabled()) {
                LeaseManager.UKYZZOGVWF.debug(((LTSSXNUWOK + " not found in lease.paths (=") + JPEZISRFPL.ODXTUDGPFC) + ")");
            }
        }
        if (!JPEZISRFPL.hasPath()) {
            OGTPNXZKVN.remove(JPEZISRFPL.XRFEQAJONF);
            if (!VWPSWAZSYH.remove(JPEZISRFPL)) {
                LeaseManager.UKYZZOGVWF.error(JPEZISRFPL + " not found in sortedLeases");
            }
        }
    }

    /**
     * Remove the lease for the specified holder and src
     */
    synchronized void removeLease(String AIRBPHPZZG, String AJXZABJVAU) {
        LeaseManager.Lease QFXMKCCGMB = getLease(AIRBPHPZZG);
        if (QFXMKCCGMB != null) {
            removeLease(QFXMKCCGMB, AJXZABJVAU);
        } else {
            LeaseManager.UKYZZOGVWF.warn((("Removing non-existent lease! holder=" + AIRBPHPZZG) + " src=") + AJXZABJVAU);
        }
    }

    synchronized void removeAllLeases() {
        VWPSWAZSYH.clear();
        JJJANFKNZD.clear();
        OGTPNXZKVN.clear();
    }

    /**
     * Reassign lease for file src to the new holder.
     */
    synchronized LeaseManager.Lease reassignLease(LeaseManager.Lease HMDDAUHAJJ, String YPOBDUDMAR, String FLMUUYHBST) {
        assert FLMUUYHBST != null : "new lease holder is null";
        if (HMDDAUHAJJ != null) {
            removeLease(HMDDAUHAJJ, YPOBDUDMAR);
        }
        return addLease(FLMUUYHBST, YPOBDUDMAR);
    }

    /**
     * Renew the lease(s) held by the given client
     */
    synchronized void renewLease(String JWQABEPSGP) {
        renewLease(getLease(JWQABEPSGP));
    }

    synchronized void renewLease(LeaseManager.Lease RDPITQJRCJ) {
        if (RDPITQJRCJ != null) {
            VWPSWAZSYH.remove(RDPITQJRCJ);
            RDPITQJRCJ.renew();
            VWPSWAZSYH.add(RDPITQJRCJ);
        }
    }

    /**
     * Renew all of the currently open leases.
     */
    synchronized void renewAllLeases() {
        for (LeaseManager.Lease RURRFOAWCU : OGTPNXZKVN.values()) {
            renewLease(RURRFOAWCU);
        }
    }

    /**
     * **********************************************************
     * A Lease governs all the locks held by a single client.
     * For each client there's a corresponding lease, whose
     * timestamp is updated when the client periodically
     * checks in.  If the client dies and allows its lease to
     * expire, all the corresponding locks can be released.
     * ***********************************************************
     */
    class Lease implements Comparable<LeaseManager.Lease> {
        private final String XRFEQAJONF;

        private long MVHPAPPGQF;

        private final Collection<String> ODXTUDGPFC = new TreeSet<String>();

        /**
         * Only LeaseManager object can create a lease
         */
        private Lease(String holder) {
            this.XRFEQAJONF = holder;
            renew();
        }

        /**
         * Only LeaseManager object can renew a lease
         */
        private void renew() {
            this.MVHPAPPGQF = now();
        }

        /**
         *
         *
         * @return true if the Hard Limit Timer has expired
         */
        public boolean expiredHardLimit() {
            return (now() - MVHPAPPGQF) > DTAIEKSZGW;
        }

        /**
         *
         *
         * @return true if the Soft Limit Timer has expired
         */
        public boolean expiredSoftLimit() {
            return (now() - MVHPAPPGQF) > KBGMHIYHNI;
        }

        /**
         * Does this lease contain any path?
         */
        boolean hasPath() {
            return !ODXTUDGPFC.isEmpty();
        }

        boolean removePath(String src) {
            return ODXTUDGPFC.remove(src);
        }

        @Override
        public String toString() {
            return ((("[Lease.  Holder: " + XRFEQAJONF) + ", pendingcreates: ") + ODXTUDGPFC.size()) + "]";
        }

        @Override
        public int compareTo(LeaseManager.Lease o) {
            LeaseManager.Lease l1 = this;
            LeaseManager.Lease l2 = o;
            long lu1 = l1.MVHPAPPGQF;
            long lu2 = l2.MVHPAPPGQF;
            if (lu1 < lu2) {
                return -1;
            } else
                if (lu1 > lu2) {
                    return 1;
                } else {
                    return l1.XRFEQAJONF.compareTo(l2.XRFEQAJONF);
                }

        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof LeaseManager.Lease)) {
                return false;
            }
            LeaseManager.Lease obj = ((LeaseManager.Lease) (o));
            if ((MVHPAPPGQF == obj.MVHPAPPGQF) && XRFEQAJONF.equals(obj.XRFEQAJONF)) {
                return true;
            }
            return false;
        }

        @Override
        public int hashCode() {
            return XRFEQAJONF.hashCode();
        }

        Collection<String> getPaths() {
            return ODXTUDGPFC;
        }

        String getHolder() {
            return XRFEQAJONF;
        }

        void replacePath(String oldpath, String newpath) {
            ODXTUDGPFC.remove(oldpath);
            ODXTUDGPFC.add(newpath);
        }

        @VisibleForTesting
        long getLastUpdate() {
            return MVHPAPPGQF;
        }
    }

    synchronized void changeLease(String NCWFDJYVDR, String PIJKGWESZB) {
        if (LeaseManager.UKYZZOGVWF.isDebugEnabled()) {
            LeaseManager.UKYZZOGVWF.debug(((((getClass().getSimpleName() + ".changelease: ") + " src=") + NCWFDJYVDR) + ", dest=") + PIJKGWESZB);
        }
        final int IULZIVPXKT = NCWFDJYVDR.length();
        for (Map.Entry<String, LeaseManager.Lease> EAVNESTXDP : LeaseManager.findLeaseWithPrefixPath(NCWFDJYVDR, JJJANFKNZD).entrySet()) {
            final String NNCXXZXTHV = EAVNESTXDP.getKey();
            final LeaseManager.Lease XCAQGQWMRU = EAVNESTXDP.getValue();
            // replace stem of src with new destination
            final String WGZHPUFTQE = PIJKGWESZB + NNCXXZXTHV.substring(IULZIVPXKT);
            if (LeaseManager.UKYZZOGVWF.isDebugEnabled()) {
                LeaseManager.UKYZZOGVWF.debug((("changeLease: replacing " + NNCXXZXTHV) + " with ") + WGZHPUFTQE);
            }
            XCAQGQWMRU.replacePath(NNCXXZXTHV, WGZHPUFTQE);
            JJJANFKNZD.remove(NNCXXZXTHV);
            JJJANFKNZD.put(WGZHPUFTQE, XCAQGQWMRU);
        }
    }

    synchronized void removeLeaseWithPrefixPath(String DOWFJQKCMD) {
        for (Map.Entry<String, LeaseManager.Lease> XAEMVZNOJW : LeaseManager.findLeaseWithPrefixPath(DOWFJQKCMD, JJJANFKNZD).entrySet()) {
            if (LeaseManager.UKYZZOGVWF.isDebugEnabled()) {
                LeaseManager.UKYZZOGVWF.debug((LeaseManager.class.getSimpleName() + ".removeLeaseWithPrefixPath: entry=") + XAEMVZNOJW);
            }
            removeLease(XAEMVZNOJW.getValue(), XAEMVZNOJW.getKey());
        }
    }

    private static Map<String, LeaseManager.Lease> findLeaseWithPrefixPath(String FRDUUJCNKF, SortedMap<String, LeaseManager.Lease> AKIYENXOXH) {
        if (LeaseManager.UKYZZOGVWF.isDebugEnabled()) {
            LeaseManager.UKYZZOGVWF.debug((LeaseManager.class.getSimpleName() + ".findLease: prefix=") + FRDUUJCNKF);
        }
        final Map<String, LeaseManager.Lease> UFQTEWMDDJ = new HashMap<String, LeaseManager.Lease>();
        int HYRTCMDWSB = FRDUUJCNKF.length();
        // prefix may ended with '/'
        if (FRDUUJCNKF.charAt(HYRTCMDWSB - 1) == Path.SEPARATOR_CHAR) {
            HYRTCMDWSB -= 1;
        }
        for (Map.Entry<String, LeaseManager.Lease> CYLUSXTTZU : AKIYENXOXH.tailMap(FRDUUJCNKF).entrySet()) {
            final String YAYXLUKFAA = CYLUSXTTZU.getKey();
            if (!YAYXLUKFAA.startsWith(FRDUUJCNKF)) {
                return UFQTEWMDDJ;
            }
            if ((YAYXLUKFAA.length() == HYRTCMDWSB) || (YAYXLUKFAA.charAt(HYRTCMDWSB) == Path.SEPARATOR_CHAR)) {
                UFQTEWMDDJ.put(CYLUSXTTZU.getKey(), CYLUSXTTZU.getValue());
            }
        }
        return UFQTEWMDDJ;
    }

    public void setLeasePeriod(long WYGXTBYMEE, long UUKFAGNKAB) {
        this.KBGMHIYHNI = WYGXTBYMEE;
        this.DTAIEKSZGW = UUKFAGNKAB;
    }

    /**
     * ****************************************************
     * Monitor checks for leases that have expired,
     * and disposes of them.
     * ****************************************************
     */
    class Monitor implements Runnable {
        final String ALNCYAIVFF = getClass().getSimpleName();

        /**
         * Check leases periodically.
         */
        @Override
        public void run() {
            for (; XQHADVQJSM && VAMRNFWDXE.isRunning();) {
                boolean needSync = false;
                try {
                    VAMRNFWDXE.writeLockInterruptibly();
                    try {
                        if (!VAMRNFWDXE.isInSafeMode()) {
                            needSync = checkLeases();
                        }
                    } finally {
                        VAMRNFWDXE.writeUnlock();
                        // lease reassignments should to be sync'ed.
                        if (needSync) {
                            VAMRNFWDXE.getEditLog().logSync();
                        }
                    }
                    Thread.sleep(NAMENODE_LEASE_RECHECK_INTERVAL);
                } catch (InterruptedException ie) {
                    if (LeaseManager.UKYZZOGVWF.isDebugEnabled()) {
                        LeaseManager.UKYZZOGVWF.debug(ALNCYAIVFF + " is interrupted", ie);
                    }
                }
            }
        }
    }

    /**
     * Get the list of inodes corresponding to valid leases.
     *
     * @return list of inodes
     */
    Map<String, INodeFile> getINodesUnderConstruction() {
        Map<String, INodeFile> FANEKJLTOA = new TreeMap<String, INodeFile>();
        for (String NXOJDYUJSE : JJJANFKNZD.keySet()) {
            // verify that path exists in namespace
            try {
                INodeFile RYUGGQQYMJ = INodeFile.valueOf(VAMRNFWDXE.dir.getINode(NXOJDYUJSE), NXOJDYUJSE);
                Preconditions.checkState(RYUGGQQYMJ.isUnderConstruction());
                FANEKJLTOA.put(NXOJDYUJSE, RYUGGQQYMJ);
            } catch (IOException ioe) {
                LeaseManager.UKYZZOGVWF.error(ioe);
            }
        }
        return FANEKJLTOA;
    }

    /**
     * Check the leases beginning from the oldest.
     *
     * @return true is sync is needed.
     */
    private synchronized boolean checkLeases() {
        boolean PTRIXZPUIL = false;
        assert VAMRNFWDXE.hasWriteLock();
        for (; VWPSWAZSYH.size() > 0;) {
            final LeaseManager.Lease LEMYUIFXQK = VWPSWAZSYH.first();
            if (!LEMYUIFXQK.expiredHardLimit()) {
                return PTRIXZPUIL;
            }
            LeaseManager.UKYZZOGVWF.info(LEMYUIFXQK + " has expired hard limit");
            final List<String> XLQXMEQBNP = new ArrayList<String>();
            // need to create a copy of the oldest lease paths, becuase
            // internalReleaseLease() removes paths corresponding to empty files,
            // i.e. it needs to modify the collection being iterated over
            // causing ConcurrentModificationException
            String[] SGRIDTSJLA = new String[LEMYUIFXQK.getPaths().size()];
            LEMYUIFXQK.getPaths().toArray(SGRIDTSJLA);
            for (String FKDUXEVCQB : SGRIDTSJLA) {
                try {
                    boolean YPYZAKYAON = VAMRNFWDXE.internalReleaseLease(LEMYUIFXQK, FKDUXEVCQB, NAMENODE_LEASE_HOLDER);
                    if (LeaseManager.UKYZZOGVWF.isDebugEnabled()) {
                        if (YPYZAKYAON) {
                            LeaseManager.UKYZZOGVWF.debug(("Lease recovery for " + FKDUXEVCQB) + " is complete. File closed.");
                        } else {
                            LeaseManager.UKYZZOGVWF.debug((("Started block recovery " + FKDUXEVCQB) + " lease ") + LEMYUIFXQK);
                        }
                    }
                    // If a lease recovery happened, we need to sync later.
                    if ((!PTRIXZPUIL) && (!YPYZAKYAON)) {
                        PTRIXZPUIL = true;
                    }
                } catch (IOException e) {
                    LeaseManager.UKYZZOGVWF.error((("Cannot release the path " + FKDUXEVCQB) + " in the lease ") + LEMYUIFXQK, e);
                    XLQXMEQBNP.add(FKDUXEVCQB);
                }
            }
            for (String PDAYZOURHE : XLQXMEQBNP) {
                removeLease(LEMYUIFXQK, PDAYZOURHE);
            }
        }
        return PTRIXZPUIL;
    }

    @Override
    public synchronized String toString() {
        return (((((((getClass().getSimpleName() + "= {") + "\n leases=") + OGTPNXZKVN) + "\n sortedLeases=") + VWPSWAZSYH) + "\n sortedLeasesByPath=") + JJJANFKNZD) + "\n}";
    }

    void startMonitor() {
        Preconditions.checkState(HFWFHOMGQP == null, "Lease Monitor already running");
        XQHADVQJSM = true;
        HFWFHOMGQP = new Daemon(new LeaseManager.Monitor());
        HFWFHOMGQP.start();
    }

    void stopMonitor() {
        if (HFWFHOMGQP != null) {
            XQHADVQJSM = false;
            try {
                HFWFHOMGQP.interrupt();
                HFWFHOMGQP.join(3000);
            } catch (InterruptedException ie) {
                LeaseManager.UKYZZOGVWF.warn("Encountered exception ", ie);
            }
            HFWFHOMGQP = null;
        }
    }

    /**
     * Trigger the currently-running Lease monitor to re-check
     * its leases immediately. This is for use by unit tests.
     */
    @VisibleForTesting
    void triggerMonitorCheckNow() {
        Preconditions.checkState(HFWFHOMGQP != null, "Lease monitor is not running");
        HFWFHOMGQP.interrupt();
    }
}