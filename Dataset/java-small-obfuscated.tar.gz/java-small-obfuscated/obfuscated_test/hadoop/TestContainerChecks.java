/**
 * Tests that WASB creates containers only if needed.
 */
public class TestContainerChecks {
    private AzureBlobStorageTestAccount RGHZQZOGDP;

    @After
    public void tearDown() throws Exception {
        if (RGHZQZOGDP != null) {
            RGHZQZOGDP.cleanup();
            RGHZQZOGDP = null;
        }
    }

    @Test
    public void testContainerExistAfterDoesNotExist() throws Exception {
        RGHZQZOGDP = AzureBlobStorageTestAccount.create("", EnumSet.noneOf(CreateOptions.class));
        assumeNotNull(RGHZQZOGDP);
        CloudBlobContainer XWWVJMSJXZ = RGHZQZOGDP.getRealContainer();
        FileSystem QDYPDVWBLV = RGHZQZOGDP.getFileSystem();
        // Starting off with the container not there
        assertFalse(XWWVJMSJXZ.exists());
        // A list shouldn't create the container and will set file system store
        // state to DoesNotExist
        try {
            QDYPDVWBLV.listStatus(new Path("/"));
            assertTrue("Should've thrown.", false);
        } catch (FileNotFoundException ex) {
            assertTrue("Unexpected exception: " + ex, ex.getMessage().contains("does not exist."));
        }
        assertFalse(XWWVJMSJXZ.exists());
        // Create a container outside of the WASB FileSystem
        XWWVJMSJXZ.create();
        // Add a file to the container outside of the WASB FileSystem
        CloudBlockBlob GRTJDIXYTV = RGHZQZOGDP.getBlobReference("foo");
        BlobOutputStream BAMOMPJIRY = GRTJDIXYTV.openOutputStream();
        BAMOMPJIRY.write(new byte[10]);
        BAMOMPJIRY.close();
        // Make sure the file is visible
        assertTrue(QDYPDVWBLV.exists(new Path("/foo")));
        assertTrue(XWWVJMSJXZ.exists());
    }

    @Test
    public void testContainerCreateAfterDoesNotExist() throws Exception {
        RGHZQZOGDP = AzureBlobStorageTestAccount.create("", EnumSet.noneOf(CreateOptions.class));
        assumeNotNull(RGHZQZOGDP);
        CloudBlobContainer BCXFQKTGQO = RGHZQZOGDP.getRealContainer();
        FileSystem JBIUTYXKOD = RGHZQZOGDP.getFileSystem();
        // Starting off with the container not there
        assertFalse(BCXFQKTGQO.exists());
        // A list shouldn't create the container and will set file system store
        // state to DoesNotExist
        try {
            assertNull(JBIUTYXKOD.listStatus(new Path("/")));
            assertTrue("Should've thrown.", false);
        } catch (FileNotFoundException ex) {
            assertTrue("Unexpected exception: " + ex, ex.getMessage().contains("does not exist."));
        }
        assertFalse(BCXFQKTGQO.exists());
        // Create a container outside of the WASB FileSystem
        BCXFQKTGQO.create();
        // Write should succeed
        assertTrue(JBIUTYXKOD.createNewFile(new Path("/foo")));
        assertTrue(BCXFQKTGQO.exists());
    }

    @Test
    public void testContainerCreateOnWrite() throws Exception {
        RGHZQZOGDP = AzureBlobStorageTestAccount.create("", EnumSet.noneOf(CreateOptions.class));
        assumeNotNull(RGHZQZOGDP);
        CloudBlobContainer FLVQEIIYKG = RGHZQZOGDP.getRealContainer();
        FileSystem ETVFYCKKST = RGHZQZOGDP.getFileSystem();
        // Starting off with the container not there
        assertFalse(FLVQEIIYKG.exists());
        // A list shouldn't create the container.
        try {
            ETVFYCKKST.listStatus(new Path("/"));
            assertTrue("Should've thrown.", false);
        } catch (FileNotFoundException ex) {
            assertTrue("Unexpected exception: " + ex, ex.getMessage().contains("does not exist."));
        }
        assertFalse(FLVQEIIYKG.exists());
        // Neither should a read.
        try {
            ETVFYCKKST.open(new Path("/foo"));
            assertFalse("Should've thrown.", true);
        } catch (FileNotFoundException ex) {
        }
        assertFalse(FLVQEIIYKG.exists());
        // Neither should a rename
        assertFalse(ETVFYCKKST.rename(new Path("/foo"), new Path("/bar")));
        assertFalse(FLVQEIIYKG.exists());
        // But a write should.
        assertTrue(ETVFYCKKST.createNewFile(new Path("/foo")));
        assertTrue(FLVQEIIYKG.exists());
    }

    @Test
    public void testContainerChecksWithSas() throws Exception {
        RGHZQZOGDP = AzureBlobStorageTestAccount.create("", EnumSet.of(UseSas));
        assumeNotNull(RGHZQZOGDP);
        CloudBlobContainer YIQBMJXYQD = RGHZQZOGDP.getRealContainer();
        FileSystem IHOFIWDCVT = RGHZQZOGDP.getFileSystem();
        // The container shouldn't be there
        assertFalse(YIQBMJXYQD.exists());
        // A write should just fail
        try {
            IHOFIWDCVT.createNewFile(new Path("/foo"));
            assertFalse("Should've thrown.", true);
        } catch (AzureException ex) {
        }
        assertFalse(YIQBMJXYQD.exists());
    }
}