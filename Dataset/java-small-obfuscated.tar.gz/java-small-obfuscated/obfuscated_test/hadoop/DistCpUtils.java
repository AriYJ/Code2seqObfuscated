/**
 * Utility functions used in DistCp.
 */
public class DistCpUtils {
    private static final Log WUQQJDNEVP = LogFactory.getLog(DistCpUtils.class);

    /**
     * Retrieves size of the file at the specified path.
     *
     * @param path
     * 		The path of the file whose size is sought.
     * @param configuration
     * 		Configuration, to retrieve the appropriate FileSystem.
     * @return The file-size, in number of bytes.
     * @throws IOException,
     * 		on failure.
     */
    public static long getFileSize(Path RYSPWEFNIS, Configuration MYNRKDHZMD) throws IOException {
        if (DistCpUtils.WUQQJDNEVP.isDebugEnabled())
            DistCpUtils.WUQQJDNEVP.debug("Retrieving file size for: " + RYSPWEFNIS);

        return RYSPWEFNIS.getFileSystem(MYNRKDHZMD).getFileStatus(RYSPWEFNIS).getLen();
    }

    /**
     * Utility to publish a value to a configuration.
     *
     * @param configuration
     * 		The Configuration to which the value must be written.
     * @param label
     * 		The label for the value being published.
     * @param value
     * 		The value being published.
     * @param <T>
     * 		The type of the value.
     */
    public static <T> void publish(Configuration GIKTSOIASX, String QHXOBZUGMY, T EBVJHRABDL) {
        GIKTSOIASX.set(QHXOBZUGMY, String.valueOf(EBVJHRABDL));
    }

    /**
     * Utility to retrieve a specified key from a Configuration. Throw exception
     * if not found.
     *
     * @param configuration
     * 		The Configuration in which the key is sought.
     * @param label
     * 		The key being sought.
     * @return Integer value of the key.
     */
    public static int getInt(Configuration ESDXYSNSLK, String NWJJHGSUJD) {
        int RJNPRJBFNS = ESDXYSNSLK.getInt(NWJJHGSUJD, -1);
        assert RJNPRJBFNS >= 0 : "Couldn't find " + NWJJHGSUJD;
        return RJNPRJBFNS;
    }

    /**
     * Utility to retrieve a specified key from a Configuration. Throw exception
     * if not found.
     *
     * @param configuration
     * 		The Configuration in which the key is sought.
     * @param label
     * 		The key being sought.
     * @return Long value of the key.
     */
    public static long getLong(Configuration DPMJQADWSH, String OPMAZKJFYP) {
        long INROJYHRYJ = DPMJQADWSH.getLong(OPMAZKJFYP, -1);
        assert INROJYHRYJ >= 0 : "Couldn't find " + OPMAZKJFYP;
        return INROJYHRYJ;
    }

    /**
     * Returns the class that implements a copy strategy. Looks up the implementation for
     * a particular strategy from distcp-default.xml
     *
     * @param conf
     * 		- Configuration object
     * @param options
     * 		- Handle to input options
     * @return Class implementing the strategy specified in options.
     */
    public static Class<? extends InputFormat> getStrategy(Configuration IEYFWRJBLH, DistCpOptions CEKNMCJFYE) {
        String VUQHZNDZGB = ("distcp." + CEKNMCJFYE.getCopyStrategy().toLowerCase(Locale.getDefault())) + ".strategy.impl";
        return IEYFWRJBLH.getClass(VUQHZNDZGB, UniformSizeInputFormat.class, InputFormat.class);
    }

    /**
     * Gets relative path of child path with respect to a root path
     * For ex. If childPath = /tmp/abc/xyz/file and
     *            sourceRootPath = /tmp/abc
     * Relative path would be /xyz/file
     *         If childPath = /file and
     *            sourceRootPath = /
     * Relative path would be /file
     *
     * @param sourceRootPath
     * 		- Source root path
     * @param childPath
     * 		- Path for which relative path is required
     * @return - Relative portion of the child path (always prefixed with /
    unless it is empty
     */
    public static String getRelativePath(Path ECXNZUCVZJ, Path OJEEAIXSZL) {
        String UFSSAUCSBN = OJEEAIXSZL.toUri().getPath();
        String DAIBEIAQSW = ECXNZUCVZJ.toUri().getPath();
        return DAIBEIAQSW.equals("/") ? UFSSAUCSBN : UFSSAUCSBN.substring(DAIBEIAQSW.length());
    }

    /**
     * Pack file preservation attributes into a string, containing
     * just the first character of each preservation attribute
     *
     * @param attributes
     * 		- Attribute set to preserve
     * @return - String containing first letters of each attribute to preserve
     */
    public static String packAttributes(EnumSet<FileAttribute> RIXZLXCGXQ) {
        StringBuffer NYQZIUJIZX = new StringBuffer(FileAttribute.values().length);
        int GFMOITVQUB = 0;
        for (FileAttribute UZYIBBEKRG : RIXZLXCGXQ) {
            NYQZIUJIZX.append(UZYIBBEKRG.name().charAt(0));
            GFMOITVQUB++;
        }
        return NYQZIUJIZX.substring(0, GFMOITVQUB);
    }

    /**
     * Un packs preservation attribute string containing the first character of
     * each preservation attribute back to a set of attributes to preserve
     *
     * @param attributes
     * 		- Attribute string
     * @return - Attribute set
     */
    public static EnumSet<FileAttribute> unpackAttributes(String LBHRANVCKW) {
        EnumSet<FileAttribute> LELGFKSEHS = EnumSet.noneOf(FileAttribute.class);
        if (LBHRANVCKW != null) {
            for (int EXTCKORDQB = 0; EXTCKORDQB < LBHRANVCKW.length(); EXTCKORDQB++) {
                LELGFKSEHS.add(FileAttribute.getAttribute(LBHRANVCKW.charAt(EXTCKORDQB)));
            }
        }
        return LELGFKSEHS;
    }

    /**
     * Preserve attribute on file matching that of the file status being sent
     * as argument. Barring the block size, all the other attributes are preserved
     * by this function
     *
     * @param targetFS
     * 		- File system
     * @param path
     * 		- Path that needs to preserve original file status
     * @param srcFileStatus
     * 		- Original file status
     * @param attributes
     * 		- Attribute set that needs to be preserved
     * @param preserveRawXattrs
     * 		if true, raw.* xattrs should be preserved
     * @throws IOException
     * 		- Exception if any (particularly relating to group/owner
     * 		change or any transient error)
     */
    public static void preserve(FileSystem GZLLOTVTCF, Path WZIXKQDMJD, CopyListingFileStatus IPGUCPLKDR, EnumSet<FileAttribute> KRDFRDIZPD, boolean INRUCJRBPK) throws IOException {
        FileStatus CKTTHAPXRI = GZLLOTVTCF.getFileStatus(WZIXKQDMJD);
        String HXHIBNMNGE = CKTTHAPXRI.getGroup();
        String EXOEYFIVNR = CKTTHAPXRI.getOwner();
        boolean JIPRDJGOTU = false;
        if (KRDFRDIZPD.contains(ACL)) {
            List<AclEntry> CLZYICZGHQ = IPGUCPLKDR.getAclEntries();
            List<AclEntry> ABJVERSLLZ = DistCpUtils.getAcl(GZLLOTVTCF, CKTTHAPXRI);
            if (!CLZYICZGHQ.equals(ABJVERSLLZ)) {
                GZLLOTVTCF.setAcl(WZIXKQDMJD, CLZYICZGHQ);
            }
            // setAcl can't preserve sticky bit, so also call setPermission if needed.
            if (IPGUCPLKDR.getPermission().getStickyBit() != CKTTHAPXRI.getPermission().getStickyBit()) {
                GZLLOTVTCF.setPermission(WZIXKQDMJD, IPGUCPLKDR.getPermission());
            }
        } else
            if (KRDFRDIZPD.contains(PERMISSION) && (!IPGUCPLKDR.getPermission().equals(CKTTHAPXRI.getPermission()))) {
                GZLLOTVTCF.setPermission(WZIXKQDMJD, IPGUCPLKDR.getPermission());
            }

        final boolean KXJXOYXLEW = KRDFRDIZPD.contains(XATTR);
        if (KXJXOYXLEW || INRUCJRBPK) {
            final String EVPPWQISBX = XAttr.NameSpace.RAW.name().toLowerCase();
            Map<String, byte[]> VFSZGFVUEM = IPGUCPLKDR.getXAttrs();
            Map<String, byte[]> YGJXGBTDNY = DistCpUtils.getXAttrs(GZLLOTVTCF, WZIXKQDMJD);
            if ((VFSZGFVUEM != null) && (!VFSZGFVUEM.equals(YGJXGBTDNY))) {
                Iterator<Map.Entry<String, byte[]>> JKTBEYRZQK = VFSZGFVUEM.entrySet().iterator();
                while (JKTBEYRZQK.hasNext()) {
                    Map.Entry<String, byte[]> DKWWFTRKQR = JKTBEYRZQK.next();
                    final String RWZAOCGAFL = DKWWFTRKQR.getKey();
                    if (RWZAOCGAFL.startsWith(EVPPWQISBX) || KXJXOYXLEW) {
                        GZLLOTVTCF.setXAttr(WZIXKQDMJD, DKWWFTRKQR.getKey(), DKWWFTRKQR.getValue());
                    }
                } 
            }
        }
        if ((KRDFRDIZPD.contains(REPLICATION) && (!CKTTHAPXRI.isDirectory())) && (IPGUCPLKDR.getReplication() != CKTTHAPXRI.getReplication())) {
            GZLLOTVTCF.setReplication(WZIXKQDMJD, IPGUCPLKDR.getReplication());
        }
        if (KRDFRDIZPD.contains(GROUP) && (!HXHIBNMNGE.equals(IPGUCPLKDR.getGroup()))) {
            HXHIBNMNGE = IPGUCPLKDR.getGroup();
            JIPRDJGOTU = true;
        }
        if (KRDFRDIZPD.contains(USER) && (!EXOEYFIVNR.equals(IPGUCPLKDR.getOwner()))) {
            EXOEYFIVNR = IPGUCPLKDR.getOwner();
            JIPRDJGOTU = true;
        }
        if (JIPRDJGOTU) {
            GZLLOTVTCF.setOwner(WZIXKQDMJD, EXOEYFIVNR, HXHIBNMNGE);
        }
    }

    /**
     * Returns a file's full logical ACL.
     *
     * @param fileSystem
     * 		FileSystem containing the file
     * @param fileStatus
     * 		FileStatus of file
     * @return List<AclEntry> containing full logical ACL
     * @throws IOException
     * 		if there is an I/O error
     */
    public static List<AclEntry> getAcl(FileSystem VFDLIMQEGN, FileStatus IRRGASCYRB) throws IOException {
        List<AclEntry> OBZZMLRPGV = VFDLIMQEGN.getAclStatus(IRRGASCYRB.getPath()).getEntries();
        return AclUtil.getAclFromPermAndEntries(IRRGASCYRB.getPermission(), OBZZMLRPGV);
    }

    /**
     * Returns a file's all xAttrs.
     *
     * @param fileSystem
     * 		FileSystem containing the file
     * @param path
     * 		file path
     * @return Map<String, byte[]> containing all xAttrs
     * @throws IOException
     * 		if there is an I/O error
     */
    public static Map<String, byte[]> getXAttrs(FileSystem WLEAOUOFPM, Path UKLVDLROWV) throws IOException {
        return WLEAOUOFPM.getXAttrs(UKLVDLROWV);
    }

    /**
     * Converts a FileStatus to a CopyListingFileStatus.  If preserving ACLs,
     * populates the CopyListingFileStatus with the ACLs. If preserving XAttrs,
     * populates the CopyListingFileStatus with the XAttrs.
     *
     * @param fileSystem
     * 		FileSystem containing the file
     * @param fileStatus
     * 		FileStatus of file
     * @param preserveAcls
     * 		boolean true if preserving ACLs
     * @param preserveXAttrs
     * 		boolean true if preserving XAttrs
     * @param preserveRawXAttrs
     * 		boolean true if preserving raw.* XAttrs
     * @throws IOException
     * 		if there is an I/O error
     */
    public static CopyListingFileStatus toCopyListingFileStatus(FileSystem BNQYPJDQMV, FileStatus BQEBYRKQTB, boolean WZJCYNTKXY, boolean YERVVDKHGB, boolean EYUMXVHYWC) throws IOException {
        CopyListingFileStatus BAQXONURCR = new CopyListingFileStatus(BQEBYRKQTB);
        if (WZJCYNTKXY) {
            FsPermission QYUFDMWUCD = BQEBYRKQTB.getPermission();
            if (QYUFDMWUCD.getAclBit()) {
                List<AclEntry> ALEHQWRYQC = BNQYPJDQMV.getAclStatus(BQEBYRKQTB.getPath()).getEntries();
                BAQXONURCR.setAclEntries(ALEHQWRYQC);
            }
        }
        if (YERVVDKHGB || EYUMXVHYWC) {
            Map<String, byte[]> GWQQZCHFTR = BNQYPJDQMV.getXAttrs(BQEBYRKQTB.getPath());
            if (YERVVDKHGB && EYUMXVHYWC) {
                BAQXONURCR.setXAttrs(GWQQZCHFTR);
            } else {
                Map<String, byte[]> GTPULKUTCG = Maps.newHashMap();
                final String SGEEDQZLSJ = XAttr.NameSpace.RAW.name().toLowerCase();
                for (Map.Entry<String, byte[]> AUGDJCJMDZ : GWQQZCHFTR.entrySet()) {
                    final String MOMZZYHKCR = AUGDJCJMDZ.getKey();
                    if (MOMZZYHKCR.startsWith(SGEEDQZLSJ)) {
                        if (EYUMXVHYWC) {
                            GTPULKUTCG.put(MOMZZYHKCR, AUGDJCJMDZ.getValue());
                        }
                    } else
                        if (YERVVDKHGB) {
                            GTPULKUTCG.put(MOMZZYHKCR, AUGDJCJMDZ.getValue());
                        }

                }
                BAQXONURCR.setXAttrs(GTPULKUTCG);
            }
        }
        return BAQXONURCR;
    }

    /**
     * Sort sequence file containing FileStatus and Text as key and value respecitvely
     *
     * @param fs
     * 		- File System
     * @param conf
     * 		- Configuration
     * @param sourceListing
     * 		- Source listing file
     * @return Path of the sorted file. Is source file with _sorted appended to the name
     * @throws IOException
     * 		- Any exception during sort.
     */
    public static Path sortListing(FileSystem SGLVGHWJXK, Configuration DTYRQWCBVV, Path OOJYBGHGZO) throws IOException {
        SequenceFile.Sorter SORVCKQCMW = new SequenceFile.Sorter(SGLVGHWJXK, Text.class, CopyListingFileStatus.class, DTYRQWCBVV);
        Path GKZXKSDIBF = new Path(OOJYBGHGZO.toString() + "_sorted");
        if (SGLVGHWJXK.exists(GKZXKSDIBF)) {
            SGLVGHWJXK.delete(GKZXKSDIBF, false);
        }
        SORVCKQCMW.sort(OOJYBGHGZO, GKZXKSDIBF);
        return GKZXKSDIBF;
    }

    /**
     * Determines if a file system supports ACLs by running a canary getAclStatus
     * request on the file system root.  This method is used before distcp job
     * submission to fail fast if the user requested preserving ACLs, but the file
     * system cannot support ACLs.
     *
     * @param fs
     * 		FileSystem to check
     * @throws AclsNotSupportedException
     * 		if fs does not support ACLs
     */
    public static void checkFileSystemAclSupport(FileSystem MZELNVJTOD) throws AclsNotSupportedException {
        try {
            MZELNVJTOD.getAclStatus(new Path(Path.SEPARATOR));
        } catch (Exception e) {
            throw new AclsNotSupportedException("ACLs not supported for file system: " + MZELNVJTOD.getUri());
        }
    }

    /**
     * Determines if a file system supports XAttrs by running a getXAttrs request
     * on the file system root. This method is used before distcp job submission
     * to fail fast if the user requested preserving XAttrs, but the file system
     * cannot support XAttrs.
     *
     * @param fs
     * 		FileSystem to check
     * @throws XAttrsNotSupportedException
     * 		if fs does not support XAttrs
     */
    public static void checkFileSystemXAttrSupport(FileSystem KVNKTHIQYL) throws XAttrsNotSupportedException {
        try {
            KVNKTHIQYL.getXAttrs(new Path(Path.SEPARATOR));
        } catch (Exception e) {
            throw new XAttrsNotSupportedException("XAttrs not supported for file system: " + KVNKTHIQYL.getUri());
        }
    }

    /**
     * String utility to convert a number-of-bytes to human readable format.
     */
    private static ThreadLocal<DecimalFormat> KMGSFOVVOT = new ThreadLocal<DecimalFormat>() {
        @Override
        protected DecimalFormat initialValue() {
            return new DecimalFormat("0.0");
        }
    };

    public static DecimalFormat getFormatter() {
        return DistCpUtils.KMGSFOVVOT.get();
    }

    public static String getStringDescriptionFor(long TBPDXCSUER) {
        char[] ENUCHVTHMA = new char[]{ 'B', 'K', 'M', 'G', 'T', 'P' };
        double MZGFZTSVJL = TBPDXCSUER;
        double RMTDIJMSFS = MZGFZTSVJL;
        int DBXGEKJNKC = 0;
        while ((MZGFZTSVJL = MZGFZTSVJL / 1024) >= 1) {
            RMTDIJMSFS = MZGFZTSVJL;
            ++DBXGEKJNKC;
        } 
        assert DBXGEKJNKC < ENUCHVTHMA.length : "Too large a number.";
        return DistCpUtils.getFormatter().format(RMTDIJMSFS) + ENUCHVTHMA[DBXGEKJNKC];
    }

    /**
     * Utility to compare checksums for the paths specified.
     *
     * If checksums's can't be retrieved, it doesn't fail the test
     * Only time the comparison would fail is when checksums are
     * available and they don't match
     *
     * @param sourceFS
     * 		FileSystem for the source path.
     * @param source
     * 		The source path.
     * @param sourceChecksum
     * 		The checksum of the source file. If it is null we
     * 		still need to retrieve it through sourceFS.
     * @param targetFS
     * 		FileSystem for the target path.
     * @param target
     * 		The target path.
     * @return If either checksum couldn't be retrieved, the function returns
    false. If checksums are retrieved, the function returns true if they match,
    and false otherwise.
     * @throws IOException
     * 		if there's an exception while retrieving checksums.
     */
    public static boolean checksumsAreEqual(FileSystem GMGXLHSERW, Path INUFUUWUPB, FileChecksum HHJNVIEHRB, FileSystem VJIFAZORWF, Path LKKTFMZWFK) throws IOException {
        FileChecksum WXWFDPXLEJ = null;
        try {
            HHJNVIEHRB = (HHJNVIEHRB != null) ? HHJNVIEHRB : GMGXLHSERW.getFileChecksum(INUFUUWUPB);
            WXWFDPXLEJ = VJIFAZORWF.getFileChecksum(LKKTFMZWFK);
        } catch (IOException e) {
            DistCpUtils.WUQQJDNEVP.error((("Unable to retrieve checksum for " + INUFUUWUPB) + " or ") + LKKTFMZWFK, e);
        }
        return ((HHJNVIEHRB == null) || (WXWFDPXLEJ == null)) || HHJNVIEHRB.equals(WXWFDPXLEJ);
    }

    /* see if two file systems are the same or not */
    public static boolean compareFs(FileSystem XSNRISGWFL, FileSystem LSOIFTSJOQ) {
        URI WUVCZKYYRI = XSNRISGWFL.getUri();
        URI WTCHPHEQPD = LSOIFTSJOQ.getUri();
        if (WUVCZKYYRI.getScheme() == null) {
            return false;
        }
        if (!WUVCZKYYRI.getScheme().equals(WTCHPHEQPD.getScheme())) {
            return false;
        }
        String JUPSLWDBBK = WUVCZKYYRI.getHost();
        String FRCJANXGXN = WTCHPHEQPD.getHost();
        if ((JUPSLWDBBK != null) && (FRCJANXGXN != null)) {
            try {
                JUPSLWDBBK = InetAddress.getByName(JUPSLWDBBK).getCanonicalHostName();
                FRCJANXGXN = InetAddress.getByName(FRCJANXGXN).getCanonicalHostName();
            } catch (UnknownHostException ue) {
                if (DistCpUtils.WUQQJDNEVP.isDebugEnabled())
                    DistCpUtils.WUQQJDNEVP.debug("Could not compare file-systems. Unknown host: ", ue);

                return false;
            }
            if (!JUPSLWDBBK.equals(FRCJANXGXN)) {
                return false;
            }
        } else
            if ((JUPSLWDBBK == null) && (FRCJANXGXN != null)) {
                return false;
            } else
                if (JUPSLWDBBK != null) {
                    return false;
                }


        // check for ports
        return WUVCZKYYRI.getPort() == WTCHPHEQPD.getPort();
    }
}