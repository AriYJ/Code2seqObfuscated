public class TestContainerResourceIncrease {
    @Test
    public void testResourceIncreaseContext() {
        byte[] SMVSGJLCRA = new byte[]{ 1, 2, 3, 4 };
        Token VQQVDMQTDO = Token.newInstance(SMVSGJLCRA, "", "".getBytes(), "");
        ContainerId SWGLPDRDTP = ContainerId.newInstance(ApplicationAttemptId.newInstance(ApplicationId.newInstance(1234, 3), 3), 7);
        Resource XTDHDTATFS = Resource.newInstance(1023, 3);
        ContainerResourceIncrease OXQVWAHSEX = ContainerResourceIncrease.newInstance(SWGLPDRDTP, XTDHDTATFS, VQQVDMQTDO);
        // get proto and recover to ctx
        ContainerResourceIncreaseProto JYMHIWXNWP = ((org.apache.hadoop.yarn.api.records.impl.pb.ContainerResourceIncreasePBImpl) (OXQVWAHSEX)).getProto();
        OXQVWAHSEX = new org.apache.hadoop.yarn.api.records.impl.pb.ContainerResourceIncreasePBImpl(JYMHIWXNWP);
        // check values
        Assert.assertEquals(OXQVWAHSEX.getCapability(), XTDHDTATFS);
        Assert.assertEquals(OXQVWAHSEX.getContainerId(), SWGLPDRDTP);
        Assert.assertTrue(Arrays.equals(OXQVWAHSEX.getContainerToken().getIdentifier().array(), SMVSGJLCRA));
    }

    @Test
    public void testResourceIncreaseContextWithNull() {
        ContainerResourceIncrease JVHCPKYUEQ = ContainerResourceIncrease.newInstance(null, null, null);
        // get proto and recover to ctx;
        ContainerResourceIncreaseProto WLYLZGJAWE = ((org.apache.hadoop.yarn.api.records.impl.pb.ContainerResourceIncreasePBImpl) (JVHCPKYUEQ)).getProto();
        JVHCPKYUEQ = new org.apache.hadoop.yarn.api.records.impl.pb.ContainerResourceIncreasePBImpl(WLYLZGJAWE);
        // check values
        Assert.assertNull(JVHCPKYUEQ.getContainerToken());
        Assert.assertNull(JVHCPKYUEQ.getCapability());
        Assert.assertNull(JVHCPKYUEQ.getContainerId());
    }
}