/**
 * The state machine for the representation of an Application
 * within the NodeManager.
 */
public class ApplicationImpl implements Application {
    final Dispatcher JOONLDIZMV;

    final String CQULTHQWHL;

    final ApplicationId JLSQTXKKFL;

    final Credentials SMSDFAVTZY;

    Map<ApplicationAccessType, String> FIGLUCSDPJ;

    final ApplicationACLsManager HUVOFCRTZT;

    private final ReentrantReadWriteLock.ReadLock EDFZDAQMXQ;

    private final ReentrantReadWriteLock.WriteLock VPXSFMMSMH;

    private final Context THDCQFEKBB;

    private static final Log SOYBKODAYG = LogFactory.getLog(Application.class);

    Map<ContainerId, Container> LDESHCMEWJ = new HashMap<ContainerId, Container>();

    public ApplicationImpl(Dispatcher FBHMGVFMAP, String YQVANHYDTL, ApplicationId TJMZZXAHQW, Credentials FQLORRXRDO, Context SUWXXPRDXV) {
        this.JOONLDIZMV = FBHMGVFMAP;
        this.CQULTHQWHL = YQVANHYDTL;
        this.JLSQTXKKFL = TJMZZXAHQW;
        this.SMSDFAVTZY = FQLORRXRDO;
        this.HUVOFCRTZT = SUWXXPRDXV.getApplicationACLsManager();
        this.THDCQFEKBB = SUWXXPRDXV;
        ReentrantReadWriteLock KBSQJHTPBY = new ReentrantReadWriteLock();
        EDFZDAQMXQ = KBSQJHTPBY.readLock();
        VPXSFMMSMH = KBSQJHTPBY.writeLock();
        UILCCHEHHH = ApplicationImpl.BMLSLWAFIH.make(this);
    }

    @Override
    public String getUser() {
        return CQULTHQWHL.toString();
    }

    @Override
    public ApplicationId getAppId() {
        return JLSQTXKKFL;
    }

    @Override
    public ApplicationState getApplicationState() {
        this.EDFZDAQMXQ.lock();
        try {
            return this.UILCCHEHHH.getCurrentState();
        } finally {
            this.EDFZDAQMXQ.unlock();
        }
    }

    @Override
    public Map<ContainerId, Container> getContainers() {
        this.EDFZDAQMXQ.lock();
        try {
            return this.LDESHCMEWJ;
        } finally {
            this.EDFZDAQMXQ.unlock();
        }
    }

    private static final ApplicationImpl.ContainerDoneTransition IAJQFRZUDO = new ApplicationImpl.ContainerDoneTransition();

    private static StateMachineFactory<ApplicationImpl, ApplicationState, ApplicationEventType, ApplicationEvent> BMLSLWAFIH = // create the topology tables
    // Transitions from FINISHED state
    // Transitions from APPLICATION_RESOURCES_CLEANINGUP state
    // Transitions from FINISHING_CONTAINERS_WAIT state.
    // Transitions from RUNNING state
    // Transitions from INITING state
    // Transitions from NEW state
    new StateMachineFactory<ApplicationImpl, ApplicationState, ApplicationEventType, ApplicationEvent>(ApplicationState.NEW).addTransition(ApplicationState.NEW, ApplicationState.INITING, ApplicationEventType.INIT_APPLICATION, new ApplicationImpl.AppInitTransition()).addTransition(ApplicationState.NEW, ApplicationState.NEW, ApplicationEventType.INIT_CONTAINER, new ApplicationImpl.InitContainerTransition()).addTransition(ApplicationState.INITING, ApplicationState.INITING, ApplicationEventType.INIT_CONTAINER, new ApplicationImpl.InitContainerTransition()).addTransition(ApplicationState.INITING, java.util.EnumSet.of(ApplicationState.FINISHING_CONTAINERS_WAIT, ApplicationState.APPLICATION_RESOURCES_CLEANINGUP), ApplicationEventType.FINISH_APPLICATION, new ApplicationImpl.AppFinishTriggeredTransition()).addTransition(ApplicationState.INITING, ApplicationState.INITING, ApplicationEventType.APPLICATION_CONTAINER_FINISHED, ApplicationImpl.IAJQFRZUDO).addTransition(ApplicationState.INITING, ApplicationState.INITING, ApplicationEventType.APPLICATION_LOG_HANDLING_INITED, new ApplicationImpl.AppLogInitDoneTransition()).addTransition(ApplicationState.INITING, ApplicationState.INITING, ApplicationEventType.APPLICATION_LOG_HANDLING_FAILED, new ApplicationImpl.AppLogInitFailTransition()).addTransition(ApplicationState.INITING, ApplicationState.RUNNING, ApplicationEventType.APPLICATION_INITED, new ApplicationImpl.AppInitDoneTransition()).addTransition(ApplicationState.RUNNING, ApplicationState.RUNNING, ApplicationEventType.INIT_CONTAINER, new ApplicationImpl.InitContainerTransition()).addTransition(ApplicationState.RUNNING, ApplicationState.RUNNING, ApplicationEventType.APPLICATION_CONTAINER_FINISHED, ApplicationImpl.IAJQFRZUDO).addTransition(ApplicationState.RUNNING, java.util.EnumSet.of(ApplicationState.FINISHING_CONTAINERS_WAIT, ApplicationState.APPLICATION_RESOURCES_CLEANINGUP), ApplicationEventType.FINISH_APPLICATION, new ApplicationImpl.AppFinishTriggeredTransition()).addTransition(ApplicationState.FINISHING_CONTAINERS_WAIT, java.util.EnumSet.of(ApplicationState.FINISHING_CONTAINERS_WAIT, ApplicationState.APPLICATION_RESOURCES_CLEANINGUP), ApplicationEventType.APPLICATION_CONTAINER_FINISHED, new ApplicationImpl.AppFinishTransition()).addTransition(ApplicationState.FINISHING_CONTAINERS_WAIT, ApplicationState.FINISHING_CONTAINERS_WAIT, java.util.EnumSet.of(ApplicationEventType.APPLICATION_LOG_HANDLING_INITED, ApplicationEventType.APPLICATION_LOG_HANDLING_FAILED, ApplicationEventType.APPLICATION_INITED, ApplicationEventType.FINISH_APPLICATION)).addTransition(ApplicationState.APPLICATION_RESOURCES_CLEANINGUP, ApplicationState.APPLICATION_RESOURCES_CLEANINGUP, ApplicationEventType.APPLICATION_CONTAINER_FINISHED).addTransition(ApplicationState.APPLICATION_RESOURCES_CLEANINGUP, ApplicationState.FINISHED, ApplicationEventType.APPLICATION_RESOURCES_CLEANEDUP, new ApplicationImpl.AppCompletelyDoneTransition()).addTransition(ApplicationState.APPLICATION_RESOURCES_CLEANINGUP, ApplicationState.APPLICATION_RESOURCES_CLEANINGUP, java.util.EnumSet.of(ApplicationEventType.APPLICATION_LOG_HANDLING_INITED, ApplicationEventType.APPLICATION_LOG_HANDLING_FAILED, ApplicationEventType.APPLICATION_LOG_HANDLING_FINISHED, ApplicationEventType.APPLICATION_INITED, ApplicationEventType.FINISH_APPLICATION)).addTransition(ApplicationState.FINISHED, ApplicationState.FINISHED, ApplicationEventType.APPLICATION_LOG_HANDLING_FINISHED, new ApplicationImpl.AppLogsAggregatedTransition()).addTransition(ApplicationState.FINISHED, ApplicationState.FINISHED, java.util.EnumSet.of(ApplicationEventType.APPLICATION_LOG_HANDLING_INITED, ApplicationEventType.APPLICATION_LOG_HANDLING_FAILED, ApplicationEventType.FINISH_APPLICATION)).installTopology();

    private final StateMachine<ApplicationState, ApplicationEventType, ApplicationEvent> UILCCHEHHH;

    /**
     * Notify services of new application.
     *
     * In particular, this initializes the {@link LogAggregationService}
     */
    @SuppressWarnings("unchecked")
    static class AppInitTransition implements SingleArcTransition<ApplicationImpl, ApplicationEvent> {
        @Override
        public void transition(ApplicationImpl app, ApplicationEvent event) {
            ApplicationInitEvent initEvent = ((ApplicationInitEvent) (event));
            app.FIGLUCSDPJ = initEvent.getApplicationACLs();
            app.HUVOFCRTZT.addApplication(app.getAppId(), app.FIGLUCSDPJ);
            // Inform the logAggregator
            app.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.loghandler.event.LogHandlerAppStartedEvent(app.JLSQTXKKFL, app.CQULTHQWHL, app.SMSDFAVTZY, ContainerLogsRetentionPolicy.ALL_CONTAINERS, app.FIGLUCSDPJ));
        }
    }

    /**
     * Handles the APPLICATION_LOG_HANDLING_INITED event that occurs after
     * {@link LogAggregationService} has created the directories for the app
     * and started the aggregation thread for the app.
     *
     * In particular, this requests that the {@link ResourceLocalizationService}
     * localize the application-scoped resources.
     */
    @SuppressWarnings("unchecked")
    static class AppLogInitDoneTransition implements SingleArcTransition<ApplicationImpl, ApplicationEvent> {
        @Override
        public void transition(ApplicationImpl app, ApplicationEvent event) {
            app.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.event.ApplicationLocalizationEvent(LocalizationEventType.INIT_APPLICATION_RESOURCES, app));
        }
    }

    /**
     * Handles the APPLICATION_LOG_HANDLING_FAILED event that occurs after
     * {@link LogAggregationService} has failed to initialize the log
     * aggregation service
     *
     * In particular, this requests that the {@link ResourceLocalizationService}
     * localize the application-scoped resources.
     */
    @SuppressWarnings("unchecked")
    static class AppLogInitFailTransition implements SingleArcTransition<ApplicationImpl, ApplicationEvent> {
        @Override
        public void transition(ApplicationImpl app, ApplicationEvent event) {
            ApplicationImpl.SOYBKODAYG.warn("Log Aggregation service failed to initialize, there will " + "be no logs for this application");
            app.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.event.ApplicationLocalizationEvent(LocalizationEventType.INIT_APPLICATION_RESOURCES, app));
        }
    }

    /**
     * Handles INIT_CONTAINER events which request that we launch a new
     * container. When we're still in the INITTING state, we simply
     * queue these up. When we're in the RUNNING state, we pass along
     * an ContainerInitEvent to the appropriate ContainerImpl.
     */
    @SuppressWarnings("unchecked")
    static class InitContainerTransition implements SingleArcTransition<ApplicationImpl, ApplicationEvent> {
        @Override
        public void transition(ApplicationImpl app, ApplicationEvent event) {
            ApplicationContainerInitEvent initEvent = ((ApplicationContainerInitEvent) (event));
            Container container = initEvent.getContainer();
            app.LDESHCMEWJ.put(container.getContainerId(), container);
            ApplicationImpl.SOYBKODAYG.info((("Adding " + container.getContainerId()) + " to application ") + app.toString());
            switch (app.getApplicationState()) {
                case RUNNING :
                    app.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerInitEvent(container.getContainerId()));
                    break;
                case INITING :
                case NEW :
                    // these get queued up and sent out in AppInitDoneTransition
                    break;
                default :
                    assert false : "Invalid state for InitContainerTransition: " + app.getApplicationState();
            }
        }
    }

    @SuppressWarnings("unchecked")
    static class AppInitDoneTransition implements SingleArcTransition<ApplicationImpl, ApplicationEvent> {
        @Override
        public void transition(ApplicationImpl app, ApplicationEvent event) {
            // Start all the containers waiting for ApplicationInit
            for (Container container : app.LDESHCMEWJ.values()) {
                app.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerInitEvent(container.getContainerId()));
            }
        }
    }

    static final class ContainerDoneTransition implements SingleArcTransition<ApplicationImpl, ApplicationEvent> {
        @Override
        public void transition(ApplicationImpl app, ApplicationEvent event) {
            ApplicationContainerFinishedEvent containerEvent = ((ApplicationContainerFinishedEvent) (event));
            if (null == app.LDESHCMEWJ.remove(containerEvent.getContainerID())) {
                ApplicationImpl.SOYBKODAYG.warn((("Removing unknown " + containerEvent.getContainerID()) + " from application ") + app.toString());
            } else {
                ApplicationImpl.SOYBKODAYG.info((("Removing " + containerEvent.getContainerID()) + " from application ") + app.toString());
            }
        }
    }

    @SuppressWarnings("unchecked")
    void handleAppFinishWithContainersCleanedup() {
        // Delete Application level resources
        this.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.event.ApplicationLocalizationEvent(LocalizationEventType.DESTROY_APPLICATION_RESOURCES, this));
        // tell any auxiliary services that the app is done
        this.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.AuxServicesEvent(AuxServicesEventType.APPLICATION_STOP, JLSQTXKKFL));
        // TODO: Trigger the LogsManager
    }

    @SuppressWarnings("unchecked")
    static class AppFinishTriggeredTransition implements MultipleArcTransition<ApplicationImpl, ApplicationEvent, ApplicationState> {
        @Override
        public ApplicationState transition(ApplicationImpl app, ApplicationEvent event) {
            ApplicationFinishEvent appEvent = ((ApplicationFinishEvent) (event));
            if (app.LDESHCMEWJ.isEmpty()) {
                // No container to cleanup. Cleanup app level resources.
                app.handleAppFinishWithContainersCleanedup();
                return ApplicationState.APPLICATION_RESOURCES_CLEANINGUP;
            }
            // Send event to ContainersLauncher to finish all the containers of this
            // application.
            for (ContainerId containerID : app.LDESHCMEWJ.keySet()) {
                app.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerKillEvent(containerID, ContainerExitStatus.KILLED_AFTER_APP_COMPLETION, "Container killed on application-finish event: " + appEvent.getDiagnostic()));
            }
            return ApplicationState.FINISHING_CONTAINERS_WAIT;
        }
    }

    static class AppFinishTransition implements MultipleArcTransition<ApplicationImpl, ApplicationEvent, ApplicationState> {
        @Override
        public ApplicationState transition(ApplicationImpl app, ApplicationEvent event) {
            ApplicationContainerFinishedEvent containerFinishEvent = ((ApplicationContainerFinishedEvent) (event));
            ApplicationImpl.SOYBKODAYG.info((("Removing " + containerFinishEvent.getContainerID()) + " from application ") + app.toString());
            app.LDESHCMEWJ.remove(containerFinishEvent.getContainerID());
            if (app.LDESHCMEWJ.isEmpty()) {
                // All containers are cleanedup.
                app.handleAppFinishWithContainersCleanedup();
                return ApplicationState.APPLICATION_RESOURCES_CLEANINGUP;
            }
            return ApplicationState.FINISHING_CONTAINERS_WAIT;
        }
    }

    @SuppressWarnings("unchecked")
    static class AppCompletelyDoneTransition implements SingleArcTransition<ApplicationImpl, ApplicationEvent> {
        @Override
        public void transition(ApplicationImpl app, ApplicationEvent event) {
            // Inform the logService
            app.JOONLDIZMV.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.loghandler.event.LogHandlerAppFinishedEvent(app.JLSQTXKKFL));
            app.THDCQFEKBB.getNMTokenSecretManager().appFinished(app.getAppId());
        }
    }

    static class AppLogsAggregatedTransition implements SingleArcTransition<ApplicationImpl, ApplicationEvent> {
        @Override
        public void transition(ApplicationImpl app, ApplicationEvent event) {
            ApplicationId appId = event.getApplicationID();
            app.THDCQFEKBB.getApplications().remove(appId);
            app.HUVOFCRTZT.removeApplication(appId);
            try {
                app.THDCQFEKBB.getNMStateStore().removeApplication(appId);
            } catch (IOException e) {
                ApplicationImpl.SOYBKODAYG.error("Unable to remove application from state store", e);
            }
        }
    }

    @Override
    public void handle(ApplicationEvent ICINFYSDMY) {
        this.VPXSFMMSMH.lock();
        try {
            ApplicationId EKEBQIYGXJ = ICINFYSDMY.getApplicationID();
            ApplicationImpl.SOYBKODAYG.debug((("Processing " + EKEBQIYGXJ) + " of type ") + ICINFYSDMY.getType());
            ApplicationState PAVJOQUXPH = UILCCHEHHH.getCurrentState();
            ApplicationState ZPAXRVRDCZ = null;
            try {
                // queue event requesting init of the same app
                ZPAXRVRDCZ = UILCCHEHHH.doTransition(ICINFYSDMY.getType(), ICINFYSDMY);
            } catch (InvalidStateTransitonException e) {
                ApplicationImpl.SOYBKODAYG.warn("Can't handle this event at current state", e);
            }
            if (PAVJOQUXPH != ZPAXRVRDCZ) {
                ApplicationImpl.SOYBKODAYG.info((((("Application " + EKEBQIYGXJ) + " transitioned from ") + PAVJOQUXPH) + " to ") + ZPAXRVRDCZ);
            }
        } finally {
            this.VPXSFMMSMH.unlock();
        }
    }

    @Override
    public String toString() {
        return JLSQTXKKFL.toString();
    }
}