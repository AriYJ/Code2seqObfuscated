public class TestSnapshotListing {
    static final long UNMPQHUKWV = 0;

    static final short DMQQSXLSKB = 3;

    static final long JSOYRVQJOH = 1024;

    private final Path FQGCKXQDNY = new Path("/test.snapshot/dir");

    Configuration TFROJJATCJ;

    MiniDFSCluster FDBWKRFXXS;

    FSNamesystem DTJCRQGXRG;

    DistributedFileSystem JIVUFVYSKU;

    @Before
    public void setUp() throws Exception {
        TFROJJATCJ = new Configuration();
        FDBWKRFXXS = new MiniDFSCluster.Builder(TFROJJATCJ).numDataNodes(TestSnapshotListing.DMQQSXLSKB).build();
        FDBWKRFXXS.waitActive();
        DTJCRQGXRG = FDBWKRFXXS.getNamesystem();
        JIVUFVYSKU = FDBWKRFXXS.getFileSystem();
        JIVUFVYSKU.mkdirs(FQGCKXQDNY);
    }

    @After
    public void tearDown() throws Exception {
        if (FDBWKRFXXS != null) {
            FDBWKRFXXS.shutdown();
        }
    }

    /**
     * Test listing snapshots under a snapshottable directory
     */
    @Test(timeout = 15000)
    public void testListSnapshots() throws Exception {
        final Path LPWYNBFDYY = new Path(FQGCKXQDNY, ".snapshot");
        FileStatus[] MYYWKZLICH = null;
        // special case: snapshots of root
        MYYWKZLICH = JIVUFVYSKU.listStatus(new Path("/.snapshot"));
        // should be 0 since root's snapshot quota is 0
        assertEquals(0, MYYWKZLICH.length);
        // list before set dir as snapshottable
        try {
            MYYWKZLICH = JIVUFVYSKU.listStatus(LPWYNBFDYY);
            fail("expect SnapshotException");
        } catch (IOException e) {
            GenericTestUtils.assertExceptionContains("Directory is not a snapshottable directory: " + FQGCKXQDNY.toString(), e);
        }
        // list before creating snapshots
        JIVUFVYSKU.allowSnapshot(FQGCKXQDNY);
        MYYWKZLICH = JIVUFVYSKU.listStatus(LPWYNBFDYY);
        assertEquals(0, MYYWKZLICH.length);
        // list while creating snapshots
        final int NVTJNTEULI = 5;
        for (int VUXXUQJXDP = 0; VUXXUQJXDP < NVTJNTEULI; VUXXUQJXDP++) {
            JIVUFVYSKU.createSnapshot(FQGCKXQDNY, "s_" + VUXXUQJXDP);
            MYYWKZLICH = JIVUFVYSKU.listStatus(LPWYNBFDYY);
            assertEquals(VUXXUQJXDP + 1, MYYWKZLICH.length);
            for (int LRBUXRBKQB = 0; LRBUXRBKQB <= VUXXUQJXDP; LRBUXRBKQB++) {
                assertEquals("s_" + LRBUXRBKQB, MYYWKZLICH[LRBUXRBKQB].getPath().getName());
            }
        }
        // list while deleting snapshots
        for (int PDKTWHQPZG = NVTJNTEULI - 1; PDKTWHQPZG > 0; PDKTWHQPZG--) {
            JIVUFVYSKU.deleteSnapshot(FQGCKXQDNY, "s_" + PDKTWHQPZG);
            MYYWKZLICH = JIVUFVYSKU.listStatus(LPWYNBFDYY);
            assertEquals(PDKTWHQPZG, MYYWKZLICH.length);
            for (int PRIOXAUISB = 0; PRIOXAUISB < PDKTWHQPZG; PRIOXAUISB++) {
                assertEquals("s_" + PRIOXAUISB, MYYWKZLICH[PRIOXAUISB].getPath().getName());
            }
        }
        // remove the last snapshot
        JIVUFVYSKU.deleteSnapshot(FQGCKXQDNY, "s_0");
        MYYWKZLICH = JIVUFVYSKU.listStatus(LPWYNBFDYY);
        assertEquals(0, MYYWKZLICH.length);
    }
}