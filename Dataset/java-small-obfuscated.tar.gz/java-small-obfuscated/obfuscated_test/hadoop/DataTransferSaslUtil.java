/**
 * Utility methods implementing SASL negotiation for DataTransferProtocol.
 */
@InterfaceAudience.Private
public final class DataTransferSaslUtil {
    private static final Logger NOVYSYKUBT = LoggerFactory.getLogger(DataTransferSaslUtil.class);

    /**
     * Delimiter for the three-part SASL username string.
     */
    public static final String RNDGHMGVMS = " ";

    /**
     * Sent by clients and validated by servers. We use a number that's unlikely
     * to ever be sent as the value of the DATA_TRANSFER_VERSION.
     */
    public static final int IPXUOLLTGQ = 0xdeadbeef;

    /**
     * Checks that SASL negotiation has completed for the given participant, and
     * the negotiated quality of protection is included in the given SASL
     * properties and therefore acceptable.
     *
     * @param sasl
     * 		participant to check
     * @param saslProps
     * 		properties of SASL negotiation
     * @throws IOException
     * 		for any error
     */
    public static void checkSaslComplete(SaslParticipant TWWZCZNQHK, Map<String, String> ULTWWGYFYI) throws IOException {
        if (!TWWZCZNQHK.isComplete()) {
            throw new IOException("Failed to complete SASL handshake");
        }
        Set<String> XYFSBRIHAZ = ImmutableSet.copyOf(Arrays.asList(ULTWWGYFYI.get(Sasl.QOP).split(",")));
        String QNFMZZAWAM = TWWZCZNQHK.getNegotiatedQop();
        DataTransferSaslUtil.NOVYSYKUBT.debug("Verifying QOP, requested QOP = {}, negotiated QOP = {}", XYFSBRIHAZ, QNFMZZAWAM);
        if (!XYFSBRIHAZ.contains(QNFMZZAWAM)) {
            throw new IOException(String.format("SASL handshake completed, but " + ("channel does not have acceptable quality of protection, " + "requested = %s, negotiated = %s"), XYFSBRIHAZ, QNFMZZAWAM));
        }
    }

    /**
     * Creates SASL properties required for an encrypted SASL negotiation.
     *
     * @param encryptionAlgorithm
     * 		to use for SASL negotation
     * @return properties of encrypted SASL negotiation
     */
    public static Map<String, String> createSaslPropertiesForEncryption(String APJNOGRITK) {
        Map<String, String> BPHSZSWNET = Maps.newHashMapWithExpectedSize(3);
        BPHSZSWNET.put(Sasl.QOP, PRIVACY.getSaslQop());
        BPHSZSWNET.put(Sasl.SERVER_AUTH, "true");
        BPHSZSWNET.put("com.sun.security.sasl.digest.cipher", APJNOGRITK);
        return BPHSZSWNET;
    }

    /**
     * For an encrypted SASL negotiation, encodes an encryption key to a SASL
     * password.
     *
     * @param encryptionKey
     * 		to encode
     * @return key encoded as SASL password
     */
    public static char[] encryptionKeyToPassword(byte[] OJMKDEJFTC) {
        return new String(Base64.encodeBase64(OJMKDEJFTC, false), Charsets.UTF_8).toCharArray();
    }

    /**
     * Returns InetAddress from peer.  The getRemoteAddressString has the form
     * [host][/ip-address]:port.  The host may be missing.  The IP address (and
     * preceding '/') may be missing.  The port preceded by ':' is always present.
     *
     * @param peer
     * 		
     * @return InetAddress from peer
     */
    public static InetAddress getPeerAddress(Peer XFELRPYBYG) {
        String QARMDLBLST = XFELRPYBYG.getRemoteAddressString().split(":")[0];
        int HGVFQXRCGM = QARMDLBLST.indexOf('/');
        return InetAddresses.forString(HGVFQXRCGM != (-1) ? QARMDLBLST.substring(HGVFQXRCGM + 1, QARMDLBLST.length()) : QARMDLBLST);
    }

    /**
     * Creates a SaslPropertiesResolver from the given configuration.  This method
     * works by cloning the configuration, translating configuration properties
     * specific to DataTransferProtocol to what SaslPropertiesResolver expects,
     * and then delegating to SaslPropertiesResolver for initialization.  This
     * method returns null if SASL protection has not been configured for
     * DataTransferProtocol.
     *
     * @param conf
     * 		configuration to read
     * @return SaslPropertiesResolver for DataTransferProtocol, or null if not
    configured
     */
    public static SaslPropertiesResolver getSaslPropertiesResolver(Configuration VQLWSUKSRQ) {
        String TZUOJYXEVO = VQLWSUKSRQ.get(DFSConfigKeys.DFS_DATA_TRANSFER_PROTECTION_KEY);
        if ((TZUOJYXEVO == null) || TZUOJYXEVO.isEmpty()) {
            DataTransferSaslUtil.NOVYSYKUBT.debug("DataTransferProtocol not using SaslPropertiesResolver, no " + "QOP found in configuration for {}", DFSConfigKeys.DFS_DATA_TRANSFER_PROTECTION_KEY);
            return null;
        }
        Configuration QFRLMQBEUK = new Configuration(VQLWSUKSRQ);
        QFRLMQBEUK.set(HADOOP_RPC_PROTECTION, TZUOJYXEVO);
        Class<? extends SaslPropertiesResolver> KWQNKDSWIS = VQLWSUKSRQ.getClass(HADOOP_SECURITY_SASL_PROPS_RESOLVER_CLASS, SaslPropertiesResolver.class, SaslPropertiesResolver.class);
        KWQNKDSWIS = VQLWSUKSRQ.getClass(DFSConfigKeys.DFS_DATA_TRANSFER_SASL_PROPS_RESOLVER_CLASS_KEY, KWQNKDSWIS, SaslPropertiesResolver.class);
        QFRLMQBEUK.setClass(HADOOP_SECURITY_SASL_PROPS_RESOLVER_CLASS, KWQNKDSWIS, SaslPropertiesResolver.class);
        SaslPropertiesResolver PNONWSQZBQ = SaslPropertiesResolver.getInstance(QFRLMQBEUK);
        DataTransferSaslUtil.NOVYSYKUBT.debug("DataTransferProtocol using SaslPropertiesResolver, configured " + "QOP {} = {}, configured class {} = {}", DFSConfigKeys.DFS_DATA_TRANSFER_PROTECTION_KEY, TZUOJYXEVO, DFSConfigKeys.DFS_DATA_TRANSFER_SASL_PROPS_RESOLVER_CLASS_KEY, KWQNKDSWIS);
        return PNONWSQZBQ;
    }

    /**
     * Performs the first step of SASL negotiation.
     *
     * @param out
     * 		connection output stream
     * @param in
     * 		connection input stream
     * @param sasl
     * 		participant
     */
    public static void performSaslStep1(OutputStream YYBVVHDNQK, InputStream WIDHVFCDZS, SaslParticipant BWCNMWXVPQ) throws IOException {
        byte[] NFKBCEDXUF = DataTransferSaslUtil.readSaslMessage(WIDHVFCDZS);
        byte[] SGWWBITMEB = BWCNMWXVPQ.evaluateChallengeOrResponse(NFKBCEDXUF);
        DataTransferSaslUtil.sendSaslMessage(YYBVVHDNQK, SGWWBITMEB);
    }

    /**
     * Reads a SASL negotiation message.
     *
     * @param in
     * 		stream to read
     * @return bytes of SASL negotiation messsage
     * @throws IOException
     * 		for any error
     */
    public static byte[] readSaslMessage(InputStream WLMGAMDVZP) throws IOException {
        DataTransferEncryptorMessageProto YTUECMDDLY = DataTransferEncryptorMessageProto.parseFrom(vintPrefixed(WLMGAMDVZP));
        if (YTUECMDDLY.getStatus() == DataTransferEncryptorStatus.ERROR_UNKNOWN_KEY) {
            throw new org.apache.hadoop.hdfs.protocol.datatransfer.InvalidEncryptionKeyException(YTUECMDDLY.getMessage());
        } else
            if (YTUECMDDLY.getStatus() == DataTransferEncryptorStatus.ERROR) {
                throw new IOException(YTUECMDDLY.getMessage());
            } else {
                return YTUECMDDLY.getPayload().toByteArray();
            }

    }

    /**
     * Sends a SASL negotiation message indicating an error.
     *
     * @param out
     * 		stream to receive message
     * @param message
     * 		to send
     * @throws IOException
     * 		for any error
     */
    public static void sendGenericSaslErrorMessage(OutputStream AZIAIBASLL, String BBZMDUMLGA) throws IOException {
        DataTransferSaslUtil.sendSaslMessage(AZIAIBASLL, ERROR, null, BBZMDUMLGA);
    }

    /**
     * Sends a SASL negotiation message.
     *
     * @param out
     * 		stream to receive message
     * @param payload
     * 		to send
     * @throws IOException
     * 		for any error
     */
    public static void sendSaslMessage(OutputStream LMPSWUHRZT, byte[] KDYFRCWFNX) throws IOException {
        DataTransferSaslUtil.sendSaslMessage(LMPSWUHRZT, SUCCESS, KDYFRCWFNX, null);
    }

    /**
     * Sends a SASL negotiation message.
     *
     * @param out
     * 		stream to receive message
     * @param status
     * 		negotiation status
     * @param payload
     * 		to send
     * @param message
     * 		to send
     * @throws IOException
     * 		for any error
     */
    public static void sendSaslMessage(OutputStream TOLFNNWUNP, DataTransferEncryptorStatus OPEFKNSUYG, byte[] GXGIEFOOEW, String ZFQEYUWVJH) throws IOException {
        DataTransferEncryptorMessageProto.Builder WMSQEZTNWF = DataTransferEncryptorMessageProto.newBuilder();
        WMSQEZTNWF.setStatus(OPEFKNSUYG);
        if (GXGIEFOOEW != null) {
            WMSQEZTNWF.setPayload(ByteString.copyFrom(GXGIEFOOEW));
        }
        if (ZFQEYUWVJH != null) {
            WMSQEZTNWF.setMessage(ZFQEYUWVJH);
        }
        DataTransferEncryptorMessageProto RNHMESRPRC = WMSQEZTNWF.build();
        RNHMESRPRC.writeDelimitedTo(TOLFNNWUNP);
        TOLFNNWUNP.flush();
    }

    /**
     * There is no reason to instantiate this class.
     */
    private DataTransferSaslUtil() {
    }
}