public class UserNamePermission {
    private static final Log QKOIBEJWOV = LogFactory.getLog(UserNamePermission.class);

    // This mapper will read the user name and pass in to the reducer
    public static class UserNameMapper extends Mapper<LongWritable, Text, Text, Text> {
        Text GZHBAGDKQY = new Text("UserName");

        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            Text val = new Text(System.getProperty("user.name").toString());
            context.write(GZHBAGDKQY, val);
        }
    }

    // The reducer is responsible for writing the user name to the file
    // which will be validated by the testcase
    public static class UserNameReducer extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterator<Text> values, Context context) throws IOException, InterruptedException {
            UserNamePermission.QKOIBEJWOV.info("The key " + key);
            if (values.hasNext()) {
                Text val = values.next();
                UserNamePermission.QKOIBEJWOV.info("The value  " + val);
                context.write(key, new Text(System.getProperty("user.name")));
            }
        }
    }

    public static void main(String[] ZXRIYYFFPE) throws Exception {
        Path NIOTFLIWQB = new Path("output");
        Configuration KIEHFPNYIM = new Configuration();
        Job CENFUFPVLD = new Job(KIEHFPNYIM, "user name check");
        CENFUFPVLD.setJarByClass(UserNamePermission.class);
        CENFUFPVLD.setMapperClass(UserNamePermission.UserNameMapper.class);
        CENFUFPVLD.setCombinerClass(UserNamePermission.UserNameReducer.class);
        CENFUFPVLD.setMapOutputKeyClass(Text.class);
        CENFUFPVLD.setMapOutputValueClass(Text.class);
        CENFUFPVLD.setReducerClass(UserNamePermission.UserNameReducer.class);
        CENFUFPVLD.setNumReduceTasks(1);
        CENFUFPVLD.setInputFormatClass(TextInputFormat.class);
        TextInputFormat.addInputPath(CENFUFPVLD, new Path("input"));
        FileOutputFormat.setOutputPath(CENFUFPVLD, NIOTFLIWQB);
        System.exit(CENFUFPVLD.waitForCompletion(true) ? 0 : 1);
    }
}