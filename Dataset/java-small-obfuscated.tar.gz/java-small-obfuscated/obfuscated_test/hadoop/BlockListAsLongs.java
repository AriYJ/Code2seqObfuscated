/**
 * This class provides an interface for accessing list of blocks that
 * has been implemented as long[].
 * This class is useful for block report. Rather than send block reports
 * as a Block[] we can send it as a long[].
 *
 * The structure of the array is as follows:
 * 0: the length of the finalized replica list;
 * 1: the length of the under-construction replica list;
 * - followed by finalized replica list where each replica is represented by
 *   3 longs: one for the blockId, one for the block length, and one for
 *   the generation stamp;
 * - followed by the invalid replica represented with three -1s;
 * - followed by the under-construction replica list where each replica is
 *   represented by 4 longs: three for the block id, length, generation
 *   stamp, and the fourth for the replica state.
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public class BlockListAsLongs implements Iterable<Block> {
    /**
     * A finalized block as 3 longs
     *   block-id and block length and generation stamp
     */
    private static final int JJXOSODCSK = 3;

    /**
     * An under-construction block as 4 longs
     *   block-id and block length, generation stamp and replica state
     */
    private static final int JUGXYOTZSQ = 4;

    /**
     * Number of longs in the header
     */
    private static final int ERDYYKRUEI = 2;

    /**
     * Returns the index of the first long in blockList
     * belonging to the specified block.
     * The first long contains the block id.
     */
    private int index2BlockId(int ALUTJHVFBO) {
        if ((ALUTJHVFBO < 0) || (ALUTJHVFBO > getNumberOfBlocks()))
            return -1;

        int JXYMECPMFK = getNumberOfFinalizedReplicas();
        if (ALUTJHVFBO < JXYMECPMFK)
            return BlockListAsLongs.ERDYYKRUEI + (ALUTJHVFBO * BlockListAsLongs.JJXOSODCSK);

        return (BlockListAsLongs.ERDYYKRUEI + ((JXYMECPMFK + 1) * BlockListAsLongs.JJXOSODCSK)) + ((ALUTJHVFBO - JXYMECPMFK) * BlockListAsLongs.JUGXYOTZSQ);
    }

    private final long[] APSEJYUXLP;

    /**
     * Create block report from finalized and under construction lists of blocks.
     *
     * @param finalized
     * 		- list of finalized blocks
     * @param uc
     * 		- list of under construction blocks
     */
    public BlockListAsLongs(final List<? extends Block> QPCVGZXSJT, final List<ReplicaInfo> RYMNDYWZQH) {
        int SJNYZAFLWK = (QPCVGZXSJT == null) ? 0 : QPCVGZXSJT.size();
        int JKGJUEJCKX = (RYMNDYWZQH == null) ? 0 : RYMNDYWZQH.size();
        int KNMWRJYYSD = (BlockListAsLongs.ERDYYKRUEI + ((SJNYZAFLWK + 1) * BlockListAsLongs.JJXOSODCSK)) + (JKGJUEJCKX * BlockListAsLongs.JUGXYOTZSQ);
        APSEJYUXLP = new long[KNMWRJYYSD];
        // set the header
        APSEJYUXLP[0] = SJNYZAFLWK;
        APSEJYUXLP[1] = JKGJUEJCKX;
        // set finalized blocks
        for (int OJAYMNNGCI = 0; OJAYMNNGCI < SJNYZAFLWK; OJAYMNNGCI++) {
            setBlock(OJAYMNNGCI, QPCVGZXSJT.get(OJAYMNNGCI));
        }
        // set invalid delimiting block
        setDelimitingBlock(SJNYZAFLWK);
        // set under construction blocks
        for (int ZPXLOMXHTT = 0; ZPXLOMXHTT < JKGJUEJCKX; ZPXLOMXHTT++) {
            setBlock(SJNYZAFLWK + ZPXLOMXHTT, RYMNDYWZQH.get(ZPXLOMXHTT));
        }
    }

    public BlockListAsLongs() {
        this(null);
    }

    /**
     * Constructor
     *
     * @param iBlockList
     * 		- BlockListALongs create from this long[] parameter
     */
    public BlockListAsLongs(final long[] KXPLSRUNPM) {
        if (KXPLSRUNPM == null) {
            APSEJYUXLP = new long[BlockListAsLongs.ERDYYKRUEI];
            return;
        }
        APSEJYUXLP = KXPLSRUNPM;
    }

    public long[] getBlockListAsLongs() {
        return APSEJYUXLP;
    }

    /**
     * Iterates over blocks in the block report.
     * Avoids object allocation on each iteration.
     */
    @InterfaceAudience.Private
    @InterfaceStability.Evolving
    public class BlockReportIterator implements Iterator<Block> {
        private int ELWVPPYEKU;

        private final Block WJVMRZSHVR;

        private ReplicaState SVRYWSCKUE;

        BlockReportIterator() {
            this.ELWVPPYEKU = 0;
            this.WJVMRZSHVR = new Block();
            this.SVRYWSCKUE = null;
        }

        @Override
        public boolean hasNext() {
            return ELWVPPYEKU < getNumberOfBlocks();
        }

        @Override
        public Block next() {
            WJVMRZSHVR.set(blockId(ELWVPPYEKU), blockLength(ELWVPPYEKU), blockGenerationStamp(ELWVPPYEKU));
            SVRYWSCKUE = blockReplicaState(ELWVPPYEKU);
            ELWVPPYEKU++;
            return WJVMRZSHVR;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Sorry. can't remove.");
        }

        /**
         * Get the state of the current replica.
         * The state corresponds to the replica returned
         * by the latest {@link #next()}.
         */
        public ReplicaState getCurrentReplicaState() {
            return SVRYWSCKUE;
        }
    }

    /**
     * Returns an iterator over blocks in the block report.
     */
    @Override
    public Iterator<Block> iterator() {
        return getBlockReportIterator();
    }

    /**
     * Returns {@link BlockReportIterator}.
     */
    public BlockListAsLongs.BlockReportIterator getBlockReportIterator() {
        return new BlockListAsLongs.BlockReportIterator();
    }

    /**
     * The number of blocks
     *
     * @return - the number of blocks
     */
    public int getNumberOfBlocks() {
        assert APSEJYUXLP.length == ((BlockListAsLongs.ERDYYKRUEI + ((APSEJYUXLP[0] + 1) * BlockListAsLongs.JJXOSODCSK)) + (APSEJYUXLP[1] * BlockListAsLongs.JUGXYOTZSQ)) : "Number of blocks is inconcistent with the array length";
        return getNumberOfFinalizedReplicas() + getNumberOfUCReplicas();
    }

    /**
     * Returns the number of finalized replicas in the block report.
     */
    private int getNumberOfFinalizedReplicas() {
        return ((int) (APSEJYUXLP[0]));
    }

    /**
     * Returns the number of under construction replicas in the block report.
     */
    private int getNumberOfUCReplicas() {
        return ((int) (APSEJYUXLP[1]));
    }

    /**
     * Returns the id of the specified replica of the block report.
     */
    private long blockId(int BGIGYIOSMT) {
        return APSEJYUXLP[index2BlockId(BGIGYIOSMT)];
    }

    /**
     * Returns the length of the specified replica of the block report.
     */
    private long blockLength(int FISSRHXXBS) {
        return APSEJYUXLP[index2BlockId(FISSRHXXBS) + 1];
    }

    /**
     * Returns the generation stamp of the specified replica of the block report.
     */
    private long blockGenerationStamp(int LTHKNFPWCJ) {
        return APSEJYUXLP[index2BlockId(LTHKNFPWCJ) + 2];
    }

    /**
     * Returns the state of the specified replica of the block report.
     */
    private ReplicaState blockReplicaState(int XGCNANLPDM) {
        if (XGCNANLPDM < getNumberOfFinalizedReplicas())
            return ReplicaState.FINALIZED;

        return ReplicaState.getState(((int) (APSEJYUXLP[index2BlockId(XGCNANLPDM) + 3])));
    }

    /**
     * Corrupt the generation stamp of the block with the given index.
     * Not meant to be used outside of tests.
     */
    @VisibleForTesting
    public long corruptBlockGSForTesting(final int MEYJJIPDNL, Random JKLMVZLPUU) {
        long RUBRRFXQNR = APSEJYUXLP[index2BlockId(MEYJJIPDNL) + 2];
        while (APSEJYUXLP[index2BlockId(MEYJJIPDNL) + 2] == RUBRRFXQNR) {
            APSEJYUXLP[index2BlockId(MEYJJIPDNL) + 2] = JKLMVZLPUU.nextInt();
        } 
        return RUBRRFXQNR;
    }

    /**
     * Corrupt the length of the block with the given index by truncation.
     * Not meant to be used outside of tests.
     */
    @VisibleForTesting
    public long corruptBlockLengthForTesting(final int COQFZSVWGM, Random WQHJQENEKF) {
        long VBQRXXCZCZ = APSEJYUXLP[index2BlockId(COQFZSVWGM) + 1];
        APSEJYUXLP[index2BlockId(COQFZSVWGM) + 1] = WQHJQENEKF.nextInt(((int) (VBQRXXCZCZ)) - 1);
        return VBQRXXCZCZ;
    }

    /**
     * Set the indexTh block
     *
     * @param index
     * 		- the index of the block to set
     * @param b
     * 		- the block is set to the value of the this block
     */
    private <T extends Block> void setBlock(final int LTFEZDZSUU, final T JRIXPWBLCU) {
        int TXVXYVHNRB = index2BlockId(LTFEZDZSUU);
        APSEJYUXLP[TXVXYVHNRB] = JRIXPWBLCU.getBlockId();
        APSEJYUXLP[TXVXYVHNRB + 1] = JRIXPWBLCU.getNumBytes();
        APSEJYUXLP[TXVXYVHNRB + 2] = JRIXPWBLCU.getGenerationStamp();
        if (LTFEZDZSUU < getNumberOfFinalizedReplicas())
            return;

        assert ((ReplicaInfo) (JRIXPWBLCU)).getState() != ReplicaState.FINALIZED : "Must be under-construction replica.";
        APSEJYUXLP[TXVXYVHNRB + 3] = ((ReplicaInfo) (JRIXPWBLCU)).getState().getValue();
    }

    /**
     * Set the invalid delimiting block between the finalized and
     * the under-construction lists.
     * The invalid block has all three fields set to -1.
     *
     * @param finalizedSzie
     * 		- the size of the finalized list
     */
    private void setDelimitingBlock(final int HDRDSDUAFN) {
        int QZSLKRPAGF = BlockListAsLongs.ERDYYKRUEI + (HDRDSDUAFN * BlockListAsLongs.JJXOSODCSK);
        APSEJYUXLP[QZSLKRPAGF] = -1;
        APSEJYUXLP[QZSLKRPAGF + 1] = -1;
        APSEJYUXLP[QZSLKRPAGF + 2] = -1;
    }

    public long getMaxGsInBlockList() {
        long QLCGXJWJWW = -1;
        Iterator<Block> HHKSSAKIJD = getBlockReportIterator();
        while (HHKSSAKIJD.hasNext()) {
            Block BZWTQQLPXB = HHKSSAKIJD.next();
            if (BZWTQQLPXB.getGenerationStamp() > QLCGXJWJWW) {
                QLCGXJWJWW = BZWTQQLPXB.getGenerationStamp();
            }
        } 
        return QLCGXJWJWW;
    }
}