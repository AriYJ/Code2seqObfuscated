public class NMLeveldbStateStoreService extends NMStateStoreService {
    public static final Log DMXULKZQOO = LogFactory.getLog(NMLeveldbStateStoreService.class);

    private static final String UGSKXLBZZX = "yarn-nm-state";

    private static final String BUGRDKKSTC = "nm-schema-version";

    private static final Version LKULDCBSRN = Version.newInstance(1, 0);

    private static final String VZCCCNVTEW = "DeletionService/deltask_";

    private static final String LZKBCJCHDO = "ContainerManager/applications/";

    private static final String LPONCHTAKB = "ContainerManager/finishedApps/";

    private static final String PLAXYPUYKT = "Localization/";

    private static final String OIGYLZTMKM = NMLeveldbStateStoreService.PLAXYPUYKT + "public/";

    private static final String QGOOYPPGTE = NMLeveldbStateStoreService.PLAXYPUYKT + "private/";

    private static final String OZTMJKCAVZ = "started/";

    private static final String NDKMQLIPLU = "completed/";

    private static final String RHQPAOUBYN = "filecache/";

    private static final String EYIQPGKGEJ = "appcache/";

    private static final String MZJVYHQKCA = "ContainerManager/containers/";

    private static final String SLBSYLICCQ = "/request";

    private static final String NEDSYLDSLX = "/diagnostics";

    private static final String VPDFHVIHGZ = "/launched";

    private static final String CLOPXRXIRD = "/killed";

    private static final String KRGXZTSTMO = "/exitcode";

    private static final String NVUCBIWKOB = "CurrentMasterKey";

    private static final String WENTNXKBFV = "PreviousMasterKey";

    private static final String EWHMLDQGSZ = "NMTokens/";

    private static final String DWHSIMQHHN = NMLeveldbStateStoreService.EWHMLDQGSZ + NMLeveldbStateStoreService.NVUCBIWKOB;

    private static final String JYNNZLKOWQ = NMLeveldbStateStoreService.EWHMLDQGSZ + NMLeveldbStateStoreService.WENTNXKBFV;

    private static final String WYYHFPJCAV = "ContainerTokens/";

    private static final String JYTKAOSEUO = NMLeveldbStateStoreService.WYYHFPJCAV + NMLeveldbStateStoreService.NVUCBIWKOB;

    private static final String VOVKANFBHZ = NMLeveldbStateStoreService.WYYHFPJCAV + NMLeveldbStateStoreService.WENTNXKBFV;

    private static final byte[] NULAVFNWYD = new byte[0];

    private DB YPBXGJVGVN;

    public NMLeveldbStateStoreService() {
        super(NMLeveldbStateStoreService.class.getName());
    }

    @Override
    protected void startStorage() throws IOException {
    }

    @Override
    protected void closeStorage() throws IOException {
        if (YPBXGJVGVN != null) {
            YPBXGJVGVN.close();
        }
    }

    @Override
    public List<RecoveredContainerState> loadContainersState() throws IOException {
        ArrayList<RecoveredContainerState> MOOZBZTQUC = new ArrayList<RecoveredContainerState>();
        LeveldbIterator QNJAPSNZCT = null;
        try {
            QNJAPSNZCT = new LeveldbIterator(YPBXGJVGVN);
            QNJAPSNZCT.seek(bytes(NMLeveldbStateStoreService.MZJVYHQKCA));
            while (QNJAPSNZCT.hasNext()) {
                Map.Entry<byte[], byte[]> ZYPOLFQFUT = QNJAPSNZCT.peekNext();
                String KLZNCHOCTG = asString(ZYPOLFQFUT.getKey());
                if (!KLZNCHOCTG.startsWith(NMLeveldbStateStoreService.MZJVYHQKCA)) {
                    break;
                }
                int XURMPFBAET = KLZNCHOCTG.indexOf('/', NMLeveldbStateStoreService.MZJVYHQKCA.length());
                if (XURMPFBAET < 0) {
                    throw new IOException("Unable to determine container in key: " + KLZNCHOCTG);
                }
                ContainerId TBZGDTWPXF = ConverterUtils.toContainerId(KLZNCHOCTG.substring(NMLeveldbStateStoreService.MZJVYHQKCA.length(), XURMPFBAET));
                String SRJLHODEPV = KLZNCHOCTG.substring(0, XURMPFBAET + 1);
                MOOZBZTQUC.add(loadContainerState(TBZGDTWPXF, QNJAPSNZCT, SRJLHODEPV));
            } 
        } catch (DBException e) {
            throw new IOException(e);
        } finally {
            if (QNJAPSNZCT != null) {
                QNJAPSNZCT.close();
            }
        }
        return MOOZBZTQUC;
    }

    private RecoveredContainerState loadContainerState(ContainerId LDSFQJFORI, LeveldbIterator QCVAVUPFJZ, String ZMXDTWOTYN) throws IOException {
        RecoveredContainerState LPKGNBOTXY = new RecoveredContainerState();
        LPKGNBOTXY.status = RecoveredContainerStatus.REQUESTED;
        while (QCVAVUPFJZ.hasNext()) {
            Map.Entry<byte[], byte[]> OSVELTUHWI = QCVAVUPFJZ.peekNext();
            String JYFMVWYNXY = asString(OSVELTUHWI.getKey());
            if (!JYFMVWYNXY.startsWith(ZMXDTWOTYN)) {
                break;
            }
            QCVAVUPFJZ.next();
            String NVHINWKTSB = JYFMVWYNXY.substring(ZMXDTWOTYN.length() - 1);// start with '/'

            if (NVHINWKTSB.equals(NMLeveldbStateStoreService.SLBSYLICCQ)) {
                LPKGNBOTXY.startRequest = new org.apache.hadoop.yarn.api.protocolrecords.impl.pb.StartContainerRequestPBImpl(StartContainerRequestProto.parseFrom(OSVELTUHWI.getValue()));
            } else
                if (NVHINWKTSB.equals(NMLeveldbStateStoreService.NEDSYLDSLX)) {
                    LPKGNBOTXY.diagnostics = asString(OSVELTUHWI.getValue());
                } else
                    if (NVHINWKTSB.equals(NMLeveldbStateStoreService.VPDFHVIHGZ)) {
                        if (LPKGNBOTXY.status == RecoveredContainerStatus.REQUESTED) {
                            LPKGNBOTXY.status = RecoveredContainerStatus.LAUNCHED;
                        }
                    } else
                        if (NVHINWKTSB.equals(NMLeveldbStateStoreService.CLOPXRXIRD)) {
                            LPKGNBOTXY.killed = true;
                        } else
                            if (NVHINWKTSB.equals(NMLeveldbStateStoreService.KRGXZTSTMO)) {
                                LPKGNBOTXY.status = RecoveredContainerStatus.COMPLETED;
                                LPKGNBOTXY.exitCode = Integer.parseInt(asString(OSVELTUHWI.getValue()));
                            } else {
                                throw new IOException("Unexpected container state key: " + JYFMVWYNXY);
                            }




        } 
        return LPKGNBOTXY;
    }

    @Override
    public void storeContainer(ContainerId GXRAWWWVVK, StartContainerRequest ZZRUOHBJLX) throws IOException {
        String TOLEYJJOHC = (NMLeveldbStateStoreService.MZJVYHQKCA + GXRAWWWVVK.toString()) + NMLeveldbStateStoreService.SLBSYLICCQ;
        try {
            YPBXGJVGVN.put(bytes(TOLEYJJOHC), ((org.apache.hadoop.yarn.api.protocolrecords.impl.pb.StartContainerRequestPBImpl) (ZZRUOHBJLX)).getProto().toByteArray());
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void storeContainerDiagnostics(ContainerId JFCYXASRCJ, StringBuilder GTAARZBJYG) throws IOException {
        String MFKXNSFOQR = (NMLeveldbStateStoreService.MZJVYHQKCA + JFCYXASRCJ.toString()) + NMLeveldbStateStoreService.NEDSYLDSLX;
        try {
            YPBXGJVGVN.put(bytes(MFKXNSFOQR), bytes(GTAARZBJYG.toString()));
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void storeContainerLaunched(ContainerId GVMEPMOGLG) throws IOException {
        String IVYTMYKGPP = (NMLeveldbStateStoreService.MZJVYHQKCA + GVMEPMOGLG.toString()) + NMLeveldbStateStoreService.VPDFHVIHGZ;
        try {
            YPBXGJVGVN.put(bytes(IVYTMYKGPP), NMLeveldbStateStoreService.NULAVFNWYD);
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void storeContainerKilled(ContainerId ADHLDRMFBH) throws IOException {
        String MTJWLLWXAW = (NMLeveldbStateStoreService.MZJVYHQKCA + ADHLDRMFBH.toString()) + NMLeveldbStateStoreService.CLOPXRXIRD;
        try {
            YPBXGJVGVN.put(bytes(MTJWLLWXAW), NMLeveldbStateStoreService.NULAVFNWYD);
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void storeContainerCompleted(ContainerId OCNNKYBHUM, int FXWZNHIRFY) throws IOException {
        String KVJNRPAADM = (NMLeveldbStateStoreService.MZJVYHQKCA + OCNNKYBHUM.toString()) + NMLeveldbStateStoreService.KRGXZTSTMO;
        try {
            YPBXGJVGVN.put(bytes(KVJNRPAADM), bytes(Integer.toString(FXWZNHIRFY)));
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void removeContainer(ContainerId DHZVIGVOQU) throws IOException {
        String JMXPPGGKRY = NMLeveldbStateStoreService.MZJVYHQKCA + DHZVIGVOQU.toString();
        try {
            WriteBatch OMJESFZZDC = YPBXGJVGVN.createWriteBatch();
            try {
                OMJESFZZDC.delete(bytes(JMXPPGGKRY + NMLeveldbStateStoreService.SLBSYLICCQ));
                OMJESFZZDC.delete(bytes(JMXPPGGKRY + NMLeveldbStateStoreService.NEDSYLDSLX));
                OMJESFZZDC.delete(bytes(JMXPPGGKRY + NMLeveldbStateStoreService.VPDFHVIHGZ));
                OMJESFZZDC.delete(bytes(JMXPPGGKRY + NMLeveldbStateStoreService.CLOPXRXIRD));
                OMJESFZZDC.delete(bytes(JMXPPGGKRY + NMLeveldbStateStoreService.KRGXZTSTMO));
                YPBXGJVGVN.write(OMJESFZZDC);
            } finally {
                OMJESFZZDC.close();
            }
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public RecoveredApplicationsState loadApplicationsState() throws IOException {
        RecoveredApplicationsState MBTHECZOFS = new RecoveredApplicationsState();
        MBTHECZOFS.applications = new ArrayList<ContainerManagerApplicationProto>();
        String BUOKPVPJVF = NMLeveldbStateStoreService.LZKBCJCHDO;
        LeveldbIterator HZGYUQOKPH = null;
        try {
            HZGYUQOKPH = new LeveldbIterator(YPBXGJVGVN);
            HZGYUQOKPH.seek(bytes(BUOKPVPJVF));
            while (HZGYUQOKPH.hasNext()) {
                Map.Entry<byte[], byte[]> CGOOBUWCHU = HZGYUQOKPH.next();
                String DDXGAHHMIV = asString(CGOOBUWCHU.getKey());
                if (!DDXGAHHMIV.startsWith(BUOKPVPJVF)) {
                    break;
                }
                MBTHECZOFS.applications.add(ContainerManagerApplicationProto.parseFrom(CGOOBUWCHU.getValue()));
            } 
            MBTHECZOFS.finishedApplications = new ArrayList<ApplicationId>();
            BUOKPVPJVF = NMLeveldbStateStoreService.LPONCHTAKB;
            HZGYUQOKPH.seek(bytes(BUOKPVPJVF));
            while (HZGYUQOKPH.hasNext()) {
                Map.Entry<byte[], byte[]> TBBSDNOWAU = HZGYUQOKPH.next();
                String SQPEMYOPXG = asString(TBBSDNOWAU.getKey());
                if (!SQPEMYOPXG.startsWith(BUOKPVPJVF)) {
                    break;
                }
                ApplicationId YQNGFTUGID = ConverterUtils.toApplicationId(SQPEMYOPXG.substring(BUOKPVPJVF.length()));
                MBTHECZOFS.finishedApplications.add(YQNGFTUGID);
            } 
        } catch (DBException e) {
            throw new IOException(e);
        } finally {
            if (HZGYUQOKPH != null) {
                HZGYUQOKPH.close();
            }
        }
        return MBTHECZOFS;
    }

    @Override
    public void storeApplication(ApplicationId OWTEARDEYW, ContainerManagerApplicationProto QKGFCANHYV) throws IOException {
        String VBMOXEMCYQ = NMLeveldbStateStoreService.LZKBCJCHDO + OWTEARDEYW;
        try {
            YPBXGJVGVN.put(bytes(VBMOXEMCYQ), QKGFCANHYV.toByteArray());
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void storeFinishedApplication(ApplicationId DPDHRVUHDI) throws IOException {
        String ISYLTSXWMI = NMLeveldbStateStoreService.LPONCHTAKB + DPDHRVUHDI;
        try {
            YPBXGJVGVN.put(bytes(ISYLTSXWMI), new byte[0]);
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void removeApplication(ApplicationId RDYIMUGRLZ) throws IOException {
        try {
            WriteBatch UYGPUEIFFX = YPBXGJVGVN.createWriteBatch();
            try {
                String GTOAHCUDMA = NMLeveldbStateStoreService.LZKBCJCHDO + RDYIMUGRLZ;
                UYGPUEIFFX.delete(bytes(GTOAHCUDMA));
                GTOAHCUDMA = NMLeveldbStateStoreService.LPONCHTAKB + RDYIMUGRLZ;
                UYGPUEIFFX.delete(bytes(GTOAHCUDMA));
                YPBXGJVGVN.write(UYGPUEIFFX);
            } finally {
                UYGPUEIFFX.close();
            }
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public RecoveredLocalizationState loadLocalizationState() throws IOException {
        RecoveredLocalizationState IXJFNZDZWY = new RecoveredLocalizationState();
        LeveldbIterator NDJQNUIZCQ = null;
        try {
            NDJQNUIZCQ = new LeveldbIterator(YPBXGJVGVN);
            NDJQNUIZCQ.seek(bytes(NMLeveldbStateStoreService.OIGYLZTMKM));
            IXJFNZDZWY.publicTrackerState = loadResourceTrackerState(NDJQNUIZCQ, NMLeveldbStateStoreService.OIGYLZTMKM);
            NDJQNUIZCQ.seek(bytes(NMLeveldbStateStoreService.QGOOYPPGTE));
            while (NDJQNUIZCQ.hasNext()) {
                Map.Entry<byte[], byte[]> YOAXHPMZRG = NDJQNUIZCQ.peekNext();
                String GMJUDLMFZC = asString(YOAXHPMZRG.getKey());
                if (!GMJUDLMFZC.startsWith(NMLeveldbStateStoreService.QGOOYPPGTE)) {
                    break;
                }
                int FTIAAFVKZV = GMJUDLMFZC.indexOf('/', NMLeveldbStateStoreService.QGOOYPPGTE.length());
                if (FTIAAFVKZV < 0) {
                    throw new IOException("Unable to determine user in resource key: " + GMJUDLMFZC);
                }
                String PCNEBYMTRT = GMJUDLMFZC.substring(NMLeveldbStateStoreService.QGOOYPPGTE.length(), FTIAAFVKZV);
                IXJFNZDZWY.userResources.put(PCNEBYMTRT, loadUserLocalizedResources(NDJQNUIZCQ, GMJUDLMFZC.substring(0, FTIAAFVKZV + 1)));
            } 
        } catch (DBException e) {
            throw new IOException(e);
        } finally {
            if (NDJQNUIZCQ != null) {
                NDJQNUIZCQ.close();
            }
        }
        return IXJFNZDZWY;
    }

    private LocalResourceTrackerState loadResourceTrackerState(LeveldbIterator LNJSIRPMEM, String QCEPVPBIRX) throws IOException {
        final String UPXRQMKTTB = QCEPVPBIRX + NMLeveldbStateStoreService.NDKMQLIPLU;
        final String AFDGLCAUCW = QCEPVPBIRX + NMLeveldbStateStoreService.OZTMJKCAVZ;
        LocalResourceTrackerState CTPULOEQKQ = new LocalResourceTrackerState();
        while (LNJSIRPMEM.hasNext()) {
            Map.Entry<byte[], byte[]> CWYTKKVKGM = LNJSIRPMEM.peekNext();
            String RGEWQYHOHO = asString(CWYTKKVKGM.getKey());
            if (!RGEWQYHOHO.startsWith(QCEPVPBIRX)) {
                break;
            }
            if (RGEWQYHOHO.startsWith(UPXRQMKTTB)) {
                CTPULOEQKQ.localizedResources = loadCompletedResources(LNJSIRPMEM, UPXRQMKTTB);
            } else
                if (RGEWQYHOHO.startsWith(AFDGLCAUCW)) {
                    CTPULOEQKQ.inProgressResources = loadStartedResources(LNJSIRPMEM, AFDGLCAUCW);
                } else {
                    throw new IOException("Unexpected key in resource tracker state: " + RGEWQYHOHO);
                }

        } 
        return CTPULOEQKQ;
    }

    private List<LocalizedResourceProto> loadCompletedResources(LeveldbIterator IHTCDBSWGD, String WZAASDAOJQ) throws IOException {
        List<LocalizedResourceProto> OXGPNFTBKQ = new ArrayList<LocalizedResourceProto>();
        while (IHTCDBSWGD.hasNext()) {
            Map.Entry<byte[], byte[]> OEWPSKQNMM = IHTCDBSWGD.peekNext();
            String APBKSDIPCR = asString(OEWPSKQNMM.getKey());
            if (!APBKSDIPCR.startsWith(WZAASDAOJQ)) {
                break;
            }
            if (NMLeveldbStateStoreService.DMXULKZQOO.isDebugEnabled()) {
                NMLeveldbStateStoreService.DMXULKZQOO.debug("Loading completed resource from " + APBKSDIPCR);
            }
            OXGPNFTBKQ.add(LocalizedResourceProto.parseFrom(OEWPSKQNMM.getValue()));
            IHTCDBSWGD.next();
        } 
        return OXGPNFTBKQ;
    }

    private Map<LocalResourceProto, Path> loadStartedResources(LeveldbIterator OGIDTXYBEL, String RXAOILIEWN) throws IOException {
        Map<LocalResourceProto, Path> BYMQTSGYAO = new HashMap<LocalResourceProto, Path>();
        while (OGIDTXYBEL.hasNext()) {
            Map.Entry<byte[], byte[]> SPVSYCIFXB = OGIDTXYBEL.peekNext();
            String LTEEAVPNGN = asString(SPVSYCIFXB.getKey());
            if (!LTEEAVPNGN.startsWith(RXAOILIEWN)) {
                break;
            }
            Path SUVPTCXIZI = new Path(LTEEAVPNGN.substring(RXAOILIEWN.length()));
            if (NMLeveldbStateStoreService.DMXULKZQOO.isDebugEnabled()) {
                NMLeveldbStateStoreService.DMXULKZQOO.debug("Loading in-progress resource at " + SUVPTCXIZI);
            }
            BYMQTSGYAO.put(LocalResourceProto.parseFrom(SPVSYCIFXB.getValue()), SUVPTCXIZI);
            OGIDTXYBEL.next();
        } 
        return BYMQTSGYAO;
    }

    private RecoveredUserResources loadUserLocalizedResources(LeveldbIterator YRKTQTDTYY, String JDDQIXNTMP) throws IOException {
        RecoveredUserResources QTNZVZUQLI = new RecoveredUserResources();
        while (YRKTQTDTYY.hasNext()) {
            Map.Entry<byte[], byte[]> WQGNMVVWOY = YRKTQTDTYY.peekNext();
            String SPPGOYLLCW = asString(WQGNMVVWOY.getKey());
            if (!SPPGOYLLCW.startsWith(JDDQIXNTMP)) {
                break;
            }
            if (SPPGOYLLCW.startsWith(NMLeveldbStateStoreService.RHQPAOUBYN, JDDQIXNTMP.length())) {
                QTNZVZUQLI.privateTrackerState = loadResourceTrackerState(YRKTQTDTYY, JDDQIXNTMP + NMLeveldbStateStoreService.RHQPAOUBYN);
            } else
                if (SPPGOYLLCW.startsWith(NMLeveldbStateStoreService.EYIQPGKGEJ, JDDQIXNTMP.length())) {
                    int UDQKSHFRBM = JDDQIXNTMP.length() + NMLeveldbStateStoreService.EYIQPGKGEJ.length();
                    int ERFBQOLLZS = SPPGOYLLCW.indexOf('/', UDQKSHFRBM);
                    if (ERFBQOLLZS < 0) {
                        throw new IOException("Unable to determine appID in resource key: " + SPPGOYLLCW);
                    }
                    ApplicationId FLFRDDAZAL = ConverterUtils.toApplicationId(SPPGOYLLCW.substring(UDQKSHFRBM, ERFBQOLLZS));
                    QTNZVZUQLI.appTrackerStates.put(FLFRDDAZAL, loadResourceTrackerState(YRKTQTDTYY, SPPGOYLLCW.substring(0, ERFBQOLLZS + 1)));
                } else {
                    throw new IOException("Unexpected user resource key " + SPPGOYLLCW);
                }

        } 
        return QTNZVZUQLI;
    }

    @Override
    public void startResourceLocalization(String MWJLXOTMUK, ApplicationId XPYUTXEMAI, LocalResourceProto OPRYUEENRP, Path KJCYUBJJDH) throws IOException {
        String ZWGFGJWEIO = getResourceStartedKey(MWJLXOTMUK, XPYUTXEMAI, KJCYUBJJDH.toString());
        try {
            YPBXGJVGVN.put(bytes(ZWGFGJWEIO), OPRYUEENRP.toByteArray());
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void finishResourceLocalization(String JUKATJIKVE, ApplicationId ZQWWJDNJAY, LocalizedResourceProto HONVHFMZZV) throws IOException {
        String CDHIONQCQQ = HONVHFMZZV.getLocalPath();
        String ENMGAVFIXU = getResourceStartedKey(JUKATJIKVE, ZQWWJDNJAY, CDHIONQCQQ);
        String WGLSYKWMMQ = getResourceCompletedKey(JUKATJIKVE, ZQWWJDNJAY, CDHIONQCQQ);
        if (NMLeveldbStateStoreService.DMXULKZQOO.isDebugEnabled()) {
            NMLeveldbStateStoreService.DMXULKZQOO.debug("Storing localized resource to " + WGLSYKWMMQ);
        }
        try {
            WriteBatch MHBZBHRAOO = YPBXGJVGVN.createWriteBatch();
            try {
                MHBZBHRAOO.delete(bytes(ENMGAVFIXU));
                MHBZBHRAOO.put(bytes(WGLSYKWMMQ), HONVHFMZZV.toByteArray());
                YPBXGJVGVN.write(MHBZBHRAOO);
            } finally {
                MHBZBHRAOO.close();
            }
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void removeLocalizedResource(String KPUYQBRDZX, ApplicationId AGOKIBNSBA, Path ZHIUOMNKHE) throws IOException {
        String JEUUMDXKPK = ZHIUOMNKHE.toString();
        String NSMDFYSOSU = getResourceStartedKey(KPUYQBRDZX, AGOKIBNSBA, JEUUMDXKPK);
        String NHBTEIZVUT = getResourceCompletedKey(KPUYQBRDZX, AGOKIBNSBA, JEUUMDXKPK);
        if (NMLeveldbStateStoreService.DMXULKZQOO.isDebugEnabled()) {
            NMLeveldbStateStoreService.DMXULKZQOO.debug("Removing local resource at " + JEUUMDXKPK);
        }
        try {
            WriteBatch OOSUCVPVHP = YPBXGJVGVN.createWriteBatch();
            try {
                OOSUCVPVHP.delete(bytes(NSMDFYSOSU));
                OOSUCVPVHP.delete(bytes(NHBTEIZVUT));
                YPBXGJVGVN.write(OOSUCVPVHP);
            } finally {
                OOSUCVPVHP.close();
            }
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    private String getResourceStartedKey(String KYWTUIQZYO, ApplicationId MLZIWFYXMW, String NAWVMMFLCH) {
        return (getResourceTrackerKeyPrefix(KYWTUIQZYO, MLZIWFYXMW) + NMLeveldbStateStoreService.OZTMJKCAVZ) + NAWVMMFLCH;
    }

    private String getResourceCompletedKey(String MSAQLGJISP, ApplicationId XBHPEPIBVD, String MHMAZZNVQA) {
        return (getResourceTrackerKeyPrefix(MSAQLGJISP, XBHPEPIBVD) + NMLeveldbStateStoreService.NDKMQLIPLU) + MHMAZZNVQA;
    }

    private String getResourceTrackerKeyPrefix(String XFYWQGCRGS, ApplicationId TBDJOCDICQ) {
        if (XFYWQGCRGS == null) {
            return NMLeveldbStateStoreService.OIGYLZTMKM;
        }
        if (TBDJOCDICQ == null) {
            return ((NMLeveldbStateStoreService.QGOOYPPGTE + XFYWQGCRGS) + "/") + NMLeveldbStateStoreService.RHQPAOUBYN;
        }
        return ((((NMLeveldbStateStoreService.QGOOYPPGTE + XFYWQGCRGS) + "/") + NMLeveldbStateStoreService.EYIQPGKGEJ) + TBDJOCDICQ) + "/";
    }

    @Override
    public RecoveredDeletionServiceState loadDeletionServiceState() throws IOException {
        RecoveredDeletionServiceState IZRPNKDPFX = new RecoveredDeletionServiceState();
        IZRPNKDPFX.tasks = new ArrayList<DeletionServiceDeleteTaskProto>();
        LeveldbIterator KXUHIXLYIL = null;
        try {
            KXUHIXLYIL = new LeveldbIterator(YPBXGJVGVN);
            KXUHIXLYIL.seek(bytes(NMLeveldbStateStoreService.VZCCCNVTEW));
            while (KXUHIXLYIL.hasNext()) {
                Map.Entry<byte[], byte[]> QMHEZKJXUZ = KXUHIXLYIL.next();
                String IQJSLAPDNZ = asString(QMHEZKJXUZ.getKey());
                if (!IQJSLAPDNZ.startsWith(NMLeveldbStateStoreService.VZCCCNVTEW)) {
                    break;
                }
                IZRPNKDPFX.tasks.add(DeletionServiceDeleteTaskProto.parseFrom(QMHEZKJXUZ.getValue()));
            } 
        } catch (DBException e) {
            throw new IOException(e);
        } finally {
            if (KXUHIXLYIL != null) {
                KXUHIXLYIL.close();
            }
        }
        return IZRPNKDPFX;
    }

    @Override
    public void storeDeletionTask(int JYAZRVGQGH, DeletionServiceDeleteTaskProto WWYRVGLXCG) throws IOException {
        String CGGCYRFTOQ = NMLeveldbStateStoreService.VZCCCNVTEW + JYAZRVGQGH;
        try {
            YPBXGJVGVN.put(bytes(CGGCYRFTOQ), WWYRVGLXCG.toByteArray());
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void removeDeletionTask(int BIYSZGALOB) throws IOException {
        String ZCIXSLYAVP = NMLeveldbStateStoreService.VZCCCNVTEW + BIYSZGALOB;
        try {
            YPBXGJVGVN.delete(bytes(ZCIXSLYAVP));
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public RecoveredNMTokensState loadNMTokensState() throws IOException {
        RecoveredNMTokensState LAJMTWYLJH = new RecoveredNMTokensState();
        LAJMTWYLJH.applicationMasterKeys = new HashMap<ApplicationAttemptId, MasterKey>();
        LeveldbIterator UEDQFHFZKY = null;
        try {
            UEDQFHFZKY = new LeveldbIterator(YPBXGJVGVN);
            UEDQFHFZKY.seek(bytes(NMLeveldbStateStoreService.EWHMLDQGSZ));
            while (UEDQFHFZKY.hasNext()) {
                Map.Entry<byte[], byte[]> DPFDZXONZR = UEDQFHFZKY.next();
                String QMGKAWFQLE = asString(DPFDZXONZR.getKey());
                if (!QMGKAWFQLE.startsWith(NMLeveldbStateStoreService.EWHMLDQGSZ)) {
                    break;
                }
                String CUTKBKYSQU = QMGKAWFQLE.substring(NMLeveldbStateStoreService.EWHMLDQGSZ.length());
                if (CUTKBKYSQU.equals(NMLeveldbStateStoreService.NVUCBIWKOB)) {
                    LAJMTWYLJH.currentMasterKey = parseMasterKey(DPFDZXONZR.getValue());
                } else
                    if (CUTKBKYSQU.equals(NMLeveldbStateStoreService.WENTNXKBFV)) {
                        LAJMTWYLJH.previousMasterKey = parseMasterKey(DPFDZXONZR.getValue());
                    } else
                        if (CUTKBKYSQU.startsWith(appAttemptIdStrPrefix)) {
                            ApplicationAttemptId LDKBLCBHYJ;
                            try {
                                LDKBLCBHYJ = ConverterUtils.toApplicationAttemptId(CUTKBKYSQU);
                            } catch (IllegalArgumentException e) {
                                throw new IOException("Bad application master key state for " + QMGKAWFQLE, e);
                            }
                            LAJMTWYLJH.applicationMasterKeys.put(LDKBLCBHYJ, parseMasterKey(DPFDZXONZR.getValue()));
                        }


            } 
        } catch (DBException e) {
            throw new IOException(e);
        } finally {
            if (UEDQFHFZKY != null) {
                UEDQFHFZKY.close();
            }
        }
        return LAJMTWYLJH;
    }

    @Override
    public void storeNMTokenCurrentMasterKey(MasterKey RAHAUGHJAX) throws IOException {
        storeMasterKey(NMLeveldbStateStoreService.DWHSIMQHHN, RAHAUGHJAX);
    }

    @Override
    public void storeNMTokenPreviousMasterKey(MasterKey DESQLRYHAX) throws IOException {
        storeMasterKey(NMLeveldbStateStoreService.JYNNZLKOWQ, DESQLRYHAX);
    }

    @Override
    public void storeNMTokenApplicationMasterKey(ApplicationAttemptId JFMAHFTDEJ, MasterKey CUVVFZNWBR) throws IOException {
        storeMasterKey(NMLeveldbStateStoreService.EWHMLDQGSZ + JFMAHFTDEJ, CUVVFZNWBR);
    }

    @Override
    public void removeNMTokenApplicationMasterKey(ApplicationAttemptId KWMOXHIBYS) throws IOException {
        String QTMQAQIDNY = NMLeveldbStateStoreService.EWHMLDQGSZ + KWMOXHIBYS;
        try {
            YPBXGJVGVN.delete(bytes(QTMQAQIDNY));
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    private MasterKey parseMasterKey(byte[] BFGQDUXMYV) throws IOException {
        return new MasterKeyPBImpl(MasterKeyProto.parseFrom(BFGQDUXMYV));
    }

    private void storeMasterKey(String ISBZPRWQSG, MasterKey ZBPWCXJGPW) throws IOException {
        MasterKeyPBImpl ZZQQKWNUCI = ((MasterKeyPBImpl) (ZBPWCXJGPW));
        try {
            YPBXGJVGVN.put(bytes(ISBZPRWQSG), ZZQQKWNUCI.getProto().toByteArray());
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public RecoveredContainerTokensState loadContainerTokensState() throws IOException {
        RecoveredContainerTokensState XCETNSCBOI = new RecoveredContainerTokensState();
        XCETNSCBOI.activeTokens = new HashMap<ContainerId, Long>();
        LeveldbIterator BIJXFZGEFX = null;
        try {
            BIJXFZGEFX = new LeveldbIterator(YPBXGJVGVN);
            BIJXFZGEFX.seek(bytes(NMLeveldbStateStoreService.WYYHFPJCAV));
            final int SCNSVKHUFI = NMLeveldbStateStoreService.WYYHFPJCAV.length();
            while (BIJXFZGEFX.hasNext()) {
                Map.Entry<byte[], byte[]> AKVUXJDSYS = BIJXFZGEFX.next();
                String MTQUFLCYAT = asString(AKVUXJDSYS.getKey());
                if (!MTQUFLCYAT.startsWith(NMLeveldbStateStoreService.WYYHFPJCAV)) {
                    break;
                }
                String IWBMXHHVEA = MTQUFLCYAT.substring(SCNSVKHUFI);
                if (IWBMXHHVEA.equals(NMLeveldbStateStoreService.NVUCBIWKOB)) {
                    XCETNSCBOI.currentMasterKey = parseMasterKey(AKVUXJDSYS.getValue());
                } else
                    if (IWBMXHHVEA.equals(NMLeveldbStateStoreService.WENTNXKBFV)) {
                        XCETNSCBOI.previousMasterKey = parseMasterKey(AKVUXJDSYS.getValue());
                    } else
                        if (IWBMXHHVEA.startsWith(CONTAINER_PREFIX)) {
                            NMLeveldbStateStoreService.loadContainerToken(XCETNSCBOI, MTQUFLCYAT, IWBMXHHVEA, AKVUXJDSYS.getValue());
                        }


            } 
        } catch (DBException e) {
            throw new IOException(e);
        } finally {
            if (BIJXFZGEFX != null) {
                BIJXFZGEFX.close();
            }
        }
        return XCETNSCBOI;
    }

    private static void loadContainerToken(RecoveredContainerTokensState RYSWYVNMRR, String DGGDJHUHPD, String GKMZPCXTHK, byte[] KMIYQBCMRJ) throws IOException {
        ContainerId ZIZGGIZDKB;
        Long QPPYDBBSDS;
        try {
            ZIZGGIZDKB = ConverterUtils.toContainerId(GKMZPCXTHK);
            QPPYDBBSDS = Long.parseLong(asString(KMIYQBCMRJ));
        } catch (IllegalArgumentException e) {
            throw new IOException("Bad container token state for " + DGGDJHUHPD, e);
        }
        RYSWYVNMRR.activeTokens.put(ZIZGGIZDKB, QPPYDBBSDS);
    }

    @Override
    public void storeContainerTokenCurrentMasterKey(MasterKey VJBKMQWLKW) throws IOException {
        storeMasterKey(NMLeveldbStateStoreService.JYTKAOSEUO, VJBKMQWLKW);
    }

    @Override
    public void storeContainerTokenPreviousMasterKey(MasterKey EFTVJBPQVO) throws IOException {
        storeMasterKey(NMLeveldbStateStoreService.VOVKANFBHZ, EFTVJBPQVO);
    }

    @Override
    public void storeContainerToken(ContainerId IOUGFSXYWB, Long LDYHTODYUJ) throws IOException {
        String CXZILFQTQA = NMLeveldbStateStoreService.WYYHFPJCAV + IOUGFSXYWB;
        try {
            YPBXGJVGVN.put(bytes(CXZILFQTQA), bytes(LDYHTODYUJ.toString()));
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void removeContainerToken(ContainerId WZNRDYEBDM) throws IOException {
        String STLKBXGSFH = NMLeveldbStateStoreService.WYYHFPJCAV + WZNRDYEBDM;
        try {
            YPBXGJVGVN.delete(bytes(STLKBXGSFH));
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    @Override
    protected void initStorage(Configuration MSQNDXQHKU) throws IOException {
        Path ZCQPDYGAGF = createStorageDir(MSQNDXQHKU);
        Options PGMGKVBQNS = new Options();
        PGMGKVBQNS.createIfMissing(false);
        PGMGKVBQNS.logger(new NMLeveldbStateStoreService.LeveldbLogger());
        NMLeveldbStateStoreService.DMXULKZQOO.info(("Using state database at " + ZCQPDYGAGF) + " for recovery");
        File AGXGHYYPGF = new File(ZCQPDYGAGF.toString());
        try {
            YPBXGJVGVN = factory.open(AGXGHYYPGF, PGMGKVBQNS);
        } catch (NativeDB e) {
            if (e.isNotFound() || e.getMessage().contains(" does not exist ")) {
                NMLeveldbStateStoreService.DMXULKZQOO.info("Creating state database at " + AGXGHYYPGF);
                PGMGKVBQNS.createIfMissing(true);
                try {
                    YPBXGJVGVN = factory.open(AGXGHYYPGF, PGMGKVBQNS);
                    // store version
                    storeVersion();
                } catch (DBException dbErr) {
                    throw new IOException(dbErr.getMessage(), dbErr);
                }
            } else {
                throw e;
            }
        }
        checkVersion();
    }

    private Path createStorageDir(Configuration TJBGJGNNOK) throws IOException {
        final String AZLVLOGEEY = TJBGJGNNOK.get(NM_RECOVERY_DIR);
        if (AZLVLOGEEY == null) {
            throw new IOException("No store location directory configured in " + YarnConfiguration.NM_RECOVERY_DIR);
        }
        Path OSNTHDVTOL = new Path(AZLVLOGEEY, NMLeveldbStateStoreService.UGSKXLBZZX);
        FileSystem EXHELFYLZP = FileSystem.getLocal(TJBGJGNNOK);
        EXHELFYLZP.mkdirs(OSNTHDVTOL, new FsPermission(((short) (0700))));
        return OSNTHDVTOL;
    }

    private static class LeveldbLogger implements Logger {
        private static final Log UMDFCNRTRY = LogFactory.getLog(NMLeveldbStateStoreService.LeveldbLogger.class);

        @Override
        public void log(String message) {
            NMLeveldbStateStoreService.LeveldbLogger.UMDFCNRTRY.info(message);
        }
    }

    Version loadVersion() throws IOException {
        byte[] TANDKTIGSB = YPBXGJVGVN.get(bytes(NMLeveldbStateStoreService.BUGRDKKSTC));
        // if version is not stored previously, treat it as 1.0.
        if ((TANDKTIGSB == null) || (TANDKTIGSB.length == 0)) {
            return Version.newInstance(1, 0);
        }
        Version SFFZHFSUHC = new org.apache.hadoop.yarn.server.records.impl.pb.VersionPBImpl(VersionProto.parseFrom(TANDKTIGSB));
        return SFFZHFSUHC;
    }

    private void storeVersion() throws IOException {
        dbStoreVersion(NMLeveldbStateStoreService.LKULDCBSRN);
    }

    // Only used for test
    @VisibleForTesting
    void storeVersion(Version YRCLTYLNGA) throws IOException {
        dbStoreVersion(YRCLTYLNGA);
    }

    private void dbStoreVersion(Version XMRNWJFSKX) throws IOException {
        String JQOYTIOVJA = NMLeveldbStateStoreService.BUGRDKKSTC;
        byte[] CXWNIVBTSV = ((org.apache.hadoop.yarn.server.records.impl.pb.VersionPBImpl) (XMRNWJFSKX)).getProto().toByteArray();
        try {
            YPBXGJVGVN.put(bytes(JQOYTIOVJA), CXWNIVBTSV);
        } catch (DBException e) {
            throw new IOException(e);
        }
    }

    Version getCurrentVersion() {
        return NMLeveldbStateStoreService.LKULDCBSRN;
    }

    /**
     * 1) Versioning scheme: major.minor. For e.g. 1.0, 1.1, 1.2...1.25, 2.0 etc.
     * 2) Any incompatible change of state-store is a major upgrade, and any
     *    compatible change of state-store is a minor upgrade.
     * 3) Within a minor upgrade, say 1.1 to 1.2:
     *    overwrite the version info and proceed as normal.
     * 4) Within a major upgrade, say 1.2 to 2.0:
     *    throw exception and indicate user to use a separate upgrade tool to
     *    upgrade NM state or remove incompatible old state.
     */
    private void checkVersion() throws IOException {
        Version RHBCGYBQUG = loadVersion();
        NMLeveldbStateStoreService.DMXULKZQOO.info("Loaded NM state version info " + RHBCGYBQUG);
        if (RHBCGYBQUG.equals(getCurrentVersion())) {
            return;
        }
        if (RHBCGYBQUG.isCompatibleTo(getCurrentVersion())) {
            NMLeveldbStateStoreService.DMXULKZQOO.info("Storing NM state version info " + getCurrentVersion());
            storeVersion();
        } else {
            throw new IOException((("Incompatible version for NM state: expecting NM state version " + getCurrentVersion()) + ", but loading version ") + RHBCGYBQUG);
        }
    }
}