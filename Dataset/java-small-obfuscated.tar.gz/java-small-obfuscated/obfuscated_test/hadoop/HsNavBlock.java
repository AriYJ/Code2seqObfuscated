/**
 * The navigation block for the history server
 */
public class HsNavBlock extends HtmlBlock {
    final App LXBQYDVECX;

    @Inject
    HsNavBlock(App TGVLHDLRCG) {
        this.LXBQYDVECX = TGVLHDLRCG;
    }

    /* (non-Javadoc)
    @see org.apache.hadoop.yarn.webapp.view.HtmlBlock#render(org.apache.hadoop.yarn.webapp.view.HtmlBlock.Block)
     */
    @Override
    protected void render(Block JSXCBBAGLN) {
        DIV<Hamlet> NGFHEFDOQL = JSXCBBAGLN.div("#nav").h3("Application").ul().li().a(url("about"), "About")._().li().a(url("app"), "Jobs")._()._();
        if (LXBQYDVECX.getJob() != null) {
            String DVHKLXPWOF = MRApps.toString(LXBQYDVECX.getJob().getID());
            NGFHEFDOQL.h3("Job").ul().li().a(url("job", DVHKLXPWOF), "Overview")._().li().a(url("jobcounters", DVHKLXPWOF), "Counters")._().li().a(url("conf", DVHKLXPWOF), "Configuration")._().li().a(url("tasks", DVHKLXPWOF, "m"), "Map tasks")._().li().a(url("tasks", DVHKLXPWOF, "r"), "Reduce tasks")._()._();
            if (LXBQYDVECX.getTask() != null) {
                String YYKBZLGRKI = MRApps.toString(LXBQYDVECX.getTask().getID());
                NGFHEFDOQL.h3("Task").ul().li().a(url("task", YYKBZLGRKI), "Task Overview")._().li().a(url("taskcounters", YYKBZLGRKI), "Counters")._()._();
            }
        }
        NGFHEFDOQL.h3("Tools").ul().li().a("/conf", "Configuration")._().li().a("/logs", "Local logs")._().li().a("/stacks", "Server stacks")._().li().a("/metrics", "Server metrics")._()._()._();
    }
}