/**
 * Implements a hash object that returns a certain number of hashed values.
 *
 * @see Key The general behavior of a key being stored in a filter
 * @see Filter The general behavior of a filter
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public final class HashFunction {
    /**
     * The number of hashed values.
     */
    private int HCZQMXEHQB;

    /**
     * The maximum highest returned value.
     */
    private int EGIMYWHODM;

    /**
     * Hashing algorithm to use.
     */
    private Hash WLYMDGKBHU;

    /**
     * Constructor.
     * <p>
     * Builds a hash function that must obey to a given maximum number of returned values and a highest value.
     *
     * @param maxValue
     * 		The maximum highest returned value.
     * @param nbHash
     * 		The number of resulting hashed values.
     * @param hashType
     * 		type of the hashing function (see {@link Hash}).
     */
    public HashFunction(int UBWQAPQJFS, int GCNRBFTJPJ, int RVXWNOAREA) {
        if (UBWQAPQJFS <= 0) {
            throw new IllegalArgumentException("maxValue must be > 0");
        }
        if (GCNRBFTJPJ <= 0) {
            throw new IllegalArgumentException("nbHash must be > 0");
        }
        this.EGIMYWHODM = UBWQAPQJFS;
        this.HCZQMXEHQB = GCNRBFTJPJ;
        this.WLYMDGKBHU = Hash.getInstance(RVXWNOAREA);
        if (this.WLYMDGKBHU == null)
            throw new IllegalArgumentException("hashType must be known");

    }

    /**
     * Clears <i>this</i> hash function. A NOOP
     */
    public void clear() {
    }

    /**
     * Hashes a specified key into several integers.
     *
     * @param k
     * 		The specified key.
     * @return The array of hashed values.
     */
    public int[] hash(Key ZTFOAHYWZR) {
        byte[] JBKPMLXDLH = ZTFOAHYWZR.getBytes();
        if (JBKPMLXDLH == null) {
            throw new NullPointerException("buffer reference is null");
        }
        if (JBKPMLXDLH.length == 0) {
            throw new IllegalArgumentException("key length must be > 0");
        }
        int[] NXEMCGQMDK = new int[HCZQMXEHQB];
        for (int FSGZXLAEXE = 0, XJKDSUFTKA = 0; FSGZXLAEXE < HCZQMXEHQB; FSGZXLAEXE++) {
            XJKDSUFTKA = WLYMDGKBHU.hash(JBKPMLXDLH, XJKDSUFTKA);
            NXEMCGQMDK[FSGZXLAEXE] = Math.abs(XJKDSUFTKA % EGIMYWHODM);
        }
        return NXEMCGQMDK;
    }
}