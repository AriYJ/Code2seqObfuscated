public class TestBootstrapStandby {
    private static final Log XTXOHAVCQN = LogFactory.getLog(TestBootstrapStandby.class);

    private MiniDFSCluster JFQTZAEBHD;

    private NameNode ITTINRAZGC;

    @Before
    public void setupCluster() throws IOException {
        Configuration OMKJCCBANW = new Configuration();
        MiniDFSNNTopology DGHIJQZUDU = new MiniDFSNNTopology().addNameservice(new MiniDFSNNTopology.NSConf("ns1").addNN(new MiniDFSNNTopology.NNConf("nn1").setHttpPort(20001)).addNN(new MiniDFSNNTopology.NNConf("nn2").setHttpPort(20002)));
        JFQTZAEBHD = new MiniDFSCluster.Builder(OMKJCCBANW).nnTopology(DGHIJQZUDU).numDataNodes(0).build();
        JFQTZAEBHD.waitActive();
        ITTINRAZGC = JFQTZAEBHD.getNameNode(0);
        JFQTZAEBHD.transitionToActive(0);
        JFQTZAEBHD.shutdownNameNode(1);
    }

    @After
    public void shutdownCluster() {
        if (JFQTZAEBHD != null) {
            JFQTZAEBHD.shutdown();
        }
    }

    /**
     * Test for the base success case. The primary NN
     * hasn't made any checkpoints, and we copy the fsimage_0
     * file over and start up.
     */
    @Test
    public void testSuccessfulBaseCase() throws Exception {
        removeStandbyNameDirs();
        try {
            JFQTZAEBHD.restartNameNode(1);
            fail("Did not throw");
        } catch (IOException ioe) {
            GenericTestUtils.assertExceptionContains("storage directory does not exist or is not accessible", ioe);
        }
        int ULHJSFKEZB = BootstrapStandby.run(new String[]{ "-nonInteractive" }, JFQTZAEBHD.getConfiguration(1));
        assertEquals(0, ULHJSFKEZB);
        // Should have copied over the namespace from the active
        FSImageTestUtil.assertNNHasCheckpoints(JFQTZAEBHD, 1, ImmutableList.of(0));
        FSImageTestUtil.assertNNFilesMatch(JFQTZAEBHD);
        // We should now be able to start the standby successfully.
        JFQTZAEBHD.restartNameNode(1);
    }

    /**
     * Test for downloading a checkpoint made at a later checkpoint
     * from the active.
     */
    @Test
    public void testDownloadingLaterCheckpoint() throws Exception {
        // Roll edit logs a few times to inflate txid
        ITTINRAZGC.getRpcServer().rollEditLog();
        ITTINRAZGC.getRpcServer().rollEditLog();
        // Make checkpoint
        NameNodeAdapter.enterSafeMode(ITTINRAZGC, false);
        NameNodeAdapter.saveNamespace(ITTINRAZGC);
        NameNodeAdapter.leaveSafeMode(ITTINRAZGC);
        long BOXKXGMBUC = NameNodeAdapter.getNamesystem(ITTINRAZGC).getFSImage().getMostRecentCheckpointTxId();
        assertEquals(6, BOXKXGMBUC);
        int RKTARYSECG = BootstrapStandby.run(new String[]{ "-force" }, JFQTZAEBHD.getConfiguration(1));
        assertEquals(0, RKTARYSECG);
        // Should have copied over the namespace from the active
        FSImageTestUtil.assertNNHasCheckpoints(JFQTZAEBHD, 1, ImmutableList.of(((int) (BOXKXGMBUC))));
        FSImageTestUtil.assertNNFilesMatch(JFQTZAEBHD);
        // We should now be able to start the standby successfully.
        JFQTZAEBHD.restartNameNode(1);
    }

    /**
     * Test for the case where the shared edits dir doesn't have
     * all of the recent edit logs.
     */
    @Test
    public void testSharedEditsMissingLogs() throws Exception {
        removeStandbyNameDirs();
        CheckpointSignature YUYLILTAZX = ITTINRAZGC.getRpcServer().rollEditLog();
        assertEquals(3, YUYLILTAZX.getCurSegmentTxId());
        // Should have created edits_1-2 in shared edits dir
        URI KTXPPQQLUI = JFQTZAEBHD.getSharedEditsDir(0, 1);
        File GPNGWBMRJA = new File(KTXPPQQLUI);
        File PQXORWZOFT = new File(new File(GPNGWBMRJA, "current"), NNStorage.getFinalizedEditsFileName(1, 2));
        GenericTestUtils.assertExists(PQXORWZOFT);
        // Delete the segment.
        assertTrue(PQXORWZOFT.delete());
        // Trying to bootstrap standby should now fail since the edit
        // logs aren't available in the shared dir.
        LogCapturer QALMWEACVQ = GenericTestUtils.LogCapturer.captureLogs(LogFactory.getLog(BootstrapStandby.class));
        try {
            int XPTKZVJEJB = BootstrapStandby.run(new String[]{ "-force" }, JFQTZAEBHD.getConfiguration(1));
            assertEquals(BootstrapStandby.ERR_CODE_LOGS_UNAVAILABLE, XPTKZVJEJB);
        } finally {
            QALMWEACVQ.stopCapturing();
        }
        GenericTestUtils.assertMatches(QALMWEACVQ.getOutput(), "FATAL.*Unable to read transaction ids 1-3 from the configured shared");
    }

    @Test
    public void testStandbyDirsAlreadyExist() throws Exception {
        // Should not pass since standby dirs exist, force not given
        int BLNAUKGPMA = BootstrapStandby.run(new String[]{ "-nonInteractive" }, JFQTZAEBHD.getConfiguration(1));
        assertEquals(BootstrapStandby.ERR_CODE_ALREADY_FORMATTED, BLNAUKGPMA);
        // Should pass with -force
        BLNAUKGPMA = BootstrapStandby.run(new String[]{ "-force" }, JFQTZAEBHD.getConfiguration(1));
        assertEquals(0, BLNAUKGPMA);
    }

    /**
     * Test that, even if the other node is not active, we are able
     * to bootstrap standby from it.
     */
    @Test(timeout = 30000)
    public void testOtherNodeNotActive() throws Exception {
        JFQTZAEBHD.transitionToStandby(0);
        int UPLEAUMKKJ = BootstrapStandby.run(new String[]{ "-force" }, JFQTZAEBHD.getConfiguration(1));
        assertEquals(0, UPLEAUMKKJ);
    }

    private void removeStandbyNameDirs() {
        for (URI MVTWDXPMDU : JFQTZAEBHD.getNameDirs(1)) {
            assertTrue(MVTWDXPMDU.getScheme().equals("file"));
            File GBJSMSYQZH = new File(MVTWDXPMDU.getPath());
            TestBootstrapStandby.XTXOHAVCQN.info("Removing standby dir " + GBJSMSYQZH);
            assertTrue(FileUtil.fullyDelete(GBJSMSYQZH));
        }
    }
}