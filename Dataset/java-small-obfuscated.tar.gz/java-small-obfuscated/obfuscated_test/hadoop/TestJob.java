public class TestJob {
    @Test
    public void testJobToString() throws IOException, InterruptedException {
        Cluster FZBOYLPWUK = mock(Cluster.class);
        ClientProtocol XQXSJOYPCO = mock(ClientProtocol.class);
        when(FZBOYLPWUK.getClient()).thenReturn(XQXSJOYPCO);
        JobID VUGTECVVOE = new JobID("1014873536921", 6);
        JobStatus TMMIPQELBE = new JobStatus(VUGTECVVOE, 0.0F, 0.0F, 0.0F, 0.0F, State.FAILED, JobPriority.NORMAL, "root", "TestJobToString", "job file", "tracking url");
        when(XQXSJOYPCO.getJobStatus(VUGTECVVOE)).thenReturn(TMMIPQELBE);
        when(XQXSJOYPCO.getTaskReports(VUGTECVVOE, TaskType.MAP)).thenReturn(new TaskReport[0]);
        when(XQXSJOYPCO.getTaskReports(VUGTECVVOE, TaskType.REDUCE)).thenReturn(new TaskReport[0]);
        when(XQXSJOYPCO.getTaskCompletionEvents(VUGTECVVOE, 0, 10)).thenReturn(new TaskCompletionEvent[0]);
        Job IVRBMWDUAJ = Job.getInstance(FZBOYLPWUK, TMMIPQELBE, new JobConf());
        Assert.assertNotNull(IVRBMWDUAJ.toString());
    }

    @Test
    public void testUGICredentialsPropogation() throws Exception {
        Credentials KEWLZWJLRP = new Credentials();
        Token<?> OJFSFYBJCE = mock(Token.class);
        Text DNZONEWZHY = new Text("service");
        Text XAFMVLZVHY = new Text("secret");
        byte[] PSYXFXFGST = new byte[]{  };
        KEWLZWJLRP.addToken(DNZONEWZHY, OJFSFYBJCE);
        KEWLZWJLRP.addSecretKey(XAFMVLZVHY, PSYXFXFGST);
        org.apache.hadoop.security.UserGroupInformation.getLoginUser().addCredentials(KEWLZWJLRP);
        JobConf SBFDBMVOGQ = new JobConf();
        Job JFUAHFCVYG = new Job(SBFDBMVOGQ);
        assertSame(OJFSFYBJCE, JFUAHFCVYG.getCredentials().getToken(DNZONEWZHY));
        assertSame(PSYXFXFGST, JFUAHFCVYG.getCredentials().getSecretKey(XAFMVLZVHY));
    }
}