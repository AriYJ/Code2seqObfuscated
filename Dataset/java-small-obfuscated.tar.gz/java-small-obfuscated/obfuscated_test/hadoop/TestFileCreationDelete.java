public class TestFileCreationDelete {
    {
        ((org.apache.commons.logging.impl.Log4JLogger) (NameNode.stateChangeLog)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (LeaseManager.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (org.apache.commons.logging.LogFactory.getLog(org.apache.hadoop.hdfs.server.namenode.FSNamesystem.class))).getLogger().setLevel(Level.ALL);
    }

    @Test
    public void testFileCreationDeleteParent() throws IOException {
        Configuration XDQYTMJANV = new HdfsConfiguration();
        final int ZNQAHFPXYA = 2000;// 2s

        XDQYTMJANV.setInt("ipc.client.connection.maxidletime", ZNQAHFPXYA);
        XDQYTMJANV.setInt(DFS_NAMENODE_HEARTBEAT_RECHECK_INTERVAL_KEY, 1000);
        XDQYTMJANV.setInt(DFS_HEARTBEAT_INTERVAL_KEY, 1);
        // create cluster
        MiniDFSCluster JZZRCBWVSY = new MiniDFSCluster.Builder(XDQYTMJANV).build();
        FileSystem JOACSGYGQM = null;
        try {
            JZZRCBWVSY.waitActive();
            JOACSGYGQM = JZZRCBWVSY.getFileSystem();
            final int TNOSPHJJFV = JZZRCBWVSY.getNameNodePort();
            // create file1.
            Path ECESHMKZBZ = new Path("/foo");
            Path MXXALIDGRM = new Path(ECESHMKZBZ, "file1");
            FSDataOutputStream TRPKETXQAW = TestFileCreation.createFile(JOACSGYGQM, MXXALIDGRM, 1);
            System.out.println(("testFileCreationDeleteParent: " + "Created file ") + MXXALIDGRM);
            TestFileCreation.writeFile(TRPKETXQAW, 1000);
            TRPKETXQAW.hflush();
            // create file2.
            Path QLYMWGETRH = new Path("/file2");
            FSDataOutputStream GAIXHBXDQT = TestFileCreation.createFile(JOACSGYGQM, QLYMWGETRH, 1);
            System.out.println(("testFileCreationDeleteParent: " + "Created file ") + QLYMWGETRH);
            TestFileCreation.writeFile(GAIXHBXDQT, 1000);
            GAIXHBXDQT.hflush();
            // rm dir
            JOACSGYGQM.delete(ECESHMKZBZ, true);
            // restart cluster with the same namenode port as before.
            // This ensures that leases are persisted in fsimage.
            JZZRCBWVSY.shutdown();
            try {
                Thread.sleep(2 * ZNQAHFPXYA);
            } catch (InterruptedException e) {
            }
            JZZRCBWVSY = new MiniDFSCluster.Builder(XDQYTMJANV).nameNodePort(TNOSPHJJFV).format(false).build();
            JZZRCBWVSY.waitActive();
            // restart cluster yet again. This triggers the code to read in
            // persistent leases from fsimage.
            JZZRCBWVSY.shutdown();
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
            }
            JZZRCBWVSY = new MiniDFSCluster.Builder(XDQYTMJANV).nameNodePort(TNOSPHJJFV).format(false).build();
            JZZRCBWVSY.waitActive();
            JOACSGYGQM = JZZRCBWVSY.getFileSystem();
            assertTrue(!JOACSGYGQM.exists(MXXALIDGRM));
            assertTrue(JOACSGYGQM.exists(QLYMWGETRH));
        } finally {
            JOACSGYGQM.close();
            JZZRCBWVSY.shutdown();
        }
    }
}