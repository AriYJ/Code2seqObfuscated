public class TestOptionsParser {
    @Test
    public void testParseIgnoreFailure() {
        DistCpOptions UNALJVTYDS = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(UNALJVTYDS.shouldIgnoreFailures());
        UNALJVTYDS = OptionsParser.parse(new String[]{ "-i", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(UNALJVTYDS.shouldIgnoreFailures());
    }

    @Test
    public void testParseOverwrite() {
        DistCpOptions LAZNUPOEFZ = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(LAZNUPOEFZ.shouldOverwrite());
        LAZNUPOEFZ = OptionsParser.parse(new String[]{ "-overwrite", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(LAZNUPOEFZ.shouldOverwrite());
        try {
            OptionsParser.parse(new String[]{ "-update", "-overwrite", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            Assert.fail("Update and overwrite aren't allowed together");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testLogPath() {
        DistCpOptions QDMSDCOMPS = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertNull(QDMSDCOMPS.getLogPath());
        QDMSDCOMPS = OptionsParser.parse(new String[]{ "-log", "hdfs://localhost:8020/logs", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(QDMSDCOMPS.getLogPath(), new Path("hdfs://localhost:8020/logs"));
    }

    @Test
    public void testParseBlokcing() {
        DistCpOptions GPBLCKXYPX = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(GPBLCKXYPX.shouldBlock());
        GPBLCKXYPX = OptionsParser.parse(new String[]{ "-async", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(GPBLCKXYPX.shouldBlock());
    }

    @Test
    public void testParsebandwidth() {
        DistCpOptions KEMAGRISZD = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(KEMAGRISZD.getMapBandwidth(), DEFAULT_BANDWIDTH_MB);
        KEMAGRISZD = OptionsParser.parse(new String[]{ "-bandwidth", "11", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(KEMAGRISZD.getMapBandwidth(), 11);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseNonPositiveBandwidth() {
        OptionsParser.parse(new String[]{ "-bandwidth", "-11", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseZeroBandwidth() {
        OptionsParser.parse(new String[]{ "-bandwidth", "0", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
    }

    @Test
    public void testParseSkipCRC() {
        DistCpOptions WNWNUMBHPW = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(WNWNUMBHPW.shouldSkipCRC());
        WNWNUMBHPW = OptionsParser.parse(new String[]{ "-update", "-skipcrccheck", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(WNWNUMBHPW.shouldSyncFolder());
        Assert.assertTrue(WNWNUMBHPW.shouldSkipCRC());
    }

    @Test
    public void testParseAtomicCommit() {
        DistCpOptions IHPPJTHIMO = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(IHPPJTHIMO.shouldAtomicCommit());
        IHPPJTHIMO = OptionsParser.parse(new String[]{ "-atomic", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(IHPPJTHIMO.shouldAtomicCommit());
        try {
            OptionsParser.parse(new String[]{ "-atomic", "-update", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            Assert.fail("Atomic and sync folders were allowed");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testParseWorkPath() {
        DistCpOptions JQYHLNMBVF = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertNull(JQYHLNMBVF.getAtomicWorkPath());
        JQYHLNMBVF = OptionsParser.parse(new String[]{ "-atomic", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertNull(JQYHLNMBVF.getAtomicWorkPath());
        JQYHLNMBVF = OptionsParser.parse(new String[]{ "-atomic", "-tmp", "hdfs://localhost:8020/work", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(JQYHLNMBVF.getAtomicWorkPath(), new Path("hdfs://localhost:8020/work"));
        try {
            OptionsParser.parse(new String[]{ "-tmp", "hdfs://localhost:8020/work", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            Assert.fail("work path was allowed without -atomic switch");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testParseSyncFolders() {
        DistCpOptions GSWTBXHTMH = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(GSWTBXHTMH.shouldSyncFolder());
        GSWTBXHTMH = OptionsParser.parse(new String[]{ "-update", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(GSWTBXHTMH.shouldSyncFolder());
    }

    @Test
    public void testParseDeleteMissing() {
        DistCpOptions DCVLECZPPU = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(DCVLECZPPU.shouldDeleteMissing());
        DCVLECZPPU = OptionsParser.parse(new String[]{ "-update", "-delete", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(DCVLECZPPU.shouldSyncFolder());
        Assert.assertTrue(DCVLECZPPU.shouldDeleteMissing());
        DCVLECZPPU = OptionsParser.parse(new String[]{ "-overwrite", "-delete", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(DCVLECZPPU.shouldOverwrite());
        Assert.assertTrue(DCVLECZPPU.shouldDeleteMissing());
        try {
            OptionsParser.parse(new String[]{ "-atomic", "-delete", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            Assert.fail("Atomic and delete folders were allowed");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testParseSSLConf() {
        DistCpOptions TBQALDAFTD = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertNull(TBQALDAFTD.getSslConfigurationFile());
        TBQALDAFTD = OptionsParser.parse(new String[]{ "-mapredSslConf", "/tmp/ssl-client.xml", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(TBQALDAFTD.getSslConfigurationFile(), "/tmp/ssl-client.xml");
    }

    @Test
    public void testParseMaps() {
        DistCpOptions FWYITMWRXS = OptionsParser.parse(new String[]{ "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(FWYITMWRXS.getMaxMaps(), DEFAULT_MAPS);
        FWYITMWRXS = OptionsParser.parse(new String[]{ "-m", "1", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(FWYITMWRXS.getMaxMaps(), 1);
        FWYITMWRXS = OptionsParser.parse(new String[]{ "-m", "0", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(FWYITMWRXS.getMaxMaps(), 1);
        try {
            OptionsParser.parse(new String[]{ "-m", "hello", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            Assert.fail("Non numberic map parsed");
        } catch (IllegalArgumentException ignore) {
        }
        try {
            OptionsParser.parse(new String[]{ "-mapredXslConf", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            Assert.fail("Non numberic map parsed");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testSourceListing() {
        DistCpOptions UFBWWWSNXG = OptionsParser.parse(new String[]{ "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(UFBWWWSNXG.getSourceFileListing(), new Path("hdfs://localhost:8020/source/first"));
    }

    @Test
    public void testSourceListingAndSourcePath() {
        try {
            OptionsParser.parse(new String[]{ "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            Assert.fail("Both source listing & source paths allowed");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testMissingSourceInfo() {
        try {
            OptionsParser.parse(new String[]{ "hdfs://localhost:8020/target/" });
            Assert.fail("Neither source listing not source paths present");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testMissingTarget() {
        try {
            OptionsParser.parse(new String[]{ "-f", "hdfs://localhost:8020/source" });
            Assert.fail("Missing target allowed");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testInvalidArgs() {
        try {
            OptionsParser.parse(new String[]{ "-m", "-f", "hdfs://localhost:8020/source" });
            Assert.fail("Missing map value");
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Test
    public void testToString() {
        DistCpOptions GKPFVYAXCF = new DistCpOptions(new Path("abc"), new Path("xyz"));
        String OFMZJKDUOE = "DistCpOptions{atomicCommit=false, syncFolder=false, deleteMissing=false, " + (("ignoreFailures=false, maxMaps=20, sslConfigurationFile='null', copyStrategy='uniformsize', " + "sourceFileListing=abc, sourcePaths=null, targetPath=xyz, targetPathExists=true, ") + "preserveRawXattrs=false}");
        Assert.assertEquals(OFMZJKDUOE, GKPFVYAXCF.toString());
        Assert.assertNotSame(ATOMIC_COMMIT.toString(), ATOMIC_COMMIT.name());
    }

    @Test
    public void testCopyStrategy() {
        DistCpOptions KVYXDGLRWC = OptionsParser.parse(new String[]{ "-strategy", "dynamic", "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(KVYXDGLRWC.getCopyStrategy(), "dynamic");
        KVYXDGLRWC = OptionsParser.parse(new String[]{ "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(KVYXDGLRWC.getCopyStrategy(), UNIFORMSIZE);
    }

    @Test
    public void testTargetPath() {
        DistCpOptions WJNDGURGCJ = OptionsParser.parse(new String[]{ "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertEquals(WJNDGURGCJ.getTargetPath(), new Path("hdfs://localhost:8020/target/"));
    }

    @Test
    public void testPreserve() {
        DistCpOptions QRVVPDQLVA = OptionsParser.parse(new String[]{ "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(BLOCKSIZE));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(REPLICATION));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(PERMISSION));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(USER));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(GROUP));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(CHECKSUMTYPE));
        QRVVPDQLVA = OptionsParser.parse(new String[]{ "-p", "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(BLOCKSIZE));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(REPLICATION));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(PERMISSION));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(USER));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(GROUP));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(CHECKSUMTYPE));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(ACL));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(XATTR));
        QRVVPDQLVA = OptionsParser.parse(new String[]{ "-p", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(BLOCKSIZE));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(REPLICATION));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(PERMISSION));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(USER));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(GROUP));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(CHECKSUMTYPE));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(ACL));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(XATTR));
        QRVVPDQLVA = OptionsParser.parse(new String[]{ "-pbr", "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(BLOCKSIZE));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(REPLICATION));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(PERMISSION));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(USER));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(GROUP));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(CHECKSUMTYPE));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(ACL));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(XATTR));
        QRVVPDQLVA = OptionsParser.parse(new String[]{ "-pbrgup", "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(BLOCKSIZE));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(REPLICATION));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(PERMISSION));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(USER));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(GROUP));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(CHECKSUMTYPE));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(ACL));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(XATTR));
        QRVVPDQLVA = OptionsParser.parse(new String[]{ "-pbrgupcax", "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(BLOCKSIZE));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(REPLICATION));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(PERMISSION));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(USER));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(GROUP));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(CHECKSUMTYPE));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(ACL));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(XATTR));
        QRVVPDQLVA = OptionsParser.parse(new String[]{ "-pc", "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(BLOCKSIZE));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(REPLICATION));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(PERMISSION));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(USER));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(GROUP));
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(CHECKSUMTYPE));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(ACL));
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(XATTR));
        QRVVPDQLVA = OptionsParser.parse(new String[]{ "-p", "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        int TCVDIRAIBR = 0;
        Iterator<FileAttribute> FWOJRNGQJU = QRVVPDQLVA.preserveAttributes();
        while (FWOJRNGQJU.hasNext()) {
            FWOJRNGQJU.next();
            TCVDIRAIBR++;
        } 
        Assert.assertEquals(TCVDIRAIBR, 6);
        try {
            OptionsParser.parse(new String[]{ "-pabcd", "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target" });
            Assert.fail("Invalid preserve attribute");
        } catch (IllegalArgumentException ignore) {
        } catch (NoSuchElementException ignore) {
        }
        QRVVPDQLVA = OptionsParser.parse(new String[]{ "-f", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        Assert.assertFalse(QRVVPDQLVA.shouldPreserve(PERMISSION));
        QRVVPDQLVA.preserve(PERMISSION);
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(PERMISSION));
        QRVVPDQLVA.preserve(PERMISSION);
        Assert.assertTrue(QRVVPDQLVA.shouldPreserve(PERMISSION));
    }

    @Test
    public void testOptionsSwitchAddToConf() {
        Configuration ZUKYBHXIBC = new Configuration();
        Assert.assertNull(ZUKYBHXIBC.get(ATOMIC_COMMIT.getConfigLabel()));
        DistCpOptionSwitch.addToConf(ZUKYBHXIBC, ATOMIC_COMMIT);
        Assert.assertTrue(ZUKYBHXIBC.getBoolean(ATOMIC_COMMIT.getConfigLabel(), false));
    }

    @Test
    public void testOptionsAppendToConf() {
        Configuration RWPBFNYOZF = new Configuration();
        Assert.assertFalse(RWPBFNYOZF.getBoolean(IGNORE_FAILURES.getConfigLabel(), false));
        Assert.assertFalse(RWPBFNYOZF.getBoolean(ATOMIC_COMMIT.getConfigLabel(), false));
        DistCpOptions BRBHREZAMO = OptionsParser.parse(new String[]{ "-atomic", "-i", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        BRBHREZAMO.appendToConf(RWPBFNYOZF);
        Assert.assertTrue(RWPBFNYOZF.getBoolean(IGNORE_FAILURES.getConfigLabel(), false));
        Assert.assertTrue(RWPBFNYOZF.getBoolean(ATOMIC_COMMIT.getConfigLabel(), false));
        Assert.assertEquals(RWPBFNYOZF.getInt(BANDWIDTH.getConfigLabel(), -1), DEFAULT_BANDWIDTH_MB);
        RWPBFNYOZF = new Configuration();
        Assert.assertFalse(RWPBFNYOZF.getBoolean(SYNC_FOLDERS.getConfigLabel(), false));
        Assert.assertFalse(RWPBFNYOZF.getBoolean(DELETE_MISSING.getConfigLabel(), false));
        Assert.assertEquals(RWPBFNYOZF.get(PRESERVE_STATUS.getConfigLabel()), null);
        BRBHREZAMO = OptionsParser.parse(new String[]{ "-update", "-delete", "-pu", "-bandwidth", "11", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        BRBHREZAMO.appendToConf(RWPBFNYOZF);
        Assert.assertTrue(RWPBFNYOZF.getBoolean(SYNC_FOLDERS.getConfigLabel(), false));
        Assert.assertTrue(RWPBFNYOZF.getBoolean(DELETE_MISSING.getConfigLabel(), false));
        Assert.assertEquals(RWPBFNYOZF.get(PRESERVE_STATUS.getConfigLabel()), "U");
        Assert.assertEquals(RWPBFNYOZF.getInt(BANDWIDTH.getConfigLabel(), -1), 11);
    }

    @Test
    public void testAppendOption() {
        Configuration DIFUSGGOOV = new Configuration();
        Assert.assertFalse(DIFUSGGOOV.getBoolean(APPEND.getConfigLabel(), false));
        Assert.assertFalse(DIFUSGGOOV.getBoolean(SYNC_FOLDERS.getConfigLabel(), false));
        DistCpOptions XAPYEYLHWN = OptionsParser.parse(new String[]{ "-update", "-append", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
        XAPYEYLHWN.appendToConf(DIFUSGGOOV);
        Assert.assertTrue(DIFUSGGOOV.getBoolean(APPEND.getConfigLabel(), false));
        Assert.assertTrue(DIFUSGGOOV.getBoolean(SYNC_FOLDERS.getConfigLabel(), false));
        // make sure -append is only valid when -update is specified
        try {
            XAPYEYLHWN = OptionsParser.parse(new String[]{ "-append", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            fail("Append should fail if update option is not specified");
        } catch (IllegalArgumentException e) {
            GenericTestUtils.assertExceptionContains("Append is valid only with update options", e);
        }
        // make sure -append is invalid when skipCrc is specified
        try {
            XAPYEYLHWN = OptionsParser.parse(new String[]{ "-append", "-update", "-skipcrccheck", "hdfs://localhost:8020/source/first", "hdfs://localhost:8020/target/" });
            fail("Append should fail if skipCrc option is specified");
        } catch (IllegalArgumentException e) {
            GenericTestUtils.assertExceptionContains("Append is disallowed when skipping CRC", e);
        }
    }
}