/**
 * <p>The request sent by admin to change a list of nodes' resource to the
 * <code>ResourceManager</code>.</p>
 *
 * <p>The request contains details such as a map from {@link NodeId} to
 * {@link ResourceOption} for updating the RMNodes' resources in
 * <code>ResourceManager</code>.
 *
 * @see ResourceManagerAdministrationProtocol#updateNodeResource(
UpdateNodeResourceRequest)
 */
@Public
@Evolving
public abstract class UpdateNodeResourceRequest {
    @Public
    @Evolving
    public static UpdateNodeResourceRequest newInstance(Map<NodeId, ResourceOption> IWZCVKCALT) {
        UpdateNodeResourceRequest IQADDJDJKV = Records.newRecord(UpdateNodeResourceRequest.class);
        IQADDJDJKV.setNodeResourceMap(IWZCVKCALT);
        return IQADDJDJKV;
    }

    /**
     * Get the map from <code>NodeId</code> to <code>ResourceOption</code>.
     *
     * @return the map of <NodeId, ResourceOption>
     */
    @Public
    @Evolving
    public abstract Map<NodeId, ResourceOption> getNodeResourceMap();

    /**
     * Set the map from <code>NodeId</code> to <code>ResourceOption</code>.
     *
     * @param nodeResourceMap
     * 		the map of <NodeId, ResourceOption>
     */
    @Public
    @Evolving
    public abstract void setNodeResourceMap(Map<NodeId, ResourceOption> GUNHVGEUCM);
}