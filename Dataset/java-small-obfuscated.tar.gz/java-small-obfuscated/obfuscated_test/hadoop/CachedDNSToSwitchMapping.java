/**
 * A cached implementation of DNSToSwitchMapping that takes an
 * raw DNSToSwitchMapping and stores the resolved network location in
 * a cache. The following calls to a resolved network location
 * will get its location from the cache.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class CachedDNSToSwitchMapping extends AbstractDNSToSwitchMapping {
    private Map<String, String> LCTVGCFXNC = new ConcurrentHashMap<String, String>();

    /**
     * The uncached mapping
     */
    protected final DNSToSwitchMapping KNDIARYYNZ;

    /**
     * cache a raw DNS mapping
     *
     * @param rawMapping
     * 		the raw mapping to cache
     */
    public CachedDNSToSwitchMapping(DNSToSwitchMapping WGRWCLWVPK) {
        this.KNDIARYYNZ = WGRWCLWVPK;
    }

    /**
     *
     *
     * @param names
     * 		a list of hostnames to probe for being cached
     * @return the hosts from 'names' that have not been cached previously
     */
    private List<String> getUncachedHosts(List<String> ODCRWVWMYY) {
        // find out all names without cached resolved location
        List<String> SKNLQHDCKB = new ArrayList<String>(ODCRWVWMYY.size());
        for (String SVYSRORBLY : ODCRWVWMYY) {
            if (LCTVGCFXNC.get(SVYSRORBLY) == null) {
                SKNLQHDCKB.add(SVYSRORBLY);
            }
        }
        return SKNLQHDCKB;
    }

    /**
     * Caches the resolved host:rack mappings. The two list
     * parameters must be of equal size.
     *
     * @param uncachedHosts
     * 		a list of hosts that were uncached
     * @param resolvedHosts
     * 		a list of resolved host entries where the element
     * 		at index(i) is the resolved value for the entry in uncachedHosts[i]
     */
    private void cacheResolvedHosts(List<String> PHTUQZTWKO, List<String> WKYLXINTAY) {
        // Cache the result
        if (WKYLXINTAY != null) {
            for (int HEWJDJPRPY = 0; HEWJDJPRPY < PHTUQZTWKO.size(); HEWJDJPRPY++) {
                LCTVGCFXNC.put(PHTUQZTWKO.get(HEWJDJPRPY), WKYLXINTAY.get(HEWJDJPRPY));
            }
        }
    }

    /**
     *
     *
     * @param names
     * 		a list of hostnames to look up (can be be empty)
     * @return the cached resolution of the list of hostnames/addresses.
    or null if any of the names are not currently in the cache
     */
    private List<String> getCachedHosts(List<String> CNXSLMTJXN) {
        List<String> QRQULEVFXJ = new ArrayList<String>(CNXSLMTJXN.size());
        // Construct the result
        for (String LLXAGRBQLS : CNXSLMTJXN) {
            String MISZOMNKTM = LCTVGCFXNC.get(LLXAGRBQLS);
            if (MISZOMNKTM != null) {
                QRQULEVFXJ.add(MISZOMNKTM);
            } else {
                return null;
            }
        }
        return QRQULEVFXJ;
    }

    @Override
    public List<String> resolve(List<String> EFHYQAJTRB) {
        // normalize all input names to be in the form of IP addresses
        EFHYQAJTRB = NetUtils.normalizeHostNames(EFHYQAJTRB);
        List<String> AJBBBUHYEZ = new ArrayList<String>(EFHYQAJTRB.size());
        if (EFHYQAJTRB.isEmpty()) {
            return AJBBBUHYEZ;
        }
        List<String> XKTMHAEUXE = getUncachedHosts(EFHYQAJTRB);
        // Resolve the uncached hosts
        List<String> WIVJTOAVKF = KNDIARYYNZ.resolve(XKTMHAEUXE);
        // cache them
        cacheResolvedHosts(XKTMHAEUXE, WIVJTOAVKF);
        // now look up the entire list in the cache
        return getCachedHosts(EFHYQAJTRB);
    }

    /**
     * Get the (host x switch) map.
     *
     * @return a copy of the cached map of hosts to rack
     */
    @Override
    public Map<String, String> getSwitchMap() {
        Map<String, String> RWYSSISXVR = new HashMap<String, String>(LCTVGCFXNC);
        return RWYSSISXVR;
    }

    @Override
    public String toString() {
        return "cached switch mapping relaying to " + KNDIARYYNZ;
    }

    /**
     * Delegate the switch topology query to the raw mapping, via
     * {@link AbstractDNSToSwitchMapping#isMappingSingleSwitch(DNSToSwitchMapping)}
     *
     * @return true iff the raw mapper is considered single-switch.
     */
    @Override
    public boolean isSingleSwitch() {
        return isMappingSingleSwitch(KNDIARYYNZ);
    }

    @Override
    public void reloadCachedMappings() {
        LCTVGCFXNC.clear();
    }

    @Override
    public void reloadCachedMappings(List<String> RJRHWNAWMS) {
        for (String QPGVYIPDLD : RJRHWNAWMS) {
            LCTVGCFXNC.remove(QPGVYIPDLD);
        }
    }
}