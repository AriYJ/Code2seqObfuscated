@Provider
@Produces(MediaType.APPLICATION_JSON)
@InterfaceAudience.Private
public class JSONMapProvider implements MessageBodyWriter<Map> {
    private static final String ITOVSSKHPX = System.getProperty("line.separator");

    @Override
    public boolean isWriteable(Class<?> HTLIQDJGUA, Type TEYBSRJWGO, Annotation[] LDJNUJQYKE, MediaType AIQHGZGKSG) {
        return Map.class.isAssignableFrom(HTLIQDJGUA);
    }

    @Override
    public long getSize(Map BZRSWSGINO, Class<?> YFYRSKSETO, Type BYTAAQZSEK, Annotation[] CZJYZUBOKT, MediaType GHWEOJQSDN) {
        return -1;
    }

    @Override
    public void writeTo(Map FINJOEOIQA, Class<?> PEYPCNJFZV, Type YWFRYPLKRV, Annotation[] DFNUGQLBGR, MediaType LLNLOOCOEX, MultivaluedMap<String, Object> DFWCNSMPJI, OutputStream RKHDOGNUXZ) throws IOException, WebApplicationException {
        Writer UXFCNZADVL = new OutputStreamWriter(RKHDOGNUXZ);
        JSONObject.writeJSONString(FINJOEOIQA, UXFCNZADVL);
        UXFCNZADVL.write(JSONMapProvider.ITOVSSKHPX);
        UXFCNZADVL.flush();
    }
}