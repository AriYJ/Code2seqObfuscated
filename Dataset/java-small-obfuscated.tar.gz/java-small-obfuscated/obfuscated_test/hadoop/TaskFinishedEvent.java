/**
 * Event to record the successful completion of a task
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class TaskFinishedEvent implements HistoryEvent {
    private TaskFinished MYQGGLHRTV = null;

    private TaskID ACKXRPCQLD;

    private TaskAttemptID SRMKKDZJAU;

    private long KWOLCFMXUY;

    private TaskType PONAXUXAIR;

    private String WPHQYSUCKS;

    private Counters HTYLDMCXQH;

    /**
     * Create an event to record the successful completion of a task
     *
     * @param id
     * 		Task ID
     * @param attemptId
     * 		Task Attempt ID of the successful attempt for this task
     * @param finishTime
     * 		Finish time of the task
     * @param taskType
     * 		Type of the task
     * @param status
     * 		Status string
     * @param counters
     * 		Counters for the task
     */
    public TaskFinishedEvent(TaskID RJUVWEFFVZ, TaskAttemptID LKDHKTVJVS, long RSZGZIICOG, TaskType POTZXIOKVC, String BXJQHUXITJ, Counters CVFNZQHEIT) {
        this.ACKXRPCQLD = RJUVWEFFVZ;
        this.SRMKKDZJAU = LKDHKTVJVS;
        this.KWOLCFMXUY = RSZGZIICOG;
        this.PONAXUXAIR = POTZXIOKVC;
        this.WPHQYSUCKS = BXJQHUXITJ;
        this.HTYLDMCXQH = CVFNZQHEIT;
    }

    TaskFinishedEvent() {
    }

    public Object getDatum() {
        if (MYQGGLHRTV == null) {
            MYQGGLHRTV = new TaskFinished();
            MYQGGLHRTV.taskid = new Utf8(ACKXRPCQLD.toString());
            if (SRMKKDZJAU != null) {
                MYQGGLHRTV.successfulAttemptId = new Utf8(SRMKKDZJAU.toString());
            }
            MYQGGLHRTV.finishTime = KWOLCFMXUY;
            MYQGGLHRTV.counters = EventWriter.toAvro(HTYLDMCXQH);
            MYQGGLHRTV.taskType = new Utf8(PONAXUXAIR.name());
            MYQGGLHRTV.status = new Utf8(WPHQYSUCKS);
        }
        return MYQGGLHRTV;
    }

    public void setDatum(Object NUGDIABNNJ) {
        this.MYQGGLHRTV = ((TaskFinished) (NUGDIABNNJ));
        this.ACKXRPCQLD = TaskID.forName(MYQGGLHRTV.taskid.toString());
        if (MYQGGLHRTV.successfulAttemptId != null) {
            this.SRMKKDZJAU = TaskAttemptID.forName(MYQGGLHRTV.successfulAttemptId.toString());
        }
        this.KWOLCFMXUY = MYQGGLHRTV.finishTime;
        this.PONAXUXAIR = TaskType.valueOf(MYQGGLHRTV.taskType.toString());
        this.WPHQYSUCKS = MYQGGLHRTV.status.toString();
        this.HTYLDMCXQH = EventReader.fromAvro(MYQGGLHRTV.counters);
    }

    /**
     * Get task id
     */
    public TaskID getTaskId() {
        return ACKXRPCQLD;
    }

    /**
     * Get successful task attempt id
     */
    public TaskAttemptID getSuccessfulTaskAttemptId() {
        return SRMKKDZJAU;
    }

    /**
     * Get the task finish time
     */
    public long getFinishTime() {
        return KWOLCFMXUY;
    }

    /**
     * Get task counters
     */
    public Counters getCounters() {
        return HTYLDMCXQH;
    }

    /**
     * Get task type
     */
    public TaskType getTaskType() {
        return PONAXUXAIR;
    }

    /**
     * Get task status
     */
    public String getTaskStatus() {
        return WPHQYSUCKS.toString();
    }

    /**
     * Get event type
     */
    public EventType getEventType() {
        return EventType.TASK_FINISHED;
    }
}