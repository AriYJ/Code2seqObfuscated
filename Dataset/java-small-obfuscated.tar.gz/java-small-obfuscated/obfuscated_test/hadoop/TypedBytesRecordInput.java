/**
 * Serializer for records that writes typed bytes.
 */
public class TypedBytesRecordInput implements RecordInput {
    private TypedBytesInput JSMUIJJTWS;

    private TypedBytesRecordInput() {
    }

    private void setTypedBytesInput(TypedBytesInput HDXGQQHBWP) {
        this.JSMUIJJTWS = HDXGQQHBWP;
    }

    private static ThreadLocal GFJVVVRFLR = new ThreadLocal() {
        protected synchronized Object initialValue() {
            return new TypedBytesRecordInput();
        }
    };

    /**
     * Get a thread-local typed bytes record input for the supplied
     * {@link TypedBytesInput}.
     *
     * @param in
     * 		typed bytes input object
     * @return typed bytes record input corresponding to the supplied
    {@link TypedBytesInput}.
     */
    public static TypedBytesRecordInput get(TypedBytesInput UHVDIKFVYM) {
        TypedBytesRecordInput QCXVYYTSDT = ((TypedBytesRecordInput) (TypedBytesRecordInput.GFJVVVRFLR.get()));
        QCXVYYTSDT.setTypedBytesInput(UHVDIKFVYM);
        return QCXVYYTSDT;
    }

    /**
     * Get a thread-local typed bytes record input for the supplied
     * {@link DataInput}.
     *
     * @param in
     * 		data input object
     * @return typed bytes record input corresponding to the supplied
    {@link DataInput}.
     */
    public static TypedBytesRecordInput get(DataInput ZXPICKAAMM) {
        return TypedBytesRecordInput.get(TypedBytesInput.get(ZXPICKAAMM));
    }

    /**
     * Creates a new instance of TypedBytesRecordInput.
     */
    public TypedBytesRecordInput(TypedBytesInput TSWTKZEZME) {
        this.JSMUIJJTWS = TSWTKZEZME;
    }

    /**
     * Creates a new instance of TypedBytesRecordInput.
     */
    public TypedBytesRecordInput(DataInput HSDPNJKALW) {
        this(new TypedBytesInput(HSDPNJKALW));
    }

    public boolean readBool(String EANSBQBMWT) throws IOException {
        JSMUIJJTWS.skipType();
        return JSMUIJJTWS.readBool();
    }

    public Buffer readBuffer(String NBCTQXYFFY) throws IOException {
        JSMUIJJTWS.skipType();
        return new Buffer(JSMUIJJTWS.readBytes());
    }

    public byte readByte(String LDCHTFRBCW) throws IOException {
        JSMUIJJTWS.skipType();
        return JSMUIJJTWS.readByte();
    }

    public double readDouble(String JXNEUHXBAR) throws IOException {
        JSMUIJJTWS.skipType();
        return JSMUIJJTWS.readDouble();
    }

    public float readFloat(String PSEBIEYNAQ) throws IOException {
        JSMUIJJTWS.skipType();
        return JSMUIJJTWS.readFloat();
    }

    public int readInt(String UBHNPQIWNC) throws IOException {
        JSMUIJJTWS.skipType();
        return JSMUIJJTWS.readInt();
    }

    public long readLong(String LMENGCWADQ) throws IOException {
        JSMUIJJTWS.skipType();
        return JSMUIJJTWS.readLong();
    }

    public String readString(String ZYUILYKEJE) throws IOException {
        JSMUIJJTWS.skipType();
        return JSMUIJJTWS.readString();
    }

    public void startRecord(String QDLRXSFBDI) throws IOException {
        JSMUIJJTWS.skipType();
    }

    public Index startVector(String FOIMECTRHK) throws IOException {
        JSMUIJJTWS.skipType();
        return new TypedBytesRecordInput.TypedBytesIndex(JSMUIJJTWS.readVectorHeader());
    }

    public Index startMap(String YBWNVWLIDF) throws IOException {
        JSMUIJJTWS.skipType();
        return new TypedBytesRecordInput.TypedBytesIndex(JSMUIJJTWS.readMapHeader());
    }

    public void endRecord(String DPYWPECWNY) throws IOException {
    }

    public void endVector(String DXBOTOTDWO) throws IOException {
    }

    public void endMap(String VDHVMPZVZF) throws IOException {
    }

    private static final class TypedBytesIndex implements Index {
        private int WDUZLHLUFZ;

        private TypedBytesIndex(int nelems) {
            this.WDUZLHLUFZ = nelems;
        }

        public boolean done() {
            return WDUZLHLUFZ <= 0;
        }

        public void incr() {
            WDUZLHLUFZ--;
        }
    }
}