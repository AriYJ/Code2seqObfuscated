public class TestSortedRanges extends TestCase {
    private static final Log FLPZQOMAOI = LogFactory.getLog(TestSortedRanges.class);

    public void testAdd() {
        SortedRanges IUJFCICZYP = new SortedRanges();
        IUJFCICZYP.add(new Range(2, 9));
        assertEquals(9, IUJFCICZYP.getIndicesCount());
        IUJFCICZYP.add(new SortedRanges.Range(3, 5));
        assertEquals(9, IUJFCICZYP.getIndicesCount());
        IUJFCICZYP.add(new SortedRanges.Range(7, 1));
        assertEquals(9, IUJFCICZYP.getIndicesCount());
        IUJFCICZYP.add(new Range(1, 12));
        assertEquals(12, IUJFCICZYP.getIndicesCount());
        IUJFCICZYP.add(new Range(7, 9));
        assertEquals(15, IUJFCICZYP.getIndicesCount());
        IUJFCICZYP.add(new Range(31, 10));
        IUJFCICZYP.add(new Range(51, 10));
        IUJFCICZYP.add(new Range(66, 10));
        assertEquals(45, IUJFCICZYP.getIndicesCount());
        IUJFCICZYP.add(new Range(21, 50));
        assertEquals(70, IUJFCICZYP.getIndicesCount());
        TestSortedRanges.FLPZQOMAOI.debug(IUJFCICZYP);
        Iterator<Long> NNDAZQKDRW = IUJFCICZYP.skipRangeIterator();
        int AYIMLFFAIG = 0;
        assertEquals(AYIMLFFAIG, NNDAZQKDRW.next().longValue());
        for (AYIMLFFAIG = 16; AYIMLFFAIG < 21; AYIMLFFAIG++) {
            assertEquals(AYIMLFFAIG, NNDAZQKDRW.next().longValue());
        }
        assertEquals(76, NNDAZQKDRW.next().longValue());
        assertEquals(77, NNDAZQKDRW.next().longValue());
    }

    public void testRemove() {
        SortedRanges IASFNBZSOB = new SortedRanges();
        IASFNBZSOB.add(new Range(2, 19));
        assertEquals(19, IASFNBZSOB.getIndicesCount());
        IASFNBZSOB.remove(new SortedRanges.Range(15, 8));
        assertEquals(13, IASFNBZSOB.getIndicesCount());
        IASFNBZSOB.remove(new SortedRanges.Range(6, 5));
        assertEquals(8, IASFNBZSOB.getIndicesCount());
        IASFNBZSOB.remove(new SortedRanges.Range(8, 4));
        assertEquals(7, IASFNBZSOB.getIndicesCount());
        IASFNBZSOB.add(new Range(18, 5));
        assertEquals(12, IASFNBZSOB.getIndicesCount());
        IASFNBZSOB.add(new Range(25, 1));
        assertEquals(13, IASFNBZSOB.getIndicesCount());
        IASFNBZSOB.remove(new SortedRanges.Range(7, 24));
        assertEquals(4, IASFNBZSOB.getIndicesCount());
        IASFNBZSOB.remove(new SortedRanges.Range(5, 1));
        assertEquals(3, IASFNBZSOB.getIndicesCount());
        TestSortedRanges.FLPZQOMAOI.debug(IASFNBZSOB);
    }
}