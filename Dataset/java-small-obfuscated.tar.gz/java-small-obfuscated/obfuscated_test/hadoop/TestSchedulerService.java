public class TestSchedulerService extends HTestCase {
    @Test
    @TestDir
    public void service() throws Exception {
        String AIHNZRSSNK = org.apache.hadoop.test.TestDirHelper.getTestDir().getAbsolutePath();
        Configuration FWBETKUBRG = new Configuration(false);
        FWBETKUBRG.set("server.services", StringUtils.join(",", Arrays.asList(InstrumentationService.class.getName(), SchedulerService.class.getName())));
        Server CYTAMPGTEJ = new Server("server", AIHNZRSSNK, AIHNZRSSNK, AIHNZRSSNK, AIHNZRSSNK, FWBETKUBRG);
        CYTAMPGTEJ.init();
        assertNotNull(CYTAMPGTEJ.get(Scheduler.class));
        CYTAMPGTEJ.destroy();
    }
}