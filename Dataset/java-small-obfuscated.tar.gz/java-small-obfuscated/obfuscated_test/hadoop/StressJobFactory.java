public class StressJobFactory extends JobFactory<Statistics.ClusterStats> {
    public static final Log RJDZWCRTKZ = LogFactory.getLog(StressJobFactory.class);

    private final StressJobFactory.LoadStatus ZIZFMAQOPK = new StressJobFactory.LoadStatus();

    /**
     * The minimum ratio between pending+running map tasks (aka. incomplete map
     * tasks) and cluster map slot capacity for us to consider the cluster is
     * overloaded. For running maps, we only count them partially. Namely, a 40%
     * completed map is counted as 0.6 map tasks in our calculation.
     */
    private static final float DRCHPPQWKJ = 2.0F;

    public static final String ETUGYDOHDU = "gridmix.throttle.maps.task-to-slot-ratio";

    final float XRRZBLTJKZ;

    /**
     * The minimum ratio between pending+running reduce tasks (aka. incomplete
     * reduce tasks) and cluster reduce slot capacity for us to consider the
     * cluster is overloaded. For running reduces, we only count them partially.
     * Namely, a 40% completed reduce is counted as 0.6 reduce tasks in our
     * calculation.
     */
    private static final float GPVRUBJCLR = 2.5F;

    public static final String ZGPURQMEDJ = "gridmix.throttle.reduces.task-to-slot-ratio";

    final float ZHWCILJJGU;

    /**
     * The maximum share of the cluster's mapslot capacity that can be counted
     * toward a job's incomplete map tasks in overload calculation.
     */
    private static final float PXQQIMSLCW = 0.1F;

    public static final String SMRMDEKYHU = "gridmix.throttle.maps.max-slot-share-per-job";

    final float VGYAJGNOCX;

    /**
     * The maximum share of the cluster's reduceslot capacity that can be counted
     * toward a job's incomplete reduce tasks in overload calculation.
     */
    private static final float EFLRILEXES = 0.1F;

    public static final String CKNRTAACFN = "gridmix.throttle.reducess.max-slot-share-per-job";

    final float IWHCTUAVJL;

    /**
     * The ratio of the maximum number of pending+running jobs over the number of
     * task trackers.
     */
    private static final float HKJXYBBTOM = 1.0F;

    public static final String AOKNCQYFUX = "gridmix.throttle.jobs-to-tracker-ratio";

    final float BAVGKSPSYZ;

    /**
     * Represents a list of blacklisted jobs. Jobs are blacklisted when either
     * they are complete or their status cannot be obtained. Stress mode will
     * ignore blacklisted jobs from its overload computation.
     */
    private Set<JobID> ZTMYHJJKDD = new HashSet<JobID>();

    /**
     * Creating a new instance does not start the thread.
     *
     * @param submitter
     * 		Component to which deserialized jobs are passed
     * @param jobProducer
     * 		Stream of job traces with which to construct a
     * 		{@link org.apache.hadoop.tools.rumen.ZombieJobProducer}
     * @param scratch
     * 		Directory into which to write output from simulated jobs
     * @param conf
     * 		Config passed to all jobs to be submitted
     * @param startFlag
     * 		Latch released from main to start pipeline
     * @throws java.io.IOException
     * 		
     */
    public StressJobFactory(JobSubmitter ZWTAUIAQKA, JobStoryProducer NXCRASJSVA, Path PBYBUIDPAP, Configuration QEMPZXXQZY, CountDownLatch QBLMHTBXDH, UserResolver CFWADIQOZC) throws IOException {
        super(ZWTAUIAQKA, NXCRASJSVA, PBYBUIDPAP, QEMPZXXQZY, QBLMHTBXDH, CFWADIQOZC);
        XRRZBLTJKZ = QEMPZXXQZY.getFloat(StressJobFactory.ETUGYDOHDU, StressJobFactory.DRCHPPQWKJ);
        ZHWCILJJGU = QEMPZXXQZY.getFloat(StressJobFactory.ZGPURQMEDJ, StressJobFactory.GPVRUBJCLR);
        VGYAJGNOCX = QEMPZXXQZY.getFloat(StressJobFactory.SMRMDEKYHU, StressJobFactory.PXQQIMSLCW);
        IWHCTUAVJL = QEMPZXXQZY.getFloat(StressJobFactory.CKNRTAACFN, StressJobFactory.EFLRILEXES);
        BAVGKSPSYZ = QEMPZXXQZY.getFloat(StressJobFactory.AOKNCQYFUX, StressJobFactory.HKJXYBBTOM);
    }

    public Thread createReaderThread() {
        return new StressJobFactory.StressReaderThread("StressJobFactory");
    }

    /* Worker thread responsible for reading descriptions, assigning sequence
    numbers, and normalizing time.
     */
    private class StressReaderThread extends Thread {
        public StressReaderThread(String name) {
            super(name);
        }

        /**
         * STRESS: Submits the job in STRESS mode.
         * while(JT is overloaded) {
         * wait();
         * }
         * If not overloaded , get number of slots available.
         * Keep submitting the jobs till ,total jobs  is sufficient to
         * load the JT.
         * That is submit  (Sigma(no of maps/Job)) > (2 * no of slots available)
         */
        public void run() {
            try {
                startFlag.await();
                if (Thread.currentThread().isInterrupted()) {
                    StressJobFactory.RJDZWCRTKZ.warn("[STRESS] Interrupted before start!. Exiting..");
                    return;
                }
                StressJobFactory.RJDZWCRTKZ.info("START STRESS @ " + System.currentTimeMillis());
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        while (ZIZFMAQOPK.overloaded()) {
                            // update the overload status
                            if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                                StressJobFactory.RJDZWCRTKZ.debug("Updating the overload status.");
                            }
                            try {
                                checkLoadAndGetSlotsToBackfill();
                            } catch (IOException ioe) {
                                StressJobFactory.RJDZWCRTKZ.warn("[STRESS] Check failed!", ioe);
                                return;
                            }
                            // if the cluster is still overloaded, then sleep
                            if (ZIZFMAQOPK.overloaded()) {
                                if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                                    StressJobFactory.RJDZWCRTKZ.debug("[STRESS] Cluster overloaded in run! Sleeping...");
                                }
                                // sleep
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException ie) {
                                    StressJobFactory.RJDZWCRTKZ.warn("[STRESS] Interrupted while sleeping! Exiting.", ie);
                                    return;
                                }
                            }
                        } 
                        while (!ZIZFMAQOPK.overloaded()) {
                            if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                                StressJobFactory.RJDZWCRTKZ.debug("[STRESS] Cluster underloaded in run! Stressing...");
                            }
                            try {
                                // TODO This in-line read can block submission for large jobs.
                                final JobStory job = getNextJobFiltered();
                                if (null == job) {
                                    StressJobFactory.RJDZWCRTKZ.warn("[STRESS] Finished consuming the input trace. " + "Exiting..");
                                    return;
                                }
                                if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                                    StressJobFactory.RJDZWCRTKZ.debug("Job Selected: " + job.getJobID());
                                }
                                UserGroupInformation ugi = UserGroupInformation.createRemoteUser(job.getUser());
                                UserGroupInformation tgtUgi = userResolver.getTargetUgi(ugi);
                                GridmixJob tJob = jobCreator.createGridmixJob(conf, 0L, job, scratch, tgtUgi, sequence.getAndIncrement());
                                // submit the job
                                submitter.add(tJob);
                                // TODO: We need to take care of scenario when one map/reduce
                                // takes more than 1 slot.
                                // Lock the loadjob as we are making updates
                                int incompleteMapTasks = ((int) (calcEffectiveIncompleteMapTasks(ZIZFMAQOPK.getMapCapacity(), job.getNumberMaps(), 0.0F)));
                                ZIZFMAQOPK.decrementMapLoad(incompleteMapTasks);
                                int incompleteReduceTasks = ((int) (calcEffectiveIncompleteReduceTasks(ZIZFMAQOPK.getReduceCapacity(), job.getNumberReduces(), 0.0F)));
                                ZIZFMAQOPK.decrementReduceLoad(incompleteReduceTasks);
                                ZIZFMAQOPK.decrementJobLoad(1);
                            } catch (IOException e) {
                                StressJobFactory.RJDZWCRTKZ.error("[STRESS] Error while submitting the job ", e);
                                error = e;
                                return;
                            }
                        } 
                    } finally {
                        // do nothing
                    }
                } 
            } catch (InterruptedException e) {
                StressJobFactory.RJDZWCRTKZ.error("[STRESS] Interrupted in the main block!", e);
                return;
            } finally {
                IOUtils.cleanup(null, jobProducer);
            }
        }
    }

    /**
     * STRESS Once you get the notification from StatsCollector.Collect the
     * clustermetrics. Update current loadStatus with new load status of JT.
     *
     * @param item
     * 		
     */
    @Override
    public void update(Statistics.ClusterStats EIHKJCPXUC) {
        ClusterStatus MFDXJQOSLV = EIHKJCPXUC.getStatus();
        try {
            // update the max cluster map/reduce task capacity
            ZIZFMAQOPK.updateMapCapacity(MFDXJQOSLV.getMaxMapTasks());
            ZIZFMAQOPK.updateReduceCapacity(MFDXJQOSLV.getMaxReduceTasks());
            int EQVOMZNAUG = MFDXJQOSLV.getTaskTrackers();
            int DHYZDRDGPT = ((int) (BAVGKSPSYZ * EQVOMZNAUG)) - EIHKJCPXUC.getNumRunningJob();
            ZIZFMAQOPK.updateJobLoad(DHYZDRDGPT);
        } catch (Exception e) {
            StressJobFactory.RJDZWCRTKZ.error("Couldn't get the new Status", e);
        }
    }

    float calcEffectiveIncompleteMapTasks(int VGOWWSZUST, int BDUFCTEDNG, float CGFENOGTJM) {
        float YVEECEVEPA = Math.max(1.0F, VGOWWSZUST * VGYAJGNOCX);
        float LHEXQSQCKJ = Math.max(Math.min(CGFENOGTJM, 1.0F), 0.0F);
        return Math.min(YVEECEVEPA, BDUFCTEDNG * (1.0F - LHEXQSQCKJ));
    }

    float calcEffectiveIncompleteReduceTasks(int DBFYJZOZWA, int CMORDCFBAP, float MEHUXGKFDM) {
        float TXMOVPKKRE = Math.max(1.0F, DBFYJZOZWA * IWHCTUAVJL);
        float CFVSYVOLBB = Math.max(Math.min(MEHUXGKFDM, 1.0F), 0.0F);
        return Math.min(TXMOVPKKRE, CMORDCFBAP * (1.0F - CFVSYVOLBB));
    }

    /**
     * We try to use some light-weight mechanism to determine cluster load.
     *
     * @throws java.io.IOException
     * 		
     */
    protected void checkLoadAndGetSlotsToBackfill() throws IOException, InterruptedException {
        if (ZIZFMAQOPK.getJobLoad() <= 0) {
            if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                StressJobFactory.RJDZWCRTKZ.debug((((System.currentTimeMillis() + " [JobLoad] Overloaded is ") + Boolean.TRUE.toString()) + " NumJobsBackfill is ") + ZIZFMAQOPK.getJobLoad());
            }
            return;// stop calculation because we know it is overloaded.

        }
        int UMXQCBKWCU = ZIZFMAQOPK.getMapCapacity();
        int XBOIMQGGLT = ZIZFMAQOPK.getReduceCapacity();
        // return if the cluster status is not set
        if ((UMXQCBKWCU < 0) || (XBOIMQGGLT < 0)) {
            // note that, by default, the overload status is true
            // missing cluster status will result into blocking of job submission
            return;
        }
        // Determine the max permissible map & reduce task load
        int OGIHOWWINP = ((int) (XRRZBLTJKZ * UMXQCBKWCU));
        int MDBIQCZFEE = ((int) (ZHWCILJJGU * XBOIMQGGLT));
        // compute the total number of map & reduce tasks submitted
        int ZQZIQXOGJI = ClusterStats.getSubmittedMapTasks();
        int TUGWWECSNA = ClusterStats.getSubmittedReduceTasks();
        if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
            StressJobFactory.RJDZWCRTKZ.debug("Total submitted map tasks: " + ZQZIQXOGJI);
            StressJobFactory.RJDZWCRTKZ.debug("Total submitted reduce tasks: " + TUGWWECSNA);
            StressJobFactory.RJDZWCRTKZ.debug("Max map load: " + OGIHOWWINP);
            StressJobFactory.RJDZWCRTKZ.debug("Max reduce load: " + MDBIQCZFEE);
        }
        // generate a pessimistic bound on the max running+pending map tasks
        // this check is to avoid the heavy-duty actual map load calculation
        int FZLSWPERJY = ((int) (OGIHOWWINP - ZQZIQXOGJI));
        // generate a pessimistic bound on the max running+pending reduce tasks
        // this check is to avoid the heavy-duty actual reduce load calculation
        int VLBPEALABA = ((int) (MDBIQCZFEE - TUGWWECSNA));
        // maintain a list of seen job ids
        Set<JobID> CDFZZQVZPJ = new HashSet<JobID>();
        // check if the total number of submitted map/reduce tasks exceeds the
        // permissible limit
        if ((ZQZIQXOGJI > OGIHOWWINP) || (TUGWWECSNA > MDBIQCZFEE)) {
            // if yes, calculate the real load
            float LOMDQZSDZF = 0;// include pending & running map tasks.

            float GTMOVAZRMD = 0;// include pending & running reduce tasks

            for (JobStats LOQWKAXKHM : ClusterStats.getRunningJobStats()) {
                JobID MMRJOHBHTM = LOQWKAXKHM.getJob().getJobID();
                CDFZZQVZPJ.add(MMRJOHBHTM);
                // Note that this is a hack! Ideally, ClusterStats.getRunningJobStats()
                // should be smart enough to take care of completed jobs.
                if (ZTMYHJJKDD.contains(MMRJOHBHTM)) {
                    StressJobFactory.RJDZWCRTKZ.warn("Ignoring blacklisted job: " + MMRJOHBHTM);
                    continue;
                }
                int QRNQNTOBME = LOQWKAXKHM.getNoOfMaps();
                int BIWWLPHHJC = LOQWKAXKHM.getNoOfReds();
                // consider polling for jobs where maps>0 and reds>0
                // TODO: What about setup/cleanup tasks for cases where m=0 and r=0
                // What otherwise?
                if ((QRNQNTOBME > 0) || (BIWWLPHHJC > 0)) {
                    // get the job's status
                    JobStatus HKIKAELGGO = LOQWKAXKHM.getJobStatus();
                    // blacklist completed jobs and continue
                    if ((HKIKAELGGO != null) && HKIKAELGGO.isJobComplete()) {
                        StressJobFactory.RJDZWCRTKZ.warn("Blacklisting completed job: " + MMRJOHBHTM);
                        ZTMYHJJKDD.add(MMRJOHBHTM);
                        continue;
                    }
                    // get the map and reduce tasks' progress
                    float SMTILEAWEV = 0.0F;
                    float BBATTLBAMT = 0.0F;
                    // check if the status is missing (this can happen for unpolled jobs)
                    if (HKIKAELGGO != null) {
                        SMTILEAWEV = HKIKAELGGO.getMapProgress();
                        BBATTLBAMT = HKIKAELGGO.getReduceProgress();
                    }
                    LOMDQZSDZF += calcEffectiveIncompleteMapTasks(UMXQCBKWCU, QRNQNTOBME, SMTILEAWEV);
                    // bail out early
                    int TOORNLLVUE = ((int) (OGIHOWWINP - LOMDQZSDZF));
                    if (TOORNLLVUE <= 0) {
                        // reset the reduce task load since we are bailing out
                        GTMOVAZRMD = TUGWWECSNA;
                        if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                            StressJobFactory.RJDZWCRTKZ.debug("Terminating overload check due to high map load.");
                        }
                        break;
                    }
                    // compute the real reduce load
                    if (BIWWLPHHJC > 0) {
                        GTMOVAZRMD += calcEffectiveIncompleteReduceTasks(XBOIMQGGLT, BIWWLPHHJC, BBATTLBAMT);
                    }
                    // bail out early
                    int GZCNMVBBBE = ((int) (MDBIQCZFEE - GTMOVAZRMD));
                    if (GZCNMVBBBE <= 0) {
                        // reset the map task load since we are bailing out
                        LOMDQZSDZF = ZQZIQXOGJI;
                        if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                            StressJobFactory.RJDZWCRTKZ.debug("Terminating overload check due to high reduce load.");
                        }
                        break;
                    }
                } else {
                    StressJobFactory.RJDZWCRTKZ.warn("Blacklisting empty job: " + MMRJOHBHTM);
                    ZTMYHJJKDD.add(MMRJOHBHTM);
                }
            }
            // calculate the real map load on the cluster
            FZLSWPERJY = ((int) (OGIHOWWINP - LOMDQZSDZF));
            // calculate the real reduce load on the cluster
            VLBPEALABA = ((int) (MDBIQCZFEE - GTMOVAZRMD));
            // clean up the backlisted set to keep the memory footprint minimal
            // retain only the jobs that are seen in this cycle
            ZTMYHJJKDD.retainAll(CDFZZQVZPJ);
            if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled() && (ZTMYHJJKDD.size() > 0)) {
                StressJobFactory.RJDZWCRTKZ.debug("Blacklisted jobs count: " + ZTMYHJJKDD.size());
            }
        }
        // update
        ZIZFMAQOPK.updateMapLoad(FZLSWPERJY);
        ZIZFMAQOPK.updateReduceLoad(VLBPEALABA);
        if (ZIZFMAQOPK.getMapLoad() <= 0) {
            if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                StressJobFactory.RJDZWCRTKZ.debug((((System.currentTimeMillis() + " [MAP-LOAD] Overloaded is ") + Boolean.TRUE.toString()) + " MapSlotsBackfill is ") + ZIZFMAQOPK.getMapLoad());
            }
            return;// stop calculation because we know it is overloaded.

        }
        if (ZIZFMAQOPK.getReduceLoad() <= 0) {
            if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
                StressJobFactory.RJDZWCRTKZ.debug((((System.currentTimeMillis() + " [REDUCE-LOAD] Overloaded is ") + Boolean.TRUE.toString()) + " ReduceSlotsBackfill is ") + ZIZFMAQOPK.getReduceLoad());
            }
            return;// stop calculation because we know it is overloaded.

        }
        if (StressJobFactory.RJDZWCRTKZ.isDebugEnabled()) {
            StressJobFactory.RJDZWCRTKZ.debug((((System.currentTimeMillis() + " [OVERALL] Overloaded is ") + Boolean.FALSE.toString()) + "Current load Status is ") + ZIZFMAQOPK);
        }
    }

    static class LoadStatus {
        /**
         * Additional number of map slots that can be requested before
         * declaring (by Gridmix STRESS mode) the cluster as overloaded.
         */
        private volatile int HXDVLJYCLR;

        /**
         * Determines the total map slot capacity of the cluster.
         */
        private volatile int HJOMRYPHWN;

        /**
         * Additional number of reduce slots that can be requested before
         * declaring (by Gridmix STRESS mode) the cluster as overloaded.
         */
        private volatile int VNRIUNZYKR;

        /**
         * Determines the total reduce slot capacity of the cluster.
         */
        private volatile int HFXJXBGHXB;

        /**
         * Determines the max count of running jobs in the cluster.
         */
        private volatile int VTTKKMBDYZ;

        // set the default to true
        private AtomicBoolean XKCXMQYLPI = new AtomicBoolean(true);

        /**
         * Construct the LoadStatus in an unknown state - assuming the cluster is
         * overloaded by setting numSlotsBackfill=0.
         */
        LoadStatus() {
            HXDVLJYCLR = 0;
            VNRIUNZYKR = 0;
            VTTKKMBDYZ = 0;
            HJOMRYPHWN = -1;
            HFXJXBGHXB = -1;
        }

        public synchronized int getMapLoad() {
            return HXDVLJYCLR;
        }

        public synchronized int getMapCapacity() {
            return HJOMRYPHWN;
        }

        public synchronized int getReduceLoad() {
            return VNRIUNZYKR;
        }

        public synchronized int getReduceCapacity() {
            return HFXJXBGHXB;
        }

        public synchronized int getJobLoad() {
            return VTTKKMBDYZ;
        }

        public synchronized void decrementMapLoad(int mapSlotsConsumed) {
            this.HXDVLJYCLR -= mapSlotsConsumed;
            updateOverloadStatus();
        }

        public synchronized void decrementReduceLoad(int reduceSlotsConsumed) {
            this.VNRIUNZYKR -= reduceSlotsConsumed;
            updateOverloadStatus();
        }

        public synchronized void decrementJobLoad(int numJobsConsumed) {
            this.VTTKKMBDYZ -= numJobsConsumed;
            updateOverloadStatus();
        }

        public synchronized void updateMapCapacity(int mapSlotsCapacity) {
            this.HJOMRYPHWN = mapSlotsCapacity;
            updateOverloadStatus();
        }

        public synchronized void updateReduceCapacity(int reduceSlotsCapacity) {
            this.HFXJXBGHXB = reduceSlotsCapacity;
            updateOverloadStatus();
        }

        public synchronized void updateMapLoad(int mapSlotsBackfill) {
            this.HXDVLJYCLR = mapSlotsBackfill;
            updateOverloadStatus();
        }

        public synchronized void updateReduceLoad(int reduceSlotsBackfill) {
            this.VNRIUNZYKR = reduceSlotsBackfill;
            updateOverloadStatus();
        }

        public synchronized void updateJobLoad(int numJobsBackfill) {
            this.VTTKKMBDYZ = numJobsBackfill;
            updateOverloadStatus();
        }

        private synchronized void updateOverloadStatus() {
            XKCXMQYLPI.set(((HXDVLJYCLR <= 0) || (VNRIUNZYKR <= 0)) || (VTTKKMBDYZ <= 0));
        }

        public boolean overloaded() {
            return XKCXMQYLPI.get();
        }

        public synchronized String toString() {
            // TODO Use StringBuilder instead
            return ((((((((((" Overloaded = " + overloaded()) + ", MapSlotBackfill = ") + HXDVLJYCLR) + ", MapSlotCapacity = ") + HJOMRYPHWN) + ", ReduceSlotBackfill = ") + VNRIUNZYKR) + ", ReduceSlotCapacity = ") + HFXJXBGHXB) + ", NumJobsBackfill = ") + VTTKKMBDYZ;
        }
    }

    /**
     * Start the reader thread, wait for latch if necessary.
     */
    @Override
    public void start() {
        StressJobFactory.RJDZWCRTKZ.info(" Starting Stress submission ");
        this.rThread.start();
    }
}