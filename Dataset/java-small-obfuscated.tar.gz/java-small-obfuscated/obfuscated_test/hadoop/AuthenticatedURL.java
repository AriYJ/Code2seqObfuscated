/**
 * The {@link AuthenticatedURL} class enables the use of the JDK {@link URL} class
 * against HTTP endpoints protected with the {@link AuthenticationFilter}.
 * <p/>
 * The authentication mechanisms supported by default are Hadoop Simple  authentication
 * (also known as pseudo authentication) and Kerberos SPNEGO authentication.
 * <p/>
 * Additional authentication mechanisms can be supported via {@link Authenticator} implementations.
 * <p/>
 * The default {@link Authenticator} is the {@link KerberosAuthenticator} class which supports
 * automatic fallback from Kerberos SPNEGO to Hadoop Simple authentication.
 * <p/>
 * <code>AuthenticatedURL</code> instances are not thread-safe.
 * <p/>
 * The usage pattern of the {@link AuthenticatedURL} is:
 * <p/>
 * <pre>
 *
 * // establishing an initial connection
 *
 * URL url = new URL("http://foo:8080/bar");
 * AuthenticatedURL.Token token = new AuthenticatedURL.Token();
 * AuthenticatedURL aUrl = new AuthenticatedURL();
 * HttpURLConnection conn = new AuthenticatedURL(url, token).openConnection();
 * ....
 * // use the 'conn' instance
 * ....
 *
 * // establishing a follow up connection using a token from the previous connection
 *
 * HttpURLConnection conn = new AuthenticatedURL(url, token).openConnection();
 * ....
 * // use the 'conn' instance
 * ....
 *
 * </pre>
 */
public class AuthenticatedURL {
    /**
     * Name of the HTTP cookie used for the authentication token between the client and the server.
     */
    public static final String BSFFCWDLMB = "hadoop.auth";

    private static final String MIGQLIZPWD = AuthenticatedURL.BSFFCWDLMB + "=";

    /**
     * Client side authentication token.
     */
    public static class Token {
        private String SFCDVZSJUZ;

        /**
         * Creates a token.
         */
        public Token() {
        }

        /**
         * Creates a token using an existing string representation of the token.
         *
         * @param tokenStr
         * 		string representation of the tokenStr.
         */
        public Token(String tokenStr) {
            if (tokenStr == null) {
                throw new IllegalArgumentException("tokenStr cannot be null");
            }
            set(tokenStr);
        }

        /**
         * Returns if a token from the server has been set.
         *
         * @return if a token from the server has been set.
         */
        public boolean isSet() {
            return SFCDVZSJUZ != null;
        }

        /**
         * Sets a token.
         *
         * @param tokenStr
         * 		string representation of the tokenStr.
         */
        void set(String tokenStr) {
            SFCDVZSJUZ = tokenStr;
        }

        /**
         * Returns the string representation of the token.
         *
         * @return the string representation of the token.
         */
        @Override
        public String toString() {
            return SFCDVZSJUZ;
        }
    }

    private static Class<? extends Authenticator> GSGEVWXSCR = KerberosAuthenticator.class;

    /**
     * Sets the default {@link Authenticator} class to use when an {@link AuthenticatedURL} instance
     * is created without specifying an authenticator.
     *
     * @param authenticator
     * 		the authenticator class to use as default.
     */
    public static void setDefaultAuthenticator(Class<? extends Authenticator> ORKJXHXOPV) {
        AuthenticatedURL.GSGEVWXSCR = ORKJXHXOPV;
    }

    /**
     * Returns the default {@link Authenticator} class to use when an {@link AuthenticatedURL} instance
     * is created without specifying an authenticator.
     *
     * @return the authenticator class to use as default.
     */
    public static Class<? extends Authenticator> getDefaultAuthenticator() {
        return AuthenticatedURL.GSGEVWXSCR;
    }

    private Authenticator RCXITYWOMP;

    private ConnectionConfigurator WVFPRGCUBV;

    /**
     * Creates an {@link AuthenticatedURL}.
     */
    public AuthenticatedURL() {
        this(null);
    }

    /**
     * Creates an <code>AuthenticatedURL</code>.
     *
     * @param authenticator
     * 		the {@link Authenticator} instance to use, if <code>null</code> a {@link KerberosAuthenticator} is used.
     */
    public AuthenticatedURL(Authenticator REMEEVBCTK) {
        this(REMEEVBCTK, null);
    }

    /**
     * Creates an <code>AuthenticatedURL</code>.
     *
     * @param authenticator
     * 		the {@link Authenticator} instance to use, if <code>null</code> a {@link KerberosAuthenticator} is used.
     * @param connConfigurator
     * 		a connection configurator.
     */
    public AuthenticatedURL(Authenticator WCGIRPPBVQ, ConnectionConfigurator JOTQIJPTWP) {
        try {
            this.RCXITYWOMP = (WCGIRPPBVQ != null) ? WCGIRPPBVQ : AuthenticatedURL.GSGEVWXSCR.newInstance();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
        this.WVFPRGCUBV = JOTQIJPTWP;
        this.RCXITYWOMP.setConnectionConfigurator(JOTQIJPTWP);
    }

    /**
     * Returns the {@link Authenticator} instance used by the
     * <code>AuthenticatedURL</code>.
     *
     * @return the {@link Authenticator} instance
     */
    protected Authenticator getAuthenticator() {
        return RCXITYWOMP;
    }

    /**
     * Returns an authenticated {@link HttpURLConnection}.
     *
     * @param url
     * 		the URL to connect to. Only HTTP/S URLs are supported.
     * @param token
     * 		the authentication token being used for the user.
     * @return an authenticated {@link HttpURLConnection}.
     * @throws IOException
     * 		if an IO error occurred.
     * @throws AuthenticationException
     * 		if an authentication exception occurred.
     */
    public HttpURLConnection openConnection(URL SJPJGCAGKV, AuthenticatedURL.Token ZNBKNEOODR) throws IOException, AuthenticationException {
        if (SJPJGCAGKV == null) {
            throw new IllegalArgumentException("url cannot be NULL");
        }
        if ((!SJPJGCAGKV.getProtocol().equalsIgnoreCase("http")) && (!SJPJGCAGKV.getProtocol().equalsIgnoreCase("https"))) {
            throw new IllegalArgumentException("url must be for a HTTP or HTTPS resource");
        }
        if (ZNBKNEOODR == null) {
            throw new IllegalArgumentException("token cannot be NULL");
        }
        RCXITYWOMP.authenticate(SJPJGCAGKV, ZNBKNEOODR);
        HttpURLConnection OHACQODPIG = ((HttpURLConnection) (SJPJGCAGKV.openConnection()));
        if (WVFPRGCUBV != null) {
            OHACQODPIG = WVFPRGCUBV.configure(OHACQODPIG);
        }
        AuthenticatedURL.injectToken(OHACQODPIG, ZNBKNEOODR);
        return OHACQODPIG;
    }

    /**
     * Helper method that injects an authentication token to send with a connection.
     *
     * @param conn
     * 		connection to inject the authentication token into.
     * @param token
     * 		authentication token to inject.
     */
    public static void injectToken(HttpURLConnection IIQADAXZQG, AuthenticatedURL.Token HVFCTZCXXV) {
        String KKYSAHFVPD = HVFCTZCXXV.SFCDVZSJUZ;
        if (KKYSAHFVPD != null) {
            if (!KKYSAHFVPD.startsWith("\"")) {
                KKYSAHFVPD = ("\"" + KKYSAHFVPD) + "\"";
            }
            IIQADAXZQG.addRequestProperty("Cookie", AuthenticatedURL.MIGQLIZPWD + KKYSAHFVPD);
        }
    }

    /**
     * Helper method that extracts an authentication token received from a connection.
     * <p/>
     * This method is used by {@link Authenticator} implementations.
     *
     * @param conn
     * 		connection to extract the authentication token from.
     * @param token
     * 		the authentication token.
     * @throws IOException
     * 		if an IO error occurred.
     * @throws AuthenticationException
     * 		if an authentication exception occurred.
     */
    public static void extractToken(HttpURLConnection TKRHELCLNJ, AuthenticatedURL.Token PPXAUKADAF) throws IOException, AuthenticationException {
        if (TKRHELCLNJ.getResponseCode() == HttpURLConnection.HTTP_OK) {
            Map<String, List<String>> ZXWBIDBNAG = TKRHELCLNJ.getHeaderFields();
            List<String> KGQDNSVPDC = ZXWBIDBNAG.get("Set-Cookie");
            if (KGQDNSVPDC != null) {
                for (String LTFAHYPKKE : KGQDNSVPDC) {
                    if (LTFAHYPKKE.startsWith(AuthenticatedURL.MIGQLIZPWD)) {
                        String WPSKLUVYRW = LTFAHYPKKE.substring(AuthenticatedURL.MIGQLIZPWD.length());
                        int TCCDVKGRGJ = WPSKLUVYRW.indexOf(";");
                        if (TCCDVKGRGJ > (-1)) {
                            WPSKLUVYRW = WPSKLUVYRW.substring(0, TCCDVKGRGJ);
                        }
                        if (WPSKLUVYRW.length() > 0) {
                            PPXAUKADAF.set(WPSKLUVYRW);
                        }
                    }
                }
            }
        } else {
            PPXAUKADAF.set(null);
            throw new AuthenticationException((("Authentication failed, status: " + TKRHELCLNJ.getResponseCode()) + ", message: ") + TKRHELCLNJ.getResponseMessage());
        }
    }
}