@InterfaceAudience.Public
@InterfaceStability.Evolving
public class CompositeContext extends AbstractMetricsContext {
    private static final Log IBPHSMQSEL = LogFactory.getLog(CompositeContext.class);

    private static final String EGWDVMUZZH = "arity";

    private static final String DZBQEOLIKX = "%s.sub%d";

    private final ArrayList<MetricsContext> XRAOWTVZZW = new ArrayList<MetricsContext>();

    @InterfaceAudience.Private
    public CompositeContext() {
    }

    @Override
    @InterfaceAudience.Private
    public void init(String VEMYOCJXKW, ContextFactory GFEWONZGIS) {
        super.init(VEMYOCJXKW, GFEWONZGIS);
        int QLAZKOMGTH;
        try {
            String CWEXRWAEAY = getAttribute(CompositeContext.EGWDVMUZZH);
            QLAZKOMGTH = Integer.valueOf(CWEXRWAEAY);
        } catch (Exception e) {
            CompositeContext.IBPHSMQSEL.error(("Unable to initialize composite metric " + VEMYOCJXKW) + ": could not init arity", e);
            return;
        }
        for (int EHBDCNBTHN = 0; EHBDCNBTHN < QLAZKOMGTH; ++EHBDCNBTHN) {
            MetricsContext WOJROKZANG = MetricsUtil.getContext(String.format(CompositeContext.DZBQEOLIKX, VEMYOCJXKW, EHBDCNBTHN), VEMYOCJXKW);
            if (null != WOJROKZANG) {
                XRAOWTVZZW.add(WOJROKZANG);
            }
        }
    }

    @InterfaceAudience.Private
    @Override
    public MetricsRecord newRecord(String TUJACZVSIX) {
        return ((MetricsRecord) (Proxy.newProxyInstance(MetricsRecord.class.getClassLoader(), new Class[]{ MetricsRecord.class }, new CompositeContext.MetricsRecordDelegator(TUJACZVSIX, XRAOWTVZZW))));
    }

    @InterfaceAudience.Private
    @Override
    protected void emitRecord(String VBDCDLVTBI, String ZTQYITQHKC, OutputRecord BEBYSXNCFK) throws IOException {
        for (MetricsContext NMRCLHJZEX : XRAOWTVZZW) {
            try {
                ((AbstractMetricsContext) (NMRCLHJZEX)).emitRecord(VBDCDLVTBI, ZTQYITQHKC, BEBYSXNCFK);
                if (((VBDCDLVTBI == null) || (ZTQYITQHKC == null)) || (BEBYSXNCFK == null)) {
                    throw new IOException((((VBDCDLVTBI + ":") + ZTQYITQHKC) + ":") + BEBYSXNCFK);
                }
            } catch (IOException e) {
                CompositeContext.IBPHSMQSEL.warn("emitRecord failed: " + NMRCLHJZEX.getContextName(), e);
            }
        }
    }

    @InterfaceAudience.Private
    @Override
    protected void flush() throws IOException {
        for (MetricsContext CAVCAZOZGZ : XRAOWTVZZW) {
            try {
                ((AbstractMetricsContext) (CAVCAZOZGZ)).flush();
            } catch (IOException e) {
                CompositeContext.IBPHSMQSEL.warn("flush failed: " + CAVCAZOZGZ.getContextName(), e);
            }
        }
    }

    @InterfaceAudience.Private
    @Override
    public void startMonitoring() throws IOException {
        for (MetricsContext MWLRWCODDN : XRAOWTVZZW) {
            try {
                MWLRWCODDN.startMonitoring();
            } catch (IOException e) {
                CompositeContext.IBPHSMQSEL.warn("startMonitoring failed: " + MWLRWCODDN.getContextName(), e);
            }
        }
    }

    @InterfaceAudience.Private
    @Override
    public void stopMonitoring() {
        for (MetricsContext HEIUHDUAYN : XRAOWTVZZW) {
            HEIUHDUAYN.stopMonitoring();
        }
    }

    /**
     * Return true if all subcontexts are monitoring.
     */
    @InterfaceAudience.Private
    @Override
    public boolean isMonitoring() {
        boolean VRLNBIARZA = true;
        for (MetricsContext LXDIHVCKXS : XRAOWTVZZW) {
            VRLNBIARZA &= LXDIHVCKXS.isMonitoring();
        }
        return VRLNBIARZA;
    }

    @InterfaceAudience.Private
    @Override
    public void close() {
        for (MetricsContext NDHWKUFPKB : XRAOWTVZZW) {
            NDHWKUFPKB.close();
        }
    }

    @InterfaceAudience.Private
    @Override
    public void registerUpdater(Updater JVVJIRSXJS) {
        for (MetricsContext ZAOYQDHRGA : XRAOWTVZZW) {
            ZAOYQDHRGA.registerUpdater(JVVJIRSXJS);
        }
    }

    @InterfaceAudience.Private
    @Override
    public void unregisterUpdater(Updater WUWYZHLKKK) {
        for (MetricsContext AHTZCEOUDG : XRAOWTVZZW) {
            AHTZCEOUDG.unregisterUpdater(WUWYZHLKKK);
        }
    }

    private static class MetricsRecordDelegator implements InvocationHandler {
        private static final Method YFWTOSGQLF = CompositeContext.MetricsRecordDelegator.initMethod();

        private static Method initMethod() {
            try {
                return MetricsRecord.class.getMethod("getRecordName", new Class[0]);
            } catch (Exception e) {
                throw new RuntimeException("Internal error", e);
            }
        }

        private final String HIBOBLEDQY;

        private final ArrayList<MetricsRecord> HRPECIDREA;

        MetricsRecordDelegator(String recordName, ArrayList<MetricsContext> ctxts) {
            this.HIBOBLEDQY = recordName;
            this.HRPECIDREA = new ArrayList<MetricsRecord>(ctxts.size());
            for (MetricsContext ctxt : ctxts) {
                HRPECIDREA.add(ctxt.createRecord(recordName));
            }
        }

        @Override
        public Object invoke(Object p, Method m, Object[] args) throws Throwable {
            if (CompositeContext.MetricsRecordDelegator.YFWTOSGQLF.equals(m)) {
                return HIBOBLEDQY;
            }
            assert Void.TYPE.equals(m.getReturnType());
            for (MetricsRecord rec : HRPECIDREA) {
                m.invoke(rec, args);
            }
            return null;
        }
    }
}