/**
 * This class tests if a balancer schedules tasks correctly.
 */
public class TestBalancerWithNodeGroup {
    private static final Log HHSDWWUDFX = LogFactory.getLog("org.apache.hadoop.hdfs.TestBalancerWithNodeGroup");

    private static final long JKHCPUBRVE = 5000L;

    private static final String RPBUVBCIVU = "/rack0";

    private static final String LUPVRYMDUN = "/rack1";

    private static final String UFBOKUHSEA = "/nodegroup0";

    private static final String GSSPDJWRYS = "/nodegroup1";

    private static final String TGIHZUWCSH = "/nodegroup2";

    private static final String WAUIGSHDHF = "/tmp.txt";

    private static final Path YBEYYIUAZC = new Path(TestBalancerWithNodeGroup.WAUIGSHDHF);

    MiniDFSClusterWithNodeGroup ORZWTZGYYJ;

    ClientProtocol LSFOAKXSOT;

    static final long GELQWGFZBH = 40000L;// msec


    static final double HWWMHAGGXF = 0.005;// 0.5%


    static final double WFBFDKSDCM = 0.11;// 10%+delta


    static final int YCLPZUMUPU = 100;

    static {
        Dispatcher.setBlockMoveWaitTime(1000L);
    }

    static Configuration createConf() {
        Configuration UQVMTTTIJB = new HdfsConfiguration();
        TestBalancer.initConf(UQVMTTTIJB);
        UQVMTTTIJB.setLong(DFS_BLOCK_SIZE_KEY, TestBalancerWithNodeGroup.YCLPZUMUPU);
        UQVMTTTIJB.set(NET_TOPOLOGY_IMPL_KEY, NetworkTopologyWithNodeGroup.class.getName());
        UQVMTTTIJB.set(DFS_BLOCK_REPLICATOR_CLASSNAME_KEY, BlockPlacementPolicyWithNodeGroup.class.getName());
        return UQVMTTTIJB;
    }

    /**
     * Wait until heartbeat gives expected results, within CAPACITY_ALLOWED_VARIANCE,
     * summed over all nodes.  Times out after TIMEOUT msec.
     *
     * @param expectedUsedSpace
     * 		
     * @param expectedTotalSpace
     * 		
     * @throws IOException
     * 		- if getStats() fails
     * @throws TimeoutException
     * 		
     */
    private void waitForHeartBeat(long SQUWXNEHEI, long TUVEVNOJTY) throws IOException, TimeoutException {
        long MFPJYYHDNL = TestBalancerWithNodeGroup.GELQWGFZBH;
        long NGOANNGISI = (MFPJYYHDNL <= 0L) ? Long.MAX_VALUE : System.currentTimeMillis() + MFPJYYHDNL;
        while (true) {
            long[] TZZDIVIEUW = LSFOAKXSOT.getStats();
            double ASVZQCPMME = Math.abs(((double) (TZZDIVIEUW[0])) - TUVEVNOJTY) / TUVEVNOJTY;
            double SKOAMLNWOV = Math.abs(((double) (TZZDIVIEUW[1])) - SQUWXNEHEI) / SQUWXNEHEI;
            if ((ASVZQCPMME < TestBalancerWithNodeGroup.HWWMHAGGXF) && (SKOAMLNWOV < TestBalancerWithNodeGroup.HWWMHAGGXF))
                break;
            // done

            if (System.currentTimeMillis() > NGOANNGISI) {
                throw new TimeoutException((((((((((("Cluster failed to reached expected values of " + "totalSpace (current: ") + TZZDIVIEUW[0]) + ", expected: ") + TUVEVNOJTY) + "), or usedSpace (current: ") + TZZDIVIEUW[1]) + ", expected: ") + SQUWXNEHEI) + "), in more than ") + MFPJYYHDNL) + " msec.");
            }
            try {
                Thread.sleep(100L);
            } catch (InterruptedException ignored) {
            }
        } 
    }

    /**
     * Wait until balanced: each datanode gives utilization within
     * BALANCE_ALLOWED_VARIANCE of average
     *
     * @throws IOException
     * 		
     * @throws TimeoutException
     * 		
     */
    private void waitForBalancer(long SAQGEVTPBH, long WHOJOWXVEW) throws IOException, TimeoutException {
        long VTPRTYJYUY = TestBalancerWithNodeGroup.GELQWGFZBH;
        long HDROWXHZBA = (VTPRTYJYUY <= 0L) ? Long.MAX_VALUE : System.currentTimeMillis() + VTPRTYJYUY;
        final double RQCKELPDGA = ((double) (SAQGEVTPBH)) / WHOJOWXVEW;
        boolean PZNBFTUSBS;
        do {
            DatanodeInfo[] XKPZCOXKUK = LSFOAKXSOT.getDatanodeReport(ALL);
            assertEquals(XKPZCOXKUK.length, ORZWTZGYYJ.getDataNodes().size());
            PZNBFTUSBS = true;
            for (DatanodeInfo MVYLJHQRQN : XKPZCOXKUK) {
                double UZARMVMSAX = ((double) (MVYLJHQRQN.getDfsUsed())) / MVYLJHQRQN.getCapacity();
                if (Math.abs(RQCKELPDGA - UZARMVMSAX) > TestBalancerWithNodeGroup.WFBFDKSDCM) {
                    PZNBFTUSBS = false;
                    if (System.currentTimeMillis() > HDROWXHZBA) {
                        throw new TimeoutException(((((((("Rebalancing expected avg utilization to become " + RQCKELPDGA) + ", but on datanode ") + MVYLJHQRQN) + " it remains at ") + UZARMVMSAX) + " after more than ") + TestBalancerWithNodeGroup.GELQWGFZBH) + " msec.");
                    }
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ignored) {
                    }
                    break;
                }
            }
        } while (!PZNBFTUSBS );
    }

    private void runBalancer(Configuration XZBKJGAEYZ, long BYBDQVVFWQ, long RMDWUBPVSX) throws Exception {
        waitForHeartBeat(BYBDQVVFWQ, RMDWUBPVSX);
        // start rebalancing
        Collection<URI> AWVEVDPGOJ = DFSUtil.getNsServiceRpcUris(XZBKJGAEYZ);
        final int GGECAPQDXT = Balancer.run(AWVEVDPGOJ, DEFAULT, XZBKJGAEYZ);
        assertEquals(SUCCESS.getExitCode(), GGECAPQDXT);
        waitForHeartBeat(BYBDQVVFWQ, RMDWUBPVSX);
        TestBalancerWithNodeGroup.HHSDWWUDFX.info("Rebalancing with default factor.");
        waitForBalancer(BYBDQVVFWQ, RMDWUBPVSX);
    }

    private void runBalancerCanFinish(Configuration KPZMTCKAOP, long ONXEXWLSWR, long CUIDJFAOWL) throws Exception {
        waitForHeartBeat(ONXEXWLSWR, CUIDJFAOWL);
        // start rebalancing
        Collection<URI> BRPQPIHVYT = DFSUtil.getNsServiceRpcUris(KPZMTCKAOP);
        final int FOJKIHNTZQ = Balancer.run(BRPQPIHVYT, DEFAULT, KPZMTCKAOP);
        Assert.assertTrue((FOJKIHNTZQ == SUCCESS.getExitCode()) || (FOJKIHNTZQ == NO_MOVE_PROGRESS.getExitCode()));
        waitForHeartBeat(ONXEXWLSWR, CUIDJFAOWL);
        TestBalancerWithNodeGroup.HHSDWWUDFX.info("Rebalancing with default factor.");
    }

    private Set<ExtendedBlock> getBlocksOnRack(List<LocatedBlock> VQKKIWAWOC, String ZMMTAFZVVU) {
        Set<ExtendedBlock> USYQYZVLJI = new HashSet<ExtendedBlock>();
        for (LocatedBlock RJGHEKHYPB : VQKKIWAWOC) {
            for (DatanodeInfo ISSDSWGISV : RJGHEKHYPB.getLocations()) {
                if (ZMMTAFZVVU.equals(NetworkTopology.getFirstHalf(ISSDSWGISV.getNetworkLocation()))) {
                    USYQYZVLJI.add(RJGHEKHYPB.getBlock());
                    break;
                }
            }
        }
        return USYQYZVLJI;
    }

    /**
     * Create a cluster with even distribution, and a new empty node is added to
     * the cluster, then test rack locality for balancer policy.
     */
    @Test(timeout = 60000)
    public void testBalancerWithRackLocality() throws Exception {
        Configuration UODIGMERZJ = TestBalancerWithNodeGroup.createConf();
        long[] XCCCFUUNVX = new long[]{ TestBalancerWithNodeGroup.JKHCPUBRVE, TestBalancerWithNodeGroup.JKHCPUBRVE };
        String[] LJGMYOZYHH = new String[]{ TestBalancerWithNodeGroup.RPBUVBCIVU, TestBalancerWithNodeGroup.LUPVRYMDUN };
        String[] OTGOYITVGJ = new String[]{ TestBalancerWithNodeGroup.UFBOKUHSEA, TestBalancerWithNodeGroup.GSSPDJWRYS };
        int CTNOKWRUAO = XCCCFUUNVX.length;
        assertEquals(CTNOKWRUAO, LJGMYOZYHH.length);
        MiniDFSCluster.Builder SQFFAXRXAZ = new MiniDFSCluster.Builder(UODIGMERZJ).numDataNodes(XCCCFUUNVX.length).racks(LJGMYOZYHH).simulatedCapacities(XCCCFUUNVX);
        MiniDFSClusterWithNodeGroup.setNodeGroups(OTGOYITVGJ);
        ORZWTZGYYJ = new MiniDFSClusterWithNodeGroup(SQFFAXRXAZ);
        try {
            ORZWTZGYYJ.waitActive();
            LSFOAKXSOT = org.apache.hadoop.hdfs.NameNodeProxies.createProxy(UODIGMERZJ, ORZWTZGYYJ.getFileSystem(0).getUri(), ClientProtocol.class).getProxy();
            long BXRKMSOFAS = TestBalancer.sum(XCCCFUUNVX);
            // fill up the cluster to be 30% full
            long ZHFJIXYOXU = (BXRKMSOFAS * 3) / 10;
            long ZDIZENXZMU = ZHFJIXYOXU / CTNOKWRUAO;
            TestBalancer.createFile(ORZWTZGYYJ, TestBalancerWithNodeGroup.YBEYYIUAZC, ZDIZENXZMU, ((short) (CTNOKWRUAO)), 0);
            LocatedBlocks VUIBPZLOEQ = LSFOAKXSOT.getBlockLocations(TestBalancerWithNodeGroup.YBEYYIUAZC.toUri().getPath(), 0, ZDIZENXZMU);
            Set<ExtendedBlock> HFYZFINSMS = getBlocksOnRack(VUIBPZLOEQ.getLocatedBlocks(), TestBalancerWithNodeGroup.RPBUVBCIVU);
            long SWLYLJBDBN = TestBalancerWithNodeGroup.JKHCPUBRVE;
            String IVBQNPTXSY = TestBalancerWithNodeGroup.LUPVRYMDUN;
            String TONVWYDRXD = TestBalancerWithNodeGroup.TGIHZUWCSH;
            // start up an empty node with the same capacity and on the same rack
            ORZWTZGYYJ.startDataNodes(UODIGMERZJ, 1, true, null, new String[]{ IVBQNPTXSY }, new long[]{ SWLYLJBDBN }, new String[]{ TONVWYDRXD });
            BXRKMSOFAS += SWLYLJBDBN;
            // run balancer and validate results
            runBalancerCanFinish(UODIGMERZJ, ZHFJIXYOXU, BXRKMSOFAS);
            VUIBPZLOEQ = LSFOAKXSOT.getBlockLocations(TestBalancerWithNodeGroup.YBEYYIUAZC.toUri().getPath(), 0, ZDIZENXZMU);
            Set<ExtendedBlock> MFYEXHHDEO = getBlocksOnRack(VUIBPZLOEQ.getLocatedBlocks(), TestBalancerWithNodeGroup.RPBUVBCIVU);
            assertEquals(HFYZFINSMS, MFYEXHHDEO);
        } finally {
            ORZWTZGYYJ.shutdown();
        }
    }

    /**
     * Create a cluster with even distribution, and a new empty node is added to
     * the cluster, then test node-group locality for balancer policy.
     */
    @Test(timeout = 60000)
    public void testBalancerWithNodeGroup() throws Exception {
        Configuration XMLIDVGDGX = TestBalancerWithNodeGroup.createConf();
        long[] SPXLGNXLWU = new long[]{ TestBalancerWithNodeGroup.JKHCPUBRVE, TestBalancerWithNodeGroup.JKHCPUBRVE, TestBalancerWithNodeGroup.JKHCPUBRVE, TestBalancerWithNodeGroup.JKHCPUBRVE };
        String[] MURRHGNUPU = new String[]{ TestBalancerWithNodeGroup.RPBUVBCIVU, TestBalancerWithNodeGroup.RPBUVBCIVU, TestBalancerWithNodeGroup.LUPVRYMDUN, TestBalancerWithNodeGroup.LUPVRYMDUN };
        String[] LGQXCXCJGD = new String[]{ TestBalancerWithNodeGroup.UFBOKUHSEA, TestBalancerWithNodeGroup.UFBOKUHSEA, TestBalancerWithNodeGroup.GSSPDJWRYS, TestBalancerWithNodeGroup.TGIHZUWCSH };
        int OSKWGKJNKG = SPXLGNXLWU.length;
        assertEquals(OSKWGKJNKG, MURRHGNUPU.length);
        assertEquals(OSKWGKJNKG, LGQXCXCJGD.length);
        MiniDFSCluster.Builder VPQMLYTGZJ = new MiniDFSCluster.Builder(XMLIDVGDGX).numDataNodes(SPXLGNXLWU.length).racks(MURRHGNUPU).simulatedCapacities(SPXLGNXLWU);
        MiniDFSClusterWithNodeGroup.setNodeGroups(LGQXCXCJGD);
        ORZWTZGYYJ = new MiniDFSClusterWithNodeGroup(VPQMLYTGZJ);
        try {
            ORZWTZGYYJ.waitActive();
            LSFOAKXSOT = org.apache.hadoop.hdfs.NameNodeProxies.createProxy(XMLIDVGDGX, ORZWTZGYYJ.getFileSystem(0).getUri(), ClientProtocol.class).getProxy();
            long PPXDAQOYJK = TestBalancer.sum(SPXLGNXLWU);
            // fill up the cluster to be 20% full
            long OTQNRRRQEA = (PPXDAQOYJK * 2) / 10;
            TestBalancer.createFile(ORZWTZGYYJ, TestBalancerWithNodeGroup.YBEYYIUAZC, OTQNRRRQEA / (OSKWGKJNKG / 2), ((short) (OSKWGKJNKG / 2)), 0);
            long VBBIQDVNKF = TestBalancerWithNodeGroup.JKHCPUBRVE;
            String CQFBDWVFFL = TestBalancerWithNodeGroup.LUPVRYMDUN;
            String QOWIHCEDLF = TestBalancerWithNodeGroup.TGIHZUWCSH;
            // start up an empty node with the same capacity and on NODEGROUP2
            ORZWTZGYYJ.startDataNodes(XMLIDVGDGX, 1, true, null, new String[]{ CQFBDWVFFL }, new long[]{ VBBIQDVNKF }, new String[]{ QOWIHCEDLF });
            PPXDAQOYJK += VBBIQDVNKF;
            // run balancer and validate results
            runBalancer(XMLIDVGDGX, OTQNRRRQEA, PPXDAQOYJK);
        } finally {
            ORZWTZGYYJ.shutdown();
        }
    }

    /**
     * Create a 4 nodes cluster: 2 nodes (n0, n1) in RACK0/NODEGROUP0, 1 node (n2)
     * in RACK1/NODEGROUP1 and 1 node (n3) in RACK1/NODEGROUP2. Fill the cluster
     * to 60% and 3 replicas, so n2 and n3 will have replica for all blocks according
     * to replica placement policy with NodeGroup. As a result, n2 and n3 will be
     * filled with 80% (60% x 4 / 3), and no blocks can be migrated from n2 and n3
     * to n0 or n1 as balancer policy with node group. Thus, we expect the balancer
     * to end in 5 iterations without move block process.
     */
    @Test(timeout = 60000)
    public void testBalancerEndInNoMoveProgress() throws Exception {
        Configuration KBUNANQXWK = TestBalancerWithNodeGroup.createConf();
        long[] ZYYDTVLFME = new long[]{ TestBalancerWithNodeGroup.JKHCPUBRVE, TestBalancerWithNodeGroup.JKHCPUBRVE, TestBalancerWithNodeGroup.JKHCPUBRVE, TestBalancerWithNodeGroup.JKHCPUBRVE };
        String[] KYBTLESMPK = new String[]{ TestBalancerWithNodeGroup.RPBUVBCIVU, TestBalancerWithNodeGroup.RPBUVBCIVU, TestBalancerWithNodeGroup.LUPVRYMDUN, TestBalancerWithNodeGroup.LUPVRYMDUN };
        String[] IIQAVZJWQT = new String[]{ TestBalancerWithNodeGroup.UFBOKUHSEA, TestBalancerWithNodeGroup.UFBOKUHSEA, TestBalancerWithNodeGroup.GSSPDJWRYS, TestBalancerWithNodeGroup.TGIHZUWCSH };
        int NKAESJKMNI = ZYYDTVLFME.length;
        assertEquals(NKAESJKMNI, KYBTLESMPK.length);
        assertEquals(NKAESJKMNI, IIQAVZJWQT.length);
        MiniDFSCluster.Builder KAAHDIWUES = new MiniDFSCluster.Builder(KBUNANQXWK).numDataNodes(ZYYDTVLFME.length).racks(KYBTLESMPK).simulatedCapacities(ZYYDTVLFME);
        MiniDFSClusterWithNodeGroup.setNodeGroups(IIQAVZJWQT);
        ORZWTZGYYJ = new MiniDFSClusterWithNodeGroup(KAAHDIWUES);
        try {
            ORZWTZGYYJ.waitActive();
            LSFOAKXSOT = org.apache.hadoop.hdfs.NameNodeProxies.createProxy(KBUNANQXWK, ORZWTZGYYJ.getFileSystem(0).getUri(), ClientProtocol.class).getProxy();
            long PEKHCZNRZY = TestBalancer.sum(ZYYDTVLFME);
            // fill up the cluster to be 60% full
            long VKXODNOYAP = (PEKHCZNRZY * 6) / 10;
            TestBalancer.createFile(ORZWTZGYYJ, TestBalancerWithNodeGroup.YBEYYIUAZC, VKXODNOYAP / 3, ((short) (3)), 0);
            // run balancer which can finish in 5 iterations with no block movement.
            runBalancerCanFinish(KBUNANQXWK, VKXODNOYAP, PEKHCZNRZY);
        } finally {
            ORZWTZGYYJ.shutdown();
        }
    }
}