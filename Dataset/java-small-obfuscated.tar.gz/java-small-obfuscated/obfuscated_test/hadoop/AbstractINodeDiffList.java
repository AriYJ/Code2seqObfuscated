/**
 * A list of snapshot diffs for storing snapshot data.
 *
 * @param <N>
 * 		The {@link INode} type.
 * @param <D>
 * 		The diff type, which must extend {@link AbstractINodeDiff}.
 */
abstract class AbstractINodeDiffList<N extends INode, A extends INodeAttributes, D extends AbstractINodeDiff<N, A, D>> implements Iterable<D> {
    /**
     * Diff list sorted by snapshot IDs, i.e. in chronological order.
     */
    private final List<D> JSJREAZKZG = new ArrayList<D>();

    /**
     *
     *
     * @return this list as a unmodifiable {@link List}.
     */
    public final List<D> asList() {
        return Collections.unmodifiableList(JSJREAZKZG);
    }

    /**
     * Get the size of the list and then clear it.
     */
    public void clear() {
        JSJREAZKZG.clear();
    }

    /**
     *
     *
     * @return an {@link AbstractINodeDiff}.
     */
    abstract D createDiff(int OTWSYIOZAD, N THIEMLPVQA);

    /**
     *
     *
     * @return a snapshot copy of the current inode.
     */
    abstract A createSnapshotCopy(N YGPLPIHAPD);

    /**
     * Delete a snapshot. The synchronization of the diff list will be done
     * outside. If the diff to remove is not the first one in the diff list, we
     * need to combine the diff with its previous one.
     *
     * @param snapshot
     * 		The id of the snapshot to be deleted
     * @param prior
     * 		The id of the snapshot taken before the to-be-deleted snapshot
     * @param collectedBlocks
     * 		Used to collect information for blocksMap update
     * @return delta in namespace.
     */
    public final Counts deleteSnapshotDiff(final int REKNAXRULR, final int KPQIXPASND, final N HWJBCAQPEX, final BlocksMapUpdateInfo ATRHSNIWGS, final List<INode> RLKRMUGUBP, boolean MFBAWFDJBW) throws QuotaExceededException {
        int DDMBZJXADI = Collections.binarySearch(JSJREAZKZG, REKNAXRULR);
        Quota.Counts CQENMUZTIO = Counts.newInstance();
        D YYBLMFMIHX = null;
        if (DDMBZJXADI == 0) {
            if (KPQIXPASND != Snapshot.NO_SNAPSHOT_ID) {
                // there is still snapshot before
                // set the snapshot to latestBefore
                JSJREAZKZG.get(DDMBZJXADI).setSnapshotId(KPQIXPASND);
            } else {
                // there is no snapshot before
                YYBLMFMIHX = JSJREAZKZG.remove(0);
                if (MFBAWFDJBW) {
                    CQENMUZTIO.add(NAMESPACE, 1);
                } else {
                    // the currentINode must be a descendant of a WithName node, which set
                    // countDiffChange to false. In that case we should count in the diff
                    // change when updating the quota usage in the current tree
                    HWJBCAQPEX.addSpaceConsumed(-1, 0, false);
                }
                CQENMUZTIO.add(YYBLMFMIHX.destroyDiffAndCollectBlocks(HWJBCAQPEX, ATRHSNIWGS, RLKRMUGUBP));
            }
        } else
            if (DDMBZJXADI > 0) {
                final AbstractINodeDiff<N, A, D> EGEFZANICJ = JSJREAZKZG.get(DDMBZJXADI - 1);
                if (EGEFZANICJ.getSnapshotId() != KPQIXPASND) {
                    JSJREAZKZG.get(DDMBZJXADI).setSnapshotId(KPQIXPASND);
                } else {
                    // combine the to-be-removed diff with its previous diff
                    YYBLMFMIHX = JSJREAZKZG.remove(DDMBZJXADI);
                    if (MFBAWFDJBW) {
                        CQENMUZTIO.add(NAMESPACE, 1);
                    } else {
                        HWJBCAQPEX.addSpaceConsumed(-1, 0, false);
                    }
                    if (EGEFZANICJ.snapshotINode == null) {
                        EGEFZANICJ.snapshotINode = YYBLMFMIHX.snapshotINode;
                    }
                    CQENMUZTIO.add(EGEFZANICJ.combinePosteriorAndCollectBlocks(HWJBCAQPEX, YYBLMFMIHX, ATRHSNIWGS, RLKRMUGUBP));
                    EGEFZANICJ.setPosterior(YYBLMFMIHX.getPosterior());
                    YYBLMFMIHX.setPosterior(null);
                }
            }

        return CQENMUZTIO;
    }

    /**
     * Add an {@link AbstractINodeDiff} for the given snapshot.
     */
    final D addDiff(int UTIBJHSEGC, N NSOETMJIHH) throws QuotaExceededException {
        NSOETMJIHH.addSpaceConsumed(1, 0, true);
        return addLast(createDiff(UTIBJHSEGC, NSOETMJIHH));
    }

    /**
     * Append the diff at the end of the list.
     */
    private final D addLast(D OWGPAQRJIL) {
        final D XOIADCVSRT = getLast();
        JSJREAZKZG.add(OWGPAQRJIL);
        if (XOIADCVSRT != null) {
            XOIADCVSRT.setPosterior(OWGPAQRJIL);
        }
        return OWGPAQRJIL;
    }

    /**
     * Add the diff to the beginning of the list.
     */
    final void addFirst(D KWKCMVIVSK) {
        final D PKMBWWDXOB = (JSJREAZKZG.isEmpty()) ? null : JSJREAZKZG.get(0);
        JSJREAZKZG.add(0, KWKCMVIVSK);
        KWKCMVIVSK.setPosterior(PKMBWWDXOB);
    }

    /**
     *
     *
     * @return the last diff.
     */
    public final D getLast() {
        final int VUFTSLIUFN = JSJREAZKZG.size();
        return VUFTSLIUFN == 0 ? null : JSJREAZKZG.get(VUFTSLIUFN - 1);
    }

    /**
     *
     *
     * @return the id of the last snapshot.
     */
    public final int getLastSnapshotId() {
        final AbstractINodeDiff<N, A, D> FLJOSDHHSM = getLast();
        return FLJOSDHHSM == null ? Snapshot.CURRENT_STATE_ID : FLJOSDHHSM.getSnapshotId();
    }

    /**
     * Find the latest snapshot before a given snapshot.
     *
     * @param anchorId
     * 		The returned snapshot's id must be <= or < this given
     * 		snapshot id.
     * @param exclusive
     * 		True means the returned snapshot's id must be < the given
     * 		id, otherwise <=.
     * @return The id of the latest snapshot before the given snapshot.
     */
    private final int getPrior(int MVNMTKEHQN, boolean UYAJHPNPBY) {
        if (MVNMTKEHQN == Snapshot.CURRENT_STATE_ID) {
            return getLastSnapshotId();
        }
        final int MYRBZTGTSW = Collections.binarySearch(JSJREAZKZG, MVNMTKEHQN);
        if (UYAJHPNPBY) {
            // must be the one before
            if ((MYRBZTGTSW == (-1)) || (MYRBZTGTSW == 0)) {
                return Snapshot.NO_SNAPSHOT_ID;
            } else {
                int HQDXQFYRFL = (MYRBZTGTSW > 0) ? MYRBZTGTSW - 1 : (-MYRBZTGTSW) - 2;
                return JSJREAZKZG.get(HQDXQFYRFL).getSnapshotId();
            }
        } else {
            // the one, or the one before if not existing
            if (MYRBZTGTSW >= 0) {
                return JSJREAZKZG.get(MYRBZTGTSW).getSnapshotId();
            } else
                if (MYRBZTGTSW < (-1)) {
                    return JSJREAZKZG.get((-MYRBZTGTSW) - 2).getSnapshotId();
                } else {
                    // i == -1
                    return Snapshot.NO_SNAPSHOT_ID;
                }

        }
    }

    public final int getPrior(int WPZIZAUZXR) {
        return getPrior(WPZIZAUZXR, false);
    }

    /**
     * Update the prior snapshot.
     */
    final int updatePrior(int BCYJJVLUAR, int YYCFTKQIMX) {
        int PEFNZWAEOI = getPrior(BCYJJVLUAR, true);
        if ((PEFNZWAEOI != Snapshot.CURRENT_STATE_ID) && (ID_INTEGER_COMPARATOR.compare(PEFNZWAEOI, YYCFTKQIMX) > 0)) {
            return PEFNZWAEOI;
        }
        return YYCFTKQIMX;
    }

    public final D getDiffById(final int NFTKMVHQRS) {
        if (NFTKMVHQRS == Snapshot.CURRENT_STATE_ID) {
            return null;
        }
        final int JOCOAVQKQP = Collections.binarySearch(JSJREAZKZG, NFTKMVHQRS);
        if (JOCOAVQKQP >= 0) {
            // exact match
            return JSJREAZKZG.get(JOCOAVQKQP);
        } else {
            // Exact match not found means that there were no changes between
            // given snapshot and the next state so that the diff for the given
            // snapshot was not recorded. Thus, return the next state.
            final int LUEMXPWQAK = (-JOCOAVQKQP) - 1;
            return LUEMXPWQAK < JSJREAZKZG.size() ? JSJREAZKZG.get(LUEMXPWQAK) : null;
        }
    }

    /**
     * Search for the snapshot whose id is 1) no less than the given id,
     * and 2) most close to the given id.
     */
    public final int getSnapshotById(final int WFQMMKZPPL) {
        D AIWDMAGBLS = getDiffById(WFQMMKZPPL);
        return AIWDMAGBLS == null ? Snapshot.CURRENT_STATE_ID : AIWDMAGBLS.getSnapshotId();
    }

    final int[] changedBetweenSnapshots(Snapshot ORMNHOWOXM, Snapshot IIAXNHOEHX) {
        Snapshot DIQGJWLHDH = ORMNHOWOXM;
        Snapshot PACAKTKWAK = IIAXNHOEHX;
        if (ID_COMPARATOR.compare(ORMNHOWOXM, IIAXNHOEHX) > 0) {
            DIQGJWLHDH = IIAXNHOEHX;
            PACAKTKWAK = ORMNHOWOXM;
        }
        final int FSKERFJULU = JSJREAZKZG.size();
        int TEASLTWONM = Collections.binarySearch(JSJREAZKZG, DIQGJWLHDH.getId());
        int FNSFOHMJJK = (PACAKTKWAK == null) ? FSKERFJULU : Collections.binarySearch(JSJREAZKZG, PACAKTKWAK.getId());
        if (((-TEASLTWONM) - 1) == FSKERFJULU) {
            // if the earlierSnapshot is after the latest SnapshotDiff stored in
            // diffs, no modification happened after the earlierSnapshot
            return null;
        }
        if ((FNSFOHMJJK == (-1)) || (FNSFOHMJJK == 0)) {
            // if the laterSnapshot is the earliest SnapshotDiff stored in diffs, or
            // before it, no modification happened before the laterSnapshot
            return null;
        }
        TEASLTWONM = (TEASLTWONM < 0) ? (-TEASLTWONM) - 1 : TEASLTWONM;
        FNSFOHMJJK = (FNSFOHMJJK < 0) ? (-FNSFOHMJJK) - 1 : FNSFOHMJJK;
        return new int[]{ TEASLTWONM, FNSFOHMJJK };
    }

    /**
     *
     *
     * @return the inode corresponding to the given snapshot.
    Note that the current inode is returned if there is no change
    between the given snapshot and the current state.
     */
    public A getSnapshotINode(final int DNFOAWJENV, final A JAPMIMKOAU) {
        final D UPXSCOIONG = getDiffById(DNFOAWJENV);
        final A QOEWXOXKHU = (UPXSCOIONG == null) ? null : UPXSCOIONG.getSnapshotINode();
        return QOEWXOXKHU == null ? JAPMIMKOAU : QOEWXOXKHU;
    }

    /**
     * Check if the latest snapshot diff exists.  If not, add it.
     *
     * @return the latest snapshot diff, which is never null.
     */
    final D checkAndAddLatestSnapshotDiff(int MEMEJFALZO, N MXFTHFUWID) throws QuotaExceededException {
        final D ISQHVSRXIT = getLast();
        if ((ISQHVSRXIT != null) && (ID_INTEGER_COMPARATOR.compare(ISQHVSRXIT.getSnapshotId(), MEMEJFALZO) >= 0)) {
            return ISQHVSRXIT;
        } else {
            try {
                return addDiff(MEMEJFALZO, MXFTHFUWID);
            } catch (NSQuotaExceededException e) {
                e.setMessagePrefix("Failed to record modification for snapshot");
                throw e;
            }
        }
    }

    /**
     * Save the snapshot copy to the latest snapshot.
     */
    public void saveSelf2Snapshot(int OHEJKIEWZC, N YIDVBNWTCF, A UQISKWLOZH) throws QuotaExceededException {
        if (OHEJKIEWZC != Snapshot.CURRENT_STATE_ID) {
            D CMFLPZABSN = checkAndAddLatestSnapshotDiff(OHEJKIEWZC, YIDVBNWTCF);
            if (CMFLPZABSN.snapshotINode == null) {
                if (UQISKWLOZH == null) {
                    UQISKWLOZH = createSnapshotCopy(YIDVBNWTCF);
                }
                CMFLPZABSN.saveSnapshotCopy(UQISKWLOZH);
            }
        }
    }

    @Override
    public Iterator<D> iterator() {
        return JSJREAZKZG.iterator();
    }

    @Override
    public String toString() {
        return (getClass().getSimpleName() + ": ") + JSJREAZKZG;
    }
}