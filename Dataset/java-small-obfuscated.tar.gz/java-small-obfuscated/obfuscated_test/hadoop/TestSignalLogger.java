public class TestSignalLogger {
    public static final Log YPVXYLZQWK = LogFactory.getLog(TestSignalLogger.class);

    @Test(timeout = 60000)
    public void testInstall() throws Exception {
        Assume.assumeTrue(IS_OS_UNIX);
        INSTANCE.register(TestSignalLogger.YPVXYLZQWK);
        try {
            INSTANCE.register(TestSignalLogger.YPVXYLZQWK);
            Assert.fail("expected IllegalStateException from double registration");
        } catch (IllegalStateException e) {
            // fall through
        }
    }
}