public class CountersPage extends AppView {
    @Override
    protected void preHead(Page.HTML<_> XOMTZNEFPC) {
        commonPreHead(XOMTZNEFPC);
        String RQUAWXTXOG = $(AMParams.TASK_ID);
        String UTRQHQNVTA = "3";
        if ((RQUAWXTXOG == null) || RQUAWXTXOG.isEmpty()) {
            UTRQHQNVTA = "2";
        }
        set(initID(ACCORDION, "nav"), ("{autoHeight:false, active:" + UTRQHQNVTA) + "}");
        set(DATATABLES_SELECTOR, "#counters .dt-counters");
        set(initSelector(DATATABLES), "{bJQueryUI:true, sDom:'t', iDisplayLength:-1}");
    }

    @Override
    protected void postHead(Page.HTML<_> JYZRVMVQRU) {
        JYZRVMVQRU.style("#counters, .dt-counters { table-layout: fixed }", "#counters th { overflow: hidden; vertical-align: middle }", "#counters .dataTables_wrapper { min-height: 1em }", "#counters .group { width: 15em }", "#counters .name { width: 30em }");
    }

    @Override
    protected Class<? extends SubView> content() {
        return CountersBlock.class;
    }
}