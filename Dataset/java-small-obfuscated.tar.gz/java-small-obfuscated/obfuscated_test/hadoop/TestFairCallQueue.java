public class TestFairCallQueue extends TestCase {
    private FairCallQueue<Schedulable> YSMBQUSJQF;

    private Schedulable mockCall(String UCFKEMSOBD) {
        Schedulable EPWTKMMYYB = mock(Schedulable.class);
        UserGroupInformation BIQVGPEFZU = mock(UserGroupInformation.class);
        when(BIQVGPEFZU.getUserName()).thenReturn(UCFKEMSOBD);
        when(EPWTKMMYYB.getUserGroupInformation()).thenReturn(BIQVGPEFZU);
        return EPWTKMMYYB;
    }

    // A scheduler which always schedules into priority zero
    private RpcScheduler SIKFRIGTBA;

    {
        RpcScheduler sched = mock(RpcScheduler.class);
        when(sched.getPriorityLevel(org.mockito.Matchers.<Schedulable>any())).thenReturn(0);// always queue 0

        SIKFRIGTBA = sched;
    }

    public void setUp() {
        Configuration WATHKLYQNQ = new Configuration();
        WATHKLYQNQ.setInt("ns." + FairCallQueue.IPC_CALLQUEUE_PRIORITY_LEVELS_KEY, 2);
        YSMBQUSJQF = new FairCallQueue<Schedulable>(5, "ns", WATHKLYQNQ);
    }

    // 
    // Ensure that FairCallQueue properly implements BlockingQueue
    // 
    public void testPollReturnsNullWhenEmpty() {
        assertNull(YSMBQUSJQF.poll());
    }

    public void testPollReturnsTopCallWhenNotEmpty() {
        Schedulable EGYGRNEUSU = mockCall("c");
        assertTrue(YSMBQUSJQF.offer(EGYGRNEUSU));
        assertEquals(EGYGRNEUSU, YSMBQUSJQF.poll());
        // Poll took it out so the fcq is empty
        assertEquals(0, YSMBQUSJQF.size());
    }

    public void testOfferSucceeds() {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        for (int AOMZYNYAHJ = 0; AOMZYNYAHJ < 5; AOMZYNYAHJ++) {
            // We can fit 10 calls
            assertTrue(YSMBQUSJQF.offer(mockCall("c")));
        }
        assertEquals(5, YSMBQUSJQF.size());
    }

    public void testOfferFailsWhenFull() {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        for (int KGRMJLTUJM = 0; KGRMJLTUJM < 5; KGRMJLTUJM++) {
            assertTrue(YSMBQUSJQF.offer(mockCall("c")));
        }
        assertFalse(YSMBQUSJQF.offer(mockCall("c")));// It's full

        assertEquals(5, YSMBQUSJQF.size());
    }

    public void testOfferSucceedsWhenScheduledLowPriority() {
        // Scheduler will schedule into queue 0 x 5, then queue 1
        RpcScheduler GHWBXEXNBM = mock(RpcScheduler.class);
        when(GHWBXEXNBM.getPriorityLevel(org.mockito.Matchers.<Schedulable>any())).thenReturn(0, 0, 0, 0, 0, 1, 0);
        YSMBQUSJQF.setScheduler(GHWBXEXNBM);
        for (int OANLJHXKSX = 0; OANLJHXKSX < 5; OANLJHXKSX++) {
            assertTrue(YSMBQUSJQF.offer(mockCall("c")));
        }
        assertTrue(YSMBQUSJQF.offer(mockCall("c")));
        assertEquals(6, YSMBQUSJQF.size());
    }

    public void testPeekNullWhenEmpty() {
        assertNull(YSMBQUSJQF.peek());
    }

    public void testPeekNonDestructive() {
        Schedulable VQXQHJNVWU = mockCall("c");
        assertTrue(YSMBQUSJQF.offer(VQXQHJNVWU));
        assertEquals(VQXQHJNVWU, YSMBQUSJQF.peek());
        assertEquals(VQXQHJNVWU, YSMBQUSJQF.peek());// Non-destructive

        assertEquals(1, YSMBQUSJQF.size());
    }

    public void testPeekPointsAtHead() {
        Schedulable OZTTRJHRPM = mockCall("c");
        Schedulable BTLEXJZTTW = mockCall("b");
        YSMBQUSJQF.offer(OZTTRJHRPM);
        YSMBQUSJQF.offer(BTLEXJZTTW);
        assertEquals(OZTTRJHRPM, YSMBQUSJQF.peek());// Peek points at the head

    }

    public void testPollTimeout() throws InterruptedException {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        assertNull(YSMBQUSJQF.poll(10, TimeUnit.MILLISECONDS));
    }

    public void testPollSuccess() throws InterruptedException {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        Schedulable MXFGJBRIIR = mockCall("c");
        assertTrue(YSMBQUSJQF.offer(MXFGJBRIIR));
        assertEquals(MXFGJBRIIR, YSMBQUSJQF.poll(10, TimeUnit.MILLISECONDS));
        assertEquals(0, YSMBQUSJQF.size());
    }

    public void testOfferTimeout() throws InterruptedException {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        for (int ICKRUKVBCC = 0; ICKRUKVBCC < 5; ICKRUKVBCC++) {
            assertTrue(YSMBQUSJQF.offer(mockCall("c"), 10, TimeUnit.MILLISECONDS));
        }
        assertFalse(YSMBQUSJQF.offer(mockCall("e"), 10, TimeUnit.MILLISECONDS));// It's full

        assertEquals(5, YSMBQUSJQF.size());
    }

    public void testDrainTo() {
        Configuration CUWOKMHWKF = new Configuration();
        CUWOKMHWKF.setInt("ns." + FairCallQueue.IPC_CALLQUEUE_PRIORITY_LEVELS_KEY, 2);
        FairCallQueue<Schedulable> ZSJEDQACPS = new FairCallQueue<Schedulable>(10, "ns", CUWOKMHWKF);
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        ZSJEDQACPS.setScheduler(SIKFRIGTBA);
        // Start with 3 in fcq, to be drained
        for (int XFAWUIAXPA = 0; XFAWUIAXPA < 3; XFAWUIAXPA++) {
            YSMBQUSJQF.offer(mockCall("c"));
        }
        YSMBQUSJQF.drainTo(ZSJEDQACPS);
        assertEquals(0, YSMBQUSJQF.size());
        assertEquals(3, ZSJEDQACPS.size());
    }

    public void testDrainToWithLimit() {
        Configuration ZYUNCOSBUK = new Configuration();
        ZYUNCOSBUK.setInt("ns." + FairCallQueue.IPC_CALLQUEUE_PRIORITY_LEVELS_KEY, 2);
        FairCallQueue<Schedulable> FZZRZDZAJM = new FairCallQueue<Schedulable>(10, "ns", ZYUNCOSBUK);
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        FZZRZDZAJM.setScheduler(SIKFRIGTBA);
        // Start with 3 in fcq, to be drained
        for (int IMTOKGWOMU = 0; IMTOKGWOMU < 3; IMTOKGWOMU++) {
            YSMBQUSJQF.offer(mockCall("c"));
        }
        YSMBQUSJQF.drainTo(FZZRZDZAJM, 2);
        assertEquals(1, YSMBQUSJQF.size());
        assertEquals(2, FZZRZDZAJM.size());
    }

    public void testInitialRemainingCapacity() {
        assertEquals(10, YSMBQUSJQF.remainingCapacity());
    }

    public void testFirstQueueFullRemainingCapacity() {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        while (YSMBQUSJQF.offer(mockCall("c")));// Queue 0 will fill up first, then queue 1

        assertEquals(5, YSMBQUSJQF.remainingCapacity());
    }

    public void testAllQueuesFullRemainingCapacity() {
        RpcScheduler FZAXCRIPCF = mock(RpcScheduler.class);
        when(FZAXCRIPCF.getPriorityLevel(org.mockito.Matchers.<Schedulable>any())).thenReturn(0, 0, 0, 0, 0, 1, 1, 1, 1, 1);
        YSMBQUSJQF.setScheduler(FZAXCRIPCF);
        while (YSMBQUSJQF.offer(mockCall("c")));
        assertEquals(0, YSMBQUSJQF.remainingCapacity());
        assertEquals(10, YSMBQUSJQF.size());
    }

    public void testQueuesPartialFilledRemainingCapacity() {
        RpcScheduler HZYSPWFJDK = mock(RpcScheduler.class);
        when(HZYSPWFJDK.getPriorityLevel(org.mockito.Matchers.<Schedulable>any())).thenReturn(0, 1, 0, 1, 0);
        YSMBQUSJQF.setScheduler(HZYSPWFJDK);
        for (int ROGUYIFMYC = 0; ROGUYIFMYC < 5; ROGUYIFMYC++) {
            YSMBQUSJQF.offer(mockCall("c"));
        }
        assertEquals(5, YSMBQUSJQF.remainingCapacity());
        assertEquals(5, YSMBQUSJQF.size());
    }

    /**
     * Putter produces FakeCalls
     */
    public class Putter implements Runnable {
        private final BlockingQueue<Schedulable> RGNJXSQWNS;

        public final String ZOXVANCKVP;

        public volatile int FYNVOYPYEE = 0;// How many calls we added, accurate unless interrupted


        private final int JNMJZOXHQA;

        public Putter(BlockingQueue<Schedulable> aCq, int maxCalls, String tag) {
            this.JNMJZOXHQA = maxCalls;
            this.RGNJXSQWNS = aCq;
            this.ZOXVANCKVP = tag;
        }

        private String getTag() {
            if (this.ZOXVANCKVP != null)
                return this.ZOXVANCKVP;

            return "";
        }

        @Override
        public void run() {
            try {
                // Fill up to max (which is infinite if maxCalls < 0)
                while ((FYNVOYPYEE < JNMJZOXHQA) || (JNMJZOXHQA < 0)) {
                    RGNJXSQWNS.put(mockCall(getTag()));
                    FYNVOYPYEE++;
                } 
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    /**
     * Taker consumes FakeCalls
     */
    public class Taker implements Runnable {
        private final BlockingQueue<Schedulable> HNLBOHOHAU;

        public final String FELAYWINFO;// if >= 0 means we will only take the matching tag, and put back


        // anything else
        public volatile int VECEXYZPZY = 0;// total calls taken, accurate if we aren't interrupted


        public volatile Schedulable CTFGHPHDKY = null;// the last thing we took


        private final int UBOINXOVAA;// maximum calls to take


        private IdentityProvider YAHXSBHRDV;

        public Taker(BlockingQueue<Schedulable> aCq, int maxCalls, String tag) {
            this.UBOINXOVAA = maxCalls;
            this.HNLBOHOHAU = aCq;
            this.FELAYWINFO = tag;
            this.YAHXSBHRDV = new UserIdentityProvider();
        }

        @Override
        public void run() {
            try {
                // Take while we don't exceed maxCalls, or if maxCalls is undefined (< 0)
                while ((VECEXYZPZY < UBOINXOVAA) || (UBOINXOVAA < 0)) {
                    Schedulable res = HNLBOHOHAU.take();
                    String identity = YAHXSBHRDV.makeIdentity(res);
                    if ((FELAYWINFO != null) && this.FELAYWINFO.equals(identity)) {
                        // This call does not match our tag, we should put it back and try again
                        HNLBOHOHAU.put(res);
                    } else {
                        VECEXYZPZY++;
                        CTFGHPHDKY = res;
                    }
                } 
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    // Assert we can take exactly the numberOfTakes
    public void assertCanTake(BlockingQueue<Schedulable> ASMYYZCHDF, int MOHLDOUCXN, int KHYPQGRCND) throws InterruptedException {
        TestFairCallQueue.Taker TDSJHMTFCR = new TestFairCallQueue.Taker(ASMYYZCHDF, KHYPQGRCND, "default");
        Thread TDAVEWSOXQ = new Thread(TDSJHMTFCR);
        TDAVEWSOXQ.start();
        TDAVEWSOXQ.join(100);
        assertEquals(MOHLDOUCXN, TDSJHMTFCR.VECEXYZPZY);
        TDAVEWSOXQ.interrupt();
    }

    // Assert we can put exactly the numberOfPuts
    public void assertCanPut(BlockingQueue<Schedulable> ZGXBJGABOT, int CUFKYDNNIT, int HALAWJUZEV) throws InterruptedException {
        TestFairCallQueue.Putter WUQHFUYRYN = new TestFairCallQueue.Putter(ZGXBJGABOT, HALAWJUZEV, null);
        Thread NQMZNQPKWF = new Thread(WUQHFUYRYN);
        NQMZNQPKWF.start();
        NQMZNQPKWF.join(100);
        assertEquals(CUFKYDNNIT, WUQHFUYRYN.FYNVOYPYEE);
        NQMZNQPKWF.interrupt();
    }

    // Make sure put will overflow into lower queues when the top is full
    public void testPutOverflows() throws InterruptedException {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        // We can fit more than 5, even though the scheduler suggests the top queue
        assertCanPut(YSMBQUSJQF, 8, 8);
        assertEquals(8, YSMBQUSJQF.size());
    }

    public void testPutBlocksWhenAllFull() throws InterruptedException {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        assertCanPut(YSMBQUSJQF, 10, 10);// Fill up

        assertEquals(10, YSMBQUSJQF.size());
        // Put more which causes overflow
        assertCanPut(YSMBQUSJQF, 0, 1);// Will block

    }

    public void testTakeBlocksWhenEmpty() throws InterruptedException {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        assertCanTake(YSMBQUSJQF, 0, 1);
    }

    public void testTakeRemovesCall() throws InterruptedException {
        YSMBQUSJQF.setScheduler(SIKFRIGTBA);
        Schedulable DJQWWBFXHO = mockCall("c");
        YSMBQUSJQF.offer(DJQWWBFXHO);
        assertEquals(DJQWWBFXHO, YSMBQUSJQF.take());
        assertEquals(0, YSMBQUSJQF.size());
    }

    public void testTakeTriesNextQueue() throws InterruptedException {
        // Make a FCQ filled with calls in q 1 but empty in q 0
        RpcScheduler UCCVJDKJRJ = mock(RpcScheduler.class);
        when(UCCVJDKJRJ.getPriorityLevel(org.mockito.Matchers.<Schedulable>any())).thenReturn(1);
        YSMBQUSJQF.setScheduler(UCCVJDKJRJ);
        // A mux which only draws from q 0
        RpcMultiplexer QZYCNGLTYH = mock(RpcMultiplexer.class);
        when(QZYCNGLTYH.getAndAdvanceCurrentIndex()).thenReturn(0);
        YSMBQUSJQF.setMultiplexer(QZYCNGLTYH);
        Schedulable INJTGLELNW = mockCall("c");
        YSMBQUSJQF.put(INJTGLELNW);
        // Take from q1 even though mux said q0, since q0 empty
        assertEquals(INJTGLELNW, YSMBQUSJQF.take());
        assertEquals(0, YSMBQUSJQF.size());
    }
}