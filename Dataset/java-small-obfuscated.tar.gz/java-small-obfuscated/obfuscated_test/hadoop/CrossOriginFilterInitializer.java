public class CrossOriginFilterInitializer extends FilterInitializer {
    public static final String HJGICRRGAJ = "yarn.timeline-service.http-cross-origin.";

    @Override
    public void initFilter(FilterContainer ILSCNCNQBT, Configuration VONXWPANEF) {
        ILSCNCNQBT.addGlobalFilter("Cross Origin Filter", CrossOriginFilter.class.getName(), CrossOriginFilterInitializer.getFilterParameters(VONXWPANEF));
    }

    static Map<String, String> getFilterParameters(Configuration VIVWCMCLNN) {
        return VIVWCMCLNN.getValByRegex(CrossOriginFilterInitializer.HJGICRRGAJ);
    }
}