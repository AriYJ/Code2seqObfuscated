public class ClientCache {
    private final Configuration BVJCZEMPLW;

    private final ResourceMgrDelegate ZIYTXLRDZA;

    private static final Log APHFTXGOYW = LogFactory.getLog(ClientCache.class);

    private Map<JobID, ClientServiceDelegate> EXVGGVIWEP = new HashMap<JobID, ClientServiceDelegate>();

    private MRClientProtocol EZGFOKHVUW;

    public ClientCache(Configuration IFRXEVHPPS, ResourceMgrDelegate BCKKCANIXV) {
        this.BVJCZEMPLW = IFRXEVHPPS;
        this.ZIYTXLRDZA = BCKKCANIXV;
    }

    // TODO: evict from the cache on some threshold
    public synchronized ClientServiceDelegate getClient(JobID XUHIXBWDQR) {
        if (EZGFOKHVUW == null) {
            try {
                EZGFOKHVUW = instantiateHistoryProxy();
            } catch (IOException e) {
                ClientCache.APHFTXGOYW.warn("Could not connect to History server.", e);
                throw new YarnRuntimeException("Could not connect to History server.", e);
            }
        }
        ClientServiceDelegate IDAQZFOHOX = EXVGGVIWEP.get(XUHIXBWDQR);
        if (IDAQZFOHOX == null) {
            IDAQZFOHOX = new ClientServiceDelegate(BVJCZEMPLW, ZIYTXLRDZA, XUHIXBWDQR, EZGFOKHVUW);
            EXVGGVIWEP.put(XUHIXBWDQR, IDAQZFOHOX);
        }
        return IDAQZFOHOX;
    }

    protected synchronized MRClientProtocol getInitializedHSProxy() throws IOException {
        if (this.EZGFOKHVUW == null) {
            EZGFOKHVUW = instantiateHistoryProxy();
        }
        return this.EZGFOKHVUW;
    }

    protected MRClientProtocol instantiateHistoryProxy() throws IOException {
        final String SWMIQQVJHK = BVJCZEMPLW.get(MR_HISTORY_ADDRESS);
        if (StringUtils.isEmpty(SWMIQQVJHK)) {
            return null;
        }
        ClientCache.APHFTXGOYW.debug("Connecting to HistoryServer at: " + SWMIQQVJHK);
        final YarnRPC CMOMBVDUQV = YarnRPC.create(BVJCZEMPLW);
        ClientCache.APHFTXGOYW.debug("Connected to HistoryServer at: " + SWMIQQVJHK);
        UserGroupInformation IWQMAIFADW = UserGroupInformation.getCurrentUser();
        return IWQMAIFADW.doAs(new PrivilegedAction<MRClientProtocol>() {
            @Override
            public MRClientProtocol run() {
                return ((MRClientProtocol) (CMOMBVDUQV.getProxy(HSClientProtocol.class, NetUtils.createSocketAddr(SWMIQQVJHK), BVJCZEMPLW)));
            }
        });
    }
}