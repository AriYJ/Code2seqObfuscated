@InterfaceAudience.LimitedPrivate({ "MapReduce" })
@InterfaceStability.Unstable
public class SpillRecord {
    /**
     * Backing store
     */
    private final ByteBuffer MLAVAJZQBU;

    /**
     * View of backing storage as longs
     */
    private final LongBuffer YEMAUFLVKR;

    public SpillRecord(int PEGBPUIQNF) {
        MLAVAJZQBU = ByteBuffer.allocate(PEGBPUIQNF * MapTask.MAP_OUTPUT_INDEX_RECORD_LENGTH);
        YEMAUFLVKR = MLAVAJZQBU.asLongBuffer();
    }

    public SpillRecord(Path QTRBBZOXQO, JobConf FICAPGJKGP) throws IOException {
        this(QTRBBZOXQO, FICAPGJKGP, null);
    }

    public SpillRecord(Path IMZJZCCKLD, JobConf SFNIUVMNZR, String BNIGWWMLDF) throws IOException {
        this(IMZJZCCKLD, SFNIUVMNZR, new PureJavaCrc32(), BNIGWWMLDF);
    }

    public SpillRecord(Path RHJBXXIGLD, JobConf RYFECAFXOC, Checksum SMLJCQEIPK, String ZWGTIAGXOP) throws IOException {
        final FileSystem GQDJLTDVDA = FileSystem.getLocal(RYFECAFXOC).getRaw();
        final FSDataInputStream UHLZKTEUKG = SecureIOUtils.openFSDataInputStream(new File(RHJBXXIGLD.toUri().getRawPath()), ZWGTIAGXOP, null);
        try {
            final long STHYSJAXBD = GQDJLTDVDA.getFileStatus(RHJBXXIGLD).getLen();
            final int ULSNYSFFST = ((int) (STHYSJAXBD)) / MapTask.MAP_OUTPUT_INDEX_RECORD_LENGTH;
            final int VJQLCQGYYK = ULSNYSFFST * MapTask.MAP_OUTPUT_INDEX_RECORD_LENGTH;
            MLAVAJZQBU = ByteBuffer.allocate(VJQLCQGYYK);
            if (SMLJCQEIPK != null) {
                SMLJCQEIPK.reset();
                CheckedInputStream LGGOXMYQTO = new CheckedInputStream(UHLZKTEUKG, SMLJCQEIPK);
                IOUtils.readFully(LGGOXMYQTO, MLAVAJZQBU.array(), 0, VJQLCQGYYK);
                if (LGGOXMYQTO.getChecksum().getValue() != UHLZKTEUKG.readLong()) {
                    throw new org.apache.hadoop.fs.ChecksumException("Checksum error reading spill index: " + RHJBXXIGLD, -1);
                }
            } else {
                IOUtils.readFully(UHLZKTEUKG, MLAVAJZQBU.array(), 0, VJQLCQGYYK);
            }
            YEMAUFLVKR = MLAVAJZQBU.asLongBuffer();
        } finally {
            UHLZKTEUKG.close();
        }
    }

    /**
     * Return number of IndexRecord entries in this spill.
     */
    public int size() {
        return YEMAUFLVKR.capacity() / (MapTask.MAP_OUTPUT_INDEX_RECORD_LENGTH / 8);
    }

    /**
     * Get spill offsets for given partition.
     */
    public IndexRecord getIndex(int JVVUMBADEN) {
        final int ABXFNWXEWT = (JVVUMBADEN * MapTask.MAP_OUTPUT_INDEX_RECORD_LENGTH) / 8;
        return new IndexRecord(YEMAUFLVKR.get(ABXFNWXEWT), YEMAUFLVKR.get(ABXFNWXEWT + 1), YEMAUFLVKR.get(ABXFNWXEWT + 2));
    }

    /**
     * Set spill offsets for given partition.
     */
    public void putIndex(IndexRecord GXQGSGQUWC, int ZTYJNKWFJP) {
        final int PXFBHKDWPZ = (ZTYJNKWFJP * MapTask.MAP_OUTPUT_INDEX_RECORD_LENGTH) / 8;
        YEMAUFLVKR.put(PXFBHKDWPZ, GXQGSGQUWC.startOffset);
        YEMAUFLVKR.put(PXFBHKDWPZ + 1, GXQGSGQUWC.rawLength);
        YEMAUFLVKR.put(PXFBHKDWPZ + 2, GXQGSGQUWC.partLength);
    }

    /**
     * Write this spill record to the location provided.
     */
    public void writeToFile(Path LOFVFQHGSS, JobConf TNLHOLFCAP) throws IOException {
        writeToFile(LOFVFQHGSS, TNLHOLFCAP, new PureJavaCrc32());
    }

    public void writeToFile(Path WMRARIDNKO, JobConf KLFRWKPCDQ, Checksum SNOUPVFMSR) throws IOException {
        final FileSystem OZVQSMXVWP = FileSystem.getLocal(KLFRWKPCDQ).getRaw();
        CheckedOutputStream KLPGOPKXUH = null;
        final FSDataOutputStream LVAKJJEKFA = OZVQSMXVWP.create(WMRARIDNKO);
        try {
            if (SNOUPVFMSR != null) {
                SNOUPVFMSR.reset();
                KLPGOPKXUH = new CheckedOutputStream(LVAKJJEKFA, SNOUPVFMSR);
                KLPGOPKXUH.write(MLAVAJZQBU.array());
                LVAKJJEKFA.writeLong(KLPGOPKXUH.getChecksum().getValue());
            } else {
                LVAKJJEKFA.write(MLAVAJZQBU.array());
            }
        } finally {
            if (KLPGOPKXUH != null) {
                KLPGOPKXUH.close();
            } else {
                LVAKJJEKFA.close();
            }
        }
    }
}