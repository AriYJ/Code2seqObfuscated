public class TestYarnClientProtocolProvider extends TestCase {
    private static final RecordFactory GIUGDLUCFG = RecordFactoryProvider.getRecordFactory(null);

    @Test
    public void testClusterWithYarnClientProtocolProvider() throws Exception {
        Configuration LCBGEBOPLT = new Configuration(false);
        Cluster ZKMWRNSSUR = null;
        try {
            ZKMWRNSSUR = new Cluster(LCBGEBOPLT);
        } catch (Exception e) {
            throw new Exception("Failed to initialize a local runner w/o a cluster framework key", e);
        }
        try {
            assertTrue("client is not a LocalJobRunner", ZKMWRNSSUR.getClient() instanceof LocalJobRunner);
        } finally {
            if (ZKMWRNSSUR != null) {
                ZKMWRNSSUR.close();
            }
        }
        try {
            LCBGEBOPLT = new Configuration();
            LCBGEBOPLT.set(FRAMEWORK_NAME, YARN_FRAMEWORK_NAME);
            ZKMWRNSSUR = new Cluster(LCBGEBOPLT);
            ClientProtocol DTKPFVFKII = ZKMWRNSSUR.getClient();
            assertTrue("client is a YARNRunner", DTKPFVFKII instanceof YARNRunner);
        } catch (IOException e) {
        } finally {
            if (ZKMWRNSSUR != null) {
                ZKMWRNSSUR.close();
            }
        }
    }

    @Test
    public void testClusterGetDelegationToken() throws Exception {
        Configuration TCJQRNVZXW = new Configuration(false);
        Cluster TCWVNBNAWX = null;
        try {
            TCJQRNVZXW = new Configuration();
            TCJQRNVZXW.set(FRAMEWORK_NAME, YARN_FRAMEWORK_NAME);
            TCWVNBNAWX = new Cluster(TCJQRNVZXW);
            YARNRunner QTRENQTXWP = ((YARNRunner) (TCWVNBNAWX.getClient()));
            GetDelegationTokenResponse ILGVBNNZQG = TestYarnClientProtocolProvider.GIUGDLUCFG.newRecordInstance(GetDelegationTokenResponse.class);
            Token YAZMTOIYFN = TestYarnClientProtocolProvider.GIUGDLUCFG.newRecordInstance(org.apache.hadoop.security.token.Token.class);
            YAZMTOIYFN.setIdentifier(ByteBuffer.wrap(new byte[2]));
            YAZMTOIYFN.setKind("Testclusterkind");
            YAZMTOIYFN.setPassword(ByteBuffer.wrap("testcluster".getBytes()));
            YAZMTOIYFN.setService("0.0.0.0:8032");
            ILGVBNNZQG.setRMDelegationToken(YAZMTOIYFN);
            final ApplicationClientProtocol TPFGQSVTYW = mock(ApplicationClientProtocol.class);
            when(TPFGQSVTYW.getDelegationToken(any(org.apache.hadoop.yarn.api.protocolrecords.GetDelegationTokenRequest.class))).thenReturn(ILGVBNNZQG);
            ResourceMgrDelegate DBSBQPGYAO = new ResourceMgrDelegate(new org.apache.hadoop.yarn.conf.YarnConfiguration(TCJQRNVZXW)) {
                @Override
                protected void serviceStart() throws Exception {
                    assertTrue(this.client instanceof YarnClientImpl);
                    ((YarnClientImpl) (this.client)).setRMClient(TPFGQSVTYW);
                }
            };
            QTRENQTXWP.setResourceMgrDelegate(DBSBQPGYAO);
            org.apache.hadoop.security.token.Token UVCJKINRKK = TCWVNBNAWX.getDelegationToken(new Text(" "));
            assertTrue("Token kind is instead " + UVCJKINRKK.getKind().toString(), "Testclusterkind".equals(UVCJKINRKK.getKind().toString()));
        } finally {
            if (TCWVNBNAWX != null) {
                TCWVNBNAWX.close();
            }
        }
    }
}