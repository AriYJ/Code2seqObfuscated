/**
 * The OptionsParser parses out the command-line options passed to DistCp,
 * and interprets those specific to DistCp, to create an Options object.
 */
public class OptionsParser {
    private static final Log EGHSJBUSWP = LogFactory.getLog(OptionsParser.class);

    private static final Options ILGPLUSZYP = new Options();

    static {
        for (DistCpOptionSwitch option : DistCpOptionSwitch.values()) {
            if (OptionsParser.EGHSJBUSWP.isDebugEnabled()) {
                OptionsParser.EGHSJBUSWP.debug("Adding option " + option.getOption());
            }
            OptionsParser.ILGPLUSZYP.addOption(option.getOption());
        }
    }

    private static class CustomParser extends GnuParser {
        @Override
        protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
            for (int index = 0; index < arguments.length; index++) {
                if (arguments[index].equals("-" + PRESERVE_STATUS.getSwitch())) {
                    arguments[index] = DistCpOptionSwitch.PRESERVE_STATUS_DEFAULT;
                }
            }
            return super.flatten(options, arguments, stopAtNonOption);
        }
    }

    /**
     * The parse method parses the command-line options, and creates
     * a corresponding Options object.
     *
     * @param args
     * 		Command-line arguments (excluding the options consumed
     * 		by the GenericOptionsParser).
     * @return The Options object, corresponding to the specified command-line.
     * @throws IllegalArgumentException:
     * 		Thrown if the parse fails.
     */
    public static DistCpOptions parse(String[] DNLSSQEANH) throws IllegalArgumentException {
        CommandLineParser XHPPLKNFZN = new OptionsParser.CustomParser();
        CommandLine OCUYPCMTXC;
        try {
            OCUYPCMTXC = XHPPLKNFZN.parse(OptionsParser.ILGPLUSZYP, DNLSSQEANH, true);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Unable to parse arguments. " + Arrays.toString(DNLSSQEANH), e);
        }
        DistCpOptions XJMDLGDDBS;
        Path DXASLSQXAS;
        List<Path> CWAPBDCRUM = new ArrayList<Path>();
        String[] AZZDRYCFCB = OCUYPCMTXC.getArgs();
        if ((AZZDRYCFCB == null) || (AZZDRYCFCB.length < 1)) {
            throw new IllegalArgumentException("Target path not specified");
        }
        // Last Argument is the target path
        DXASLSQXAS = new Path(AZZDRYCFCB[AZZDRYCFCB.length - 1].trim());
        // Copy any source paths in the arguments to the list
        for (int HYUKMVYZWP = 0; HYUKMVYZWP < (AZZDRYCFCB.length - 1); HYUKMVYZWP++) {
            CWAPBDCRUM.add(new Path(AZZDRYCFCB[HYUKMVYZWP].trim()));
        }
        /* If command has source file listing, use it else, fall back on source paths in args
        If both are present, throw exception and bail
         */
        if (OCUYPCMTXC.hasOption(SOURCE_FILE_LISTING.getSwitch())) {
            if (!CWAPBDCRUM.isEmpty()) {
                throw new IllegalArgumentException("Both source file listing and source paths present");
            }
            XJMDLGDDBS = new DistCpOptions(new Path(OptionsParser.getVal(OCUYPCMTXC, SOURCE_FILE_LISTING.getSwitch())), DXASLSQXAS);
        } else {
            if (CWAPBDCRUM.isEmpty()) {
                throw new IllegalArgumentException("Neither source file listing nor source paths present");
            }
            XJMDLGDDBS = new DistCpOptions(CWAPBDCRUM, DXASLSQXAS);
        }
        // Process all the other option switches and set options appropriately
        if (OCUYPCMTXC.hasOption(IGNORE_FAILURES.getSwitch())) {
            XJMDLGDDBS.setIgnoreFailures(true);
        }
        if (OCUYPCMTXC.hasOption(ATOMIC_COMMIT.getSwitch())) {
            XJMDLGDDBS.setAtomicCommit(true);
        }
        if (OCUYPCMTXC.hasOption(WORK_PATH.getSwitch()) && XJMDLGDDBS.shouldAtomicCommit()) {
            String JZFGDLVVQX = OptionsParser.getVal(OCUYPCMTXC, WORK_PATH.getSwitch());
            if ((JZFGDLVVQX != null) && (!JZFGDLVVQX.isEmpty())) {
                XJMDLGDDBS.setAtomicWorkPath(new Path(JZFGDLVVQX));
            }
        } else
            if (OCUYPCMTXC.hasOption(WORK_PATH.getSwitch())) {
                throw new IllegalArgumentException("-tmp work-path can only be specified along with -atomic");
            }

        if (OCUYPCMTXC.hasOption(LOG_PATH.getSwitch())) {
            XJMDLGDDBS.setLogPath(new Path(OptionsParser.getVal(OCUYPCMTXC, LOG_PATH.getSwitch())));
        }
        if (OCUYPCMTXC.hasOption(SYNC_FOLDERS.getSwitch())) {
            XJMDLGDDBS.setSyncFolder(true);
        }
        if (OCUYPCMTXC.hasOption(OVERWRITE.getSwitch())) {
            XJMDLGDDBS.setOverwrite(true);
        }
        if (OCUYPCMTXC.hasOption(APPEND.getSwitch())) {
            XJMDLGDDBS.setAppend(true);
        }
        if (OCUYPCMTXC.hasOption(DELETE_MISSING.getSwitch())) {
            XJMDLGDDBS.setDeleteMissing(true);
        }
        if (OCUYPCMTXC.hasOption(SKIP_CRC.getSwitch())) {
            XJMDLGDDBS.setSkipCRC(true);
        }
        if (OCUYPCMTXC.hasOption(BLOCKING.getSwitch())) {
            XJMDLGDDBS.setBlocking(false);
        }
        if (OCUYPCMTXC.hasOption(BANDWIDTH.getSwitch())) {
            try {
                Integer EGSMNXZEOF = Integer.parseInt(OptionsParser.getVal(OCUYPCMTXC, BANDWIDTH.getSwitch()).trim());
                if (EGSMNXZEOF.intValue() <= 0) {
                    throw new IllegalArgumentException("Bandwidth specified is not positive: " + EGSMNXZEOF);
                }
                XJMDLGDDBS.setMapBandwidth(EGSMNXZEOF);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Bandwidth specified is invalid: " + OptionsParser.getVal(OCUYPCMTXC, BANDWIDTH.getSwitch()), e);
            }
        }
        if (OCUYPCMTXC.hasOption(SSL_CONF.getSwitch())) {
            XJMDLGDDBS.setSslConfigurationFile(OCUYPCMTXC.getOptionValue(SSL_CONF.getSwitch()));
        }
        if (OCUYPCMTXC.hasOption(MAX_MAPS.getSwitch())) {
            try {
                Integer FVPICZLEMM = Integer.parseInt(OptionsParser.getVal(OCUYPCMTXC, MAX_MAPS.getSwitch()).trim());
                XJMDLGDDBS.setMaxMaps(FVPICZLEMM);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Number of maps is invalid: " + OptionsParser.getVal(OCUYPCMTXC, MAX_MAPS.getSwitch()), e);
            }
        }
        if (OCUYPCMTXC.hasOption(COPY_STRATEGY.getSwitch())) {
            XJMDLGDDBS.setCopyStrategy(OptionsParser.getVal(OCUYPCMTXC, COPY_STRATEGY.getSwitch()));
        }
        if (OCUYPCMTXC.hasOption(PRESERVE_STATUS.getSwitch())) {
            String VIHYXSSIJN = OptionsParser.getVal(OCUYPCMTXC, PRESERVE_STATUS.getSwitch());
            if ((VIHYXSSIJN == null) || VIHYXSSIJN.isEmpty()) {
                for (FileAttribute OUKCGSYJDU : FileAttribute.values()) {
                    XJMDLGDDBS.preserve(OUKCGSYJDU);
                }
            } else {
                for (int PGAXXVUNAN = 0; PGAXXVUNAN < VIHYXSSIJN.length(); PGAXXVUNAN++) {
                    XJMDLGDDBS.preserve(FileAttribute.getAttribute(VIHYXSSIJN.charAt(PGAXXVUNAN)));
                }
            }
        }
        if (OCUYPCMTXC.hasOption(FILE_LIMIT.getSwitch())) {
            String YKCVQMHLAS = OptionsParser.getVal(OCUYPCMTXC, FILE_LIMIT.getSwitch().trim());
            try {
                Integer.parseInt(YKCVQMHLAS);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("File-limit is invalid: " + YKCVQMHLAS, e);
            }
            OptionsParser.EGHSJBUSWP.warn((FILE_LIMIT.getSwitch() + " is a deprecated") + " option. Ignoring.");
        }
        if (OCUYPCMTXC.hasOption(SIZE_LIMIT.getSwitch())) {
            String ALYKLKSCTG = OptionsParser.getVal(OCUYPCMTXC, SIZE_LIMIT.getSwitch().trim());
            try {
                Long.parseLong(ALYKLKSCTG);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Size-limit is invalid: " + ALYKLKSCTG, e);
            }
            OptionsParser.EGHSJBUSWP.warn((SIZE_LIMIT.getSwitch() + " is a deprecated") + " option. Ignoring.");
        }
        return XJMDLGDDBS;
    }

    private static String getVal(CommandLine EWNAWCKNDT, String VTTOEZTSHR) {
        String WWICMIXIDM = EWNAWCKNDT.getOptionValue(VTTOEZTSHR);
        if (WWICMIXIDM == null) {
            return null;
        } else {
            return WWICMIXIDM.trim();
        }
    }

    public static void usage() {
        HelpFormatter NTBSRVFFCB = new HelpFormatter();
        NTBSRVFFCB.printHelp("distcp OPTIONS [source_path...] <target_path>\n\nOPTIONS", OptionsParser.ILGPLUSZYP);
    }
}