/**
 * Tests for upgrading with HA enabled.
 */
public class TestDFSUpgradeWithHA {
    private static final Log APDTGRLAVG = LogFactory.getLog(TestDFSUpgradeWithHA.class);

    private Configuration CMRTJKMJYF;

    @Before
    public void createConfiguration() {
        CMRTJKMJYF = new HdfsConfiguration();
        // Turn off persistent IPC, so that the DFSClient can survive NN restart
        CMRTJKMJYF.setInt(IPC_CLIENT_CONNECTION_MAXIDLETIME_KEY, 0);
    }

    private static void assertCTimesEqual(MiniDFSCluster NKWCBKPCBQ) {
        long UVLCWDKTLP = NKWCBKPCBQ.getNamesystem(0).getFSImage().getStorage().getCTime();
        long PKFIDAZNQU = NKWCBKPCBQ.getNamesystem(1).getFSImage().getStorage().getCTime();
        assertEquals(UVLCWDKTLP, PKFIDAZNQU);
    }

    private static void checkClusterPreviousDirExistence(MiniDFSCluster GVAHMIXEDG, boolean ALOKBRIGWO) {
        for (int XJHNHOHFBO = 0; XJHNHOHFBO < 2; XJHNHOHFBO++) {
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(GVAHMIXEDG, XJHNHOHFBO, ALOKBRIGWO);
        }
    }

    private static void checkNnPreviousDirExistence(MiniDFSCluster PTIYGYYMOX, int HOUAAFMMMY, boolean UUIAOGCFPN) {
        Collection<URI> HGGRCROIUJ = PTIYGYYMOX.getNameDirs(HOUAAFMMMY);
        for (URI BRPCIJZFNT : HGGRCROIUJ) {
            TestDFSUpgradeWithHA.checkPreviousDirExistence(new File(BRPCIJZFNT), UUIAOGCFPN);
        }
    }

    private static void checkJnPreviousDirExistence(MiniQJMHACluster VPDYHUPIWY, boolean FANGAFZHJU) throws IOException {
        for (int BBMBCGADPG = 0; BBMBCGADPG < 3; BBMBCGADPG++) {
            TestDFSUpgradeWithHA.checkPreviousDirExistence(VPDYHUPIWY.getJournalCluster().getJournalDir(BBMBCGADPG, "ns1"), FANGAFZHJU);
        }
        if (FANGAFZHJU) {
            TestDFSUpgradeWithHA.assertEpochFilesCopied(VPDYHUPIWY);
        }
    }

    private static void assertEpochFilesCopied(MiniQJMHACluster JBUZJTTFYQ) throws IOException {
        for (int HVXADBBLHS = 0; HVXADBBLHS < 3; HVXADBBLHS++) {
            File VTKGUYAZVD = JBUZJTTFYQ.getJournalCluster().getJournalDir(HVXADBBLHS, "ns1");
            File GFDSXHMWUF = new File(VTKGUYAZVD, "current");
            File WUNXMQSQBV = new File(VTKGUYAZVD, "previous");
            for (String CMTRSTZLHU : new String[]{ Journal.LAST_PROMISED_FILENAME, Journal.LAST_WRITER_EPOCH }) {
                File XYUTYIIDLK = new File(WUNXMQSQBV, CMTRSTZLHU);
                // Possible the prev file doesn't exist, e.g. if there has never been a
                // writer before the upgrade.
                if (XYUTYIIDLK.exists()) {
                    PersistentLongFile RFCWGXGWFG = new PersistentLongFile(XYUTYIIDLK, -10);
                    PersistentLongFile EWNSPHNBEC = new PersistentLongFile(new File(GFDSXHMWUF, CMTRSTZLHU), -11);
                    assertTrue((("Value in " + CMTRSTZLHU) + " has decreased on upgrade in ") + VTKGUYAZVD, RFCWGXGWFG.get() <= EWNSPHNBEC.get());
                }
            }
        }
    }

    private static void checkPreviousDirExistence(File YOVEONQRLV, boolean JVFTACQDLC) {
        File NFIKZWQMYE = new File(YOVEONQRLV, "previous");
        if (JVFTACQDLC) {
            assertTrue(NFIKZWQMYE + " does not exist", NFIKZWQMYE.exists());
        } else {
            assertFalse(NFIKZWQMYE + " does exist", NFIKZWQMYE.exists());
        }
    }

    private void runFinalizeCommand(MiniDFSCluster PDUSYDJMXN) throws IOException {
        HATestUtil.setFailoverConfigurations(PDUSYDJMXN, CMRTJKMJYF);
        new org.apache.hadoop.hdfs.tools.DFSAdmin(CMRTJKMJYF).finalizeUpgrade();
    }

    /**
     * Ensure that an admin cannot finalize an HA upgrade without at least one NN
     * being active.
     */
    @Test
    public void testCannotFinalizeIfNoActive() throws IOException, URISyntaxException {
        MiniDFSCluster FSAOPODYKA = null;
        FileSystem PDKPXHAYAE = null;
        try {
            FSAOPODYKA = new MiniDFSCluster.Builder(CMRTJKMJYF).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).build();
            File MZEDKBMBFI = new File(FSAOPODYKA.getSharedEditsDir(0, 1));
            // No upgrade is in progress at the moment.
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(FSAOPODYKA, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(FSAOPODYKA);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(MZEDKBMBFI, false);
            // Transition NN0 to active and do some FS ops.
            FSAOPODYKA.transitionToActive(0);
            PDKPXHAYAE = HATestUtil.configureFailoverFs(FSAOPODYKA, CMRTJKMJYF);
            assertTrue(PDKPXHAYAE.mkdirs(new Path("/foo1")));
            // Do the upgrade. Shut down NN1 and then restart NN0 with the upgrade
            // flag.
            FSAOPODYKA.shutdownNameNode(1);
            FSAOPODYKA.getNameNodeInfos()[0].setStartOpt(StartupOption.UPGRADE);
            FSAOPODYKA.restartNameNode(0, false);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(FSAOPODYKA, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(FSAOPODYKA, 1, false);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(MZEDKBMBFI, true);
            // NN0 should come up in the active state when given the -upgrade option,
            // so no need to transition it to active.
            assertTrue(PDKPXHAYAE.mkdirs(new Path("/foo2")));
            // Restart NN0 without the -upgrade flag, to make sure that works.
            FSAOPODYKA.getNameNodeInfos()[0].setStartOpt(StartupOption.REGULAR);
            FSAOPODYKA.restartNameNode(0, false);
            // Make sure we can still do FS ops after upgrading.
            FSAOPODYKA.transitionToActive(0);
            assertTrue(PDKPXHAYAE.mkdirs(new Path("/foo3")));
            // Now bootstrap the standby with the upgraded info.
            int UZXOLISYSO = BootstrapStandby.run(new String[]{ "-force" }, FSAOPODYKA.getConfiguration(1));
            assertEquals(0, UZXOLISYSO);
            // Now restart NN1 and make sure that we can do ops against that as well.
            FSAOPODYKA.restartNameNode(1);
            FSAOPODYKA.transitionToStandby(0);
            FSAOPODYKA.transitionToActive(1);
            assertTrue(PDKPXHAYAE.mkdirs(new Path("/foo4")));
            TestDFSUpgradeWithHA.assertCTimesEqual(FSAOPODYKA);
            // Now there's no active NN.
            FSAOPODYKA.transitionToStandby(1);
            try {
                runFinalizeCommand(FSAOPODYKA);
                fail("Should not have been able to finalize upgrade with no NN active");
            } catch (IOException ioe) {
                GenericTestUtils.assertExceptionContains("Cannot finalize with no NameNode active", ioe);
            }
        } finally {
            if (PDKPXHAYAE != null) {
                PDKPXHAYAE.close();
            }
            if (FSAOPODYKA != null) {
                FSAOPODYKA.shutdown();
            }
        }
    }

    /**
     * Make sure that an HA NN with NFS-based HA can successfully start and
     * upgrade.
     */
    @Test
    public void testNfsUpgrade() throws IOException, URISyntaxException {
        MiniDFSCluster QAPNJJYICR = null;
        FileSystem AXSIRLPRYU = null;
        try {
            QAPNJJYICR = new MiniDFSCluster.Builder(CMRTJKMJYF).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).build();
            File WUTTRAXMZO = new File(QAPNJJYICR.getSharedEditsDir(0, 1));
            // No upgrade is in progress at the moment.
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(QAPNJJYICR, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(QAPNJJYICR);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(WUTTRAXMZO, false);
            // Transition NN0 to active and do some FS ops.
            QAPNJJYICR.transitionToActive(0);
            AXSIRLPRYU = HATestUtil.configureFailoverFs(QAPNJJYICR, CMRTJKMJYF);
            assertTrue(AXSIRLPRYU.mkdirs(new Path("/foo1")));
            // Do the upgrade. Shut down NN1 and then restart NN0 with the upgrade
            // flag.
            QAPNJJYICR.shutdownNameNode(1);
            QAPNJJYICR.getNameNodeInfos()[0].setStartOpt(StartupOption.UPGRADE);
            QAPNJJYICR.restartNameNode(0, false);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(QAPNJJYICR, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(QAPNJJYICR, 1, false);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(WUTTRAXMZO, true);
            // NN0 should come up in the active state when given the -upgrade option,
            // so no need to transition it to active.
            assertTrue(AXSIRLPRYU.mkdirs(new Path("/foo2")));
            // Restart NN0 without the -upgrade flag, to make sure that works.
            QAPNJJYICR.getNameNodeInfos()[0].setStartOpt(StartupOption.REGULAR);
            QAPNJJYICR.restartNameNode(0, false);
            // Make sure we can still do FS ops after upgrading.
            QAPNJJYICR.transitionToActive(0);
            assertTrue(AXSIRLPRYU.mkdirs(new Path("/foo3")));
            // Now bootstrap the standby with the upgraded info.
            int GPDGEUNRDJ = BootstrapStandby.run(new String[]{ "-force" }, QAPNJJYICR.getConfiguration(1));
            assertEquals(0, GPDGEUNRDJ);
            // Now restart NN1 and make sure that we can do ops against that as well.
            QAPNJJYICR.restartNameNode(1);
            QAPNJJYICR.transitionToStandby(0);
            QAPNJJYICR.transitionToActive(1);
            assertTrue(AXSIRLPRYU.mkdirs(new Path("/foo4")));
            TestDFSUpgradeWithHA.assertCTimesEqual(QAPNJJYICR);
        } finally {
            if (AXSIRLPRYU != null) {
                AXSIRLPRYU.close();
            }
            if (QAPNJJYICR != null) {
                QAPNJJYICR.shutdown();
            }
        }
    }

    /**
     * Make sure that an HA NN can successfully upgrade when configured using
     * JournalNodes.
     */
    @Test
    public void testUpgradeWithJournalNodes() throws IOException, URISyntaxException {
        MiniQJMHACluster SUDXMEZLEJ = null;
        FileSystem FKXWJKBLLX = null;
        try {
            Builder RTADAGWSVZ = new MiniQJMHACluster.Builder(CMRTJKMJYF);
            RTADAGWSVZ.getDfsBuilder().numDataNodes(0);
            SUDXMEZLEJ = RTADAGWSVZ.build();
            MiniDFSCluster QAROQSCHVR = SUDXMEZLEJ.getDfsCluster();
            // No upgrade is in progress at the moment.
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(SUDXMEZLEJ, false);
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(QAROQSCHVR, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(QAROQSCHVR);
            // Transition NN0 to active and do some FS ops.
            QAROQSCHVR.transitionToActive(0);
            FKXWJKBLLX = HATestUtil.configureFailoverFs(QAROQSCHVR, CMRTJKMJYF);
            assertTrue(FKXWJKBLLX.mkdirs(new Path("/foo1")));
            // Do the upgrade. Shut down NN1 and then restart NN0 with the upgrade
            // flag.
            QAROQSCHVR.shutdownNameNode(1);
            QAROQSCHVR.getNameNodeInfos()[0].setStartOpt(StartupOption.UPGRADE);
            QAROQSCHVR.restartNameNode(0, false);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(QAROQSCHVR, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(QAROQSCHVR, 1, false);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(SUDXMEZLEJ, true);
            // NN0 should come up in the active state when given the -upgrade option,
            // so no need to transition it to active.
            assertTrue(FKXWJKBLLX.mkdirs(new Path("/foo2")));
            // Restart NN0 without the -upgrade flag, to make sure that works.
            QAROQSCHVR.getNameNodeInfos()[0].setStartOpt(StartupOption.REGULAR);
            QAROQSCHVR.restartNameNode(0, false);
            // Make sure we can still do FS ops after upgrading.
            QAROQSCHVR.transitionToActive(0);
            assertTrue(FKXWJKBLLX.mkdirs(new Path("/foo3")));
            // Now bootstrap the standby with the upgraded info.
            int TNFFKHMXGB = BootstrapStandby.run(new String[]{ "-force" }, QAROQSCHVR.getConfiguration(1));
            assertEquals(0, TNFFKHMXGB);
            // Now restart NN1 and make sure that we can do ops against that as well.
            QAROQSCHVR.restartNameNode(1);
            QAROQSCHVR.transitionToStandby(0);
            QAROQSCHVR.transitionToActive(1);
            assertTrue(FKXWJKBLLX.mkdirs(new Path("/foo4")));
            TestDFSUpgradeWithHA.assertCTimesEqual(QAROQSCHVR);
        } finally {
            if (FKXWJKBLLX != null) {
                FKXWJKBLLX.close();
            }
            if (SUDXMEZLEJ != null) {
                SUDXMEZLEJ.shutdown();
            }
        }
    }

    @Test
    public void testFinalizeWithJournalNodes() throws IOException, URISyntaxException {
        MiniQJMHACluster KHLAMZZDZI = null;
        FileSystem PDJSHLKPFU = null;
        try {
            Builder FUVNDKEPIJ = new MiniQJMHACluster.Builder(CMRTJKMJYF);
            FUVNDKEPIJ.getDfsBuilder().numDataNodes(0);
            KHLAMZZDZI = FUVNDKEPIJ.build();
            MiniDFSCluster MTGRNHDNQR = KHLAMZZDZI.getDfsCluster();
            // No upgrade is in progress at the moment.
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(KHLAMZZDZI, false);
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(MTGRNHDNQR, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(MTGRNHDNQR);
            // Transition NN0 to active and do some FS ops.
            MTGRNHDNQR.transitionToActive(0);
            PDJSHLKPFU = HATestUtil.configureFailoverFs(MTGRNHDNQR, CMRTJKMJYF);
            assertTrue(PDJSHLKPFU.mkdirs(new Path("/foo1")));
            // Do the upgrade. Shut down NN1 and then restart NN0 with the upgrade
            // flag.
            MTGRNHDNQR.shutdownNameNode(1);
            MTGRNHDNQR.getNameNodeInfos()[0].setStartOpt(StartupOption.UPGRADE);
            MTGRNHDNQR.restartNameNode(0, false);
            assertTrue(PDJSHLKPFU.mkdirs(new Path("/foo2")));
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(MTGRNHDNQR, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(MTGRNHDNQR, 1, false);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(KHLAMZZDZI, true);
            // Now bootstrap the standby with the upgraded info.
            int PZMIMVGWHQ = BootstrapStandby.run(new String[]{ "-force" }, MTGRNHDNQR.getConfiguration(1));
            assertEquals(0, PZMIMVGWHQ);
            MTGRNHDNQR.restartNameNode(1);
            runFinalizeCommand(MTGRNHDNQR);
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(MTGRNHDNQR, false);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(KHLAMZZDZI, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(MTGRNHDNQR);
        } finally {
            if (PDJSHLKPFU != null) {
                PDJSHLKPFU.close();
            }
            if (KHLAMZZDZI != null) {
                KHLAMZZDZI.shutdown();
            }
        }
    }

    /**
     * Make sure that even if the NN which initiated the upgrade is in the standby
     * state that we're allowed to finalize.
     */
    @Test
    public void testFinalizeFromSecondNameNodeWithJournalNodes() throws IOException, URISyntaxException {
        MiniQJMHACluster OQBTKERQHH = null;
        FileSystem DDTXFXIXFN = null;
        try {
            Builder SZHTHTKUKH = new MiniQJMHACluster.Builder(CMRTJKMJYF);
            SZHTHTKUKH.getDfsBuilder().numDataNodes(0);
            OQBTKERQHH = SZHTHTKUKH.build();
            MiniDFSCluster MOEJCHYZKZ = OQBTKERQHH.getDfsCluster();
            // No upgrade is in progress at the moment.
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(OQBTKERQHH, false);
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(MOEJCHYZKZ, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(MOEJCHYZKZ);
            // Transition NN0 to active and do some FS ops.
            MOEJCHYZKZ.transitionToActive(0);
            DDTXFXIXFN = HATestUtil.configureFailoverFs(MOEJCHYZKZ, CMRTJKMJYF);
            assertTrue(DDTXFXIXFN.mkdirs(new Path("/foo1")));
            // Do the upgrade. Shut down NN1 and then restart NN0 with the upgrade
            // flag.
            MOEJCHYZKZ.shutdownNameNode(1);
            MOEJCHYZKZ.getNameNodeInfos()[0].setStartOpt(StartupOption.UPGRADE);
            MOEJCHYZKZ.restartNameNode(0, false);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(MOEJCHYZKZ, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(MOEJCHYZKZ, 1, false);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(OQBTKERQHH, true);
            // Now bootstrap the standby with the upgraded info.
            int ZXCHXTSGJF = BootstrapStandby.run(new String[]{ "-force" }, MOEJCHYZKZ.getConfiguration(1));
            assertEquals(0, ZXCHXTSGJF);
            MOEJCHYZKZ.restartNameNode(1);
            // Make the second NN (not the one that initiated the upgrade) active when
            // the finalize command is run.
            MOEJCHYZKZ.transitionToStandby(0);
            MOEJCHYZKZ.transitionToActive(1);
            runFinalizeCommand(MOEJCHYZKZ);
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(MOEJCHYZKZ, false);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(OQBTKERQHH, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(MOEJCHYZKZ);
        } finally {
            if (DDTXFXIXFN != null) {
                DDTXFXIXFN.close();
            }
            if (OQBTKERQHH != null) {
                OQBTKERQHH.shutdown();
            }
        }
    }

    /**
     * Make sure that an HA NN will start if a previous upgrade was in progress.
     */
    @Test
    public void testStartingWithUpgradeInProgressSucceeds() throws Exception {
        MiniDFSCluster PJOKKRJXOB = null;
        try {
            PJOKKRJXOB = new MiniDFSCluster.Builder(CMRTJKMJYF).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).build();
            // Simulate an upgrade having started.
            for (int USNSERQVDZ = 0; USNSERQVDZ < 2; USNSERQVDZ++) {
                for (URI BVVPJDAGOC : PJOKKRJXOB.getNameDirs(USNSERQVDZ)) {
                    File XEHWEOGOIJ = new File(new File(BVVPJDAGOC), Storage.STORAGE_TMP_PREVIOUS);
                    TestDFSUpgradeWithHA.APDTGRLAVG.info("creating previous tmp dir: " + XEHWEOGOIJ);
                    assertTrue(XEHWEOGOIJ.mkdirs());
                }
            }
            PJOKKRJXOB.restartNameNodes();
        } finally {
            if (PJOKKRJXOB != null) {
                PJOKKRJXOB.shutdown();
            }
        }
    }

    /**
     * Test rollback with NFS shared dir.
     */
    @Test
    public void testRollbackWithNfs() throws Exception {
        MiniDFSCluster NKJCUMTMTP = null;
        FileSystem KVKRDJZYUK = null;
        try {
            NKJCUMTMTP = new MiniDFSCluster.Builder(CMRTJKMJYF).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).build();
            File UVPJYHYNNW = new File(NKJCUMTMTP.getSharedEditsDir(0, 1));
            // No upgrade is in progress at the moment.
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(NKJCUMTMTP, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(NKJCUMTMTP);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(UVPJYHYNNW, false);
            // Transition NN0 to active and do some FS ops.
            NKJCUMTMTP.transitionToActive(0);
            KVKRDJZYUK = HATestUtil.configureFailoverFs(NKJCUMTMTP, CMRTJKMJYF);
            assertTrue(KVKRDJZYUK.mkdirs(new Path("/foo1")));
            // Do the upgrade. Shut down NN1 and then restart NN0 with the upgrade
            // flag.
            NKJCUMTMTP.shutdownNameNode(1);
            NKJCUMTMTP.getNameNodeInfos()[0].setStartOpt(StartupOption.UPGRADE);
            NKJCUMTMTP.restartNameNode(0, false);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(NKJCUMTMTP, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(NKJCUMTMTP, 1, false);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(UVPJYHYNNW, true);
            // NN0 should come up in the active state when given the -upgrade option,
            // so no need to transition it to active.
            assertTrue(KVKRDJZYUK.mkdirs(new Path("/foo2")));
            // Now bootstrap the standby with the upgraded info.
            int CNLITYNUAM = BootstrapStandby.run(new String[]{ "-force" }, NKJCUMTMTP.getConfiguration(1));
            assertEquals(0, CNLITYNUAM);
            NKJCUMTMTP.restartNameNode(1);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(NKJCUMTMTP, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(NKJCUMTMTP, 1, false);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(UVPJYHYNNW, true);
            TestDFSUpgradeWithHA.assertCTimesEqual(NKJCUMTMTP);
            // Now shut down the cluster and do the rollback.
            Collection<URI> LLHKTLXZXS = NKJCUMTMTP.getNameDirs(0);
            NKJCUMTMTP.shutdown();
            CMRTJKMJYF.setStrings(DFS_NAMENODE_NAME_DIR_KEY, com.google.common.base.Joiner.on(",").join(LLHKTLXZXS));
            NameNode.doRollback(CMRTJKMJYF, false);
            // The rollback operation should have rolled back the first NN's local
            // dirs, and the shared dir, but not the other NN's dirs. Those have to be
            // done by bootstrapping the standby.
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(NKJCUMTMTP, 0, false);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(UVPJYHYNNW, false);
        } finally {
            if (KVKRDJZYUK != null) {
                KVKRDJZYUK.close();
            }
            if (NKJCUMTMTP != null) {
                NKJCUMTMTP.shutdown();
            }
        }
    }

    @Test
    public void testRollbackWithJournalNodes() throws IOException, URISyntaxException {
        MiniQJMHACluster ZXJQCURXED = null;
        FileSystem UTJRHIWKTV = null;
        try {
            Builder BOMMBDBBDW = new MiniQJMHACluster.Builder(CMRTJKMJYF);
            BOMMBDBBDW.getDfsBuilder().numDataNodes(0);
            ZXJQCURXED = BOMMBDBBDW.build();
            MiniDFSCluster UOVQZDJUSC = ZXJQCURXED.getDfsCluster();
            // No upgrade is in progress at the moment.
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(UOVQZDJUSC, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(UOVQZDJUSC);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(ZXJQCURXED, false);
            // Transition NN0 to active and do some FS ops.
            UOVQZDJUSC.transitionToActive(0);
            UTJRHIWKTV = HATestUtil.configureFailoverFs(UOVQZDJUSC, CMRTJKMJYF);
            assertTrue(UTJRHIWKTV.mkdirs(new Path("/foo1")));
            // Do the upgrade. Shut down NN1 and then restart NN0 with the upgrade
            // flag.
            UOVQZDJUSC.shutdownNameNode(1);
            UOVQZDJUSC.getNameNodeInfos()[0].setStartOpt(StartupOption.UPGRADE);
            UOVQZDJUSC.restartNameNode(0, false);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(UOVQZDJUSC, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(UOVQZDJUSC, 1, false);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(ZXJQCURXED, true);
            // NN0 should come up in the active state when given the -upgrade option,
            // so no need to transition it to active.
            assertTrue(UTJRHIWKTV.mkdirs(new Path("/foo2")));
            // Now bootstrap the standby with the upgraded info.
            int YQQJTQZYNC = BootstrapStandby.run(new String[]{ "-force" }, UOVQZDJUSC.getConfiguration(1));
            assertEquals(0, YQQJTQZYNC);
            UOVQZDJUSC.restartNameNode(1);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(UOVQZDJUSC, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(UOVQZDJUSC, 1, false);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(ZXJQCURXED, true);
            TestDFSUpgradeWithHA.assertCTimesEqual(UOVQZDJUSC);
            // Shut down the NNs, but deliberately leave the JNs up and running.
            Collection<URI> RTACIPCTNT = UOVQZDJUSC.getNameDirs(0);
            UOVQZDJUSC.shutdown();
            CMRTJKMJYF.setStrings(DFS_NAMENODE_NAME_DIR_KEY, com.google.common.base.Joiner.on(",").join(RTACIPCTNT));
            NameNode.doRollback(CMRTJKMJYF, false);
            // The rollback operation should have rolled back the first NN's local
            // dirs, and the shared dir, but not the other NN's dirs. Those have to be
            // done by bootstrapping the standby.
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(UOVQZDJUSC, 0, false);
            TestDFSUpgradeWithHA.checkJnPreviousDirExistence(ZXJQCURXED, false);
        } finally {
            if (UTJRHIWKTV != null) {
                UTJRHIWKTV.close();
            }
            if (ZXJQCURXED != null) {
                ZXJQCURXED.shutdown();
            }
        }
    }

    /**
     * Make sure that starting a second NN with the -upgrade flag fails if the
     * other NN has already done that.
     */
    @Test
    public void testCannotUpgradeSecondNameNode() throws IOException, URISyntaxException {
        MiniDFSCluster IKKNGANFAU = null;
        FileSystem XVQNTTOPLI = null;
        try {
            IKKNGANFAU = new MiniDFSCluster.Builder(CMRTJKMJYF).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleHATopology()).numDataNodes(0).build();
            File CZDNBNXSXJ = new File(IKKNGANFAU.getSharedEditsDir(0, 1));
            // No upgrade is in progress at the moment.
            TestDFSUpgradeWithHA.checkClusterPreviousDirExistence(IKKNGANFAU, false);
            TestDFSUpgradeWithHA.assertCTimesEqual(IKKNGANFAU);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(CZDNBNXSXJ, false);
            // Transition NN0 to active and do some FS ops.
            IKKNGANFAU.transitionToActive(0);
            XVQNTTOPLI = HATestUtil.configureFailoverFs(IKKNGANFAU, CMRTJKMJYF);
            assertTrue(XVQNTTOPLI.mkdirs(new Path("/foo1")));
            // Do the upgrade. Shut down NN1 and then restart NN0 with the upgrade
            // flag.
            IKKNGANFAU.shutdownNameNode(1);
            IKKNGANFAU.getNameNodeInfos()[0].setStartOpt(StartupOption.UPGRADE);
            IKKNGANFAU.restartNameNode(0, false);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(IKKNGANFAU, 0, true);
            TestDFSUpgradeWithHA.checkNnPreviousDirExistence(IKKNGANFAU, 1, false);
            TestDFSUpgradeWithHA.checkPreviousDirExistence(CZDNBNXSXJ, true);
            // NN0 should come up in the active state when given the -upgrade option,
            // so no need to transition it to active.
            assertTrue(XVQNTTOPLI.mkdirs(new Path("/foo2")));
            // Restart NN0 without the -upgrade flag, to make sure that works.
            IKKNGANFAU.getNameNodeInfos()[0].setStartOpt(StartupOption.REGULAR);
            IKKNGANFAU.restartNameNode(0, false);
            // Make sure we can still do FS ops after upgrading.
            IKKNGANFAU.transitionToActive(0);
            assertTrue(XVQNTTOPLI.mkdirs(new Path("/foo3")));
            // Make sure that starting the second NN with the -upgrade flag fails.
            IKKNGANFAU.getNameNodeInfos()[1].setStartOpt(StartupOption.UPGRADE);
            try {
                IKKNGANFAU.restartNameNode(1, false);
                fail("Should not have been able to start second NN with -upgrade");
            } catch (IOException ioe) {
                GenericTestUtils.assertExceptionContains("It looks like the shared log is already being upgraded", ioe);
            }
        } finally {
            if (XVQNTTOPLI != null) {
                XVQNTTOPLI.close();
            }
            if (IKKNGANFAU != null) {
                IKKNGANFAU.shutdown();
            }
        }
    }
}