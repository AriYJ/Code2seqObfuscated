/**
 * Adaptor class to wrap byte-array backed objects (including java byte array)
 * as RawComparable objects.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public final class ByteArray implements RawComparable {
    private final byte[] GPJOASCNPX;

    private final int FTCBRZKQRT;

    private final int KJDYMGARAK;

    /**
     * Constructing a ByteArray from a {@link BytesWritable}.
     *
     * @param other
     * 		
     */
    public ByteArray(BytesWritable DIEJGEGCRN) {
        this(DIEJGEGCRN.getBytes(), 0, DIEJGEGCRN.getLength());
    }

    /**
     * Wrap a whole byte array as a RawComparable.
     *
     * @param buffer
     * 		the byte array buffer.
     */
    public ByteArray(byte[] TEDUKGJRYJ) {
        this(TEDUKGJRYJ, 0, TEDUKGJRYJ.length);
    }

    /**
     * Wrap a partial byte array as a RawComparable.
     *
     * @param buffer
     * 		the byte array buffer.
     * @param offset
     * 		the starting offset
     * @param len
     * 		the length of the consecutive bytes to be wrapped.
     */
    public ByteArray(byte[] PHFGXVGNRA, int FLKZWDICSG, int IMNWHRNCGP) {
        if (((FLKZWDICSG | IMNWHRNCGP) | ((PHFGXVGNRA.length - FLKZWDICSG) - IMNWHRNCGP)) < 0) {
            throw new IndexOutOfBoundsException();
        }
        this.GPJOASCNPX = PHFGXVGNRA;
        this.FTCBRZKQRT = FLKZWDICSG;
        this.KJDYMGARAK = IMNWHRNCGP;
    }

    /**
     *
     *
     * @return the underlying buffer.
     */
    @Override
    public byte[] buffer() {
        return GPJOASCNPX;
    }

    /**
     *
     *
     * @return the offset in the buffer.
     */
    @Override
    public int offset() {
        return FTCBRZKQRT;
    }

    /**
     *
     *
     * @return the size of the byte array.
     */
    @Override
    public int size() {
        return KJDYMGARAK;
    }
}