public class JobUpdatedNodesEvent extends JobEvent {
    private final List<NodeReport> KSSMUOOKGR;

    public JobUpdatedNodesEvent(JobId JKCDJZZVZB, List<NodeReport> DUZPVZQBDC) {
        super(JKCDJZZVZB, JOB_UPDATED_NODES);
        this.KSSMUOOKGR = DUZPVZQBDC;
    }

    public List<NodeReport> getUpdatedNodes() {
        return KSSMUOOKGR;
    }
}