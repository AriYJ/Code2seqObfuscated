public class MasterKeyData {
    private final MasterKey BEDEJGZJOH;

    // Underlying secret-key also stored to avoid repetitive encoding and
    // decoding the masterKeyRecord bytes.
    private final SecretKey DGIXVMIMDF;

    public MasterKeyData(int RMMRWMONNZ, SecretKey ZQEZIPDPXN) {
        this.BEDEJGZJOH = Records.newRecord(MasterKey.class);
        this.BEDEJGZJOH.setKeyId(RMMRWMONNZ);
        this.DGIXVMIMDF = ZQEZIPDPXN;
        this.BEDEJGZJOH.setBytes(ByteBuffer.wrap(DGIXVMIMDF.getEncoded()));
    }

    public MasterKeyData(MasterKey PENROEJVOT, SecretKey TNVWDMXAMZ) {
        this.BEDEJGZJOH = PENROEJVOT;
        this.DGIXVMIMDF = TNVWDMXAMZ;
    }

    public MasterKey getMasterKey() {
        return this.BEDEJGZJOH;
    }

    public SecretKey getSecretKey() {
        return this.DGIXVMIMDF;
    }
}