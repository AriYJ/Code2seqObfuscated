public class TestWrappedRecordReaderClassloader extends TestCase {
    /**
     * Tests the class loader set by {@link JobConf#setClassLoader(ClassLoader)}
     * is inherited by any {@link WrappedRecordReader}s created by
     * {@link CompositeRecordReader}
     */
    public void testClassLoader() throws Exception {
        JobConf SLRLELJJIA = new JobConf();
        TestWrappedRecordReaderClassloader.Fake_ClassLoader BDZHWEEPQV = new TestWrappedRecordReaderClassloader.Fake_ClassLoader();
        SLRLELJJIA.setClassLoader(BDZHWEEPQV);
        assertTrue(SLRLELJJIA.getClassLoader() instanceof TestWrappedRecordReaderClassloader.Fake_ClassLoader);
        FileSystem FZOBAQNWWW = FileSystem.get(SLRLELJJIA);
        Path SHGHFFNFRF = new Path(System.getProperty("test.build.data", "/tmp")).makeQualified(FZOBAQNWWW);
        Path JZLLIVCBBN = new Path(SHGHFFNFRF, "/empty");
        Path[] YPLPPSQENT = new Path[]{ new Path(JZLLIVCBBN, "i0"), new Path("i1"), new Path("i2") };
        SLRLELJJIA.set("mapreduce.join.expr", CompositeInputFormat.compose("outer", TestWrappedRecordReaderClassloader.IF_ClassLoaderChecker.class, YPLPPSQENT));
        CompositeInputFormat<NullWritable> ASBJDKTXRL = new CompositeInputFormat<NullWritable>();
        ASBJDKTXRL.getRecordReader(ASBJDKTXRL.getSplits(SLRLELJJIA, 1)[0], SLRLELJJIA, NULL);
    }

    public static class Fake_ClassLoader extends ClassLoader {}

    public static class IF_ClassLoaderChecker<K, V> implements InputFormat<K, V> , JobConfigurable {
        public static class FakeSplit implements InputSplit {
            public void write(DataOutput out) throws IOException {
            }

            public void readFields(DataInput in) throws IOException {
            }

            public long getLength() {
                return 0L;
            }

            public String[] getLocations() {
                return new String[0];
            }
        }

        public static void setKeyClass(JobConf job, Class<?> k) {
            job.setClass("test.fakeif.keyclass", k, WritableComparable.class);
        }

        public static void setValClass(JobConf job, Class<?> v) {
            job.setClass("test.fakeif.valclass", v, Writable.class);
        }

        protected Class<? extends K> GVYSNCRNZM;

        protected Class<? extends V> MJWGFNUOHL;

        @SuppressWarnings("unchecked")
        public void configure(JobConf job) {
            GVYSNCRNZM = ((Class<? extends K>) (job.getClass("test.fakeif.keyclass", NullWritable.class, WritableComparable.class)));
            MJWGFNUOHL = ((Class<? extends V>) (job.getClass("test.fakeif.valclass", NullWritable.class, WritableComparable.class)));
        }

        public IF_ClassLoaderChecker() {
        }

        public InputSplit[] getSplits(JobConf conf, int splits) {
            return new InputSplit[]{ new TestWrappedRecordReaderClassloader.IF_ClassLoaderChecker.FakeSplit() };
        }

        public RecordReader<K, V> getRecordReader(InputSplit ignored, JobConf job, Reporter reporter) {
            return new TestWrappedRecordReaderClassloader.RR_ClassLoaderChecker<K, V>(job);
        }
    }

    public static class RR_ClassLoaderChecker<K, V> implements RecordReader<K, V> {
        private Class<? extends K> FKGQKONMWS;

        private Class<? extends V> WSEHDMCSQS;

        @SuppressWarnings("unchecked")
        public RR_ClassLoaderChecker(JobConf job) {
            assertTrue("The class loader has not been inherited from " + CompositeRecordReader.class.getSimpleName(), job.getClassLoader() instanceof TestWrappedRecordReaderClassloader.Fake_ClassLoader);
            FKGQKONMWS = ((Class<? extends K>) (job.getClass("test.fakeif.keyclass", NullWritable.class, WritableComparable.class)));
            WSEHDMCSQS = ((Class<? extends V>) (job.getClass("test.fakeif.valclass", NullWritable.class, WritableComparable.class)));
        }

        public boolean next(K key, V value) throws IOException {
            return false;
        }

        public K createKey() {
            return ReflectionUtils.newInstance(FKGQKONMWS, null);
        }

        public V createValue() {
            return ReflectionUtils.newInstance(WSEHDMCSQS, null);
        }

        public long getPos() throws IOException {
            return 0L;
        }

        public void close() throws IOException {
        }

        public float getProgress() throws IOException {
            return 0.0F;
        }
    }
}