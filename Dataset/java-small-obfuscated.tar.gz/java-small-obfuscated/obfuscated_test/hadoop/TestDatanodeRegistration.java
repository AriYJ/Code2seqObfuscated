/**
 * This class tests data node registration.
 */
public class TestDatanodeRegistration {
    public static final Log KBPRZZQDYU = LogFactory.getLog(TestDatanodeRegistration.class);

    private static class MonitorDNS extends SecurityManager {
        int JMTZPJYMXG = 0;

        @Override
        public void checkPermission(Permission perm) {
        }

        @Override
        public void checkConnect(String host, int port) {
            if (port == (-1)) {
                JMTZPJYMXG++;
            }
        }
    }

    /**
     * Ensure the datanode manager does not do host lookup after registration,
     * especially for node reports.
     *
     * @throws Exception
     * 		
     */
    @Test
    public void testDNSLookups() throws Exception {
        TestDatanodeRegistration.MonitorDNS YAWORSFZKF = new TestDatanodeRegistration.MonitorDNS();
        System.setSecurityManager(YAWORSFZKF);
        MiniDFSCluster VGCYJWEHIO = null;
        try {
            HdfsConfiguration AFKELBQJHL = new HdfsConfiguration();
            VGCYJWEHIO = new MiniDFSCluster.Builder(AFKELBQJHL).numDataNodes(8).build();
            VGCYJWEHIO.waitActive();
            int BEHUEHKXWJ = YAWORSFZKF.JMTZPJYMXG;
            assertTrue("dns security manager is active", BEHUEHKXWJ != 0);
            DatanodeManager RGTCHESYCJ = VGCYJWEHIO.getNamesystem().getBlockManager().getDatanodeManager();
            // make sure no lookups occur
            RGTCHESYCJ.refreshNodes(AFKELBQJHL);
            assertEquals(BEHUEHKXWJ, YAWORSFZKF.JMTZPJYMXG);
            RGTCHESYCJ.refreshNodes(AFKELBQJHL);
            assertEquals(BEHUEHKXWJ, YAWORSFZKF.JMTZPJYMXG);
            // ensure none of the reports trigger lookups
            RGTCHESYCJ.getDatanodeListForReport(ALL);
            assertEquals(BEHUEHKXWJ, YAWORSFZKF.JMTZPJYMXG);
            RGTCHESYCJ.getDatanodeListForReport(LIVE);
            assertEquals(BEHUEHKXWJ, YAWORSFZKF.JMTZPJYMXG);
            RGTCHESYCJ.getDatanodeListForReport(DEAD);
            assertEquals(BEHUEHKXWJ, YAWORSFZKF.JMTZPJYMXG);
        } finally {
            if (VGCYJWEHIO != null) {
                VGCYJWEHIO.shutdown();
            }
            System.setSecurityManager(null);
        }
    }

    /**
     * Regression test for HDFS-894 ensures that, when datanodes
     * are restarted, the new IPC port is registered with the
     * namenode.
     */
    @Test
    public void testChangeIpcPort() throws Exception {
        HdfsConfiguration TSBSFYMJPC = new HdfsConfiguration();
        MiniDFSCluster NKYITZEVMJ = null;
        try {
            NKYITZEVMJ = new MiniDFSCluster.Builder(TSBSFYMJPC).build();
            InetSocketAddress XNECMORTGN = new InetSocketAddress("localhost", NKYITZEVMJ.getNameNodePort());
            DFSClient BEPKJTLWYA = new DFSClient(XNECMORTGN, TSBSFYMJPC);
            // Restart datanodes
            NKYITZEVMJ.restartDataNodes();
            // Wait until we get a heartbeat from the new datanode
            DatanodeInfo[] KTNTYIGAAL = BEPKJTLWYA.datanodeReport(ALL);
            long HEACAPFQAG = KTNTYIGAAL[0].getLastUpdate();
            boolean ASZSRORYLZ = false;
            for (int ANHEGMQRSI = 0; (ANHEGMQRSI < 10) && (!ASZSRORYLZ); ANHEGMQRSI++) {
                try {
                    Thread.sleep(ANHEGMQRSI * 1000);
                } catch (InterruptedException ie) {
                }
                KTNTYIGAAL = BEPKJTLWYA.datanodeReport(ALL);
                ASZSRORYLZ = KTNTYIGAAL[0].getLastUpdate() > HEACAPFQAG;
            }
            if (!ASZSRORYLZ) {
                fail("Never got a heartbeat from restarted datanode.");
            }
            int CPUQNIDSAO = NKYITZEVMJ.getDataNodes().get(0).getIpcPort();
            // Now make sure the reported IPC port is the correct one.
            assertEquals(CPUQNIDSAO, KTNTYIGAAL[0].getIpcPort());
        } finally {
            if (NKYITZEVMJ != null) {
                NKYITZEVMJ.shutdown();
            }
        }
    }

    @Test
    public void testChangeStorageID() throws Exception {
        final String JGTLWQNKJX = "127.0.0.1";
        final String PSGJUOKAEY = "localhost";
        final int ZVVBJCMJJF = 12345;
        final int AQUFCCOYOB = 12346;
        final int USHJYTZGRE = 12347;
        final int ZKVKCSFDGI = 12348;
        Configuration EROTTQKHHI = new HdfsConfiguration();
        MiniDFSCluster RTJDWAWIAQ = null;
        try {
            RTJDWAWIAQ = new MiniDFSCluster.Builder(EROTTQKHHI).numDataNodes(0).build();
            InetSocketAddress YGYVDNICUM = new InetSocketAddress("localhost", RTJDWAWIAQ.getNameNodePort());
            DFSClient ITVPOAUSVD = new DFSClient(YGYVDNICUM, EROTTQKHHI);
            NamenodeProtocols MQXVFLGNQG = RTJDWAWIAQ.getNameNodeRpc();
            // register a datanode
            DatanodeID OBNMFIKXFH = new DatanodeID(JGTLWQNKJX, PSGJUOKAEY, "fake-datanode-id", ZVVBJCMJJF, AQUFCCOYOB, USHJYTZGRE, ZKVKCSFDGI);
            long HHMDLEIFPM = RTJDWAWIAQ.getNamesystem().getFSImage().getStorage().getCTime();
            StorageInfo QWVZNKQZNY = mock(StorageInfo.class);
            doReturn(HHMDLEIFPM).when(QWVZNKQZNY).getCTime();
            doReturn(HdfsConstants.DATANODE_LAYOUT_VERSION).when(QWVZNKQZNY).getLayoutVersion();
            DatanodeRegistration XEVHPMIRJP = new DatanodeRegistration(OBNMFIKXFH, QWVZNKQZNY, null, VersionInfo.getVersion());
            MQXVFLGNQG.registerDatanode(XEVHPMIRJP);
            DatanodeInfo[] YBPKVIZBLV = ITVPOAUSVD.datanodeReport(ALL);
            assertEquals("Expected a registered datanode", 1, YBPKVIZBLV.length);
            // register the same datanode again with a different storage ID
            OBNMFIKXFH = new DatanodeID(JGTLWQNKJX, PSGJUOKAEY, "changed-fake-datanode-id", ZVVBJCMJJF, AQUFCCOYOB, USHJYTZGRE, ZKVKCSFDGI);
            XEVHPMIRJP = new DatanodeRegistration(OBNMFIKXFH, QWVZNKQZNY, null, VersionInfo.getVersion());
            MQXVFLGNQG.registerDatanode(XEVHPMIRJP);
            YBPKVIZBLV = ITVPOAUSVD.datanodeReport(ALL);
            assertEquals("Datanode with changed storage ID not recognized", 1, YBPKVIZBLV.length);
        } finally {
            if (RTJDWAWIAQ != null) {
                RTJDWAWIAQ.shutdown();
            }
        }
    }

    @Test
    public void testRegistrationWithDifferentSoftwareVersions() throws Exception {
        Configuration ILSNHXQZCI = new HdfsConfiguration();
        ILSNHXQZCI.set(DFS_DATANODE_MIN_SUPPORTED_NAMENODE_VERSION_KEY, "3.0.0");
        ILSNHXQZCI.set(DFS_NAMENODE_MIN_SUPPORTED_DATANODE_VERSION_KEY, "3.0.0");
        MiniDFSCluster WJHVIOBJMV = null;
        try {
            WJHVIOBJMV = new MiniDFSCluster.Builder(ILSNHXQZCI).numDataNodes(0).build();
            NamenodeProtocols ADVDMCGHUM = WJHVIOBJMV.getNameNodeRpc();
            long GAFKUEJASJ = WJHVIOBJMV.getNamesystem().getFSImage().getStorage().getCTime();
            StorageInfo EXMHZIBHCY = mock(StorageInfo.class);
            doReturn(GAFKUEJASJ).when(EXMHZIBHCY).getCTime();
            DatanodeRegistration MGCVVWSAZN = mock(DatanodeRegistration.class);
            doReturn(HdfsConstants.DATANODE_LAYOUT_VERSION).when(MGCVVWSAZN).getVersion();
            doReturn("127.0.0.1").when(MGCVVWSAZN).getIpAddr();
            doReturn(123).when(MGCVVWSAZN).getXferPort();
            doReturn("fake-storage-id").when(MGCVVWSAZN).getDatanodeUuid();
            doReturn(EXMHZIBHCY).when(MGCVVWSAZN).getStorageInfo();
            // Should succeed when software versions are the same.
            doReturn("3.0.0").when(MGCVVWSAZN).getSoftwareVersion();
            ADVDMCGHUM.registerDatanode(MGCVVWSAZN);
            // Should succeed when software version of DN is above minimum required by NN.
            doReturn("4.0.0").when(MGCVVWSAZN).getSoftwareVersion();
            ADVDMCGHUM.registerDatanode(MGCVVWSAZN);
            // Should fail when software version of DN is below minimum required by NN.
            doReturn("2.0.0").when(MGCVVWSAZN).getSoftwareVersion();
            try {
                ADVDMCGHUM.registerDatanode(MGCVVWSAZN);
                fail("Should not have been able to register DN with too-low version.");
            } catch (IncorrectVersionException ive) {
                GenericTestUtils.assertExceptionContains("The reported DataNode version is too low", ive);
                TestDatanodeRegistration.KBPRZZQDYU.info("Got expected exception", ive);
            }
        } finally {
            if (WJHVIOBJMV != null) {
                WJHVIOBJMV.shutdown();
            }
        }
    }

    @Test
    public void testRegistrationWithDifferentSoftwareVersionsDuringUpgrade() throws Exception {
        Configuration WFEYSMAQGW = new HdfsConfiguration();
        WFEYSMAQGW.set(DFS_DATANODE_MIN_SUPPORTED_NAMENODE_VERSION_KEY, "1.0.0");
        MiniDFSCluster VLEKFARXVM = null;
        try {
            VLEKFARXVM = new MiniDFSCluster.Builder(WFEYSMAQGW).numDataNodes(0).build();
            NamenodeProtocols RYHASVNFMN = VLEKFARXVM.getNameNodeRpc();
            long HSLNVENWWP = VLEKFARXVM.getNamesystem().getFSImage().getStorage().getCTime();
            StorageInfo IQVYFAUSTX = mock(StorageInfo.class);
            doReturn(HSLNVENWWP).when(IQVYFAUSTX).getCTime();
            DatanodeRegistration RLSWTAZGOI = mock(DatanodeRegistration.class);
            doReturn(HdfsConstants.DATANODE_LAYOUT_VERSION).when(RLSWTAZGOI).getVersion();
            doReturn("fake-storage-id").when(RLSWTAZGOI).getDatanodeUuid();
            doReturn(IQVYFAUSTX).when(RLSWTAZGOI).getStorageInfo();
            // Should succeed when software versions are the same and CTimes are the
            // same.
            doReturn(VersionInfo.getVersion()).when(RLSWTAZGOI).getSoftwareVersion();
            doReturn("127.0.0.1").when(RLSWTAZGOI).getIpAddr();
            doReturn(123).when(RLSWTAZGOI).getXferPort();
            RYHASVNFMN.registerDatanode(RLSWTAZGOI);
            // Should succeed when software versions are the same and CTimes are
            // different.
            doReturn(HSLNVENWWP + 1).when(IQVYFAUSTX).getCTime();
            RYHASVNFMN.registerDatanode(RLSWTAZGOI);
            // Should fail when software version of DN is different from NN and CTimes
            // are different.
            doReturn(VersionInfo.getVersion() + ".1").when(RLSWTAZGOI).getSoftwareVersion();
            try {
                RYHASVNFMN.registerDatanode(RLSWTAZGOI);
                fail("Should not have been able to register DN with different software" + " versions and CTimes");
            } catch (IncorrectVersionException ive) {
                GenericTestUtils.assertExceptionContains("does not match CTime of NN", ive);
                TestDatanodeRegistration.KBPRZZQDYU.info("Got expected exception", ive);
            }
        } finally {
            if (VLEKFARXVM != null) {
                VLEKFARXVM.shutdown();
            }
        }
    }
}