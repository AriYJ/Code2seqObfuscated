@Private
@Unstable
public class StartContainersResponsePBImpl extends StartContainersResponse {
    StartContainersResponseProto VKTTKWRIQC = StartContainersResponseProto.getDefaultInstance();

    Builder PNOFTFSKDA = null;

    boolean MTPGASVHTV = false;

    private Map<String, ByteBuffer> PSDTXKGEDK = null;

    private List<ContainerId> OWYKSISFPQ = null;

    private Map<ContainerId, SerializedException> HBTTZHJWJE = null;

    public StartContainersResponsePBImpl() {
        PNOFTFSKDA = StartContainersResponseProto.newBuilder();
    }

    public StartContainersResponsePBImpl(StartContainersResponseProto GWFUFLUDVX) {
        this.VKTTKWRIQC = GWFUFLUDVX;
        MTPGASVHTV = true;
    }

    public StartContainersResponseProto getProto() {
        mergeLocalToProto();
        VKTTKWRIQC = (MTPGASVHTV) ? VKTTKWRIQC : PNOFTFSKDA.build();
        MTPGASVHTV = true;
        return VKTTKWRIQC;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object LNFSLQTJDT) {
        if (LNFSLQTJDT == null)
            return false;

        if (LNFSLQTJDT.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(LNFSLQTJDT).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }

    private void mergeLocalToBuilder() {
        if (this.PSDTXKGEDK != null) {
            addServicesMetaDataToProto();
        }
        if (this.OWYKSISFPQ != null) {
            addSucceededContainersToProto();
        }
        if (this.HBTTZHJWJE != null) {
            addFailedContainersToProto();
        }
    }

    protected final ByteBuffer convertFromProtoFormat(ByteString VDYYUYIDFR) {
        return ProtoUtils.convertFromProtoFormat(VDYYUYIDFR);
    }

    protected final ByteString convertToProtoFormat(ByteBuffer TXWJFUSPPV) {
        return ProtoUtils.convertToProtoFormat(TXWJFUSPPV);
    }

    private ContainerIdPBImpl convertFromProtoFormat(ContainerIdProto TSWISTHHHH) {
        return new ContainerIdPBImpl(TSWISTHHHH);
    }

    private ContainerIdProto convertToProtoFormat(ContainerId NRIKQVTQKR) {
        return ((ContainerIdPBImpl) (NRIKQVTQKR)).getProto();
    }

    private SerializedExceptionPBImpl convertFromProtoFormat(SerializedExceptionProto PTKMCRCWPB) {
        return new SerializedExceptionPBImpl(PTKMCRCWPB);
    }

    private SerializedExceptionProto convertToProtoFormat(SerializedException WMODFGQPMM) {
        return ((SerializedExceptionPBImpl) (WMODFGQPMM)).getProto();
    }

    private void mergeLocalToProto() {
        if (MTPGASVHTV) {
            maybeInitBuilder();
        }
        mergeLocalToBuilder();
        VKTTKWRIQC = PNOFTFSKDA.build();
        MTPGASVHTV = true;
    }

    private void maybeInitBuilder() {
        if (MTPGASVHTV || (PNOFTFSKDA == null)) {
            PNOFTFSKDA = StartContainersResponseProto.newBuilder(VKTTKWRIQC);
        }
        MTPGASVHTV = false;
    }

    @Override
    public Map<String, ByteBuffer> getAllServicesMetaData() {
        initServicesMetaData();
        return this.PSDTXKGEDK;
    }

    @Override
    public void setAllServicesMetaData(Map<String, ByteBuffer> EJUPIVFMQD) {
        if (EJUPIVFMQD == null) {
            return;
        }
        initServicesMetaData();
        this.PSDTXKGEDK.clear();
        this.PSDTXKGEDK.putAll(EJUPIVFMQD);
    }

    private void initServicesMetaData() {
        if (this.PSDTXKGEDK != null) {
            return;
        }
        StartContainersResponseProtoOrBuilder DUENIGKDPM = (MTPGASVHTV) ? VKTTKWRIQC : PNOFTFSKDA;
        List<StringBytesMapProto> WFJXNPCFYJ = DUENIGKDPM.getServicesMetaDataList();
        this.PSDTXKGEDK = new HashMap<String, ByteBuffer>();
        for (StringBytesMapProto BQPADNBBAF : WFJXNPCFYJ) {
            this.PSDTXKGEDK.put(BQPADNBBAF.getKey(), convertFromProtoFormat(BQPADNBBAF.getValue()));
        }
    }

    private void addServicesMetaDataToProto() {
        maybeInitBuilder();
        PNOFTFSKDA.clearServicesMetaData();
        if (PSDTXKGEDK == null)
            return;

        Iterable<StringBytesMapProto> AIWBDIGMOL = new Iterable<StringBytesMapProto>() {
            @Override
            public Iterator<StringBytesMapProto> iterator() {
                return new Iterator<StringBytesMapProto>() {
                    Iterator<String> RLROWBDKYR = PSDTXKGEDK.keySet().iterator();

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }

                    @Override
                    public StringBytesMapProto next() {
                        String QVYUBXJQOJ = RLROWBDKYR.next();
                        return StringBytesMapProto.newBuilder().setKey(QVYUBXJQOJ).setValue(convertToProtoFormat(PSDTXKGEDK.get(QVYUBXJQOJ))).build();
                    }

                    @Override
                    public boolean hasNext() {
                        return RLROWBDKYR.hasNext();
                    }
                };
            }
        };
        PNOFTFSKDA.addAllServicesMetaData(AIWBDIGMOL);
    }

    private void addFailedContainersToProto() {
        maybeInitBuilder();
        PNOFTFSKDA.clearFailedRequests();
        if (this.HBTTZHJWJE == null)
            return;

        List<ContainerExceptionMapProto> XQSBJJDROQ = new ArrayList<ContainerExceptionMapProto>();
        for (Map.Entry<ContainerId, SerializedException> IJHXPEHLRV : this.HBTTZHJWJE.entrySet()) {
            XQSBJJDROQ.add(ContainerExceptionMapProto.newBuilder().setContainerId(convertToProtoFormat(IJHXPEHLRV.getKey())).setException(convertToProtoFormat(IJHXPEHLRV.getValue())).build());
        }
        PNOFTFSKDA.addAllFailedRequests(XQSBJJDROQ);
    }

    private void addSucceededContainersToProto() {
        maybeInitBuilder();
        PNOFTFSKDA.clearSucceededRequests();
        if (this.OWYKSISFPQ == null) {
            return;
        }
        Iterable<ContainerIdProto> WUNQUSKDPE = new Iterable<ContainerIdProto>() {
            @Override
            public Iterator<ContainerIdProto> iterator() {
                return new Iterator<ContainerIdProto>() {
                    Iterator<ContainerId> YMUUBLASWB = OWYKSISFPQ.iterator();

                    @Override
                    public boolean hasNext() {
                        return YMUUBLASWB.hasNext();
                    }

                    @Override
                    public ContainerIdProto next() {
                        return convertToProtoFormat(YMUUBLASWB.next());
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        };
        PNOFTFSKDA.addAllSucceededRequests(WUNQUSKDPE);
    }

    private void initSucceededContainers() {
        if (this.OWYKSISFPQ != null)
            return;

        StartContainersResponseProtoOrBuilder SBVYWZXKNJ = (MTPGASVHTV) ? VKTTKWRIQC : PNOFTFSKDA;
        List<ContainerIdProto> NMIKNODAYM = SBVYWZXKNJ.getSucceededRequestsList();
        this.OWYKSISFPQ = new ArrayList<ContainerId>();
        for (ContainerIdProto KDOZJZRXSJ : NMIKNODAYM) {
            this.OWYKSISFPQ.add(convertFromProtoFormat(KDOZJZRXSJ));
        }
    }

    @Override
    public List<ContainerId> getSuccessfullyStartedContainers() {
        initSucceededContainers();
        return this.OWYKSISFPQ;
    }

    @Override
    public void setSuccessfullyStartedContainers(List<ContainerId> VBGQFINTLG) {
        maybeInitBuilder();
        if (VBGQFINTLG == null) {
            PNOFTFSKDA.clearSucceededRequests();
        }
        this.OWYKSISFPQ = VBGQFINTLG;
    }

    private void initFailedContainers() {
        if (this.HBTTZHJWJE != null) {
            return;
        }
        StartContainersResponseProtoOrBuilder TGBKJGZYIQ = (MTPGASVHTV) ? VKTTKWRIQC : PNOFTFSKDA;
        List<ContainerExceptionMapProto> TYWFMDPQEF = TGBKJGZYIQ.getFailedRequestsList();
        this.HBTTZHJWJE = new HashMap<ContainerId, SerializedException>();
        for (ContainerExceptionMapProto WNSLRVSWPI : TYWFMDPQEF) {
            this.HBTTZHJWJE.put(convertFromProtoFormat(WNSLRVSWPI.getContainerId()), convertFromProtoFormat(WNSLRVSWPI.getException()));
        }
    }

    @Override
    public Map<ContainerId, SerializedException> getFailedRequests() {
        initFailedContainers();
        return this.HBTTZHJWJE;
    }

    @Override
    public void setFailedRequests(Map<ContainerId, SerializedException> GTJNGQJYET) {
        maybeInitBuilder();
        if (GTJNGQJYET == null)
            PNOFTFSKDA.clearFailedRequests();

        this.HBTTZHJWJE = GTJNGQJYET;
    }
}