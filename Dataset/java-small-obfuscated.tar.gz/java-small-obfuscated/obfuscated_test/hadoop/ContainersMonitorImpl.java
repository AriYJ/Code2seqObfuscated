public class ContainersMonitorImpl extends AbstractService implements ContainersMonitor {
    static final Log SFDWIECOHW = LogFactory.getLog(ContainersMonitorImpl.class);

    private long GZSXLGQWBE;

    private ContainersMonitorImpl.MonitoringThread WTRQORKGCR;

    final List<ContainerId> MHXECQOOLE;

    final Map<ContainerId, ContainersMonitorImpl.ProcessTreeInfo> XFTSYKRTWW;

    Map<ContainerId, ContainersMonitorImpl.ProcessTreeInfo> BKGGWTLQIC = new HashMap<ContainerId, ContainersMonitorImpl.ProcessTreeInfo>();

    final ContainerExecutor MTSVGMBIKB;

    private final Dispatcher AXFJXICTBB;

    private final Context YTTYNNELPV;

    private ResourceCalculatorPlugin JGCUFPEBPN;

    private Configuration AHTPMZUATF;

    private Class<? extends ResourceCalculatorProcessTree> WDAASSYYAD;

    private long HOEAWXOPRT = ContainersMonitorImpl.YPQVDZWOQL;

    private long OBAFOMOFMK = ContainersMonitorImpl.YPQVDZWOQL;

    private boolean IPAQUOMMJY;

    private boolean VTFDICIFCG;

    private long ENRZMYIWVV;

    private static final long YPQVDZWOQL = -1L;

    public ContainersMonitorImpl(ContainerExecutor IAYOJDZRIO, AsyncDispatcher UCSTRTHMOK, Context WNTXOBAZCF) {
        super("containers-monitor");
        this.MTSVGMBIKB = IAYOJDZRIO;
        this.AXFJXICTBB = UCSTRTHMOK;
        this.YTTYNNELPV = WNTXOBAZCF;
        this.XFTSYKRTWW = new HashMap<ContainerId, ContainersMonitorImpl.ProcessTreeInfo>();
        this.MHXECQOOLE = new ArrayList<ContainerId>();
        this.WTRQORKGCR = new ContainersMonitorImpl.MonitoringThread();
    }

    @Override
    protected void serviceInit(Configuration VJHQZSOFAY) throws Exception {
        this.GZSXLGQWBE = VJHQZSOFAY.getLong(NM_CONTAINER_MON_INTERVAL_MS, DEFAULT_NM_CONTAINER_MON_INTERVAL_MS);
        Class<? extends ResourceCalculatorPlugin> CFZLHHGDWC = VJHQZSOFAY.getClass(NM_CONTAINER_MON_RESOURCE_CALCULATOR, null, ResourceCalculatorPlugin.class);
        this.JGCUFPEBPN = ResourceCalculatorPlugin.getResourceCalculatorPlugin(CFZLHHGDWC, VJHQZSOFAY);
        ContainersMonitorImpl.SFDWIECOHW.info(" Using ResourceCalculatorPlugin : " + this.JGCUFPEBPN);
        WDAASSYYAD = VJHQZSOFAY.getClass(NM_CONTAINER_MON_PROCESS_TREE, null, ResourceCalculatorProcessTree.class);
        this.AHTPMZUATF = VJHQZSOFAY;
        ContainersMonitorImpl.SFDWIECOHW.info(" Using ResourceCalculatorProcessTree : " + this.WDAASSYYAD);
        long VKQKPNYNBF = (VJHQZSOFAY.getLong(NM_PMEM_MB, DEFAULT_NM_PMEM_MB) * 1024) * 1024L;
        long TOBUYVRGYQ = VJHQZSOFAY.getLong(NM_VCORES, DEFAULT_NM_VCORES);
        // Setting these irrespective of whether checks are enabled. Required in
        // the UI.
        // ///////// Physical memory configuration //////
        this.OBAFOMOFMK = VKQKPNYNBF;
        this.ENRZMYIWVV = TOBUYVRGYQ;
        // ///////// Virtual memory configuration //////
        float GTLOCPESWF = VJHQZSOFAY.getFloat(NM_VMEM_PMEM_RATIO, DEFAULT_NM_VMEM_PMEM_RATIO);
        Preconditions.checkArgument(GTLOCPESWF > 0.99F, YarnConfiguration.NM_VMEM_PMEM_RATIO + " should be at least 1.0");
        this.HOEAWXOPRT = ((long) (GTLOCPESWF * VKQKPNYNBF));
        IPAQUOMMJY = VJHQZSOFAY.getBoolean(NM_PMEM_CHECK_ENABLED, DEFAULT_NM_PMEM_CHECK_ENABLED);
        VTFDICIFCG = VJHQZSOFAY.getBoolean(NM_VMEM_CHECK_ENABLED, DEFAULT_NM_VMEM_CHECK_ENABLED);
        ContainersMonitorImpl.SFDWIECOHW.info("Physical memory check enabled: " + IPAQUOMMJY);
        ContainersMonitorImpl.SFDWIECOHW.info("Virtual memory check enabled: " + VTFDICIFCG);
        if (IPAQUOMMJY) {
            // Logging if actual pmem cannot be determined.
            long LXAUQTJDTY = ContainersMonitorImpl.YPQVDZWOQL;
            if (this.JGCUFPEBPN != null) {
                LXAUQTJDTY = this.JGCUFPEBPN.getPhysicalMemorySize();
                if (LXAUQTJDTY <= 0) {
                    ContainersMonitorImpl.SFDWIECOHW.warn(("NodeManager's totalPmem could not be calculated. " + "Setting it to ") + ContainersMonitorImpl.YPQVDZWOQL);
                    LXAUQTJDTY = ContainersMonitorImpl.YPQVDZWOQL;
                }
            }
            if ((LXAUQTJDTY != ContainersMonitorImpl.YPQVDZWOQL) && (this.OBAFOMOFMK > (LXAUQTJDTY * 0.8F))) {
                ContainersMonitorImpl.SFDWIECOHW.warn((((("NodeManager configured with " + TraditionalBinaryPrefix.long2String(OBAFOMOFMK, "", 1)) + " physical memory allocated to containers, which is more than ") + "80% of the total physical memory available (") + TraditionalBinaryPrefix.long2String(LXAUQTJDTY, "", 1)) + "). Thrashing might happen.");
            }
        }
        super.serviceInit(VJHQZSOFAY);
    }

    private boolean isEnabled() {
        if (JGCUFPEBPN == null) {
            ContainersMonitorImpl.SFDWIECOHW.info(("ResourceCalculatorPlugin is unavailable on this system. " + this.getClass().getName()) + " is disabled.");
            return false;
        }
        if (ResourceCalculatorProcessTree.getResourceCalculatorProcessTree("0", WDAASSYYAD, AHTPMZUATF) == null) {
            ContainersMonitorImpl.SFDWIECOHW.info(("ResourceCalculatorProcessTree is unavailable on this system. " + this.getClass().getName()) + " is disabled.");
            return false;
        }
        if (!(isPmemCheckEnabled() || isVmemCheckEnabled())) {
            ContainersMonitorImpl.SFDWIECOHW.info("Neither virutal-memory nor physical-memory monitoring is " + "needed. Not running the monitor-thread");
            return false;
        }
        return true;
    }

    @Override
    protected void serviceStart() throws Exception {
        if (this.isEnabled()) {
            this.WTRQORKGCR.start();
        }
        super.serviceStart();
    }

    @Override
    protected void serviceStop() throws Exception {
        if (this.isEnabled()) {
            this.WTRQORKGCR.interrupt();
            try {
                this.WTRQORKGCR.join();
            } catch (InterruptedException e) {
            }
        }
        super.serviceStop();
    }

    private static class ProcessTreeInfo {
        private ContainerId ZRZWTBGZCS;

        private String FHCKXCHIXT;

        private ResourceCalculatorProcessTree CGKTIFRCXR;

        private long BMSXLBWPZT;

        private long LTCQCJJMHM;

        public ProcessTreeInfo(ContainerId containerId, String pid, ResourceCalculatorProcessTree pTree, long vmemLimit, long pmemLimit) {
            this.ZRZWTBGZCS = containerId;
            this.FHCKXCHIXT = pid;
            this.CGKTIFRCXR = pTree;
            this.BMSXLBWPZT = vmemLimit;
            this.LTCQCJJMHM = pmemLimit;
        }

        public ContainerId getContainerId() {
            return this.ZRZWTBGZCS;
        }

        public String getPID() {
            return this.FHCKXCHIXT;
        }

        public void setPid(String pid) {
            this.FHCKXCHIXT = pid;
        }

        public ResourceCalculatorProcessTree getProcessTree() {
            return this.CGKTIFRCXR;
        }

        public void setProcessTree(ResourceCalculatorProcessTree pTree) {
            this.CGKTIFRCXR = pTree;
        }

        public long getVmemLimit() {
            return this.BMSXLBWPZT;
        }

        /**
         *
         *
         * @return Physical memory limit for the process tree in bytes
         */
        public long getPmemLimit() {
            return this.LTCQCJJMHM;
        }
    }

    /**
     * Check whether a container's process tree's current memory usage is over
     * limit.
     *
     * When a java process exec's a program, it could momentarily account for
     * double the size of it's memory, because the JVM does a fork()+exec()
     * which at fork time creates a copy of the parent's memory. If the
     * monitoring thread detects the memory used by the container tree at the
     * same instance, it could assume it is over limit and kill the tree, for no
     * fault of the process itself.
     *
     * We counter this problem by employing a heuristic check: - if a process
     * tree exceeds the memory limit by more than twice, it is killed
     * immediately - if a process tree has processes older than the monitoring
     * interval exceeding the memory limit by even 1 time, it is killed. Else it
     * is given the benefit of doubt to lie around for one more iteration.
     *
     * @param containerId
     * 		Container Id for the container tree
     * @param currentMemUsage
     * 		Memory usage of a container tree
     * @param curMemUsageOfAgedProcesses
     * 		Memory usage of processes older than an iteration in a container
     * 		tree
     * @param vmemLimit
     * 		The limit specified for the container
     * @return true if the memory usage is more than twice the specified limit,
    or if processes in the tree, older than this thread's monitoring
    interval, exceed the memory limit. False, otherwise.
     */
    boolean isProcessTreeOverLimit(String BWKCMTMZLB, long LXRKNTVBCY, long MACAZPNIZB, long REKGVDUWDZ) {
        boolean IJFYWTVIVJ = false;
        if (LXRKNTVBCY > (2 * REKGVDUWDZ)) {
            ContainersMonitorImpl.SFDWIECOHW.warn(((((("Process tree for container: " + BWKCMTMZLB) + " running over twice ") + "the configured limit. Limit=") + REKGVDUWDZ) + ", current usage = ") + LXRKNTVBCY);
            IJFYWTVIVJ = true;
        } else
            if (MACAZPNIZB > REKGVDUWDZ) {
                ContainersMonitorImpl.SFDWIECOHW.warn(((((("Process tree for container: " + BWKCMTMZLB) + " has processes older than 1 ") + "iteration running over the configured limit. Limit=") + REKGVDUWDZ) + ", current usage = ") + MACAZPNIZB);
                IJFYWTVIVJ = true;
            }

        return IJFYWTVIVJ;
    }

    // method provided just for easy testing purposes
    boolean isProcessTreeOverLimit(ResourceCalculatorProcessTree IVXVJASOYC, String ZRGXPMBLZJ, long EFCIRZWTGC) {
        long ZRDAJLQRRC = IVXVJASOYC.getCumulativeVmem();
        // as processes begin with an age 1, we want to see if there are processes
        // more than 1 iteration old.
        long BDNCEUNFNU = IVXVJASOYC.getCumulativeVmem(1);
        return isProcessTreeOverLimit(ZRGXPMBLZJ, ZRDAJLQRRC, BDNCEUNFNU, EFCIRZWTGC);
    }

    private class MonitoringThread extends Thread {
        public MonitoringThread() {
            super("Container Monitor");
        }

        @Override
        public void run() {
            while (true) {
                // Print the processTrees for debugging.
                if (ContainersMonitorImpl.SFDWIECOHW.isDebugEnabled()) {
                    StringBuilder tmp = new StringBuilder("[ ");
                    for (ContainersMonitorImpl.ProcessTreeInfo p : BKGGWTLQIC.values()) {
                        tmp.append(p.getPID());
                        tmp.append(" ");
                    }
                    ContainersMonitorImpl.SFDWIECOHW.debug(("Current ProcessTree list : " + tmp.substring(0, tmp.length())) + "]");
                }
                // Add new containers
                synchronized(XFTSYKRTWW) {
                    for (Map.Entry<ContainerId, ContainersMonitorImpl.ProcessTreeInfo> entry : XFTSYKRTWW.entrySet()) {
                        ContainerId containerId = entry.getKey();
                        ContainersMonitorImpl.ProcessTreeInfo processTreeInfo = entry.getValue();
                        ContainersMonitorImpl.SFDWIECOHW.info("Starting resource-monitoring for " + containerId);
                        BKGGWTLQIC.put(containerId, processTreeInfo);
                    }
                    XFTSYKRTWW.clear();
                }
                // Remove finished containers
                synchronized(MHXECQOOLE) {
                    for (ContainerId containerId : MHXECQOOLE) {
                        BKGGWTLQIC.remove(containerId);
                        ContainersMonitorImpl.SFDWIECOHW.info("Stopping resource-monitoring for " + containerId);
                    }
                    MHXECQOOLE.clear();
                }
                // Now do the monitoring for the trackingContainers
                // Check memory usage and kill any overflowing containers
                long vmemStillInUsage = 0;
                long pmemStillInUsage = 0;
                for (Iterator<Map.Entry<ContainerId, ContainersMonitorImpl.ProcessTreeInfo>> it = BKGGWTLQIC.entrySet().iterator(); it.hasNext();) {
                    Map.Entry<ContainerId, ContainersMonitorImpl.ProcessTreeInfo> entry = it.next();
                    ContainerId containerId = entry.getKey();
                    ContainersMonitorImpl.ProcessTreeInfo ptInfo = entry.getValue();
                    try {
                        String pId = ptInfo.getPID();
                        // Initialize any uninitialized processTrees
                        if (pId == null) {
                            // get pid from ContainerId
                            pId = MTSVGMBIKB.getProcessId(ptInfo.getContainerId());
                            if (pId != null) {
                                // pId will be null, either if the container is not spawned yet
                                // or if the container's pid is removed from ContainerExecutor
                                ContainersMonitorImpl.SFDWIECOHW.debug(("Tracking ProcessTree " + pId) + " for the first time");
                                ResourceCalculatorProcessTree pt = ResourceCalculatorProcessTree.getResourceCalculatorProcessTree(pId, WDAASSYYAD, AHTPMZUATF);
                                ptInfo.setPid(pId);
                                ptInfo.setProcessTree(pt);
                            }
                        }
                        // End of initializing any uninitialized processTrees
                        if (pId == null) {
                            continue;// processTree cannot be tracked

                        }
                        ContainersMonitorImpl.SFDWIECOHW.debug((("Constructing ProcessTree for : PID = " + pId) + " ContainerId = ") + containerId);
                        ResourceCalculatorProcessTree pTree = ptInfo.getProcessTree();
                        pTree.updateProcessTree();// update process-tree

                        long currentVmemUsage = pTree.getCumulativeVmem();
                        long currentPmemUsage = pTree.getCumulativeRssmem();
                        // as processes begin with an age 1, we want to see if there
                        // are processes more than 1 iteration old.
                        long curMemUsageOfAgedProcesses = pTree.getCumulativeVmem(1);
                        long curRssMemUsageOfAgedProcesses = pTree.getCumulativeRssmem(1);
                        long vmemLimit = ptInfo.getVmemLimit();
                        long pmemLimit = ptInfo.getPmemLimit();
                        ContainersMonitorImpl.SFDWIECOHW.info(String.format("Memory usage of ProcessTree %s for container-id %s: ", pId, containerId.toString()) + formatUsageString(currentVmemUsage, vmemLimit, currentPmemUsage, pmemLimit));
                        boolean isMemoryOverLimit = false;
                        String msg = "";
                        int containerExitStatus = ContainerExitStatus.INVALID;
                        if (isVmemCheckEnabled() && isProcessTreeOverLimit(containerId.toString(), currentVmemUsage, curMemUsageOfAgedProcesses, vmemLimit)) {
                            // Container (the root process) is still alive and overflowing
                            // memory.
                            // Dump the process-tree and then clean it up.
                            msg = formatErrorMessage("virtual", currentVmemUsage, vmemLimit, currentPmemUsage, pmemLimit, pId, containerId, pTree);
                            isMemoryOverLimit = true;
                            containerExitStatus = ContainerExitStatus.KILLED_EXCEEDED_VMEM;
                        } else
                            if (isPmemCheckEnabled() && isProcessTreeOverLimit(containerId.toString(), currentPmemUsage, curRssMemUsageOfAgedProcesses, pmemLimit)) {
                                // Container (the root process) is still alive and overflowing
                                // memory.
                                // Dump the process-tree and then clean it up.
                                msg = formatErrorMessage("physical", currentVmemUsage, vmemLimit, currentPmemUsage, pmemLimit, pId, containerId, pTree);
                                isMemoryOverLimit = true;
                                containerExitStatus = ContainerExitStatus.KILLED_EXCEEDED_PMEM;
                            }

                        if (isMemoryOverLimit) {
                            // Virtual or physical memory over limit. Fail the container and
                            // remove
                            // the corresponding process tree
                            ContainersMonitorImpl.SFDWIECOHW.warn(msg);
                            // warn if not a leader
                            if (!pTree.checkPidPgrpidForMatch()) {
                                ContainersMonitorImpl.SFDWIECOHW.error(("Killed container process with PID " + pId) + " but it is not a process group leader.");
                            }
                            // kill the container
                            AXFJXICTBB.getEventHandler().handle(new org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerKillEvent(containerId, containerExitStatus, msg));
                            it.remove();
                            ContainersMonitorImpl.SFDWIECOHW.info("Removed ProcessTree with root " + pId);
                        } else {
                            // Accounting the total memory in usage for all containers that
                            // are still
                            // alive and within limits.
                            vmemStillInUsage += currentVmemUsage;
                            pmemStillInUsage += currentPmemUsage;
                        }
                    } catch (Exception e) {
                        // Log the exception and proceed to the next container.
                        ContainersMonitorImpl.SFDWIECOHW.warn(("Uncaught exception in ContainerMemoryManager " + "while managing memory of ") + containerId, e);
                    }
                }
                try {
                    Thread.sleep(GZSXLGQWBE);
                } catch (InterruptedException e) {
                    ContainersMonitorImpl.SFDWIECOHW.warn(ContainersMonitorImpl.class.getName() + " is interrupted. Exiting.");
                    break;
                }
            } 
        }

        private String formatErrorMessage(String memTypeExceeded, long currentVmemUsage, long vmemLimit, long currentPmemUsage, long pmemLimit, String pId, ContainerId containerId, ResourceCalculatorProcessTree pTree) {
            return ((((((String.format("Container [pid=%s,containerID=%s] is running beyond %s memory limits. ", pId, containerId, memTypeExceeded) + "Current usage: ") + formatUsageString(currentVmemUsage, vmemLimit, currentPmemUsage, pmemLimit)) + ". Killing container.\n") + "Dump of the process-tree for ") + containerId) + " :\n") + pTree.getProcessTreeDump();
        }

        private String formatUsageString(long currentVmemUsage, long vmemLimit, long currentPmemUsage, long pmemLimit) {
            return String.format("%sB of %sB physical memory used; " + "%sB of %sB virtual memory used", TraditionalBinaryPrefix.long2String(currentPmemUsage, "", 1), TraditionalBinaryPrefix.long2String(pmemLimit, "", 1), TraditionalBinaryPrefix.long2String(currentVmemUsage, "", 1), TraditionalBinaryPrefix.long2String(vmemLimit, "", 1));
        }
    }

    @Override
    public long getVmemAllocatedForContainers() {
        return this.HOEAWXOPRT;
    }

    /**
     * Is the total physical memory check enabled?
     *
     * @return true if total physical memory check is enabled.
     */
    @Override
    public boolean isPmemCheckEnabled() {
        return this.IPAQUOMMJY;
    }

    @Override
    public long getPmemAllocatedForContainers() {
        return this.OBAFOMOFMK;
    }

    @Override
    public long getVCoresAllocatedForContainers() {
        return this.ENRZMYIWVV;
    }

    /**
     * Is the total virtual memory check enabled?
     *
     * @return true if total virtual memory check is enabled.
     */
    @Override
    public boolean isVmemCheckEnabled() {
        return this.VTFDICIFCG;
    }

    @Override
    public void handle(ContainersMonitorEvent YNTGDYHVVY) {
        if (!isEnabled()) {
            return;
        }
        ContainerId UOMWFVPTZA = YNTGDYHVVY.getContainerId();
        switch (YNTGDYHVVY.getType()) {
            case START_MONITORING_CONTAINER :
                ContainerStartMonitoringEvent RLQEXHZNAZ = ((ContainerStartMonitoringEvent) (YNTGDYHVVY));
                synchronized(this.XFTSYKRTWW) {
                    ContainersMonitorImpl.ProcessTreeInfo BSRSEOEJYS = new ContainersMonitorImpl.ProcessTreeInfo(UOMWFVPTZA, null, null, RLQEXHZNAZ.getVmemLimit(), RLQEXHZNAZ.getPmemLimit());
                    this.XFTSYKRTWW.put(UOMWFVPTZA, BSRSEOEJYS);
                }
                break;
            case STOP_MONITORING_CONTAINER :
                synchronized(this.MHXECQOOLE) {
                    this.MHXECQOOLE.add(UOMWFVPTZA);
                }
                break;
            default :
                // TODO: Wrong event.
        }
    }
}