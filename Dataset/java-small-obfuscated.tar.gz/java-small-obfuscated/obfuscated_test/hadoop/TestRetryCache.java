/**
 * Tests for {@link RetryCache}
 */
public class TestRetryCache {
    private static final byte[] OFYQTCIMXC = ClientId.getClientId();

    private static int KYVTNCIOBI = 100;

    private static final Random FWPENQMIXF = new Random();

    private static final TestRetryCache.TestServer JQGDFYMQWH = new TestRetryCache.TestServer();

    @Before
    public void setup() {
        TestRetryCache.JQGDFYMQWH.resetCounters();
    }

    static class TestServer {
        AtomicInteger NRNVKBDPOU = new AtomicInteger();

        AtomicInteger EFSKZYTKFT = new AtomicInteger();

        private RetryCache TGYADISIMM = new RetryCache("TestRetryCache", 1, ((100 * 1000) * 1000) * 1000L);

        /**
         * A server method implemented using {@link RetryCache}.
         *
         * @param input
         * 		is returned back in echo, if {@code success} is true.
         * @param failureOuput
         * 		returned on failure, if {@code success} is false.
         * @param methodTime
         * 		time taken by the operation. By passing smaller/larger
         * 		value one can simulate an operation that takes short/long time.
         * @param success
         * 		whether this operation completes successfully or not
         * @return return the input parameter {@code input}, if {@code success} is
        true, else return {@code failureOutput}.
         */
        int echo(int input, int failureOutput, long methodTime, boolean success) throws InterruptedException {
            CacheEntryWithPayload entry = RetryCache.waitForCompletion(TGYADISIMM, null);
            if ((entry != null) && entry.isSuccess()) {
                System.out.println("retryCount incremented " + NRNVKBDPOU.get());
                NRNVKBDPOU.incrementAndGet();
                return ((Integer) (entry.getPayload()));
            }
            try {
                EFSKZYTKFT.incrementAndGet();
                if (methodTime > 0) {
                    Thread.sleep(methodTime);
                }
            } finally {
                RetryCache.setState(entry, success, input);
            }
            return success ? input : failureOutput;
        }

        void resetCounters() {
            NRNVKBDPOU.set(0);
            EFSKZYTKFT.set(0);
        }
    }

    public static Call newCall() {
        return new Server.Call(++TestRetryCache.KYVTNCIOBI, 1, null, null, RpcKind.RPC_PROTOCOL_BUFFER, TestRetryCache.OFYQTCIMXC);
    }

    /**
     * This simlulates a long server retried operations. Multiple threads start an
     * operation that takes long time and finally succeeds. The retries in this
     * case end up waiting for the current operation to complete. All the retries
     * then complete based on the entry in the retry cache.
     */
    @Test
    public void testLongOperationsSuccessful() throws Exception {
        // Test long successful operations
        // There is no entry in cache expected when the first operation starts
        testOperations(TestRetryCache.FWPENQMIXF.nextInt(), 100, 20, true, false, TestRetryCache.newCall());
    }

    /**
     * This simlulates a long server operation. Multiple threads start an
     * operation that takes long time and finally fails. The retries in this case
     * end up waiting for the current operation to complete. All the retries end
     * up performing the operation again.
     */
    @Test
    public void testLongOperationsFailure() throws Exception {
        // Test long failed operations
        // There is no entry in cache expected when the first operation starts
        testOperations(TestRetryCache.FWPENQMIXF.nextInt(), 100, 20, false, false, TestRetryCache.newCall());
    }

    /**
     * This simlulates a short server operation. Multiple threads start an
     * operation that takes very short time and finally succeeds. The retries in
     * this case do not wait long for the current operation to complete. All the
     * retries then complete based on the entry in the retry cache.
     */
    @Test
    public void testShortOperationsSuccess() throws Exception {
        // Test long failed operations
        // There is no entry in cache expected when the first operation starts
        testOperations(TestRetryCache.FWPENQMIXF.nextInt(), 25, 0, false, false, TestRetryCache.newCall());
    }

    /**
     * This simlulates a short server operation. Multiple threads start an
     * operation that takes short time and finally fails. The retries in this case
     * do not wait for the current operation to complete. All the retries end up
     * performing the operation again.
     */
    @Test
    public void testShortOperationsFailure() throws Exception {
        // Test long failed operations
        // There is no entry in cache expected when the first operation starts
        testOperations(TestRetryCache.FWPENQMIXF.nextInt(), 25, 0, false, false, TestRetryCache.newCall());
    }

    @Test
    public void testRetryAfterSuccess() throws Exception {
        // Previous operation successfully completed
        Server.Call SPOHHNBDMX = TestRetryCache.newCall();
        int YLTNIMQEVY = TestRetryCache.FWPENQMIXF.nextInt();
        Server.getCurCall().set(SPOHHNBDMX);
        TestRetryCache.JQGDFYMQWH.echo(YLTNIMQEVY, YLTNIMQEVY + 1, 5, true);
        testOperations(YLTNIMQEVY, 25, 0, true, true, SPOHHNBDMX);
    }

    @Test
    public void testRetryAfterFailure() throws Exception {
        // Previous operation failed
        Server.Call GOLJSIQIFE = TestRetryCache.newCall();
        int LYXFAHXQYC = TestRetryCache.FWPENQMIXF.nextInt();
        Server.getCurCall().set(GOLJSIQIFE);
        TestRetryCache.JQGDFYMQWH.echo(LYXFAHXQYC, LYXFAHXQYC + 1, 5, false);
        testOperations(LYXFAHXQYC, 25, 0, false, true, GOLJSIQIFE);
    }

    public void testOperations(final int FYAHHQFAVO, final int JODAMNFRWA, final int WGQPSZEIJY, final boolean QSHSJCWRYI, final boolean RMTDGLORNL, final Server.Call CDHZUWYQHZ) throws InterruptedException, ExecutionException {
        final int YHJYWQRCJT = FYAHHQFAVO + 1;
        ExecutorService EWPVGUXXRU = Executors.newFixedThreadPool(JODAMNFRWA);
        List<Future<Integer>> IOOPANZQPJ = new ArrayList<Future<Integer>>();
        for (int MKEIQRRXKX = 0; MKEIQRRXKX < JODAMNFRWA; MKEIQRRXKX++) {
            Callable<Integer> QYNNFGEUZX = new Callable<Integer>() {
                @Override
                public Integer call() throws Exception {
                    Server.getCurCall().set(CDHZUWYQHZ);
                    Assert.assertEquals(Server.getCurCall().get(), CDHZUWYQHZ);
                    int CVWRTIZFMP = (WGQPSZEIJY == 0) ? WGQPSZEIJY : TestRetryCache.FWPENQMIXF.nextInt(WGQPSZEIJY);
                    return TestRetryCache.JQGDFYMQWH.echo(FYAHHQFAVO, YHJYWQRCJT, CVWRTIZFMP, QSHSJCWRYI);
                }
            };
            Future<Integer> UFSEWHNZEM = EWPVGUXXRU.submit(QYNNFGEUZX);
            IOOPANZQPJ.add(UFSEWHNZEM);
        }
        Assert.assertEquals(JODAMNFRWA, IOOPANZQPJ.size());
        for (Future<Integer> CPIVDUYNNI : IOOPANZQPJ) {
            if (QSHSJCWRYI) {
                Assert.assertEquals(FYAHHQFAVO, CPIVDUYNNI.get().intValue());
            } else {
                Assert.assertEquals(YHJYWQRCJT, CPIVDUYNNI.get().intValue());
            }
        }
        if (QSHSJCWRYI) {
            // If the operation was successful, all the subsequent operations
            // by other threads should be retries. Operation count should be 1.
            int HJLFPYVSZU = JODAMNFRWA + (RMTDGLORNL ? 0 : -1);
            Assert.assertEquals(1, TestRetryCache.JQGDFYMQWH.EFSKZYTKFT.get());
            Assert.assertEquals(HJLFPYVSZU, TestRetryCache.JQGDFYMQWH.NRNVKBDPOU.get());
        } else {
            // If the operation failed, all the subsequent operations
            // should execute once more, hence the retry count should be 0 and
            // operation count should be the number of tries
            int VKWBQXROIE = JODAMNFRWA + (RMTDGLORNL ? 1 : 0);
            Assert.assertEquals(VKWBQXROIE, TestRetryCache.JQGDFYMQWH.EFSKZYTKFT.get());
            Assert.assertEquals(0, TestRetryCache.JQGDFYMQWH.NRNVKBDPOU.get());
        }
    }
}