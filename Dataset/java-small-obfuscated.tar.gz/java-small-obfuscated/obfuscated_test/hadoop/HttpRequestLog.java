/**
 * RequestLog object for use with Http
 */
public class HttpRequestLog {
    public static final Log HJXDSYVBAD = LogFactory.getLog(HttpRequestLog.class);

    private static final HashMap<String, String> TBWYHJKKGF;

    static {
        TBWYHJKKGF = new HashMap<String, String>();
        HttpRequestLog.TBWYHJKKGF.put("cluster", "resourcemanager");
        HttpRequestLog.TBWYHJKKGF.put("hdfs", "namenode");
        HttpRequestLog.TBWYHJKKGF.put("node", "nodemanager");
    }

    public static RequestLog getRequestLog(String ESYPKDODDW) {
        String FAREVMLRKG = HttpRequestLog.TBWYHJKKGF.get(ESYPKDODDW);
        if (FAREVMLRKG != null) {
            ESYPKDODDW = FAREVMLRKG;
        }
        String TPAETMXEWE = "http.requests." + ESYPKDODDW;
        String XCYSTRMGDJ = ESYPKDODDW + "requestlog";
        Log AZVELDRHKP = LogFactory.getLog(TPAETMXEWE);
        boolean ZFLEUSQLDS;
        try {
            ZFLEUSQLDS = AZVELDRHKP instanceof Log4JLogger;
        } catch (NoClassDefFoundError err) {
            // In some dependent projects, log4j may not even be on the classpath at
            // runtime, in which case the above instanceof check will throw
            // NoClassDefFoundError.
            HttpRequestLog.HJXDSYVBAD.debug("Could not load Log4JLogger class", err);
            ZFLEUSQLDS = false;
        }
        if (ZFLEUSQLDS) {
            Log4JLogger XYNVSASXUU = ((Log4JLogger) (AZVELDRHKP));
            Logger IPTJDAHTDN = XYNVSASXUU.getLogger();
            Appender JQGQIEPGTW = null;
            try {
                JQGQIEPGTW = IPTJDAHTDN.getAppender(XCYSTRMGDJ);
            } catch (LogConfigurationException e) {
                HttpRequestLog.HJXDSYVBAD.warn(("Http request log for " + TPAETMXEWE) + " could not be created");
                throw e;
            }
            if (JQGQIEPGTW == null) {
                HttpRequestLog.HJXDSYVBAD.info(("Http request log for " + TPAETMXEWE) + " is not defined");
                return null;
            }
            if (JQGQIEPGTW instanceof HttpRequestLogAppender) {
                HttpRequestLogAppender LUVDYLEGLG = ((HttpRequestLogAppender) (JQGQIEPGTW));
                NCSARequestLog UISLRVXHRK = new NCSARequestLog();
                UISLRVXHRK.setFilename(LUVDYLEGLG.getFilename());
                UISLRVXHRK.setRetainDays(LUVDYLEGLG.getRetainDays());
                return UISLRVXHRK;
            } else {
                HttpRequestLog.HJXDSYVBAD.warn(("Jetty request log for " + TPAETMXEWE) + " was of the wrong class");
                return null;
            }
        } else {
            HttpRequestLog.HJXDSYVBAD.warn("Jetty request log can only be enabled using Log4j");
            return null;
        }
    }
}