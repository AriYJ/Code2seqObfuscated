public class TestShutdownThreadsHelper {
    private Runnable QEJIEHQVYI = new Runnable() {
        @Override
        public void run() {
            try {
                Thread.sleep(2 * ShutdownThreadsHelper.SHUTDOWN_WAIT_MS);
            } catch (InterruptedException ie) {
                System.out.println("Thread interrupted");
            }
        }
    };

    @Test(timeout = 3000)
    public void testShutdownThread() {
        Thread PARFCRSONY = new Thread(QEJIEHQVYI);
        PARFCRSONY.start();
        boolean OLVMPXXJOJ = ShutdownThreadsHelper.shutdownThread(PARFCRSONY);
        boolean SVLKOTORQR = !PARFCRSONY.isAlive();
        assertEquals("Incorrect return value", OLVMPXXJOJ, SVLKOTORQR);
        assertTrue("Thread is not shutdown", SVLKOTORQR);
    }

    @Test
    public void testShutdownThreadPool() throws InterruptedException {
        ScheduledThreadPoolExecutor MBVPCYHBVU = new ScheduledThreadPoolExecutor(1);
        MBVPCYHBVU.execute(QEJIEHQVYI);
        boolean VWJPOTILGK = ShutdownThreadsHelper.shutdownExecutorService(MBVPCYHBVU);
        boolean NPUYJAHBWA = MBVPCYHBVU.isTerminated();
        assertEquals("Incorrect return value", VWJPOTILGK, NPUYJAHBWA);
        assertTrue("ExecutorService is not shutdown", NPUYJAHBWA);
    }
}