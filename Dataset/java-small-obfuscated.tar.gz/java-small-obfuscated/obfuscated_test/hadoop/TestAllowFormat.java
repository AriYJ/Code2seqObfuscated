/**
 * Startup and format tests
 */
public class TestAllowFormat {
    public static final String QAQBXVJXES = "localhost:";

    public static final String HHMSXIDNRQ = "0.0.0.0:";

    private static final Log NEAHTPNIRK = LogFactory.getLog(TestAllowFormat.class.getName());

    private static final File OZKERJHRNM = new File(PathUtils.getTestDir(TestAllowFormat.class), "dfs");

    private static Configuration RRYSWIMGEJ;

    private static MiniDFSCluster KROPFUPCPI = null;

    @BeforeClass
    public static void setUp() throws Exception {
        TestAllowFormat.RRYSWIMGEJ = new Configuration();
        if (TestAllowFormat.OZKERJHRNM.exists() && (!FileUtil.fullyDelete(TestAllowFormat.OZKERJHRNM))) {
            throw new IOException(("Could not delete hdfs directory '" + TestAllowFormat.OZKERJHRNM) + "'");
        }
        // Test has multiple name directories.
        // Format should not really prompt us if one of the directories exist,
        // but is empty. So in case the test hangs on an input, it means something
        // could be wrong in the format prompting code. (HDFS-1636)
        TestAllowFormat.NEAHTPNIRK.info("hdfsdir is " + TestAllowFormat.OZKERJHRNM.getAbsolutePath());
        File IIEJBUHXGK = new File(TestAllowFormat.OZKERJHRNM, "name1");
        File MCKLZVUOVB = new File(TestAllowFormat.OZKERJHRNM, "name2");
        // To test multiple directory handling, we pre-create one of the name directories.
        IIEJBUHXGK.mkdirs();
        // Set multiple name directories.
        TestAllowFormat.RRYSWIMGEJ.set(DFSConfigKeys.DFS_NAMENODE_NAME_DIR_KEY, (IIEJBUHXGK.getPath() + ",") + MCKLZVUOVB.getPath());
        TestAllowFormat.RRYSWIMGEJ.set(DFSConfigKeys.DFS_DATANODE_DATA_DIR_KEY, new File(TestAllowFormat.OZKERJHRNM, "data").getPath());
        TestAllowFormat.RRYSWIMGEJ.set(DFSConfigKeys.DFS_NAMENODE_CHECKPOINT_DIR_KEY, new File(TestAllowFormat.OZKERJHRNM, "secondary").getPath());
        FileSystem.setDefaultUri(TestAllowFormat.RRYSWIMGEJ, ("hdfs://" + TestAllowFormat.QAQBXVJXES) + "0");
    }

    /**
     * clean up
     */
    @AfterClass
    public static void tearDown() throws Exception {
        if (TestAllowFormat.KROPFUPCPI != null) {
            TestAllowFormat.KROPFUPCPI.shutdown();
            TestAllowFormat.NEAHTPNIRK.info("Stopping mini cluster");
        }
        if (TestAllowFormat.OZKERJHRNM.exists() && (!FileUtil.fullyDelete(TestAllowFormat.OZKERJHRNM))) {
            throw new IOException(("Could not delete hdfs directory in tearDown '" + TestAllowFormat.OZKERJHRNM) + "'");
        }
    }

    /**
     * start MiniDFScluster, try formatting with different settings
     *
     * @throws IOException
     * 		
     * @throws InterruptedException
     * 		
     */
    @Test
    public void testAllowFormat() throws IOException {
        TestAllowFormat.NEAHTPNIRK.info("--starting mini cluster");
        // manage dirs parameter set to false
        NameNode WWSLIQAPYT;
        // 1. Create a new cluster and format DFS
        TestAllowFormat.RRYSWIMGEJ.setBoolean(DFSConfigKeys.DFS_NAMENODE_SUPPORT_ALLOW_FORMAT_KEY, true);
        TestAllowFormat.KROPFUPCPI = new MiniDFSCluster.Builder(TestAllowFormat.RRYSWIMGEJ).manageDataDfsDirs(false).manageNameDfsDirs(false).build();
        TestAllowFormat.KROPFUPCPI.waitActive();
        assertNotNull(TestAllowFormat.KROPFUPCPI);
        WWSLIQAPYT = TestAllowFormat.KROPFUPCPI.getNameNode();
        assertNotNull(WWSLIQAPYT);
        TestAllowFormat.NEAHTPNIRK.info("Mini cluster created OK");
        // 2. Try formatting DFS with allowformat false.
        // NOTE: the cluster must be shut down for format to work.
        TestAllowFormat.NEAHTPNIRK.info("Verifying format will fail with allowformat false");
        TestAllowFormat.RRYSWIMGEJ.setBoolean(DFSConfigKeys.DFS_NAMENODE_SUPPORT_ALLOW_FORMAT_KEY, false);
        try {
            TestAllowFormat.KROPFUPCPI.shutdown();
            NameNode.format(TestAllowFormat.RRYSWIMGEJ);
            fail("Format succeeded, when it should have failed");
        } catch (IOException e) {
            // expected to fail
            // Verify we got message we expected
            assertTrue("Exception was not about formatting Namenode", e.getMessage().startsWith("The option " + DFSConfigKeys.DFS_NAMENODE_SUPPORT_ALLOW_FORMAT_KEY));
            TestAllowFormat.NEAHTPNIRK.info("Expected failure: " + StringUtils.stringifyException(e));
            TestAllowFormat.NEAHTPNIRK.info("Done verifying format will fail with allowformat false");
        }
        // 3. Try formatting DFS with allowformat true
        TestAllowFormat.NEAHTPNIRK.info("Verifying format will succeed with allowformat true");
        TestAllowFormat.RRYSWIMGEJ.setBoolean(DFSConfigKeys.DFS_NAMENODE_SUPPORT_ALLOW_FORMAT_KEY, true);
        NameNode.format(TestAllowFormat.RRYSWIMGEJ);
        TestAllowFormat.NEAHTPNIRK.info("Done verifying format will succeed with allowformat true");
    }

    /**
     * Test to skip format for non file scheme directory configured
     *
     * @throws Exception
     * 		
     */
    @Test
    public void testFormatShouldBeIgnoredForNonFileBasedDirs() throws Exception {
        Configuration GLOASRBCNN = new HdfsConfiguration();
        String ABPJRHUBRD = "mycluster";
        // DFS_NAMENODE_RPC_ADDRESS_KEY are required to identify the NameNode
        // is configured in HA, then only DFS_NAMENODE_SHARED_EDITS_DIR_KEY
        // is considered.
        String ZALGACJGYK = "127.0.0.1";
        InetSocketAddress BNYRQXNLHZ = new InetSocketAddress(ZALGACJGYK, 8020);
        InetSocketAddress FAETDHWMWI = new InetSocketAddress(ZALGACJGYK, 9020);
        HATestUtil.setFailoverConfigurations(GLOASRBCNN, ABPJRHUBRD, BNYRQXNLHZ, FAETDHWMWI);
        GLOASRBCNN.set(DFSConfigKeys.DFS_NAMENODE_NAME_DIR_KEY, new File(TestAllowFormat.OZKERJHRNM, "name").getAbsolutePath());
        GLOASRBCNN.setBoolean(DFSConfigKeys.DFS_NAMENODE_SUPPORT_ALLOW_FORMAT_KEY, true);
        GLOASRBCNN.set(DFSUtil.addKeySuffixes(DFS_NAMENODE_EDITS_PLUGIN_PREFIX, "dummy"), DummyJournalManager.class.getName());
        GLOASRBCNN.set(DFS_NAMENODE_SHARED_EDITS_DIR_KEY, ("dummy://" + ZALGACJGYK) + ":2181/ledgers");
        GLOASRBCNN.set(DFS_HA_NAMENODE_ID_KEY, "nn1");
        // An internal assert is added to verify the working of test
        NameNode.format(GLOASRBCNN);
    }
}