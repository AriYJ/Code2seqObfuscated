@Private
public class NodeManager implements ContainerManagementProtocol {
    private static final Log FHYFINCWNL = LogFactory.getLog(NodeManager.class);

    private static final RecordFactory GIBXBVNCHV = RecordFactoryProvider.getRecordFactory(null);

    private final String TVORNBIKGC;

    private final String AZQQUZSFRJ;

    private final String OUXBOASZPV;

    private final NodeId UKRVPFHCDR;

    private final Resource MVCHAEYMTG;

    private final ResourceManager NAXEANRDZZ;

    Resource LFWXZXRZAB = NodeManager.GIBXBVNCHV.newRecordInstance(Resource.class);

    Resource TAJOIIVXJA = NodeManager.GIBXBVNCHV.newRecordInstance(Resource.class);

    final ResourceTrackerService WYELADXLYY;

    final Map<ApplicationId, List<Container>> RAAOFHQWBR = new HashMap<ApplicationId, List<Container>>();

    final Map<Container, ContainerStatus> ROFXVAPAGN = new HashMap<Container, ContainerStatus>();

    public NodeManager(String REXVVURTUE, int ECHDMZKUNY, int OOZJWCRTIU, String EAKHTGCRUV, Resource DOROJZZWRZ, ResourceManager VHGNDBOORX) throws IOException, YarnException {
        this.TVORNBIKGC = (REXVVURTUE + ":") + ECHDMZKUNY;
        this.AZQQUZSFRJ = (REXVVURTUE + ":") + OOZJWCRTIU;
        this.OUXBOASZPV = EAKHTGCRUV;
        this.WYELADXLYY = VHGNDBOORX.getResourceTrackerService();
        this.MVCHAEYMTG = DOROJZZWRZ;
        Resources.addTo(LFWXZXRZAB, DOROJZZWRZ);
        this.UKRVPFHCDR = NodeId.newInstance(REXVVURTUE, ECHDMZKUNY);
        RegisterNodeManagerRequest HVRPJTLPLX = NodeManager.GIBXBVNCHV.newRecordInstance(RegisterNodeManagerRequest.class);
        HVRPJTLPLX.setHttpPort(OOZJWCRTIU);
        HVRPJTLPLX.setResource(DOROJZZWRZ);
        HVRPJTLPLX.setNodeId(this.UKRVPFHCDR);
        HVRPJTLPLX.setNMVersion(YarnVersionInfo.getVersion());
        WYELADXLYY.registerNodeManager(HVRPJTLPLX);
        this.NAXEANRDZZ = VHGNDBOORX;
        VHGNDBOORX.getResourceScheduler().getNodeReport(this.UKRVPFHCDR);
    }

    public String getHostName() {
        return TVORNBIKGC;
    }

    public String getRackName() {
        return OUXBOASZPV;
    }

    public NodeId getNodeId() {
        return UKRVPFHCDR;
    }

    public Resource getCapability() {
        return MVCHAEYMTG;
    }

    public Resource getAvailable() {
        return LFWXZXRZAB;
    }

    public Resource getUsed() {
        return TAJOIIVXJA;
    }

    int WFTIGUXUAM = 0;

    private List<ContainerStatus> getContainerStatuses(Map<ApplicationId, List<Container>> FRONIMQHJR) {
        List<ContainerStatus> XVVBUZDMNH = new ArrayList<ContainerStatus>();
        for (List<Container> BXBECNOWLZ : FRONIMQHJR.values()) {
            for (Container DLHSJHFDMX : BXBECNOWLZ) {
                XVVBUZDMNH.add(ROFXVAPAGN.get(DLHSJHFDMX));
            }
        }
        return XVVBUZDMNH;
    }

    public void heartbeat() throws IOException, YarnException {
        NodeStatus DTEUPUGKPT = NodeManager.createNodeStatus(UKRVPFHCDR, getContainerStatuses(RAAOFHQWBR));
        DTEUPUGKPT.setResponseId(WFTIGUXUAM);
        NodeHeartbeatRequest WRZUHRJADJ = NodeManager.GIBXBVNCHV.newRecordInstance(NodeHeartbeatRequest.class);
        WRZUHRJADJ.setNodeStatus(DTEUPUGKPT);
        NodeHeartbeatResponse MWMERHSNJB = WYELADXLYY.nodeHeartbeat(WRZUHRJADJ);
        WFTIGUXUAM = MWMERHSNJB.getResponseId();
    }

    @Override
    public synchronized StartContainersResponse startContainers(StartContainersRequest NETFIIYYGY) throws YarnException {
        for (StartContainerRequest XXSTZSQHTX : NETFIIYYGY.getStartContainerRequests()) {
            Token WTXZGVWUOP = XXSTZSQHTX.getContainerToken();
            ContainerTokenIdentifier KZWINRJOGL = null;
            try {
                KZWINRJOGL = BuilderUtils.newContainerTokenIdentifier(WTXZGVWUOP);
            } catch (IOException e) {
                throw RPCUtil.getRemoteException(e);
            }
            ContainerId NHXTNPWVHA = KZWINRJOGL.getContainerID();
            ApplicationId KJJTUOWCLS = NHXTNPWVHA.getApplicationAttemptId().getApplicationId();
            List<Container> SUOYWWTNLC = RAAOFHQWBR.get(KJJTUOWCLS);
            if (SUOYWWTNLC == null) {
                SUOYWWTNLC = new ArrayList<Container>();
                RAAOFHQWBR.put(KJJTUOWCLS, SUOYWWTNLC);
            }
            // Sanity check
            for (Container XNZXFZBCWA : SUOYWWTNLC) {
                if (XNZXFZBCWA.getId().compareTo(NHXTNPWVHA) == 0) {
                    throw new IllegalStateException((("Container " + NHXTNPWVHA) + " already setup on node ") + TVORNBIKGC);
                }
            }
            Container IUJZNAYKVG = // DKDC - Doesn't matter
            BuilderUtils.newContainer(NHXTNPWVHA, this.UKRVPFHCDR, AZQQUZSFRJ, KZWINRJOGL.getResource(), null, null);
            ContainerStatus MPZZUQOANS = BuilderUtils.newContainerStatus(IUJZNAYKVG.getId(), NEW, "", -1000);
            SUOYWWTNLC.add(IUJZNAYKVG);
            ROFXVAPAGN.put(IUJZNAYKVG, MPZZUQOANS);
            Resources.subtractFrom(LFWXZXRZAB, KZWINRJOGL.getResource());
            Resources.addTo(TAJOIIVXJA, KZWINRJOGL.getResource());
            if (NodeManager.FHYFINCWNL.isDebugEnabled()) {
                NodeManager.FHYFINCWNL.debug(((((((((("startContainer:" + " node=") + TVORNBIKGC) + " application=") + KJJTUOWCLS) + " container=") + IUJZNAYKVG) + " available=") + LFWXZXRZAB) + " used=") + TAJOIIVXJA);
            }
        }
        StartContainersResponse JFAXUKUEMD = StartContainersResponse.newInstance(null, null, null);
        return JFAXUKUEMD;
    }

    public synchronized void checkResourceUsage() {
        NodeManager.FHYFINCWNL.info("Checking resource usage for " + TVORNBIKGC);
        Assert.assertEquals(LFWXZXRZAB.getMemory(), NAXEANRDZZ.getResourceScheduler().getNodeReport(this.UKRVPFHCDR).getAvailableResource().getMemory());
        Assert.assertEquals(TAJOIIVXJA.getMemory(), NAXEANRDZZ.getResourceScheduler().getNodeReport(this.UKRVPFHCDR).getUsedResource().getMemory());
    }

    @Override
    public synchronized StopContainersResponse stopContainers(StopContainersRequest WQFLVGELYQ) throws YarnException {
        for (ContainerId GJSCGJOZSY : WQFLVGELYQ.getContainerIds()) {
            String ABPXPMMUNY = String.valueOf(GJSCGJOZSY.getApplicationAttemptId().getApplicationId().getId());
            // Mark the container as COMPLETE
            List<Container> YSDADNGDBZ = RAAOFHQWBR.get(GJSCGJOZSY.getApplicationAttemptId().getApplicationId());
            for (Container BCLCLMQVAG : YSDADNGDBZ) {
                if (BCLCLMQVAG.getId().compareTo(GJSCGJOZSY) == 0) {
                    ContainerStatus XFYMUILZUN = ROFXVAPAGN.get(BCLCLMQVAG);
                    XFYMUILZUN.setState(COMPLETE);
                    ROFXVAPAGN.put(BCLCLMQVAG, XFYMUILZUN);
                }
            }
            // Send a heartbeat
            try {
                heartbeat();
            } catch (IOException ioe) {
                throw RPCUtil.getRemoteException(ioe);
            }
            // Remove container and update status
            int BYIELUGPGD = 0;
            Container TQNKNLFKUX = null;
            for (Iterator<Container> TAKPGPNMWY = YSDADNGDBZ.iterator(); TAKPGPNMWY.hasNext();) {
                TQNKNLFKUX = TAKPGPNMWY.next();
                if (TQNKNLFKUX.getId().compareTo(GJSCGJOZSY) == 0) {
                    TAKPGPNMWY.remove();
                    ++BYIELUGPGD;
                }
            }
            if (BYIELUGPGD != 1) {
                throw new IllegalStateException(((("Container " + GJSCGJOZSY) + " stopped ") + BYIELUGPGD) + " times!");
            }
            Resources.addTo(LFWXZXRZAB, TQNKNLFKUX.getResource());
            Resources.subtractFrom(TAJOIIVXJA, TQNKNLFKUX.getResource());
            if (NodeManager.FHYFINCWNL.isDebugEnabled()) {
                NodeManager.FHYFINCWNL.debug(((((((((("stopContainer:" + " node=") + TVORNBIKGC) + " application=") + ABPXPMMUNY) + " container=") + GJSCGJOZSY) + " available=") + LFWXZXRZAB) + " used=") + TAJOIIVXJA);
            }
        }
        return StopContainersResponse.newInstance(null, null);
    }

    @Override
    public synchronized GetContainerStatusesResponse getContainerStatuses(GetContainerStatusesRequest XTUXPRDPBT) throws YarnException {
        List<ContainerStatus> GBDAUIUNBI = new ArrayList<ContainerStatus>();
        for (ContainerId OWPLDHKODU : XTUXPRDPBT.getContainerIds()) {
            List<Container> EYCEJMJCMV = RAAOFHQWBR.get(OWPLDHKODU.getApplicationAttemptId().getApplicationId());
            Container ARTNWLPSID = null;
            for (Container IGEHLHRCGW : EYCEJMJCMV) {
                if (IGEHLHRCGW.getId().equals(OWPLDHKODU)) {
                    ARTNWLPSID = IGEHLHRCGW;
                }
            }
            if ((ARTNWLPSID != null) && (ROFXVAPAGN.get(ARTNWLPSID).getState() != null)) {
                GBDAUIUNBI.add(ROFXVAPAGN.get(ARTNWLPSID));
            }
        }
        return GetContainerStatusesResponse.newInstance(GBDAUIUNBI, null);
    }

    public static NodeStatus createNodeStatus(NodeId VQQADOFTRB, List<ContainerStatus> GLSVZTRLKU) {
        RecordFactory BWRJGFEJNV = RecordFactoryProvider.getRecordFactory(null);
        NodeStatus AUFUQELBWP = BWRJGFEJNV.newRecordInstance(NodeStatus.class);
        AUFUQELBWP.setNodeId(VQQADOFTRB);
        AUFUQELBWP.setContainersStatuses(GLSVZTRLKU);
        NodeHealthStatus AWLYUZOAVX = BWRJGFEJNV.newRecordInstance(NodeHealthStatus.class);
        AWLYUZOAVX.setIsNodeHealthy(true);
        AUFUQELBWP.setNodeHealthStatus(AWLYUZOAVX);
        return AUFUQELBWP;
    }
}