/**
 * Access token representation of Openstack Keystone authentication.
 * Class holds token id, tenant and expiration time.
 * THIS FILE IS MAPPED BY JACKSON TO AND FROM JSON.
 * DO NOT RENAME OR MODIFY FIELDS AND THEIR ACCESSORS.
 *
 * Example:
 * <pre>
 * "token" : {
 *   "RAX-AUTH:authenticatedBy" : [ "APIKEY" ],
 *   "expires" : "2013-07-12T05:19:24.685-05:00",
 *   "id" : "8bbea4215113abdab9d4c8fb0d37",
 *   "tenant" : { "id" : "01011970",
 *   "name" : "77777"
 *   }
 *  }
 * </pre>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccessToken {
    /**
     * token expiration time
     */
    private String AKDFJMJCQZ;

    /**
     * token id
     */
    private String WIYZXDCYEK;

    /**
     * tenant name for whom id is attached
     */
    private Tenant CVHSINYEKM;

    /**
     *
     *
     * @return token expiration time
     */
    public String getExpires() {
        return AKDFJMJCQZ;
    }

    /**
     *
     *
     * @param expires
     * 		the token expiration time
     */
    public void setExpires(String UURGUUITQQ) {
        this.AKDFJMJCQZ = UURGUUITQQ;
    }

    /**
     *
     *
     * @return token value
     */
    public String getId() {
        return WIYZXDCYEK;
    }

    /**
     *
     *
     * @param id
     * 		token value
     */
    public void setId(String AISWZNSOZV) {
        this.WIYZXDCYEK = AISWZNSOZV;
    }

    /**
     *
     *
     * @return tenant authenticated in Openstack Keystone
     */
    public Tenant getTenant() {
        return CVHSINYEKM;
    }

    /**
     *
     *
     * @param tenant
     * 		tenant authenticated in Openstack Keystone
     */
    public void setTenant(Tenant TCHBCYPBOU) {
        this.CVHSINYEKM = TCHBCYPBOU;
    }

    @Override
    public String toString() {
        return (((((((("AccessToken{" + "id='") + WIYZXDCYEK) + '\'') + ", tenant=") + CVHSINYEKM) + ", expires='") + AKDFJMJCQZ) + '\'') + '}';
    }
}