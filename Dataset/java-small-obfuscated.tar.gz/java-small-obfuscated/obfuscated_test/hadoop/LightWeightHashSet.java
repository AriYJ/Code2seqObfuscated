/**
 * A low memory linked hash set implementation, which uses an array for storing
 * the elements and linked lists for collision resolution. This class does not
 * support null element.
 *
 * This class is not thread safe.
 */
public class LightWeightHashSet<T> implements Collection<T> {
    /**
     * Elements of {@link LightWeightLinkedSet}.
     */
    static class LinkedElement<T> {
        protected final T BRSXFRIORQ;

        // reference to the next entry within a bucket linked list
        protected LightWeightHashSet.LinkedElement<T> VGDIYFPRQJ;

        // hashCode of the element
        protected final int GIIXHODDBA;

        public LinkedElement(T elem, int hash) {
            this.element = elem;
            this.next = null;
            this.hashCode = hash;
        }

        @Override
        public String toString() {
            return BRSXFRIORQ.toString();
        }
    }

    protected static final float VEGUQKMIAA = 0.75F;

    protected static final float SJYLKEHMFT = 0.2F;

    protected static final int FUNZNRHGZT = 16;

    static final int MBKVCPFCGB = 1 << 30;

    private static final Log OSODHSGMMU = LogFactory.getLog(LightWeightHashSet.class);

    /**
     * An internal array of entries, which are the rows of the hash table. The
     * size must be a power of two.
     */
    protected LightWeightHashSet.LinkedElement<T>[] XEPSTBHQPS;

    /**
     * Size of the entry table.
     */
    private int TOOGNDMWYA;

    /**
     * The size of the set (not the entry array).
     */
    protected int RLUQWYAOXB = 0;

    /**
     * Hashmask used for determining the bucket index *
     */
    private int ZJIFYUPWKK;

    /**
     * Capacity at initialization time *
     */
    private final int PVRWRFDCSF;

    /**
     * Modification version for fail-fast.
     *
     * @see ConcurrentModificationException
     */
    protected int KPBYAGUHOQ = 0;

    private float OSFCMZTIPP;

    private float RSBAGGMXPG;

    private final int BHHJVZJOMS = 2;

    private int YNMITFWHBH;

    private int JBVOFZAHAU;

    /**
     *
     *
     * @param initCapacity
     * 		Recommended size of the internal array.
     * @param maxLoadFactor
     * 		used to determine when to expand the internal array
     * @param minLoadFactor
     * 		used to determine when to shrink the internal array
     */
    @SuppressWarnings("unchecked")
    public LightWeightHashSet(int EGPRMFUWHM, float GZLOSVRFXT, float BTWPBRYKJH) {
        if ((GZLOSVRFXT <= 0) || (GZLOSVRFXT > 1.0F))
            throw new IllegalArgumentException("Illegal maxload factor: " + GZLOSVRFXT);

        if ((BTWPBRYKJH <= 0) || (BTWPBRYKJH > GZLOSVRFXT))
            throw new IllegalArgumentException("Illegal minload factor: " + BTWPBRYKJH);

        this.initialCapacity = computeCapacity(EGPRMFUWHM);
        this.capacity = this.initialCapacity;
        this.hash_mask = TOOGNDMWYA - 1;
        this.maxLoadFactor = GZLOSVRFXT;
        this.expandThreshold = ((int) (TOOGNDMWYA * GZLOSVRFXT));
        this.minLoadFactor = BTWPBRYKJH;
        this.shrinkThreshold = ((int) (TOOGNDMWYA * BTWPBRYKJH));
        XEPSTBHQPS = new LightWeightHashSet.LinkedElement[TOOGNDMWYA];
        LightWeightHashSet.OSODHSGMMU.debug((((("initial capacity=" + PVRWRFDCSF) + ", max load factor= ") + GZLOSVRFXT) + ", min load factor= ") + BTWPBRYKJH);
    }

    public LightWeightHashSet() {
        this(LightWeightHashSet.FUNZNRHGZT, LightWeightHashSet.VEGUQKMIAA, LightWeightHashSet.SJYLKEHMFT);
    }

    public LightWeightHashSet(int PQWHZJIAYL) {
        this(PQWHZJIAYL, LightWeightHashSet.VEGUQKMIAA, LightWeightHashSet.SJYLKEHMFT);
    }

    /**
     * Check if the set is empty.
     *
     * @return true is set empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return RLUQWYAOXB == 0;
    }

    /**
     * Return the current capacity (for testing).
     */
    public int getCapacity() {
        return TOOGNDMWYA;
    }

    /**
     * Return the number of stored elements.
     */
    @Override
    public int size() {
        return RLUQWYAOXB;
    }

    /**
     * Get index in the internal table for a given hash.
     */
    protected int getIndex(int RJRIBHOMFO) {
        return RJRIBHOMFO & ZJIFYUPWKK;
    }

    /**
     * Check if the set contains given element
     *
     * @return true if element present, false otherwise.
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean contains(final Object KPDMTSTBVN) {
        return getElement(((T) (KPDMTSTBVN))) != null;
    }

    /**
     * Return the element in this set which is equal to
     * the given key, if such an element exists.
     * Otherwise returns null.
     */
    public T getElement(final T CTRHLJVCKB) {
        // validate key
        if (CTRHLJVCKB == null) {
            throw new IllegalArgumentException("Null element is not supported.");
        }
        // find element
        final int KEMEGYLKVH = CTRHLJVCKB.hashCode();
        final int WLEDXWDZBG = getIndex(KEMEGYLKVH);
        return getContainedElem(WLEDXWDZBG, CTRHLJVCKB, KEMEGYLKVH);
    }

    /**
     * Check if the set contains given element at given index. If it
     * does, return that element.
     *
     * @return the element, or null, if no element matches
     */
    protected T getContainedElem(int SYUAAZFYIZ, final T JJDVPWAXWE, int FMKZDDIJEL) {
        for (LightWeightHashSet.LinkedElement<T> WTJADVGOBC = XEPSTBHQPS[SYUAAZFYIZ]; WTJADVGOBC != null; WTJADVGOBC = WTJADVGOBC.next) {
            // element found
            if ((FMKZDDIJEL == WTJADVGOBC.hashCode) && WTJADVGOBC.element.equals(JJDVPWAXWE)) {
                return WTJADVGOBC.element;
            }
        }
        // element not found
        return null;
    }

    /**
     * All all elements in the collection. Expand if necessary.
     *
     * @param toAdd
     * 		- elements to add.
     * @return true if the set has changed, false otherwise
     */
    @Override
    public boolean addAll(Collection<? extends T> DRMRPCZGRU) {
        boolean MMOENTUPBS = false;
        for (T OAVLOPSAKG : DRMRPCZGRU) {
            MMOENTUPBS |= addElem(OAVLOPSAKG);
        }
        expandIfNecessary();
        return MMOENTUPBS;
    }

    /**
     * Add given element to the hash table. Expand table if necessary.
     *
     * @return true if the element was not present in the table, false otherwise
     */
    @Override
    public boolean add(final T USQDSDQYSH) {
        boolean PKCBABYGTP = addElem(USQDSDQYSH);
        expandIfNecessary();
        return PKCBABYGTP;
    }

    /**
     * Add given element to the hash table
     *
     * @return true if the element was not present in the table, false otherwise
     */
    protected boolean addElem(final T ABFDTFSFPN) {
        // validate element
        if (ABFDTFSFPN == null) {
            throw new IllegalArgumentException("Null element is not supported.");
        }
        // find hashCode & index
        final int EKLAWSBBPT = ABFDTFSFPN.hashCode();
        final int WSITKAAEXS = getIndex(EKLAWSBBPT);
        // return false if already present
        if (getContainedElem(WSITKAAEXS, ABFDTFSFPN, EKLAWSBBPT) != null) {
            return false;
        }
        KPBYAGUHOQ++;
        RLUQWYAOXB++;
        // update bucket linked list
        LightWeightHashSet.LinkedElement<T> CXDBUCQBUR = new LightWeightHashSet.LinkedElement<T>(ABFDTFSFPN, EKLAWSBBPT);
        CXDBUCQBUR.next = XEPSTBHQPS[WSITKAAEXS];
        XEPSTBHQPS[WSITKAAEXS] = CXDBUCQBUR;
        return true;
    }

    /**
     * Remove the element corresponding to the key.
     *
     * @return If such element exists, return true. Otherwise, return false.
     */
    @Override
    @SuppressWarnings("unchecked")
    public boolean remove(final Object EMXVJJNMKL) {
        // validate key
        if (EMXVJJNMKL == null) {
            throw new IllegalArgumentException("Null element is not supported.");
        }
        LightWeightHashSet.LinkedElement<T> RSUWBVYZQY = removeElem(((T) (EMXVJJNMKL)));
        shrinkIfNecessary();
        return RSUWBVYZQY == null ? false : true;
    }

    /**
     * Remove the element corresponding to the key, given key.hashCode() == index.
     *
     * @return If such element exists, return true. Otherwise, return false.
     */
    protected LightWeightHashSet.LinkedElement<T> removeElem(final T WVHPXGTSID) {
        LightWeightHashSet.LinkedElement<T> TRDLMUBADW = null;
        final int EHJWFBAMGJ = WVHPXGTSID.hashCode();
        final int INUKOVIDKI = getIndex(EHJWFBAMGJ);
        if (XEPSTBHQPS[INUKOVIDKI] == null) {
            return null;
        } else
            if ((EHJWFBAMGJ == XEPSTBHQPS[INUKOVIDKI].hashCode) && XEPSTBHQPS[INUKOVIDKI].element.equals(WVHPXGTSID)) {
                // remove the head of the bucket linked list
                KPBYAGUHOQ++;
                RLUQWYAOXB--;
                TRDLMUBADW = XEPSTBHQPS[INUKOVIDKI];
                XEPSTBHQPS[INUKOVIDKI] = TRDLMUBADW.next;
            } else {
                // head != null and key is not equal to head
                // search the element
                LightWeightHashSet.LinkedElement<T> VIWIWCMCYZ = XEPSTBHQPS[INUKOVIDKI];
                for (TRDLMUBADW = VIWIWCMCYZ.next; TRDLMUBADW != null;) {
                    if ((EHJWFBAMGJ == TRDLMUBADW.hashCode) && TRDLMUBADW.element.equals(WVHPXGTSID)) {
                        // found the element, remove it
                        KPBYAGUHOQ++;
                        RLUQWYAOXB--;
                        VIWIWCMCYZ.next = TRDLMUBADW.next;
                        TRDLMUBADW.next = null;
                        break;
                    } else {
                        VIWIWCMCYZ = TRDLMUBADW;
                        TRDLMUBADW = TRDLMUBADW.next;
                    }
                }
            }

        return TRDLMUBADW;
    }

    /**
     * Remove and return n elements from the hashtable.
     * The order in which entries are removed is unspecified, and
     * and may not correspond to the order in which they were inserted.
     *
     * @return first element
     */
    public List<T> pollN(int KHFTCUNZIN) {
        if (KHFTCUNZIN >= RLUQWYAOXB) {
            return pollAll();
        }
        List<T> VZDEDBALAX = new ArrayList<T>(KHFTCUNZIN);
        if (KHFTCUNZIN == 0) {
            return VZDEDBALAX;
        }
        boolean UREOGRAIDR = false;
        int UYYDPPUHDV = 0;
        while (!UREOGRAIDR) {
            LightWeightHashSet.LinkedElement<T> GUKWYMGESR = XEPSTBHQPS[UYYDPPUHDV];
            while (GUKWYMGESR != null) {
                VZDEDBALAX.add(GUKWYMGESR.element);
                GUKWYMGESR = GUKWYMGESR.next;
                XEPSTBHQPS[UYYDPPUHDV] = GUKWYMGESR;
                RLUQWYAOXB--;
                KPBYAGUHOQ++;
                if ((--KHFTCUNZIN) == 0) {
                    UREOGRAIDR = true;
                    break;
                }
            } 
            UYYDPPUHDV++;
        } 
        shrinkIfNecessary();
        return VZDEDBALAX;
    }

    /**
     * Remove all elements from the set and return them. Clear the entries.
     */
    public List<T> pollAll() {
        List<T> GDTHHUIODV = new ArrayList<T>(RLUQWYAOXB);
        for (int HPYBSTUDIS = 0; HPYBSTUDIS < entries.length; HPYBSTUDIS++) {
            LightWeightHashSet.LinkedElement<T> JNHWCWFPAL = XEPSTBHQPS[HPYBSTUDIS];
            while (JNHWCWFPAL != null) {
                GDTHHUIODV.add(JNHWCWFPAL.element);
                JNHWCWFPAL = JNHWCWFPAL.next;
            } 
        }
        this.clear();
        return GDTHHUIODV;
    }

    /**
     * Get array.length elements from the set, and put them into the array.
     */
    @SuppressWarnings("unchecked")
    public T[] pollToArray(T[] QOXNYQJKND) {
        int GSYAXCHYYX = 0;
        LightWeightHashSet.LinkedElement<T> IUHQPXIJSZ = null;
        if (QOXNYQJKND.length == 0) {
            return QOXNYQJKND;
        }
        if (QOXNYQJKND.length > RLUQWYAOXB) {
            QOXNYQJKND = ((T[]) (Array.newInstance(QOXNYQJKND.getClass().getComponentType(), RLUQWYAOXB)));
        }
        // do fast polling if the entire set needs to be fetched
        if (QOXNYQJKND.length == RLUQWYAOXB) {
            for (int WGIDHONLSR = 0; WGIDHONLSR < entries.length; WGIDHONLSR++) {
                IUHQPXIJSZ = XEPSTBHQPS[WGIDHONLSR];
                while (IUHQPXIJSZ != null) {
                    QOXNYQJKND[GSYAXCHYYX++] = IUHQPXIJSZ.element;
                    IUHQPXIJSZ = IUHQPXIJSZ.next;
                } 
            }
            this.clear();
            return QOXNYQJKND;
        }
        boolean YFTYXRAODJ = false;
        int XLYYDCGSVM = 0;
        while (!YFTYXRAODJ) {
            IUHQPXIJSZ = XEPSTBHQPS[XLYYDCGSVM];
            while (IUHQPXIJSZ != null) {
                QOXNYQJKND[GSYAXCHYYX++] = IUHQPXIJSZ.element;
                IUHQPXIJSZ = IUHQPXIJSZ.next;
                XEPSTBHQPS[XLYYDCGSVM] = IUHQPXIJSZ;
                RLUQWYAOXB--;
                KPBYAGUHOQ++;
                if (GSYAXCHYYX == QOXNYQJKND.length) {
                    YFTYXRAODJ = true;
                    break;
                }
            } 
            XLYYDCGSVM++;
        } 
        shrinkIfNecessary();
        return QOXNYQJKND;
    }

    /**
     * Compute capacity given initial capacity.
     *
     * @return final capacity, either MIN_CAPACITY, MAX_CAPACITY, or power of 2
    closest to the requested capacity.
     */
    private int computeCapacity(int WICZSMJKXT) {
        if (WICZSMJKXT < LightWeightHashSet.FUNZNRHGZT) {
            return LightWeightHashSet.FUNZNRHGZT;
        }
        if (WICZSMJKXT > LightWeightHashSet.MBKVCPFCGB) {
            return LightWeightHashSet.MBKVCPFCGB;
        }
        int IVVQZDZIAV = 1;
        while (IVVQZDZIAV < WICZSMJKXT) {
            IVVQZDZIAV <<= 1;
        } 
        return IVVQZDZIAV;
    }

    /**
     * Resize the internal table to given capacity.
     */
    @SuppressWarnings("unchecked")
    private void resize(int SREWEFPURF) {
        int LJBFDVMBFX = computeCapacity(SREWEFPURF);
        if (LJBFDVMBFX == this.capacity) {
            return;
        }
        this.capacity = LJBFDVMBFX;
        this.expandThreshold = ((int) (TOOGNDMWYA * OSFCMZTIPP));
        this.shrinkThreshold = ((int) (TOOGNDMWYA * RSBAGGMXPG));
        this.hash_mask = TOOGNDMWYA - 1;
        LightWeightHashSet.LinkedElement<T>[] NLHKKPGLEG = XEPSTBHQPS;
        XEPSTBHQPS = new LightWeightHashSet.LinkedElement[TOOGNDMWYA];
        for (int RWQMLNQOWC = 0; RWQMLNQOWC < NLHKKPGLEG.length; RWQMLNQOWC++) {
            LightWeightHashSet.LinkedElement<T> LGGVUJCPAL = NLHKKPGLEG[RWQMLNQOWC];
            while (LGGVUJCPAL != null) {
                LightWeightHashSet.LinkedElement<T> BJMYSODTZC = LGGVUJCPAL.next;
                int IFLDSSQCFS = getIndex(LGGVUJCPAL.hashCode);
                LGGVUJCPAL.next = XEPSTBHQPS[IFLDSSQCFS];
                XEPSTBHQPS[IFLDSSQCFS] = LGGVUJCPAL;
                LGGVUJCPAL = BJMYSODTZC;
            } 
        }
    }

    /**
     * Checks if we need to shrink, and shrinks if necessary.
     */
    protected void shrinkIfNecessary() {
        if ((RLUQWYAOXB < this.shrinkThreshold) && (TOOGNDMWYA > PVRWRFDCSF)) {
            resize(TOOGNDMWYA / BHHJVZJOMS);
        }
    }

    /**
     * Checks if we need to expand, and expands if necessary.
     */
    protected void expandIfNecessary() {
        if ((RLUQWYAOXB > this.expandThreshold) && (TOOGNDMWYA < LightWeightHashSet.MBKVCPFCGB)) {
            resize(TOOGNDMWYA * BHHJVZJOMS);
        }
    }

    @Override
    public Iterator<T> iterator() {
        return new LinkedSetIterator();
    }

    @Override
    public String toString() {
        final StringBuilder AZMZKSEXOI = new StringBuilder(getClass().getSimpleName());
        AZMZKSEXOI.append("(size=").append(RLUQWYAOXB).append(", modification=").append(KPBYAGUHOQ).append(", entries.length=").append(entries.length).append(")");
        return AZMZKSEXOI.toString();
    }

    /**
     * Print detailed information of this object.
     */
    public void printDetails(final PrintStream HTSLBOHWWG) {
        HTSLBOHWWG.print(this + ", entries = [");
        for (int QFFEJPTJWH = 0; QFFEJPTJWH < entries.length; QFFEJPTJWH++) {
            if (XEPSTBHQPS[QFFEJPTJWH] != null) {
                LightWeightHashSet.LinkedElement<T> FXHGCIRIIC = XEPSTBHQPS[QFFEJPTJWH];
                HTSLBOHWWG.print((("\n  " + QFFEJPTJWH) + ": ") + FXHGCIRIIC);
                for (FXHGCIRIIC = FXHGCIRIIC.next; FXHGCIRIIC != null; FXHGCIRIIC = FXHGCIRIIC.next) {
                    HTSLBOHWWG.print(" -> " + FXHGCIRIIC);
                }
            }
        }
        HTSLBOHWWG.println("\n]");
    }

    private class LinkedSetIterator implements Iterator<T> {
        /**
         * The starting modification for fail-fast.
         */
        private final int MHWAMCCGWJ = KPBYAGUHOQ;

        /**
         * The current index of the entry array.
         */
        private int WIIHODLEZF = -1;

        /**
         * The next element to return.
         */
        private LightWeightHashSet.LinkedElement<T> QONXUDCEOD = nextNonemptyEntry();

        private LightWeightHashSet.LinkedElement<T> nextNonemptyEntry() {
            for (WIIHODLEZF++; (WIIHODLEZF < entries.length) && (XEPSTBHQPS[WIIHODLEZF] == null); WIIHODLEZF++);
            return WIIHODLEZF < entries.length ? XEPSTBHQPS[WIIHODLEZF] : null;
        }

        @Override
        public boolean hasNext() {
            return QONXUDCEOD != null;
        }

        @Override
        public T next() {
            if (KPBYAGUHOQ != MHWAMCCGWJ) {
                throw new ConcurrentModificationException((("modification=" + KPBYAGUHOQ) + " != startModification = ") + MHWAMCCGWJ);
            }
            if (QONXUDCEOD == null) {
                throw new NoSuchElementException();
            }
            final T e = next.element;
            // find the next element
            final LightWeightHashSet.LinkedElement<T> n = next.next;
            QONXUDCEOD = (n != null) ? n : nextNonemptyEntry();
            return e;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Remove is not supported.");
        }
    }

    /**
     * Clear the set. Resize it to the original capacity.
     */
    @Override
    @SuppressWarnings("unchecked")
    public void clear() {
        this.capacity = this.initialCapacity;
        this.hash_mask = TOOGNDMWYA - 1;
        this.expandThreshold = ((int) (TOOGNDMWYA * OSFCMZTIPP));
        this.shrinkThreshold = ((int) (TOOGNDMWYA * RSBAGGMXPG));
        XEPSTBHQPS = new LightWeightHashSet.LinkedElement[TOOGNDMWYA];
        RLUQWYAOXB = 0;
        KPBYAGUHOQ++;
    }

    @Override
    public Object[] toArray() {
        Object[] HOWYGTIBNL = new Object[RLUQWYAOXB];
        return toArray(HOWYGTIBNL);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <U> U[] toArray(U[] NFPZDITXMO) {
        if (NFPZDITXMO == null) {
            throw new NullPointerException("Input array can not be null");
        }
        if (NFPZDITXMO.length < RLUQWYAOXB) {
            NFPZDITXMO = ((U[]) (Array.newInstance(NFPZDITXMO.getClass().getComponentType(), RLUQWYAOXB)));
        }
        int GDRAAJRDMA = 0;
        for (int WHUIKYBKJJ = 0; WHUIKYBKJJ < entries.length; WHUIKYBKJJ++) {
            LightWeightHashSet.LinkedElement<T> IZTAIPICPC = XEPSTBHQPS[WHUIKYBKJJ];
            while (IZTAIPICPC != null) {
                NFPZDITXMO[GDRAAJRDMA++] = ((U) (IZTAIPICPC.element));
                IZTAIPICPC = IZTAIPICPC.next;
            } 
        }
        return NFPZDITXMO;
    }

    @Override
    public boolean containsAll(Collection<?> AZBQJQZHWU) {
        Iterator<?> FQZKCRDSAP = AZBQJQZHWU.iterator();
        while (FQZKCRDSAP.hasNext()) {
            if (!contains(FQZKCRDSAP.next())) {
                return false;
            }
        } 
        return true;
    }

    @Override
    public boolean removeAll(Collection<?> OESEGZAWXM) {
        boolean WVUVBEFOFB = false;
        Iterator<?> GWQIWBUZXT = OESEGZAWXM.iterator();
        while (GWQIWBUZXT.hasNext()) {
            WVUVBEFOFB |= remove(GWQIWBUZXT.next());
        } 
        return WVUVBEFOFB;
    }

    @Override
    public boolean retainAll(Collection<?> IPHTPSCVYT) {
        throw new UnsupportedOperationException("retainAll is not supported.");
    }
}