/**
 * The FileContext class provides an interface for users of the Hadoop
 * file system. It exposes a number of file system operations, e.g. create,
 * open, list.
 *
 * <h2>Path Names</h2>
 *
 * The Hadoop file system supports a URI namespace and URI names. This enables
 * multiple types of file systems to be referenced using fully-qualified URIs.
 * Two common Hadoop file system implementations are
 * <ul>
 * <li>the local file system: file:///path
 * <li>the HDFS file system: hdfs://nnAddress:nnPort/path
 * </ul>
 *
 * The Hadoop file system also supports additional naming schemes besides URIs.
 * Hadoop has the concept of a <i>default file system</i>, which implies a
 * default URI scheme and authority. This enables <i>slash-relative names</i>
 * relative to the default FS, which are more convenient for users and
 * application writers. The default FS is typically set by the user's
 * environment, though it can also be manually specified.
 * <p>
 *
 * Hadoop also supports <i>working-directory-relative</i> names, which are paths
 * relative to the current working directory (similar to Unix). The working
 * directory can be in a different file system than the default FS.
 * <p>
 * Thus, Hadoop path names can be specified as one of the following:
 * <ul>
 * <li>a fully-qualified URI: scheme://authority/path (e.g.
 * hdfs://nnAddress:nnPort/foo/bar)
 * <li>a slash-relative name: path relative to the default file system (e.g.
 * /foo/bar)
 * <li>a working-directory-relative name: path relative to the working dir (e.g.
 * foo/bar)
 * </ul>
 *  Relative paths with scheme (scheme:foo/bar) are illegal.
 *
 * <h2>Role of FileContext and Configuration Defaults</h2>
 *
 * The FileContext is the analogue of per-process file-related state in Unix. It
 * contains two properties:
 *
 * <ul>
 * <li>the default file system (for resolving slash-relative names)
 * <li>the umask (for file permissions)
 * </ul>
 * In general, these properties are obtained from the default configuration file
 * in the user's environment (see {@link Configuration}).
 *
 * Further file system properties are specified on the server-side. File system
 * operations default to using these server-side defaults unless otherwise
 * specified.
 * <p>
 * The file system related server-side defaults are:
 *  <ul>
 *  <li> the home directory (default is "/user/userName")
 *  <li> the initial wd (only for local fs)
 *  <li> replication factor
 *  <li> block size
 *  <li> buffer size
 *  <li> encryptDataTransfer
 *  <li> checksum option. (checksumType and  bytesPerChecksum)
 *  </ul>
 *
 * <h2>Example Usage</h2>
 *
 * Example 1: use the default config read from the $HADOOP_CONFIG/core.xml.
 *   Unspecified values come from core-defaults.xml in the release jar.
 *  <ul>
 *  <li> myFContext = FileContext.getFileContext(); // uses the default config
 *                                                // which has your default FS
 *  <li>  myFContext.create(path, ...);
 *  <li>  myFContext.setWorkingDir(path);
 *  <li>  myFContext.open (path, ...);
 *  <li>...
 *  </ul>
 * Example 2: Get a FileContext with a specific URI as the default FS
 *  <ul>
 *  <li> myFContext = FileContext.getFileContext(URI);
 *  <li> myFContext.create(path, ...);
 *  <li>...
 * </ul>
 * Example 3: FileContext with local file system as the default
 *  <ul>
 *  <li> myFContext = FileContext.getLocalFSFileContext();
 *  <li> myFContext.create(path, ...);
 *  <li> ...
 *  </ul>
 * Example 4: Use a specific config, ignoring $HADOOP_CONFIG
 *  Generally you should not need use a config unless you are doing
 *   <ul>
 *   <li> configX = someConfigSomeOnePassedToYou;
 *   <li> myFContext = getFileContext(configX); // configX is not changed,
 *                                              // is passed down
 *   <li> myFContext.create(path, ...);
 *   <li>...
 *  </ul>
 */
/* Evolving for a release,to be changed to Stable */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public final class FileContext {
    public static final Log HZZZSOIUVX = LogFactory.getLog(FileContext.class);

    /**
     * Default permission for directory and symlink
     * In previous versions, this default permission was also used to
     * create files, so files created end up with ugo+x permission.
     * See HADOOP-9155 for detail.
     * Two new constants are added to solve this, please use
     * {@link FileContext#DIR_DEFAULT_PERM} for directory, and use
     * {@link FileContext#FILE_DEFAULT_PERM} for file.
     * This constant is kept for compatibility.
     */
    public static final FsPermission KRBTCZSZYK = FsPermission.getDefault();

    /**
     * Default permission for directory
     */
    public static final FsPermission HFBMMZXRVQ = FsPermission.getDirDefault();

    /**
     * Default permission for file
     */
    public static final FsPermission BDHLBMLJPP = FsPermission.getFileDefault();

    /**
     * Priority of the FileContext shutdown hook.
     */
    public static final int FGHJLOKPMH = 20;

    /**
     * List of files that should be deleted on JVM shutdown.
     */
    static final Map<FileContext, Set<Path>> WFIKBRJBMG = new IdentityHashMap<FileContext, Set<Path>>();

    /**
     * JVM shutdown hook thread.
     */
    static final FileContext.FileContextFinalizer XQDFXPXZSW = new FileContext.FileContextFinalizer();

    private static final PathFilter IVHDMKVXTZ = new PathFilter() {
        @Override
        public boolean accept(final Path file) {
            return true;
        }
    };

    /**
     * The FileContext is defined by.
     *  1) defaultFS (slash)
     *  2) wd
     *  3) umask
     */
    private final AbstractFileSystem YGLYUFPTDN;// default FS for this FileContext.


    private Path WKLIRGQOJC;// Fully qualified


    private FsPermission OQAEREPYJS;

    private final Configuration DLFFKWAYOE;

    private final UserGroupInformation BAFLMARENQ;

    final boolean VELHNNCHZR;

    private FileContext(final AbstractFileSystem HNFQGUAVMK, final FsPermission DSUPGUVPOQ, final Configuration WPLUKZEQLZ) {
        YGLYUFPTDN = HNFQGUAVMK;
        OQAEREPYJS = FsPermission.getUMask(WPLUKZEQLZ);
        DLFFKWAYOE = WPLUKZEQLZ;
        try {
            BAFLMARENQ = UserGroupInformation.getCurrentUser();
        } catch (IOException e) {
            FileContext.HZZZSOIUVX.error("Exception in getCurrentUser: ", e);
            throw new RuntimeException("Failed to get the current user " + "while creating a FileContext", e);
        }
        /* Init the wd.
        WorkingDir is implemented at the FileContext layer 
        NOT at the AbstractFileSystem layer. 
        If the DefaultFS, such as localFilesystem has a notion of
         builtin WD, we use that as the initial WD.
         Otherwise the WD is initialized to the home directory.
         */
        WKLIRGQOJC = YGLYUFPTDN.getInitialWorkingDirectory();
        if (WKLIRGQOJC == null) {
            WKLIRGQOJC = YGLYUFPTDN.getHomeDirectory();
        }
        VELHNNCHZR = DLFFKWAYOE.getBoolean(FS_CLIENT_RESOLVE_REMOTE_SYMLINKS_KEY, FS_CLIENT_RESOLVE_REMOTE_SYMLINKS_DEFAULT);
        PEZIGAWISH = new FileContext.Util();// for the inner class

    }

    /* Remove relative part - return "absolute":
    If input is relative path ("foo/bar") add wd: ie "/<workingDir>/foo/bar"
    A fully qualified uri ("hdfs://nn:p/foo/bar") or a slash-relative path
    ("/foo/bar") are returned unchanged.

    Applications that use FileContext should use #makeQualified() since
    they really want a fully qualified URI.
    Hence this method is not called makeAbsolute() and 
    has been deliberately declared private.
     */
    Path fixRelativePart(Path STWWRVVDEI) {
        if (STWWRVVDEI.isUriPathAbsolute()) {
            return STWWRVVDEI;
        } else {
            return new Path(WKLIRGQOJC, STWWRVVDEI);
        }
    }

    /**
     * Delete all the paths that were marked as delete-on-exit.
     */
    static void processDeleteOnExit() {
        synchronized(FileContext.WFIKBRJBMG) {
            Set<Map.Entry<FileContext, Set<Path>>> MVEFNGFJBY = FileContext.WFIKBRJBMG.entrySet();
            for (Map.Entry<FileContext, Set<Path>> MAGQVJFVIM : MVEFNGFJBY) {
                FileContext LJYGPEXDBE = MAGQVJFVIM.getKey();
                Set<Path> ITWSQHMHYU = MAGQVJFVIM.getValue();
                for (Path BKHEBGDENN : ITWSQHMHYU) {
                    try {
                        LJYGPEXDBE.delete(BKHEBGDENN, true);
                    } catch (IOException e) {
                        FileContext.HZZZSOIUVX.warn("Ignoring failure to deleteOnExit for path " + BKHEBGDENN);
                    }
                }
            }
            FileContext.WFIKBRJBMG.clear();
        }
    }

    /**
     * Get the file system of supplied path.
     *
     * @param absOrFqPath
     * 		- absolute or fully qualified path
     * @return the file system of the path
     * @throws UnsupportedFileSystemException
     * 		If the file system for
     * 		<code>absOrFqPath</code> is not supported.
     * @throws IOExcepton
     * 		If the file system for <code>absOrFqPath</code> could
     * 		not be instantiated.
     */
    protected AbstractFileSystem getFSofPath(final Path PLFWKFJDRD) throws IOException, UnsupportedFileSystemException {
        PLFWKFJDRD.checkNotSchemeWithRelative();
        PLFWKFJDRD.checkNotRelative();
        try {
            // Is it the default FS for this FileContext?
            YGLYUFPTDN.checkPath(PLFWKFJDRD);
            return YGLYUFPTDN;
        } catch (Exception e) {
            // it is different FileSystem
            return FileContext.getAbstractFileSystem(BAFLMARENQ, PLFWKFJDRD.toUri(), DLFFKWAYOE);
        }
    }

    private static AbstractFileSystem getAbstractFileSystem(UserGroupInformation QNTFKUWASP, final URI RUBIVTHVZN, final Configuration JDCLUJFKEZ) throws IOException, UnsupportedFileSystemException {
        try {
            return QNTFKUWASP.doAs(new PrivilegedExceptionAction<AbstractFileSystem>() {
                @Override
                public AbstractFileSystem run() throws UnsupportedFileSystemException {
                    return AbstractFileSystem.get(RUBIVTHVZN, JDCLUJFKEZ);
                }
            });
        } catch (InterruptedException ex) {
            FileContext.HZZZSOIUVX.error(ex);
            throw new IOException("Failed to get the AbstractFileSystem for path: " + RUBIVTHVZN, ex);
        }
    }

    /**
     * Protected Static Factory methods for getting a FileContexts
     * that take a AbstractFileSystem as input. To be used for testing.
     */
    /**
     * Create a FileContext with specified FS as default using the specified
     * config.
     *
     * @param defFS
     * 		
     * @param aConf
     * 		
     * @return new FileContext with specifed FS as default.
     */
    public static FileContext getFileContext(final AbstractFileSystem RKFKSRRAHZ, final Configuration KJNPJBMSHJ) {
        return new FileContext(RKFKSRRAHZ, FsPermission.getUMask(KJNPJBMSHJ), KJNPJBMSHJ);
    }

    /**
     * Create a FileContext for specified file system using the default config.
     *
     * @param defaultFS
     * 		
     * @return a FileContext with the specified AbstractFileSystem
    as the default FS.
     */
    protected static FileContext getFileContext(final AbstractFileSystem DYGMUCGOSE) {
        return FileContext.getFileContext(DYGMUCGOSE, new Configuration());
    }

    /**
     * Static Factory methods for getting a FileContext.
     * Note new file contexts are created for each call.
     * The only singleton is the local FS context using the default config.
     *
     * Methods that use the default config: the default config read from the
     * $HADOOP_CONFIG/core.xml,
     * Unspecified key-values for config are defaulted from core-defaults.xml
     * in the release jar.
     *
     * The keys relevant to the FileContext layer are extracted at time of
     * construction. Changes to the config after the call are ignore
     * by the FileContext layer.
     * The conf is passed to lower layers like AbstractFileSystem and HDFS which
     * pick up their own config variables.
     */
    /**
     * Create a FileContext using the default config read from the
     * $HADOOP_CONFIG/core.xml, Unspecified key-values for config are defaulted
     * from core-defaults.xml in the release jar.
     *
     * @throws UnsupportedFileSystemException
     * 		If the file system from the default
     * 		configuration is not supported
     */
    public static FileContext getFileContext() throws UnsupportedFileSystemException {
        return FileContext.getFileContext(new Configuration());
    }

    /**
     *
     *
     * @return a FileContext for the local file system using the default config.
     * @throws UnsupportedFileSystemException
     * 		If the file system for
     * 		{@link FsConstants#LOCAL_FS_URI} is not supported.
     */
    public static FileContext getLocalFSFileContext() throws UnsupportedFileSystemException {
        return FileContext.getFileContext(LOCAL_FS_URI);
    }

    /**
     * Create a FileContext for specified URI using the default config.
     *
     * @param defaultFsUri
     * 		
     * @return a FileContext with the specified URI as the default FS.
     * @throws UnsupportedFileSystemException
     * 		If the file system for
     * 		<code>defaultFsUri</code> is not supported
     */
    public static FileContext getFileContext(final URI ZAGAIADTAF) throws UnsupportedFileSystemException {
        return FileContext.getFileContext(ZAGAIADTAF, new Configuration());
    }

    /**
     * Create a FileContext for specified default URI using the specified config.
     *
     * @param defaultFsUri
     * 		
     * @param aConf
     * 		
     * @return new FileContext for specified uri
     * @throws UnsupportedFileSystemException
     * 		If the file system with specified is
     * 		not supported
     * @throws RuntimeException
     * 		If the file system specified is supported but
     * 		could not be instantiated, or if login fails.
     */
    public static FileContext getFileContext(final URI KGPVIZKKCR, final Configuration CJLRYFHKNC) throws UnsupportedFileSystemException {
        UserGroupInformation SWYXGPHKND = null;
        AbstractFileSystem BEFGFTUKOD = null;
        try {
            SWYXGPHKND = UserGroupInformation.getCurrentUser();
            BEFGFTUKOD = FileContext.getAbstractFileSystem(SWYXGPHKND, KGPVIZKKCR, CJLRYFHKNC);
        } catch (UnsupportedFileSystemException ex) {
            throw ex;
        } catch (IOException ex) {
            FileContext.HZZZSOIUVX.error(ex);
            throw new RuntimeException(ex);
        }
        return FileContext.getFileContext(BEFGFTUKOD, CJLRYFHKNC);
    }

    /**
     * Create a FileContext using the passed config. Generally it is better to use
     * {@link #getFileContext(URI, Configuration)} instead of this one.
     *
     * @param aConf
     * 		
     * @return new FileContext
     * @throws UnsupportedFileSystemException
     * 		If file system in the config
     * 		is not supported
     */
    public static FileContext getFileContext(final Configuration KDJTWFHJCL) throws UnsupportedFileSystemException {
        return FileContext.getFileContext(URI.create(KDJTWFHJCL.get(CommonConfigurationKeysPublic.FS_DEFAULT_NAME_KEY, CommonConfigurationKeysPublic.FS_DEFAULT_NAME_DEFAULT)), KDJTWFHJCL);
    }

    /**
     *
     *
     * @param aConf
     * 		- from which the FileContext is configured
     * @return a FileContext for the local file system using the specified config.
     * @throws UnsupportedFileSystemException
     * 		If default file system in the config
     * 		is not supported
     */
    public static FileContext getLocalFSFileContext(final Configuration MAWHSYUCDE) throws UnsupportedFileSystemException {
        return FileContext.getFileContext(LOCAL_FS_URI, MAWHSYUCDE);
    }

    /* This method is needed for tests. */
    /* return type will change to AFS once
    HADOOP-6223 is completed
     */
    @InterfaceAudience.Private
    @InterfaceStability.Unstable
    public AbstractFileSystem getDefaultFileSystem() {
        return YGLYUFPTDN;
    }

    /**
     * Set the working directory for wd-relative names (such a "foo/bar"). Working
     * directory feature is provided by simply prefixing relative names with the
     * working dir. Note this is different from Unix where the wd is actually set
     * to the inode. Hence setWorkingDir does not follow symlinks etc. This works
     * better in a distributed environment that has multiple independent roots.
     * {@link #getWorkingDirectory()} should return what setWorkingDir() set.
     *
     * @param newWDir
     * 		new working directory
     * @throws IOException
     * 		<br>
     * 		NewWdir can be one of:
     * 		<ul>
     * 		<li>relative path: "foo/bar";</li>
     * 		<li>absolute without scheme: "/foo/bar"</li>
     * 		<li>fully qualified with scheme: "xx://auth/foo/bar"</li>
     * 		</ul>
     * 		<br>
     * 		Illegal WDs:
     * 		<ul>
     * 		<li>relative with scheme: "xx:foo/bar"</li>
     * 		<li>non existent directory</li>
     * 		</ul>
     */
    public void setWorkingDirectory(final Path BGRFWTHDLD) throws IOException {
        BGRFWTHDLD.checkNotSchemeWithRelative();
        /* wd is stored as a fully qualified path. We check if the given 
        path is not relative first since resolve requires and returns 
        an absolute path.
         */
        final Path IABNSOAIXQ = new Path(WKLIRGQOJC, BGRFWTHDLD);
        FileStatus NTOCNRAOBX = getFileStatus(IABNSOAIXQ);
        if (NTOCNRAOBX.isFile()) {
            throw new FileNotFoundException("Cannot setWD to a file");
        }
        WKLIRGQOJC = IABNSOAIXQ;
    }

    /**
     * Gets the working directory for wd-relative names (such a "foo/bar").
     */
    public Path getWorkingDirectory() {
        return WKLIRGQOJC;
    }

    /**
     * Gets the ugi in the file-context
     *
     * @return UserGroupInformation
     */
    public UserGroupInformation getUgi() {
        return BAFLMARENQ;
    }

    /**
     * Return the current user's home directory in this file system.
     * The default implementation returns "/user/$USER/".
     *
     * @return the home directory
     */
    public Path getHomeDirectory() {
        return YGLYUFPTDN.getHomeDirectory();
    }

    /**
     *
     *
     * @return the umask of this FileContext
     */
    public FsPermission getUMask() {
        return OQAEREPYJS;
    }

    /**
     * Set umask to the supplied parameter.
     *
     * @param newUmask
     * 		the new umask
     */
    public void setUMask(final FsPermission JLSPIBFKZR) {
        OQAEREPYJS = JLSPIBFKZR;
    }

    /**
     * Resolve the path following any symlinks or mount points
     *
     * @param f
     * 		to be resolved
     * @return fully qualified resolved path
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws AccessControlException
     * 		if access denied
     * @throws IOException
     * 		If an IO Error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     * 		
     * 		RuntimeExceptions:
     * @throws InvalidPathException
     * 		If path <code>f</code> is not valid
     */
    public Path resolvePath(final Path XHNTVGHQOL) throws FileNotFoundException, IOException, UnresolvedLinkException, AccessControlException {
        return resolve(XHNTVGHQOL);
    }

    /**
     * Make the path fully qualified if it is isn't.
     * A Fully-qualified path has scheme and authority specified and an absolute
     * path.
     * Use the default file system and working dir in this FileContext to qualify.
     *
     * @param path
     * 		
     * @return qualified path
     */
    public Path makeQualified(final Path GVXVQRIYZW) {
        return GVXVQRIYZW.makeQualified(YGLYUFPTDN.getUri(), getWorkingDirectory());
    }

    /**
     * Create or overwrite file on indicated path and returns an output stream for
     * writing into the file.
     *
     * @param f
     * 		the file name to open
     * @param createFlag
     * 		gives the semantics of create; see {@link CreateFlag}
     * @param opts
     * 		file creation options; see {@link Options.CreateOpts}.
     * 		<ul>
     * 		<li>Progress - to report progress on the operation - default null
     * 		<li>Permission - umask is applied against permisssion: default is
     * 		FsPermissions:getDefault()
     * 		
     * 		<li>CreateParent - create missing parent path; default is to not
     * 		to create parents
     * 		<li>The defaults for the following are SS defaults of the file
     * 		server implementing the target path. Not all parameters make sense
     * 		for all kinds of file system - eg. localFS ignores Blocksize,
     * 		replication, checksum
     * 		<ul>
     * 		<li>BufferSize - buffersize used in FSDataOutputStream
     * 		<li>Blocksize - block size for file blocks
     * 		<li>ReplicationFactor - replication for blocks
     * 		<li>ChecksumParam - Checksum parameters. server default is used
     * 		if not specified.
     * 		</ul>
     * 		</ul>
     * @return {@link FSDataOutputStream} for created file
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileAlreadyExistsException
     * 		If file <code>f</code> already exists
     * @throws FileNotFoundException
     * 		If parent of <code>f</code> does not exist
     * 		and <code>createParent</code> is false
     * @throws ParentNotDirectoryException
     * 		If parent of <code>f</code> is not a
     * 		directory.
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     * 		
     * 		RuntimeExceptions:
     * @throws InvalidPathException
     * 		If path <code>f</code> is not valid
     */
    public FSDataOutputStream create(final Path JBDMSQYRGP, final EnumSet<CreateFlag> RQXDBSNOIN, Options... KWVGSHRKSS) throws FileNotFoundException, IOException, FileAlreadyExistsException, ParentNotDirectoryException, UnsupportedFileSystemException, AccessControlException {
        Path BLCSNMXEIH = fixRelativePart(JBDMSQYRGP);
        // If one of the options is a permission, extract it & apply umask
        // If not, add a default Perms and apply umask;
        // AbstractFileSystem#create
        CreateOpts.Perms CPKQATPVUH = CreateOpts.getOpt(Perms.class, KWVGSHRKSS);
        FsPermission UKXBPZWXQY = (CPKQATPVUH != null) ? CPKQATPVUH.getValue() : FileContext.BDHLBMLJPP;
        UKXBPZWXQY = UKXBPZWXQY.applyUMask(OQAEREPYJS);
        final CreateOpts[] GQMIOOGPLB = CreateOpts.setOpt(CreateOpts.perms(UKXBPZWXQY), KWVGSHRKSS);
        return new FSLinkResolver<FSDataOutputStream>() {
            @Override
            public FSDataOutputStream next(final AbstractFileSystem JOYHCLSQYF, final Path HRNZJRRTIC) throws IOException {
                return JOYHCLSQYF.create(HRNZJRRTIC, RQXDBSNOIN, GQMIOOGPLB);
            }
        }.resolve(this, BLCSNMXEIH);
    }

    /**
     * Make(create) a directory and all the non-existent parents.
     *
     * @param dir
     * 		- the dir to make
     * @param permission
     * 		- permissions is set permission&~umask
     * @param createParent
     * 		- if true then missing parent dirs are created if false
     * 		then parent must exist
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileAlreadyExistsException
     * 		If directory <code>dir</code> already
     * 		exists
     * @throws FileNotFoundException
     * 		If parent of <code>dir</code> does not exist
     * 		and <code>createParent</code> is false
     * @throws ParentNotDirectoryException
     * 		If parent of <code>dir</code> is not a
     * 		directory
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>dir</code>
     * 		is not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     * 		
     * 		RuntimeExceptions:
     * @throws InvalidPathException
     * 		If path <code>dir</code> is not valid
     */
    public void mkdir(final Path QWJVMWMNNY, final FsPermission OENVNNSFMG, final boolean ASIEDVBMFC) throws FileNotFoundException, IOException, FileAlreadyExistsException, ParentNotDirectoryException, UnsupportedFileSystemException, AccessControlException {
        final Path JZXRDOLWRP = fixRelativePart(QWJVMWMNNY);
        final FsPermission RAFTKTHASD = (OENVNNSFMG == null ? FsPermission.getDirDefault() : OENVNNSFMG).applyUMask(OQAEREPYJS);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem HTRZLFILEM, final Path EYFVCSURLT) throws IOException, UnresolvedLinkException {
                HTRZLFILEM.mkdir(EYFVCSURLT, RAFTKTHASD, ASIEDVBMFC);
                return null;
            }
        }.resolve(this, JZXRDOLWRP);
    }

    /**
     * Delete a file.
     *
     * @param f
     * 		the path to delete.
     * @param recursive
     * 		if path is a directory and set to
     * 		true, the directory is deleted else throws an exception. In
     * 		case of a file the recursive can be set to either true or false.
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     * 		
     * 		RuntimeExceptions:
     * @throws InvalidPathException
     * 		If path <code>f</code> is invalid
     */
    public boolean delete(final Path NFZWCIXXHO, final boolean JSQDHGAPSO) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        Path XCMRNNPIRT = fixRelativePart(NFZWCIXXHO);
        return new FSLinkResolver<Boolean>() {
            @Override
            public Boolean next(final AbstractFileSystem VNPEKXLFVS, final Path NQNPUZYEWS) throws IOException, UnresolvedLinkException {
                return Boolean.valueOf(VNPEKXLFVS.delete(NQNPUZYEWS, JSQDHGAPSO));
            }
        }.resolve(this, XCMRNNPIRT);
    }

    /**
     * Opens an FSDataInputStream at the indicated Path using
     * default buffersize.
     *
     * @param f
     * 		the file name to open
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If file <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code>
     * 		is not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public FSDataInputStream open(final Path JMOTGLECXZ) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path DAOGBEMUJS = fixRelativePart(JMOTGLECXZ);
        return new FSLinkResolver<FSDataInputStream>() {
            @Override
            public FSDataInputStream next(final AbstractFileSystem YJPSDUJNAA, final Path CJSFLLKJAO) throws IOException, UnresolvedLinkException {
                return YJPSDUJNAA.open(CJSFLLKJAO);
            }
        }.resolve(this, DAOGBEMUJS);
    }

    /**
     * Opens an FSDataInputStream at the indicated Path.
     *
     * @param f
     * 		the file name to open
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If file <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public FSDataInputStream open(final Path ELXFFOYONR, final int PDFTHLHUTH) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path HZCPMCFGQO = fixRelativePart(ELXFFOYONR);
        return new FSLinkResolver<FSDataInputStream>() {
            @Override
            public FSDataInputStream next(final AbstractFileSystem ATVVAASYBA, final Path MIVUGZQQMZ) throws IOException, UnresolvedLinkException {
                return ATVVAASYBA.open(MIVUGZQQMZ, PDFTHLHUTH);
            }
        }.resolve(this, HZCPMCFGQO);
    }

    /**
     * Set replication for an existing file.
     *
     * @param f
     * 		file name
     * @param replication
     * 		new replication
     * @return true if successful
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If file <code>f</code> does not exist
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public boolean setReplication(final Path ZTQELZHPAI, final short RVVCYSTVIC) throws FileNotFoundException, IOException, AccessControlException {
        final Path MINZLCXTJI = fixRelativePart(ZTQELZHPAI);
        return new FSLinkResolver<Boolean>() {
            @Override
            public Boolean next(final AbstractFileSystem RAXUPAUBPS, final Path VGCMPKFCUH) throws IOException, UnresolvedLinkException {
                return Boolean.valueOf(RAXUPAUBPS.setReplication(VGCMPKFCUH, RVVCYSTVIC));
            }
        }.resolve(this, MINZLCXTJI);
    }

    /**
     * Renames Path src to Path dst
     * <ul>
     * <li
     * <li>Fails if src is a file and dst is a directory.
     * <li>Fails if src is a directory and dst is a file.
     * <li>Fails if the parent of dst does not exist or is a file.
     * </ul>
     * <p>
     * If OVERWRITE option is not passed as an argument, rename fails if the dst
     * already exists.
     * <p>
     * If OVERWRITE option is passed as an argument, rename overwrites the dst if
     * it is a file or an empty directory. Rename fails if dst is a non-empty
     * directory.
     * <p>
     * Note that atomicity of rename is dependent on the file system
     * implementation. Please refer to the file system documentation for details
     * <p>
     *
     * @param src
     * 		path to be renamed
     * @param dst
     * 		new path after rename
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileAlreadyExistsException
     * 		If <code>dst</code> already exists and
     * 		<code>options</options> has {@link Options.Rename#OVERWRITE}
     * 		option false.
     * @throws FileNotFoundException
     * 		If <code>src</code> does not exist
     * @throws ParentNotDirectoryException
     * 		If parent of <code>dst</code> is not a
     * 		directory
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>src</code>
     * 		and <code>dst</code> is not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public void rename(final Path GOXTMSBJVZ, final Path RRZQZLKGSS, final Options... QCUTBURLSO) throws FileNotFoundException, IOException, FileAlreadyExistsException, ParentNotDirectoryException, UnsupportedFileSystemException, AccessControlException {
        final Path DZMUTHCEEV = fixRelativePart(GOXTMSBJVZ);
        final Path WJWPAIVQUU = fixRelativePart(RRZQZLKGSS);
        AbstractFileSystem PORNESKNZW = getFSofPath(DZMUTHCEEV);
        AbstractFileSystem GMWVBUIOZA = getFSofPath(WJWPAIVQUU);
        if (!PORNESKNZW.getUri().equals(GMWVBUIOZA.getUri())) {
            throw new IOException("Renames across AbstractFileSystems not supported");
        }
        try {
            PORNESKNZW.rename(DZMUTHCEEV, WJWPAIVQUU, QCUTBURLSO);
        } catch (UnresolvedLinkException e) {
            /* We do not know whether the source or the destination path
            was unresolved. Resolve the source path up until the final
            path component, then fully resolve the destination.
             */
            final Path LQLYZGSCGM = resolveIntermediate(DZMUTHCEEV);
            new FSLinkResolver<Void>() {
                @Override
                public Void next(final AbstractFileSystem FIYWRGMSVQ, final Path MDYRTEPFIG) throws IOException, UnresolvedLinkException {
                    FIYWRGMSVQ.rename(LQLYZGSCGM, MDYRTEPFIG, QCUTBURLSO);
                    return null;
                }
            }.resolve(this, WJWPAIVQUU);
        }
    }

    /**
     * Set permission of a path.
     *
     * @param f
     * 		
     * @param permission
     * 		- the new absolute permission (umask is not applied)
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code>
     * 		is not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public void setPermission(final Path LOGCTAVHXN, final FsPermission XAKYSZUOZW) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path TFWCLMVVDT = fixRelativePart(LOGCTAVHXN);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem UGCGHXXILZ, final Path SLPIJFUUCS) throws IOException, UnresolvedLinkException {
                UGCGHXXILZ.setPermission(SLPIJFUUCS, XAKYSZUOZW);
                return null;
            }
        }.resolve(this, TFWCLMVVDT);
    }

    /**
     * Set owner of a path (i.e. a file or a directory). The parameters username
     * and groupname cannot both be null.
     *
     * @param f
     * 		The path
     * @param username
     * 		If it is null, the original username remains unchanged.
     * @param groupname
     * 		If it is null, the original groupname remains unchanged.
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     * 		
     * 		RuntimeExceptions:
     * @throws HadoopIllegalArgumentException
     * 		If <code>username</code> or
     * 		<code>groupname</code> is invalid.
     */
    public void setOwner(final Path OMHVWLLZZS, final String YVWVNACGIS, final String BEBJFJPQYB) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        if ((YVWVNACGIS == null) && (BEBJFJPQYB == null)) {
            throw new HadoopIllegalArgumentException("username and groupname cannot both be null");
        }
        final Path LXQWAYCKKN = fixRelativePart(OMHVWLLZZS);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem LGOSTDHJLG, final Path GNXTKKCEYH) throws IOException, UnresolvedLinkException {
                LGOSTDHJLG.setOwner(GNXTKKCEYH, YVWVNACGIS, BEBJFJPQYB);
                return null;
            }
        }.resolve(this, LXQWAYCKKN);
    }

    /**
     * Set access time of a file.
     *
     * @param f
     * 		The path
     * @param mtime
     * 		Set the modification time of this file.
     * 		The number of milliseconds since epoch (Jan 1, 1970).
     * 		A value of -1 means that this call should not set modification time.
     * @param atime
     * 		Set the access time of this file.
     * 		The number of milliseconds since Jan 1, 1970.
     * 		A value of -1 means that this call should not set access time.
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public void setTimes(final Path HVSCSJAUBK, final long LODOCALNBC, final long ZLBWUGGFGC) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path YGCJKYXFLY = fixRelativePart(HVSCSJAUBK);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem DKBIMAKNBS, final Path MXXUJBONQP) throws IOException, UnresolvedLinkException {
                DKBIMAKNBS.setTimes(MXXUJBONQP, LODOCALNBC, ZLBWUGGFGC);
                return null;
            }
        }.resolve(this, YGCJKYXFLY);
    }

    /**
     * Get the checksum of a file.
     *
     * @param f
     * 		file path
     * @return The file checksum.  The default return value is null,
    which indicates that no checksum algorithm is implemented
    in the corresponding FileSystem.
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public FileChecksum getFileChecksum(final Path ICXDIUROJK) throws FileNotFoundException, IOException, AccessControlException {
        final Path FIMJTWWGFK = fixRelativePart(ICXDIUROJK);
        return new FSLinkResolver<FileChecksum>() {
            @Override
            public FileChecksum next(final AbstractFileSystem XURBGTJLGI, final Path GANFYNLMPM) throws IOException, UnresolvedLinkException {
                return XURBGTJLGI.getFileChecksum(GANFYNLMPM);
            }
        }.resolve(this, FIMJTWWGFK);
    }

    /**
     * Set the verify checksum flag for the  file system denoted by the path.
     * This is only applicable if the
     * corresponding FileSystem supports checksum. By default doesn't do anything.
     *
     * @param verifyChecksum
     * 		
     * @param f
     * 		set the verifyChecksum for the Filesystem containing this path
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public void setVerifyChecksum(final boolean RVBQBQPCVG, final Path UGBYBWKEPK) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path EDHBYXXPRB = resolve(fixRelativePart(UGBYBWKEPK));
        getFSofPath(EDHBYXXPRB).setVerifyChecksum(RVBQBQPCVG);
    }

    /**
     * Return a file status object that represents the path.
     *
     * @param f
     * 		The path we want information from
     * @return a FileStatus object
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public FileStatus getFileStatus(final Path GFRZZHMYDF) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path JXAFIYIFKH = fixRelativePart(GFRZZHMYDF);
        return new FSLinkResolver<FileStatus>() {
            @Override
            public FileStatus next(final AbstractFileSystem KQQNLNVQZO, final Path XVWRXAUPQB) throws IOException, UnresolvedLinkException {
                return KQQNLNVQZO.getFileStatus(XVWRXAUPQB);
            }
        }.resolve(this, JXAFIYIFKH);
    }

    /**
     * Checks if the user can access a path.  The mode specifies which access
     * checks to perform.  If the requested permissions are granted, then the
     * method returns normally.  If access is denied, then the method throws an
     * {@link AccessControlException}.
     * <p/>
     * The default implementation of this method calls {@link #getFileStatus(Path)}
     * and checks the returned permissions against the requested permissions.
     * Note that the getFileStatus call will be subject to authorization checks.
     * Typically, this requires search (execute) permissions on each directory in
     * the path's prefix, but this is implementation-defined.  Any file system
     * that provides a richer authorization model (such as ACLs) may override the
     * default implementation so that it checks against that model instead.
     * <p>
     * In general, applications should avoid using this method, due to the risk of
     * time-of-check/time-of-use race conditions.  The permissions on a file may
     * change immediately after the access call returns.  Most applications should
     * prefer running specific file system actions as the desired user represented
     * by a {@link UserGroupInformation}.
     *
     * @param path
     * 		Path to check
     * @param mode
     * 		type of access to check
     * @throws AccessControlException
     * 		if access is denied
     * @throws FileNotFoundException
     * 		if the path does not exist
     * @throws UnsupportedFileSystemException
     * 		if file system for <code>path</code>
     * 		is not supported
     * @throws IOException
     * 		see specific implementation
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    @InterfaceAudience.LimitedPrivate({ "HDFS", "Hive" })
    public void access(final Path HBEZKUSCXH, final FsAction HCFOFRSWJL) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path QUOGPDDXNP = fixRelativePart(HBEZKUSCXH);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(AbstractFileSystem CZPWWJLIJN, Path ZHAXOMIQYY) throws IOException, UnresolvedLinkException {
                CZPWWJLIJN.access(ZHAXOMIQYY, HCFOFRSWJL);
                return null;
            }
        }.resolve(this, QUOGPDDXNP);
    }

    /**
     * Return a file status object that represents the path. If the path
     * refers to a symlink then the FileStatus of the symlink is returned.
     * The behavior is equivalent to #getFileStatus() if the underlying
     * file system does not support symbolic links.
     *
     * @param f
     * 		The path we want information from.
     * @return A FileStatus object
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     */
    public FileStatus getFileLinkStatus(final Path JEBDZSKVQK) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path HCYSDGBOJV = fixRelativePart(JEBDZSKVQK);
        return new FSLinkResolver<FileStatus>() {
            @Override
            public FileStatus next(final AbstractFileSystem PUAELPMSLB, final Path QAHHYILZLS) throws IOException, UnresolvedLinkException {
                FileStatus TDCPPGUHEF = PUAELPMSLB.getFileLinkStatus(QAHHYILZLS);
                if (TDCPPGUHEF.isSymlink()) {
                    TDCPPGUHEF.setSymlink(FSLinkResolver.qualifySymlinkTarget(PUAELPMSLB.getUri(), QAHHYILZLS, TDCPPGUHEF.getSymlink()));
                }
                return TDCPPGUHEF;
            }
        }.resolve(this, HCYSDGBOJV);
    }

    /**
     * Returns the target of the given symbolic link as it was specified
     * when the link was created.  Links in the path leading up to the
     * final path component are resolved transparently.
     *
     * @param f
     * 		the path to return the target of
     * @return The un-interpreted target of the symbolic link.
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If path <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If the given path does not refer to a symlink
     * 		or an I/O error occurred
     */
    public Path getLinkTarget(final Path JRQUZWAVTT) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path YYYTFHOBZA = fixRelativePart(JRQUZWAVTT);
        return new FSLinkResolver<Path>() {
            @Override
            public Path next(final AbstractFileSystem AUKFLJKDAY, final Path JZVGXBNJRA) throws IOException, UnresolvedLinkException {
                FileStatus XCXFTOWNCM = AUKFLJKDAY.getFileLinkStatus(JZVGXBNJRA);
                return XCXFTOWNCM.getSymlink();
            }
        }.resolve(this, YYYTFHOBZA);
    }

    /**
     * Return blockLocation of the given file for the given offset and len.
     *  For a nonexistent file or regions, null will be returned.
     *
     * This call is most helpful with DFS, where it returns
     * hostnames of machines that contain the given file.
     *
     * @param f
     * 		- get blocklocations of this file
     * @param start
     * 		position (byte offset)
     * @param len
     * 		(in bytes)
     * @return block locations for given file at specified offset of len
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     * 		
     * 		RuntimeExceptions:
     * @throws InvalidPathException
     * 		If path <code>f</code> is invalid
     */
    @InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
    @InterfaceStability.Evolving
    public BlockLocation[] getFileBlockLocations(final Path HVQLYRORXT, final long VKBKHJXECR, final long LWBOGFJJEL) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path TJPNCAONRD = fixRelativePart(HVQLYRORXT);
        return new FSLinkResolver<BlockLocation[]>() {
            @Override
            public BlockLocation[] next(final AbstractFileSystem FAYZAEHCUM, final Path FJVCAUVEEL) throws IOException, UnresolvedLinkException {
                return FAYZAEHCUM.getFileBlockLocations(FJVCAUVEEL, VKBKHJXECR, LWBOGFJJEL);
            }
        }.resolve(this, TJPNCAONRD);
    }

    /**
     * Returns a status object describing the use and capacity of the
     * file system denoted by the Parh argument p.
     * If the file system has multiple partitions, the
     * use and capacity of the partition pointed to by the specified
     * path is reflected.
     *
     * @param f
     * 		Path for which status should be obtained. null means the
     * 		root partition of the default file system.
     * @return a FsStatus object
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public FsStatus getFsStatus(final Path HRMAKNWDOF) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        if (HRMAKNWDOF == null) {
            return YGLYUFPTDN.getFsStatus();
        }
        final Path RQIOCGLDCF = fixRelativePart(HRMAKNWDOF);
        return new FSLinkResolver<FsStatus>() {
            @Override
            public FsStatus next(final AbstractFileSystem JWWDPJAJGI, final Path UDNRXNUPUT) throws IOException, UnresolvedLinkException {
                return JWWDPJAJGI.getFsStatus(UDNRXNUPUT);
            }
        }.resolve(this, RQIOCGLDCF);
    }

    /**
     * Creates a symbolic link to an existing file. An exception is thrown if
     * the symlink exits, the user does not have permission to create symlink,
     * or the underlying file system does not support symlinks.
     *
     * Symlink permissions are ignored, access to a symlink is determined by
     * the permissions of the symlink target.
     *
     * Symlinks in paths leading up to the final path component are resolved
     * transparently. If the final path component refers to a symlink some
     * functions operate on the symlink itself, these are:
     * - delete(f) and deleteOnExit(f) - Deletes the symlink.
     * - rename(src, dst) - If src refers to a symlink, the symlink is
     *   renamed. If dst refers to a symlink, the symlink is over-written.
     * - getLinkTarget(f) - Returns the target of the symlink.
     * - getFileLinkStatus(f) - Returns a FileStatus object describing
     *   the symlink.
     * Some functions, create() and mkdir(), expect the final path component
     * does not exist. If they are given a path that refers to a symlink that
     * does exist they behave as if the path referred to an existing file or
     * directory. All other functions fully resolve, ie follow, the symlink.
     * These are: open, setReplication, setOwner, setTimes, setWorkingDirectory,
     * setPermission, getFileChecksum, setVerifyChecksum, getFileBlockLocations,
     * getFsStatus, getFileStatus, exists, and listStatus.
     *
     * Symlink targets are stored as given to createSymlink, assuming the
     * underlying file system is capable of storing a fully qualified URI.
     * Dangling symlinks are permitted. FileContext supports four types of
     * symlink targets, and resolves them as follows
     * <pre>
     * Given a path referring to a symlink of form:
     *
     *   <---X--->
     *   fs://host/A/B/link
     *   <-----Y----->
     *
     * In this path X is the scheme and authority that identify the file system,
     * and Y is the path leading up to the final path component "link". If Y is
     * a symlink  itself then let Y' be the target of Y and X' be the scheme and
     * authority of Y'. Symlink targets may:
     *
     * 1. Fully qualified URIs
     *
     * fs://hostX/A/B/file  Resolved according to the target file system.
     *
     * 2. Partially qualified URIs (eg scheme but no host)
     *
     * fs:///A/B/file  Resolved according to the target file system. Eg resolving
     *                 a symlink to hdfs:///A results in an exception because
     *                 HDFS URIs must be fully qualified, while a symlink to
     *                 file:///A will not since Hadoop's local file systems
     *                 require partially qualified URIs.
     *
     * 3. Relative paths
     *
     * path  Resolves to [Y'][path]. Eg if Y resolves to hdfs://host/A and path
     *       is "../B/file" then [Y'][path] is hdfs://host/B/file
     *
     * 4. Absolute paths
     *
     * path  Resolves to [X'][path]. Eg if Y resolves hdfs://host/A/B and path
     *       is "/file" then [X][path] is hdfs://host/file
     * </pre>
     *
     * @param target
     * 		the target of the symbolic link
     * @param link
     * 		the path to be created that points to target
     * @param createParent
     * 		if true then missing parent dirs are created if
     * 		false then parent must exist
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileAlreadyExistsException
     * 		If file <code>linkcode> already exists
     * @throws FileNotFoundException
     * 		If <code>target</code> does not exist
     * @throws ParentNotDirectoryException
     * 		If parent of <code>link</code> is not a
     * 		directory.
     * @throws UnsupportedFileSystemException
     * 		If file system for
     * 		<code>target</code> or <code>link</code> is not supported
     * @throws IOException
     * 		If an I/O error occurred
     */
    public void createSymlink(final Path UDZWCXFUWV, final Path GHFMYQFPZQ, final boolean TAUIXYNIAP) throws FileNotFoundException, IOException, FileAlreadyExistsException, ParentNotDirectoryException, UnsupportedFileSystemException, AccessControlException {
        final Path GZNLLFACCR = fixRelativePart(GHFMYQFPZQ);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem WXJTWOTPQE, final Path ZGZFWBJENJ) throws IOException, UnresolvedLinkException {
                WXJTWOTPQE.createSymlink(UDZWCXFUWV, ZGZFWBJENJ, TAUIXYNIAP);
                return null;
            }
        }.resolve(this, GZNLLFACCR);
    }

    /**
     * List the statuses of the files/directories in the given path if the path is
     * a directory.
     *
     * @param f
     * 		is the path
     * @return an iterator that traverses statuses of the files/directories
    in the given path
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public RemoteIterator<FileStatus> listStatus(final Path JUJIZURAOW) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path ORBKCSMWPW = fixRelativePart(JUJIZURAOW);
        return new FSLinkResolver<RemoteIterator<FileStatus>>() {
            @Override
            public RemoteIterator<FileStatus> next(final AbstractFileSystem NLIRAWBOTW, final Path CHMVTKLAIZ) throws IOException, UnresolvedLinkException {
                return NLIRAWBOTW.listStatusIterator(CHMVTKLAIZ);
            }
        }.resolve(this, ORBKCSMWPW);
    }

    /**
     *
     *
     * @return an iterator over the corrupt files under the given path
    (may contain duplicates if a file has more than one corrupt block)
     * @throws IOException
     * 		
     */
    public RemoteIterator<Path> listCorruptFileBlocks(Path DVWAWRDWLN) throws IOException {
        final Path EUXLJEOTQM = fixRelativePart(DVWAWRDWLN);
        return new FSLinkResolver<RemoteIterator<Path>>() {
            @Override
            public RemoteIterator<Path> next(final AbstractFileSystem AXCVTMGRFK, final Path RUUDTQPKSK) throws IOException, UnresolvedLinkException {
                return AXCVTMGRFK.listCorruptFileBlocks(RUUDTQPKSK);
            }
        }.resolve(this, EUXLJEOTQM);
    }

    /**
     * List the statuses of the files/directories in the given path if the path is
     * a directory.
     * Return the file's status and block locations If the path is a file.
     *
     * If a returned status is a file, it contains the file's block locations.
     *
     * @param f
     * 		is the path
     * @return an iterator that traverses statuses of the files/directories
    in the given path
    If any IO exception (for example the input directory gets deleted while
    listing is being executed), next() or hasNext() of the returned iterator
    may throw a RuntimeException with the io exception as the cause.
     * @throws AccessControlException
     * 		If access is denied
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public RemoteIterator<LocatedFileStatus> listLocatedStatus(final Path JKEHXXOEVA) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        final Path TYUJPCCORG = fixRelativePart(JKEHXXOEVA);
        return new FSLinkResolver<RemoteIterator<LocatedFileStatus>>() {
            @Override
            public RemoteIterator<LocatedFileStatus> next(final AbstractFileSystem LABYFQLFKA, final Path GVDGJXMDVO) throws IOException, UnresolvedLinkException {
                return LABYFQLFKA.listLocatedStatus(GVDGJXMDVO);
            }
        }.resolve(this, TYUJPCCORG);
    }

    /**
     * Mark a path to be deleted on JVM shutdown.
     *
     * @param f
     * 		the existing path to delete.
     * @return true if deleteOnExit is successful, otherwise false.
     * @throws AccessControlException
     * 		If access is denied
     * @throws UnsupportedFileSystemException
     * 		If file system for <code>f</code> is
     * 		not supported
     * @throws IOException
     * 		If an I/O error occurred
     * 		
     * 		Exceptions applicable to file systems accessed over RPC:
     * @throws RpcClientException
     * 		If an exception occurred in the RPC client
     * @throws RpcServerException
     * 		If an exception occurred in the RPC server
     * @throws UnexpectedServerException
     * 		If server implementation throws
     * 		undeclared exception to RPC server
     */
    public boolean deleteOnExit(Path WHFSHFUMXF) throws IOException, AccessControlException {
        if (!this.util().exists(WHFSHFUMXF)) {
            return false;
        }
        synchronized(FileContext.WFIKBRJBMG) {
            if (FileContext.WFIKBRJBMG.isEmpty()) {
                org.apache.hadoop.util.ShutdownHookManager.get().addShutdownHook(FileContext.XQDFXPXZSW, FileContext.FGHJLOKPMH);
            }
            Set<Path> JHKBFYXKXZ = FileContext.WFIKBRJBMG.get(this);
            if (JHKBFYXKXZ == null) {
                JHKBFYXKXZ = new TreeSet<Path>();
                FileContext.WFIKBRJBMG.put(this, JHKBFYXKXZ);
            }
            JHKBFYXKXZ.add(WHFSHFUMXF);
        }
        return true;
    }

    private final FileContext.Util PEZIGAWISH;

    public FileContext.Util util() {
        return PEZIGAWISH;
    }

    /**
     * Utility/library methods built over the basic FileContext methods.
     * Since this are library functions, the oprtation are not atomic
     * and some of them may partially complete if other threads are making
     * changes to the same part of the name space.
     */
    public class Util {
        /**
         * Does the file exist?
         * Note: Avoid using this method if you already have FileStatus in hand.
         * Instead reuse the FileStatus
         *
         * @param f
         * 		the  file or dir to be checked
         * @throws AccessControlException
         * 		If access is denied
         * @throws IOException
         * 		If an I/O error occurred
         * @throws UnsupportedFileSystemException
         * 		If file system for <code>f</code> is
         * 		not supported
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         */
        public boolean exists(final Path f) throws IOException, UnsupportedFileSystemException, AccessControlException {
            try {
                FileStatus fs = FileContext.this.getFileStatus(f);
                assert fs != null;
                return true;
            } catch (FileNotFoundException e) {
                return false;
            }
        }

        /**
         * Return the {@link ContentSummary} of path f.
         *
         * @param f
         * 		path
         * @return the {@link ContentSummary} of path f.
         * @throws AccessControlException
         * 		If access is denied
         * @throws FileNotFoundException
         * 		If <code>f</code> does not exist
         * @throws UnsupportedFileSystemException
         * 		If file system for
         * 		<code>f</code> is not supported
         * @throws IOException
         * 		If an I/O error occurred
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         */
        public ContentSummary getContentSummary(Path f) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
            FileStatus status = FileContext.this.getFileStatus(f);
            if (status.isFile()) {
                return new ContentSummary(status.getLen(), 1, 0);
            }
            long[] summary = new long[]{ 0, 0, 1 };
            RemoteIterator<FileStatus> statusIterator = FileContext.this.listStatus(f);
            while (statusIterator.hasNext()) {
                FileStatus s = statusIterator.next();
                ContentSummary c = (s.isDirectory()) ? getContentSummary(s.getPath()) : new ContentSummary(s.getLen(), 1, 0);
                summary[0] += c.getLength();
                summary[1] += c.getFileCount();
                summary[2] += c.getDirectoryCount();
            } 
            return new ContentSummary(summary[0], summary[1], summary[2]);
        }

        /**
         * See {@link #listStatus(Path[], PathFilter)}
         */
        public FileStatus[] listStatus(Path[] files) throws FileNotFoundException, IOException, AccessControlException {
            return listStatus(files, FileContext.IVHDMKVXTZ);
        }

        /**
         * Filter files/directories in the given path using the user-supplied path
         * filter.
         *
         * @param f
         * 		is the path name
         * @param filter
         * 		is the user-supplied path filter
         * @return an array of FileStatus objects for the files under the given path
        after applying the filter
         * @throws AccessControlException
         * 		If access is denied
         * @throws FileNotFoundException
         * 		If <code>f</code> does not exist
         * @throws UnsupportedFileSystemException
         * 		If file system for
         * 		<code>pathPattern</code> is not supported
         * @throws IOException
         * 		If an I/O error occurred
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         */
        public FileStatus[] listStatus(Path f, PathFilter filter) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
            ArrayList<FileStatus> results = new ArrayList<FileStatus>();
            listStatus(results, f, filter);
            return results.toArray(new FileStatus[results.size()]);
        }

        /**
         * Filter files/directories in the given list of paths using user-supplied
         * path filter.
         *
         * @param files
         * 		is a list of paths
         * @param filter
         * 		is the filter
         * @return a list of statuses for the files under the given paths after
        applying the filter
         * @throws AccessControlException
         * 		If access is denied
         * @throws FileNotFoundException
         * 		If a file in <code>files</code> does not
         * 		exist
         * @throws IOException
         * 		If an I/O error occurred
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         */
        public FileStatus[] listStatus(Path[] files, PathFilter filter) throws FileNotFoundException, IOException, AccessControlException {
            ArrayList<FileStatus> results = new ArrayList<FileStatus>();
            for (int i = 0; i < files.length; i++) {
                listStatus(results, files[i], filter);
            }
            return results.toArray(new FileStatus[results.size()]);
        }

        /* Filter files/directories in the given path using the user-supplied path
        filter. Results are added to the given array <code>results</code>.
         */
        private void listStatus(ArrayList<FileStatus> results, Path f, PathFilter filter) throws FileNotFoundException, IOException, AccessControlException {
            FileStatus[] listing = listStatus(f);
            if (listing != null) {
                for (int i = 0; i < listing.length; i++) {
                    if (filter.accept(listing[i].getPath())) {
                        results.add(listing[i]);
                    }
                }
            }
        }

        /**
         * List the statuses of the files/directories in the given path
         * if the path is a directory.
         *
         * @param f
         * 		is the path
         * @return an array that contains statuses of the files/directories
        in the given path
         * @throws AccessControlException
         * 		If access is denied
         * @throws FileNotFoundException
         * 		If <code>f</code> does not exist
         * @throws UnsupportedFileSystemException
         * 		If file system for <code>f</code> is
         * 		not supported
         * @throws IOException
         * 		If an I/O error occurred
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         */
        public FileStatus[] listStatus(final Path f) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
            final Path absF = fixRelativePart(f);
            return new FSLinkResolver<FileStatus[]>() {
                @Override
                public FileStatus[] next(final AbstractFileSystem fs, final Path p) throws IOException, UnresolvedLinkException {
                    return fs.listStatus(p);
                }
            }.resolve(FileContext.this, absF);
        }

        /**
         * List the statuses and block locations of the files in the given path.
         *
         * If the path is a directory,
         *   if recursive is false, returns files in the directory;
         *   if recursive is true, return files in the subtree rooted at the path.
         *   The subtree is traversed in the depth-first order.
         * If the path is a file, return the file's status and block locations.
         * Files across symbolic links are also returned.
         *
         * @param f
         * 		is the path
         * @param recursive
         * 		if the subdirectories need to be traversed recursively
         * @return an iterator that traverses statuses of the files
        If any IO exception (for example a sub-directory gets deleted while
        listing is being executed), next() or hasNext() of the returned iterator
        may throw a RuntimeException with the IO exception as the cause.
         * @throws AccessControlException
         * 		If access is denied
         * @throws FileNotFoundException
         * 		If <code>f</code> does not exist
         * @throws UnsupportedFileSystemException
         * 		If file system for <code>f</code>
         * 		is not supported
         * @throws IOException
         * 		If an I/O error occurred
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         */
        public RemoteIterator<LocatedFileStatus> listFiles(final Path f, final boolean recursive) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
            return new RemoteIterator<LocatedFileStatus>() {
                private Stack<RemoteIterator<LocatedFileStatus>> VWHPZHTSRY = new Stack<RemoteIterator<LocatedFileStatus>>();

                RemoteIterator<LocatedFileStatus> UHWRMNAQJM = listLocatedStatus(f);

                LocatedFileStatus EEAFWKLRXR;

                /**
                 * Returns <tt>true</tt> if the iterator has more files.
                 *
                 * @return <tt>true</tt> if the iterator has more files.
                 * @throws AccessControlException
                 * 		if not allowed to access next
                 * 		file's status or locations
                 * @throws FileNotFoundException
                 * 		if next file does not exist any more
                 * @throws UnsupportedFileSystemException
                 * 		if next file's
                 * 		fs is unsupported
                 * @throws IOException
                 * 		for all other IO errors
                 * 		for example, NameNode is not avaialbe or
                 * 		NameNode throws IOException due to an error
                 * 		while getting the status or block locations
                 */
                @Override
                public boolean hasNext() throws IOException {
                    while (EEAFWKLRXR == null) {
                        if (UHWRMNAQJM.hasNext()) {
                            handleFileStat(UHWRMNAQJM.next());
                        } else
                            if (!VWHPZHTSRY.empty()) {
                                UHWRMNAQJM = VWHPZHTSRY.pop();
                            } else {
                                return false;
                            }

                    } 
                    return true;
                }

                /**
                 * Process the input stat.
                 * If it is a file, return the file stat.
                 * If it is a directory, traverse the directory if recursive is true;
                 * ignore it if recursive is false.
                 * If it is a symlink, resolve the symlink first and then process it
                 * depending on if it is a file or directory.
                 *
                 * @param stat
                 * 		input status
                 * @throws AccessControlException
                 * 		if access is denied
                 * @throws FileNotFoundException
                 * 		if file is not found
                 * @throws UnsupportedFileSystemException
                 * 		if fs is not supported
                 * @throws IOException
                 * 		for all other IO errors
                 */
                private void handleFileStat(LocatedFileStatus stat) throws IOException {
                    if (stat.isFile()) {
                        // file
                        EEAFWKLRXR = stat;
                    } else
                        if (stat.isSymlink()) {
                            // symbolic link
                            // resolve symbolic link
                            FileStatus symstat = FileContext.this.getFileStatus(stat.getSymlink());
                            if (symstat.isFile() || (recursive && symstat.isDirectory())) {
                                VWHPZHTSRY.push(UHWRMNAQJM);
                                UHWRMNAQJM = listLocatedStatus(stat.getPath());
                            }
                        } else
                            if (recursive) {
                                // directory
                                VWHPZHTSRY.push(UHWRMNAQJM);
                                UHWRMNAQJM = listLocatedStatus(stat.getPath());
                            }


                }

                /**
                 * Returns the next file's status with its block locations
                 *
                 * @throws AccessControlException
                 * 		if not allowed to access next
                 * 		file's status or locations
                 * @throws FileNotFoundException
                 * 		if next file does not exist any more
                 * @throws UnsupportedFileSystemException
                 * 		if next file's
                 * 		fs is unsupported
                 * @throws IOException
                 * 		for all other IO errors
                 * 		for example, NameNode is not avaialbe or
                 * 		NameNode throws IOException due to an error
                 * 		while getting the status or block locations
                 */
                @Override
                public LocatedFileStatus next() throws IOException {
                    if (hasNext()) {
                        LocatedFileStatus result = EEAFWKLRXR;
                        EEAFWKLRXR = null;
                        return result;
                    }
                    throw new NoSuchElementException("No more entry in " + f);
                }
            };
        }

        /**
         * <p>Return all the files that match filePattern and are not checksum
         * files. Results are sorted by their names.
         *
         * <p>
         * A filename pattern is composed of <i>regular</i> characters and
         * <i>special pattern matching</i> characters, which are:
         *
         * <dl>
         *  <dd>
         *   <dl>
         *    <p>
         *    <dt> <tt> ? </tt>
         *    <dd> Matches any single character.
         *
         *    <p>
         *    <dt> <tt> * </tt>
         *    <dd> Matches zero or more characters.
         *
         *    <p>
         *    <dt> <tt> [<i>abc</i>] </tt>
         *    <dd> Matches a single character from character set
         *     <tt>{<i>a,b,c</i>}</tt>.
         *
         *    <p>
         *    <dt> <tt> [<i>a</i>-<i>b</i>] </tt>
         *    <dd> Matches a single character from the character range
         *     <tt>{<i>a...b</i>}</tt>. Note: character <tt><i>a</i></tt> must be
         *     lexicographically less than or equal to character <tt><i>b</i></tt>.
         *
         *    <p>
         *    <dt> <tt> [^<i>a</i>] </tt>
         *    <dd> Matches a single char that is not from character set or range
         *     <tt>{<i>a</i>}</tt>.  Note that the <tt>^</tt> character must occur
         *     immediately to the right of the opening bracket.
         *
         *    <p>
         *    <dt> <tt> \<i>c</i> </tt>
         *    <dd> Removes (escapes) any special meaning of character <i>c</i>.
         *
         *    <p>
         *    <dt> <tt> {ab,cd} </tt>
         *    <dd> Matches a string from the string set <tt>{<i>ab, cd</i>} </tt>
         *
         *    <p>
         *    <dt> <tt> {ab,c{de,fh}} </tt>
         *    <dd> Matches a string from string set <tt>{<i>ab, cde, cfh</i>}</tt>
         *
         *   </dl>
         *  </dd>
         * </dl>
         *
         * @param pathPattern
         * 		a regular expression specifying a pth pattern
         * @return an array of paths that match the path pattern
         * @throws AccessControlException
         * 		If access is denied
         * @throws UnsupportedFileSystemException
         * 		If file system for
         * 		<code>pathPattern</code> is not supported
         * @throws IOException
         * 		If an I/O error occurred
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         */
        public FileStatus[] globStatus(Path pathPattern) throws IOException, UnsupportedFileSystemException, AccessControlException {
            return new Globber(FileContext.this, pathPattern, FileContext.IVHDMKVXTZ).glob();
        }

        /**
         * Return an array of FileStatus objects whose path names match pathPattern
         * and is accepted by the user-supplied path filter. Results are sorted by
         * their path names.
         * Return null if pathPattern has no glob and the path does not exist.
         * Return an empty array if pathPattern has a glob and no path matches it.
         *
         * @param pathPattern
         * 		regular expression specifying the path pattern
         * @param filter
         * 		user-supplied path filter
         * @return an array of FileStatus objects
         * @throws AccessControlException
         * 		If access is denied
         * @throws UnsupportedFileSystemException
         * 		If file system for
         * 		<code>pathPattern</code> is not supported
         * @throws IOException
         * 		If an I/O error occurred
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         */
        public FileStatus[] globStatus(final Path pathPattern, final PathFilter filter) throws IOException, UnsupportedFileSystemException, AccessControlException {
            return new Globber(FileContext.this, pathPattern, filter).glob();
        }

        /**
         * Copy file from src to dest. See
         * {@link #copy(Path, Path, boolean, boolean)}
         */
        public boolean copy(final Path src, final Path dst) throws FileNotFoundException, IOException, FileAlreadyExistsException, ParentNotDirectoryException, UnsupportedFileSystemException, AccessControlException {
            return copy(src, dst, false, false);
        }

        /**
         * Copy from src to dst, optionally deleting src and overwriting dst.
         *
         * @param src
         * 		
         * @param dst
         * 		
         * @param deleteSource
         * 		- delete src if true
         * @param overwrite
         * 		overwrite dst if true; throw IOException if dst exists
         * 		and overwrite is false.
         * @return true if copy is successful
         * @throws AccessControlException
         * 		If access is denied
         * @throws FileAlreadyExistsException
         * 		If <code>dst</code> already exists
         * @throws FileNotFoundException
         * 		If <code>src</code> does not exist
         * @throws ParentNotDirectoryException
         * 		If parent of <code>dst</code> is not
         * 		a directory
         * @throws UnsupportedFileSystemException
         * 		If file system for
         * 		<code>src</code> or <code>dst</code> is not supported
         * @throws IOException
         * 		If an I/O error occurred
         * 		
         * 		Exceptions applicable to file systems accessed over RPC:
         * @throws RpcClientException
         * 		If an exception occurred in the RPC client
         * @throws RpcServerException
         * 		If an exception occurred in the RPC server
         * @throws UnexpectedServerException
         * 		If server implementation throws
         * 		undeclared exception to RPC server
         * 		
         * 		RuntimeExceptions:
         * @throws InvalidPathException
         * 		If path <code>dst</code> is invalid
         */
        public boolean copy(final Path src, final Path dst, boolean deleteSource, boolean overwrite) throws FileNotFoundException, IOException, FileAlreadyExistsException, ParentNotDirectoryException, UnsupportedFileSystemException, AccessControlException {
            src.checkNotSchemeWithRelative();
            dst.checkNotSchemeWithRelative();
            Path qSrc = makeQualified(src);
            Path qDst = makeQualified(dst);
            checkDest(qSrc.getName(), qDst, overwrite);
            FileStatus fs = FileContext.this.getFileStatus(qSrc);
            if (fs.isDirectory()) {
                FileContext.checkDependencies(qSrc, qDst);
                mkdir(qDst, FsPermission.getDirDefault(), true);
                FileStatus[] contents = listStatus(qSrc);
                for (FileStatus content : contents) {
                    copy(makeQualified(content.getPath()), makeQualified(new Path(qDst, content.getPath().getName())), deleteSource, overwrite);
                }
            } else {
                InputStream in = null;
                OutputStream out = null;
                try {
                    in = open(qSrc);
                    EnumSet<CreateFlag> createFlag = (overwrite) ? EnumSet.of(CREATE, OVERWRITE) : EnumSet.of(CREATE);
                    out = create(qDst, createFlag);
                    IOUtils.copyBytes(in, out, DLFFKWAYOE, true);
                } catch (IOException e) {
                    IOUtils.closeStream(out);
                    IOUtils.closeStream(in);
                    throw e;
                }
            }
            if (deleteSource) {
                return delete(qSrc, true);
            } else {
                return true;
            }
        }
    }

    /**
     * Check if copying srcName to dst would overwrite an existing
     * file or directory.
     *
     * @param srcName
     * 		File or directory to be copied.
     * @param dst
     * 		Destination to copy srcName to.
     * @param overwrite
     * 		Whether it's ok to overwrite an existing file.
     * @throws AccessControlException
     * 		If access is denied.
     * @throws IOException
     * 		If dst is an existing directory, or dst is an
     * 		existing file and the overwrite option is not passed.
     */
    private void checkDest(String HWYKOWROSB, Path JIQUUPFYLO, boolean MLAFARGYKW) throws IOException, AccessControlException {
        try {
            FileStatus UWWYSCWNCK = getFileStatus(JIQUUPFYLO);
            if (UWWYSCWNCK.isDirectory()) {
                if (null == HWYKOWROSB) {
                    throw new IOException(("Target " + JIQUUPFYLO) + " is a directory");
                }
                // Recurse to check if dst/srcName exists.
                checkDest(null, new Path(JIQUUPFYLO, HWYKOWROSB), MLAFARGYKW);
            } else
                if (!MLAFARGYKW) {
                    throw new IOException(("Target " + new Path(JIQUUPFYLO, HWYKOWROSB)) + " already exists");
                }

        } catch (FileNotFoundException e) {
            // dst does not exist - OK to copy.
        }
    }

    // 
    // If the destination is a subdirectory of the source, then
    // generate exception
    // 
    private static void checkDependencies(Path ZNXIULQMSY, Path IEHOPCOTSV) throws IOException {
        if (FileContext.isSameFS(ZNXIULQMSY, IEHOPCOTSV)) {
            String DTUIPDFXTQ = ZNXIULQMSY.toString() + Path.SEPARATOR;
            String MSMVUUJEVM = IEHOPCOTSV.toString() + Path.SEPARATOR;
            if (MSMVUUJEVM.startsWith(DTUIPDFXTQ)) {
                if (DTUIPDFXTQ.length() == MSMVUUJEVM.length()) {
                    throw new IOException(("Cannot copy " + ZNXIULQMSY) + " to itself.");
                } else {
                    throw new IOException((("Cannot copy " + ZNXIULQMSY) + " to its subdirectory ") + IEHOPCOTSV);
                }
            }
        }
    }

    /**
     * Are qualSrc and qualDst of the same file system?
     *
     * @param qualPath1
     * 		- fully qualified path
     * @param qualPath2
     * 		- fully qualified path
     * @return 
     */
    private static boolean isSameFS(Path LIXRLQRRBW, Path SLOBSTSCTJ) {
        URI DAFLFYBCEG = LIXRLQRRBW.toUri();
        URI AVJUYMPTWP = SLOBSTSCTJ.toUri();
        return DAFLFYBCEG.getScheme().equals(AVJUYMPTWP.getScheme()) && (!(((DAFLFYBCEG.getAuthority() != null) && (AVJUYMPTWP.getAuthority() != null)) && DAFLFYBCEG.getAuthority().equals(AVJUYMPTWP.getAuthority())));
    }

    /**
     * Deletes all the paths in deleteOnExit on JVM shutdown.
     */
    static class FileContextFinalizer implements Runnable {
        @Override
        public synchronized void run() {
            FileContext.processDeleteOnExit();
        }
    }

    /**
     * Resolves all symbolic links in the specified path.
     * Returns the new path object.
     */
    protected Path resolve(final Path BDHSSVOFJB) throws FileNotFoundException, IOException, UnresolvedLinkException, AccessControlException {
        return new FSLinkResolver<Path>() {
            @Override
            public Path next(final AbstractFileSystem XBHXWJWGMO, final Path OMWQHQYIXO) throws IOException, UnresolvedLinkException {
                return XBHXWJWGMO.resolvePath(OMWQHQYIXO);
            }
        }.resolve(this, BDHSSVOFJB);
    }

    /**
     * Resolves all symbolic links in the specified path leading up
     * to, but not including the final path component.
     *
     * @param f
     * 		path to resolve
     * @return the new path object.
     */
    protected Path resolveIntermediate(final Path ESZJALAZAE) throws IOException {
        return new FSLinkResolver<FileStatus>() {
            @Override
            public FileStatus next(final AbstractFileSystem DIVXMPHLXJ, final Path HIAUUGAOBD) throws IOException, UnresolvedLinkException {
                return DIVXMPHLXJ.getFileLinkStatus(HIAUUGAOBD);
            }
        }.resolve(this, ESZJALAZAE).getPath();
    }

    /**
     * Returns the list of AbstractFileSystems accessed in the path. The list may
     * contain more than one AbstractFileSystems objects in case of symlinks.
     *
     * @param f
     * 		Path which needs to be resolved
     * @return List of AbstractFileSystems accessed in the path
     * @throws IOException
     * 		
     */
    Set<AbstractFileSystem> resolveAbstractFileSystems(final Path NDTSCXMTDS) throws IOException {
        final Path CJNTZMRUQS = fixRelativePart(NDTSCXMTDS);
        final HashSet<AbstractFileSystem> YTPBBULZTH = new HashSet<AbstractFileSystem>();
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem EDWGCHMROI, final Path TKHKFPZKPK) throws IOException, UnresolvedLinkException {
                YTPBBULZTH.add(EDWGCHMROI);
                EDWGCHMROI.getFileStatus(TKHKFPZKPK);
                return null;
            }
        }.resolve(this, CJNTZMRUQS);
        return YTPBBULZTH;
    }

    /**
     * Get the statistics for a particular file system
     *
     * @param uri
     * 		the uri to lookup the statistics. Only scheme and authority part
     * 		of the uri are used as the key to store and lookup.
     * @return a statistics object
     */
    public static Statistics getStatistics(URI KCMJRXWEGH) {
        return AbstractFileSystem.getStatistics(KCMJRXWEGH);
    }

    /**
     * Clears all the statistics stored in AbstractFileSystem, for all the file
     * systems.
     */
    public static void clearStatistics() {
        AbstractFileSystem.clearStatistics();
    }

    /**
     * Prints the statistics to standard output. File System is identified by the
     * scheme and authority.
     */
    public static void printStatistics() {
        AbstractFileSystem.printStatistics();
    }

    /**
     *
     *
     * @return Map of uri and statistics for each filesystem instantiated. The uri
    consists of scheme and authority for the filesystem.
     */
    public static Map<URI, Statistics> getAllStatistics() {
        return AbstractFileSystem.getAllStatistics();
    }

    /**
     * Get delegation tokens for the file systems accessed for a given
     * path.
     *
     * @param p
     * 		Path for which delegations tokens are requested.
     * @param renewer
     * 		the account name that is allowed to renew the token.
     * @return List of delegation tokens.
     * @throws IOException
     * 		
     */
    @InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
    public List<Token<?>> getDelegationTokens(Path FANPPTAVCU, String LCNOSCEVSB) throws IOException {
        Set<AbstractFileSystem> MUBWXJSAHF = resolveAbstractFileSystems(FANPPTAVCU);
        List<Token<?>> KJMMDBPLFR = new ArrayList<Token<?>>();
        for (AbstractFileSystem EYLQOTQSUI : MUBWXJSAHF) {
            List<Token<?>> ULDYSVHTZI = EYLQOTQSUI.getDelegationTokens(LCNOSCEVSB);
            KJMMDBPLFR.addAll(ULDYSVHTZI);
        }
        return KJMMDBPLFR;
    }

    /**
     * Modifies ACL entries of files and directories.  This method can add new ACL
     * entries or modify the permissions on existing ACL entries.  All existing
     * ACL entries that are not specified in this call are retained without
     * changes.  (Modifications are merged into the current ACL.)
     *
     * @param path
     * 		Path to modify
     * @param aclSpec
     * 		List<AclEntry> describing modifications
     * @throws IOException
     * 		if an ACL could not be modified
     */
    public void modifyAclEntries(final Path KWEEQDFGAQ, final List<AclEntry> DUZVHYRVIP) throws IOException {
        Path ACDZRXQMNI = fixRelativePart(KWEEQDFGAQ);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem EVEJRTYIIR, final Path NBSATZPQNT) throws IOException {
                EVEJRTYIIR.modifyAclEntries(NBSATZPQNT, DUZVHYRVIP);
                return null;
            }
        }.resolve(this, ACDZRXQMNI);
    }

    /**
     * Removes ACL entries from files and directories.  Other ACL entries are
     * retained.
     *
     * @param path
     * 		Path to modify
     * @param aclSpec
     * 		List<AclEntry> describing entries to remove
     * @throws IOException
     * 		if an ACL could not be modified
     */
    public void removeAclEntries(final Path LUHQAXKBTO, final List<AclEntry> JJVJMOBXOO) throws IOException {
        Path BLDXPUAHKP = fixRelativePart(LUHQAXKBTO);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem YGYFVOAWET, final Path TSHEXNIUCM) throws IOException {
                YGYFVOAWET.removeAclEntries(TSHEXNIUCM, JJVJMOBXOO);
                return null;
            }
        }.resolve(this, BLDXPUAHKP);
    }

    /**
     * Removes all default ACL entries from files and directories.
     *
     * @param path
     * 		Path to modify
     * @throws IOException
     * 		if an ACL could not be modified
     */
    public void removeDefaultAcl(Path MADAWOHRRB) throws IOException {
        Path MCUMSHZHSP = fixRelativePart(MADAWOHRRB);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem YXAHBBQXFZ, final Path MYYJEOJNDT) throws IOException {
                YXAHBBQXFZ.removeDefaultAcl(MYYJEOJNDT);
                return null;
            }
        }.resolve(this, MCUMSHZHSP);
    }

    /**
     * Removes all but the base ACL entries of files and directories.  The entries
     * for user, group, and others are retained for compatibility with permission
     * bits.
     *
     * @param path
     * 		Path to modify
     * @throws IOException
     * 		if an ACL could not be removed
     */
    public void removeAcl(Path ADDDTQZWOC) throws IOException {
        Path YQFWIPECXB = fixRelativePart(ADDDTQZWOC);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem VACWYAWIIM, final Path AOIJHYFNUE) throws IOException {
                VACWYAWIIM.removeAcl(AOIJHYFNUE);
                return null;
            }
        }.resolve(this, YQFWIPECXB);
    }

    /**
     * Fully replaces ACL of files and directories, discarding all existing
     * entries.
     *
     * @param path
     * 		Path to modify
     * @param aclSpec
     * 		List<AclEntry> describing modifications, must include entries
     * 		for user, group, and others for compatibility with permission bits.
     * @throws IOException
     * 		if an ACL could not be modified
     */
    public void setAcl(Path ZVIMXAHKVO, final List<AclEntry> NAVXFRRMCS) throws IOException {
        Path UKNTWZQGWU = fixRelativePart(ZVIMXAHKVO);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem XWLDFRYUUO, final Path AYMDLYJARL) throws IOException {
                XWLDFRYUUO.setAcl(AYMDLYJARL, NAVXFRRMCS);
                return null;
            }
        }.resolve(this, UKNTWZQGWU);
    }

    /**
     * Gets the ACLs of files and directories.
     *
     * @param path
     * 		Path to get
     * @return RemoteIterator<AclStatus> which returns each AclStatus
     * @throws IOException
     * 		if an ACL could not be read
     */
    public AclStatus getAclStatus(Path ZSVEQIUQKW) throws IOException {
        Path LQBIGWKETR = fixRelativePart(ZSVEQIUQKW);
        return new FSLinkResolver<AclStatus>() {
            @Override
            public AclStatus next(final AbstractFileSystem LRCWVIFOTY, final Path LVALMCXLXT) throws IOException {
                return LRCWVIFOTY.getAclStatus(LVALMCXLXT);
            }
        }.resolve(this, LQBIGWKETR);
    }

    /**
     * Set an xattr of a file or directory.
     * The name must be prefixed with the namespace followed by ".". For example,
     * "user.attr".
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to modify
     * @param name
     * 		xattr name.
     * @param value
     * 		xattr value.
     * @throws IOException
     * 		
     */
    public void setXAttr(Path SQOPAUITEC, String LEESBQMBJW, byte[] LIOEJUKMNK) throws IOException {
        setXAttr(SQOPAUITEC, LEESBQMBJW, LIOEJUKMNK, EnumSet.of(XAttrSetFlag.CREATE, REPLACE));
    }

    /**
     * Set an xattr of a file or directory.
     * The name must be prefixed with the namespace followed by ".". For example,
     * "user.attr".
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to modify
     * @param name
     * 		xattr name.
     * @param value
     * 		xattr value.
     * @param flag
     * 		xattr set flag
     * @throws IOException
     * 		
     */
    public void setXAttr(Path STEXYRMJBU, final String PVAOEXSFYT, final byte[] XCQUEPVKMR, final EnumSet<XAttrSetFlag> BDGOZUGFIR) throws IOException {
        final Path NSVBKGMHCE = fixRelativePart(STEXYRMJBU);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem WCJIRTPDVJ, final Path FAKNKXUDRC) throws IOException {
                WCJIRTPDVJ.setXAttr(FAKNKXUDRC, PVAOEXSFYT, XCQUEPVKMR, BDGOZUGFIR);
                return null;
            }
        }.resolve(this, NSVBKGMHCE);
    }

    /**
     * Get an xattr for a file or directory.
     * The name must be prefixed with the namespace followed by ".". For example,
     * "user.attr".
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to get extended attribute
     * @param name
     * 		xattr name.
     * @return byte[] xattr value.
     * @throws IOException
     * 		
     */
    public byte[] getXAttr(Path PRDSJJEIEQ, final String FQDCFNPDWG) throws IOException {
        final Path MNYXQSGKQB = fixRelativePart(PRDSJJEIEQ);
        return new FSLinkResolver<byte[]>() {
            @Override
            public byte[] next(final AbstractFileSystem NRGNFFZAIB, final Path AHZTVZCQUZ) throws IOException {
                return NRGNFFZAIB.getXAttr(AHZTVZCQUZ, FQDCFNPDWG);
            }
        }.resolve(this, MNYXQSGKQB);
    }

    /**
     * Get all of the xattrs for a file or directory.
     * Only those xattrs for which the logged-in user has permissions to view
     * are returned.
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to get extended attributes
     * @return Map<String, byte[]> describing the XAttrs of the file or directory
     * @throws IOException
     * 		
     */
    public Map<String, byte[]> getXAttrs(Path LHDPCYYZER) throws IOException {
        final Path NEBJBJGUUE = fixRelativePart(LHDPCYYZER);
        return new FSLinkResolver<Map<String, byte[]>>() {
            @Override
            public Map<String, byte[]> next(final AbstractFileSystem AVPAFHZZLD, final Path VIBWILVOSZ) throws IOException {
                return AVPAFHZZLD.getXAttrs(VIBWILVOSZ);
            }
        }.resolve(this, NEBJBJGUUE);
    }

    /**
     * Get all of the xattrs for a file or directory.
     * Only those xattrs for which the logged-in user has permissions to view
     * are returned.
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to get extended attributes
     * @param names
     * 		XAttr names.
     * @return Map<String, byte[]> describing the XAttrs of the file or directory
     * @throws IOException
     * 		
     */
    public Map<String, byte[]> getXAttrs(Path DKKJWATQNC, final List<String> VFPMUIEHOZ) throws IOException {
        final Path NYFIQCELON = fixRelativePart(DKKJWATQNC);
        return new FSLinkResolver<Map<String, byte[]>>() {
            @Override
            public Map<String, byte[]> next(final AbstractFileSystem GUGXZEDACD, final Path FUQGDMXSUO) throws IOException {
                return GUGXZEDACD.getXAttrs(FUQGDMXSUO, VFPMUIEHOZ);
            }
        }.resolve(this, NYFIQCELON);
    }

    /**
     * Remove an xattr of a file or directory.
     * The name must be prefixed with the namespace followed by ".". For example,
     * "user.attr".
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to remove extended attribute
     * @param name
     * 		xattr name
     * @throws IOException
     * 		
     */
    public void removeXAttr(Path SZPXWMGCIF, final String CKWTTFBJSH) throws IOException {
        final Path YJYOFSGMUE = fixRelativePart(SZPXWMGCIF);
        new FSLinkResolver<Void>() {
            @Override
            public Void next(final AbstractFileSystem XQSMGJYJEU, final Path GUAQMSAIYB) throws IOException {
                XQSMGJYJEU.removeXAttr(GUAQMSAIYB, CKWTTFBJSH);
                return null;
            }
        }.resolve(this, YJYOFSGMUE);
    }

    /**
     * Get all of the xattr names for a file or directory.
     * Only those xattr names which the logged-in user has permissions to view
     * are returned.
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to get extended attributes
     * @return List<String> of the XAttr names of the file or directory
     * @throws IOException
     * 		
     */
    public List<String> listXAttrs(Path VHMPWYMYTJ) throws IOException {
        final Path SMYBDXOPUQ = fixRelativePart(VHMPWYMYTJ);
        return new FSLinkResolver<List<String>>() {
            @Override
            public List<String> next(final AbstractFileSystem UIRXTGZFCC, final Path JCBSXWAGIU) throws IOException {
                return UIRXTGZFCC.listXAttrs(JCBSXWAGIU);
            }
        }.resolve(this, SMYBDXOPUQ);
    }
}