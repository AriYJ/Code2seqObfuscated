/**
 * A simple memory key-value store to help mock the Windows Azure Storage
 * implementation for unit testing.
 */
public class InMemoryBlockBlobStore {
    private final HashMap<String, InMemoryBlockBlobStore.Entry> YSRFRJLSSN = new HashMap<String, InMemoryBlockBlobStore.Entry>();

    private HashMap<String, String> KVXODLFKEW;

    public synchronized Iterable<String> getKeys() {
        return new ArrayList<String>(YSRFRJLSSN.keySet());
    }

    public static class ListBlobEntry {
        private final String CGNEUJPYSH;

        private final HashMap<String, String> KDMFUGDCMD;

        private final int CDRDUJXZRP;

        ListBlobEntry(String key, HashMap<String, String> metadata, int contentLength) {
            this.CGNEUJPYSH = key;
            this.KDMFUGDCMD = metadata;
            this.CDRDUJXZRP = contentLength;
        }

        public String getKey() {
            return CGNEUJPYSH;
        }

        public HashMap<String, String> getMetadata() {
            return KDMFUGDCMD;
        }

        public int getContentLength() {
            return CDRDUJXZRP;
        }
    }

    /**
     * List all the blobs whose key starts with the given prefix.
     *
     * @param prefix
     * 		The prefix to check.
     * @param includeMetadata
     * 		If set, the metadata in the returned listing will be populated;
     * 		otherwise it'll be null.
     * @return The listing.
     */
    public synchronized Iterable<InMemoryBlockBlobStore.ListBlobEntry> listBlobs(String PIFUQFCFOO, boolean LWWIPDPBCX) {
        ArrayList<InMemoryBlockBlobStore.ListBlobEntry> STWMVJTBIO = new ArrayList<InMemoryBlockBlobStore.ListBlobEntry>();
        for (Map.Entry<String, InMemoryBlockBlobStore.Entry> ISBVVYUPHW : YSRFRJLSSN.entrySet()) {
            if (ISBVVYUPHW.getKey().startsWith(PIFUQFCFOO)) {
                STWMVJTBIO.add(new InMemoryBlockBlobStore.ListBlobEntry(ISBVVYUPHW.getKey(), LWWIPDPBCX ? new HashMap<String, String>(ISBVVYUPHW.getValue().IIAQSSJWWQ) : null, ISBVVYUPHW.getValue().LWMMHWRETZ.length));
            }
        }
        return STWMVJTBIO;
    }

    public synchronized byte[] getContent(String SOKVPRJEAT) {
        return YSRFRJLSSN.get(SOKVPRJEAT).LWMMHWRETZ;
    }

    @SuppressWarnings("unchecked")
    public synchronized void setContent(String ELILKVETUL, byte[] YCFMBHKBJH, HashMap<String, String> UKGWFAJEZL) {
        YSRFRJLSSN.put(ELILKVETUL, new InMemoryBlockBlobStore.Entry(YCFMBHKBJH, ((HashMap<String, String>) (UKGWFAJEZL.clone()))));
    }

    public OutputStream upload(final String NYLVQZIAXZ, final HashMap<String, String> EANVZCQJMP) {
        setContent(NYLVQZIAXZ, new byte[0], EANVZCQJMP);
        return new ByteArrayOutputStream() {
            @Override
            public void flush() throws IOException {
                super.flush();
                setContent(NYLVQZIAXZ, toByteArray(), EANVZCQJMP);
            }
        };
    }

    public synchronized void copy(String QXCTLEKEJE, String RVTJOAMFSJ) {
        YSRFRJLSSN.put(RVTJOAMFSJ, YSRFRJLSSN.get(QXCTLEKEJE));
    }

    public synchronized void delete(String ZETWQEGTXZ) {
        YSRFRJLSSN.remove(ZETWQEGTXZ);
    }

    public synchronized boolean exists(String CRZEYREOIH) {
        return YSRFRJLSSN.containsKey(CRZEYREOIH);
    }

    @SuppressWarnings("unchecked")
    public synchronized HashMap<String, String> getMetadata(String TFRUTNRQQR) {
        return ((HashMap<String, String>) (YSRFRJLSSN.get(TFRUTNRQQR).IIAQSSJWWQ.clone()));
    }

    public synchronized HashMap<String, String> getContainerMetadata() {
        return KVXODLFKEW;
    }

    public synchronized void setContainerMetadata(HashMap<String, String> BPGMMFKGDU) {
        KVXODLFKEW = BPGMMFKGDU;
    }

    private static class Entry {
        private byte[] LWMMHWRETZ;

        private HashMap<String, String> IIAQSSJWWQ;

        public Entry(byte[] content, HashMap<String, String> metadata) {
            this.LWMMHWRETZ = content;
            this.IIAQSSJWWQ = metadata;
        }
    }
}