public class ExternalIdentityReducer implements Reducer<WritableComparable, Writable, WritableComparable, Writable> {
    public void configure(JobConf PVOTLCXPKM) {
    }

    public void close() throws IOException {
    }

    public void reduce(WritableComparable ZIPTGCDCQQ, Iterator<Writable> AGMTHDBRJZ, OutputCollector<WritableComparable, Writable> EBCJLJQORM, Reporter QPPJFDISMJ) throws IOException {
        while (AGMTHDBRJZ.hasNext()) {
            EBCJLJQORM.collect(ZIPTGCDCQQ, AGMTHDBRJZ.next());
        } 
    }
}