@SuppressWarnings("rawtypes")
public class TestNodeStatusUpdater {
    // temp fix until metrics system can auto-detect itself running in unit test:
    static {
        DefaultMetricsSystem.setMiniClusterMode(true);
    }

    static final Log RULNNGBXHM = LogFactory.getLog(TestNodeStatusUpdater.class);

    static final File VAJREPZJQY = new File("target", TestNodeStatusUpdater.class.getName());

    static final File DCJDJYOBTO = new File(TestNodeStatusUpdater.VAJREPZJQY, "nm0");

    static final File BGEXVDWFDR = new File(TestNodeStatusUpdater.VAJREPZJQY, "tmpDir");

    static final File VDYVZKASTN = new File(TestNodeStatusUpdater.VAJREPZJQY, "remotelogs");

    static final File IENLATLWGM = new File(TestNodeStatusUpdater.VAJREPZJQY, "logs");

    private static final RecordFactory EWWMOUHBOU = RecordFactoryProvider.getRecordFactory(null);

    volatile int FHQZQVZNEY = 0;

    volatile Throwable UEOOAGNVYD = null;

    private final List<NodeId> SUPLMVWWNA = new ArrayList<NodeId>();

    private boolean MSCZSDVSRO = false;

    private Configuration BYOTYNLEJG;

    private NodeManager RLLEYMONMH;

    private AtomicBoolean IYBVZPPRDQ = new AtomicBoolean(false);

    @Before
    public void setUp() {
        TestNodeStatusUpdater.DCJDJYOBTO.mkdirs();
        TestNodeStatusUpdater.BGEXVDWFDR.mkdirs();
        TestNodeStatusUpdater.IENLATLWGM.mkdirs();
        TestNodeStatusUpdater.VDYVZKASTN.mkdirs();
        BYOTYNLEJG = createNMConfig();
    }

    @After
    public void tearDown() {
        this.SUPLMVWWNA.clear();
        FHQZQVZNEY = 0;
        ServiceOperations.stop(RLLEYMONMH);
        IYBVZPPRDQ.set(false);
        DefaultMetricsSystem.shutdown();
    }

    public static MasterKey createMasterKey() {
        MasterKey FFAJUFGMLC = new MasterKeyPBImpl();
        FFAJUFGMLC.setKeyId(123);
        FFAJUFGMLC.setBytes(ByteBuffer.wrap(new byte[]{ new Integer(123).byteValue() }));
        return FFAJUFGMLC;
    }

    private class MyResourceTracker implements ResourceTracker {
        private final Context JHDSSZFEID;

        public MyResourceTracker(Context context) {
            this.JHDSSZFEID = context;
        }

        @Override
        public RegisterNodeManagerResponse registerNodeManager(RegisterNodeManagerRequest request) throws IOException, YarnException {
            NodeId nodeId = request.getNodeId();
            Resource resource = request.getResource();
            TestNodeStatusUpdater.RULNNGBXHM.info("Registering " + nodeId.toString());
            // NOTE: this really should be checking against the config value
            InetSocketAddress expected = NetUtils.getConnectAddress(BYOTYNLEJG.getSocketAddr(NM_ADDRESS, null, -1));
            Assert.assertEquals(NetUtils.getHostPortString(expected), nodeId.toString());
            Assert.assertEquals(5 * 1024, resource.getMemory());
            SUPLMVWWNA.add(nodeId);
            RegisterNodeManagerResponse response = TestNodeStatusUpdater.EWWMOUHBOU.newRecordInstance(RegisterNodeManagerResponse.class);
            response.setContainerTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            response.setNMTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            return response;
        }

        private Map<ApplicationId, List<ContainerStatus>> getAppToContainerStatusMap(List<ContainerStatus> containers) {
            Map<ApplicationId, List<ContainerStatus>> map = new HashMap<ApplicationId, List<ContainerStatus>>();
            for (ContainerStatus cs : containers) {
                ApplicationId applicationId = cs.getContainerId().getApplicationAttemptId().getApplicationId();
                List<ContainerStatus> appContainers = map.get(applicationId);
                if (appContainers == null) {
                    appContainers = new ArrayList<ContainerStatus>();
                    map.put(applicationId, appContainers);
                }
                appContainers.add(cs);
            }
            return map;
        }

        @Override
        public NodeHeartbeatResponse nodeHeartbeat(NodeHeartbeatRequest request) throws IOException, YarnException {
            NodeStatus nodeStatus = request.getNodeStatus();
            TestNodeStatusUpdater.RULNNGBXHM.info("Got heartbeat number " + FHQZQVZNEY);
            NodeManagerMetrics mockMetrics = mock(NodeManagerMetrics.class);
            Dispatcher mockDispatcher = mock(Dispatcher.class);
            EventHandler mockEventHandler = mock(EventHandler.class);
            when(mockDispatcher.getEventHandler()).thenReturn(mockEventHandler);
            NMStateStoreService stateStore = new NMNullStateStoreService();
            nodeStatus.setResponseId(FHQZQVZNEY++);
            Map<ApplicationId, List<ContainerStatus>> appToContainers = getAppToContainerStatusMap(nodeStatus.getContainersStatuses());
            ApplicationId appId1 = ApplicationId.newInstance(0, 1);
            ApplicationId appId2 = ApplicationId.newInstance(0, 2);
            if (FHQZQVZNEY == 1) {
                Assert.assertEquals(0, nodeStatus.getContainersStatuses().size());
                // Give a container to the NM.
                ApplicationAttemptId appAttemptID = ApplicationAttemptId.newInstance(appId1, 0);
                ContainerId firstContainerID = ContainerId.newInstance(appAttemptID, FHQZQVZNEY);
                ContainerLaunchContext launchContext = TestNodeStatusUpdater.EWWMOUHBOU.newRecordInstance(ContainerLaunchContext.class);
                Resource resource = BuilderUtils.newResource(2, 1);
                long currentTime = System.currentTimeMillis();
                String user = "testUser";
                ContainerTokenIdentifier containerToken = BuilderUtils.newContainerTokenIdentifier(BuilderUtils.newContainerToken(firstContainerID, InetAddress.getByName("localhost").getCanonicalHostName(), 1234, user, resource, currentTime + 10000, 123, "password".getBytes(), currentTime));
                Container container = new ContainerImpl(BYOTYNLEJG, mockDispatcher, stateStore, launchContext, null, mockMetrics, containerToken);
                this.JHDSSZFEID.getContainers().put(firstContainerID, container);
            } else
                if (FHQZQVZNEY == 2) {
                    // Checks on the RM end
                    Assert.assertEquals("Number of applications should only be one!", 1, nodeStatus.getContainersStatuses().size());
                    Assert.assertEquals("Number of container for the app should be one!", 1, appToContainers.get(appId1).size());
                    // Checks on the NM end
                    ConcurrentMap<ContainerId, Container> activeContainers = this.JHDSSZFEID.getContainers();
                    Assert.assertEquals(1, activeContainers.size());
                    // Give another container to the NM.
                    ApplicationAttemptId appAttemptID = ApplicationAttemptId.newInstance(appId2, 0);
                    ContainerId secondContainerID = ContainerId.newInstance(appAttemptID, FHQZQVZNEY);
                    ContainerLaunchContext launchContext = TestNodeStatusUpdater.EWWMOUHBOU.newRecordInstance(ContainerLaunchContext.class);
                    long currentTime = System.currentTimeMillis();
                    String user = "testUser";
                    Resource resource = BuilderUtils.newResource(3, 1);
                    ContainerTokenIdentifier containerToken = BuilderUtils.newContainerTokenIdentifier(BuilderUtils.newContainerToken(secondContainerID, InetAddress.getByName("localhost").getCanonicalHostName(), 1234, user, resource, currentTime + 10000, 123, "password".getBytes(), currentTime));
                    Container container = new ContainerImpl(BYOTYNLEJG, mockDispatcher, stateStore, launchContext, null, mockMetrics, containerToken);
                    this.JHDSSZFEID.getContainers().put(secondContainerID, container);
                } else
                    if (FHQZQVZNEY == 3) {
                        // Checks on the RM end
                        Assert.assertEquals("Number of applications should have two!", 2, appToContainers.size());
                        Assert.assertEquals("Number of container for the app-1 should be only one!", 1, appToContainers.get(appId1).size());
                        Assert.assertEquals("Number of container for the app-2 should be only one!", 1, appToContainers.get(appId2).size());
                        // Checks on the NM end
                        ConcurrentMap<ContainerId, Container> activeContainers = this.JHDSSZFEID.getContainers();
                        Assert.assertEquals(2, activeContainers.size());
                    }


            NodeHeartbeatResponse nhResponse = YarnServerBuilderUtils.newNodeHeartbeatResponse(FHQZQVZNEY, null, null, null, null, null, 1000L);
            return nhResponse;
        }
    }

    private class MyNodeStatusUpdater extends NodeStatusUpdaterImpl {
        public ResourceTracker GKBDBLPECZ;

        private Context HYPFTACKZL;

        public MyNodeStatusUpdater(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker, NodeManagerMetrics metrics) {
            super(context, dispatcher, healthChecker, metrics);
            this.HYPFTACKZL = context;
            GKBDBLPECZ = new TestNodeStatusUpdater.MyResourceTracker(this.HYPFTACKZL);
        }

        @Override
        protected ResourceTracker getRMClient() {
            return GKBDBLPECZ;
        }

        @Override
        protected void stopRMProxy() {
            return;
        }
    }

    // Test NodeStatusUpdater sends the right container statuses each time it
    // heart beats.
    private class MyNodeStatusUpdater2 extends NodeStatusUpdaterImpl {
        public ResourceTracker ZWOGRXKPAJ;

        public MyNodeStatusUpdater2(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker, NodeManagerMetrics metrics) {
            super(context, dispatcher, healthChecker, metrics);
            ZWOGRXKPAJ = new TestNodeStatusUpdater.MyResourceTracker4(context);
        }

        @Override
        protected ResourceTracker getRMClient() {
            return ZWOGRXKPAJ;
        }

        @Override
        protected void stopRMProxy() {
            return;
        }
    }

    private class MyNodeStatusUpdater3 extends NodeStatusUpdaterImpl {
        public ResourceTracker JKADRPDBMZ;

        private Context MHBJZSLVXK;

        public MyNodeStatusUpdater3(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker, NodeManagerMetrics metrics) {
            super(context, dispatcher, healthChecker, metrics);
            this.MHBJZSLVXK = context;
            this.JKADRPDBMZ = new TestNodeStatusUpdater.MyResourceTracker3(this.MHBJZSLVXK);
        }

        @Override
        protected ResourceTracker getRMClient() {
            return JKADRPDBMZ;
        }

        @Override
        protected void stopRMProxy() {
            return;
        }

        @Override
        protected boolean isTokenKeepAliveEnabled(Configuration conf) {
            return true;
        }
    }

    private class MyNodeStatusUpdater4 extends NodeStatusUpdaterImpl {
        private final long XHTXBXABAR;

        private final boolean ARUFGEBNHL;

        public ResourceTracker FZPKALZOHZ;

        public MyNodeStatusUpdater4(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker, NodeManagerMetrics metrics, long rmStartIntervalMS, boolean rmNeverStart) {
            super(context, dispatcher, healthChecker, metrics);
            this.XHTXBXABAR = rmStartIntervalMS;
            this.ARUFGEBNHL = rmNeverStart;
        }

        @Override
        protected void serviceStart() throws Exception {
            // record the startup time
            super.serviceStart();
        }

        @Override
        protected ResourceTracker getRMClient() throws IOException {
            RetryPolicy retryPolicy = RMProxy.createRetryPolicy(BYOTYNLEJG);
            FZPKALZOHZ = ((ResourceTracker) (RetryProxy.create(ResourceTracker.class, new TestNodeStatusUpdater.MyResourceTracker6(XHTXBXABAR, ARUFGEBNHL), retryPolicy)));
            return FZPKALZOHZ;
        }

        private boolean isTriggered() {
            return MSCZSDVSRO;
        }

        @Override
        protected void stopRMProxy() {
            return;
        }
    }

    private class MyNodeStatusUpdater5 extends NodeStatusUpdaterImpl {
        private ResourceTracker HPRPMQQDST;

        private Configuration VKDNMEJLUJ;

        public MyNodeStatusUpdater5(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker, NodeManagerMetrics metrics, Configuration conf) {
            super(context, dispatcher, healthChecker, metrics);
            HPRPMQQDST = new TestNodeStatusUpdater.MyResourceTracker5();
            this.VKDNMEJLUJ = conf;
        }

        @Override
        protected ResourceTracker getRMClient() {
            RetryPolicy retryPolicy = RMProxy.createRetryPolicy(VKDNMEJLUJ);
            return ((ResourceTracker) (RetryProxy.create(ResourceTracker.class, HPRPMQQDST, retryPolicy)));
        }

        @Override
        protected void stopRMProxy() {
            return;
        }
    }

    private class MyNodeManager extends NodeManager {
        private TestNodeStatusUpdater.MyNodeStatusUpdater3 XQENQUEVHH;

        @Override
        protected NodeStatusUpdater createNodeStatusUpdater(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker) {
            this.XQENQUEVHH = new TestNodeStatusUpdater.MyNodeStatusUpdater3(context, dispatcher, healthChecker, metrics);
            return this.XQENQUEVHH;
        }

        public TestNodeStatusUpdater.MyNodeStatusUpdater3 getNodeStatusUpdater() {
            return this.XQENQUEVHH;
        }
    }

    private class MyNodeManager2 extends NodeManager {
        public boolean DZHOXXPHZZ = false;

        private NodeStatusUpdater NLOUYJSFUY;

        private CyclicBarrier RHAYLCPCEC;

        private Configuration IBFDBLAZDW;

        public MyNodeManager2(CyclicBarrier syncBarrier, Configuration conf) {
            this.RHAYLCPCEC = syncBarrier;
            this.IBFDBLAZDW = conf;
        }

        @Override
        protected NodeStatusUpdater createNodeStatusUpdater(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker) {
            NLOUYJSFUY = new TestNodeStatusUpdater.MyNodeStatusUpdater5(context, dispatcher, healthChecker, metrics, IBFDBLAZDW);
            return NLOUYJSFUY;
        }

        @Override
        protected void serviceStop() throws Exception {
            System.out.println("Called stooppppp");
            super.serviceStop();
            DZHOXXPHZZ = true;
            ConcurrentMap<ApplicationId, Application> applications = getNMContext().getApplications();
            // ensure that applications are empty
            if (!applications.isEmpty()) {
                IYBVZPPRDQ.set(true);
            }
            RHAYLCPCEC.await(10000, TimeUnit.MILLISECONDS);
        }
    }

    // 
    private class MyResourceTracker2 implements ResourceTracker {
        public NodeAction WPZGJRKYQN = NodeAction.NORMAL;

        public NodeAction PPHGVZAKQE = NodeAction.NORMAL;

        public String LRZEWTUWRB = "";

        public String GUMRXFAATD = "3.0.1";

        @Override
        public RegisterNodeManagerResponse registerNodeManager(RegisterNodeManagerRequest request) throws IOException, YarnException {
            RegisterNodeManagerResponse response = TestNodeStatusUpdater.EWWMOUHBOU.newRecordInstance(RegisterNodeManagerResponse.class);
            response.setNodeAction(PPHGVZAKQE);
            response.setContainerTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            response.setNMTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            response.setDiagnosticsMessage(LRZEWTUWRB);
            response.setRMVersion(GUMRXFAATD);
            return response;
        }

        @Override
        public NodeHeartbeatResponse nodeHeartbeat(NodeHeartbeatRequest request) throws IOException, YarnException {
            NodeStatus nodeStatus = request.getNodeStatus();
            nodeStatus.setResponseId(FHQZQVZNEY++);
            NodeHeartbeatResponse nhResponse = YarnServerBuilderUtils.newNodeHeartbeatResponse(FHQZQVZNEY, WPZGJRKYQN, null, null, null, null, 1000L);
            nhResponse.setDiagnosticsMessage(LRZEWTUWRB);
            return nhResponse;
        }
    }

    private class MyResourceTracker3 implements ResourceTracker {
        public NodeAction ORXINMNIXY = NodeAction.NORMAL;

        public NodeAction UYOKKXDVPP = NodeAction.NORMAL;

        private Map<ApplicationId, List<Long>> MFUKZLVRNN = new HashMap<ApplicationId, List<Long>>();

        private ApplicationId PFWXFONUNN = BuilderUtils.newApplicationId(1, 1);

        private final Context UPELHBPZHX;

        MyResourceTracker3(Context context) {
            this.UPELHBPZHX = context;
        }

        @Override
        public RegisterNodeManagerResponse registerNodeManager(RegisterNodeManagerRequest request) throws IOException, YarnException {
            RegisterNodeManagerResponse response = TestNodeStatusUpdater.EWWMOUHBOU.newRecordInstance(RegisterNodeManagerResponse.class);
            response.setNodeAction(UYOKKXDVPP);
            response.setContainerTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            response.setNMTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            return response;
        }

        @Override
        public NodeHeartbeatResponse nodeHeartbeat(NodeHeartbeatRequest request) throws IOException, YarnException {
            TestNodeStatusUpdater.RULNNGBXHM.info(("Got heartBeatId: [" + FHQZQVZNEY) + "]");
            NodeStatus nodeStatus = request.getNodeStatus();
            nodeStatus.setResponseId(FHQZQVZNEY++);
            NodeHeartbeatResponse nhResponse = YarnServerBuilderUtils.newNodeHeartbeatResponse(FHQZQVZNEY, ORXINMNIXY, null, null, null, null, 1000L);
            if ((nodeStatus.getKeepAliveApplications() != null) && (nodeStatus.getKeepAliveApplications().size() > 0)) {
                for (ApplicationId appId : nodeStatus.getKeepAliveApplications()) {
                    List<Long> list = MFUKZLVRNN.get(appId);
                    if (list == null) {
                        list = new LinkedList<Long>();
                        MFUKZLVRNN.put(appId, list);
                    }
                    list.add(System.currentTimeMillis());
                }
            }
            if (FHQZQVZNEY == 2) {
                TestNodeStatusUpdater.RULNNGBXHM.info(("Sending FINISH_APP for application: [" + PFWXFONUNN) + "]");
                this.UPELHBPZHX.getApplications().put(PFWXFONUNN, mock(Application.class));
                nhResponse.addAllApplicationsToCleanup(Collections.singletonList(PFWXFONUNN));
            }
            return nhResponse;
        }
    }

    // Test NodeStatusUpdater sends the right container statuses each time it
    // heart beats.
    private class MyResourceTracker4 implements ResourceTracker {
        public NodeAction QLCPPSVHRI = NodeAction.NORMAL;

        public NodeAction TKRLHRPAKX = NodeAction.NORMAL;

        private Context VKBZPSZRCB;

        public MyResourceTracker4(Context context) {
            this.VKBZPSZRCB = context;
        }

        @Override
        public RegisterNodeManagerResponse registerNodeManager(RegisterNodeManagerRequest request) throws IOException, YarnException {
            RegisterNodeManagerResponse response = TestNodeStatusUpdater.EWWMOUHBOU.newRecordInstance(RegisterNodeManagerResponse.class);
            response.setNodeAction(QLCPPSVHRI);
            response.setContainerTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            response.setNMTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            return response;
        }

        @Override
        public NodeHeartbeatResponse nodeHeartbeat(NodeHeartbeatRequest request) throws IOException, YarnException {
            try {
                if (FHQZQVZNEY == 0) {
                    Assert.assertEquals(request.getNodeStatus().getContainersStatuses().size(), 0);
                    Assert.assertEquals(VKBZPSZRCB.getContainers().size(), 0);
                } else
                    if (FHQZQVZNEY == 1) {
                        List<ContainerStatus> statuses = request.getNodeStatus().getContainersStatuses();
                        Assert.assertEquals(statuses.size(), 2);
                        Assert.assertEquals(VKBZPSZRCB.getContainers().size(), 2);
                        ContainerStatus containerStatus2 = TestNodeStatusUpdater.createContainerStatus(2, RUNNING);
                        ContainerStatus containerStatus3 = TestNodeStatusUpdater.createContainerStatus(3, COMPLETE);
                        boolean container2Exist = false;
                        boolean container3Exist = false;
                        for (ContainerStatus status : statuses) {
                            if (status.getContainerId().equals(containerStatus2.getContainerId())) {
                                Assert.assertTrue(status.getState().equals(containerStatus2.getState()));
                                container2Exist = true;
                            }
                            if (status.getContainerId().equals(containerStatus3.getContainerId())) {
                                Assert.assertTrue(status.getState().equals(containerStatus3.getState()));
                                container3Exist = true;
                            }
                        }
                        Assert.assertTrue(container2Exist && container3Exist);
                        // should throw exception that can be retried by the
                        // nodeStatusUpdaterRunnable, otherwise nm just shuts down and the
                        // test passes.
                        throw new YarnRuntimeException("Lost the heartbeat response");
                    } else
                        if (FHQZQVZNEY == 2) {
                            List<ContainerStatus> statuses = request.getNodeStatus().getContainersStatuses();
                            Assert.assertEquals(statuses.size(), 4);
                            Assert.assertEquals(VKBZPSZRCB.getContainers().size(), 4);
                            ContainerStatus containerStatus2 = TestNodeStatusUpdater.createContainerStatus(2, RUNNING);
                            ContainerStatus containerStatus3 = TestNodeStatusUpdater.createContainerStatus(3, COMPLETE);
                            ContainerStatus containerStatus4 = TestNodeStatusUpdater.createContainerStatus(4, RUNNING);
                            ContainerStatus containerStatus5 = TestNodeStatusUpdater.createContainerStatus(5, COMPLETE);
                            boolean container2Exist = false;
                            boolean container3Exist = false;
                            boolean container4Exist = false;
                            boolean container5Exist = false;
                            for (ContainerStatus status : statuses) {
                                if (status.getContainerId().equals(containerStatus2.getContainerId())) {
                                    Assert.assertTrue(status.getState().equals(containerStatus2.getState()));
                                    container2Exist = true;
                                }
                                if (status.getContainerId().equals(containerStatus3.getContainerId())) {
                                    Assert.assertTrue(status.getState().equals(containerStatus3.getState()));
                                    container3Exist = true;
                                }
                                if (status.getContainerId().equals(containerStatus4.getContainerId())) {
                                    Assert.assertTrue(status.getState().equals(containerStatus4.getState()));
                                    container4Exist = true;
                                }
                                if (status.getContainerId().equals(containerStatus5.getContainerId())) {
                                    Assert.assertTrue(status.getState().equals(containerStatus5.getState()));
                                    container5Exist = true;
                                }
                            }
                            Assert.assertTrue(((container2Exist && container3Exist) && container4Exist) && container5Exist);
                        }


            } catch (AssertionError error) {
                error.printStackTrace();
                IYBVZPPRDQ.set(true);
            } finally {
                FHQZQVZNEY++;
            }
            NodeStatus nodeStatus = request.getNodeStatus();
            nodeStatus.setResponseId(FHQZQVZNEY);
            NodeHeartbeatResponse nhResponse = YarnServerBuilderUtils.newNodeHeartbeatResponse(FHQZQVZNEY, TKRLHRPAKX, null, null, null, null, 1000L);
            return nhResponse;
        }
    }

    private class MyResourceTracker5 implements ResourceTracker {
        public NodeAction XQDTCOXWCM = NodeAction.NORMAL;

        @Override
        public RegisterNodeManagerResponse registerNodeManager(RegisterNodeManagerRequest request) throws IOException, YarnException {
            RegisterNodeManagerResponse response = TestNodeStatusUpdater.EWWMOUHBOU.newRecordInstance(RegisterNodeManagerResponse.class);
            response.setNodeAction(XQDTCOXWCM);
            response.setContainerTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            response.setNMTokenMasterKey(TestNodeStatusUpdater.createMasterKey());
            return response;
        }

        @Override
        public NodeHeartbeatResponse nodeHeartbeat(NodeHeartbeatRequest request) throws IOException, YarnException {
            FHQZQVZNEY++;
            throw new ConnectException("NodeHeartbeat exception");
        }
    }

    private class MyResourceTracker6 implements ResourceTracker {
        private long IDARMQIEIA;

        private boolean HYJOSFWXSC;

        private final long JVVJGPUGWJ;

        public MyResourceTracker6(long rmStartIntervalMS, boolean rmNeverStart) {
            this.IDARMQIEIA = rmStartIntervalMS;
            this.HYJOSFWXSC = rmNeverStart;
            this.JVVJGPUGWJ = System.currentTimeMillis();
        }

        @Override
        public RegisterNodeManagerResponse registerNodeManager(RegisterNodeManagerRequest request) throws IOException, YarnException {
            if (((System.currentTimeMillis() - JVVJGPUGWJ) <= IDARMQIEIA) || HYJOSFWXSC) {
                throw new ConnectException("Faking RM start failure as start " + "delay timer has not expired.");
            } else {
                NodeId nodeId = request.getNodeId();
                Resource resource = request.getResource();
                TestNodeStatusUpdater.RULNNGBXHM.info("Registering " + nodeId.toString());
                // NOTE: this really should be checking against the config value
                InetSocketAddress expected = NetUtils.getConnectAddress(BYOTYNLEJG.getSocketAddr(NM_ADDRESS, null, -1));
                Assert.assertEquals(NetUtils.getHostPortString(expected), nodeId.toString());
                Assert.assertEquals(5 * 1024, resource.getMemory());
                SUPLMVWWNA.add(nodeId);
                RegisterNodeManagerResponse response = TestNodeStatusUpdater.EWWMOUHBOU.newRecordInstance(RegisterNodeManagerResponse.class);
                MSCZSDVSRO = true;
                return response;
            }
        }

        @Override
        public NodeHeartbeatResponse nodeHeartbeat(NodeHeartbeatRequest request) throws IOException, YarnException {
            NodeStatus nodeStatus = request.getNodeStatus();
            nodeStatus.setResponseId(FHQZQVZNEY++);
            NodeHeartbeatResponse nhResponse = YarnServerBuilderUtils.newNodeHeartbeatResponse(FHQZQVZNEY, NORMAL, null, null, null, null, 1000L);
            return nhResponse;
        }
    }

    @Before
    public void clearError() {
        UEOOAGNVYD = null;
    }

    @After
    public void deleteBaseDir() throws IOException {
        FileContext CCJUNQJQHW = FileContext.getLocalFSFileContext();
        CCJUNQJQHW.delete(new Path(TestNodeStatusUpdater.VAJREPZJQY.getPath()), true);
    }

    @Test(timeout = 90000)
    public void testRecentlyFinishedContainers() throws Exception {
        NodeManager DYEYFNDEXQ = new NodeManager();
        YarnConfiguration CVRDNALBHG = new YarnConfiguration();
        CVRDNALBHG.set(YARN_NODEMANAGER_DURATION_TO_TRACK_STOPPED_CONTAINERS, "10000");
        DYEYFNDEXQ.init(CVRDNALBHG);
        NodeStatusUpdaterImpl MWOHVTZNYH = ((NodeStatusUpdaterImpl) (DYEYFNDEXQ.getNodeStatusUpdater()));
        ApplicationId UWCIYWUKGP = ApplicationId.newInstance(0, 0);
        ApplicationAttemptId JPKQCGDUEX = ApplicationAttemptId.newInstance(UWCIYWUKGP, 0);
        ContainerId MYXOHWAEBC = ContainerId.newInstance(JPKQCGDUEX, 0);
        MWOHVTZNYH.addCompletedContainer(MYXOHWAEBC);
        Assert.assertTrue(MWOHVTZNYH.isContainerRecentlyStopped(MYXOHWAEBC));
        long NIWMVTMTFB = System.currentTimeMillis();
        int TRSXARNPWO = 15;
        while (((TRSXARNPWO--) > 0) && MWOHVTZNYH.isContainerRecentlyStopped(MYXOHWAEBC)) {
            MWOHVTZNYH.removeVeryOldStoppedContainersFromCache();
            Thread.sleep(1000);
        } 
        long MALUSIDJVV = System.currentTimeMillis();
        // By this time the container will be removed from cache. need to verify.
        Assert.assertFalse(MWOHVTZNYH.isContainerRecentlyStopped(MYXOHWAEBC));
        Assert.assertTrue(((MALUSIDJVV - NIWMVTMTFB) >= 10000) && ((MALUSIDJVV - NIWMVTMTFB) <= 250000));
    }

    @Test
    public void testNMRegistration() throws InterruptedException {
        RLLEYMONMH = new NodeManager() {
            @Override
            protected NodeStatusUpdater createNodeStatusUpdater(Context RMKADAIRYB, Dispatcher EYMTYEWMBN, NodeHealthCheckerService ERPELQBBTR) {
                return new TestNodeStatusUpdater.MyNodeStatusUpdater(RMKADAIRYB, EYMTYEWMBN, ERPELQBBTR, metrics);
            }
        };
        YarnConfiguration NOMJCICTGN = createNMConfig();
        RLLEYMONMH.init(NOMJCICTGN);
        // verify that the last service is the nodeStatusUpdater (ie registration
        // with RM)
        Object[] HDFNFNFCKY = RLLEYMONMH.getServices().toArray();
        Object FRSNQXLLLZ = HDFNFNFCKY[HDFNFNFCKY.length - 1];
        Assert.assertTrue("last service is NOT the node status updater", FRSNQXLLLZ instanceof NodeStatusUpdater);
        new Thread() {
            public void run() {
                try {
                    RLLEYMONMH.start();
                } catch (Throwable e) {
                    TestNodeStatusUpdater.this.UEOOAGNVYD = e;
                    throw new YarnRuntimeException(e);
                }
            }
        }.start();
        System.out.println(" ----- thread already started.." + RLLEYMONMH.getServiceState());
        int TIFSYSMJMV = 0;
        while ((RLLEYMONMH.getServiceState() == STATE.INITED) && ((TIFSYSMJMV++) != 50)) {
            TestNodeStatusUpdater.RULNNGBXHM.info("Waiting for NM to start..");
            if (UEOOAGNVYD != null) {
                TestNodeStatusUpdater.RULNNGBXHM.error("Error during startup. ", UEOOAGNVYD);
                Assert.fail(UEOOAGNVYD.getCause().getMessage());
            }
            Thread.sleep(2000);
        } 
        if (RLLEYMONMH.getServiceState() != STATE.STARTED) {
            // NM could have failed.
            Assert.fail("NodeManager failed to start");
        }
        TIFSYSMJMV = 0;
        while ((FHQZQVZNEY <= 3) && ((TIFSYSMJMV++) != 200)) {
            Thread.sleep(1000);
        } 
        Assert.assertFalse(FHQZQVZNEY <= 3);
        Assert.assertEquals("Number of registered NMs is wrong!!", 1, this.SUPLMVWWNA.size());
        RLLEYMONMH.stop();
    }

    @Test
    public void testStopReentrant() throws Exception {
        final AtomicInteger ULBXFWHRDM = new AtomicInteger(0);
        RLLEYMONMH = new NodeManager() {
            @Override
            protected NodeStatusUpdater createNodeStatusUpdater(Context FEZUIIMLQF, Dispatcher ICHMUKQFPY, NodeHealthCheckerService JFVMOHMGJJ) {
                TestNodeStatusUpdater.MyNodeStatusUpdater YKNHCDMXTV = new TestNodeStatusUpdater.MyNodeStatusUpdater(FEZUIIMLQF, ICHMUKQFPY, JFVMOHMGJJ, metrics);
                TestNodeStatusUpdater.MyResourceTracker2 EIGXCQCVXG = new TestNodeStatusUpdater.MyResourceTracker2();
                EIGXCQCVXG.WPZGJRKYQN = NodeAction.SHUTDOWN;
                YKNHCDMXTV.GKBDBLPECZ = EIGXCQCVXG;
                return YKNHCDMXTV;
            }

            @Override
            protected ContainerManagerImpl createContainerManager(Context WHAAYBIELV, ContainerExecutor HMIHWNAMJS, DeletionService AHSTMIPZEI, NodeStatusUpdater OOZJPMLIBL, ApplicationACLsManager FIGYJBGXVF, LocalDirsHandlerService LNQZHJSOTX) {
                return new ContainerManagerImpl(WHAAYBIELV, HMIHWNAMJS, AHSTMIPZEI, OOZJPMLIBL, metrics, FIGYJBGXVF, LNQZHJSOTX) {
                    @Override
                    public void cleanUpApplicationsOnNMShutDown() {
                        super.cleanUpApplicationsOnNMShutDown();
                        ULBXFWHRDM.incrementAndGet();
                    }
                };
            }
        };
        YarnConfiguration LWRKBFIXCI = createNMConfig();
        RLLEYMONMH.init(LWRKBFIXCI);
        RLLEYMONMH.start();
        int BLAXWKNVSM = 0;
        while ((FHQZQVZNEY < 1) && ((BLAXWKNVSM++) != 200)) {
            Thread.sleep(500);
        } 
        Assert.assertFalse(FHQZQVZNEY < 1);
        // Meanwhile call stop directly as the shutdown hook would
        RLLEYMONMH.stop();
        // NM takes a while to reach the STOPPED state.
        BLAXWKNVSM = 0;
        while ((RLLEYMONMH.getServiceState() != STATE.STOPPED) && ((BLAXWKNVSM++) != 20)) {
            TestNodeStatusUpdater.RULNNGBXHM.info("Waiting for NM to stop..");
            Thread.sleep(1000);
        } 
        Assert.assertEquals(STOPPED, RLLEYMONMH.getServiceState());
        Assert.assertEquals(ULBXFWHRDM.get(), 1);
    }

    @Test
    public void testNodeDecommision() throws Exception {
        RLLEYMONMH = getNodeManager(SHUTDOWN);
        YarnConfiguration KXQBYEXRYY = createNMConfig();
        RLLEYMONMH.init(KXQBYEXRYY);
        Assert.assertEquals(INITED, RLLEYMONMH.getServiceState());
        RLLEYMONMH.start();
        int SSXGCJVQGF = 0;
        while ((FHQZQVZNEY < 1) && ((SSXGCJVQGF++) != 200)) {
            Thread.sleep(500);
        } 
        Assert.assertFalse(FHQZQVZNEY < 1);
        Assert.assertTrue(RLLEYMONMH.getNMContext().getDecommissioned());
        // NM takes a while to reach the STOPPED state.
        SSXGCJVQGF = 0;
        while ((RLLEYMONMH.getServiceState() != STATE.STOPPED) && ((SSXGCJVQGF++) != 20)) {
            TestNodeStatusUpdater.RULNNGBXHM.info("Waiting for NM to stop..");
            Thread.sleep(1000);
        } 
        Assert.assertEquals(STOPPED, RLLEYMONMH.getServiceState());
    }

    private abstract class NodeManagerWithCustomNodeStatusUpdater extends NodeManager {
        private NodeStatusUpdater WLDROAZROB;

        private NodeManagerWithCustomNodeStatusUpdater() {
        }

        @Override
        protected NodeStatusUpdater createNodeStatusUpdater(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker) {
            WLDROAZROB = createUpdater(context, dispatcher, healthChecker);
            return WLDROAZROB;
        }

        public NodeStatusUpdater getUpdater() {
            return WLDROAZROB;
        }

        abstract NodeStatusUpdater createUpdater(Context context, Dispatcher dispatcher, NodeHealthCheckerService healthChecker);
    }

    @Test
    public void testNMShutdownForRegistrationFailure() throws Exception {
        RLLEYMONMH = new TestNodeStatusUpdater.NodeManagerWithCustomNodeStatusUpdater() {
            @Override
            protected NodeStatusUpdater createUpdater(Context XZXTSLDPOP, Dispatcher RHZNEWWAIA, NodeHealthCheckerService EWZVSBGJZH) {
                TestNodeStatusUpdater.MyNodeStatusUpdater SXAMUSHEEP = new TestNodeStatusUpdater.MyNodeStatusUpdater(XZXTSLDPOP, RHZNEWWAIA, EWZVSBGJZH, metrics);
                TestNodeStatusUpdater.MyResourceTracker2 BPBEQASPZP = new TestNodeStatusUpdater.MyResourceTracker2();
                BPBEQASPZP.PPHGVZAKQE = NodeAction.SHUTDOWN;
                BPBEQASPZP.LRZEWTUWRB = "RM Shutting Down Node";
                SXAMUSHEEP.GKBDBLPECZ = BPBEQASPZP;
                return SXAMUSHEEP;
            }
        };
        verifyNodeStartFailure("Recieved SHUTDOWN signal from Resourcemanager ," + ("Registration of NodeManager failed, " + "Message from ResourceManager: RM Shutting Down Node"));
    }

    @Test(timeout = 150000)
    public void testNMConnectionToRM() throws Exception {
        final long FTVUAQGFBJ = 50000;
        final long EUIZPKEHFM = 5000;
        final long QUHUJBDVOO = 1000;
        // Waiting for rmStartIntervalMS, RM will be started
        final long UWCRAXQYIP = 2 * 1000;
        BYOTYNLEJG.setLong(RESOURCEMANAGER_CONNECT_MAX_WAIT_MS, EUIZPKEHFM);
        BYOTYNLEJG.setLong(RESOURCEMANAGER_CONNECT_RETRY_INTERVAL_MS, QUHUJBDVOO);
        // Test NM try to connect to RM Several times, but finally fail
        TestNodeStatusUpdater.NodeManagerWithCustomNodeStatusUpdater CCVWLEYBGC;
        RLLEYMONMH = CCVWLEYBGC = new TestNodeStatusUpdater.NodeManagerWithCustomNodeStatusUpdater() {
            @Override
            protected NodeStatusUpdater createUpdater(Context LFDISLIXEC, Dispatcher GBBKDOMEEH, NodeHealthCheckerService MVSMSLKHOO) {
                NodeStatusUpdater EEVYSGJHKR = new TestNodeStatusUpdater.MyNodeStatusUpdater4(LFDISLIXEC, GBBKDOMEEH, MVSMSLKHOO, metrics, UWCRAXQYIP, true);
                return EEVYSGJHKR;
            }
        };
        RLLEYMONMH.init(BYOTYNLEJG);
        long FKNHMUAEFM = System.currentTimeMillis();
        try {
            RLLEYMONMH.start();
            Assert.fail("NM should have failed to start due to RM connect failure");
        } catch (Exception e) {
            long IYUPFIGBVU = System.currentTimeMillis();
            long EUJIHUJKHH = IYUPFIGBVU - FKNHMUAEFM;
            boolean YGMRARXBVS = (EUJIHUJKHH >= EUIZPKEHFM) && (EUJIHUJKHH < (EUIZPKEHFM + FTVUAQGFBJ));
            if (!YGMRARXBVS) {
                // either the exception was too early, or it had a different cause.
                // reject with the inner stack trace
                throw new Exception((((((("NM should have tried re-connecting to RM during " + "period of at least ") + EUIZPKEHFM) + " ms, but ") + "stopped retrying within ") + (EUIZPKEHFM + FTVUAQGFBJ)) + " ms: ") + e, e);
            }
        }
        // Test NM connect to RM, fail at first several attempts,
        // but finally success.
        RLLEYMONMH = CCVWLEYBGC = new TestNodeStatusUpdater.NodeManagerWithCustomNodeStatusUpdater() {
            @Override
            protected NodeStatusUpdater createUpdater(Context IQWRTQADHS, Dispatcher HLSFRSTUJT, NodeHealthCheckerService YEMADYEUGX) {
                NodeStatusUpdater VIOTFKTUFK = new TestNodeStatusUpdater.MyNodeStatusUpdater4(IQWRTQADHS, HLSFRSTUJT, YEMADYEUGX, metrics, UWCRAXQYIP, false);
                return VIOTFKTUFK;
            }
        };
        RLLEYMONMH.init(BYOTYNLEJG);
        NodeStatusUpdater GKTKVCMVTJ = CCVWLEYBGC.getUpdater();
        Assert.assertNotNull("Updater not yet created ", GKTKVCMVTJ);
        FKNHMUAEFM = System.currentTimeMillis();
        try {
            RLLEYMONMH.start();
        } catch (Exception ex) {
            TestNodeStatusUpdater.RULNNGBXHM.error("NM should have started successfully " + "after connecting to RM.", ex);
            throw ex;
        }
        long XRLRICDJSN = System.currentTimeMillis() - FKNHMUAEFM;
        TestNodeStatusUpdater.MyNodeStatusUpdater4 IEEMUVKXIJ = ((TestNodeStatusUpdater.MyNodeStatusUpdater4) (GKTKVCMVTJ));
        Assert.assertTrue("NM started before updater triggered", IEEMUVKXIJ.isTriggered());
        Assert.assertTrue(((((("NM should have connected to RM after " + "the start interval of ") + UWCRAXQYIP) + ": actual ") + XRLRICDJSN) + " ") + IEEMUVKXIJ, XRLRICDJSN >= UWCRAXQYIP);
        Assert.assertTrue((((("NM should have connected to RM less than " + (UWCRAXQYIP + FTVUAQGFBJ)) + " milliseconds of RM starting up: actual ") + XRLRICDJSN) + " ") + IEEMUVKXIJ, XRLRICDJSN < (UWCRAXQYIP + FTVUAQGFBJ));
    }

    /**
     * Verifies that if for some reason NM fails to start ContainerManager RPC
     * server, RM is oblivious to NM's presence. The behaviour is like this
     * because otherwise, NM will report to RM even if all its servers are not
     * started properly, RM will think that the NM is alive and will retire the NM
     * only after NM_EXPIRY interval. See MAPREDUCE-2749.
     */
    @Test
    public void testNoRegistrationWhenNMServicesFail() throws Exception {
        RLLEYMONMH = new NodeManager() {
            @Override
            protected NodeStatusUpdater createNodeStatusUpdater(Context RZHNIXZPUM, Dispatcher ZTOQUKPUTP, NodeHealthCheckerService QVZENBMSPM) {
                return new TestNodeStatusUpdater.MyNodeStatusUpdater(RZHNIXZPUM, ZTOQUKPUTP, QVZENBMSPM, metrics);
            }

            @Override
            protected ContainerManagerImpl createContainerManager(Context QPPPFVRWHU, ContainerExecutor ETPAHKXVBD, DeletionService DGTDMAISKE, NodeStatusUpdater KDZHIKWHKO, ApplicationACLsManager WYEVXYAMSB, LocalDirsHandlerService PZWIUYKBHU) {
                return new ContainerManagerImpl(QPPPFVRWHU, ETPAHKXVBD, DGTDMAISKE, KDZHIKWHKO, metrics, WYEVXYAMSB, PZWIUYKBHU) {
                    @Override
                    protected void serviceStart() {
                        // Simulating failure of starting RPC server
                        throw new YarnRuntimeException("Starting of RPC Server failed");
                    }
                };
            }
        };
        verifyNodeStartFailure("Starting of RPC Server failed");
    }

    @Test
    public void testApplicationKeepAlive() throws Exception {
        TestNodeStatusUpdater.MyNodeManager SVCRTWIEDL = new TestNodeStatusUpdater.MyNodeManager();
        try {
            YarnConfiguration NBPCFSCEIB = createNMConfig();
            NBPCFSCEIB.setBoolean(LOG_AGGREGATION_ENABLED, true);
            NBPCFSCEIB.setLong(RM_NM_EXPIRY_INTERVAL_MS, 4000L);
            SVCRTWIEDL.init(NBPCFSCEIB);
            SVCRTWIEDL.start();
            // HB 2 -> app cancelled by RM.
            while (FHQZQVZNEY < 12) {
                Thread.sleep(1000L);
            } 
            TestNodeStatusUpdater.MyResourceTracker3 VDETVVUCGI = ((TestNodeStatusUpdater.MyResourceTracker3) (SVCRTWIEDL.getNodeStatusUpdater().getRMClient()));
            VDETVVUCGI.UPELHBPZHX.getApplications().remove(VDETVVUCGI.PFWXFONUNN);
            Assert.assertEquals(1, VDETVVUCGI.MFUKZLVRNN.size());
            int FZPBWAQWVP = VDETVVUCGI.MFUKZLVRNN.get(VDETVVUCGI.PFWXFONUNN).size();
            TestNodeStatusUpdater.RULNNGBXHM.info(("Number of Keep Alive Requests: [" + FZPBWAQWVP) + "]");
            Assert.assertTrue((FZPBWAQWVP == 2) || (FZPBWAQWVP == 3));
            while (FHQZQVZNEY < 20) {
                Thread.sleep(1000L);
            } 
            int AJQEXIXUJV = VDETVVUCGI.MFUKZLVRNN.get(VDETVVUCGI.PFWXFONUNN).size();
            Assert.assertEquals(FZPBWAQWVP, AJQEXIXUJV);
        } finally {
            if (SVCRTWIEDL.getServiceState() == STATE.STARTED)
                SVCRTWIEDL.stop();

        }
    }

    /**
     * Test completed containerStatus get back up when heart beat lost, and will
     * be sent via next heart beat.
     */
    @Test(timeout = 200000)
    public void testCompletedContainerStatusBackup() throws Exception {
        RLLEYMONMH = new NodeManager() {
            @Override
            protected NodeStatusUpdater createNodeStatusUpdater(Context OHHKDTIAKC, Dispatcher JOSEGWEFAS, NodeHealthCheckerService XRIKFUKZEE) {
                TestNodeStatusUpdater.MyNodeStatusUpdater2 VAPXQEOFKJ = new TestNodeStatusUpdater.MyNodeStatusUpdater2(OHHKDTIAKC, JOSEGWEFAS, XRIKFUKZEE, metrics);
                return VAPXQEOFKJ;
            }

            @Override
            protected NMContext createNMContext(NMContainerTokenSecretManager HLPWWXOIDA, NMTokenSecretManagerInNM YPCYMJCDJO, NMStateStoreService JOOFMPHGCH) {
                return new TestNodeStatusUpdater.MyNMContext(HLPWWXOIDA, YPCYMJCDJO);
            }
        };
        YarnConfiguration RVOXKYHHQH = createNMConfig();
        RLLEYMONMH.init(RVOXKYHHQH);
        RLLEYMONMH.start();
        int FWWEAATLGR = 0;
        while ((FHQZQVZNEY <= 3) && ((FWWEAATLGR++) != 20)) {
            Thread.sleep(500);
        } 
        if (IYBVZPPRDQ.get()) {
            Assert.fail("ContainerStatus Backup failed");
        }
        RLLEYMONMH.stop();
    }

    @Test(timeout = 200000)
    public void testNodeStatusUpdaterRetryAndNMShutdown() throws Exception {
        final long BNDHZKUUMR = 1000;
        final long HUSHIDWCER = 1000;
        YarnConfiguration IJQFBUDVJV = createNMConfig();
        IJQFBUDVJV.setLong(RESOURCEMANAGER_CONNECT_MAX_WAIT_MS, BNDHZKUUMR);
        IJQFBUDVJV.setLong(RESOURCEMANAGER_CONNECT_RETRY_INTERVAL_MS, HUSHIDWCER);
        IJQFBUDVJV.setLong(NM_SLEEP_DELAY_BEFORE_SIGKILL_MS, 5000);
        IJQFBUDVJV.setLong(NM_LOG_RETAIN_SECONDS, 1);
        CyclicBarrier TTAFHAWXKT = new CyclicBarrier(2);
        RLLEYMONMH = new TestNodeStatusUpdater.MyNodeManager2(TTAFHAWXKT, IJQFBUDVJV);
        RLLEYMONMH.init(IJQFBUDVJV);
        RLLEYMONMH.start();
        // start a container
        ContainerId TWSEVWWJVK = TestNodeManagerShutdown.createContainerId();
        FileContext COVARCTAMT = FileContext.getLocalFSFileContext();
        TestNodeManagerShutdown.startContainer(RLLEYMONMH, TWSEVWWJVK, COVARCTAMT, TestNodeStatusUpdater.DCJDJYOBTO, new File("start_file.txt"));
        try {
            TTAFHAWXKT.await(10000, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
        }
        Assert.assertFalse("Containers not cleaned up when NM stopped", IYBVZPPRDQ.get());
        Assert.assertTrue(((TestNodeStatusUpdater.MyNodeManager2) (RLLEYMONMH)).DZHOXXPHZZ);
        Assert.assertTrue("calculate heartBeatCount based on" + " connectionWaitSecs and RetryIntervalSecs", FHQZQVZNEY == 2);
    }

    @Test
    public void testRMVersionLessThanMinimum() throws InterruptedException {
        final AtomicInteger FOGXMFXJQE = new AtomicInteger(0);
        YarnConfiguration YKWCXISHKY = createNMConfig();
        YKWCXISHKY.set(NM_RESOURCEMANAGER_MINIMUM_VERSION, "3.0.0");
        RLLEYMONMH = new NodeManager() {
            @Override
            protected NodeStatusUpdater createNodeStatusUpdater(Context SCLRZWOICI, Dispatcher HKGSPVAZMS, NodeHealthCheckerService LSADIAPHAL) {
                TestNodeStatusUpdater.MyNodeStatusUpdater KNKHVXOMHS = new TestNodeStatusUpdater.MyNodeStatusUpdater(SCLRZWOICI, HKGSPVAZMS, LSADIAPHAL, metrics);
                TestNodeStatusUpdater.MyResourceTracker2 MJWEBYOKPM = new TestNodeStatusUpdater.MyResourceTracker2();
                MJWEBYOKPM.WPZGJRKYQN = NodeAction.NORMAL;
                MJWEBYOKPM.GUMRXFAATD = "3.0.0";
                KNKHVXOMHS.GKBDBLPECZ = MJWEBYOKPM;
                return KNKHVXOMHS;
            }

            @Override
            protected ContainerManagerImpl createContainerManager(Context CKVQCDAVFE, ContainerExecutor OGYZWFTOZN, DeletionService LIPNRJVVHC, NodeStatusUpdater QHDNLGNDNV, ApplicationACLsManager XHWBARLHCE, LocalDirsHandlerService WWYBBLYJDI) {
                return new ContainerManagerImpl(CKVQCDAVFE, OGYZWFTOZN, LIPNRJVVHC, QHDNLGNDNV, metrics, XHWBARLHCE, WWYBBLYJDI) {
                    @Override
                    public void cleanUpApplicationsOnNMShutDown() {
                        super.cleanUpApplicationsOnNMShutDown();
                        FOGXMFXJQE.incrementAndGet();
                    }
                };
            }
        };
        RLLEYMONMH.init(YKWCXISHKY);
        RLLEYMONMH.start();
        // NM takes a while to reach the STARTED state.
        int MXYFHCUGFB = 0;
        while ((RLLEYMONMH.getServiceState() != STATE.STARTED) && ((MXYFHCUGFB++) != 20)) {
            TestNodeStatusUpdater.RULNNGBXHM.info("Waiting for NM to stop..");
            Thread.sleep(1000);
        } 
        Assert.assertTrue(RLLEYMONMH.getServiceState() == STATE.STARTED);
        RLLEYMONMH.stop();
    }

    // Add new containers info into NM context each time node heart beats.
    private class MyNMContext extends NMContext {
        public MyNMContext(NMContainerTokenSecretManager containerTokenSecretManager, NMTokenSecretManagerInNM nmTokenSecretManager) {
            super(containerTokenSecretManager, nmTokenSecretManager, null, null, new NMNullStateStoreService());
        }

        @Override
        public ConcurrentMap<ContainerId, Container> getContainers() {
            if (FHQZQVZNEY == 0) {
                return containers;
            } else
                if (FHQZQVZNEY == 1) {
                    ContainerStatus containerStatus2 = TestNodeStatusUpdater.createContainerStatus(2, RUNNING);
                    Container container2 = TestNodeStatusUpdater.getMockContainer(containerStatus2);
                    containers.put(containerStatus2.getContainerId(), container2);
                    ContainerStatus containerStatus3 = TestNodeStatusUpdater.createContainerStatus(3, COMPLETE);
                    Container container3 = TestNodeStatusUpdater.getMockContainer(containerStatus3);
                    containers.put(containerStatus3.getContainerId(), container3);
                    return containers;
                } else
                    if (FHQZQVZNEY == 2) {
                        ContainerStatus containerStatus4 = TestNodeStatusUpdater.createContainerStatus(4, RUNNING);
                        Container container4 = TestNodeStatusUpdater.getMockContainer(containerStatus4);
                        containers.put(containerStatus4.getContainerId(), container4);
                        ContainerStatus containerStatus5 = TestNodeStatusUpdater.createContainerStatus(5, COMPLETE);
                        Container container5 = TestNodeStatusUpdater.getMockContainer(containerStatus5);
                        containers.put(containerStatus5.getContainerId(), container5);
                        return containers;
                    } else {
                        containers.clear();
                        return containers;
                    }


        }
    }

    public static ContainerStatus createContainerStatus(int SGUFFFIOYY, ContainerState LZJRJPERAK) {
        ApplicationId YUUNWXPKOC = ApplicationId.newInstance(0, 1);
        ApplicationAttemptId LMIVJQTXJR = ApplicationAttemptId.newInstance(YUUNWXPKOC, 1);
        ContainerId BMVDRRZLPW = ContainerId.newInstance(LMIVJQTXJR, SGUFFFIOYY);
        ContainerStatus ENBTBDLATA = BuilderUtils.newContainerStatus(BMVDRRZLPW, LZJRJPERAK, (("test_containerStatus: id=" + SGUFFFIOYY) + ", containerState: ") + LZJRJPERAK, 0);
        return ENBTBDLATA;
    }

    public static Container getMockContainer(ContainerStatus MEEOWQOAET) {
        ContainerImpl OPKNQDLTAG = mock(ContainerImpl.class);
        when(OPKNQDLTAG.cloneAndGetContainerStatus()).thenReturn(MEEOWQOAET);
        when(OPKNQDLTAG.getCurrentState()).thenReturn(MEEOWQOAET.getState());
        when(OPKNQDLTAG.getContainerId()).thenReturn(MEEOWQOAET.getContainerId());
        return OPKNQDLTAG;
    }

    private void verifyNodeStartFailure(String AFUKOFOKJM) throws Exception {
        Assert.assertNotNull("nm is null", RLLEYMONMH);
        YarnConfiguration FXXMQMHAGH = createNMConfig();
        RLLEYMONMH.init(FXXMQMHAGH);
        try {
            RLLEYMONMH.start();
            Assert.fail("NM should have failed to start. Didn't get exception!!");
        } catch (Exception e) {
            // the version in trunk looked in the cause for equality
            // and assumed failures were nested.
            // this version assumes that error strings propagate to the base and
            // use a contains() test only. It should be less brittle
            if (!e.getMessage().contains(AFUKOFOKJM)) {
                throw e;
            }
        }
        // the service should be stopped
        Assert.assertEquals("NM state is wrong!", STOPPED, RLLEYMONMH.getServiceState());
        Assert.assertEquals("Number of registered nodes is wrong!", 0, this.SUPLMVWWNA.size());
    }

    private YarnConfiguration createNMConfig() {
        YarnConfiguration HDOXNDDCXC = new YarnConfiguration();
        String KABCQZSTMI = null;
        try {
            KABCQZSTMI = InetAddress.getByName("localhost").getCanonicalHostName();
        } catch (UnknownHostException e) {
            Assert.fail("Unable to get localhost address: " + e.getMessage());
        }
        HDOXNDDCXC.setInt(NM_PMEM_MB, 5 * 1024);// 5GB

        HDOXNDDCXC.set(NM_ADDRESS, KABCQZSTMI + ":12345");
        HDOXNDDCXC.set(NM_LOCALIZER_ADDRESS, KABCQZSTMI + ":12346");
        HDOXNDDCXC.set(NM_LOG_DIRS, TestNodeStatusUpdater.IENLATLWGM.getAbsolutePath());
        HDOXNDDCXC.set(NM_REMOTE_APP_LOG_DIR, TestNodeStatusUpdater.VDYVZKASTN.getAbsolutePath());
        HDOXNDDCXC.set(NM_LOCAL_DIRS, TestNodeStatusUpdater.DCJDJYOBTO.getAbsolutePath());
        HDOXNDDCXC.setLong(NM_LOG_RETAIN_SECONDS, 1);
        return HDOXNDDCXC;
    }

    private NodeManager getNodeManager(final NodeAction QEZBXINZII) {
        return new NodeManager() {
            @Override
            protected NodeStatusUpdater createNodeStatusUpdater(Context PRBHMJRLOL, Dispatcher IWFAHILDTC, NodeHealthCheckerService SOJAQCFWVB) {
                TestNodeStatusUpdater.MyNodeStatusUpdater KXLFYJSJWS = new TestNodeStatusUpdater.MyNodeStatusUpdater(PRBHMJRLOL, IWFAHILDTC, SOJAQCFWVB, metrics);
                TestNodeStatusUpdater.MyResourceTracker2 EASFHCFNGU = new TestNodeStatusUpdater.MyResourceTracker2();
                EASFHCFNGU.WPZGJRKYQN = QEZBXINZII;
                KXLFYJSJWS.GKBDBLPECZ = EASFHCFNGU;
                return KXLFYJSJWS;
            }
        };
    }
}