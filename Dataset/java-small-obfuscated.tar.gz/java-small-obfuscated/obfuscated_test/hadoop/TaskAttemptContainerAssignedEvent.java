public class TaskAttemptContainerAssignedEvent extends TaskAttemptEvent {
    private final Container KPSJUFINRI;

    private final Map<ApplicationAccessType, String> MQAGHJQZUN;

    public TaskAttemptContainerAssignedEvent(TaskAttemptId MJCIQPWDYL, Container PRAJOZEHFB, Map<ApplicationAccessType, String> XQVODBDWDG) {
        super(MJCIQPWDYL, TA_ASSIGNED);
        this.KPSJUFINRI = PRAJOZEHFB;
        this.MQAGHJQZUN = XQVODBDWDG;
    }

    public Container getContainer() {
        return this.KPSJUFINRI;
    }

    public Map<ApplicationAccessType, String> getApplicationACLs() {
        return this.MQAGHJQZUN;
    }
}