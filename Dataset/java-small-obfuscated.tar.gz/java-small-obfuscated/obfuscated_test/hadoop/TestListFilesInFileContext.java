/**
 * This class tests the FileStatus API.
 */
public class TestListFilesInFileContext {
    {
        ((org.apache.commons.logging.impl.Log4JLogger) (FileSystem.LOG)).getLogger().setLevel(Level.ALL);
    }

    static final long HXUAROQWNI = 0xdeadbeefL;

    private static final Configuration XUZWYKGCPF = new Configuration();

    private static MiniDFSCluster DQIPPTHAMY;

    private static FileContext HTMUBGEWEP;

    private static final Path NIHPXJABKH = new Path("/main_");

    private static final int XIHNOFRMPJ = 10;

    private static final Path YJOFRWKOJW = new Path(TestListFilesInFileContext.NIHPXJABKH, "file1");

    private static final Path CIPPFQRFCB = new Path(TestListFilesInFileContext.NIHPXJABKH, "dir1");

    private static final Path FMDVERCTLX = new Path(TestListFilesInFileContext.CIPPFQRFCB, "file2");

    private static final Path PVNWCIYMEY = new Path(TestListFilesInFileContext.CIPPFQRFCB, "file3");

    @BeforeClass
    public static void testSetUp() throws Exception {
        TestListFilesInFileContext.DQIPPTHAMY = new MiniDFSCluster.Builder(TestListFilesInFileContext.XUZWYKGCPF).build();
        TestListFilesInFileContext.HTMUBGEWEP = FileContext.getFileContext(TestListFilesInFileContext.DQIPPTHAMY.getConfiguration(0));
        TestListFilesInFileContext.HTMUBGEWEP.delete(TestListFilesInFileContext.NIHPXJABKH, true);
    }

    private static void writeFile(FileContext DGKRJFSZJX, Path PTVRDIBCJF, int MJXWERHZXM) throws IOException {
        // Create and write a file that contains three blocks of data
        FSDataOutputStream ZWJQTWLFQD = DGKRJFSZJX.create(PTVRDIBCJF, EnumSet.of(CREATE), CreateOpts.createParent());
        byte[] GXXWIZXCJO = new byte[MJXWERHZXM];
        Random JRDEYIBNVR = new Random(TestListFilesInFileContext.HXUAROQWNI);
        JRDEYIBNVR.nextBytes(GXXWIZXCJO);
        ZWJQTWLFQD.write(GXXWIZXCJO);
        ZWJQTWLFQD.close();
    }

    @AfterClass
    public static void testShutdown() throws Exception {
        TestListFilesInFileContext.DQIPPTHAMY.shutdown();
    }

    /**
     * Test when input path is a file
     */
    @Test
    public void testFile() throws IOException {
        TestListFilesInFileContext.HTMUBGEWEP.mkdir(TestListFilesInFileContext.NIHPXJABKH, FsPermission.getDefault(), true);
        TestListFilesInFileContext.writeFile(TestListFilesInFileContext.HTMUBGEWEP, TestListFilesInFileContext.YJOFRWKOJW, TestListFilesInFileContext.XIHNOFRMPJ);
        RemoteIterator<LocatedFileStatus> XQCVODTVNH = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(TestListFilesInFileContext.YJOFRWKOJW, true);
        LocatedFileStatus TNMYEXUBXG = XQCVODTVNH.next();
        assertFalse(XQCVODTVNH.hasNext());
        assertTrue(TNMYEXUBXG.isFile());
        assertEquals(TestListFilesInFileContext.XIHNOFRMPJ, TNMYEXUBXG.getLen());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.YJOFRWKOJW), TNMYEXUBXG.getPath());
        assertEquals(1, TNMYEXUBXG.getBlockLocations().length);
        XQCVODTVNH = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(TestListFilesInFileContext.YJOFRWKOJW, false);
        TNMYEXUBXG = XQCVODTVNH.next();
        assertFalse(XQCVODTVNH.hasNext());
        assertTrue(TNMYEXUBXG.isFile());
        assertEquals(TestListFilesInFileContext.XIHNOFRMPJ, TNMYEXUBXG.getLen());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.YJOFRWKOJW), TNMYEXUBXG.getPath());
        assertEquals(1, TNMYEXUBXG.getBlockLocations().length);
    }

    @After
    public void cleanDir() throws IOException {
        TestListFilesInFileContext.HTMUBGEWEP.delete(TestListFilesInFileContext.NIHPXJABKH, true);
    }

    /**
     * Test when input path is a directory
     */
    @Test
    public void testDirectory() throws IOException {
        TestListFilesInFileContext.HTMUBGEWEP.mkdir(TestListFilesInFileContext.CIPPFQRFCB, FsPermission.getDefault(), true);
        // test empty directory
        RemoteIterator<LocatedFileStatus> AUAUIOZSYF = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(TestListFilesInFileContext.CIPPFQRFCB, true);
        assertFalse(AUAUIOZSYF.hasNext());
        AUAUIOZSYF = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(TestListFilesInFileContext.CIPPFQRFCB, false);
        assertFalse(AUAUIOZSYF.hasNext());
        // testing directory with 1 file
        TestListFilesInFileContext.writeFile(TestListFilesInFileContext.HTMUBGEWEP, TestListFilesInFileContext.FMDVERCTLX, TestListFilesInFileContext.XIHNOFRMPJ);
        AUAUIOZSYF = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(TestListFilesInFileContext.CIPPFQRFCB, true);
        LocatedFileStatus NZLNVNSHHA = AUAUIOZSYF.next();
        assertFalse(AUAUIOZSYF.hasNext());
        assertTrue(NZLNVNSHHA.isFile());
        assertEquals(TestListFilesInFileContext.XIHNOFRMPJ, NZLNVNSHHA.getLen());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.FMDVERCTLX), NZLNVNSHHA.getPath());
        assertEquals(1, NZLNVNSHHA.getBlockLocations().length);
        AUAUIOZSYF = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(TestListFilesInFileContext.CIPPFQRFCB, false);
        NZLNVNSHHA = AUAUIOZSYF.next();
        assertFalse(AUAUIOZSYF.hasNext());
        assertTrue(NZLNVNSHHA.isFile());
        assertEquals(TestListFilesInFileContext.XIHNOFRMPJ, NZLNVNSHHA.getLen());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.FMDVERCTLX), NZLNVNSHHA.getPath());
        assertEquals(1, NZLNVNSHHA.getBlockLocations().length);
        // test more complicated directory
        TestListFilesInFileContext.writeFile(TestListFilesInFileContext.HTMUBGEWEP, TestListFilesInFileContext.YJOFRWKOJW, TestListFilesInFileContext.XIHNOFRMPJ);
        TestListFilesInFileContext.writeFile(TestListFilesInFileContext.HTMUBGEWEP, TestListFilesInFileContext.PVNWCIYMEY, TestListFilesInFileContext.XIHNOFRMPJ);
        AUAUIOZSYF = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(TestListFilesInFileContext.NIHPXJABKH, true);
        NZLNVNSHHA = AUAUIOZSYF.next();
        assertTrue(NZLNVNSHHA.isFile());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.FMDVERCTLX), NZLNVNSHHA.getPath());
        NZLNVNSHHA = AUAUIOZSYF.next();
        assertTrue(NZLNVNSHHA.isFile());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.PVNWCIYMEY), NZLNVNSHHA.getPath());
        NZLNVNSHHA = AUAUIOZSYF.next();
        assertTrue(NZLNVNSHHA.isFile());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.YJOFRWKOJW), NZLNVNSHHA.getPath());
        assertFalse(AUAUIOZSYF.hasNext());
        AUAUIOZSYF = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(TestListFilesInFileContext.NIHPXJABKH, false);
        NZLNVNSHHA = AUAUIOZSYF.next();
        assertTrue(NZLNVNSHHA.isFile());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.YJOFRWKOJW), NZLNVNSHHA.getPath());
        assertFalse(AUAUIOZSYF.hasNext());
    }

    /**
     * Test when input patch has a symbolic links as its children
     */
    @Test
    public void testSymbolicLinks() throws IOException {
        TestListFilesInFileContext.writeFile(TestListFilesInFileContext.HTMUBGEWEP, TestListFilesInFileContext.YJOFRWKOJW, TestListFilesInFileContext.XIHNOFRMPJ);
        TestListFilesInFileContext.writeFile(TestListFilesInFileContext.HTMUBGEWEP, TestListFilesInFileContext.FMDVERCTLX, TestListFilesInFileContext.XIHNOFRMPJ);
        TestListFilesInFileContext.writeFile(TestListFilesInFileContext.HTMUBGEWEP, TestListFilesInFileContext.PVNWCIYMEY, TestListFilesInFileContext.XIHNOFRMPJ);
        Path LTZXAWCMKH = new Path(TestListFilesInFileContext.NIHPXJABKH, "dir4");
        Path ROVNONSXQV = new Path(LTZXAWCMKH, "dir5");
        Path RPBMKMWMMO = new Path(LTZXAWCMKH, "file4");
        TestListFilesInFileContext.HTMUBGEWEP.createSymlink(TestListFilesInFileContext.CIPPFQRFCB, ROVNONSXQV, true);
        TestListFilesInFileContext.HTMUBGEWEP.createSymlink(TestListFilesInFileContext.YJOFRWKOJW, RPBMKMWMMO, true);
        RemoteIterator<LocatedFileStatus> MQAAFHBWLI = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(LTZXAWCMKH, true);
        LocatedFileStatus LETRHLDKCF = MQAAFHBWLI.next();
        assertTrue(LETRHLDKCF.isFile());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.FMDVERCTLX), LETRHLDKCF.getPath());
        LETRHLDKCF = MQAAFHBWLI.next();
        assertTrue(LETRHLDKCF.isFile());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.PVNWCIYMEY), LETRHLDKCF.getPath());
        LETRHLDKCF = MQAAFHBWLI.next();
        assertTrue(LETRHLDKCF.isFile());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.YJOFRWKOJW), LETRHLDKCF.getPath());
        assertFalse(MQAAFHBWLI.hasNext());
        MQAAFHBWLI = TestListFilesInFileContext.HTMUBGEWEP.util().listFiles(LTZXAWCMKH, false);
        LETRHLDKCF = MQAAFHBWLI.next();
        assertTrue(LETRHLDKCF.isFile());
        assertEquals(TestListFilesInFileContext.HTMUBGEWEP.makeQualified(TestListFilesInFileContext.YJOFRWKOJW), LETRHLDKCF.getPath());
        assertFalse(MQAAFHBWLI.hasNext());
    }
}