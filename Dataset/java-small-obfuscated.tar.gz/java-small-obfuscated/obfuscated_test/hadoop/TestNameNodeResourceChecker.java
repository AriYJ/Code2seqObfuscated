public class TestNameNodeResourceChecker {
    private static final File CPBWQQLBTF = PathUtils.getTestDir(TestNameNodeResourceChecker.class);

    private Configuration FPERIEKNTF;

    private File QSHNJMXJYK;

    private File WFPBWIFABP;

    @Before
    public void setUp() throws IOException {
        FPERIEKNTF = new Configuration();
        WFPBWIFABP = new File(TestNameNodeResourceChecker.CPBWQQLBTF, "resource-check-name-dir");
        WFPBWIFABP.mkdirs();
        FPERIEKNTF.set(DFS_NAMENODE_EDITS_DIR_KEY, WFPBWIFABP.getAbsolutePath());
    }

    /**
     * Tests that hasAvailableDiskSpace returns true if disk usage is below
     * threshold.
     */
    @Test
    public void testCheckAvailability() throws IOException {
        FPERIEKNTF.setLong(DFS_NAMENODE_DU_RESERVED_KEY, 0);
        NameNodeResourceChecker VWAHREDNQU = new NameNodeResourceChecker(FPERIEKNTF);
        assertTrue("isResourceAvailable must return true if " + "disk usage is lower than threshold", VWAHREDNQU.hasAvailableDiskSpace());
    }

    /**
     * Tests that hasAvailableDiskSpace returns false if disk usage is above
     * threshold.
     */
    @Test
    public void testCheckAvailabilityNeg() throws IOException {
        FPERIEKNTF.setLong(DFS_NAMENODE_DU_RESERVED_KEY, Long.MAX_VALUE);
        NameNodeResourceChecker TNYLTQWUFJ = new NameNodeResourceChecker(FPERIEKNTF);
        assertFalse("isResourceAvailable must return false if " + "disk usage is higher than threshold", TNYLTQWUFJ.hasAvailableDiskSpace());
    }

    /**
     * Tests that NameNode resource monitor causes the NN to enter safe mode when
     * resources are low.
     */
    @Test
    public void testCheckThatNameNodeResourceMonitorIsRunning() throws IOException, InterruptedException {
        MiniDFSCluster DYUEAFUTEP = null;
        try {
            FPERIEKNTF.set(DFS_NAMENODE_EDITS_DIR_KEY, WFPBWIFABP.getAbsolutePath());
            FPERIEKNTF.setLong(DFS_NAMENODE_RESOURCE_CHECK_INTERVAL_KEY, 1);
            DYUEAFUTEP = new MiniDFSCluster.Builder(FPERIEKNTF).numDataNodes(1).build();
            NameNodeResourceChecker ZWDKELNBKI = Mockito.mock(NameNodeResourceChecker.class);
            Mockito.when(ZWDKELNBKI.hasAvailableDiskSpace()).thenReturn(true);
            DYUEAFUTEP.getNameNode().getNamesystem().nnResourceChecker = ZWDKELNBKI;
            DYUEAFUTEP.waitActive();
            String JXUBFOVDWM = NameNodeResourceMonitor.class.getName();
            boolean HMHGBHAOYR = false;
            Set<Thread> FWNSMACTBR = Thread.getAllStackTraces().keySet();
            for (Thread MZFCKXEIVS : FWNSMACTBR) {
                if (MZFCKXEIVS.toString().startsWith("Thread[" + JXUBFOVDWM)) {
                    HMHGBHAOYR = true;
                    break;
                }
            }
            assertTrue("NN resource monitor should be running", HMHGBHAOYR);
            assertFalse("NN should not presently be in safe mode", DYUEAFUTEP.getNameNode().isInSafeMode());
            Mockito.when(ZWDKELNBKI.hasAvailableDiskSpace()).thenReturn(false);
            // Make sure the NNRM thread has a chance to run.
            long AMVUBCXBXQ = Time.now();
            while ((!DYUEAFUTEP.getNameNode().isInSafeMode()) && (Time.now() < (AMVUBCXBXQ + (60 * 1000)))) {
                Thread.sleep(1000);
            } 
            assertTrue("NN should be in safe mode after resources crossed threshold", DYUEAFUTEP.getNameNode().isInSafeMode());
        } finally {
            if (DYUEAFUTEP != null)
                DYUEAFUTEP.shutdown();

        }
    }

    /**
     * Tests that only a single space check is performed if two name dirs are
     * supplied which are on the same volume.
     */
    @Test
    public void testChecking2NameDirsOnOneVolume() throws IOException {
        Configuration TOMSBKFXLJ = new Configuration();
        File QBVLDOLAYA = new File(TestNameNodeResourceChecker.CPBWQQLBTF, "name-dir1");
        File VPVCPHVIMQ = new File(TestNameNodeResourceChecker.CPBWQQLBTF, "name-dir2");
        QBVLDOLAYA.mkdirs();
        VPVCPHVIMQ.mkdirs();
        TOMSBKFXLJ.set(DFS_NAMENODE_EDITS_DIR_KEY, (QBVLDOLAYA.getAbsolutePath() + ",") + VPVCPHVIMQ.getAbsolutePath());
        TOMSBKFXLJ.setLong(DFS_NAMENODE_DU_RESERVED_KEY, Long.MAX_VALUE);
        NameNodeResourceChecker YGKEWXMSAZ = new NameNodeResourceChecker(TOMSBKFXLJ);
        assertEquals("Should not check the same volume more than once.", 1, YGKEWXMSAZ.getVolumesLowOnSpace().size());
    }

    /**
     * Tests that only a single space check is performed if extra volumes are
     * configured manually which also coincide with a volume the name dir is on.
     */
    @Test
    public void testCheckingExtraVolumes() throws IOException {
        Configuration RXIWQTVKCL = new Configuration();
        File BDVAOTDZDB = new File(TestNameNodeResourceChecker.CPBWQQLBTF, "name-dir");
        BDVAOTDZDB.mkdirs();
        RXIWQTVKCL.set(DFS_NAMENODE_EDITS_DIR_KEY, BDVAOTDZDB.getAbsolutePath());
        RXIWQTVKCL.set(DFS_NAMENODE_CHECKED_VOLUMES_KEY, BDVAOTDZDB.getAbsolutePath());
        RXIWQTVKCL.setLong(DFS_NAMENODE_DU_RESERVED_KEY, Long.MAX_VALUE);
        NameNodeResourceChecker FTWIVWBEOE = new NameNodeResourceChecker(RXIWQTVKCL);
        assertEquals("Should not check the same volume more than once.", 1, FTWIVWBEOE.getVolumesLowOnSpace().size());
    }

    /**
     * Test that the NN is considered to be out of resources only once all
     * redundant configured volumes are low on resources, or when any required
     * volume is low on resources.
     */
    @Test
    public void testLowResourceVolumePolicy() throws IOException, URISyntaxException {
        Configuration PZLWSRSVYH = new Configuration();
        File RYCMMMUWJS = new File(TestNameNodeResourceChecker.CPBWQQLBTF, "name-dir1");
        File SORTDEBMRU = new File(TestNameNodeResourceChecker.CPBWQQLBTF, "name-dir2");
        RYCMMMUWJS.mkdirs();
        SORTDEBMRU.mkdirs();
        PZLWSRSVYH.set(DFS_NAMENODE_EDITS_DIR_KEY, (RYCMMMUWJS.getAbsolutePath() + ",") + SORTDEBMRU.getAbsolutePath());
        PZLWSRSVYH.setInt(DFS_NAMENODE_CHECKED_VOLUMES_MINIMUM_KEY, 2);
        NameNodeResourceChecker BIWERSUAIT = new NameNodeResourceChecker(PZLWSRSVYH);
        // For the purpose of this test, we need to force the name dirs to appear to
        // be on different volumes.
        Map<String, CheckedVolume> BSTDVLSNAB = new HashMap<String, CheckedVolume>();
        CheckedVolume CKVJBGBVZO = Mockito.mock(CheckedVolume.class);
        CheckedVolume DNCLNZWVKU = Mockito.mock(CheckedVolume.class);
        CheckedVolume VLDEEGXPJU = Mockito.mock(CheckedVolume.class);
        CheckedVolume CUIMRPVSAJ = Mockito.mock(CheckedVolume.class);
        CheckedVolume ARUMCMDGZC = Mockito.mock(CheckedVolume.class);
        Mockito.when(CKVJBGBVZO.isResourceAvailable()).thenReturn(true);
        Mockito.when(DNCLNZWVKU.isResourceAvailable()).thenReturn(true);
        Mockito.when(VLDEEGXPJU.isResourceAvailable()).thenReturn(true);
        Mockito.when(CUIMRPVSAJ.isResourceAvailable()).thenReturn(true);
        Mockito.when(ARUMCMDGZC.isResourceAvailable()).thenReturn(true);
        // Make volumes 4 and 5 required.
        Mockito.when(CUIMRPVSAJ.isRequired()).thenReturn(true);
        Mockito.when(ARUMCMDGZC.isRequired()).thenReturn(true);
        BSTDVLSNAB.put("volume1", CKVJBGBVZO);
        BSTDVLSNAB.put("volume2", DNCLNZWVKU);
        BSTDVLSNAB.put("volume3", VLDEEGXPJU);
        BSTDVLSNAB.put("volume4", CUIMRPVSAJ);
        BSTDVLSNAB.put("volume5", ARUMCMDGZC);
        BIWERSUAIT.setVolumes(BSTDVLSNAB);
        // Initially all dirs have space.
        assertTrue(BIWERSUAIT.hasAvailableDiskSpace());
        // 1/3 redundant dir is low on space.
        Mockito.when(CKVJBGBVZO.isResourceAvailable()).thenReturn(false);
        assertTrue(BIWERSUAIT.hasAvailableDiskSpace());
        // 2/3 redundant dirs are low on space.
        Mockito.when(DNCLNZWVKU.isResourceAvailable()).thenReturn(false);
        assertFalse(BIWERSUAIT.hasAvailableDiskSpace());
        // Lower the minimum number of redundant volumes that must be available.
        BIWERSUAIT.setMinimumReduntdantVolumes(1);
        assertTrue(BIWERSUAIT.hasAvailableDiskSpace());
        // Just one required dir is low on space.
        Mockito.when(VLDEEGXPJU.isResourceAvailable()).thenReturn(false);
        assertFalse(BIWERSUAIT.hasAvailableDiskSpace());
        // Just the other required dir is low on space.
        Mockito.when(VLDEEGXPJU.isResourceAvailable()).thenReturn(true);
        Mockito.when(CUIMRPVSAJ.isResourceAvailable()).thenReturn(false);
        assertFalse(BIWERSUAIT.hasAvailableDiskSpace());
    }
}