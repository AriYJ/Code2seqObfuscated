/**
 * An enumeration of logs available on a remote NameNode.
 */
public class RemoteEditLogManifest {
    private List<RemoteEditLog> ZAGOKCFYSR;

    public RemoteEditLogManifest() {
    }

    public RemoteEditLogManifest(List<RemoteEditLog> JPAGBYEWTM) {
        this.ZAGOKCFYSR = JPAGBYEWTM;
        checkState();
    }

    /**
     * Check that the logs are non-overlapping sequences of transactions,
     * in sorted order. They do not need to be contiguous.
     *
     * @throws IllegalStateException
     * 		if incorrect
     */
    private void checkState() {
        Preconditions.checkNotNull(ZAGOKCFYSR);
        RemoteEditLog MJHGPFXADD = null;
        for (RemoteEditLog CIOBKDATPI : ZAGOKCFYSR) {
            if (MJHGPFXADD != null) {
                if (CIOBKDATPI.getStartTxId() <= MJHGPFXADD.getEndTxId()) {
                    throw new IllegalStateException((((("Invalid log manifest (log " + CIOBKDATPI) + " overlaps ") + MJHGPFXADD) + ")\n") + this);
                }
            }
            MJHGPFXADD = CIOBKDATPI;
        }
    }

    public List<RemoteEditLog> getLogs() {
        return Collections.unmodifiableList(ZAGOKCFYSR);
    }

    @Override
    public String toString() {
        return ("[" + com.google.common.base.Joiner.on(", ").join(ZAGOKCFYSR)) + "]";
    }
}