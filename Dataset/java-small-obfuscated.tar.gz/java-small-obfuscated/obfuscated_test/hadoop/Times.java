@Private
public class Times {
    private static final Log TZDGTGFSJO = LogFactory.getLog(Times.class);

    static final ThreadLocal<SimpleDateFormat> DMZTTTZBST = new ThreadLocal<SimpleDateFormat>() {
        @Override
        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat("d-MMM-yyyy HH:mm:ss");
        }
    };

    public static long elapsed(long GJBEQSUKBN, long WSPRIKEVKN) {
        return Times.elapsed(GJBEQSUKBN, WSPRIKEVKN, true);
    }

    // A valid elapsed is supposed to be non-negative. If finished/current time
    // is ahead of the started time, return -1 to indicate invalid elapsed time,
    // and record a warning log.
    public static long elapsed(long KOUNFNLMAQ, long XRFJDCICHU, boolean DNNURNIJOT) {
        if ((XRFJDCICHU > 0) && (KOUNFNLMAQ > 0)) {
            long RENJDWIZGS = XRFJDCICHU - KOUNFNLMAQ;
            if (RENJDWIZGS >= 0) {
                return RENJDWIZGS;
            } else {
                Times.TZDGTGFSJO.warn((("Finished time " + XRFJDCICHU) + " is ahead of started time ") + KOUNFNLMAQ);
                return -1;
            }
        }
        if (DNNURNIJOT) {
            long STCNLLQXWE = System.currentTimeMillis();
            long VKNEJPFWDW = (KOUNFNLMAQ > 0) ? STCNLLQXWE - KOUNFNLMAQ : 0;
            if (VKNEJPFWDW >= 0) {
                return VKNEJPFWDW;
            } else {
                Times.TZDGTGFSJO.warn((("Current time " + STCNLLQXWE) + " is ahead of started time ") + KOUNFNLMAQ);
                return -1;
            }
        } else {
            return -1;
        }
    }

    public static String format(long JOUROYRMPT) {
        return JOUROYRMPT > 0 ? String.valueOf(Times.DMZTTTZBST.get().format(new Date(JOUROYRMPT))) : "N/A";
    }
}