public class TestServerWebApp extends HTestCase {
    @Test(expected = IllegalArgumentException.class)
    public void getHomeDirNotDef() {
        ServerWebApp.getHomeDir("TestServerWebApp00");
    }

    @Test
    public void getHomeDir() {
        System.setProperty("TestServerWebApp0.home.dir", "/tmp");
        assertEquals(ServerWebApp.getHomeDir("TestServerWebApp0"), "/tmp");
        assertEquals(ServerWebApp.getDir("TestServerWebApp0", ".log.dir", "/tmp/log"), "/tmp/log");
        System.setProperty("TestServerWebApp0.log.dir", "/tmplog");
        assertEquals(ServerWebApp.getDir("TestServerWebApp0", ".log.dir", "/tmp/log"), "/tmplog");
    }

    @Test
    @TestDir
    public void lifecycle() throws Exception {
        String PPWTDPCJZL = org.apache.hadoop.test.TestDirHelper.getTestDir().getAbsolutePath();
        System.setProperty("TestServerWebApp1.home.dir", PPWTDPCJZL);
        System.setProperty("TestServerWebApp1.config.dir", PPWTDPCJZL);
        System.setProperty("TestServerWebApp1.log.dir", PPWTDPCJZL);
        System.setProperty("TestServerWebApp1.temp.dir", PPWTDPCJZL);
        ServerWebApp TVXHVGXOXF = new ServerWebApp("TestServerWebApp1") {};
        assertEquals(TVXHVGXOXF.getStatus(), Server.Status.UNDEF);
        TVXHVGXOXF.contextInitialized(null);
        assertEquals(TVXHVGXOXF.getStatus(), Server.Status.NORMAL);
        TVXHVGXOXF.contextDestroyed(null);
        assertEquals(TVXHVGXOXF.getStatus(), Server.Status.SHUTDOWN);
    }

    @Test(expected = RuntimeException.class)
    @TestDir
    public void failedInit() throws Exception {
        String HOFGAPABTW = org.apache.hadoop.test.TestDirHelper.getTestDir().getAbsolutePath();
        System.setProperty("TestServerWebApp2.home.dir", HOFGAPABTW);
        System.setProperty("TestServerWebApp2.config.dir", HOFGAPABTW);
        System.setProperty("TestServerWebApp2.log.dir", HOFGAPABTW);
        System.setProperty("TestServerWebApp2.temp.dir", HOFGAPABTW);
        System.setProperty("testserverwebapp2.services", "FOO");
        ServerWebApp KJCFNHEGGA = new ServerWebApp("TestServerWebApp2") {};
        KJCFNHEGGA.contextInitialized(null);
    }

    @Test
    @TestDir
    public void testResolveAuthority() throws Exception {
        String HWZRODGZHX = org.apache.hadoop.test.TestDirHelper.getTestDir().getAbsolutePath();
        System.setProperty("TestServerWebApp3.home.dir", HWZRODGZHX);
        System.setProperty("TestServerWebApp3.config.dir", HWZRODGZHX);
        System.setProperty("TestServerWebApp3.log.dir", HWZRODGZHX);
        System.setProperty("TestServerWebApp3.temp.dir", HWZRODGZHX);
        System.setProperty("testserverwebapp3.http.hostname", "localhost");
        System.setProperty("testserverwebapp3.http.port", "14000");
        ServerWebApp RQSKGAYXBW = new ServerWebApp("TestServerWebApp3") {};
        InetSocketAddress YJKMWAHCQO = RQSKGAYXBW.resolveAuthority();
        Assert.assertEquals("localhost", YJKMWAHCQO.getHostName());
        Assert.assertEquals(14000, YJKMWAHCQO.getPort());
    }
}