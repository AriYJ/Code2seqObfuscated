/**
 * This class is used in Namesystem's jetty to retrieve/upload a file
 * Typically used by the Secondary NameNode to retrieve image and
 * edit file for periodic checkpointing in Non-HA deployments.
 * Standby NameNode uses to upload checkpoints in HA deployments.
 */
@InterfaceAudience.Private
public class ImageServlet extends HttpServlet {
    public static final String WKQLUSEXMB = "/imagetransfer";

    private static final long RLXIXPHGNI = -7669068179452648952L;

    private static final Log AOHXZDHOCV = LogFactory.getLog(ImageServlet.class);

    public static final String BGVEWAEZPI = "Content-Disposition";

    public static final String DXUOZLQDDX = "X-Image-Edits-Name";

    private static final String RVIGSWMONW = "txid";

    private static final String RBAMVUXDJP = "startTxId";

    private static final String HGKFPCAPWY = "endTxId";

    private static final String DXPLXYXBGP = "storageInfo";

    private static final String LTVPIXOUYS = "latest";

    private static final String TNNFHQMZDU = "imageFile";

    private static final Set<Long> UVCHXQATAX = Collections.synchronizedSet(new HashSet<Long>());

    @Override
    public void doGet(final HttpServletRequest UZRRVIRQJY, final HttpServletResponse ITRPLDWMAR) throws IOException, ServletException {
        try {
            final ServletContext HBBMVWQMSA = getServletContext();
            final FSImage GOWTNEOUFY = NameNodeHttpServer.getFsImageFromContext(HBBMVWQMSA);
            final ImageServlet.GetImageParams SHAXLKNQQU = new ImageServlet.GetImageParams(UZRRVIRQJY, ITRPLDWMAR);
            final Configuration BZBPZXPPKN = ((Configuration) (HBBMVWQMSA.getAttribute(CURRENT_CONF)));
            final NameNodeMetrics KPXJJAIYWA = NameNode.getNameNodeMetrics();
            validateRequest(HBBMVWQMSA, BZBPZXPPKN, UZRRVIRQJY, ITRPLDWMAR, GOWTNEOUFY, SHAXLKNQQU.getStorageInfoString());
            UserGroupInformation.getCurrentUser().doAs(new PrivilegedExceptionAction<Void>() {
                @Override
                public Void run() throws Exception {
                    if (SHAXLKNQQU.isGetImage()) {
                        long LIJTGTPGRO = SHAXLKNQQU.getTxId();
                        File SFBJSVYABY = null;
                        String TWKJYQWGOQ = "Could not find image";
                        if (SHAXLKNQQU.shouldFetchLatest()) {
                            SFBJSVYABY = GOWTNEOUFY.getStorage().getHighestFsImageName();
                        } else {
                            TWKJYQWGOQ += " with txid " + LIJTGTPGRO;
                            SFBJSVYABY = GOWTNEOUFY.getStorage().getFsImage(LIJTGTPGRO, EnumSet.of(IMAGE, IMAGE_ROLLBACK));
                        }
                        if (SFBJSVYABY == null) {
                            throw new IOException(TWKJYQWGOQ);
                        }
                        CheckpointFaultInjector.getInstance().beforeGetImageSetsHeaders();
                        long JHFQCIKXVQ = monotonicNow();
                        serveFile(SFBJSVYABY);
                        if (KPXJJAIYWA != null) {
                            // Metrics non-null only when used inside name node
                            long OWVGXJUFZS = monotonicNow() - JHFQCIKXVQ;
                            KPXJJAIYWA.addGetImage(OWVGXJUFZS);
                        }
                    } else
                        if (SHAXLKNQQU.isGetEdit()) {
                            long GUVBZZOPFI = SHAXLKNQQU.getStartTxId();
                            long CRDDRXVSSY = SHAXLKNQQU.getEndTxId();
                            File NHAMTZNGJR = GOWTNEOUFY.getStorage().findFinalizedEditsFile(GUVBZZOPFI, CRDDRXVSSY);
                            long IIKQILADIM = monotonicNow();
                            serveFile(NHAMTZNGJR);
                            if (KPXJJAIYWA != null) {
                                // Metrics non-null only when used inside name node
                                long OPZRERJKZZ = monotonicNow() - IIKQILADIM;
                                KPXJJAIYWA.addGetEdit(OPZRERJKZZ);
                            }
                        }

                    return null;
                }

                private void serveFile(File IHOPVNSVLK) throws IOException {
                    FileInputStream UZVVRVGKES = new FileInputStream(IHOPVNSVLK);
                    try {
                        ImageServlet.setVerificationHeadersForGet(ITRPLDWMAR, IHOPVNSVLK);
                        ImageServlet.setFileNameHeaders(ITRPLDWMAR, IHOPVNSVLK);
                        if (!IHOPVNSVLK.exists()) {
                            // Potential race where the file was deleted while we were in the
                            // process of setting headers!
                            throw new FileNotFoundException(IHOPVNSVLK.toString());
                            // It's possible the file could be deleted after this point, but
                            // we've already opened the 'fis' stream.
                            // It's also possible length could change, but this would be
                            // detected by the client side as an inaccurate length header.
                        }
                        // send file
                        TransferFsImage.copyFileToStream(ITRPLDWMAR.getOutputStream(), IHOPVNSVLK, UZVVRVGKES, ImageServlet.getThrottler(BZBPZXPPKN));
                    } finally {
                        IOUtils.closeStream(UZVVRVGKES);
                    }
                }
            });
        } catch (Throwable t) {
            String GFZJPTHSPI = "GetImage failed. " + StringUtils.stringifyException(t);
            ITRPLDWMAR.sendError(SC_GONE, GFZJPTHSPI);
            throw new IOException(GFZJPTHSPI);
        } finally {
            ITRPLDWMAR.getOutputStream().close();
        }
    }

    private void validateRequest(ServletContext WBEBJQKRZZ, Configuration ACIOLEUCMT, HttpServletRequest FQOQXGSJHG, HttpServletResponse JEKXIODILI, FSImage YRITYBGUHI, String QHMYLIDMEL) throws IOException {
        if (UserGroupInformation.isSecurityEnabled() && (!ImageServlet.isValidRequestor(WBEBJQKRZZ, FQOQXGSJHG.getUserPrincipal().getName(), ACIOLEUCMT))) {
            String GBEDRUKCPR = "Only Namenode, Secondary Namenode, and administrators may access " + "this servlet";
            JEKXIODILI.sendError(SC_FORBIDDEN, GBEDRUKCPR);
            ImageServlet.AOHXZDHOCV.warn((("Received non-NN/SNN/administrator request for image or edits from " + FQOQXGSJHG.getUserPrincipal().getName()) + " at ") + FQOQXGSJHG.getRemoteHost());
            throw new IOException(GBEDRUKCPR);
        }
        String EMZUCLMAOO = YRITYBGUHI.getStorage().toColonSeparatedString();
        if ((QHMYLIDMEL != null) && (!EMZUCLMAOO.equals(QHMYLIDMEL))) {
            String XNWKDQZTRO = (("This namenode has storage info " + EMZUCLMAOO) + " but the secondary expected ") + QHMYLIDMEL;
            JEKXIODILI.sendError(SC_FORBIDDEN, XNWKDQZTRO);
            ImageServlet.AOHXZDHOCV.warn(("Received an invalid request file transfer request " + "from a secondary with storage info ") + QHMYLIDMEL);
            throw new IOException(XNWKDQZTRO);
        }
    }

    public static void setFileNameHeaders(HttpServletResponse BSLSNFITUH, File GKGVBQGEBC) {
        BSLSNFITUH.setHeader(ImageServlet.BGVEWAEZPI, "attachment; filename=" + GKGVBQGEBC.getName());
        BSLSNFITUH.setHeader(ImageServlet.DXUOZLQDDX, GKGVBQGEBC.getName());
    }

    /**
     * Construct a throttler from conf
     *
     * @param conf
     * 		configuration
     * @return a data transfer throttler
     */
    public static final DataTransferThrottler getThrottler(Configuration BNVDMJPIEH) {
        long ZNCPIXLJAN = BNVDMJPIEH.getLong(DFS_IMAGE_TRANSFER_RATE_KEY, DFS_IMAGE_TRANSFER_RATE_DEFAULT);
        DataTransferThrottler USLBXEJUCA = null;
        if (ZNCPIXLJAN > 0) {
            USLBXEJUCA = new DataTransferThrottler(ZNCPIXLJAN);
        }
        return USLBXEJUCA;
    }

    @VisibleForTesting
    static boolean isValidRequestor(ServletContext AVFGLAYYBN, String JPYNOMTDNS, Configuration HVJXMLVFUX) throws IOException {
        if (JPYNOMTDNS == null) {
            // This really shouldn't happen...
            ImageServlet.AOHXZDHOCV.warn("Received null remoteUser while authorizing access to getImage servlet");
            return false;
        }
        Set<String> KCHWYQXFUH = new HashSet<String>();
        KCHWYQXFUH.add(SecurityUtil.getServerPrincipal(HVJXMLVFUX.get(DFS_NAMENODE_KERBEROS_PRINCIPAL_KEY), NameNode.getAddress(HVJXMLVFUX).getHostName()));
        KCHWYQXFUH.add(SecurityUtil.getServerPrincipal(HVJXMLVFUX.get(DFS_SECONDARY_NAMENODE_KERBEROS_PRINCIPAL_KEY), SecondaryNameNode.getHttpAddress(HVJXMLVFUX).getHostName()));
        if (HAUtil.isHAEnabled(HVJXMLVFUX, DFSUtil.getNamenodeNameServiceId(HVJXMLVFUX))) {
            Configuration LITOEEYQLR = HAUtil.getConfForOtherNode(HVJXMLVFUX);
            KCHWYQXFUH.add(SecurityUtil.getServerPrincipal(LITOEEYQLR.get(DFS_NAMENODE_KERBEROS_PRINCIPAL_KEY), NameNode.getAddress(LITOEEYQLR).getHostName()));
        }
        for (String ESPOSHMLNJ : KCHWYQXFUH) {
            if ((ESPOSHMLNJ != null) && ESPOSHMLNJ.equals(JPYNOMTDNS)) {
                ImageServlet.AOHXZDHOCV.info("ImageServlet allowing checkpointer: " + JPYNOMTDNS);
                return true;
            }
        }
        if (HttpServer2.userHasAdministratorAccess(AVFGLAYYBN, JPYNOMTDNS)) {
            ImageServlet.AOHXZDHOCV.info("ImageServlet allowing administrator: " + JPYNOMTDNS);
            return true;
        }
        ImageServlet.AOHXZDHOCV.info("ImageServlet rejecting: " + JPYNOMTDNS);
        return false;
    }

    /**
     * Set headers for content length, and, if available, md5.
     *
     * @throws IOException
     * 		
     */
    public static void setVerificationHeadersForGet(HttpServletResponse NJRQNPYOID, File FQZXVYCHAK) throws IOException {
        NJRQNPYOID.setHeader(CONTENT_LENGTH, String.valueOf(FQZXVYCHAK.length()));
        MD5Hash FHVFWVWMID = MD5FileUtils.readStoredMd5ForFile(FQZXVYCHAK);
        if (FHVFWVWMID != null) {
            NJRQNPYOID.setHeader(MD5_HEADER, FHVFWVWMID.toString());
        }
    }

    static String getParamStringForMostRecentImage() {
        return (("getimage=1&" + ImageServlet.RVIGSWMONW) + "=") + ImageServlet.LTVPIXOUYS;
    }

    static String getParamStringForImage(NameNodeFile IVQONHYUHZ, long UYYRKURVBM, StorageInfo BTHXJMAINM) {
        final String CBAPOJDHAI = (IVQONHYUHZ == null) ? "" : (("&" + ImageServlet.TNNFHQMZDU) + "=") + IVQONHYUHZ.name();
        return ((((((("getimage=1&" + ImageServlet.RVIGSWMONW) + "=") + UYYRKURVBM) + CBAPOJDHAI) + "&") + ImageServlet.DXPLXYXBGP) + "=") + BTHXJMAINM.toColonSeparatedString();
    }

    static String getParamStringForLog(RemoteEditLog TXBRDMIUZT, StorageInfo CNDADNKHPM) {
        return (((((((((("getedit=1&" + ImageServlet.RBAMVUXDJP) + "=") + TXBRDMIUZT.getStartTxId()) + "&") + ImageServlet.HGKFPCAPWY) + "=") + TXBRDMIUZT.getEndTxId()) + "&") + ImageServlet.DXPLXYXBGP) + "=") + CNDADNKHPM.toColonSeparatedString();
    }

    static class GetImageParams {
        private boolean WRYNOKTZZD;

        private boolean PYALYYLVPG;

        private NameNodeFile KYMOKKQTXW;

        private long ZSSYJXHBVC;

        private long GCBYTGUTRF;

        private long FPLYTIYTMR;

        private String NRYSSKMVTU;

        private boolean JZVVSZEUPL;

        /**
         *
         *
         * @param request
         * 		the object from which this servlet reads the url contents
         * @param response
         * 		the object into which this servlet writes the url contents
         * @throws IOException
         * 		if the request is bad
         */
        public GetImageParams(HttpServletRequest request, HttpServletResponse response) throws IOException {
            @SuppressWarnings("unchecked")
            Map<String, String[]> pmap = request.getParameterMap();
            WRYNOKTZZD = PYALYYLVPG = JZVVSZEUPL = false;
            for (Map.Entry<String, String[]> entry : pmap.entrySet()) {
                String key = entry.getKey();
                String[] val = entry.getValue();
                if (key.equals("getimage")) {
                    WRYNOKTZZD = true;
                    try {
                        FPLYTIYTMR = ServletUtil.parseLongParam(request, ImageServlet.RVIGSWMONW);
                        String imageType = ServletUtil.getParameter(request, ImageServlet.TNNFHQMZDU);
                        KYMOKKQTXW = (imageType == null) ? NameNodeFile.IMAGE : NameNodeFile.valueOf(imageType);
                    } catch (NumberFormatException nfe) {
                        if (request.getParameter(ImageServlet.RVIGSWMONW).equals(ImageServlet.LTVPIXOUYS)) {
                            JZVVSZEUPL = true;
                        } else {
                            throw nfe;
                        }
                    }
                } else
                    if (key.equals("getedit")) {
                        PYALYYLVPG = true;
                        ZSSYJXHBVC = ServletUtil.parseLongParam(request, ImageServlet.RBAMVUXDJP);
                        GCBYTGUTRF = ServletUtil.parseLongParam(request, ImageServlet.HGKFPCAPWY);
                    } else
                        if (key.equals(ImageServlet.DXPLXYXBGP)) {
                            NRYSSKMVTU = val[0];
                        }


            }
            int numGets = (WRYNOKTZZD ? 1 : 0) + (PYALYYLVPG ? 1 : 0);
            if ((numGets > 1) || (numGets == 0)) {
                throw new IOException("Illegal parameters to TransferFsImage");
            }
        }

        public String getStorageInfoString() {
            return NRYSSKMVTU;
        }

        public long getTxId() {
            Preconditions.checkState(WRYNOKTZZD);
            return FPLYTIYTMR;
        }

        public NameNodeFile getNameNodeFile() {
            Preconditions.checkState(WRYNOKTZZD);
            return KYMOKKQTXW;
        }

        public long getStartTxId() {
            Preconditions.checkState(PYALYYLVPG);
            return ZSSYJXHBVC;
        }

        public long getEndTxId() {
            Preconditions.checkState(PYALYYLVPG);
            return GCBYTGUTRF;
        }

        boolean isGetEdit() {
            return PYALYYLVPG;
        }

        boolean isGetImage() {
            return WRYNOKTZZD;
        }

        boolean shouldFetchLatest() {
            return JZVVSZEUPL;
        }
    }

    /**
     * Set headers for image length and if available, md5.
     *
     * @throws IOException
     * 		
     */
    static void setVerificationHeadersForPut(HttpURLConnection RUDFLNUUNV, File YQVTBPEREW) throws IOException {
        RUDFLNUUNV.setRequestProperty(CONTENT_LENGTH, String.valueOf(YQVTBPEREW.length()));
        MD5Hash UADGPKFANP = MD5FileUtils.readStoredMd5ForFile(YQVTBPEREW);
        if (UADGPKFANP != null) {
            RUDFLNUUNV.setRequestProperty(MD5_HEADER, UADGPKFANP.toString());
        }
    }

    /**
     * Set the required parameters for uploading image
     *
     * @param httpMethod
     * 		instance of method to set the parameters
     * @param storage
     * 		colon separated storageInfo string
     * @param txid
     * 		txid of the image
     * @param imageFileSize
     * 		size of the imagefile to be uploaded
     * @param nnf
     * 		NameNodeFile Type
     * @return Returns map of parameters to be used with PUT request.
     */
    static Map<String, String> getParamsForPutImage(Storage LATPASSGHQ, long IFDQKNKZSR, long WYJGISSYXF, NameNodeFile INRBAAKMJK) {
        Map<String, String> TOYSVWCFBX = new HashMap<String, String>();
        TOYSVWCFBX.put(ImageServlet.RVIGSWMONW, Long.toString(IFDQKNKZSR));
        TOYSVWCFBX.put(ImageServlet.DXPLXYXBGP, LATPASSGHQ.toColonSeparatedString());
        // setting the length of the file to be uploaded in separate property as
        // Content-Length only supports up to 2GB
        TOYSVWCFBX.put(FILE_LENGTH, Long.toString(WYJGISSYXF));
        TOYSVWCFBX.put(ImageServlet.TNNFHQMZDU, INRBAAKMJK.name());
        return TOYSVWCFBX;
    }

    @Override
    protected void doPut(final HttpServletRequest DEJBZRSPDJ, final HttpServletResponse LIAHFHDCYJ) throws IOException, ServletException {
        try {
            ServletContext PACAFQKVQY = getServletContext();
            final FSImage JOCGLJDKJD = NameNodeHttpServer.getFsImageFromContext(PACAFQKVQY);
            final Configuration LPCDVSVHUS = ((Configuration) (getServletContext().getAttribute(CURRENT_CONF)));
            final ImageServlet.PutImageParams BQSSELEPOK = new ImageServlet.PutImageParams(DEJBZRSPDJ, LIAHFHDCYJ, LPCDVSVHUS);
            final NameNodeMetrics COHEUJETZA = NameNode.getNameNodeMetrics();
            validateRequest(PACAFQKVQY, LPCDVSVHUS, DEJBZRSPDJ, LIAHFHDCYJ, JOCGLJDKJD, BQSSELEPOK.getStorageInfoString());
            UserGroupInformation.getCurrentUser().doAs(new PrivilegedExceptionAction<Void>() {
                @Override
                public Void run() throws Exception {
                    final long IAHRIACQYP = BQSSELEPOK.getTxId();
                    final NameNodeFile KIAKATLZHA = BQSSELEPOK.getNameNodeFile();
                    if (!ImageServlet.UVCHXQATAX.add(IAHRIACQYP)) {
                        LIAHFHDCYJ.sendError(SC_CONFLICT, ("Another checkpointer is already in the process of uploading a" + " checkpoint made at transaction ID ") + IAHRIACQYP);
                        return null;
                    }
                    try {
                        if (JOCGLJDKJD.getStorage().findImageFile(KIAKATLZHA, IAHRIACQYP) != null) {
                            LIAHFHDCYJ.sendError(SC_CONFLICT, ("Another checkpointer already uploaded an checkpoint " + "for txid ") + IAHRIACQYP);
                            return null;
                        }
                        InputStream FRAHNHLEEL = DEJBZRSPDJ.getInputStream();
                        try {
                            long OZPMNEKVWJ = monotonicNow();
                            MD5Hash IAXPPLPQAJ = TransferFsImage.handleUploadImageRequest(DEJBZRSPDJ, IAHRIACQYP, JOCGLJDKJD.getStorage(), FRAHNHLEEL, BQSSELEPOK.getFileSize(), ImageServlet.getThrottler(LPCDVSVHUS));
                            JOCGLJDKJD.saveDigestAndRenameCheckpointImage(KIAKATLZHA, IAHRIACQYP, IAXPPLPQAJ);
                            // Metrics non-null only when used inside name node
                            if (COHEUJETZA != null) {
                                long CQYQCVHAON = monotonicNow() - OZPMNEKVWJ;
                                COHEUJETZA.addPutImage(CQYQCVHAON);
                            }
                            // Now that we have a new checkpoint, we might be able to
                            // remove some old ones.
                            JOCGLJDKJD.purgeOldStorage(KIAKATLZHA);
                        } finally {
                            FRAHNHLEEL.close();
                        }
                    } finally {
                        ImageServlet.UVCHXQATAX.remove(IAHRIACQYP);
                    }
                    return null;
                }
            });
        } catch (Throwable t) {
            String NYGDSGEOIX = "PutImage failed. " + StringUtils.stringifyException(t);
            LIAHFHDCYJ.sendError(SC_GONE, NYGDSGEOIX);
            throw new IOException(NYGDSGEOIX);
        }
    }

    /* Params required to handle put image request */
    static class PutImageParams {
        private long YCRTOUTZXF = -1;

        private String GXMQZUUCBF = null;

        private long HCYHWKDPHP = 0L;

        private NameNodeFile UKPBAZWPCH;

        public PutImageParams(HttpServletRequest request, HttpServletResponse response, Configuration conf) throws IOException {
            YCRTOUTZXF = ServletUtil.parseLongParam(request, ImageServlet.RVIGSWMONW);
            GXMQZUUCBF = ServletUtil.getParameter(request, ImageServlet.DXPLXYXBGP);
            HCYHWKDPHP = ServletUtil.parseLongParam(request, FILE_LENGTH);
            String imageType = ServletUtil.getParameter(request, ImageServlet.TNNFHQMZDU);
            UKPBAZWPCH = (imageType == null) ? NameNodeFile.IMAGE : NameNodeFile.valueOf(imageType);
            if ((((HCYHWKDPHP == 0) || (YCRTOUTZXF == (-1))) || (GXMQZUUCBF == null)) || GXMQZUUCBF.isEmpty()) {
                throw new IOException("Illegal parameters to TransferFsImage");
            }
        }

        public long getTxId() {
            return YCRTOUTZXF;
        }

        public String getStorageInfoString() {
            return GXMQZUUCBF;
        }

        public long getFileSize() {
            return HCYHWKDPHP;
        }

        public NameNodeFile getNameNodeFile() {
            return UKPBAZWPCH;
        }
    }
}