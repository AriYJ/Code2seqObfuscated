/**
 * **************************************************************
 * An abstract base class for a fairly generic filesystem.  It
 * may be implemented as a distributed filesystem, or as a "local"
 * one that reflects the locally-connected disk.  The local version
 * exists for small Hadoop instances and for testing.
 *
 * <p>
 *
 * All user code that may potentially use the Hadoop Distributed
 * File System should be written to use a FileSystem object.  The
 * Hadoop DFS is a multi-machine system that appears as a single
 * disk.  It's useful because of its fault tolerance and potentially
 * very large capacity.
 *
 * <p>
 * The local implementation is {@link LocalFileSystem} and distributed
 * implementation is DistributedFileSystem.
 * ***************************************************************
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public abstract class FileSystem extends Configured implements Closeable {
    public static final String LCAZPMETLM = CommonConfigurationKeys.FS_DEFAULT_NAME_KEY;

    public static final String VYCIKQIJTI = CommonConfigurationKeys.FS_DEFAULT_NAME_DEFAULT;

    public static final Log DZPULTDFZF = LogFactory.getLog(FileSystem.class);

    /**
     * Priority of the FileSystem shutdown hook.
     */
    public static final int AEQJRTGPUW = 10;

    /**
     * FileSystem cache
     */
    static final FileSystem.Cache MWBGBWTFVO = new FileSystem.Cache();

    /**
     * The key this instance is stored under in the cache.
     */
    private FileSystem.Cache.Key RNSXLSVOSD;

    /**
     * Recording statistics per a FileSystem class
     */
    private static final Map<Class<? extends FileSystem>, FileSystem.Statistics> HFQDHKUNXS = new IdentityHashMap<Class<? extends FileSystem>, FileSystem.Statistics>();

    /**
     * The statistics for this file system.
     */
    protected FileSystem.Statistics TQCREIGYPB;

    /**
     * A cache of files that should be deleted when filsystem is closed
     * or the JVM is exited.
     */
    private Set<Path> NXRWXGGJFV = new TreeSet<Path>();

    boolean UIKQXBBVZG;

    /**
     * This method adds a file system for testing so that we can find it later. It
     * is only for testing.
     *
     * @param uri
     * 		the uri to store it under
     * @param conf
     * 		the configuration to store it under
     * @param fs
     * 		the file system to store
     * @throws IOException
     * 		
     */
    static void addFileSystemForTesting(URI GITKXPOHYP, Configuration OVQAEGDLXX, FileSystem MVKVCCZLEJ) throws IOException {
        FileSystem.MWBGBWTFVO.IKXXDIAEDG.put(new FileSystem.Cache.Key(GITKXPOHYP, OVQAEGDLXX), MVKVCCZLEJ);
    }

    /**
     * Get a filesystem instance based on the uri, the passed
     * configuration and the user
     *
     * @param uri
     * 		of the filesystem
     * @param conf
     * 		the configuration to use
     * @param user
     * 		to perform the get as
     * @return the filesystem instance
     * @throws IOException
     * 		
     * @throws InterruptedException
     * 		
     */
    public static FileSystem get(final URI HYCYQNERHG, final Configuration CTXQJDNQJV, final String CZLVLORHHA) throws IOException, InterruptedException {
        String KKNDEJOGJE = CTXQJDNQJV.get(KERBEROS_TICKET_CACHE_PATH);
        UserGroupInformation NGPWJJVZXK = UserGroupInformation.getBestUGI(KKNDEJOGJE, CZLVLORHHA);
        return NGPWJJVZXK.doAs(new PrivilegedExceptionAction<FileSystem>() {
            @Override
            public FileSystem run() throws IOException {
                return FileSystem.get(HYCYQNERHG, CTXQJDNQJV);
            }
        });
    }

    /**
     * Returns the configured filesystem implementation.
     *
     * @param conf
     * 		the configuration to use
     */
    public static FileSystem get(Configuration TFXMBIIQOE) throws IOException {
        return FileSystem.get(FileSystem.getDefaultUri(TFXMBIIQOE), TFXMBIIQOE);
    }

    /**
     * Get the default filesystem URI from a configuration.
     *
     * @param conf
     * 		the configuration to use
     * @return the uri of the default filesystem
     */
    public static URI getDefaultUri(Configuration ZJDQUWLMKW) {
        return URI.create(FileSystem.fixName(ZJDQUWLMKW.get(FileSystem.LCAZPMETLM, FileSystem.VYCIKQIJTI)));
    }

    /**
     * Set the default filesystem URI in a configuration.
     *
     * @param conf
     * 		the configuration to alter
     * @param uri
     * 		the new default filesystem uri
     */
    public static void setDefaultUri(Configuration IGKBYBSEGI, URI AFZXGAKDYQ) {
        IGKBYBSEGI.set(FileSystem.LCAZPMETLM, AFZXGAKDYQ.toString());
    }

    /**
     * Set the default filesystem URI in a configuration.
     *
     * @param conf
     * 		the configuration to alter
     * @param uri
     * 		the new default filesystem uri
     */
    public static void setDefaultUri(Configuration DCGSWZKPUB, String HJVEQHWKHI) {
        FileSystem.setDefaultUri(DCGSWZKPUB, URI.create(FileSystem.fixName(HJVEQHWKHI)));
    }

    /**
     * Called after a new FileSystem instance is constructed.
     *
     * @param name
     * 		a uri whose authority section names the host, port, etc.
     * 		for this FileSystem
     * @param conf
     * 		the configuration
     */
    public void initialize(URI LASILDDKDN, Configuration XVJKJHMXZB) throws IOException {
        TQCREIGYPB = FileSystem.getStatistics(LASILDDKDN.getScheme(), getClass());
        UIKQXBBVZG = XVJKJHMXZB.getBoolean(FS_CLIENT_RESOLVE_REMOTE_SYMLINKS_KEY, FS_CLIENT_RESOLVE_REMOTE_SYMLINKS_DEFAULT);
    }

    /**
     * Return the protocol scheme for the FileSystem.
     * <p/>
     * This implementation throws an <code>UnsupportedOperationException</code>.
     *
     * @return the protocol scheme for the FileSystem.
     */
    public String getScheme() {
        throw new UnsupportedOperationException(("Not implemented by the " + getClass().getSimpleName()) + " FileSystem implementation");
    }

    /**
     * Returns a URI whose scheme and authority identify this FileSystem.
     */
    public abstract URI getUri();

    /**
     * Return a canonicalized form of this FileSystem's URI.
     *
     * The default implementation simply calls {@link #canonicalizeUri(URI)}
     * on the filesystem's own URI, so subclasses typically only need to
     * implement that method.
     *
     * @see #canonicalizeUri(URI)
     */
    protected URI getCanonicalUri() {
        return canonicalizeUri(getUri());
    }

    /**
     * Canonicalize the given URI.
     *
     * This is filesystem-dependent, but may for example consist of
     * canonicalizing the hostname using DNS and adding the default
     * port if not specified.
     *
     * The default implementation simply fills in the default port if
     * not specified and if the filesystem has a default port.
     *
     * @return URI
     * @see NetUtils#getCanonicalUri(URI, int)
     */
    protected URI canonicalizeUri(URI BBVKIZWDQC) {
        if ((BBVKIZWDQC.getPort() == (-1)) && (getDefaultPort() > 0)) {
            // reconstruct the uri with the default port set
            try {
                BBVKIZWDQC = new URI(BBVKIZWDQC.getScheme(), BBVKIZWDQC.getUserInfo(), BBVKIZWDQC.getHost(), getDefaultPort(), BBVKIZWDQC.getPath(), BBVKIZWDQC.getQuery(), BBVKIZWDQC.getFragment());
            } catch (URISyntaxException e) {
                // Should never happen!
                throw new AssertionError("Valid URI became unparseable: " + BBVKIZWDQC);
            }
        }
        return BBVKIZWDQC;
    }

    /**
     * Get the default port for this file system.
     *
     * @return the default port or 0 if there isn't one
     */
    protected int getDefaultPort() {
        return 0;
    }

    protected static FileSystem getFSofPath(final Path LIKLUOQSGO, final Configuration PTLOWOQTRN) throws IOException, UnsupportedFileSystemException {
        LIKLUOQSGO.checkNotSchemeWithRelative();
        LIKLUOQSGO.checkNotRelative();
        // Uses the default file system if not fully qualified
        return FileSystem.get(LIKLUOQSGO.toUri(), PTLOWOQTRN);
    }

    /**
     * Get a canonical service name for this file system.  The token cache is
     * the only user of the canonical service name, and uses it to lookup this
     * filesystem's service tokens.
     * If file system provides a token of its own then it must have a canonical
     * name, otherwise canonical name can be null.
     *
     * Default Impl: If the file system has child file systems
     * (such as an embedded file system) then it is assumed that the fs has no
     * tokens of its own and hence returns a null name; otherwise a service
     * name is built using Uri and port.
     *
     * @return a service string that uniquely identifies this file system, null
    if the filesystem does not implement tokens
     * @see SecurityUtil#buildDTServiceName(URI, int)
     */
    @InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
    public String getCanonicalServiceName() {
        return getChildFileSystems() == null ? SecurityUtil.buildDTServiceName(getUri(), getDefaultPort()) : null;
    }

    /**
     *
     *
     * @deprecated call #getUri() instead.
     */
    @Deprecated
    public String getName() {
        return getUri().toString();
    }

    /**
     *
     *
     * @deprecated call #get(URI,Configuration) instead.
     */
    @Deprecated
    public static FileSystem getNamed(String AJFPQQHMWX, Configuration JTQVZYDMOW) throws IOException {
        return FileSystem.get(URI.create(FileSystem.fixName(AJFPQQHMWX)), JTQVZYDMOW);
    }

    /**
     * Update old-format filesystem names, for back-compatibility.  This should
     * eventually be replaced with a checkName() method that throws an exception
     * for old-format names.
     */
    private static String fixName(String EIPWZFWEFV) {
        // convert old-format name to new-format name
        if (EIPWZFWEFV.equals("local")) {
            // "local" is now "file:///".
            FileSystem.DZPULTDFZF.warn("\"local\" is a deprecated filesystem name." + " Use \"file:///\" instead.");
            EIPWZFWEFV = "file:///";
        } else
            if (EIPWZFWEFV.indexOf('/') == (-1)) {
                // unqualified is "hdfs://"
                FileSystem.DZPULTDFZF.warn((((("\"" + EIPWZFWEFV) + "\" is a deprecated filesystem name.") + " Use \"hdfs://") + EIPWZFWEFV) + "/\" instead.");
                EIPWZFWEFV = "hdfs://" + EIPWZFWEFV;
            }

        return EIPWZFWEFV;
    }

    /**
     * Get the local file system.
     *
     * @param conf
     * 		the configuration to configure the file system with
     * @return a LocalFileSystem
     */
    public static LocalFileSystem getLocal(Configuration NZQJWFCSWJ) throws IOException {
        return ((LocalFileSystem) (FileSystem.get(NAME, NZQJWFCSWJ)));
    }

    /**
     * Returns the FileSystem for this URI's scheme and authority.  The scheme
     * of the URI determines a configuration property name,
     * <tt>fs.<i>scheme</i>.class</tt> whose value names the FileSystem class.
     * The entire URI is passed to the FileSystem instance's initialize method.
     */
    public static FileSystem get(URI CAVSMDYVGS, Configuration BLPMLQVKZO) throws IOException {
        String DMBQQMWBBS = CAVSMDYVGS.getScheme();
        String GDAFYCSMIU = CAVSMDYVGS.getAuthority();
        if ((DMBQQMWBBS == null) && (GDAFYCSMIU == null)) {
            // use default FS
            return FileSystem.get(BLPMLQVKZO);
        }
        if ((DMBQQMWBBS != null) && (GDAFYCSMIU == null)) {
            // no authority
            URI RBLIITGKWP = FileSystem.getDefaultUri(BLPMLQVKZO);
            if (DMBQQMWBBS.equals(RBLIITGKWP.getScheme())// if scheme matches default
             && (RBLIITGKWP.getAuthority() != null)) {
                // & default has authority
                return FileSystem.get(RBLIITGKWP, BLPMLQVKZO);// return default

            }
        }
        String SKTQPVIQWD = String.format("fs.%s.impl.disable.cache", DMBQQMWBBS);
        if (BLPMLQVKZO.getBoolean(SKTQPVIQWD, false)) {
            return FileSystem.createFileSystem(CAVSMDYVGS, BLPMLQVKZO);
        }
        return FileSystem.MWBGBWTFVO.get(CAVSMDYVGS, BLPMLQVKZO);
    }

    /**
     * Returns the FileSystem for this URI's scheme and authority and the
     * passed user. Internally invokes {@link #newInstance(URI, Configuration)}
     *
     * @param uri
     * 		of the filesystem
     * @param conf
     * 		the configuration to use
     * @param user
     * 		to perform the get as
     * @return filesystem instance
     * @throws IOException
     * 		
     * @throws InterruptedException
     * 		
     */
    public static FileSystem newInstance(final URI XPIGKXRWWA, final Configuration ACHOXXPAMS, final String IXKJBEBCPV) throws IOException, InterruptedException {
        String DVBWYDPIBQ = ACHOXXPAMS.get(KERBEROS_TICKET_CACHE_PATH);
        UserGroupInformation UWEMQCUKLU = UserGroupInformation.getBestUGI(DVBWYDPIBQ, IXKJBEBCPV);
        return UWEMQCUKLU.doAs(new PrivilegedExceptionAction<FileSystem>() {
            @Override
            public FileSystem run() throws IOException {
                return FileSystem.newInstance(XPIGKXRWWA, ACHOXXPAMS);
            }
        });
    }

    /**
     * Returns the FileSystem for this URI's scheme and authority.  The scheme
     * of the URI determines a configuration property name,
     * <tt>fs.<i>scheme</i>.class</tt> whose value names the FileSystem class.
     * The entire URI is passed to the FileSystem instance's initialize method.
     * This always returns a new FileSystem object.
     */
    public static FileSystem newInstance(URI LFTEWEQTOC, Configuration NKIJKVMNLX) throws IOException {
        String TWROYQOKSY = LFTEWEQTOC.getScheme();
        String ICMGIJHYDI = LFTEWEQTOC.getAuthority();
        if (TWROYQOKSY == null) {
            // no scheme: use default FS
            return FileSystem.newInstance(NKIJKVMNLX);
        }
        if (ICMGIJHYDI == null) {
            // no authority
            URI SOXELEYBXU = FileSystem.getDefaultUri(NKIJKVMNLX);
            if (TWROYQOKSY.equals(SOXELEYBXU.getScheme())// if scheme matches default
             && (SOXELEYBXU.getAuthority() != null)) {
                // & default has authority
                return FileSystem.newInstance(SOXELEYBXU, NKIJKVMNLX);// return default

            }
        }
        return FileSystem.MWBGBWTFVO.getUnique(LFTEWEQTOC, NKIJKVMNLX);
    }

    /**
     * Returns a unique configured filesystem implementation.
     * This always returns a new FileSystem object.
     *
     * @param conf
     * 		the configuration to use
     */
    public static FileSystem newInstance(Configuration FFYRUPWHHN) throws IOException {
        return FileSystem.newInstance(FileSystem.getDefaultUri(FFYRUPWHHN), FFYRUPWHHN);
    }

    /**
     * Get a unique local file system object
     *
     * @param conf
     * 		the configuration to configure the file system with
     * @return a LocalFileSystem
    This always returns a new FileSystem object.
     */
    public static LocalFileSystem newInstanceLocal(Configuration AQZBHRSEBJ) throws IOException {
        return ((LocalFileSystem) (FileSystem.newInstance(NAME, AQZBHRSEBJ)));
    }

    /**
     * Close all cached filesystems. Be sure those filesystems are not
     * used anymore.
     *
     * @throws IOException
     * 		
     */
    public static void closeAll() throws IOException {
        FileSystem.MWBGBWTFVO.closeAll();
    }

    /**
     * Close all cached filesystems for a given UGI. Be sure those filesystems
     * are not used anymore.
     *
     * @param ugi
     * 		user group info to close
     * @throws IOException
     * 		
     */
    public static void closeAllForUGI(UserGroupInformation LBIJZYGYNX) throws IOException {
        FileSystem.MWBGBWTFVO.closeAll(LBIJZYGYNX);
    }

    /**
     * Make sure that a path specifies a FileSystem.
     *
     * @param path
     * 		to use
     */
    public Path makeQualified(Path GJNICPAABI) {
        checkPath(GJNICPAABI);
        return GJNICPAABI.makeQualified(this.getUri(), this.getWorkingDirectory());
    }

    /**
     * Get a new delegation token for this file system.
     * This is an internal method that should have been declared protected
     * but wasn't historically.
     * Callers should use {@link #addDelegationTokens(String, Credentials)}
     *
     * @param renewer
     * 		the account name that is allowed to renew the token.
     * @return a new delegation token
     * @throws IOException
     * 		
     */
    @Private
    public Token<?> getDelegationToken(String DVWRPOBKTB) throws IOException {
        return null;
    }

    /**
     * Obtain all delegation tokens used by this FileSystem that are not
     * already present in the given Credentials.  Existing tokens will neither
     * be verified as valid nor having the given renewer.  Missing tokens will
     * be acquired and added to the given Credentials.
     *
     * Default Impl: works for simple fs with its own token
     * and also for an embedded fs whose tokens are those of its
     * children file system (i.e. the embedded fs has not tokens of its
     * own).
     *
     * @param renewer
     * 		the user allowed to renew the delegation tokens
     * @param credentials
     * 		cache in which to add new delegation tokens
     * @return list of new delegation tokens
     * @throws IOException
     * 		
     */
    @InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
    public Token<?>[] addDelegationTokens(final String AODOHIUKXB, Credentials MKCNWDRDSS) throws IOException {
        if (MKCNWDRDSS == null) {
            MKCNWDRDSS = new Credentials();
        }
        final List<Token<?>> IVZQUSXEEV = new ArrayList<Token<?>>();
        collectDelegationTokens(AODOHIUKXB, MKCNWDRDSS, IVZQUSXEEV);
        return IVZQUSXEEV.toArray(new Token<?>[IVZQUSXEEV.size()]);
    }

    /**
     * Recursively obtain the tokens for this FileSystem and all descended
     * FileSystems as determined by getChildFileSystems().
     *
     * @param renewer
     * 		the user allowed to renew the delegation tokens
     * @param credentials
     * 		cache in which to add the new delegation tokens
     * @param tokens
     * 		list in which to add acquired tokens
     * @throws IOException
     * 		
     */
    private void collectDelegationTokens(final String VEAYEFPTLD, final Credentials XPWWIEJJMY, final List<Token<?>> XTQFMLKJFO) throws IOException {
        final String PJDJZJDCZE = getCanonicalServiceName();
        // Collect token of the this filesystem and then of its embedded children
        if (PJDJZJDCZE != null) {
            // fs has token, grab it
            final Text MGXGPPSDBE = new Text(PJDJZJDCZE);
            Token<?> QYOLOEVIKC = XPWWIEJJMY.getToken(MGXGPPSDBE);
            if (QYOLOEVIKC == null) {
                QYOLOEVIKC = getDelegationToken(VEAYEFPTLD);
                if (QYOLOEVIKC != null) {
                    XTQFMLKJFO.add(QYOLOEVIKC);
                    XPWWIEJJMY.addToken(MGXGPPSDBE, QYOLOEVIKC);
                }
            }
        }
        // Now collect the tokens from the children
        final FileSystem[] BZOXKTASIZ = getChildFileSystems();
        if (BZOXKTASIZ != null) {
            for (final FileSystem GMOADZSCUX : BZOXKTASIZ) {
                GMOADZSCUX.collectDelegationTokens(VEAYEFPTLD, XPWWIEJJMY, XTQFMLKJFO);
            }
        }
    }

    /**
     * Get all the immediate child FileSystems embedded in this FileSystem.
     * It does not recurse and get grand children.  If a FileSystem
     * has multiple child FileSystems, then it should return a unique list
     * of those FileSystems.  Default is to return null to signify no children.
     *
     * @return FileSystems used by this FileSystem
     */
    @InterfaceAudience.LimitedPrivate({ "HDFS" })
    @VisibleForTesting
    public FileSystem[] getChildFileSystems() {
        return null;
    }

    /**
     * create a file with the provided permission
     * The permission of the file is set to be the provided permission as in
     * setPermission, not permission&~umask
     *
     * It is implemented using two RPCs. It is understood that it is inefficient,
     * but the implementation is thread-safe. The other option is to change the
     * value of umask in configuration to be 0, but it is not thread-safe.
     *
     * @param fs
     * 		file system handle
     * @param file
     * 		the name of the file to be created
     * @param permission
     * 		the permission of the file
     * @return an output stream
     * @throws IOException
     * 		
     */
    public static FSDataOutputStream create(FileSystem SGIFFVKZUU, Path QLEBAJYCEY, FsPermission EQRIOYJBNC) throws IOException {
        // create the file with default permission
        FSDataOutputStream KYTOQLRTSR = SGIFFVKZUU.create(QLEBAJYCEY);
        // set its permission to the supplied one
        SGIFFVKZUU.setPermission(QLEBAJYCEY, EQRIOYJBNC);
        return KYTOQLRTSR;
    }

    /**
     * create a directory with the provided permission
     * The permission of the directory is set to be the provided permission as in
     * setPermission, not permission&~umask
     *
     * @see #create(FileSystem, Path, FsPermission)
     * @param fs
     * 		file system handle
     * @param dir
     * 		the name of the directory to be created
     * @param permission
     * 		the permission of the directory
     * @return true if the directory creation succeeds; false otherwise
     * @throws IOException
     * 		
     */
    public static boolean mkdirs(FileSystem GUNWWAAGUH, Path ERDGGGUDKH, FsPermission WKHXJOAIZJ) throws IOException {
        // create the directory using the default permission
        boolean HWSXRJLHBD = GUNWWAAGUH.mkdirs(ERDGGGUDKH);
        // set its permission to be the supplied one
        GUNWWAAGUH.setPermission(ERDGGGUDKH, WKHXJOAIZJ);
        return HWSXRJLHBD;
    }

    // /////////////////////////////////////////////////////////////
    // FileSystem
    // /////////////////////////////////////////////////////////////
    protected FileSystem() {
        super(null);
    }

    /**
     * Check that a Path belongs to this FileSystem.
     *
     * @param path
     * 		to check
     */
    protected void checkPath(Path XISZRUOALN) {
        URI BDZXMYGLDB = XISZRUOALN.toUri();
        String LRWZDGWVKS = BDZXMYGLDB.getScheme();
        // fs is relative
        if (LRWZDGWVKS == null)
            return;

        URI WBIHVSDITD = getCanonicalUri();
        String ENPOKUESDD = WBIHVSDITD.getScheme();
        // authority and scheme are not case sensitive
        if (ENPOKUESDD.equalsIgnoreCase(LRWZDGWVKS)) {
            // schemes match
            String NMOTSQSILA = WBIHVSDITD.getAuthority();
            String TFJKGRUODT = BDZXMYGLDB.getAuthority();
            if ((TFJKGRUODT == null) && // path's authority is null
            (NMOTSQSILA != null)) {
                // fs has an authority
                URI XSDPDJLYBO = FileSystem.getDefaultUri(getConf());
                if (ENPOKUESDD.equalsIgnoreCase(XSDPDJLYBO.getScheme())) {
                    BDZXMYGLDB = XSDPDJLYBO;// schemes match, so use this uri instead

                } else {
                    BDZXMYGLDB = null;// can't determine auth of the path

                }
            }
            if (BDZXMYGLDB != null) {
                // canonicalize uri before comparing with this fs
                BDZXMYGLDB = canonicalizeUri(BDZXMYGLDB);
                TFJKGRUODT = BDZXMYGLDB.getAuthority();
                if ((NMOTSQSILA == TFJKGRUODT)// authorities match
                 || ((NMOTSQSILA != null) && NMOTSQSILA.equalsIgnoreCase(TFJKGRUODT)))
                    return;

            }
        }
        throw new IllegalArgumentException((("Wrong FS: " + XISZRUOALN) + ", expected: ") + this.getUri());
    }

    /**
     * Return an array containing hostnames, offset and size of
     * portions of the given file.  For a nonexistent
     * file or regions, null will be returned.
     *
     * This call is most helpful with DFS, where it returns
     * hostnames of machines that contain the given file.
     *
     * The FileSystem will simply return an elt containing 'localhost'.
     *
     * @param file
     * 		FilesStatus to get data from
     * @param start
     * 		offset into the given file
     * @param len
     * 		length for which to get locations for
     */
    public BlockLocation[] getFileBlockLocations(FileStatus MODRPQYMMK, long DRBJTOQONR, long LZKHDUWHJX) throws IOException {
        if (MODRPQYMMK == null) {
            return null;
        }
        if ((DRBJTOQONR < 0) || (LZKHDUWHJX < 0)) {
            throw new IllegalArgumentException("Invalid start or len parameter");
        }
        if (MODRPQYMMK.getLen() <= DRBJTOQONR) {
            return new BlockLocation[0];
        }
        String[] NRSMTYPNDL = new String[]{ "localhost:50010" };
        String[] MIEDMJNBSH = new String[]{ "localhost" };
        return new BlockLocation[]{ new BlockLocation(NRSMTYPNDL, MIEDMJNBSH, 0, MODRPQYMMK.getLen()) };
    }

    /**
     * Return an array containing hostnames, offset and size of
     * portions of the given file.  For a nonexistent
     * file or regions, null will be returned.
     *
     * This call is most helpful with DFS, where it returns
     * hostnames of machines that contain the given file.
     *
     * The FileSystem will simply return an elt containing 'localhost'.
     *
     * @param p
     * 		path is used to identify an FS since an FS could have
     * 		another FS that it could be delegating the call to
     * @param start
     * 		offset into the given file
     * @param len
     * 		length for which to get locations for
     */
    public BlockLocation[] getFileBlockLocations(Path DKKWEWEFSB, long WRVAXTJHSR, long CCDTUOFULX) throws IOException {
        if (DKKWEWEFSB == null) {
            throw new NullPointerException();
        }
        FileStatus UDACUSYQHN = getFileStatus(DKKWEWEFSB);
        return getFileBlockLocations(UDACUSYQHN, WRVAXTJHSR, CCDTUOFULX);
    }

    /**
     * Return a set of server default configuration values
     *
     * @return server default configuration values
     * @throws IOException
     * 		
     * @deprecated use {@link #getServerDefaults(Path)} instead
     */
    @Deprecated
    public FsServerDefaults getServerDefaults() throws IOException {
        Configuration PFPSOHZJPV = getConf();
        // CRC32 is chosen as default as it is available in all
        // releases that support checksum.
        // The client trash configuration is ignored.
        return new FsServerDefaults(getDefaultBlockSize(), PFPSOHZJPV.getInt("io.bytes.per.checksum", 512), 64 * 1024, getDefaultReplication(), PFPSOHZJPV.getInt("io.file.buffer.size", 4096), false, CommonConfigurationKeysPublic.FS_TRASH_INTERVAL_DEFAULT, Type.CRC32);
    }

    /**
     * Return a set of server default configuration values
     *
     * @param p
     * 		path is used to identify an FS since an FS could have
     * 		another FS that it could be delegating the call to
     * @return server default configuration values
     * @throws IOException
     * 		
     */
    public FsServerDefaults getServerDefaults(Path KZKVUIHUEZ) throws IOException {
        return getServerDefaults();
    }

    /**
     * Return the fully-qualified path of path f resolving the path
     * through any symlinks or mount point
     *
     * @param p
     * 		path to be resolved
     * @return fully qualified path
     * @throws FileNotFoundException
     * 		
     */
    public Path resolvePath(final Path IBGGZORGBP) throws IOException {
        checkPath(IBGGZORGBP);
        return getFileStatus(IBGGZORGBP).getPath();
    }

    /**
     * Opens an FSDataInputStream at the indicated Path.
     *
     * @param f
     * 		the file name to open
     * @param bufferSize
     * 		the size of the buffer to be used.
     */
    public abstract FSDataInputStream open(Path ZRVFOSKKXS, int RFFCZWFOKB) throws IOException;

    /**
     * Opens an FSDataInputStream at the indicated Path.
     *
     * @param f
     * 		the file to open
     */
    public FSDataInputStream open(Path KUWNFQWPRT) throws IOException {
        return open(KUWNFQWPRT, getConf().getInt("io.file.buffer.size", 4096));
    }

    /**
     * Create an FSDataOutputStream at the indicated Path.
     * Files are overwritten by default.
     *
     * @param f
     * 		the file to create
     */
    public FSDataOutputStream create(Path KDGJSVVIEH) throws IOException {
        return create(KDGJSVVIEH, true);
    }

    /**
     * Create an FSDataOutputStream at the indicated Path.
     *
     * @param f
     * 		the file to create
     * @param overwrite
     * 		if a file with this name already exists, then if true,
     * 		the file will be overwritten, and if false an exception will be thrown.
     */
    public FSDataOutputStream create(Path JZABSOUWPK, boolean KNKAUYIDIT) throws IOException {
        return create(JZABSOUWPK, KNKAUYIDIT, getConf().getInt("io.file.buffer.size", 4096), getDefaultReplication(JZABSOUWPK), getDefaultBlockSize(JZABSOUWPK));
    }

    /**
     * Create an FSDataOutputStream at the indicated Path with write-progress
     * reporting.
     * Files are overwritten by default.
     *
     * @param f
     * 		the file to create
     * @param progress
     * 		to report progress
     */
    public FSDataOutputStream create(Path TSOACCZDKJ, Progressable TEYEMJTTIJ) throws IOException {
        return create(TSOACCZDKJ, true, getConf().getInt("io.file.buffer.size", 4096), getDefaultReplication(TSOACCZDKJ), getDefaultBlockSize(TSOACCZDKJ), TEYEMJTTIJ);
    }

    /**
     * Create an FSDataOutputStream at the indicated Path.
     * Files are overwritten by default.
     *
     * @param f
     * 		the file to create
     * @param replication
     * 		the replication factor
     */
    public FSDataOutputStream create(Path MHDMREPPHN, short CDWLOOROBO) throws IOException {
        return create(MHDMREPPHN, true, getConf().getInt("io.file.buffer.size", 4096), CDWLOOROBO, getDefaultBlockSize(MHDMREPPHN));
    }

    /**
     * Create an FSDataOutputStream at the indicated Path with write-progress
     * reporting.
     * Files are overwritten by default.
     *
     * @param f
     * 		the file to create
     * @param replication
     * 		the replication factor
     * @param progress
     * 		to report progress
     */
    public FSDataOutputStream create(Path BTDNFYTMOM, short FFGDBXLPPI, Progressable OCHADQESIH) throws IOException {
        return create(BTDNFYTMOM, true, getConf().getInt(CommonConfigurationKeysPublic.IO_FILE_BUFFER_SIZE_KEY, CommonConfigurationKeysPublic.IO_FILE_BUFFER_SIZE_DEFAULT), FFGDBXLPPI, getDefaultBlockSize(BTDNFYTMOM), OCHADQESIH);
    }

    /**
     * Create an FSDataOutputStream at the indicated Path.
     *
     * @param f
     * 		the file name to create
     * @param overwrite
     * 		if a file with this name already exists, then if true,
     * 		the file will be overwritten, and if false an error will be thrown.
     * @param bufferSize
     * 		the size of the buffer to be used.
     */
    public FSDataOutputStream create(Path RBNXOSGWHY, boolean OILQWLYPPB, int HBULRIBWVI) throws IOException {
        return create(RBNXOSGWHY, OILQWLYPPB, HBULRIBWVI, getDefaultReplication(RBNXOSGWHY), getDefaultBlockSize(RBNXOSGWHY));
    }

    /**
     * Create an FSDataOutputStream at the indicated Path with write-progress
     * reporting.
     *
     * @param f
     * 		the path of the file to open
     * @param overwrite
     * 		if a file with this name already exists, then if true,
     * 		the file will be overwritten, and if false an error will be thrown.
     * @param bufferSize
     * 		the size of the buffer to be used.
     */
    public FSDataOutputStream create(Path HQYPWCKXXO, boolean HCHKRVRXIV, int AEQYFLLTQR, Progressable ZVAJFZRVJO) throws IOException {
        return create(HQYPWCKXXO, HCHKRVRXIV, AEQYFLLTQR, getDefaultReplication(HQYPWCKXXO), getDefaultBlockSize(HQYPWCKXXO), ZVAJFZRVJO);
    }

    /**
     * Create an FSDataOutputStream at the indicated Path.
     *
     * @param f
     * 		the file name to open
     * @param overwrite
     * 		if a file with this name already exists, then if true,
     * 		the file will be overwritten, and if false an error will be thrown.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param replication
     * 		required block replication for the file.
     */
    public FSDataOutputStream create(Path YWSBFYYAFC, boolean EQMXJPXPDG, int BHAHOREPPZ, short ZKEYZVBBOU, long ANAPHIWWFP) throws IOException {
        return create(YWSBFYYAFC, EQMXJPXPDG, BHAHOREPPZ, ZKEYZVBBOU, ANAPHIWWFP, null);
    }

    /**
     * Create an FSDataOutputStream at the indicated Path with write-progress
     * reporting.
     *
     * @param f
     * 		the file name to open
     * @param overwrite
     * 		if a file with this name already exists, then if true,
     * 		the file will be overwritten, and if false an error will be thrown.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param replication
     * 		required block replication for the file.
     */
    public FSDataOutputStream create(Path HAUCRTLVDH, boolean IAFKIWSSJB, int BAZYPVZDIS, short HFCKCLDEOE, long QLYDQEGTTD, Progressable FRLXXLHTKN) throws IOException {
        return this.create(HAUCRTLVDH, FsPermission.getFileDefault().applyUMask(FsPermission.getUMask(getConf())), IAFKIWSSJB, BAZYPVZDIS, HFCKCLDEOE, QLYDQEGTTD, FRLXXLHTKN);
    }

    /**
     * Create an FSDataOutputStream at the indicated Path with write-progress
     * reporting.
     *
     * @param f
     * 		the file name to open
     * @param permission
     * 		
     * @param overwrite
     * 		if a file with this name already exists, then if true,
     * 		the file will be overwritten, and if false an error will be thrown.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param replication
     * 		required block replication for the file.
     * @param blockSize
     * 		
     * @param progress
     * 		
     * @throws IOException
     * 		
     * @see #setPermission(Path, FsPermission)
     */
    public abstract FSDataOutputStream create(Path GGAVZQCBIG, FsPermission MGODFOCVKV, boolean PSTVPQIIQU, int IEEWFJNKFV, short LPYRZUJEOQ, long VYQRKJWCPL, Progressable CUEKRDAMMU) throws IOException;

    /**
     * Create an FSDataOutputStream at the indicated Path with write-progress
     * reporting.
     *
     * @param f
     * 		the file name to open
     * @param permission
     * 		
     * @param flags
     * 		{@link CreateFlag}s to use for this stream.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param replication
     * 		required block replication for the file.
     * @param blockSize
     * 		
     * @param progress
     * 		
     * @throws IOException
     * 		
     * @see #setPermission(Path, FsPermission)
     */
    public FSDataOutputStream create(Path MXWARACXSI, FsPermission HMAPEHQQEU, EnumSet<CreateFlag> KWHDAQOHRW, int INXZXGFYMZ, short HAZAJPGWAF, long XAHPDOBFKK, Progressable KVVMXSPTGV) throws IOException {
        return create(MXWARACXSI, HMAPEHQQEU, KWHDAQOHRW, INXZXGFYMZ, HAZAJPGWAF, XAHPDOBFKK, KVVMXSPTGV, null);
    }

    /**
     * Create an FSDataOutputStream at the indicated Path with a custom
     * checksum option
     *
     * @param f
     * 		the file name to open
     * @param permission
     * 		
     * @param flags
     * 		{@link CreateFlag}s to use for this stream.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param replication
     * 		required block replication for the file.
     * @param blockSize
     * 		
     * @param progress
     * 		
     * @param checksumOpt
     * 		checksum parameter. If null, the values
     * 		found in conf will be used.
     * @throws IOException
     * 		
     * @see #setPermission(Path, FsPermission)
     */
    public FSDataOutputStream create(Path HXQCTPQNAT, FsPermission JJQROQNZVF, EnumSet<CreateFlag> ESNGXIHSOT, int GGLMEBMZXD, short FREFPOJKFR, long GXIDYUUMGI, Progressable PUXZYBHSNR, ChecksumOpt LFYIMNPSDG) throws IOException {
        // Checksum options are ignored by default. The file systems that
        // implement checksum need to override this method. The full
        // support is currently only available in DFS.
        return create(HXQCTPQNAT, JJQROQNZVF, ESNGXIHSOT.contains(OVERWRITE), GGLMEBMZXD, FREFPOJKFR, GXIDYUUMGI, PUXZYBHSNR);
    }

    /* .
    This create has been added to support the FileContext that processes
    the permission
    with umask before calling this method.
    This a temporary method added to support the transition from FileSystem
    to FileContext for user applications.
     */
    @Deprecated
    protected FSDataOutputStream primitiveCreate(Path OZWTYADEQL, FsPermission QYUFVLFZPU, EnumSet<CreateFlag> EJLJELGIMO, int UCABMYOULX, short XROALFCYZG, long YWXBUFBGKB, Progressable DJMISBNQJV, ChecksumOpt HTTIUXIOVI) throws IOException {
        boolean AJLAPIIRHU = exists(OZWTYADEQL);
        CreateFlag.validate(OZWTYADEQL, AJLAPIIRHU, EJLJELGIMO);
        // Default impl  assumes that permissions do not matter and
        // nor does the bytesPerChecksum  hence
        // calling the regular create is good enough.
        // FSs that implement permissions should override this.
        if (AJLAPIIRHU && EJLJELGIMO.contains(APPEND)) {
            return append(OZWTYADEQL, UCABMYOULX, DJMISBNQJV);
        }
        return this.create(OZWTYADEQL, QYUFVLFZPU, EJLJELGIMO.contains(OVERWRITE), UCABMYOULX, XROALFCYZG, YWXBUFBGKB, DJMISBNQJV);
    }

    /**
     * This version of the mkdirs method assumes that the permission is absolute.
     * It has been added to support the FileContext that processes the permission
     * with umask before calling this method.
     * This a temporary method added to support the transition from FileSystem
     * to FileContext for user applications.
     */
    @Deprecated
    protected boolean primitiveMkdir(Path TGRBPDWVWV, FsPermission XROJCFZYTH) throws IOException {
        // Default impl is to assume that permissions do not matter and hence
        // calling the regular mkdirs is good enough.
        // FSs that implement permissions should override this.
        return this.mkdirs(TGRBPDWVWV, XROJCFZYTH);
    }

    /**
     * This version of the mkdirs method assumes that the permission is absolute.
     * It has been added to support the FileContext that processes the permission
     * with umask before calling this method.
     * This a temporary method added to support the transition from FileSystem
     * to FileContext for user applications.
     */
    @Deprecated
    protected void primitiveMkdir(Path GMQRMQNIZP, FsPermission DZTKEPXZOU, boolean ZNMJFNBBDY) throws IOException {
        if (!ZNMJFNBBDY) {
            // parent must exist.
            // since the this.mkdirs makes parent dirs automatically
            // we must throw exception if parent does not exist.
            final FileStatus CBLRWBGYCA = getFileStatus(GMQRMQNIZP.getParent());
            if (CBLRWBGYCA == null) {
                throw new FileNotFoundException("Missing parent:" + GMQRMQNIZP);
            }
            if (!CBLRWBGYCA.isDirectory()) {
                throw new ParentNotDirectoryException("parent is not a dir");
            }
            // parent does exist - go ahead with mkdir of leaf
        }
        // Default impl is to assume that permissions do not matter and hence
        // calling the regular mkdirs is good enough.
        // FSs that implement permissions should override this.
        if (!this.mkdirs(GMQRMQNIZP, DZTKEPXZOU)) {
            throw new IOException(("mkdir of " + GMQRMQNIZP) + " failed");
        }
    }

    /**
     * Opens an FSDataOutputStream at the indicated Path with write-progress
     * reporting. Same as create(), except fails if parent directory doesn't
     * already exist.
     *
     * @param f
     * 		the file name to open
     * @param overwrite
     * 		if a file with this name already exists, then if true,
     * 		the file will be overwritten, and if false an error will be thrown.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param replication
     * 		required block replication for the file.
     * @param blockSize
     * 		
     * @param progress
     * 		
     * @throws IOException
     * 		
     * @see #setPermission(Path, FsPermission)
     * @deprecated API only for 0.20-append
     */
    @Deprecated
    public FSDataOutputStream createNonRecursive(Path XFFVPIAEBO, boolean OOEOUCLSUX, int XWXOSSKHAJ, short QUTULXMMPI, long GSACHCMVCJ, Progressable YPADVOQSFJ) throws IOException {
        return this.createNonRecursive(XFFVPIAEBO, FsPermission.getFileDefault(), OOEOUCLSUX, XWXOSSKHAJ, QUTULXMMPI, GSACHCMVCJ, YPADVOQSFJ);
    }

    /**
     * Opens an FSDataOutputStream at the indicated Path with write-progress
     * reporting. Same as create(), except fails if parent directory doesn't
     * already exist.
     *
     * @param f
     * 		the file name to open
     * @param permission
     * 		
     * @param overwrite
     * 		if a file with this name already exists, then if true,
     * 		the file will be overwritten, and if false an error will be thrown.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param replication
     * 		required block replication for the file.
     * @param blockSize
     * 		
     * @param progress
     * 		
     * @throws IOException
     * 		
     * @see #setPermission(Path, FsPermission)
     * @deprecated API only for 0.20-append
     */
    @Deprecated
    public FSDataOutputStream createNonRecursive(Path VPOEGPVHRC, FsPermission AANOJRNIXP, boolean CTFUTVKUGR, int KRABHNHLLN, short ESTXPLVAFN, long KDDYNGNHNX, Progressable GVDSZANOGR) throws IOException {
        return createNonRecursive(VPOEGPVHRC, AANOJRNIXP, CTFUTVKUGR ? EnumSet.of(CREATE, OVERWRITE) : EnumSet.of(CREATE), KRABHNHLLN, ESTXPLVAFN, KDDYNGNHNX, GVDSZANOGR);
    }

    /**
     * Opens an FSDataOutputStream at the indicated Path with write-progress
     * reporting. Same as create(), except fails if parent directory doesn't
     * already exist.
     *
     * @param f
     * 		the file name to open
     * @param permission
     * 		
     * @param flags
     * 		{@link CreateFlag}s to use for this stream.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param replication
     * 		required block replication for the file.
     * @param blockSize
     * 		
     * @param progress
     * 		
     * @throws IOException
     * 		
     * @see #setPermission(Path, FsPermission)
     * @deprecated API only for 0.20-append
     */
    @Deprecated
    public FSDataOutputStream createNonRecursive(Path PBYTPAPNDE, FsPermission JWDLSPFBQM, EnumSet<CreateFlag> LLQGPFGHCA, int YDRCCACUMQ, short WGUOXCVOUJ, long CCBKZDWQPY, Progressable KWXGJXHAOY) throws IOException {
        throw new IOException("createNonRecursive unsupported for this filesystem " + this.getClass());
    }

    /**
     * Creates the given Path as a brand-new zero-length file.  If
     * create fails, or if it already existed, return false.
     *
     * @param f
     * 		path to use for create
     */
    public boolean createNewFile(Path EBTEFDKBQP) throws IOException {
        if (exists(EBTEFDKBQP)) {
            return false;
        } else {
            create(EBTEFDKBQP, false, getConf().getInt("io.file.buffer.size", 4096)).close();
            return true;
        }
    }

    /**
     * Append to an existing file (optional operation).
     * Same as append(f, getConf().getInt("io.file.buffer.size", 4096), null)
     *
     * @param f
     * 		the existing file to be appended.
     * @throws IOException
     * 		
     */
    public FSDataOutputStream append(Path IKLEGBDNXJ) throws IOException {
        return append(IKLEGBDNXJ, getConf().getInt("io.file.buffer.size", 4096), null);
    }

    /**
     * Append to an existing file (optional operation).
     * Same as append(f, bufferSize, null).
     *
     * @param f
     * 		the existing file to be appended.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @throws IOException
     * 		
     */
    public FSDataOutputStream append(Path NEOZCISAAJ, int WGXLCUFFRE) throws IOException {
        return append(NEOZCISAAJ, WGXLCUFFRE, null);
    }

    /**
     * Append to an existing file (optional operation).
     *
     * @param f
     * 		the existing file to be appended.
     * @param bufferSize
     * 		the size of the buffer to be used.
     * @param progress
     * 		for reporting progress if it is not null.
     * @throws IOException
     * 		
     */
    public abstract FSDataOutputStream append(Path OKKZYFHRUX, int TLBEMYAUFR, Progressable MZJLCWFTLA) throws IOException;

    /**
     * Concat existing files together.
     *
     * @param trg
     * 		the path to the target destination.
     * @param psrcs
     * 		the paths to the sources to use for the concatenation.
     * @throws IOException
     * 		
     */
    public void concat(final Path ERBLSBVALR, final Path[] QLWTTARWGM) throws IOException {
        throw new UnsupportedOperationException(("Not implemented by the " + getClass().getSimpleName()) + " FileSystem implementation");
    }

    /**
     * Get replication.
     *
     * @deprecated Use getFileStatus() instead
     * @param src
     * 		file name
     * @return file replication
     * @throws IOException
     * 		
     */
    @Deprecated
    public short getReplication(Path STWMEFYODM) throws IOException {
        return getFileStatus(STWMEFYODM).getReplication();
    }

    /**
     * Set replication for an existing file.
     *
     * @param src
     * 		file name
     * @param replication
     * 		new replication
     * @throws IOException
     * 		
     * @return true if successful;
    false if file does not exist or is a directory
     */
    public boolean setReplication(Path SLKOHZEFDJ, short BLPIIJHGLZ) throws IOException {
        return true;
    }

    /**
     * Renames Path src to Path dst.  Can take place on local fs
     * or remote DFS.
     *
     * @param src
     * 		path to be renamed
     * @param dst
     * 		new path after rename
     * @throws IOException
     * 		on failure
     * @return true if rename is successful
     */
    public abstract boolean rename(Path EAOPJWHPTP, Path BOEHVEYSLD) throws IOException;

    /**
     * Renames Path src to Path dst
     * <ul>
     * <li
     * <li>Fails if src is a file and dst is a directory.
     * <li>Fails if src is a directory and dst is a file.
     * <li>Fails if the parent of dst does not exist or is a file.
     * </ul>
     * <p>
     * If OVERWRITE option is not passed as an argument, rename fails
     * if the dst already exists.
     * <p>
     * If OVERWRITE option is passed as an argument, rename overwrites
     * the dst if it is a file or an empty directory. Rename fails if dst is
     * a non-empty directory.
     * <p>
     * Note that atomicity of rename is dependent on the file system
     * implementation. Please refer to the file system documentation for
     * details. This default implementation is non atomic.
     * <p>
     * This method is deprecated since it is a temporary method added to
     * support the transition from FileSystem to FileContext for user
     * applications.
     *
     * @param src
     * 		path to be renamed
     * @param dst
     * 		new path after rename
     * @throws IOException
     * 		on failure
     */
    @Deprecated
    protected void rename(final Path DBANLGPSPL, final Path TINWRGAMEX, final Rename... PYTVGEVWID) throws IOException {
        // Default implementation
        final FileStatus WEKGDOBKPA = getFileLinkStatus(DBANLGPSPL);
        if (WEKGDOBKPA == null) {
            throw new FileNotFoundException(("rename source " + DBANLGPSPL) + " not found.");
        }
        boolean ASFYCSYWBY = false;
        if (null != PYTVGEVWID) {
            for (Rename WWZNFLGEWZ : PYTVGEVWID) {
                if (WWZNFLGEWZ == Rename.OVERWRITE) {
                    ASFYCSYWBY = true;
                }
            }
        }
        FileStatus CEYBSMHQLY;
        try {
            CEYBSMHQLY = getFileLinkStatus(TINWRGAMEX);
        } catch (IOException e) {
            CEYBSMHQLY = null;
        }
        if (CEYBSMHQLY != null) {
            if (WEKGDOBKPA.isDirectory() != CEYBSMHQLY.isDirectory()) {
                throw new IOException(((("Source " + DBANLGPSPL) + " Destination ") + TINWRGAMEX) + " both should be either file or directory");
            }
            if (!ASFYCSYWBY) {
                throw new FileAlreadyExistsException(("rename destination " + TINWRGAMEX) + " already exists.");
            }
            // Delete the destination that is a file or an empty directory
            if (CEYBSMHQLY.isDirectory()) {
                FileStatus[] CMXPTWLVEF = listStatus(TINWRGAMEX);
                if ((CMXPTWLVEF != null) && (CMXPTWLVEF.length != 0)) {
                    throw new IOException("rename cannot overwrite non empty destination directory " + TINWRGAMEX);
                }
            }
            delete(TINWRGAMEX, false);
        } else {
            final Path NQBMNRFCIV = TINWRGAMEX.getParent();
            final FileStatus AAYJIWSDVB = getFileStatus(NQBMNRFCIV);
            if (AAYJIWSDVB == null) {
                throw new FileNotFoundException(("rename destination parent " + NQBMNRFCIV) + " not found.");
            }
            if (!AAYJIWSDVB.isDirectory()) {
                throw new ParentNotDirectoryException(("rename destination parent " + NQBMNRFCIV) + " is a file.");
            }
        }
        if (!rename(DBANLGPSPL, TINWRGAMEX)) {
            throw new IOException(((("rename from " + DBANLGPSPL) + " to ") + TINWRGAMEX) + " failed.");
        }
    }

    /**
     * Delete a file
     *
     * @deprecated Use {@link #delete(Path, boolean)} instead.
     */
    @Deprecated
    public boolean delete(Path RTDDAHPTKK) throws IOException {
        return delete(RTDDAHPTKK, true);
    }

    /**
     * Delete a file.
     *
     * @param f
     * 		the path to delete.
     * @param recursive
     * 		if path is a directory and set to
     * 		true, the directory is deleted else throws an exception. In
     * 		case of a file the recursive can be set to either true or false.
     * @return true if delete is successful else false.
     * @throws IOException
     * 		
     */
    public abstract boolean delete(Path TCQCEPXOJR, boolean RIRAVTXSKL) throws IOException;

    /**
     * Mark a path to be deleted when FileSystem is closed.
     * When the JVM shuts down,
     * all FileSystem objects will be closed automatically.
     * Then,
     * the marked path will be deleted as a result of closing the FileSystem.
     *
     * The path has to exist in the file system.
     *
     * @param f
     * 		the path to delete.
     * @return true if deleteOnExit is successful, otherwise false.
     * @throws IOException
     * 		
     */
    public boolean deleteOnExit(Path WTIDTLKPZP) throws IOException {
        if (!exists(WTIDTLKPZP)) {
            return false;
        }
        synchronized(NXRWXGGJFV) {
            NXRWXGGJFV.add(WTIDTLKPZP);
        }
        return true;
    }

    /**
     * Cancel the deletion of the path when the FileSystem is closed
     *
     * @param f
     * 		the path to cancel deletion
     */
    public boolean cancelDeleteOnExit(Path VCNNQXBWBX) {
        synchronized(NXRWXGGJFV) {
            return NXRWXGGJFV.remove(VCNNQXBWBX);
        }
    }

    /**
     * Delete all files that were marked as delete-on-exit. This recursively
     * deletes all files in the specified paths.
     */
    protected void processDeleteOnExit() {
        synchronized(NXRWXGGJFV) {
            for (Iterator<Path> SJVBNWFEDI = NXRWXGGJFV.iterator(); SJVBNWFEDI.hasNext();) {
                Path YRMRZPCQNZ = SJVBNWFEDI.next();
                try {
                    if (exists(YRMRZPCQNZ)) {
                        delete(YRMRZPCQNZ, true);
                    }
                } catch (IOException e) {
                    FileSystem.DZPULTDFZF.info("Ignoring failure to deleteOnExit for path " + YRMRZPCQNZ);
                }
                SJVBNWFEDI.remove();
            }
        }
    }

    /**
     * Check if exists.
     *
     * @param f
     * 		source file
     */
    public boolean exists(Path UYHSOKXOGD) throws IOException {
        try {
            return getFileStatus(UYHSOKXOGD) != null;
        } catch (FileNotFoundException e) {
            return false;
        }
    }

    /**
     * True iff the named path is a directory.
     * Note: Avoid using this method. Instead reuse the FileStatus
     * returned by getFileStatus() or listStatus() methods.
     *
     * @param f
     * 		path to check
     */
    public boolean isDirectory(Path LPGAVNGJYY) throws IOException {
        try {
            return getFileStatus(LPGAVNGJYY).isDirectory();
        } catch (FileNotFoundException e) {
            return false;// f does not exist

        }
    }

    /**
     * True iff the named path is a regular file.
     * Note: Avoid using this method. Instead reuse the FileStatus
     * returned by getFileStatus() or listStatus() methods.
     *
     * @param f
     * 		path to check
     */
    public boolean isFile(Path HACNXEOVHM) throws IOException {
        try {
            return getFileStatus(HACNXEOVHM).isFile();
        } catch (FileNotFoundException e) {
            return false;// f does not exist

        }
    }

    /**
     * The number of bytes in a file.
     */
    /**
     *
     *
     * @deprecated Use getFileStatus() instead
     */
    @Deprecated
    public long getLength(Path YPCEPUFHSA) throws IOException {
        return getFileStatus(YPCEPUFHSA).getLen();
    }

    /**
     * Return the {@link ContentSummary} of a given {@link Path}.
     *
     * @param f
     * 		path to use
     */
    public ContentSummary getContentSummary(Path OLXCKUAVEH) throws IOException {
        FileStatus APFFYVAFAY = getFileStatus(OLXCKUAVEH);
        if (APFFYVAFAY.isFile()) {
            // f is a file
            return new ContentSummary(APFFYVAFAY.getLen(), 1, 0);
        }
        // f is a directory
        long[] DMKGOAVCZL = new long[]{ 0, 0, 1 };
        for (FileStatus CYYPCDGSQY : listStatus(OLXCKUAVEH)) {
            ContentSummary XJQKJLHOUR = (CYYPCDGSQY.isDirectory()) ? getContentSummary(CYYPCDGSQY.getPath()) : new ContentSummary(CYYPCDGSQY.getLen(), 1, 0);
            DMKGOAVCZL[0] += XJQKJLHOUR.getLength();
            DMKGOAVCZL[1] += XJQKJLHOUR.getFileCount();
            DMKGOAVCZL[2] += XJQKJLHOUR.getDirectoryCount();
        }
        return new ContentSummary(DMKGOAVCZL[0], DMKGOAVCZL[1], DMKGOAVCZL[2]);
    }

    private static final PathFilter LPVXSIHDBK = new PathFilter() {
        @Override
        public boolean accept(Path file) {
            return true;
        }
    };

    /**
     * List the statuses of the files/directories in the given path if the path is
     * a directory.
     *
     * @param f
     * 		given path
     * @return the statuses of the files/directories in the given patch
     * @throws FileNotFoundException
     * 		when the path does not exist;
     * 		IOException see specific implementation
     */
    public abstract FileStatus[] listStatus(Path ZFSSKEZLDF) throws FileNotFoundException, IOException;

    /* Filter files/directories in the given path using the user-supplied path
    filter. Results are added to the given array <code>results</code>.
     */
    private void listStatus(ArrayList<FileStatus> ONWPEMMCAR, Path SCZBRUBLWW, PathFilter WLGOKBWVVL) throws FileNotFoundException, IOException {
        FileStatus[] KEXZBJMFAY = listStatus(SCZBRUBLWW);
        if (KEXZBJMFAY == null) {
            throw new IOException("Error accessing " + SCZBRUBLWW);
        }
        for (int ZDCCSOJLWV = 0; ZDCCSOJLWV < KEXZBJMFAY.length; ZDCCSOJLWV++) {
            if (WLGOKBWVVL.accept(KEXZBJMFAY[ZDCCSOJLWV].getPath())) {
                ONWPEMMCAR.add(KEXZBJMFAY[ZDCCSOJLWV]);
            }
        }
    }

    /**
     *
     *
     * @return an iterator over the corrupt files under the given path
    (may contain duplicates if a file has more than one corrupt block)
     * @throws IOException
     * 		
     */
    public RemoteIterator<Path> listCorruptFileBlocks(Path XZCTXYMFVG) throws IOException {
        throw new UnsupportedOperationException((getClass().getCanonicalName() + " does not support") + " listCorruptFileBlocks");
    }

    /**
     * Filter files/directories in the given path using the user-supplied path
     * filter.
     *
     * @param f
     * 		a path name
     * @param filter
     * 		the user-supplied path filter
     * @return an array of FileStatus objects for the files under the given path
    after applying the filter
     * @throws FileNotFoundException
     * 		when the path does not exist;
     * 		IOException see specific implementation
     */
    public FileStatus[] listStatus(Path ESJJJXOUDN, PathFilter GVFJRZWJVT) throws FileNotFoundException, IOException {
        ArrayList<FileStatus> FCKSBUBFJX = new ArrayList<FileStatus>();
        listStatus(FCKSBUBFJX, ESJJJXOUDN, GVFJRZWJVT);
        return FCKSBUBFJX.toArray(new FileStatus[FCKSBUBFJX.size()]);
    }

    /**
     * Filter files/directories in the given list of paths using default
     * path filter.
     *
     * @param files
     * 		a list of paths
     * @return a list of statuses for the files under the given paths after
    applying the filter default Path filter
     * @throws FileNotFoundException
     * 		when the path does not exist;
     * 		IOException see specific implementation
     */
    public FileStatus[] listStatus(Path[] LRWHQEIZJA) throws FileNotFoundException, IOException {
        return listStatus(LRWHQEIZJA, FileSystem.LPVXSIHDBK);
    }

    /**
     * Filter files/directories in the given list of paths using user-supplied
     * path filter.
     *
     * @param files
     * 		a list of paths
     * @param filter
     * 		the user-supplied path filter
     * @return a list of statuses for the files under the given paths after
    applying the filter
     * @throws FileNotFoundException
     * 		when the path does not exist;
     * 		IOException see specific implementation
     */
    public FileStatus[] listStatus(Path[] VWQIAYHHSU, PathFilter BSHNGMLFYP) throws FileNotFoundException, IOException {
        ArrayList<FileStatus> DVVIEJQDSM = new ArrayList<FileStatus>();
        for (int REUYMGCDDX = 0; REUYMGCDDX < VWQIAYHHSU.length; REUYMGCDDX++) {
            listStatus(DVVIEJQDSM, VWQIAYHHSU[REUYMGCDDX], BSHNGMLFYP);
        }
        return DVVIEJQDSM.toArray(new FileStatus[DVVIEJQDSM.size()]);
    }

    /**
     * <p>Return all the files that match filePattern and are not checksum
     * files. Results are sorted by their names.
     *
     * <p>
     * A filename pattern is composed of <i>regular</i> characters and
     * <i>special pattern matching</i> characters, which are:
     *
     * <dl>
     *  <dd>
     *   <dl>
     *    <p>
     *    <dt> <tt> ? </tt>
     *    <dd> Matches any single character.
     *
     *    <p>
     *    <dt> <tt> * </tt>
     *    <dd> Matches zero or more characters.
     *
     *    <p>
     *    <dt> <tt> [<i>abc</i>] </tt>
     *    <dd> Matches a single character from character set
     *     <tt>{<i>a,b,c</i>}</tt>.
     *
     *    <p>
     *    <dt> <tt> [<i>a</i>-<i>b</i>] </tt>
     *    <dd> Matches a single character from the character range
     *     <tt>{<i>a...b</i>}</tt>.  Note that character <tt><i>a</i></tt> must be
     *     lexicographically less than or equal to character <tt><i>b</i></tt>.
     *
     *    <p>
     *    <dt> <tt> [^<i>a</i>] </tt>
     *    <dd> Matches a single character that is not from character set or range
     *     <tt>{<i>a</i>}</tt>.  Note that the <tt>^</tt> character must occur
     *     immediately to the right of the opening bracket.
     *
     *    <p>
     *    <dt> <tt> \<i>c</i> </tt>
     *    <dd> Removes (escapes) any special meaning of character <i>c</i>.
     *
     *    <p>
     *    <dt> <tt> {ab,cd} </tt>
     *    <dd> Matches a string from the string set <tt>{<i>ab, cd</i>} </tt>
     *
     *    <p>
     *    <dt> <tt> {ab,c{de,fh}} </tt>
     *    <dd> Matches a string from the string set <tt>{<i>ab, cde, cfh</i>}</tt>
     *
     *   </dl>
     *  </dd>
     * </dl>
     *
     * @param pathPattern
     * 		a regular expression specifying a pth pattern
     * @return an array of paths that match the path pattern
     * @throws IOException
     * 		
     */
    public FileStatus[] globStatus(Path VAALSSODLJ) throws IOException {
        return new Globber(this, VAALSSODLJ, FileSystem.LPVXSIHDBK).glob();
    }

    /**
     * Return an array of FileStatus objects whose path names match
     * {@code pathPattern} and is accepted by the user-supplied path filter.
     * Results are sorted by their path names.
     *
     * @param pathPattern
     * 		a regular expression specifying the path pattern
     * @param filter
     * 		a user-supplied path filter
     * @return null if {@code pathPattern} has no glob and the path does not exist
    an empty array if {@code pathPattern} has a glob and no path
    matches it else an array of {@link FileStatus} objects matching the
    pattern
     * @throws IOException
     * 		if any I/O error occurs when fetching file status
     */
    public FileStatus[] globStatus(Path STYISPBQBF, PathFilter TLMBGJPPUM) throws IOException {
        return new Globber(this, STYISPBQBF, TLMBGJPPUM).glob();
    }

    /**
     * List the statuses of the files/directories in the given path if the path is
     * a directory.
     * Return the file's status and block locations If the path is a file.
     *
     * If a returned status is a file, it contains the file's block locations.
     *
     * @param f
     * 		is the path
     * @return an iterator that traverses statuses of the files/directories
    in the given path
     * @throws FileNotFoundException
     * 		If <code>f</code> does not exist
     * @throws IOException
     * 		If an I/O error occurred
     */
    public RemoteIterator<LocatedFileStatus> listLocatedStatus(final Path QXIKTPOVOK) throws FileNotFoundException, IOException {
        return listLocatedStatus(QXIKTPOVOK, FileSystem.LPVXSIHDBK);
    }

    /**
     * Listing a directory
     * The returned results include its block location if it is a file
     * The results are filtered by the given path filter
     *
     * @param f
     * 		a path
     * @param filter
     * 		a path filter
     * @return an iterator that traverses statuses of the files/directories
    in the given path
     * @throws FileNotFoundException
     * 		if <code>f</code> does not exist
     * @throws IOException
     * 		if any I/O error occurred
     */
    protected RemoteIterator<LocatedFileStatus> listLocatedStatus(final Path KIRKBRQASF, final PathFilter XSOJLRTUOJ) throws FileNotFoundException, IOException {
        return new RemoteIterator<LocatedFileStatus>() {
            private final FileStatus[] TMGSGTCFKO = listStatus(KIRKBRQASF, XSOJLRTUOJ);

            private int YDMSTAIYOT = 0;

            @Override
            public boolean hasNext() {
                return YDMSTAIYOT < TMGSGTCFKO.length;
            }

            @Override
            public LocatedFileStatus next() throws IOException {
                if (!hasNext()) {
                    throw new NoSuchElementException("No more entry in " + KIRKBRQASF);
                }
                FileStatus WGMCCRKVMK = TMGSGTCFKO[YDMSTAIYOT++];
                BlockLocation[] HBKOZRDKIN = (WGMCCRKVMK.isFile()) ? getFileBlockLocations(WGMCCRKVMK.getPath(), 0, WGMCCRKVMK.getLen()) : null;
                return new LocatedFileStatus(WGMCCRKVMK, HBKOZRDKIN);
            }
        };
    }

    /**
     * List the statuses and block locations of the files in the given path.
     *
     * If the path is a directory,
     *   if recursive is false, returns files in the directory;
     *   if recursive is true, return files in the subtree rooted at the path.
     * If the path is a file, return the file's status and block locations.
     *
     * @param f
     * 		is the path
     * @param recursive
     * 		if the subdirectories need to be traversed recursively
     * @return an iterator that traverses statuses of the files
     * @throws FileNotFoundException
     * 		when the path does not exist;
     * 		IOException see specific implementation
     */
    public RemoteIterator<LocatedFileStatus> listFiles(final Path SMHPHBSGJG, final boolean YLBKSUORZW) throws FileNotFoundException, IOException {
        return new RemoteIterator<LocatedFileStatus>() {
            private Stack<RemoteIterator<LocatedFileStatus>> FIXSYXZNRJ = new Stack<RemoteIterator<LocatedFileStatus>>();

            private RemoteIterator<LocatedFileStatus> WRRSEJOQYK = listLocatedStatus(SMHPHBSGJG);

            private LocatedFileStatus HNZQDYCESL;

            @Override
            public boolean hasNext() throws IOException {
                while (HNZQDYCESL == null) {
                    if (WRRSEJOQYK.hasNext()) {
                        handleFileStat(WRRSEJOQYK.next());
                    } else
                        if (!FIXSYXZNRJ.empty()) {
                            WRRSEJOQYK = FIXSYXZNRJ.pop();
                        } else {
                            return false;
                        }

                } 
                return true;
            }

            /**
             * Process the input stat.
             * If it is a file, return the file stat.
             * If it is a directory, traverse the directory if recursive is true;
             * ignore it if recursive is false.
             *
             * @param stat
             * 		input status
             * @throws IOException
             * 		if any IO error occurs
             */
            private void handleFileStat(LocatedFileStatus HTMSHXKSMA) throws IOException {
                if (HTMSHXKSMA.isFile()) {
                    // file
                    HNZQDYCESL = HTMSHXKSMA;
                } else
                    if (YLBKSUORZW) {
                        // directory
                        FIXSYXZNRJ.push(WRRSEJOQYK);
                        WRRSEJOQYK = listLocatedStatus(HTMSHXKSMA.getPath());
                    }

            }

            @Override
            public LocatedFileStatus next() throws IOException {
                if (hasNext()) {
                    LocatedFileStatus DTMUNTLFQY = HNZQDYCESL;
                    HNZQDYCESL = null;
                    return DTMUNTLFQY;
                }
                throw new NoSuchElementException("No more entry in " + SMHPHBSGJG);
            }
        };
    }

    /**
     * Return the current user's home directory in this filesystem.
     * The default implementation returns "/user/$USER/".
     */
    public Path getHomeDirectory() {
        return this.makeQualified(new Path("/user/" + System.getProperty("user.name")));
    }

    /**
     * Set the current working directory for the given file system. All relative
     * paths will be resolved relative to it.
     *
     * @param new_dir
     * 		
     */
    public abstract void setWorkingDirectory(Path ENGDRDSRLK);

    /**
     * Get the current working directory for the given file system
     *
     * @return the directory pathname
     */
    public abstract Path getWorkingDirectory();

    /**
     * Note: with the new FilesContext class, getWorkingDirectory()
     * will be removed.
     * The working directory is implemented in FilesContext.
     *
     * Some file systems like LocalFileSystem have an initial workingDir
     * that we use as the starting workingDir. For other file systems
     * like HDFS there is no built in notion of an initial workingDir.
     *
     * @return if there is built in notion of workingDir then it
    is returned; else a null is returned.
     */
    protected Path getInitialWorkingDirectory() {
        return null;
    }

    /**
     * Call {@link #mkdirs(Path, FsPermission)} with default permission.
     */
    public boolean mkdirs(Path ERAVQLXLNT) throws IOException {
        return mkdirs(ERAVQLXLNT, FsPermission.getDirDefault());
    }

    /**
     * Make the given file and all non-existent parents into
     * directories. Has the semantics of Unix 'mkdir -p'.
     * Existence of the directory hierarchy is not an error.
     *
     * @param f
     * 		path to create
     * @param permission
     * 		to apply to f
     */
    public abstract boolean mkdirs(Path JJDLUHFAFY, FsPermission VVGDKIYTBW) throws IOException;

    /**
     * The src file is on the local disk.  Add it to FS at
     * the given dst name and the source is kept intact afterwards
     *
     * @param src
     * 		path
     * @param dst
     * 		path
     */
    public void copyFromLocalFile(Path VRTPKVZEKK, Path JYAYOCCIBM) throws IOException {
        copyFromLocalFile(false, VRTPKVZEKK, JYAYOCCIBM);
    }

    /**
     * The src files is on the local disk.  Add it to FS at
     * the given dst name, removing the source afterwards.
     *
     * @param srcs
     * 		path
     * @param dst
     * 		path
     */
    public void moveFromLocalFile(Path[] GIKAAGVAGS, Path AVHBWNVJNM) throws IOException {
        copyFromLocalFile(true, true, GIKAAGVAGS, AVHBWNVJNM);
    }

    /**
     * The src file is on the local disk.  Add it to FS at
     * the given dst name, removing the source afterwards.
     *
     * @param src
     * 		path
     * @param dst
     * 		path
     */
    public void moveFromLocalFile(Path NFQHUWSWTK, Path OCPCWQRJNB) throws IOException {
        copyFromLocalFile(true, NFQHUWSWTK, OCPCWQRJNB);
    }

    /**
     * The src file is on the local disk.  Add it to FS at
     * the given dst name.
     * delSrc indicates if the source should be removed
     *
     * @param delSrc
     * 		whether to delete the src
     * @param src
     * 		path
     * @param dst
     * 		path
     */
    public void copyFromLocalFile(boolean DCCLAIJFBA, Path NVCYJBJPJO, Path MZGMIRPQRR) throws IOException {
        copyFromLocalFile(DCCLAIJFBA, true, NVCYJBJPJO, MZGMIRPQRR);
    }

    /**
     * The src files are on the local disk.  Add it to FS at
     * the given dst name.
     * delSrc indicates if the source should be removed
     *
     * @param delSrc
     * 		whether to delete the src
     * @param overwrite
     * 		whether to overwrite an existing file
     * @param srcs
     * 		array of paths which are source
     * @param dst
     * 		path
     */
    public void copyFromLocalFile(boolean PUFMVGMTBV, boolean AKHDQAAAMT, Path[] AYKEGYVVXO, Path DOABYFDEVA) throws IOException {
        Configuration HTCHQBEXVF = getConf();
        FileUtil.copy(FileSystem.getLocal(HTCHQBEXVF), AYKEGYVVXO, this, DOABYFDEVA, PUFMVGMTBV, AKHDQAAAMT, HTCHQBEXVF);
    }

    /**
     * The src file is on the local disk.  Add it to FS at
     * the given dst name.
     * delSrc indicates if the source should be removed
     *
     * @param delSrc
     * 		whether to delete the src
     * @param overwrite
     * 		whether to overwrite an existing file
     * @param src
     * 		path
     * @param dst
     * 		path
     */
    public void copyFromLocalFile(boolean OMMKIYPOUC, boolean SEFMXIWANN, Path LJQYFOTIIQ, Path AYHBUXIHRV) throws IOException {
        Configuration FXGWATJXJH = getConf();
        FileUtil.copy(FileSystem.getLocal(FXGWATJXJH), LJQYFOTIIQ, this, AYHBUXIHRV, OMMKIYPOUC, SEFMXIWANN, FXGWATJXJH);
    }

    /**
     * The src file is under FS, and the dst is on the local disk.
     * Copy it from FS control to the local dst name.
     *
     * @param src
     * 		path
     * @param dst
     * 		path
     */
    public void copyToLocalFile(Path SSQNYSYNIL, Path QTQRIQDIMR) throws IOException {
        copyToLocalFile(false, SSQNYSYNIL, QTQRIQDIMR);
    }

    /**
     * The src file is under FS, and the dst is on the local disk.
     * Copy it from FS control to the local dst name.
     * Remove the source afterwards
     *
     * @param src
     * 		path
     * @param dst
     * 		path
     */
    public void moveToLocalFile(Path MIBGMCSOUG, Path SERMWRUGBE) throws IOException {
        copyToLocalFile(true, MIBGMCSOUG, SERMWRUGBE);
    }

    /**
     * The src file is under FS, and the dst is on the local disk.
     * Copy it from FS control to the local dst name.
     * delSrc indicates if the src will be removed or not.
     *
     * @param delSrc
     * 		whether to delete the src
     * @param src
     * 		path
     * @param dst
     * 		path
     */
    public void copyToLocalFile(boolean QTJDLBQDOC, Path ZXQBPSJNUU, Path WWOGITBZAL) throws IOException {
        copyToLocalFile(QTJDLBQDOC, ZXQBPSJNUU, WWOGITBZAL, false);
    }

    /**
     * The src file is under FS, and the dst is on the local disk. Copy it from FS
     * control to the local dst name. delSrc indicates if the src will be removed
     * or not. useRawLocalFileSystem indicates whether to use RawLocalFileSystem
     * as local file system or not. RawLocalFileSystem is non crc file system.So,
     * It will not create any crc files at local.
     *
     * @param delSrc
     * 		whether to delete the src
     * @param src
     * 		path
     * @param dst
     * 		path
     * @param useRawLocalFileSystem
     * 		whether to use RawLocalFileSystem as local file system or not.
     * @throws IOException
     * 		- if any IO error
     */
    public void copyToLocalFile(boolean VGCKJKBTSV, Path NQSTZMZGVL, Path NLBFFJZCPH, boolean EQOGVNRJWC) throws IOException {
        Configuration DTPZSHETNP = getConf();
        FileSystem JLPQAKFRDA = null;
        if (EQOGVNRJWC) {
            JLPQAKFRDA = FileSystem.getLocal(DTPZSHETNP).getRawFileSystem();
        } else {
            JLPQAKFRDA = FileSystem.getLocal(DTPZSHETNP);
        }
        FileUtil.copy(this, NQSTZMZGVL, JLPQAKFRDA, NLBFFJZCPH, VGCKJKBTSV, DTPZSHETNP);
    }

    /**
     * Returns a local File that the user can write output to.  The caller
     * provides both the eventual FS target name and the local working
     * file.  If the FS is local, we write directly into the target.  If
     * the FS is remote, we write into the tmp local area.
     *
     * @param fsOutputFile
     * 		path of output file
     * @param tmpLocalFile
     * 		path of local tmp file
     */
    public Path startLocalOutput(Path AERTZYMPQL, Path TEKIZNODGJ) throws IOException {
        return TEKIZNODGJ;
    }

    /**
     * Called when we're all done writing to the target.  A local FS will
     * do nothing, because we've written to exactly the right place.  A remote
     * FS will copy the contents of tmpLocalFile to the correct target at
     * fsOutputFile.
     *
     * @param fsOutputFile
     * 		path of output file
     * @param tmpLocalFile
     * 		path to local tmp file
     */
    public void completeLocalOutput(Path MRJXAPZWUW, Path BMNXLQLMNX) throws IOException {
        moveFromLocalFile(BMNXLQLMNX, MRJXAPZWUW);
    }

    /**
     * No more filesystem operations are needed.  Will
     * release any held locks.
     */
    @Override
    public void close() throws IOException {
        // delete all files that were marked as delete-on-exit.
        processDeleteOnExit();
        FileSystem.MWBGBWTFVO.remove(this.RNSXLSVOSD, this);
    }

    /**
     * Return the total size of all files in the filesystem.
     */
    public long getUsed() throws IOException {
        long VQZSAXYCMS = 0;
        FileStatus[] KPBJIOQTPL = listStatus(new Path("/"));
        for (FileStatus RYUWLSDXDO : KPBJIOQTPL) {
            VQZSAXYCMS += RYUWLSDXDO.getLen();
        }
        return VQZSAXYCMS;
    }

    /**
     * Get the block size for a particular file.
     *
     * @param f
     * 		the filename
     * @return the number of bytes in a block
     */
    /**
     *
     *
     * @deprecated Use getFileStatus() instead
     */
    @Deprecated
    public long getBlockSize(Path RXFXSQGINP) throws IOException {
        return getFileStatus(RXFXSQGINP).getBlockSize();
    }

    /**
     * Return the number of bytes that large input files should be optimally
     * be split into to minimize i/o time.
     *
     * @deprecated use {@link #getDefaultBlockSize(Path)} instead
     */
    @Deprecated
    public long getDefaultBlockSize() {
        // default to 32MB: large enough to minimize the impact of seeks
        return getConf().getLong("fs.local.block.size", (32 * 1024) * 1024);
    }

    /**
     * Return the number of bytes that large input files should be optimally
     * be split into to minimize i/o time.  The given path will be used to
     * locate the actual filesystem.  The full path does not have to exist.
     *
     * @param f
     * 		path of file
     * @return the default block size for the path's filesystem
     */
    public long getDefaultBlockSize(Path JTBBYQUPAS) {
        return getDefaultBlockSize();
    }

    /**
     * Get the default replication.
     *
     * @deprecated use {@link #getDefaultReplication(Path)} instead
     */
    @Deprecated
    public short getDefaultReplication() {
        return 1;
    }

    /**
     * Get the default replication for a path.   The given path will be used to
     * locate the actual filesystem.  The full path does not have to exist.
     *
     * @param path
     * 		of the file
     * @return default replication for the path's filesystem
     */
    public short getDefaultReplication(Path SCIUFYAYKY) {
        return getDefaultReplication();
    }

    /**
     * Return a file status object that represents the path.
     *
     * @param f
     * 		The path we want information from
     * @return a FileStatus object
     * @throws FileNotFoundException
     * 		when the path does not exist;
     * 		IOException see specific implementation
     */
    public abstract FileStatus getFileStatus(Path LHKRDPLXSW) throws IOException;

    /**
     * Checks if the user can access a path.  The mode specifies which access
     * checks to perform.  If the requested permissions are granted, then the
     * method returns normally.  If access is denied, then the method throws an
     * {@link AccessControlException}.
     * <p/>
     * The default implementation of this method calls {@link #getFileStatus(Path)}
     * and checks the returned permissions against the requested permissions.
     * Note that the getFileStatus call will be subject to authorization checks.
     * Typically, this requires search (execute) permissions on each directory in
     * the path's prefix, but this is implementation-defined.  Any file system
     * that provides a richer authorization model (such as ACLs) may override the
     * default implementation so that it checks against that model instead.
     * <p>
     * In general, applications should avoid using this method, due to the risk of
     * time-of-check/time-of-use race conditions.  The permissions on a file may
     * change immediately after the access call returns.  Most applications should
     * prefer running specific file system actions as the desired user represented
     * by a {@link UserGroupInformation}.
     *
     * @param path
     * 		Path to check
     * @param mode
     * 		type of access to check
     * @throws AccessControlException
     * 		if access is denied
     * @throws FileNotFoundException
     * 		if the path does not exist
     * @throws IOException
     * 		see specific implementation
     */
    @InterfaceAudience.LimitedPrivate({ "HDFS", "Hive" })
    public void access(Path MAAHLWMWMP, FsAction QEUGKECTPJ) throws FileNotFoundException, IOException, AccessControlException {
        FileSystem.checkAccessPermissions(this.getFileStatus(MAAHLWMWMP), QEUGKECTPJ);
    }

    /**
     * This method provides the default implementation of
     * {@link #access(Path, FsAction)}.
     *
     * @param stat
     * 		FileStatus to check
     * @param mode
     * 		type of access to check
     * @throws IOException
     * 		for any error
     */
    @InterfaceAudience.Private
    static void checkAccessPermissions(FileStatus RKXKHDAWGO, FsAction XOWTBLBZUF) throws IOException {
        FsPermission JNYJGQBTPM = RKXKHDAWGO.getPermission();
        UserGroupInformation DXVADADQPH = UserGroupInformation.getCurrentUser();
        String XCXFXFVIST = DXVADADQPH.getShortUserName();
        List<String> NBJGXFQYSB = Arrays.asList(DXVADADQPH.getGroupNames());
        if (XCXFXFVIST.equals(RKXKHDAWGO.getOwner())) {
            if (JNYJGQBTPM.getUserAction().implies(XOWTBLBZUF)) {
                return;
            }
        } else
            if (NBJGXFQYSB.contains(RKXKHDAWGO.getGroup())) {
                if (JNYJGQBTPM.getGroupAction().implies(XOWTBLBZUF)) {
                    return;
                }
            } else {
                if (JNYJGQBTPM.getOtherAction().implies(XOWTBLBZUF)) {
                    return;
                }
            }

        throw new AccessControlException(String.format("Permission denied: user=%s, path=\"%s\":%s:%s:%s%s", XCXFXFVIST, RKXKHDAWGO.getPath(), RKXKHDAWGO.getOwner(), RKXKHDAWGO.getGroup(), RKXKHDAWGO.isDirectory() ? "d" : "-", JNYJGQBTPM));
    }

    /**
     * See {@link FileContext#fixRelativePart}
     */
    protected Path fixRelativePart(Path VCLMJNUNHY) {
        if (VCLMJNUNHY.isUriPathAbsolute()) {
            return VCLMJNUNHY;
        } else {
            return new Path(getWorkingDirectory(), VCLMJNUNHY);
        }
    }

    /**
     * See {@link FileContext#createSymlink(Path, Path, boolean)}
     */
    public void createSymlink(final Path CVOFMVYHSJ, final Path CLEWDWFUXU, final boolean ETWIBQVAQC) throws FileNotFoundException, IOException, FileAlreadyExistsException, ParentNotDirectoryException, UnsupportedFileSystemException, AccessControlException {
        // Supporting filesystems should override this method
        throw new UnsupportedOperationException("Filesystem does not support symlinks!");
    }

    /**
     * See {@link FileContext#getFileLinkStatus(Path)}
     */
    public FileStatus getFileLinkStatus(final Path RLFHITUXUA) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        // Supporting filesystems should override this method
        return getFileStatus(RLFHITUXUA);
    }

    /**
     * See {@link AbstractFileSystem#supportsSymlinks()}
     */
    public boolean supportsSymlinks() {
        return false;
    }

    /**
     * See {@link FileContext#getLinkTarget(Path)}
     */
    public Path getLinkTarget(Path UTOUHWDCHG) throws IOException {
        // Supporting filesystems should override this method
        throw new UnsupportedOperationException("Filesystem does not support symlinks!");
    }

    /**
     * See {@link AbstractFileSystem#getLinkTarget(Path)}
     */
    protected Path resolveLink(Path VZLIIOJWSP) throws IOException {
        // Supporting filesystems should override this method
        throw new UnsupportedOperationException("Filesystem does not support symlinks!");
    }

    /**
     * Get the checksum of a file.
     *
     * @param f
     * 		The file path
     * @return The file checksum.  The default return value is null,
    which indicates that no checksum algorithm is implemented
    in the corresponding FileSystem.
     */
    public FileChecksum getFileChecksum(Path RRHVCENUVN) throws IOException {
        return getFileChecksum(RRHVCENUVN, Long.MAX_VALUE);
    }

    /**
     * Get the checksum of a file, from the beginning of the file till the
     * specific length.
     *
     * @param f
     * 		The file path
     * @param length
     * 		The length of the file range for checksum calculation
     * @return The file checksum.
     */
    public FileChecksum getFileChecksum(Path QHLNIBQPYT, final long VMIINQOCOK) throws IOException {
        return null;
    }

    /**
     * Set the verify checksum flag. This is only applicable if the
     * corresponding FileSystem supports checksum. By default doesn't do anything.
     *
     * @param verifyChecksum
     * 		
     */
    public void setVerifyChecksum(boolean GMOIPFLQBS) {
        // doesn't do anything
    }

    /**
     * Set the write checksum flag. This is only applicable if the
     * corresponding FileSystem supports checksum. By default doesn't do anything.
     *
     * @param writeChecksum
     * 		
     */
    public void setWriteChecksum(boolean TGFQRLJNPZ) {
        // doesn't do anything
    }

    /**
     * Returns a status object describing the use and capacity of the
     * file system. If the file system has multiple partitions, the
     * use and capacity of the root partition is reflected.
     *
     * @return a FsStatus object
     * @throws IOException
     * 		see specific implementation
     */
    public FsStatus getStatus() throws IOException {
        return getStatus(null);
    }

    /**
     * Returns a status object describing the use and capacity of the
     * file system. If the file system has multiple partitions, the
     * use and capacity of the partition pointed to by the specified
     * path is reflected.
     *
     * @param p
     * 		Path for which status should be obtained. null means
     * 		the default partition.
     * @return a FsStatus object
     * @throws IOException
     * 		see specific implementation
     */
    public FsStatus getStatus(Path UPDRXVTEDA) throws IOException {
        return new FsStatus(Long.MAX_VALUE, 0, Long.MAX_VALUE);
    }

    /**
     * Set permission of a path.
     *
     * @param p
     * 		
     * @param permission
     * 		
     */
    public void setPermission(Path XNEBHWEOUK, FsPermission FQGQLSCNEW) throws IOException {
    }

    /**
     * Set owner of a path (i.e. a file or a directory).
     * The parameters username and groupname cannot both be null.
     *
     * @param p
     * 		The path
     * @param username
     * 		If it is null, the original username remains unchanged.
     * @param groupname
     * 		If it is null, the original groupname remains unchanged.
     */
    public void setOwner(Path SFNRPZOUCJ, String SCFMLTULKO, String MJHIAYDDNG) throws IOException {
    }

    /**
     * Set access time of a file
     *
     * @param p
     * 		The path
     * @param mtime
     * 		Set the modification time of this file.
     * 		The number of milliseconds since Jan 1, 1970.
     * 		A value of -1 means that this call should not set modification time.
     * @param atime
     * 		Set the access time of this file.
     * 		The number of milliseconds since Jan 1, 1970.
     * 		A value of -1 means that this call should not set access time.
     */
    public void setTimes(Path LVXVFWKTRD, long QKYCWYWCOZ, long XGQHIEHCPY) throws IOException {
    }

    /**
     * Create a snapshot with a default name.
     *
     * @param path
     * 		The directory where snapshots will be taken.
     * @return the snapshot path.
     */
    public final Path createSnapshot(Path RXZJEYLKRK) throws IOException {
        return createSnapshot(RXZJEYLKRK, null);
    }

    /**
     * Create a snapshot
     *
     * @param path
     * 		The directory where snapshots will be taken.
     * @param snapshotName
     * 		The name of the snapshot
     * @return the snapshot path.
     */
    public Path createSnapshot(Path RBQKJVIGEP, String HDHZYHIALU) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support createSnapshot");
    }

    /**
     * Rename a snapshot
     *
     * @param path
     * 		The directory path where the snapshot was taken
     * @param snapshotOldName
     * 		Old name of the snapshot
     * @param snapshotNewName
     * 		New name of the snapshot
     * @throws IOException
     * 		
     */
    public void renameSnapshot(Path AOGVYXJQYC, String UYYZGZUIKZ, String INCZAAHLTL) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support renameSnapshot");
    }

    /**
     * Delete a snapshot of a directory
     *
     * @param path
     * 		The directory that the to-be-deleted snapshot belongs to
     * @param snapshotName
     * 		The name of the snapshot
     */
    public void deleteSnapshot(Path HUNOKAJQTE, String QLHBNUXZJW) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support deleteSnapshot");
    }

    /**
     * Modifies ACL entries of files and directories.  This method can add new ACL
     * entries or modify the permissions on existing ACL entries.  All existing
     * ACL entries that are not specified in this call are retained without
     * changes.  (Modifications are merged into the current ACL.)
     *
     * @param path
     * 		Path to modify
     * @param aclSpec
     * 		List<AclEntry> describing modifications
     * @throws IOException
     * 		if an ACL could not be modified
     */
    public void modifyAclEntries(Path RMAHTDJHJS, List<AclEntry> AKPMHGHESZ) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support modifyAclEntries");
    }

    /**
     * Removes ACL entries from files and directories.  Other ACL entries are
     * retained.
     *
     * @param path
     * 		Path to modify
     * @param aclSpec
     * 		List<AclEntry> describing entries to remove
     * @throws IOException
     * 		if an ACL could not be modified
     */
    public void removeAclEntries(Path LIMODDYKEL, List<AclEntry> ZALFMAPUDH) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support removeAclEntries");
    }

    /**
     * Removes all default ACL entries from files and directories.
     *
     * @param path
     * 		Path to modify
     * @throws IOException
     * 		if an ACL could not be modified
     */
    public void removeDefaultAcl(Path KDHVNJHGWX) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support removeDefaultAcl");
    }

    /**
     * Removes all but the base ACL entries of files and directories.  The entries
     * for user, group, and others are retained for compatibility with permission
     * bits.
     *
     * @param path
     * 		Path to modify
     * @throws IOException
     * 		if an ACL could not be removed
     */
    public void removeAcl(Path BMNAEUAYGD) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support removeAcl");
    }

    /**
     * Fully replaces ACL of files and directories, discarding all existing
     * entries.
     *
     * @param path
     * 		Path to modify
     * @param aclSpec
     * 		List<AclEntry> describing modifications, must include entries
     * 		for user, group, and others for compatibility with permission bits.
     * @throws IOException
     * 		if an ACL could not be modified
     */
    public void setAcl(Path ZHSNXVAQXX, List<AclEntry> CZQCWYBHJW) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support setAcl");
    }

    /**
     * Gets the ACL of a file or directory.
     *
     * @param path
     * 		Path to get
     * @return AclStatus describing the ACL of the file or directory
     * @throws IOException
     * 		if an ACL could not be read
     */
    public AclStatus getAclStatus(Path JLUIBHFYFR) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support getAclStatus");
    }

    /**
     * Set an xattr of a file or directory.
     * The name must be prefixed with the namespace followed by ".". For example,
     * "user.attr".
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to modify
     * @param name
     * 		xattr name.
     * @param value
     * 		xattr value.
     * @throws IOException
     * 		
     */
    public void setXAttr(Path UVOOOFDTBN, String NBGHTCPKMC, byte[] XUGLJILBKJ) throws IOException {
        setXAttr(UVOOOFDTBN, NBGHTCPKMC, XUGLJILBKJ, EnumSet.of(XAttrSetFlag.CREATE, REPLACE));
    }

    /**
     * Set an xattr of a file or directory.
     * The name must be prefixed with the namespace followed by ".". For example,
     * "user.attr".
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to modify
     * @param name
     * 		xattr name.
     * @param value
     * 		xattr value.
     * @param flag
     * 		xattr set flag
     * @throws IOException
     * 		
     */
    public void setXAttr(Path CQNBZIYQCG, String CYVUBDZITR, byte[] NSALFILVNP, EnumSet<XAttrSetFlag> CIVRFNNJEO) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support setXAttr");
    }

    /**
     * Get an xattr name and value for a file or directory.
     * The name must be prefixed with the namespace followed by ".". For example,
     * "user.attr".
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to get extended attribute
     * @param name
     * 		xattr name.
     * @return byte[] xattr value.
     * @throws IOException
     * 		
     */
    public byte[] getXAttr(Path ZGPMQVLSVR, String ASBYWZFIWA) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support getXAttr");
    }

    /**
     * Get all of the xattr name/value pairs for a file or directory.
     * Only those xattrs which the logged-in user has permissions to view
     * are returned.
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to get extended attributes
     * @return Map<String, byte[]> describing the XAttrs of the file or directory
     * @throws IOException
     * 		
     */
    public Map<String, byte[]> getXAttrs(Path IUTOHNYLXQ) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support getXAttrs");
    }

    /**
     * Get all of the xattrs name/value pairs for a file or directory.
     * Only those xattrs which the logged-in user has permissions to view
     * are returned.
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to get extended attributes
     * @param names
     * 		XAttr names.
     * @return Map<String, byte[]> describing the XAttrs of the file or directory
     * @throws IOException
     * 		
     */
    public Map<String, byte[]> getXAttrs(Path RFUJJEXZAY, List<String> RMRIUTRIPW) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support getXAttrs");
    }

    /**
     * Get all of the xattr names for a file or directory.
     * Only those xattr names which the logged-in user has permissions to view
     * are returned.
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to get extended attributes
     * @return List<String> of the XAttr names of the file or directory
     * @throws IOException
     * 		
     */
    public List<String> listXAttrs(Path PMXPKPUZZW) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support listXAttrs");
    }

    /**
     * Remove an xattr of a file or directory.
     * The name must be prefixed with the namespace followed by ".". For example,
     * "user.attr".
     * <p/>
     * Refer to the HDFS extended attributes user documentation for details.
     *
     * @param path
     * 		Path to remove extended attribute
     * @param name
     * 		xattr name
     * @throws IOException
     * 		
     */
    public void removeXAttr(Path AEILSYYMZP, String TGDHWTECKL) throws IOException {
        throw new UnsupportedOperationException(getClass().getSimpleName() + " doesn't support removeXAttr");
    }

    // making it volatile to be able to do a double checked locking
    private static volatile boolean SVJIMUBNZY = false;

    private static final Map<String, Class<? extends FileSystem>> LQBTYPHFUT = new HashMap<String, Class<? extends FileSystem>>();

    private static void loadFileSystems() {
        synchronized(FileSystem.class) {
            if (!FileSystem.SVJIMUBNZY) {
                ServiceLoader<FileSystem> OYKLQJCOOY = ServiceLoader.load(FileSystem.class);
                for (FileSystem MZVVXVAKYG : OYKLQJCOOY) {
                    FileSystem.LQBTYPHFUT.put(MZVVXVAKYG.getScheme(), MZVVXVAKYG.getClass());
                }
                FileSystem.SVJIMUBNZY = true;
            }
        }
    }

    public static Class<? extends FileSystem> getFileSystemClass(String KQUZAXPQFF, Configuration BVJVLJLQFC) throws IOException {
        if (!FileSystem.SVJIMUBNZY) {
            FileSystem.loadFileSystems();
        }
        Class<? extends FileSystem> IPNVAEOVBR = null;
        if (BVJVLJLQFC != null) {
            IPNVAEOVBR = ((Class<? extends FileSystem>) (BVJVLJLQFC.getClass(("fs." + KQUZAXPQFF) + ".impl", null)));
        }
        if (IPNVAEOVBR == null) {
            IPNVAEOVBR = FileSystem.LQBTYPHFUT.get(KQUZAXPQFF);
        }
        if (IPNVAEOVBR == null) {
            throw new IOException("No FileSystem for scheme: " + KQUZAXPQFF);
        }
        return IPNVAEOVBR;
    }

    private static FileSystem createFileSystem(URI ZCGSYDLWRZ, Configuration DTVWOKFFMD) throws IOException {
        Class<?> MUDGOUPIGE = FileSystem.getFileSystemClass(ZCGSYDLWRZ.getScheme(), DTVWOKFFMD);
        if (MUDGOUPIGE == null) {
            throw new IOException("No FileSystem for scheme: " + ZCGSYDLWRZ.getScheme());
        }
        FileSystem CMNJVFAFJX = ((FileSystem) (ReflectionUtils.newInstance(MUDGOUPIGE, DTVWOKFFMD)));
        CMNJVFAFJX.initialize(ZCGSYDLWRZ, DTVWOKFFMD);
        return CMNJVFAFJX;
    }

    /**
     * Caching FileSystem objects
     */
    static class Cache {
        private final FileSystem.Cache.ClientFinalizer EUSKWHQZSX = new FileSystem.Cache.ClientFinalizer();

        private final Map<FileSystem.Cache.Key, FileSystem> IKXXDIAEDG = new HashMap<FileSystem.Cache.Key, FileSystem>();

        private final Set<FileSystem.Cache.Key> IYEHLFBVZF = new HashSet<FileSystem.Cache.Key>();

        /**
         * A variable that makes all objects in the cache unique
         */
        private static AtomicLong HIEVLCIKLA = new AtomicLong(1);

        FileSystem get(URI uri, Configuration conf) throws IOException {
            FileSystem.Cache.Key key = new FileSystem.Cache.Key(uri, conf);
            return getInternal(uri, conf, key);
        }

        /**
         * The objects inserted into the cache using this method are all unique
         */
        FileSystem getUnique(URI uri, Configuration conf) throws IOException {
            FileSystem.Cache.Key key = new FileSystem.Cache.Key(uri, conf, FileSystem.Cache.HIEVLCIKLA.getAndIncrement());
            return getInternal(uri, conf, key);
        }

        private FileSystem getInternal(URI uri, Configuration conf, FileSystem.Cache.Key key) throws IOException {
            FileSystem fs;
            synchronized(this) {
                fs = IKXXDIAEDG.get(key);
            }
            if (fs != null) {
                return fs;
            }
            fs = FileSystem.createFileSystem(uri, conf);
            synchronized(this) {
                // refetch the lock again
                FileSystem oldfs = IKXXDIAEDG.get(key);
                if (oldfs != null) {
                    // a file system is created while lock is releasing
                    fs.close();// close the new file system

                    return oldfs;// return the old file system

                }
                // now insert the new file system into the map
                if (IKXXDIAEDG.isEmpty() && (!org.apache.hadoop.util.ShutdownHookManager.get().isShutdownInProgress())) {
                    org.apache.hadoop.util.ShutdownHookManager.get().addShutdownHook(EUSKWHQZSX, FileSystem.AEQJRTGPUW);
                }
                fs.RNSXLSVOSD = key;
                IKXXDIAEDG.put(key, fs);
                if (conf.getBoolean("fs.automatic.close", true)) {
                    IYEHLFBVZF.add(key);
                }
                return fs;
            }
        }

        synchronized void remove(FileSystem.Cache.Key key, FileSystem fs) {
            if (IKXXDIAEDG.containsKey(key) && (fs == IKXXDIAEDG.get(key))) {
                IKXXDIAEDG.remove(key);
                IYEHLFBVZF.remove(key);
            }
        }

        synchronized void closeAll() throws IOException {
            closeAll(false);
        }

        /**
         * Close all FileSystem instances in the Cache.
         *
         * @param onlyAutomatic
         * 		only close those that are marked for automatic closing
         */
        synchronized void closeAll(boolean onlyAutomatic) throws IOException {
            List<IOException> exceptions = new ArrayList<IOException>();
            // Make a copy of the keys in the map since we'll be modifying
            // the map while iterating over it, which isn't safe.
            List<FileSystem.Cache.Key> keys = new ArrayList<FileSystem.Cache.Key>();
            keys.addAll(IKXXDIAEDG.keySet());
            for (FileSystem.Cache.Key key : keys) {
                final FileSystem fs = IKXXDIAEDG.get(key);
                if (onlyAutomatic && (!IYEHLFBVZF.contains(key))) {
                    continue;
                }
                // remove from cache
                remove(key, fs);
                if (fs != null) {
                    try {
                        fs.close();
                    } catch (IOException ioe) {
                        exceptions.add(ioe);
                    }
                }
            }
            if (!exceptions.isEmpty()) {
                throw MultipleIOException.createIOException(exceptions);
            }
        }

        private class ClientFinalizer implements Runnable {
            @Override
            public synchronized void run() {
                try {
                    closeAll(true);
                } catch (IOException e) {
                    FileSystem.DZPULTDFZF.info("FileSystem.Cache.closeAll() threw an exception:\n" + e);
                }
            }
        }

        synchronized void closeAll(UserGroupInformation ugi) throws IOException {
            List<FileSystem> targetFSList = new ArrayList<FileSystem>();
            // Make a pass over the list and collect the filesystems to close
            // we cannot close inline since close() removes the entry from the Map
            for (Map.Entry<FileSystem.Cache.Key, FileSystem> entry : IKXXDIAEDG.entrySet()) {
                final FileSystem.Cache.Key key = entry.getKey();
                final FileSystem fs = entry.getValue();
                if (ugi.equals(key.YQXQMSIZMU) && (fs != null)) {
                    targetFSList.add(fs);
                }
            }
            List<IOException> exceptions = new ArrayList<IOException>();
            // now make a pass over the target list and close each
            for (FileSystem fs : targetFSList) {
                try {
                    fs.close();
                } catch (IOException ioe) {
                    exceptions.add(ioe);
                }
            }
            if (!exceptions.isEmpty()) {
                throw MultipleIOException.createIOException(exceptions);
            }
        }

        /**
         * FileSystem.Cache.Key
         */
        static class Key {
            final String TVVMMBSTSV;

            final String UUWULABQUB;

            final UserGroupInformation YQXQMSIZMU;

            final long HDAUGJANMZ;// an artificial way to make a key unique


            Key(URI uri, Configuration conf) throws IOException {
                this(uri, conf, 0);
            }

            Key(URI uri, Configuration conf, long unique) throws IOException {
                TVVMMBSTSV = (uri.getScheme() == null) ? "" : uri.getScheme().toLowerCase();
                UUWULABQUB = (uri.getAuthority() == null) ? "" : uri.getAuthority().toLowerCase();
                this.HDAUGJANMZ = unique;
                this.YQXQMSIZMU = UserGroupInformation.getCurrentUser();
            }

            @Override
            public int hashCode() {
                return ((TVVMMBSTSV + UUWULABQUB).hashCode() + YQXQMSIZMU.hashCode()) + ((int) (HDAUGJANMZ));
            }

            static boolean isEqual(Object a, Object b) {
                return (a == b) || ((a != null) && a.equals(b));
            }

            @Override
            public boolean equals(Object obj) {
                if (obj == this) {
                    return true;
                }
                if ((obj != null) && (obj instanceof FileSystem.Cache.Key)) {
                    FileSystem.Cache.Key that = ((FileSystem.Cache.Key) (obj));
                    return ((FileSystem.Cache.Key.isEqual(this.TVVMMBSTSV, that.TVVMMBSTSV) && FileSystem.Cache.Key.isEqual(this.UUWULABQUB, that.UUWULABQUB)) && FileSystem.Cache.Key.isEqual(this.YQXQMSIZMU, that.YQXQMSIZMU)) && (this.HDAUGJANMZ == that.HDAUGJANMZ);
                }
                return false;
            }

            @Override
            public String toString() {
                return (((("(" + YQXQMSIZMU.toString()) + ")@") + TVVMMBSTSV) + "://") + UUWULABQUB;
            }
        }
    }

    /**
     * Tracks statistics about how many reads, writes, and so forth have been
     * done in a FileSystem.
     *
     * Since there is only one of these objects per FileSystem, there will
     * typically be many threads writing to this object.  Almost every operation
     * on an open file will involve a write to this object.  In contrast, reading
     * statistics is done infrequently by most programs, and not at all by others.
     * Hence, this is optimized for writes.
     *
     * Each thread writes to its own thread-local area of memory.  This removes
     * contention and allows us to scale up to many, many threads.  To read
     * statistics, the reader thread totals up the contents of all of the
     * thread-local data areas.
     */
    public static final class Statistics {
        /**
         * Statistics data.
         *
         * There is only a single writer to thread-local StatisticsData objects.
         * Hence, volatile is adequate here-- we do not need AtomicLong or similar
         * to prevent lost updates.
         * The Java specification guarantees that updates to volatile longs will
         * be perceived as atomic with respect to other threads, which is all we
         * need.
         */
        public static class StatisticsData {
            volatile long JZYQBBZVTK;

            volatile long SITFQARQJY;

            volatile int RXSOAJJYEX;

            volatile int ALBCXRIXTR;

            volatile int YNYTOALDBC;

            /**
             * Stores a weak reference to the thread owning this StatisticsData.
             * This allows us to remove StatisticsData objects that pertain to
             * threads that no longer exist.
             */
            final WeakReference<Thread> HOEUWKRFRB;

            StatisticsData(WeakReference<Thread> owner) {
                this.HOEUWKRFRB = owner;
            }

            /**
             * Add another StatisticsData object to this one.
             */
            void add(FileSystem.Statistics.StatisticsData other) {
                this.JZYQBBZVTK += other.JZYQBBZVTK;
                this.SITFQARQJY += other.SITFQARQJY;
                this.RXSOAJJYEX += other.RXSOAJJYEX;
                this.ALBCXRIXTR += other.ALBCXRIXTR;
                this.YNYTOALDBC += other.YNYTOALDBC;
            }

            /**
             * Negate the values of all statistics.
             */
            void negate() {
                this.JZYQBBZVTK = -this.JZYQBBZVTK;
                this.SITFQARQJY = -this.SITFQARQJY;
                this.RXSOAJJYEX = -this.RXSOAJJYEX;
                this.ALBCXRIXTR = -this.ALBCXRIXTR;
                this.YNYTOALDBC = -this.YNYTOALDBC;
            }

            @Override
            public String toString() {
                return ((((((((JZYQBBZVTK + " bytes read, ") + SITFQARQJY) + " bytes written, ") + RXSOAJJYEX) + " read ops, ") + ALBCXRIXTR) + " large read ops, ") + YNYTOALDBC) + " write ops";
            }

            public long getBytesRead() {
                return JZYQBBZVTK;
            }

            public long getBytesWritten() {
                return SITFQARQJY;
            }

            public int getReadOps() {
                return RXSOAJJYEX;
            }

            public int getLargeReadOps() {
                return ALBCXRIXTR;
            }

            public int getWriteOps() {
                return YNYTOALDBC;
            }
        }

        private interface StatisticsAggregator<T> {
            void accept(FileSystem.Statistics.StatisticsData data);

            T aggregate();
        }

        private final String RRGTERANUH;

        /**
         * rootData is data that doesn't belong to any thread, but will be added
         * to the totals.  This is useful for making copies of Statistics objects,
         * and for storing data that pertains to threads that have been garbage
         * collected.  Protected by the Statistics lock.
         */
        private final FileSystem.Statistics.StatisticsData ZZNAGHVFJE;

        /**
         * Thread-local data.
         */
        private final ThreadLocal<FileSystem.Statistics.StatisticsData> FZRTJUMNIX;

        /**
         * List of all thread-local data areas.  Protected by the Statistics lock.
         */
        private LinkedList<FileSystem.Statistics.StatisticsData> TWXOCIPQIQ;

        public Statistics(String scheme) {
            this.RRGTERANUH = scheme;
            this.ZZNAGHVFJE = new FileSystem.Statistics.StatisticsData(null);
            this.FZRTJUMNIX = new ThreadLocal<FileSystem.Statistics.StatisticsData>();
            this.TWXOCIPQIQ = null;
        }

        /**
         * Copy constructor.
         *
         * @param other
         * 		The input Statistics object which is cloned.
         */
        public Statistics(FileSystem.Statistics other) {
            this.RRGTERANUH = other.RRGTERANUH;
            this.ZZNAGHVFJE = new FileSystem.Statistics.StatisticsData(null);
            other.visitAll(new FileSystem.Statistics.StatisticsAggregator<Void>() {
                @Override
                public void accept(FileSystem.Statistics.StatisticsData data) {
                    ZZNAGHVFJE.add(data);
                }

                public Void aggregate() {
                    return null;
                }
            });
            this.FZRTJUMNIX = new ThreadLocal<FileSystem.Statistics.StatisticsData>();
        }

        /**
         * Get or create the thread-local data associated with the current thread.
         */
        public FileSystem.Statistics.StatisticsData getThreadStatistics() {
            FileSystem.Statistics.StatisticsData data = FZRTJUMNIX.get();
            if (data == null) {
                data = new FileSystem.Statistics.StatisticsData(new WeakReference<Thread>(Thread.currentThread()));
                FZRTJUMNIX.set(data);
                synchronized(this) {
                    if (TWXOCIPQIQ == null) {
                        TWXOCIPQIQ = new LinkedList<FileSystem.Statistics.StatisticsData>();
                    }
                    TWXOCIPQIQ.add(data);
                }
            }
            return data;
        }

        /**
         * Increment the bytes read in the statistics
         *
         * @param newBytes
         * 		the additional bytes read
         */
        public void incrementBytesRead(long newBytes) {
            getThreadStatistics().JZYQBBZVTK += newBytes;
        }

        /**
         * Increment the bytes written in the statistics
         *
         * @param newBytes
         * 		the additional bytes written
         */
        public void incrementBytesWritten(long newBytes) {
            getThreadStatistics().SITFQARQJY += newBytes;
        }

        /**
         * Increment the number of read operations
         *
         * @param count
         * 		number of read operations
         */
        public void incrementReadOps(int count) {
            getThreadStatistics().RXSOAJJYEX += count;
        }

        /**
         * Increment the number of large read operations
         *
         * @param count
         * 		number of large read operations
         */
        public void incrementLargeReadOps(int count) {
            getThreadStatistics().ALBCXRIXTR += count;
        }

        /**
         * Increment the number of write operations
         *
         * @param count
         * 		number of write operations
         */
        public void incrementWriteOps(int count) {
            getThreadStatistics().YNYTOALDBC += count;
        }

        /**
         * Apply the given aggregator to all StatisticsData objects associated with
         * this Statistics object.
         *
         * For each StatisticsData object, we will call accept on the visitor.
         * Finally, at the end, we will call aggregate to get the final total.
         *
         * @param The
         * 		visitor to use.
         * @return The total.
         */
        private synchronized <T> T visitAll(FileSystem.Statistics.StatisticsAggregator<T> visitor) {
            visitor.accept(ZZNAGHVFJE);
            if (TWXOCIPQIQ != null) {
                for (Iterator<FileSystem.Statistics.StatisticsData> iter = TWXOCIPQIQ.iterator(); iter.hasNext();) {
                    FileSystem.Statistics.StatisticsData data = iter.next();
                    visitor.accept(data);
                    if (data.HOEUWKRFRB.get() == null) {
                        /* If the thread that created this thread-local data no
                        longer exists, remove the StatisticsData from our list
                        and fold the values into rootData.
                         */
                        ZZNAGHVFJE.add(data);
                        iter.remove();
                    }
                }
            }
            return visitor.aggregate();
        }

        /**
         * Get the total number of bytes read
         *
         * @return the number of bytes
         */
        public long getBytesRead() {
            return visitAll(new FileSystem.Statistics.StatisticsAggregator<Long>() {
                private long KCAAAIDNHH = 0;

                @Override
                public void accept(FileSystem.Statistics.StatisticsData data) {
                    KCAAAIDNHH += data.JZYQBBZVTK;
                }

                public Long aggregate() {
                    return KCAAAIDNHH;
                }
            });
        }

        /**
         * Get the total number of bytes written
         *
         * @return the number of bytes
         */
        public long getBytesWritten() {
            return visitAll(new FileSystem.Statistics.StatisticsAggregator<Long>() {
                private long SFSLFOFOMO = 0;

                @Override
                public void accept(FileSystem.Statistics.StatisticsData data) {
                    SFSLFOFOMO += data.SITFQARQJY;
                }

                public Long aggregate() {
                    return SFSLFOFOMO;
                }
            });
        }

        /**
         * Get the number of file system read operations such as list files
         *
         * @return number of read operations
         */
        public int getReadOps() {
            return visitAll(new FileSystem.Statistics.StatisticsAggregator<Integer>() {
                private int QLALPFKIEY = 0;

                @Override
                public void accept(FileSystem.Statistics.StatisticsData data) {
                    QLALPFKIEY += data.RXSOAJJYEX;
                    QLALPFKIEY += data.ALBCXRIXTR;
                }

                public Integer aggregate() {
                    return QLALPFKIEY;
                }
            });
        }

        /**
         * Get the number of large file system read operations such as list files
         * under a large directory
         *
         * @return number of large read operations
         */
        public int getLargeReadOps() {
            return visitAll(new FileSystem.Statistics.StatisticsAggregator<Integer>() {
                private int VPULUVKLLZ = 0;

                @Override
                public void accept(FileSystem.Statistics.StatisticsData data) {
                    VPULUVKLLZ += data.ALBCXRIXTR;
                }

                public Integer aggregate() {
                    return VPULUVKLLZ;
                }
            });
        }

        /**
         * Get the number of file system write operations such as create, append
         * rename etc.
         *
         * @return number of write operations
         */
        public int getWriteOps() {
            return visitAll(new FileSystem.Statistics.StatisticsAggregator<Integer>() {
                private int JEOXFFMCVB = 0;

                @Override
                public void accept(FileSystem.Statistics.StatisticsData data) {
                    JEOXFFMCVB += data.YNYTOALDBC;
                }

                public Integer aggregate() {
                    return JEOXFFMCVB;
                }
            });
        }

        @Override
        public String toString() {
            return visitAll(new FileSystem.Statistics.StatisticsAggregator<String>() {
                private FileSystem.Statistics.StatisticsData VPDMVTTGBB = new FileSystem.Statistics.StatisticsData(null);

                @Override
                public void accept(FileSystem.Statistics.StatisticsData data) {
                    VPDMVTTGBB.add(data);
                }

                public String aggregate() {
                    return VPDMVTTGBB.toString();
                }
            });
        }

        /**
         * Resets all statistics to 0.
         *
         * In order to reset, we add up all the thread-local statistics data, and
         * set rootData to the negative of that.
         *
         * This may seem like a counterintuitive way to reset the statsitics.  Why
         * can't we just zero out all the thread-local data?  Well, thread-local
         * data can only be modified by the thread that owns it.  If we tried to
         * modify the thread-local data from this thread, our modification might get
         * interleaved with a read-modify-write operation done by the thread that
         * owns the data.  That would result in our update getting lost.
         *
         * The approach used here avoids this problem because it only ever reads
         * (not writes) the thread-local data.  Both reads and writes to rootData
         * are done under the lock, so we're free to modify rootData from any thread
         * that holds the lock.
         */
        public void reset() {
            visitAll(new FileSystem.Statistics.StatisticsAggregator<Void>() {
                private FileSystem.Statistics.StatisticsData EKUXPQCDAS = new FileSystem.Statistics.StatisticsData(null);

                @Override
                public void accept(FileSystem.Statistics.StatisticsData data) {
                    EKUXPQCDAS.add(data);
                }

                public Void aggregate() {
                    EKUXPQCDAS.negate();
                    ZZNAGHVFJE.add(EKUXPQCDAS);
                    return null;
                }
            });
        }

        /**
         * Get the uri scheme associated with this statistics object.
         *
         * @return the schema associated with this set of statistics
         */
        public String getScheme() {
            return RRGTERANUH;
        }
    }

    /**
     * Get the Map of Statistics object indexed by URI Scheme.
     *
     * @return a Map having a key as URI scheme and value as Statistics object
     * @deprecated use {@link #getAllStatistics} instead
     */
    @Deprecated
    public static synchronized Map<String, FileSystem.Statistics> getStatistics() {
        Map<String, FileSystem.Statistics> EDOVCZNNQR = new HashMap<String, FileSystem.Statistics>();
        for (FileSystem.Statistics WUIRBNRGIK : FileSystem.HFQDHKUNXS.values()) {
            EDOVCZNNQR.put(WUIRBNRGIK.getScheme(), WUIRBNRGIK);
        }
        return EDOVCZNNQR;
    }

    /**
     * Return the FileSystem classes that have Statistics
     */
    public static synchronized List<FileSystem.Statistics> getAllStatistics() {
        return new ArrayList<FileSystem.Statistics>(FileSystem.HFQDHKUNXS.values());
    }

    /**
     * Get the statistics for a particular file system
     *
     * @param cls
     * 		the class to lookup
     * @return a statistics object
     */
    public static synchronized FileSystem.Statistics getStatistics(String ADMSTIGPAN, Class<? extends FileSystem> LGVFFYEGTZ) {
        FileSystem.Statistics CYWIXILDPU = FileSystem.HFQDHKUNXS.get(LGVFFYEGTZ);
        if (CYWIXILDPU == null) {
            CYWIXILDPU = new FileSystem.Statistics(ADMSTIGPAN);
            FileSystem.HFQDHKUNXS.put(LGVFFYEGTZ, CYWIXILDPU);
        }
        return CYWIXILDPU;
    }

    /**
     * Reset all statistics for all file systems
     */
    public static synchronized void clearStatistics() {
        for (FileSystem.Statistics QIEQEKJNOX : FileSystem.HFQDHKUNXS.values()) {
            QIEQEKJNOX.reset();
        }
    }

    /**
     * Print all statistics for all file systems
     */
    public static synchronized void printStatistics() throws IOException {
        for (Map.Entry<Class<? extends FileSystem>, FileSystem.Statistics> BOPKTRUXIR : FileSystem.HFQDHKUNXS.entrySet()) {
            System.out.println((("  FileSystem " + BOPKTRUXIR.getKey().getName()) + ": ") + BOPKTRUXIR.getValue());
        }
    }
}