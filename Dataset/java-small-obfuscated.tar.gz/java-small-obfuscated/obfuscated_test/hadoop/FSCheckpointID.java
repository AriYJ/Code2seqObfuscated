/**
 * A FileSystem based checkpoint ID contains reference to the Path
 * where the checkpoint has been saved.
 */
public class FSCheckpointID implements CheckpointID {
    private Path CXSQRRPDGR;

    public FSCheckpointID() {
    }

    public FSCheckpointID(Path TNUQJQVYRO) {
        this.CXSQRRPDGR = TNUQJQVYRO;
    }

    public Path getPath() {
        return CXSQRRPDGR;
    }

    @Override
    public String toString() {
        return CXSQRRPDGR.toString();
    }

    @Override
    public void write(DataOutput RSYMERZUJL) throws IOException {
        Text.writeString(RSYMERZUJL, CXSQRRPDGR.toString());
    }

    @Override
    public void readFields(DataInput UORTKNQZNP) throws IOException {
        this.CXSQRRPDGR = new Path(Text.readString(UORTKNQZNP));
    }

    @Override
    public boolean equals(Object WOKQFQWDKG) {
        return (WOKQFQWDKG instanceof FSCheckpointID) && CXSQRRPDGR.equals(((FSCheckpointID) (WOKQFQWDKG)).CXSQRRPDGR);
    }

    @Override
    public int hashCode() {
        return CXSQRRPDGR.hashCode();
    }
}