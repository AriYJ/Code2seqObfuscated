public class TestFadvisedFileRegion {
    private final int SBYUXBPRIA = (16 * 1024) * 1024;

    private static final Log LFTGNXARNW = LogFactory.getLog(TestFadvisedFileRegion.class);

    @Test(timeout = 100000)
    public void testCustomShuffleTransfer() throws IOException {
        File VMBQMQUJLT = new File("target", TestFadvisedFileRegion.class.getSimpleName() + "LocDir").getAbsoluteFile();
        String RDWOFFBASQ = StringUtils.join(SEPARATOR, new String[]{ VMBQMQUJLT.getAbsolutePath(), "testCustomShuffleTransfer" });
        File HBVKUIVRMO = new File(RDWOFFBASQ);
        HBVKUIVRMO.mkdirs();
        System.out.println(HBVKUIVRMO.getAbsolutePath());
        File DKUVELRWFF = new File(HBVKUIVRMO, "fileIn.out");
        File IIVKWLRVXE = new File(HBVKUIVRMO, "fileOut.out");
        // Initialize input file
        byte[] SNQYGFZAUG = new byte[SBYUXBPRIA];
        Random IOVCHGDPWY = new Random();
        IOVCHGDPWY.nextBytes(SNQYGFZAUG);
        FileOutputStream XGVXLRIHRN = new FileOutputStream(DKUVELRWFF);
        try {
            XGVXLRIHRN.write(SNQYGFZAUG);
        } finally {
            IOUtils.cleanup(TestFadvisedFileRegion.LFTGNXARNW, XGVXLRIHRN);
        }
        // define position and count to read from a file region.
        int JRMDHJZHUE = (2 * 1024) * 1024;
        int RNFSCOSNNJ = ((4 * 1024) * 1024) - 1;
        RandomAccessFile SJXLBDOSGZ = null;
        RandomAccessFile BASWNIUPDV = null;
        WritableByteChannel JKCNHEVFHD = null;
        FadvisedFileRegion HVBHUSDETO = null;
        try {
            SJXLBDOSGZ = new RandomAccessFile(DKUVELRWFF.getAbsolutePath(), "r");
            BASWNIUPDV = new RandomAccessFile(IIVKWLRVXE.getAbsolutePath(), "rw");
            JKCNHEVFHD = BASWNIUPDV.getChannel();
            Assert.assertEquals(SBYUXBPRIA, SJXLBDOSGZ.length());
            // create FadvisedFileRegion
            HVBHUSDETO = new FadvisedFileRegion(SJXLBDOSGZ, JRMDHJZHUE, RNFSCOSNNJ, false, 0, null, null, 1024, false);
            // test corner cases
            TestFadvisedFileRegion.customShuffleTransferCornerCases(HVBHUSDETO, JKCNHEVFHD, RNFSCOSNNJ);
            long RLRSVXRIJL = 0;
            long EMLXGMVXSD;
            while ((EMLXGMVXSD = HVBHUSDETO.customShuffleTransfer(JKCNHEVFHD, RLRSVXRIJL)) > 0) {
                RLRSVXRIJL += EMLXGMVXSD;
            } 
            // assert size
            Assert.assertEquals(RNFSCOSNNJ, ((int) (RLRSVXRIJL)));
            Assert.assertEquals(RNFSCOSNNJ, BASWNIUPDV.length());
        } finally {
            if (HVBHUSDETO != null) {
                HVBHUSDETO.releaseExternalResources();
            }
            IOUtils.cleanup(TestFadvisedFileRegion.LFTGNXARNW, JKCNHEVFHD);
            IOUtils.cleanup(TestFadvisedFileRegion.LFTGNXARNW, BASWNIUPDV);
            IOUtils.cleanup(TestFadvisedFileRegion.LFTGNXARNW, SJXLBDOSGZ);
        }
        // Read the target file and verify that copy is done correctly
        byte[] BJTTGTLYTN = new byte[SBYUXBPRIA];
        FileInputStream NFEWEMCJTG = new FileInputStream(IIVKWLRVXE);
        try {
            int VBEFNTVENM = NFEWEMCJTG.read(BJTTGTLYTN, 0, RNFSCOSNNJ);
            Assert.assertEquals(RNFSCOSNNJ, VBEFNTVENM);
            for (int VNLGDXPPBG = 0; VNLGDXPPBG < RNFSCOSNNJ; VNLGDXPPBG++) {
                Assert.assertEquals(SNQYGFZAUG[JRMDHJZHUE + VNLGDXPPBG], BJTTGTLYTN[VNLGDXPPBG]);
            }
        } finally {
            IOUtils.cleanup(TestFadvisedFileRegion.LFTGNXARNW, NFEWEMCJTG);
        }
        // delete files and folders
        DKUVELRWFF.delete();
        IIVKWLRVXE.delete();
        HBVKUIVRMO.delete();
        VMBQMQUJLT.delete();
    }

    private static void customShuffleTransferCornerCases(FadvisedFileRegion UUTIQGAOGO, WritableByteChannel ZYJHTIRMSA, int QBXVAVSRJR) {
        try {
            UUTIQGAOGO.customShuffleTransfer(ZYJHTIRMSA, -1);
            Assert.fail("Expected a IllegalArgumentException");
        } catch (IllegalArgumentException ie) {
            TestFadvisedFileRegion.LFTGNXARNW.info("Expected - illegal argument is passed.");
        } catch (Exception e) {
            Assert.fail("Expected a IllegalArgumentException");
        }
        // test corner cases
        try {
            UUTIQGAOGO.customShuffleTransfer(ZYJHTIRMSA, QBXVAVSRJR + 1);
            Assert.fail("Expected a IllegalArgumentException");
        } catch (IllegalArgumentException ie) {
            TestFadvisedFileRegion.LFTGNXARNW.info("Expected - illegal argument is passed.");
        } catch (Exception e) {
            Assert.fail("Expected a IllegalArgumentException");
        }
    }
}