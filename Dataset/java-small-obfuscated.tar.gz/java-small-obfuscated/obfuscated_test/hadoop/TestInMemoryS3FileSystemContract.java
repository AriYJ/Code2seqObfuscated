public class TestInMemoryS3FileSystemContract extends S3FileSystemContractBaseTest {
    @Override
    FileSystemStore getFileSystemStore() throws IOException {
        return new InMemoryFileSystemStore();
    }
}