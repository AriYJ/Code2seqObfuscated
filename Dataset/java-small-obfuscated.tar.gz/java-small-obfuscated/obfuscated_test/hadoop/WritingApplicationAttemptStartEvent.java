public class WritingApplicationAttemptStartEvent extends WritingApplicationHistoryEvent {
    private ApplicationAttemptId RKSCLFURPT;

    private ApplicationAttemptStartData BHHEUVVFOK;

    public WritingApplicationAttemptStartEvent(ApplicationAttemptId JBGNQALOVJ, ApplicationAttemptStartData XPNEZCJYMA) {
        super(APP_ATTEMPT_START);
        this.RKSCLFURPT = JBGNQALOVJ;
        this.BHHEUVVFOK = XPNEZCJYMA;
    }

    @Override
    public int hashCode() {
        return RKSCLFURPT.getApplicationId().hashCode();
    }

    public ApplicationAttemptId getApplicationAttemptId() {
        return RKSCLFURPT;
    }

    public ApplicationAttemptStartData getApplicationAttemptStartData() {
        return BHHEUVVFOK;
    }
}