/**
 * Tests {@link DirectoryScanner} handling of differences
 * between blocks on the disk and block in memory.
 */
public class TestDirectoryScanner {
    private static final Log VPLOUHBDAC = LogFactory.getLog(TestDirectoryScanner.class);

    private static final Configuration EVHPOYGKOW = new HdfsConfiguration();

    private static final int MTKJIRSDRH = 9999;

    private MiniDFSCluster URWKHRORNO;

    private String CNRZRFIRXP;

    private FsDatasetSpi<? extends FsVolumeSpi> CCCQQWUHTA = null;

    private DirectoryScanner VIATDREZTW = null;

    private final Random SGQZARGOSU = new Random();

    private final Random KPRXWWMTAH = new Random();

    static {
        TestDirectoryScanner.EVHPOYGKOW.setLong(DFS_BLOCK_SIZE_KEY, 100);
        TestDirectoryScanner.EVHPOYGKOW.setInt(DFS_BYTES_PER_CHECKSUM_KEY, 1);
        TestDirectoryScanner.EVHPOYGKOW.setLong(DFS_HEARTBEAT_INTERVAL_KEY, 1L);
    }

    /**
     * create a file with a length of <code>fileLen</code>
     */
    private void createFile(String OHQUQVNABA, long WCVRWBEJSG) throws IOException {
        FileSystem WTZGLVKQTH = URWKHRORNO.getFileSystem();
        Path SVHBGDEIAN = new Path(OHQUQVNABA);
        DFSTestUtil.createFile(WTZGLVKQTH, SVHBGDEIAN, WCVRWBEJSG, ((short) (1)), KPRXWWMTAH.nextLong());
    }

    /**
     * Truncate a block file
     */
    private long truncateBlockFile() throws IOException {
        synchronized(CCCQQWUHTA) {
            for (ReplicaInfo SZLJNVLUOZ : FsDatasetTestUtil.getReplicas(CCCQQWUHTA, CNRZRFIRXP)) {
                File VPFJFTFIXZ = SZLJNVLUOZ.getBlockFile();
                File REINNUDVEP = SZLJNVLUOZ.getMetaFile();
                // Truncate a block file that has a corresponding metadata file
                if ((VPFJFTFIXZ.exists() && (VPFJFTFIXZ.length() != 0)) && REINNUDVEP.exists()) {
                    FileOutputStream RNGUJAMJLA = null;
                    FileChannel OFQYETXDFS = null;
                    try {
                        RNGUJAMJLA = new FileOutputStream(VPFJFTFIXZ);
                        OFQYETXDFS = RNGUJAMJLA.getChannel();
                        OFQYETXDFS.truncate(0);
                        TestDirectoryScanner.VPLOUHBDAC.info("Truncated block file " + VPFJFTFIXZ.getAbsolutePath());
                        return SZLJNVLUOZ.getBlockId();
                    } finally {
                        IOUtils.cleanup(TestDirectoryScanner.VPLOUHBDAC, OFQYETXDFS, RNGUJAMJLA);
                    }
                }
            }
        }
        return 0;
    }

    /**
     * Delete a block file
     */
    private long deleteBlockFile() {
        synchronized(CCCQQWUHTA) {
            for (ReplicaInfo TVROHTPPMI : FsDatasetTestUtil.getReplicas(CCCQQWUHTA, CNRZRFIRXP)) {
                File MYASWIMWVT = TVROHTPPMI.getBlockFile();
                File LOACVIMKBC = TVROHTPPMI.getMetaFile();
                // Delete a block file that has corresponding metadata file
                if ((MYASWIMWVT.exists() && LOACVIMKBC.exists()) && MYASWIMWVT.delete()) {
                    TestDirectoryScanner.VPLOUHBDAC.info("Deleting block file " + MYASWIMWVT.getAbsolutePath());
                    return TVROHTPPMI.getBlockId();
                }
            }
        }
        return 0;
    }

    /**
     * Delete block meta file
     */
    private long deleteMetaFile() {
        synchronized(CCCQQWUHTA) {
            for (ReplicaInfo BCMNRCSMOG : FsDatasetTestUtil.getReplicas(CCCQQWUHTA, CNRZRFIRXP)) {
                File KKFXKRRLNG = BCMNRCSMOG.getMetaFile();
                // Delete a metadata file
                if (KKFXKRRLNG.exists() && KKFXKRRLNG.delete()) {
                    TestDirectoryScanner.VPLOUHBDAC.info("Deleting metadata file " + KKFXKRRLNG.getAbsolutePath());
                    return BCMNRCSMOG.getBlockId();
                }
            }
        }
        return 0;
    }

    /**
     * Get a random blockId that is not used already
     */
    private long getFreeBlockId() {
        long WJVBYSSKCW = SGQZARGOSU.nextLong();
        while (true) {
            WJVBYSSKCW = SGQZARGOSU.nextLong();
            if (FsDatasetTestUtil.fetchReplicaInfo(CCCQQWUHTA, CNRZRFIRXP, WJVBYSSKCW) == null) {
                break;
            }
        } 
        return WJVBYSSKCW;
    }

    private String getBlockFile(long XFYKMRIAHK) {
        return Block.BLOCK_FILE_PREFIX + XFYKMRIAHK;
    }

    private String getMetaFile(long BONTZLLDNR) {
        return (((Block.BLOCK_FILE_PREFIX + BONTZLLDNR) + "_") + TestDirectoryScanner.MTKJIRSDRH) + Block.METADATA_EXTENSION;
    }

    /**
     * Create a block file in a random volume
     */
    private long createBlockFile() throws IOException {
        List<? extends FsVolumeSpi> IXEHIBADIE = CCCQQWUHTA.getVolumes();
        int NQJLQCZITS = SGQZARGOSU.nextInt(IXEHIBADIE.size() - 1);
        long ITUCMQSWQG = getFreeBlockId();
        File QOZZSKTHLN = IXEHIBADIE.get(NQJLQCZITS).getFinalizedDir(CNRZRFIRXP);
        File MHUOWBOHTJ = new File(QOZZSKTHLN, getBlockFile(ITUCMQSWQG));
        if (MHUOWBOHTJ.createNewFile()) {
            TestDirectoryScanner.VPLOUHBDAC.info("Created block file " + MHUOWBOHTJ.getName());
        }
        return ITUCMQSWQG;
    }

    /**
     * Create a metafile in a random volume
     */
    private long createMetaFile() throws IOException {
        List<? extends FsVolumeSpi> KDVAVJIUMZ = CCCQQWUHTA.getVolumes();
        int UGKAFGYFNK = SGQZARGOSU.nextInt(KDVAVJIUMZ.size() - 1);
        long RMZTILYIYT = getFreeBlockId();
        File BSEONBBXQW = KDVAVJIUMZ.get(UGKAFGYFNK).getFinalizedDir(CNRZRFIRXP);
        File EVTMISEZHI = new File(BSEONBBXQW, getMetaFile(RMZTILYIYT));
        if (EVTMISEZHI.createNewFile()) {
            TestDirectoryScanner.VPLOUHBDAC.info("Created metafile " + EVTMISEZHI.getName());
        }
        return RMZTILYIYT;
    }

    /**
     * Create block file and corresponding metafile in a rondom volume
     */
    private long createBlockMetaFile() throws IOException {
        List<? extends FsVolumeSpi> NXTPHDRWLF = CCCQQWUHTA.getVolumes();
        int CQKIFRSCOW = SGQZARGOSU.nextInt(NXTPHDRWLF.size() - 1);
        long QTTBMBDKFX = getFreeBlockId();
        File PTOORFATJW = NXTPHDRWLF.get(CQKIFRSCOW).getFinalizedDir(CNRZRFIRXP);
        File WCOSZKLQRT = new File(PTOORFATJW, getBlockFile(QTTBMBDKFX));
        if (WCOSZKLQRT.createNewFile()) {
            TestDirectoryScanner.VPLOUHBDAC.info("Created block file " + WCOSZKLQRT.getName());
            // Create files with same prefix as block file but extension names
            // such that during sorting, these files appear around meta file
            // to test how DirectoryScanner handles extraneous files
            String QALZIZFPLN = WCOSZKLQRT.getAbsolutePath() + ".l";
            String CGVKRRZKBK = WCOSZKLQRT.getAbsolutePath() + ".n";
            WCOSZKLQRT = new File(QALZIZFPLN);
            if (WCOSZKLQRT.createNewFile()) {
                TestDirectoryScanner.VPLOUHBDAC.info("Created extraneous file " + QALZIZFPLN);
            }
            WCOSZKLQRT = new File(CGVKRRZKBK);
            if (WCOSZKLQRT.createNewFile()) {
                TestDirectoryScanner.VPLOUHBDAC.info("Created extraneous file " + CGVKRRZKBK);
            }
            WCOSZKLQRT = new File(PTOORFATJW, getMetaFile(QTTBMBDKFX));
            if (WCOSZKLQRT.createNewFile()) {
                TestDirectoryScanner.VPLOUHBDAC.info("Created metafile " + WCOSZKLQRT.getName());
            }
        }
        return QTTBMBDKFX;
    }

    private void scan(long YSCTJOSZYQ, int PFAPTIXUUW, long SVTCBINCZH, long ZTUBWBMKET, long PRQXUEXHDI, long UUGNGADANV) {
        VIATDREZTW.reconcile();
        assertTrue(VIATDREZTW.diffs.containsKey(CNRZRFIRXP));
        LinkedList<DirectoryScanner.ScanInfo> POOWQWVARF = VIATDREZTW.diffs.get(CNRZRFIRXP);
        assertTrue(VIATDREZTW.stats.containsKey(CNRZRFIRXP));
        DirectoryScanner.Stats TCNKAQVLOI = VIATDREZTW.stats.get(CNRZRFIRXP);
        assertEquals(PFAPTIXUUW, POOWQWVARF.size());
        assertEquals(YSCTJOSZYQ, TCNKAQVLOI.totalBlocks);
        assertEquals(SVTCBINCZH, TCNKAQVLOI.missingMetaFile);
        assertEquals(ZTUBWBMKET, TCNKAQVLOI.missingBlockFile);
        assertEquals(PRQXUEXHDI, TCNKAQVLOI.missingMemoryBlocks);
        assertEquals(UUGNGADANV, TCNKAQVLOI.mismatchBlocks);
    }

    @Test
    public void testDirectoryScanner() throws Exception {
        // Run the test with and without parallel scanning
        for (int XECZOBWPYI = 1; XECZOBWPYI < 3; XECZOBWPYI++) {
            runTest(XECZOBWPYI);
        }
    }

    public void runTest(int GXFHUDGQFW) throws Exception {
        URWKHRORNO = new MiniDFSCluster.Builder(TestDirectoryScanner.EVHPOYGKOW).build();
        try {
            URWKHRORNO.waitActive();
            CNRZRFIRXP = URWKHRORNO.getNamesystem().getBlockPoolId();
            CCCQQWUHTA = DataNodeTestUtils.getFSDataset(URWKHRORNO.getDataNodes().get(0));
            TestDirectoryScanner.EVHPOYGKOW.setInt(DFS_DATANODE_DIRECTORYSCAN_THREADS_KEY, GXFHUDGQFW);
            VIATDREZTW = new DirectoryScanner(CCCQQWUHTA, TestDirectoryScanner.EVHPOYGKOW);
            VIATDREZTW.setRetainDiffs(true);
            // Add files with 100 blocks
            createFile("/tmp/t1", 10000);
            long PXNXXKTMIC = 100;
            // Test1: No difference between in-memory and disk
            scan(100, 0, 0, 0, 0, 0);
            // Test2: block metafile is missing
            long QTJJPRONZJ = deleteMetaFile();
            scan(PXNXXKTMIC, 1, 1, 0, 0, 1);
            verifyGenStamp(QTJJPRONZJ, GRANDFATHER_GENERATION_STAMP);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test3: block file is missing
            QTJJPRONZJ = deleteBlockFile();
            scan(PXNXXKTMIC, 1, 0, 1, 0, 0);
            PXNXXKTMIC--;
            verifyDeletion(QTJJPRONZJ);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test4: A block file exists for which there is no metafile and
            // a block in memory
            QTJJPRONZJ = createBlockFile();
            PXNXXKTMIC++;
            scan(PXNXXKTMIC, 1, 1, 0, 1, 0);
            verifyAddition(QTJJPRONZJ, GRANDFATHER_GENERATION_STAMP, 0);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test5: A metafile exists for which there is no block file and
            // a block in memory
            QTJJPRONZJ = createMetaFile();
            scan(PXNXXKTMIC + 1, 1, 0, 1, 1, 0);
            File JLIFVMGAVZ = new File(getMetaFile(QTJJPRONZJ));
            assertTrue(!JLIFVMGAVZ.exists());
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test6: A block file and metafile exists for which there is no block in
            // memory
            QTJJPRONZJ = createBlockMetaFile();
            PXNXXKTMIC++;
            scan(PXNXXKTMIC, 1, 0, 0, 1, 0);
            verifyAddition(QTJJPRONZJ, TestDirectoryScanner.MTKJIRSDRH, 0);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test7: Delete bunch of metafiles
            for (int ZYCALWHXJH = 0; ZYCALWHXJH < 10; ZYCALWHXJH++) {
                QTJJPRONZJ = deleteMetaFile();
            }
            scan(PXNXXKTMIC, 10, 10, 0, 0, 10);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test8: Delete bunch of block files
            for (int BKVXESGUQG = 0; BKVXESGUQG < 10; BKVXESGUQG++) {
                QTJJPRONZJ = deleteBlockFile();
            }
            scan(PXNXXKTMIC, 10, 0, 10, 0, 0);
            PXNXXKTMIC -= 10;
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test9: create a bunch of blocks files
            for (int LBTGOGZYQF = 0; LBTGOGZYQF < 10; LBTGOGZYQF++) {
                QTJJPRONZJ = createBlockFile();
            }
            PXNXXKTMIC += 10;
            scan(PXNXXKTMIC, 10, 10, 0, 10, 0);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test10: create a bunch of metafiles
            for (int LWSZTLHWVR = 0; LWSZTLHWVR < 10; LWSZTLHWVR++) {
                QTJJPRONZJ = createMetaFile();
            }
            scan(PXNXXKTMIC + 10, 10, 0, 10, 10, 0);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test11: create a bunch block files and meta files
            for (int BNKBEYKJFM = 0; BNKBEYKJFM < 10; BNKBEYKJFM++) {
                QTJJPRONZJ = createBlockMetaFile();
            }
            PXNXXKTMIC += 10;
            scan(PXNXXKTMIC, 10, 0, 0, 10, 0);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test12: truncate block files to test block length mismatch
            for (int YUKERBLIVA = 0; YUKERBLIVA < 10; YUKERBLIVA++) {
                truncateBlockFile();
            }
            scan(PXNXXKTMIC, 10, 0, 0, 0, 10);
            scan(PXNXXKTMIC, 0, 0, 0, 0, 0);
            // Test13: all the conditions combined
            createMetaFile();
            createBlockFile();
            createBlockMetaFile();
            deleteMetaFile();
            deleteBlockFile();
            truncateBlockFile();
            scan(PXNXXKTMIC + 3, 6, 2, 2, 3, 2);
            scan(PXNXXKTMIC + 1, 0, 0, 0, 0, 0);
            // Test14: validate clean shutdown of DirectoryScanner
            // //assertTrue(scanner.getRunStatus()); //assumes "real" FSDataset, not sim
            VIATDREZTW.shutdown();
            assertFalse(VIATDREZTW.getRunStatus());
        } finally {
            VIATDREZTW.shutdown();
            URWKHRORNO.shutdown();
        }
    }

    private void verifyAddition(long JWPIWGBECC, long YIYMBQJKOL, long CAPZYLIKTM) {
        final ReplicaInfo QMWYKPJFMG;
        QMWYKPJFMG = FsDatasetTestUtil.fetchReplicaInfo(CCCQQWUHTA, CNRZRFIRXP, JWPIWGBECC);
        assertNotNull(QMWYKPJFMG);
        // Added block has the same file as the one created by the test
        File THKUZMSTCQ = new File(getBlockFile(JWPIWGBECC));
        assertEquals(THKUZMSTCQ.getName(), FsDatasetTestUtil.getFile(CCCQQWUHTA, CNRZRFIRXP, JWPIWGBECC).getName());
        // Generation stamp is same as that of created file
        assertEquals(YIYMBQJKOL, QMWYKPJFMG.getGenerationStamp());
        // File size matches
        assertEquals(CAPZYLIKTM, QMWYKPJFMG.getNumBytes());
    }

    private void verifyDeletion(long DFCUVCJJOE) {
        // Ensure block does not exist in memory
        assertNull(FsDatasetTestUtil.fetchReplicaInfo(CCCQQWUHTA, CNRZRFIRXP, DFCUVCJJOE));
    }

    private void verifyGenStamp(long NBLCCABXLF, long ITVUVLRDQY) {
        final ReplicaInfo YUOBSQRPSO;
        YUOBSQRPSO = FsDatasetTestUtil.fetchReplicaInfo(CCCQQWUHTA, CNRZRFIRXP, NBLCCABXLF);
        assertNotNull(YUOBSQRPSO);
        assertEquals(ITVUVLRDQY, YUOBSQRPSO.getGenerationStamp());
    }

    private static class TestFsVolumeSpi implements FsVolumeSpi {
        @Override
        public String[] getBlockPoolList() {
            return new String[0];
        }

        @Override
        public long getAvailable() throws IOException {
            return 0;
        }

        @Override
        public String getBasePath() {
            return new File("/base").getAbsolutePath();
        }

        @Override
        public String getPath(String bpid) throws IOException {
            return new File("/base/current/" + bpid).getAbsolutePath();
        }

        @Override
        public File getFinalizedDir(String bpid) throws IOException {
            return new File(("/base/current/" + bpid) + "/finalized");
        }

        @Override
        public StorageType getStorageType() {
            return StorageType.DEFAULT;
        }

        @Override
        public String getStorageID() {
            return "";
        }
    }

    private static final TestDirectoryScanner.TestFsVolumeSpi WRYEBXSFDE = new TestDirectoryScanner.TestFsVolumeSpi();

    private static final String INJFBTJTJZ = "BP-783049782-127.0.0.1-1370971773491";

    private static final String YFTQEQWYIP = "BP-367845636-127.0.0.1-5895645674231";

    void testScanInfoObject(long DADXWMRKZS, File TZFIJDZSSX, File MDAZERUZIQ) throws Exception {
        DirectoryScanner.ScanInfo CYZDYFPHOU = new DirectoryScanner.ScanInfo(DADXWMRKZS, TZFIJDZSSX, MDAZERUZIQ, TestDirectoryScanner.WRYEBXSFDE);
        assertEquals(DADXWMRKZS, CYZDYFPHOU.getBlockId());
        if (TZFIJDZSSX != null) {
            assertEquals(TZFIJDZSSX.getAbsolutePath(), CYZDYFPHOU.getBlockFile().getAbsolutePath());
        } else {
            assertNull(CYZDYFPHOU.getBlockFile());
        }
        if (MDAZERUZIQ != null) {
            assertEquals(MDAZERUZIQ.getAbsolutePath(), CYZDYFPHOU.getMetaFile().getAbsolutePath());
        } else {
            assertNull(CYZDYFPHOU.getMetaFile());
        }
        assertEquals(TestDirectoryScanner.WRYEBXSFDE, CYZDYFPHOU.getVolume());
    }

    void testScanInfoObject(long EGOFGYCCOQ) throws Exception {
        DirectoryScanner.ScanInfo HHALLKSQMB = new DirectoryScanner.ScanInfo(EGOFGYCCOQ, null, null, null);
        assertEquals(EGOFGYCCOQ, HHALLKSQMB.getBlockId());
        assertNull(HHALLKSQMB.getBlockFile());
        assertNull(HHALLKSQMB.getMetaFile());
    }

    @Test(timeout = 120000)
    public void TestScanInfo() throws Exception {
        testScanInfoObject(123, new File(TestDirectoryScanner.WRYEBXSFDE.getFinalizedDir(TestDirectoryScanner.INJFBTJTJZ).getAbsolutePath(), "blk_123"), new File(TestDirectoryScanner.WRYEBXSFDE.getFinalizedDir(TestDirectoryScanner.INJFBTJTJZ).getAbsolutePath(), "blk_123__1001.meta"));
        testScanInfoObject(464, new File(TestDirectoryScanner.WRYEBXSFDE.getFinalizedDir(TestDirectoryScanner.INJFBTJTJZ).getAbsolutePath(), "blk_123"), null);
        testScanInfoObject(523, null, new File(TestDirectoryScanner.WRYEBXSFDE.getFinalizedDir(TestDirectoryScanner.INJFBTJTJZ).getAbsolutePath(), "blk_123__1009.meta"));
        testScanInfoObject(789, null, null);
        testScanInfoObject(456);
        testScanInfoObject(123, new File(TestDirectoryScanner.WRYEBXSFDE.getFinalizedDir(TestDirectoryScanner.YFTQEQWYIP).getAbsolutePath(), "blk_567"), new File(TestDirectoryScanner.WRYEBXSFDE.getFinalizedDir(TestDirectoryScanner.YFTQEQWYIP).getAbsolutePath(), "blk_567__1004.meta"));
    }
}