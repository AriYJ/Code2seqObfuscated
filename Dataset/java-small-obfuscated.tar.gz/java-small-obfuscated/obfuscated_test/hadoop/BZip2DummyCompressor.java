/**
 * This is a dummy compressor for BZip2.
 */
public class BZip2DummyCompressor implements Compressor {
    @Override
    public int compress(byte[] SBCFQAUXLJ, int CBRSYQRKHI, int UUZVUQMWDI) throws IOException {
        throw new UnsupportedOperationException();
    }

    @Override
    public void end() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void finish() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean finished() {
        throw new UnsupportedOperationException();
    }

    @Override
    public long getBytesRead() {
        throw new UnsupportedOperationException();
    }

    @Override
    public long getBytesWritten() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean needsInput() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void reset() {
        // do nothing
    }

    @Override
    public void setDictionary(byte[] BMBMMLZHEM, int ZRRQCGMAYM, int CIYNUXGIIY) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void setInput(byte[] OKITBBPBLM, int JVBKCIJFIT, int KRTDNOAELZ) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void reinit(Configuration AUAXEGZXNZ) {
        // do nothing
    }
}