/**
 * One of the NN NameNodes acting as the target of an administrative command
 * (e.g. failover).
 */
@InterfaceAudience.Private
public class NNHAServiceTarget extends HAServiceTarget {
    // Keys added to the fencing script environment
    private static final String TMPQTTBQYX = "nameserviceid";

    private static final String YMRTIWTYOG = "namenodeid";

    private final InetSocketAddress UDCWCSXAYM;

    private InetSocketAddress XPYCEXVKUM;

    private NodeFencer ACUDJKTLSA;

    private BadFencingConfigurationException NEWQKSMDXG;

    private final String OJMAZZLXFF;

    private final String MZQAHHNTDK;

    private final boolean OBFKBZHBHR;

    public NNHAServiceTarget(Configuration GBNLEOIORQ, String GARRSQRINE, String UURWZFXJCY) {
        Preconditions.checkNotNull(UURWZFXJCY);
        if (GARRSQRINE == null) {
            GARRSQRINE = DFSUtil.getOnlyNameServiceIdOrNull(GBNLEOIORQ);
            if (GARRSQRINE == null) {
                throw new IllegalArgumentException("Unable to determine the nameservice id.");
            }
        }
        assert GARRSQRINE != null;
        // Make a copy of the conf, and override configs based on the
        // target node -- not the node we happen to be running on.
        HdfsConfiguration RPEOACZJBZ = new HdfsConfiguration(GBNLEOIORQ);
        NameNode.initializeGenericKeys(RPEOACZJBZ, GARRSQRINE, UURWZFXJCY);
        String NMCDNIOKMJ = DFSUtil.getNamenodeServiceAddr(RPEOACZJBZ, GARRSQRINE, UURWZFXJCY);
        if (NMCDNIOKMJ == null) {
            throw new IllegalArgumentException(("Unable to determine service address for namenode '" + UURWZFXJCY) + "'");
        }
        this.UDCWCSXAYM = NetUtils.createSocketAddr(NMCDNIOKMJ, DEFAULT_PORT);
        this.OBFKBZHBHR = RPEOACZJBZ.getBoolean(DFS_HA_AUTO_FAILOVER_ENABLED_KEY, DFS_HA_AUTO_FAILOVER_ENABLED_DEFAULT);
        if (OBFKBZHBHR) {
            int IOZTZGEGMP = DFSZKFailoverController.getZkfcPort(RPEOACZJBZ);
            if (IOZTZGEGMP != 0) {
                setZkfcPort(IOZTZGEGMP);
            }
        }
        try {
            this.ACUDJKTLSA = NodeFencer.create(RPEOACZJBZ, DFS_HA_FENCE_METHODS_KEY);
        } catch (BadFencingConfigurationException e) {
            this.NEWQKSMDXG = e;
        }
        this.OJMAZZLXFF = UURWZFXJCY;
        this.MZQAHHNTDK = GARRSQRINE;
    }

    /**
     *
     *
     * @return the NN's IPC address.
     */
    @Override
    public InetSocketAddress getAddress() {
        return UDCWCSXAYM;
    }

    @Override
    public InetSocketAddress getZKFCAddress() {
        Preconditions.checkState(OBFKBZHBHR, "ZKFC address not relevant when auto failover is off");
        assert XPYCEXVKUM != null;
        return XPYCEXVKUM;
    }

    void setZkfcPort(int SCMTEAREEK) {
        assert OBFKBZHBHR;
        this.XPYCEXVKUM = new InetSocketAddress(UDCWCSXAYM.getAddress(), SCMTEAREEK);
    }

    @Override
    public void checkFencingConfigured() throws BadFencingConfigurationException {
        if (NEWQKSMDXG != null) {
            throw NEWQKSMDXG;
        }
        if (ACUDJKTLSA == null) {
            throw new BadFencingConfigurationException("No fencer configured for " + this);
        }
    }

    @Override
    public NodeFencer getFencer() {
        return ACUDJKTLSA;
    }

    @Override
    public String toString() {
        return "NameNode at " + UDCWCSXAYM;
    }

    public String getNameServiceId() {
        return this.MZQAHHNTDK;
    }

    public String getNameNodeId() {
        return this.OJMAZZLXFF;
    }

    @Override
    protected void addFencingParameters(Map<String, String> KHTXHDBFOW) {
        super.addFencingParameters(KHTXHDBFOW);
        KHTXHDBFOW.put(NNHAServiceTarget.TMPQTTBQYX, getNameServiceId());
        KHTXHDBFOW.put(NNHAServiceTarget.YMRTIWTYOG, getNameNodeId());
    }

    @Override
    public boolean isAutoFailoverEnabled() {
        return OBFKBZHBHR;
    }
}