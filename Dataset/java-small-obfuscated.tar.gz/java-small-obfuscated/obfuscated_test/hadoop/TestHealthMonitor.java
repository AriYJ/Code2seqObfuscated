public class TestHealthMonitor {
    private static final Log SWSSZWGZYA = LogFactory.getLog(TestHealthMonitor.class);

    /**
     * How many times has createProxy been called
     */
    private AtomicInteger COKVDRNOJO = new AtomicInteger(0);

    private volatile boolean HRCHPCVBSB = false;

    private HealthMonitor HIXOMQTPQE;

    private DummyHAService JUESTQGRVF;

    @Before
    public void setupHM() throws IOException, InterruptedException {
        Configuration QOFTVQPAZN = new Configuration();
        QOFTVQPAZN.setInt(IPC_CLIENT_CONNECT_MAX_RETRIES_KEY, 1);
        QOFTVQPAZN.setInt(HA_HM_CHECK_INTERVAL_KEY, 50);
        QOFTVQPAZN.setInt(HA_HM_CONNECT_RETRY_INTERVAL_KEY, 50);
        QOFTVQPAZN.setInt(HA_HM_SLEEP_AFTER_DISCONNECT_KEY, 50);
        JUESTQGRVF = new DummyHAService(HAServiceState.ACTIVE, null);
        HIXOMQTPQE = new HealthMonitor(QOFTVQPAZN, JUESTQGRVF) {
            @Override
            protected HAServiceProtocol createProxy() throws IOException {
                COKVDRNOJO.incrementAndGet();
                if (HRCHPCVBSB) {
                    throw new OutOfMemoryError("oome");
                }
                return super.createProxy();
            }
        };
        TestHealthMonitor.SWSSZWGZYA.info("Starting health monitor");
        HIXOMQTPQE.start();
        TestHealthMonitor.SWSSZWGZYA.info("Waiting for HEALTHY signal");
        waitForState(HIXOMQTPQE, SERVICE_HEALTHY);
    }

    @Test(timeout = 15000)
    public void testMonitor() throws Exception {
        TestHealthMonitor.SWSSZWGZYA.info("Mocking bad health check, waiting for UNHEALTHY");
        JUESTQGRVF.isHealthy = false;
        waitForState(HIXOMQTPQE, SERVICE_UNHEALTHY);
        TestHealthMonitor.SWSSZWGZYA.info("Returning to healthy state, waiting for HEALTHY");
        JUESTQGRVF.isHealthy = true;
        waitForState(HIXOMQTPQE, SERVICE_HEALTHY);
        TestHealthMonitor.SWSSZWGZYA.info("Returning an IOException, as if node went down");
        // should expect many rapid retries
        int UFDQNLKWBS = COKVDRNOJO.get();
        JUESTQGRVF.actUnreachable = true;
        waitForState(HIXOMQTPQE, SERVICE_NOT_RESPONDING);
        // Should retry several times
        while (COKVDRNOJO.get() < (UFDQNLKWBS + 3)) {
            Thread.sleep(10);
        } 
        TestHealthMonitor.SWSSZWGZYA.info("Returning to healthy state, waiting for HEALTHY");
        JUESTQGRVF.actUnreachable = false;
        waitForState(HIXOMQTPQE, SERVICE_HEALTHY);
        HIXOMQTPQE.shutdown();
        HIXOMQTPQE.join();
        assertFalse(HIXOMQTPQE.isAlive());
    }

    /**
     * Test that the proper state is propagated when the health monitor
     * sees an uncaught exception in its thread.
     */
    @Test(timeout = 15000)
    public void testHealthMonitorDies() throws Exception {
        TestHealthMonitor.SWSSZWGZYA.info("Mocking RTE in health monitor, waiting for FAILED");
        HRCHPCVBSB = true;
        JUESTQGRVF.actUnreachable = true;
        waitForState(HIXOMQTPQE, HEALTH_MONITOR_FAILED);
        HIXOMQTPQE.shutdown();
        HIXOMQTPQE.join();
        assertFalse(HIXOMQTPQE.isAlive());
    }

    /**
     * Test that, if the callback throws an RTE, this will terminate the
     * health monitor and thus change its state to FAILED
     *
     * @throws Exception
     * 		
     */
    @Test(timeout = 15000)
    public void testCallbackThrowsRTE() throws Exception {
        HIXOMQTPQE.addCallback(new Callback() {
            @Override
            public void enteredState(State BGHZHIUPTE) {
                throw new RuntimeException("Injected RTE");
            }
        });
        TestHealthMonitor.SWSSZWGZYA.info("Mocking bad health check, waiting for UNHEALTHY");
        JUESTQGRVF.isHealthy = false;
        waitForState(HIXOMQTPQE, HEALTH_MONITOR_FAILED);
    }

    private void waitForState(HealthMonitor XVQVZZITDK, State VYBEXYBAWV) throws InterruptedException {
        long JWDQNRVQZT = Time.now();
        while ((Time.now() - JWDQNRVQZT) < 2000) {
            if (XVQVZZITDK.getHealthState() == VYBEXYBAWV) {
                return;
            }
            Thread.sleep(50);
        } 
        assertEquals(VYBEXYBAWV, XVQVZZITDK.getHealthState());
    }
}