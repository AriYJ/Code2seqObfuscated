/**
 * A {@link Compressor} based on the popular
 * bzip2 compression algorithm.
 * http://www.bzip2.org/
 */
public class Bzip2Compressor implements Compressor {
    private static final int XIWWENMEVT = 64 * 1024;

    // The default values for the block size and work factor are the same
    // those in Julian Seward's original bzip2 implementation.
    static final int KIVXQCQCPE = 9;

    static final int HHVCZHVDMB = 30;

    private static final Log KNDTMZATXE = LogFactory.getLog(Bzip2Compressor.class);

    // HACK - Use this as a global lock in the JNI layer.
    private static Class<Bzip2Compressor> XTDINDTAJF = Bzip2Compressor.class;

    private long FFKFHGZONC;

    private int PXPZXSDHPN;

    private int JEQLEJXATJ;

    private int BCQLFKOSFA;

    private byte[] FEOBAGRIML = null;

    private int IFDZGFVJGD = 0;

    private int PAQMFLJCWQ = 0;

    private Buffer NSPZHYBYQX = null;

    private int YIETDGMPTL = 0;

    private int VQDJNHJLDR = 0;

    private boolean HZLGLORWVN = false;

    private Buffer HJTYXGDUFQ = null;

    private boolean GJABMIKUDH;

    private boolean OCFROGWZEL;

    /**
     * Creates a new compressor with a default values for the
     * compression block size and work factor.  Compressed data will be
     * generated in bzip2 format.
     */
    public Bzip2Compressor() {
        this(Bzip2Compressor.KIVXQCQCPE, Bzip2Compressor.HHVCZHVDMB, Bzip2Compressor.XIWWENMEVT);
    }

    /**
     * Creates a new compressor, taking settings from the configuration.
     */
    public Bzip2Compressor(Configuration JOTVHDRIJE) {
        this(Bzip2Factory.getBlockSize(JOTVHDRIJE), Bzip2Factory.getWorkFactor(JOTVHDRIJE), Bzip2Compressor.XIWWENMEVT);
    }

    /**
     * Creates a new compressor using the specified block size.
     * Compressed data will be generated in bzip2 format.
     *
     * @param blockSize
     * 		The block size to be used for compression.  This is
     * 		an integer from 1 through 9, which is multiplied by 100,000 to
     * 		obtain the actual block size in bytes.
     * @param workFactor
     * 		This parameter is a threshold that determines when a
     * 		fallback algorithm is used for pathological data.  It ranges from
     * 		0 to 250.
     * @param directBufferSize
     * 		Size of the direct buffer to be used.
     */
    public Bzip2Compressor(int DZUNVPMIEW, int TJXJOVURAC, int HZHECCVXXQ) {
        this.PXPZXSDHPN = DZUNVPMIEW;
        this.JEQLEJXATJ = TJXJOVURAC;
        this.BCQLFKOSFA = HZHECCVXXQ;
        FFKFHGZONC = Bzip2Compressor.init(DZUNVPMIEW, TJXJOVURAC);
        NSPZHYBYQX = ByteBuffer.allocateDirect(HZHECCVXXQ);
        HJTYXGDUFQ = ByteBuffer.allocateDirect(HZHECCVXXQ);
        HJTYXGDUFQ.position(HZHECCVXXQ);
    }

    /**
     * Prepare the compressor to be used in a new stream with settings defined in
     * the given Configuration. It will reset the compressor's block size and
     * and work factor.
     *
     * @param conf
     * 		Configuration storing new settings
     */
    @Override
    public synchronized void reinit(Configuration WUOEYIALMY) {
        reset();
        Bzip2Compressor.end(FFKFHGZONC);
        if (WUOEYIALMY == null) {
            FFKFHGZONC = Bzip2Compressor.init(PXPZXSDHPN, JEQLEJXATJ);
            return;
        }
        PXPZXSDHPN = Bzip2Factory.getBlockSize(WUOEYIALMY);
        JEQLEJXATJ = Bzip2Factory.getWorkFactor(WUOEYIALMY);
        FFKFHGZONC = Bzip2Compressor.init(PXPZXSDHPN, JEQLEJXATJ);
        if (Bzip2Compressor.KNDTMZATXE.isDebugEnabled()) {
            Bzip2Compressor.KNDTMZATXE.debug("Reinit compressor with new compression configuration");
        }
    }

    @Override
    public synchronized void setInput(byte[] EBDKSODZJC, int YOLTKSIGFF, int WAZVFYUFXC) {
        if (EBDKSODZJC == null) {
            throw new NullPointerException();
        }
        if (((YOLTKSIGFF < 0) || (WAZVFYUFXC < 0)) || (YOLTKSIGFF > (EBDKSODZJC.length - WAZVFYUFXC))) {
            throw new ArrayIndexOutOfBoundsException();
        }
        this.FEOBAGRIML = EBDKSODZJC;
        this.IFDZGFVJGD = YOLTKSIGFF;
        this.PAQMFLJCWQ = WAZVFYUFXC;
        YIETDGMPTL = 0;
        setInputFromSavedData();
        // Reinitialize bzip2's output direct buffer.
        HJTYXGDUFQ.limit(BCQLFKOSFA);
        HJTYXGDUFQ.position(BCQLFKOSFA);
    }

    // Copy enough data from userBuf to uncompressedDirectBuf.
    synchronized void setInputFromSavedData() {
        int VDJQXSXNQV = Math.min(PAQMFLJCWQ, NSPZHYBYQX.remaining());
        ((ByteBuffer) (NSPZHYBYQX)).put(FEOBAGRIML, IFDZGFVJGD, VDJQXSXNQV);
        PAQMFLJCWQ -= VDJQXSXNQV;
        IFDZGFVJGD += VDJQXSXNQV;
        VQDJNHJLDR = NSPZHYBYQX.position();
    }

    @Override
    public synchronized void setDictionary(byte[] DETZNOTXIH, int NCMSTNUWLK, int ECIGAYVZES) {
        throw new UnsupportedOperationException();
    }

    @Override
    public synchronized boolean needsInput() {
        // Compressed data still available?
        if (HJTYXGDUFQ.remaining() > 0) {
            return false;
        }
        // Uncompressed data available in either the direct buffer or user buffer?
        if (HZLGLORWVN && (VQDJNHJLDR > 0))
            return false;

        if (NSPZHYBYQX.remaining() > 0) {
            // Check if we have consumed all data in the user buffer.
            if (PAQMFLJCWQ <= 0) {
                return true;
            } else {
                // Copy enough data from userBuf to uncompressedDirectBuf.
                setInputFromSavedData();
                return NSPZHYBYQX.remaining() > 0;
            }
        }
        return false;
    }

    @Override
    public synchronized void finish() {
        GJABMIKUDH = true;
    }

    @Override
    public synchronized boolean finished() {
        // Check if bzip2 says it has finished and
        // all compressed data has been consumed.
        return OCFROGWZEL && (HJTYXGDUFQ.remaining() == 0);
    }

    @Override
    public synchronized int compress(byte[] OGAAIZSLDG, int KFJMTORQQQ, int QSZRKDNKIH) throws IOException {
        if (OGAAIZSLDG == null) {
            throw new NullPointerException();
        }
        if (((KFJMTORQQQ < 0) || (QSZRKDNKIH < 0)) || (KFJMTORQQQ > (OGAAIZSLDG.length - QSZRKDNKIH))) {
            throw new ArrayIndexOutOfBoundsException();
        }
        // Check if there is compressed data.
        int JNRTCTVSMS = HJTYXGDUFQ.remaining();
        if (JNRTCTVSMS > 0) {
            JNRTCTVSMS = Math.min(JNRTCTVSMS, QSZRKDNKIH);
            ((ByteBuffer) (HJTYXGDUFQ)).get(OGAAIZSLDG, KFJMTORQQQ, JNRTCTVSMS);
            return JNRTCTVSMS;
        }
        // Re-initialize bzip2's output direct buffer.
        HJTYXGDUFQ.rewind();
        HJTYXGDUFQ.limit(BCQLFKOSFA);
        // Compress the data.
        JNRTCTVSMS = deflateBytesDirect();
        HJTYXGDUFQ.limit(JNRTCTVSMS);
        // Check if bzip2 has consumed the entire input buffer.
        // Set keepUncompressedBuf properly.
        if (VQDJNHJLDR <= 0) {
            // bzip2 consumed all input
            HZLGLORWVN = false;
            NSPZHYBYQX.clear();
            YIETDGMPTL = 0;
            VQDJNHJLDR = 0;
        } else {
            HZLGLORWVN = true;
        }
        // Get at most 'len' bytes.
        JNRTCTVSMS = Math.min(JNRTCTVSMS, QSZRKDNKIH);
        ((ByteBuffer) (HJTYXGDUFQ)).get(OGAAIZSLDG, KFJMTORQQQ, JNRTCTVSMS);
        return JNRTCTVSMS;
    }

    /**
     * Returns the total number of compressed bytes output so far.
     *
     * @return the total (non-negative) number of compressed bytes output so far
     */
    @Override
    public synchronized long getBytesWritten() {
        checkStream();
        return Bzip2Compressor.getBytesWritten(FFKFHGZONC);
    }

    /**
     * Returns the total number of uncompressed bytes input so far.</p>
     *
     * @return the total (non-negative) number of uncompressed bytes input so far
     */
    @Override
    public synchronized long getBytesRead() {
        checkStream();
        return Bzip2Compressor.getBytesRead(FFKFHGZONC);
    }

    @Override
    public synchronized void reset() {
        checkStream();
        Bzip2Compressor.end(FFKFHGZONC);
        FFKFHGZONC = Bzip2Compressor.init(PXPZXSDHPN, JEQLEJXATJ);
        GJABMIKUDH = false;
        OCFROGWZEL = false;
        NSPZHYBYQX.rewind();
        YIETDGMPTL = VQDJNHJLDR = 0;
        HZLGLORWVN = false;
        HJTYXGDUFQ.limit(BCQLFKOSFA);
        HJTYXGDUFQ.position(BCQLFKOSFA);
        IFDZGFVJGD = PAQMFLJCWQ = 0;
    }

    @Override
    public synchronized void end() {
        if (FFKFHGZONC != 0) {
            Bzip2Compressor.end(FFKFHGZONC);
            FFKFHGZONC = 0;
        }
    }

    static void initSymbols(String WQKVYTELPM) {
        Bzip2Compressor.initIDs(WQKVYTELPM);
    }

    private void checkStream() {
        if (FFKFHGZONC == 0)
            throw new NullPointerException();

    }

    private static native void initIDs(String SZIDNVLDWB);

    private static native long init(int XSTYLPSPHZ, int XJQUVPKNAW);

    private native int deflateBytesDirect();

    private static native long getBytesRead(long OMEUHCSZAO);

    private static native long getBytesWritten(long CKBQIGJXOQ);

    private static native void end(long UPOOKBPYUB);

    public static native String getLibraryName();
}