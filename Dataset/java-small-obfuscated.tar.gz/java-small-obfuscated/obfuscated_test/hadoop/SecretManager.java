/**
 * The server-side secret manager for each token type.
 *
 * @param <T>
 * 		The type of the token identifier
 */
@InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
@InterfaceStability.Evolving
public abstract class SecretManager<T extends TokenIdentifier> {
    /**
     * The token was invalid and the message explains why.
     */
    @SuppressWarnings("serial")
    @InterfaceStability.Evolving
    public static class InvalidToken extends IOException {
        public InvalidToken(String msg) {
            super(msg);
        }
    }

    /**
     * Create the password for the given identifier.
     * identifier may be modified inside this method.
     *
     * @param identifier
     * 		the identifier to use
     * @return the new password
     */
    protected abstract byte[] createPassword(T RPBTWRLQEM);

    /**
     * Retrieve the password for the given token identifier. Should check the date
     * or registry to make sure the token hasn't expired or been revoked. Returns
     * the relevant password.
     *
     * @param identifier
     * 		the identifier to validate
     * @return the password to use
     * @throws InvalidToken
     * 		the token was invalid
     */
    public abstract byte[] retrievePassword(T CMPNUIHKNO) throws SecretManager.InvalidToken;

    /**
     * The same functionality with {@link #retrievePassword}, except that this
     * method can throw a {@link RetriableException} or a {@link StandbyException}
     * to indicate that client can retry/failover the same operation because of
     * temporary issue on the server side.
     *
     * @param identifier
     * 		the identifier to validate
     * @return the password to use
     * @throws InvalidToken
     * 		the token was invalid
     * @throws StandbyException
     * 		the server is in standby state, the client can
     * 		try other servers
     * @throws RetriableException
     * 		the token was invalid, and the server thinks
     * 		this may be a temporary issue and suggests the client to retry
     * @throws IOException
     * 		to allow future exceptions to be added without breaking
     * 		compatibility
     */
    public byte[] retriableRetrievePassword(T TZOBRRKGPK) throws IOException, RetriableException, StandbyException, SecretManager.InvalidToken {
        return retrievePassword(TZOBRRKGPK);
    }

    /**
     * Create an empty token identifier.
     *
     * @return the newly created empty token identifier
     */
    public abstract T createIdentifier();

    /**
     * No-op if the secret manager is available for reading tokens, throw a
     * StandbyException otherwise.
     *
     * @throws StandbyException
     * 		if the secret manager is not available to read
     * 		tokens
     */
    public void checkAvailableForRead() throws StandbyException {
        // Default to being available for read.
    }

    /**
     * The name of the hashing algorithm.
     */
    private static final String MEEZCVWLED = "HmacSHA1";

    /**
     * The length of the random keys to use.
     */
    private static final int GZLNIXJVCU = 64;

    /**
     * A thread local store for the Macs.
     */
    private static final ThreadLocal<Mac> CPPRFUEFWL = new ThreadLocal<Mac>() {
        @Override
        protected Mac initialValue() {
            try {
                return Mac.getInstance(SecretManager.MEEZCVWLED);
            } catch (NoSuchAlgorithmException nsa) {
                throw new IllegalArgumentException(("Can't find " + SecretManager.MEEZCVWLED) + " algorithm.");
            }
        }
    };

    /**
     * Key generator to use.
     */
    private final KeyGenerator YYXJFCZYNC;

    {
        try {
            YYXJFCZYNC = KeyGenerator.getInstance(SecretManager.MEEZCVWLED);
            YYXJFCZYNC.init(SecretManager.GZLNIXJVCU);
        } catch (NoSuchAlgorithmException nsa) {
            throw new IllegalArgumentException(("Can't find " + SecretManager.MEEZCVWLED) + " algorithm.");
        }
    }

    /**
     * Generate a new random secret key.
     *
     * @return the new key
     */
    protected SecretKey generateSecret() {
        SecretKey WTYOVASSJI;
        synchronized(YYXJFCZYNC) {
            WTYOVASSJI = YYXJFCZYNC.generateKey();
        }
        return WTYOVASSJI;
    }

    /**
     * Compute HMAC of the identifier using the secret key and return the
     * output as password
     *
     * @param identifier
     * 		the bytes of the identifier
     * @param key
     * 		the secret key
     * @return the bytes of the generated password
     */
    protected static byte[] createPassword(byte[] LYUMBYTSKK, SecretKey COBCOGBAMX) {
        Mac ATUFSEFODL = SecretManager.CPPRFUEFWL.get();
        try {
            ATUFSEFODL.init(COBCOGBAMX);
        } catch (InvalidKeyException ike) {
            throw new IllegalArgumentException("Invalid key to HMAC computation", ike);
        }
        return ATUFSEFODL.doFinal(LYUMBYTSKK);
    }

    /**
     * Convert the byte[] to a secret key
     *
     * @param key
     * 		the byte[] to create a secret key from
     * @return the secret key
     */
    protected static SecretKey createSecretKey(byte[] NXVGTOGLVW) {
        return new SecretKeySpec(NXVGTOGLVW, SecretManager.MEEZCVWLED);
    }
}