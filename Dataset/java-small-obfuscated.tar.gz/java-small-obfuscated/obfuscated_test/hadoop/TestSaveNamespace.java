/**
 * Test various failure scenarios during saveNamespace() operation.
 * Cases covered:
 * <ol>
 * <li>Recover from failure while saving into the second storage directory</li>
 * <li>Recover from failure while moving current into lastcheckpoint.tmp</li>
 * <li>Recover from failure while moving lastcheckpoint.tmp into
 * previous.checkpoint</li>
 * <li>Recover from failure while rolling edits file</li>
 * </ol>
 */
public class TestSaveNamespace {
    static {
        ((org.apache.commons.logging.impl.Log4JLogger) (FSImage.LOG)).getLogger().setLevel(Level.ALL);
    }

    private static final Log VCGELLOZIX = LogFactory.getLog(TestSaveNamespace.class);

    private static class FaultySaveImage implements Answer<Void> {
        int FJICPLMVID = 0;

        boolean YWRJXSRVHS = true;

        // generate either a RuntimeException or IOException
        public FaultySaveImage(boolean throwRTE) {
            this.YWRJXSRVHS = throwRTE;
        }

        @Override
        public Void answer(InvocationOnMock invocation) throws Throwable {
            Object[] args = invocation.getArguments();
            StorageDirectory sd = ((StorageDirectory) (args[1]));
            if ((FJICPLMVID++) == 1) {
                TestSaveNamespace.VCGELLOZIX.info("Injecting fault for sd: " + sd);
                if (YWRJXSRVHS) {
                    throw new RuntimeException("Injected fault: saveFSImage second time");
                } else {
                    throw new IOException("Injected fault: saveFSImage second time");
                }
            }
            TestSaveNamespace.VCGELLOZIX.info("Not injecting fault for sd: " + sd);
            return ((Void) (invocation.callRealMethod()));
        }
    }

    private enum Fault {

        SAVE_SECOND_FSIMAGE_RTE,
        SAVE_SECOND_FSIMAGE_IOE,
        SAVE_ALL_FSIMAGES,
        WRITE_STORAGE_ALL,
        WRITE_STORAGE_ONE;}

    private void saveNamespaceWithInjectedFault(TestSaveNamespace.Fault AHLESBYVWV) throws Exception {
        Configuration BDQFXMMXGT = getConf();
        NameNode.initMetrics(BDQFXMMXGT, NAMENODE);
        DFSTestUtil.formatNameNode(BDQFXMMXGT);
        FSNamesystem MOTIMSLWZX = FSNamesystem.loadFromDisk(BDQFXMMXGT);
        // Replace the FSImage with a spy
        FSImage KFMCBPEXYX = MOTIMSLWZX.getFSImage();
        NNStorage ZUHGYQLYYV = KFMCBPEXYX.getStorage();
        NNStorage UMTHECRRQY = spy(ZUHGYQLYYV);
        KFMCBPEXYX.storage = UMTHECRRQY;
        FSImage KKHPOCSGXQ = spy(KFMCBPEXYX);
        Whitebox.setInternalState(MOTIMSLWZX, "fsImage", KKHPOCSGXQ);
        boolean OUKIDUZZRE = false;// should we expect the save operation to fail

        // inject fault
        switch (AHLESBYVWV) {
            case SAVE_SECOND_FSIMAGE_RTE :
                // The spy throws a RuntimeException when writing to the second directory
                doAnswer(new TestSaveNamespace.FaultySaveImage(true)).when(KKHPOCSGXQ).saveFSImage(((SaveNamespaceContext) (anyObject())), ((StorageDirectory) (anyObject())), ((org.apache.hadoop.hdfs.server.namenode.NNStorage.NameNodeFile) (anyObject())));
                OUKIDUZZRE = false;
                break;
            case SAVE_SECOND_FSIMAGE_IOE :
                // The spy throws an IOException when writing to the second directory
                doAnswer(new TestSaveNamespace.FaultySaveImage(false)).when(KKHPOCSGXQ).saveFSImage(((SaveNamespaceContext) (anyObject())), ((StorageDirectory) (anyObject())), ((org.apache.hadoop.hdfs.server.namenode.NNStorage.NameNodeFile) (anyObject())));
                OUKIDUZZRE = false;
                break;
            case SAVE_ALL_FSIMAGES :
                // The spy throws IOException in all directories
                doThrow(new RuntimeException("Injected")).when(KKHPOCSGXQ).saveFSImage(((SaveNamespaceContext) (anyObject())), ((StorageDirectory) (anyObject())), ((org.apache.hadoop.hdfs.server.namenode.NNStorage.NameNodeFile) (anyObject())));
                OUKIDUZZRE = true;
                break;
            case WRITE_STORAGE_ALL :
                // The spy throws an exception before writing any VERSION files
                doThrow(new RuntimeException("Injected")).when(UMTHECRRQY).writeAll();
                OUKIDUZZRE = true;
                break;
            case WRITE_STORAGE_ONE :
                // The spy throws on exception on one particular storage directory
                doAnswer(new TestSaveNamespace.FaultySaveImage(true)).when(UMTHECRRQY).writeProperties(((StorageDirectory) (anyObject())));
                // TODO: unfortunately this fails -- should be improved.
                // See HDFS-2173.
                OUKIDUZZRE = true;
                break;
        }
        try {
            doAnEdit(MOTIMSLWZX, 1);
            // Save namespace - this may fail, depending on fault injected
            MOTIMSLWZX.setSafeMode(SAFEMODE_ENTER);
            try {
                MOTIMSLWZX.saveNamespace();
                if (OUKIDUZZRE) {
                    fail("Did not fail!");
                }
            } catch (Exception e) {
                if (!OUKIDUZZRE) {
                    throw e;
                } else {
                    TestSaveNamespace.VCGELLOZIX.info("Test caught expected exception", e);
                }
            }
            MOTIMSLWZX.setSafeMode(SAFEMODE_LEAVE);
            // Should still be able to perform edits
            doAnEdit(MOTIMSLWZX, 2);
            // Now shut down and restart the namesystem
            KFMCBPEXYX.close();
            MOTIMSLWZX.close();
            MOTIMSLWZX = null;
            // Start a new namesystem, which should be able to recover
            // the namespace from the previous incarnation.
            MOTIMSLWZX = FSNamesystem.loadFromDisk(BDQFXMMXGT);
            // Make sure the image loaded including our edits.
            checkEditExists(MOTIMSLWZX, 1);
            checkEditExists(MOTIMSLWZX, 2);
        } finally {
            if (MOTIMSLWZX != null) {
                MOTIMSLWZX.close();
            }
        }
    }

    /**
     * Verify that a saveNamespace command brings faulty directories
     * in fs.name.dir and fs.edit.dir back online.
     */
    @Test(timeout = 30000)
    public void testReinsertnamedirsInSavenamespace() throws Exception {
        // create a configuration with the key to restore error
        // directories in fs.name.dir
        Configuration VNRLJYSVEL = getConf();
        VNRLJYSVEL.setBoolean(DFS_NAMENODE_NAME_DIR_RESTORE_KEY, true);
        NameNode.initMetrics(VNRLJYSVEL, NAMENODE);
        DFSTestUtil.formatNameNode(VNRLJYSVEL);
        FSNamesystem OJPQWCWEHI = FSNamesystem.loadFromDisk(VNRLJYSVEL);
        // Replace the FSImage with a spy
        FSImage SYCCMOBDNX = OJPQWCWEHI.getFSImage();
        NNStorage OVHXPVVUCN = SYCCMOBDNX.getStorage();
        FSImage RXEAJDCNDC = spy(SYCCMOBDNX);
        Whitebox.setInternalState(OJPQWCWEHI, "fsImage", RXEAJDCNDC);
        FileSystem CBLJNGLYLX = FileSystem.getLocal(VNRLJYSVEL);
        File XLYUTKSJBJ = OVHXPVVUCN.getStorageDir(0).getRoot();
        Path OXQCTJFTTZ = new Path(XLYUTKSJBJ.getPath(), "current");
        final FsPermission OAOMYCWBBL = new FsPermission(((short) (0)));
        final FsPermission QASNGNWVAM = new FsPermission(FsAction.ALL, FsAction.READ_EXECUTE, FsAction.READ_EXECUTE);
        CBLJNGLYLX.setPermission(OXQCTJFTTZ, OAOMYCWBBL);
        try {
            doAnEdit(OJPQWCWEHI, 1);
            OJPQWCWEHI.setSafeMode(SAFEMODE_ENTER);
            // Save namespace - should mark the first storage dir as faulty
            // since it's not traversable.
            TestSaveNamespace.VCGELLOZIX.info("Doing the first savenamespace.");
            OJPQWCWEHI.saveNamespace();
            TestSaveNamespace.VCGELLOZIX.info("First savenamespace sucessful.");
            assertTrue((("Savenamespace should have marked one directory as bad." + " But found ") + OVHXPVVUCN.getRemovedStorageDirs().size()) + " bad directories.", OVHXPVVUCN.getRemovedStorageDirs().size() == 1);
            CBLJNGLYLX.setPermission(OXQCTJFTTZ, QASNGNWVAM);
            // The next call to savenamespace should try inserting the
            // erroneous directory back to fs.name.dir. This command should
            // be successful.
            TestSaveNamespace.VCGELLOZIX.info("Doing the second savenamespace.");
            OJPQWCWEHI.saveNamespace();
            TestSaveNamespace.VCGELLOZIX.warn("Second savenamespace sucessful.");
            assertTrue((("Savenamespace should have been successful in removing " + (" bad directories from Image." + " But found ")) + OVHXPVVUCN.getRemovedStorageDirs().size()) + " bad directories.", OVHXPVVUCN.getRemovedStorageDirs().size() == 0);
            // Now shut down and restart the namesystem
            TestSaveNamespace.VCGELLOZIX.info("Shutting down fsimage.");
            SYCCMOBDNX.close();
            OJPQWCWEHI.close();
            OJPQWCWEHI = null;
            // Start a new namesystem, which should be able to recover
            // the namespace from the previous incarnation.
            TestSaveNamespace.VCGELLOZIX.info("Loading new FSmage from disk.");
            OJPQWCWEHI = FSNamesystem.loadFromDisk(VNRLJYSVEL);
            // Make sure the image loaded including our edit.
            TestSaveNamespace.VCGELLOZIX.info("Checking reloaded image.");
            checkEditExists(OJPQWCWEHI, 1);
            TestSaveNamespace.VCGELLOZIX.info("Reloaded image is good.");
        } finally {
            if (XLYUTKSJBJ.exists()) {
                CBLJNGLYLX.setPermission(OXQCTJFTTZ, QASNGNWVAM);
            }
            if (OJPQWCWEHI != null) {
                try {
                    OJPQWCWEHI.close();
                } catch (Throwable t) {
                    TestSaveNamespace.VCGELLOZIX.fatal("Failed to shut down", t);
                }
            }
        }
    }

    @Test(timeout = 30000)
    public void testRTEWhileSavingSecondImage() throws Exception {
        saveNamespaceWithInjectedFault(TestSaveNamespace.Fault.SAVE_SECOND_FSIMAGE_RTE);
    }

    @Test(timeout = 30000)
    public void testIOEWhileSavingSecondImage() throws Exception {
        saveNamespaceWithInjectedFault(TestSaveNamespace.Fault.SAVE_SECOND_FSIMAGE_IOE);
    }

    @Test(timeout = 30000)
    public void testCrashInAllImageDirs() throws Exception {
        saveNamespaceWithInjectedFault(TestSaveNamespace.Fault.SAVE_ALL_FSIMAGES);
    }

    @Test(timeout = 30000)
    public void testCrashWhenWritingVersionFiles() throws Exception {
        saveNamespaceWithInjectedFault(TestSaveNamespace.Fault.WRITE_STORAGE_ALL);
    }

    @Test(timeout = 30000)
    public void testCrashWhenWritingVersionFileInOneDir() throws Exception {
        saveNamespaceWithInjectedFault(TestSaveNamespace.Fault.WRITE_STORAGE_ONE);
    }

    /**
     * Test case where savenamespace fails in all directories
     * and then the NN shuts down. Here we should recover from the
     * failed checkpoint since it only affected ".ckpt" files, not
     * valid image files
     */
    @Test(timeout = 30000)
    public void testFailedSaveNamespace() throws Exception {
        doTestFailedSaveNamespace(false);
    }

    /**
     * Test case where saveNamespace fails in all directories, but then
     * the operator restores the directories and calls it again.
     * This should leave the NN in a clean state for next start.
     */
    @Test(timeout = 30000)
    public void testFailedSaveNamespaceWithRecovery() throws Exception {
        doTestFailedSaveNamespace(true);
    }

    /**
     * Injects a failure on all storage directories while saving namespace.
     *
     * @param restoreStorageAfterFailure
     * 		if true, will try to save again after
     * 		clearing the failure injection
     */
    public void doTestFailedSaveNamespace(boolean TKBNTOMQIR) throws Exception {
        Configuration TMTPQAJBNU = getConf();
        NameNode.initMetrics(TMTPQAJBNU, NAMENODE);
        DFSTestUtil.formatNameNode(TMTPQAJBNU);
        FSNamesystem QNDZDPUUQE = FSNamesystem.loadFromDisk(TMTPQAJBNU);
        // Replace the FSImage with a spy
        final FSImage MEEUKWXROH = QNDZDPUUQE.getFSImage();
        NNStorage FPZDOZTAHR = MEEUKWXROH.getStorage();
        FPZDOZTAHR.close();// unlock any directories that FSNamesystem's initialization may have locked

        NNStorage SDNVQAUNRA = spy(FPZDOZTAHR);
        MEEUKWXROH.storage = SDNVQAUNRA;
        FSImage DCUSTMHJBA = spy(MEEUKWXROH);
        Whitebox.setInternalState(QNDZDPUUQE, "fsImage", DCUSTMHJBA);
        DCUSTMHJBA.storage.setStorageDirectories(FSNamesystem.getNamespaceDirs(TMTPQAJBNU), FSNamesystem.getNamespaceEditsDirs(TMTPQAJBNU));
        doThrow(new IOException("Injected fault: saveFSImage")).when(DCUSTMHJBA).saveFSImage(((SaveNamespaceContext) (anyObject())), ((StorageDirectory) (anyObject())), ((org.apache.hadoop.hdfs.server.namenode.NNStorage.NameNodeFile) (anyObject())));
        try {
            doAnEdit(QNDZDPUUQE, 1);
            // Save namespace
            QNDZDPUUQE.setSafeMode(SAFEMODE_ENTER);
            try {
                QNDZDPUUQE.saveNamespace();
                fail("saveNamespace did not fail even when all directories failed!");
            } catch (IOException ioe) {
                TestSaveNamespace.VCGELLOZIX.info("Got expected exception", ioe);
            }
            // Ensure that, if storage dirs come back online, things work again.
            if (TKBNTOMQIR) {
                Mockito.reset(DCUSTMHJBA);
                SDNVQAUNRA.setRestoreFailedStorage(true);
                QNDZDPUUQE.saveNamespace();
                checkEditExists(QNDZDPUUQE, 1);
            }
            // Now shut down and restart the NN
            MEEUKWXROH.close();
            QNDZDPUUQE.close();
            QNDZDPUUQE = null;
            // Start a new namesystem, which should be able to recover
            // the namespace from the previous incarnation.
            QNDZDPUUQE = FSNamesystem.loadFromDisk(TMTPQAJBNU);
            // Make sure the image loaded including our edits.
            checkEditExists(QNDZDPUUQE, 1);
        } finally {
            if (QNDZDPUUQE != null) {
                QNDZDPUUQE.close();
            }
        }
    }

    @Test(timeout = 30000)
    public void testSaveWhileEditsRolled() throws Exception {
        Configuration SKNOHAYZNM = getConf();
        NameNode.initMetrics(SKNOHAYZNM, NAMENODE);
        DFSTestUtil.formatNameNode(SKNOHAYZNM);
        FSNamesystem CTINPDXRCN = FSNamesystem.loadFromDisk(SKNOHAYZNM);
        try {
            doAnEdit(CTINPDXRCN, 1);
            CheckpointSignature ROMYYIRECN = CTINPDXRCN.rollEditLog();
            TestSaveNamespace.VCGELLOZIX.warn("Checkpoint signature: " + ROMYYIRECN);
            // Do another edit
            doAnEdit(CTINPDXRCN, 2);
            // Save namespace
            CTINPDXRCN.setSafeMode(SAFEMODE_ENTER);
            CTINPDXRCN.saveNamespace();
            // Now shut down and restart the NN
            CTINPDXRCN.close();
            CTINPDXRCN = null;
            // Start a new namesystem, which should be able to recover
            // the namespace from the previous incarnation.
            CTINPDXRCN = FSNamesystem.loadFromDisk(SKNOHAYZNM);
            // Make sure the image loaded including our edits.
            checkEditExists(CTINPDXRCN, 1);
            checkEditExists(CTINPDXRCN, 2);
        } finally {
            if (CTINPDXRCN != null) {
                CTINPDXRCN.close();
            }
        }
    }

    @Test(timeout = 30000)
    public void testTxIdPersistence() throws Exception {
        Configuration LKZGPAICYD = getConf();
        NameNode.initMetrics(LKZGPAICYD, NAMENODE);
        DFSTestUtil.formatNameNode(LKZGPAICYD);
        FSNamesystem QOSJTPQVKT = FSNamesystem.loadFromDisk(LKZGPAICYD);
        try {
            // We have a BEGIN_LOG_SEGMENT txn to start
            assertEquals(1, QOSJTPQVKT.getEditLog().getLastWrittenTxId());
            doAnEdit(QOSJTPQVKT, 1);
            assertEquals(2, QOSJTPQVKT.getEditLog().getLastWrittenTxId());
            QOSJTPQVKT.setSafeMode(SAFEMODE_ENTER);
            QOSJTPQVKT.saveNamespace();
            // 2 more txns: END the first segment, BEGIN a new one
            assertEquals(4, QOSJTPQVKT.getEditLog().getLastWrittenTxId());
            // Shut down and restart
            QOSJTPQVKT.getFSImage().close();
            QOSJTPQVKT.close();
            // 1 more txn to END that segment
            assertEquals(5, QOSJTPQVKT.getEditLog().getLastWrittenTxId());
            QOSJTPQVKT = null;
            QOSJTPQVKT = FSNamesystem.loadFromDisk(LKZGPAICYD);
            // 1 more txn to start new segment on restart
            assertEquals(6, QOSJTPQVKT.getEditLog().getLastWrittenTxId());
        } finally {
            if (QOSJTPQVKT != null) {
                QOSJTPQVKT.close();
            }
        }
    }

    @Test(timeout = 20000)
    public void testCancelSaveNamespace() throws Exception {
        Configuration RXKEINDILD = getConf();
        NameNode.initMetrics(RXKEINDILD, NAMENODE);
        DFSTestUtil.formatNameNode(RXKEINDILD);
        FSNamesystem PPTUAJUUVR = FSNamesystem.loadFromDisk(RXKEINDILD);
        // Replace the FSImage with a spy
        final FSImage DZVTSTHUPI = PPTUAJUUVR.getFSImage();
        NNStorage MAPTZJWSTD = DZVTSTHUPI.getStorage();
        MAPTZJWSTD.close();// unlock any directories that FSNamesystem's initialization may have locked

        MAPTZJWSTD.setStorageDirectories(FSNamesystem.getNamespaceDirs(RXKEINDILD), FSNamesystem.getNamespaceEditsDirs(RXKEINDILD));
        FSNamesystem ZDHMANIDCH = spy(PPTUAJUUVR);
        final FSNamesystem LAQVXZUZFL = ZDHMANIDCH;
        DelayAnswer PRNWBGPDUY = new GenericTestUtils.DelayAnswer(TestSaveNamespace.VCGELLOZIX);
        doAnswer(PRNWBGPDUY).when(ZDHMANIDCH).getGenerationStampV2();
        ExecutorService HQTXKUFHFH = Executors.newFixedThreadPool(2);
        try {
            doAnEdit(PPTUAJUUVR, 1);
            final Canceler NOXYVBQQLY = new Canceler();
            // Save namespace
            PPTUAJUUVR.setSafeMode(SAFEMODE_ENTER);
            try {
                Future<Void> SANQQAVSPW = HQTXKUFHFH.submit(new Callable<Void>() {
                    @Override
                    public Void call() throws Exception {
                        DZVTSTHUPI.saveNamespace(LAQVXZUZFL, IMAGE, NOXYVBQQLY);
                        return null;
                    }
                });
                // Wait until saveNamespace calls getGenerationStamp
                PRNWBGPDUY.waitForCall();
                // then cancel the saveNamespace
                Future<Void> QPBQHEYHJY = HQTXKUFHFH.submit(new Callable<Void>() {
                    @Override
                    public Void call() throws Exception {
                        NOXYVBQQLY.cancel("cancelled");
                        return null;
                    }
                });
                // give the cancel call time to run
                Thread.sleep(500);
                // allow saveNamespace to proceed - it should check the cancel flag after
                // this point and throw an exception
                PRNWBGPDUY.proceed();
                QPBQHEYHJY.get();
                SANQQAVSPW.get();
                fail("saveNamespace did not fail even though cancelled!");
            } catch (Throwable t) {
                GenericTestUtils.assertExceptionContains("SaveNamespaceCancelledException", t);
            }
            TestSaveNamespace.VCGELLOZIX.info("Successfully cancelled a saveNamespace");
            // Check that we have only the original image and not any
            // cruft left over from half-finished images
            FSImageTestUtil.logStorageContents(TestSaveNamespace.VCGELLOZIX, MAPTZJWSTD);
            for (StorageDirectory CULOJLGJSQ : MAPTZJWSTD.dirIterable(null)) {
                File XQNVPMBHLI = CULOJLGJSQ.getCurrentDir();
                GenericTestUtils.assertGlobEquals(XQNVPMBHLI, "fsimage_.*", NNStorage.getImageFileName(0), NNStorage.getImageFileName(0) + MD5FileUtils.MD5_SUFFIX);
            }
        } finally {
            if (PPTUAJUUVR != null) {
                PPTUAJUUVR.close();
            }
        }
    }

    /**
     * Test for save namespace should succeed when parent directory renamed with
     * open lease and destination directory exist.
     * This test is a regression for HDFS-2827
     */
    @Test(timeout = 30000)
    public void testSaveNamespaceWithRenamedLease() throws Exception {
        MiniDFSCluster HLMPPXNVLN = new MiniDFSCluster.Builder(new Configuration()).numDataNodes(1).build();
        HLMPPXNVLN.waitActive();
        DistributedFileSystem AQUMEASXZB = HLMPPXNVLN.getFileSystem();
        OutputStream TWUQEFVMBY = null;
        try {
            AQUMEASXZB.mkdirs(new Path("/test-target"));
            TWUQEFVMBY = AQUMEASXZB.create(new Path("/test-source/foo"));// don't close

            AQUMEASXZB.rename(new Path("/test-source/"), new Path("/test-target/"));
            AQUMEASXZB.setSafeMode(SAFEMODE_ENTER);
            HLMPPXNVLN.getNameNodeRpc().saveNamespace();
            AQUMEASXZB.setSafeMode(SAFEMODE_LEAVE);
        } finally {
            IOUtils.cleanup(TestSaveNamespace.VCGELLOZIX, TWUQEFVMBY, AQUMEASXZB);
            if (HLMPPXNVLN != null) {
                HLMPPXNVLN.shutdown();
            }
        }
    }

    @Test(timeout = 30000)
    public void testSaveNamespaceWithDanglingLease() throws Exception {
        MiniDFSCluster IVCWMIOXNA = new MiniDFSCluster.Builder(new Configuration()).numDataNodes(1).build();
        IVCWMIOXNA.waitActive();
        DistributedFileSystem USESBQCUVX = IVCWMIOXNA.getFileSystem();
        try {
            IVCWMIOXNA.getNamesystem().leaseManager.addLease("me", "/non-existent");
            USESBQCUVX.setSafeMode(SAFEMODE_ENTER);
            IVCWMIOXNA.getNameNodeRpc().saveNamespace();
            USESBQCUVX.setSafeMode(SAFEMODE_LEAVE);
        } finally {
            if (IVCWMIOXNA != null) {
                IVCWMIOXNA.shutdown();
            }
        }
    }

    private void doAnEdit(FSNamesystem WBWPWOIEBD, int OWQCANQJVD) throws IOException {
        // Make an edit
        WBWPWOIEBD.mkdirs("/test" + OWQCANQJVD, new org.apache.hadoop.fs.permission.PermissionStatus("test", "Test", new FsPermission(((short) (0777)))), true);
    }

    private void checkEditExists(FSNamesystem CNRLRWOJUF, int JFFMTENLBS) throws IOException {
        // Make sure the image loaded including our edit.
        assertNotNull(CNRLRWOJUF.getFileInfo("/test" + JFFMTENLBS, false));
    }

    private Configuration getConf() throws IOException {
        String HOYHHUTTJC = MiniDFSCluster.getBaseDirectory();
        String UAANBPKIUW = (fileAsURI(new File(HOYHHUTTJC, "name1")) + ",") + fileAsURI(new File(HOYHHUTTJC, "name2"));
        Configuration IASJOOXLPM = new HdfsConfiguration();
        FileSystem.setDefaultUri(IASJOOXLPM, "hdfs://localhost:0");
        IASJOOXLPM.set(DFS_NAMENODE_HTTP_ADDRESS_KEY, "0.0.0.0:0");
        IASJOOXLPM.set(DFS_NAMENODE_NAME_DIR_KEY, UAANBPKIUW);
        IASJOOXLPM.set(DFS_NAMENODE_EDITS_DIR_KEY, UAANBPKIUW);
        IASJOOXLPM.set(DFS_NAMENODE_SECONDARY_HTTP_ADDRESS_KEY, "0.0.0.0:0");
        IASJOOXLPM.setBoolean(DFS_PERMISSIONS_ENABLED_KEY, false);
        return IASJOOXLPM;
    }
}