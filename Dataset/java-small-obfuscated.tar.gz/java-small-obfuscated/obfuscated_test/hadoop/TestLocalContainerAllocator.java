public class TestLocalContainerAllocator {
    @Test
    public void testRMConnectionRetry() throws Exception {
        // verify the connection exception is thrown
        // if we haven't exhausted the retry interval
        Configuration QZEVSDKFKB = new Configuration();
        LocalContainerAllocator DQXEOOBPIX = new TestLocalContainerAllocator.StubbedLocalContainerAllocator();
        DQXEOOBPIX.init(QZEVSDKFKB);
        DQXEOOBPIX.start();
        try {
            DQXEOOBPIX.heartbeat();
            Assert.fail("heartbeat was supposed to throw");
        } catch (YarnException e) {
            // YarnException is expected
        } finally {
            DQXEOOBPIX.stop();
        }
        // verify YarnRuntimeException is thrown when the retry interval has expired
        QZEVSDKFKB.setLong(MR_AM_TO_RM_WAIT_INTERVAL_MS, 0);
        DQXEOOBPIX = new TestLocalContainerAllocator.StubbedLocalContainerAllocator();
        DQXEOOBPIX.init(QZEVSDKFKB);
        DQXEOOBPIX.start();
        try {
            DQXEOOBPIX.heartbeat();
            Assert.fail("heartbeat was supposed to throw");
        } catch (YarnRuntimeException e) {
            // YarnRuntimeException is expected
        } finally {
            DQXEOOBPIX.stop();
        }
    }

    private static class StubbedLocalContainerAllocator extends LocalContainerAllocator {
        public StubbedLocalContainerAllocator() {
            super(mock(ClientService.class), TestLocalContainerAllocator.StubbedLocalContainerAllocator.createAppContext(), "nmhost", 1, 2, null);
        }

        @Override
        protected void register() {
        }

        @Override
        protected void unregister() {
        }

        @Override
        protected void startAllocatorThread() {
            allocatorThread = new Thread();
        }

        @Override
        protected ApplicationMasterProtocol createSchedulerProxy() {
            ApplicationMasterProtocol scheduler = mock(ApplicationMasterProtocol.class);
            try {
                when(scheduler.allocate(isA(org.apache.hadoop.yarn.api.protocolrecords.AllocateRequest.class))).thenThrow(RPCUtil.getRemoteException(new IOException("forcefail")));
            } catch (YarnException e) {
            } catch (IOException e) {
            }
            return scheduler;
        }

        private static AppContext createAppContext() {
            ApplicationId appId = ApplicationId.newInstance(1, 1);
            ApplicationAttemptId attemptId = ApplicationAttemptId.newInstance(appId, 1);
            Job job = mock(Job.class);
            @SuppressWarnings("rawtypes")
            EventHandler eventHandler = mock(EventHandler.class);
            AppContext ctx = mock(AppContext.class);
            when(ctx.getApplicationID()).thenReturn(appId);
            when(ctx.getApplicationAttemptId()).thenReturn(attemptId);
            when(ctx.getJob(isA(org.apache.hadoop.mapreduce.v2.api.records.JobId.class))).thenReturn(job);
            when(ctx.getClusterInfo()).thenReturn(new org.apache.hadoop.mapreduce.v2.app.ClusterInfo(Resource.newInstance(10240, 1)));
            when(ctx.getEventHandler()).thenReturn(eventHandler);
            return ctx;
        }
    }
}