/**
 * One instance per block-pool/namespace on the DN, which handles the
 * heartbeats to the active and standby NNs for that namespace.
 * This class manages an instance of {@link BPServiceActor} for each NN,
 * and delegates calls to both NNs.
 * It also maintains the state about which of the NNs is considered active.
 */
@InterfaceAudience.Private
class BPOfferService {
    static final Log HSVVPYDSHI = DataNode.LOG;

    /**
     * Information about the namespace that this service
     * is registering with. This is assigned after
     * the first phase of the handshake.
     */
    NamespaceInfo LESRODFOQB;

    /**
     * The registration information for this block pool.
     * This is assigned after the second phase of the
     * handshake.
     */
    volatile DatanodeRegistration BPBPOILZOI;

    private final DataNode BLAEYSYTRZ;

    /**
     * A reference to the BPServiceActor associated with the currently
     * ACTIVE NN. In the case that all NameNodes are in STANDBY mode,
     * this can be null. If non-null, this must always refer to a member
     * of the {@link #bpServices} list.
     */
    private BPServiceActor PCCDXNCSWQ = null;

    /**
     * The list of all actors for namenodes in this nameservice, regardless
     * of their active or standby states.
     */
    private final List<BPServiceActor> AYIQOSDNDK = new CopyOnWriteArrayList<BPServiceActor>();

    /**
     * Each time we receive a heartbeat from a NN claiming to be ACTIVE,
     * we record that NN's most recent transaction ID here, so long as it
     * is more recent than the previous value. This allows us to detect
     * split-brain scenarios in which a prior NN is still asserting its
     * ACTIVE state but with a too-low transaction ID. See HDFS-2627
     * for details.
     */
    private long XVRBZCUTWB = -1;

    private final ReentrantReadWriteLock OUGMVAXACK = new ReentrantReadWriteLock();

    private final Lock TRCCDXXGGD = OUGMVAXACK.readLock();

    private final Lock DWQBCUFPRZ = OUGMVAXACK.writeLock();

    // utility methods to acquire and release read lock and write lock
    void readLock() {
        TRCCDXXGGD.lock();
    }

    void readUnlock() {
        TRCCDXXGGD.unlock();
    }

    void writeLock() {
        DWQBCUFPRZ.lock();
    }

    void writeUnlock() {
        DWQBCUFPRZ.unlock();
    }

    BPOfferService(List<InetSocketAddress> SPKFQOBQAR, DataNode HYJXHCWDTU) {
        Preconditions.checkArgument(!SPKFQOBQAR.isEmpty(), "Must pass at least one NN.");
        this.BLAEYSYTRZ = HYJXHCWDTU;
        for (InetSocketAddress FIDDQWBJOZ : SPKFQOBQAR) {
            this.AYIQOSDNDK.add(new BPServiceActor(FIDDQWBJOZ, this));
        }
    }

    void refreshNNList(ArrayList<InetSocketAddress> UHYMAZUSBY) throws IOException {
        Set<InetSocketAddress> AWOTHBCNIE = Sets.newHashSet();
        for (BPServiceActor OXKSPUMHHM : AYIQOSDNDK) {
            AWOTHBCNIE.add(OXKSPUMHHM.getNNSocketAddress());
        }
        Set<InetSocketAddress> KQGQLZKDVJ = Sets.newHashSet(UHYMAZUSBY);
        if (!Sets.symmetricDifference(AWOTHBCNIE, KQGQLZKDVJ).isEmpty()) {
            // Keep things simple for now -- we can implement this at a later date.
            throw new IOException("HA does not currently support adding a new standby to a running DN. " + "Please do a rolling restart of DNs to reconfigure the list of NNs.");
        }
    }

    /**
     *
     *
     * @return true if the service has registered with at least one NameNode.
     */
    boolean isInitialized() {
        return BPBPOILZOI != null;
    }

    /**
     *
     *
     * @return true if there is at least one actor thread running which is
    talking to a NameNode.
     */
    boolean isAlive() {
        for (BPServiceActor XDOCTNCASX : AYIQOSDNDK) {
            if (XDOCTNCASX.isAlive()) {
                return true;
            }
        }
        return false;
    }

    String getBlockPoolId() {
        readLock();
        try {
            if (LESRODFOQB != null) {
                return LESRODFOQB.getBlockPoolID();
            } else {
                BPOfferService.HSVVPYDSHI.warn("Block pool ID needed, but service not yet registered with NN", new Exception("trace"));
                return null;
            }
        } finally {
            readUnlock();
        }
    }

    boolean hasBlockPoolId() {
        return getNamespaceInfo() != null;
    }

    NamespaceInfo getNamespaceInfo() {
        readLock();
        try {
            return LESRODFOQB;
        } finally {
            readUnlock();
        }
    }

    @Override
    public String toString() {
        readLock();
        try {
            if (LESRODFOQB == null) {
                // If we haven't yet connected to our NN, we don't yet know our
                // own block pool ID.
                // If _none_ of the block pools have connected yet, we don't even
                // know the DatanodeID ID of this DN.
                String PGNQYAKZPZ = BLAEYSYTRZ.getDatanodeUuid();
                if ((PGNQYAKZPZ == null) || PGNQYAKZPZ.isEmpty()) {
                    PGNQYAKZPZ = "unassigned";
                }
                return ("Block pool <registering> (Datanode Uuid " + PGNQYAKZPZ) + ")";
            } else {
                return ((("Block pool " + getBlockPoolId()) + " (Datanode Uuid ") + BLAEYSYTRZ.getDatanodeUuid()) + ")";
            }
        } finally {
            readUnlock();
        }
    }

    void reportBadBlocks(ExtendedBlock SOZTGQUYZI, String ZDILCAUFLW, StorageType MWPLZREHLN) {
        checkBlock(SOZTGQUYZI);
        for (BPServiceActor VQJQFRINZC : AYIQOSDNDK) {
            VQJQFRINZC.reportBadBlocks(SOZTGQUYZI, ZDILCAUFLW, MWPLZREHLN);
        }
    }

    /* Informing the name node could take a long long time! Should we wait
    till namenode is informed before responding with success to the
    client? For now we don't.
     */
    void notifyNamenodeReceivedBlock(ExtendedBlock ETJSTYAJGK, String OPMBXPXPSB, String OZZXYZJJAZ) {
        checkBlock(ETJSTYAJGK);
        checkDelHint(OPMBXPXPSB);
        ReceivedDeletedBlockInfo RSFCRYBARI = new ReceivedDeletedBlockInfo(ETJSTYAJGK.getLocalBlock(), BlockStatus.RECEIVED_BLOCK, OPMBXPXPSB);
        for (BPServiceActor AATBUQVGPC : AYIQOSDNDK) {
            AATBUQVGPC.notifyNamenodeBlockImmediately(RSFCRYBARI, OZZXYZJJAZ);
        }
    }

    private void checkBlock(ExtendedBlock AKTPTMZWUR) {
        Preconditions.checkArgument(AKTPTMZWUR != null, "block is null");
        Preconditions.checkArgument(AKTPTMZWUR.getBlockPoolId().equals(getBlockPoolId()), "block belongs to BP %s instead of BP %s", AKTPTMZWUR.getBlockPoolId(), getBlockPoolId());
    }

    private void checkDelHint(String PKROGUHLDA) {
        Preconditions.checkArgument(PKROGUHLDA != null, "delHint is null");
    }

    void notifyNamenodeDeletedBlock(ExtendedBlock ZBWODFHLGP, String ZQFCGHHGWM) {
        checkBlock(ZBWODFHLGP);
        ReceivedDeletedBlockInfo DIXSUTVTWW = new ReceivedDeletedBlockInfo(ZBWODFHLGP.getLocalBlock(), BlockStatus.DELETED_BLOCK, null);
        for (BPServiceActor UGAUVMTTGJ : AYIQOSDNDK) {
            UGAUVMTTGJ.notifyNamenodeDeletedBlock(DIXSUTVTWW, ZQFCGHHGWM);
        }
    }

    void notifyNamenodeReceivingBlock(ExtendedBlock CRXIDVNYJA, String XPEKHJLZZC) {
        checkBlock(CRXIDVNYJA);
        ReceivedDeletedBlockInfo TGQGANXTHR = new ReceivedDeletedBlockInfo(CRXIDVNYJA.getLocalBlock(), BlockStatus.RECEIVING_BLOCK, null);
        for (BPServiceActor GOINAOPJQO : AYIQOSDNDK) {
            GOINAOPJQO.notifyNamenodeBlockImmediately(TGQGANXTHR, XPEKHJLZZC);
        }
    }

    // This must be called only by blockPoolManager
    void start() {
        for (BPServiceActor ZMSYAGPTRV : AYIQOSDNDK) {
            ZMSYAGPTRV.start();
        }
    }

    // This must be called only by blockPoolManager.
    void stop() {
        for (BPServiceActor NTCQGHQDRY : AYIQOSDNDK) {
            NTCQGHQDRY.stop();
        }
    }

    // This must be called only by blockPoolManager
    void join() {
        for (BPServiceActor THPPZQXLVZ : AYIQOSDNDK) {
            THPPZQXLVZ.join();
        }
    }

    DataNode getDataNode() {
        return BLAEYSYTRZ;
    }

    /**
     * Called by the BPServiceActors when they handshake to a NN.
     * If this is the first NN connection, this sets the namespace info
     * for this BPOfferService. If it's a connection to a new NN, it
     * verifies that this namespace matches (eg to prevent a misconfiguration
     * where a StandbyNode from a different cluster is specified)
     */
    void verifyAndSetNamespaceInfo(NamespaceInfo JDNPZVSCJC) throws IOException {
        writeLock();
        try {
            if (this.LESRODFOQB == null) {
                this.LESRODFOQB = JDNPZVSCJC;
                boolean EDQKCCWAAJ = false;
                // Now that we know the namespace ID, etc, we can pass this to the DN.
                // The DN can now initialize its local storage if we are the
                // first BP to handshake, etc.
                try {
                    BLAEYSYTRZ.initBlockPool(this);
                    EDQKCCWAAJ = true;
                } finally {
                    if (!EDQKCCWAAJ) {
                        // The datanode failed to initialize the BP. We need to reset
                        // the namespace info so that other BPService actors still have
                        // a chance to set it, and re-initialize the datanode.
                        this.LESRODFOQB = null;
                    }
                }
            } else {
                BPOfferService.checkNSEquality(LESRODFOQB.getBlockPoolID(), JDNPZVSCJC.getBlockPoolID(), "Blockpool ID");
                BPOfferService.checkNSEquality(LESRODFOQB.getNamespaceID(), JDNPZVSCJC.getNamespaceID(), "Namespace ID");
                BPOfferService.checkNSEquality(LESRODFOQB.getClusterID(), JDNPZVSCJC.getClusterID(), "Cluster ID");
            }
        } finally {
            writeUnlock();
        }
    }

    /**
     * After one of the BPServiceActors registers successfully with the
     * NN, it calls this function to verify that the NN it connected to
     * is consistent with other NNs serving the block-pool.
     */
    void registrationSucceeded(BPServiceActor WOKVTFFMBO, DatanodeRegistration KPJTWODIAU) throws IOException {
        writeLock();
        try {
            if (BPBPOILZOI != null) {
                BPOfferService.checkNSEquality(BPBPOILZOI.getStorageInfo().getNamespaceID(), KPJTWODIAU.getStorageInfo().getNamespaceID(), "namespace ID");
                BPOfferService.checkNSEquality(BPBPOILZOI.getStorageInfo().getClusterID(), KPJTWODIAU.getStorageInfo().getClusterID(), "cluster ID");
            } else {
                BPBPOILZOI = KPJTWODIAU;
            }
            BLAEYSYTRZ.bpRegistrationSucceeded(BPBPOILZOI, getBlockPoolId());
            // Add the initial block token secret keys to the DN's secret manager.
            if (BLAEYSYTRZ.isBlockTokenEnabled) {
                BLAEYSYTRZ.blockPoolTokenSecretManager.addKeys(getBlockPoolId(), KPJTWODIAU.getExportedKeys());
            }
        } finally {
            writeUnlock();
        }
    }

    /**
     * Verify equality of two namespace-related fields, throwing
     * an exception if they are unequal.
     */
    private static void checkNSEquality(Object DQXVONIIFQ, Object FMYGSCJQAG, String FJLJFSBCMM) throws IOException {
        if (!DQXVONIIFQ.equals(FMYGSCJQAG)) {
            throw new IOException(((((((((FJLJFSBCMM + " mismatch: ") + "previously connected to ") + FJLJFSBCMM) + " ") + DQXVONIIFQ) + " but now connected to ") + FJLJFSBCMM) + " ") + FMYGSCJQAG);
        }
    }

    DatanodeRegistration createRegistration() {
        writeLock();
        try {
            Preconditions.checkState(LESRODFOQB != null, "getRegistration() can only be called after initial handshake");
            return BLAEYSYTRZ.createBPRegistration(LESRODFOQB);
        } finally {
            writeUnlock();
        }
    }

    /**
     * Called when an actor shuts down. If this is the last actor
     * to shut down, shuts down the whole blockpool in the DN.
     */
    void shutdownActor(BPServiceActor LDFYTEJMNT) {
        writeLock();
        try {
            if (PCCDXNCSWQ == LDFYTEJMNT) {
                PCCDXNCSWQ = null;
            }
            AYIQOSDNDK.remove(LDFYTEJMNT);
            if (AYIQOSDNDK.isEmpty()) {
                BLAEYSYTRZ.shutdownBlockPool(this);
            }
        } finally {
            writeUnlock();
        }
    }

    /**
     * Called by the DN to report an error to the NNs.
     */
    void trySendErrorReport(int IDUAHLOXBA, String EYFLBAYPNL) {
        for (BPServiceActor OODHAAQBFP : AYIQOSDNDK) {
            OODHAAQBFP.trySendErrorReport(IDUAHLOXBA, EYFLBAYPNL);
        }
    }

    /**
     * Ask each of the actors to schedule a block report after
     * the specified delay.
     */
    void scheduleBlockReport(long FXKIXKKABX) {
        for (BPServiceActor PCHRTQDXOH : AYIQOSDNDK) {
            PCHRTQDXOH.scheduleBlockReport(FXKIXKKABX);
        }
    }

    /**
     * Ask each of the actors to report a bad block hosted on another DN.
     */
    void reportRemoteBadBlock(DatanodeInfo CRTSCSLCMK, ExtendedBlock FCPMOCXXNN) {
        for (BPServiceActor BNGPTXQTSK : AYIQOSDNDK) {
            try {
                BNGPTXQTSK.reportRemoteBadBlock(CRTSCSLCMK, FCPMOCXXNN);
            } catch (IOException e) {
                BPOfferService.HSVVPYDSHI.warn((("Couldn't report bad block " + FCPMOCXXNN) + " to ") + BNGPTXQTSK, e);
            }
        }
    }

    /**
     *
     *
     * @return a proxy to the active NN, or null if the BPOS has not
    acknowledged any NN as active yet.
     */
    DatanodeProtocolClientSideTranslatorPB getActiveNN() {
        readLock();
        try {
            if (PCCDXNCSWQ != null) {
                return PCCDXNCSWQ.bpNamenode;
            } else {
                return null;
            }
        } finally {
            readUnlock();
        }
    }

    @VisibleForTesting
    List<BPServiceActor> getBPServiceActors() {
        return Lists.newArrayList(AYIQOSDNDK);
    }

    /**
     * Signal the current rolling upgrade status as indicated by the NN.
     *
     * @param inProgress
     * 		true if a rolling upgrade is in progress
     */
    void signalRollingUpgrade(boolean URXSLJCZQS) {
        if (URXSLJCZQS) {
            BLAEYSYTRZ.getFSDataset().enableTrash(getBlockPoolId());
        } else {
            BLAEYSYTRZ.getFSDataset().restoreTrash(getBlockPoolId());
        }
    }

    /**
     * Update the BPOS's view of which NN is active, based on a heartbeat
     * response from one of the actors.
     *
     * @param actor
     * 		the actor which received the heartbeat
     * @param nnHaState
     * 		the HA-related heartbeat contents
     */
    void updateActorStatesFromHeartbeat(BPServiceActor BXFCVJSXDS, NNHAStatusHeartbeat COINBSRMEQ) {
        writeLock();
        try {
            final long MZVZWRXFIJ = COINBSRMEQ.getTxId();
            final boolean JZPWMNGYNP = COINBSRMEQ.getState() == HAServiceState.ACTIVE;
            final boolean XAOBUWLJUA = PCCDXNCSWQ == BXFCVJSXDS;
            final boolean LSGLJNCHWH = MZVZWRXFIJ > XVRBZCUTWB;
            if (JZPWMNGYNP && (!XAOBUWLJUA)) {
                BPOfferService.HSVVPYDSHI.info(((("Namenode " + BXFCVJSXDS) + " trying to claim ACTIVE state with ") + "txid=") + MZVZWRXFIJ);
                if (!LSGLJNCHWH) {
                    // Split-brain scenario - an NN is trying to claim active
                    // state when a different NN has already claimed it with a higher
                    // txid.
                    BPOfferService.HSVVPYDSHI.warn((((("NN " + BXFCVJSXDS) + " tried to claim ACTIVE state at txid=") + MZVZWRXFIJ) + " but there was already a more recent claim at txid=") + XVRBZCUTWB);
                    return;
                } else {
                    if (PCCDXNCSWQ == null) {
                        BPOfferService.HSVVPYDSHI.info("Acknowledging ACTIVE Namenode " + BXFCVJSXDS);
                    } else {
                        BPOfferService.HSVVPYDSHI.info((((("Namenode " + BXFCVJSXDS) + " taking over ACTIVE state from ") + PCCDXNCSWQ) + " at higher txid=") + MZVZWRXFIJ);
                    }
                    PCCDXNCSWQ = BXFCVJSXDS;
                }
            } else
                if ((!JZPWMNGYNP) && XAOBUWLJUA) {
                    BPOfferService.HSVVPYDSHI.info(((("Namenode " + BXFCVJSXDS) + " relinquishing ACTIVE state with ") + "txid=") + COINBSRMEQ.getTxId());
                    PCCDXNCSWQ = null;
                }

            if (PCCDXNCSWQ == BXFCVJSXDS) {
                assert MZVZWRXFIJ >= XVRBZCUTWB;
                XVRBZCUTWB = MZVZWRXFIJ;
            }
        } finally {
            writeUnlock();
        }
    }

    /**
     *
     *
     * @return true if the given NN address is one of the NNs for this
    block pool
     */
    boolean containsNN(InetSocketAddress QEHWACLIGZ) {
        for (BPServiceActor GMNGMLQDLB : AYIQOSDNDK) {
            if (GMNGMLQDLB.getNNSocketAddress().equals(QEHWACLIGZ)) {
                return true;
            }
        }
        return false;
    }

    @VisibleForTesting
    int countNameNodes() {
        return AYIQOSDNDK.size();
    }

    /**
     * Run an immediate block report on this thread. Used by tests.
     */
    @VisibleForTesting
    void triggerBlockReportForTests() throws IOException {
        for (BPServiceActor KLZAKTBVIU : AYIQOSDNDK) {
            KLZAKTBVIU.triggerBlockReportForTests();
        }
    }

    /**
     * Run an immediate deletion report on this thread. Used by tests.
     */
    @VisibleForTesting
    void triggerDeletionReportForTests() throws IOException {
        for (BPServiceActor ZGWCRFEQJI : AYIQOSDNDK) {
            ZGWCRFEQJI.triggerDeletionReportForTests();
        }
    }

    /**
     * Run an immediate heartbeat from all actors. Used by tests.
     */
    @VisibleForTesting
    void triggerHeartbeatForTests() throws IOException {
        for (BPServiceActor MUNLQPUBGX : AYIQOSDNDK) {
            MUNLQPUBGX.triggerHeartbeatForTests();
        }
    }

    boolean processCommandFromActor(DatanodeCommand JTQFGWZLVC, BPServiceActor LVPAOVLQIF) throws IOException {
        assert AYIQOSDNDK.contains(LVPAOVLQIF);
        if (JTQFGWZLVC == null) {
            return true;
        }
        /* Datanode Registration can be done asynchronously here. No need to hold
        the lock. for more info refer HDFS-5014
         */
        if (DatanodeProtocol.DNA_REGISTER == JTQFGWZLVC.getAction()) {
            // namenode requested a registration - at start or if NN lost contact
            // Just logging the claiming state is OK here instead of checking the
            // actor state by obtaining the lock
            BPOfferService.HSVVPYDSHI.info(((("DatanodeCommand action : DNA_REGISTER from " + LVPAOVLQIF.nnAddr) + " with ") + LVPAOVLQIF.state) + " state");
            LVPAOVLQIF.reRegister();
            return false;
        }
        writeLock();
        try {
            if (LVPAOVLQIF == PCCDXNCSWQ) {
                return processCommandFromActive(JTQFGWZLVC, LVPAOVLQIF);
            } else {
                return processCommandFromStandby(JTQFGWZLVC, LVPAOVLQIF);
            }
        } finally {
            writeUnlock();
        }
    }

    private String blockIdArrayToString(long[] HJIRJZMBKM) {
        long BEYPVRCVHP = BLAEYSYTRZ.getMaxNumberOfBlocksToLog();
        StringBuilder JDMXYHYFFZ = new StringBuilder();
        String ICOMYKFNBX = "";
        for (int NBRQSWQZZU = 0; NBRQSWQZZU < HJIRJZMBKM.length; NBRQSWQZZU++) {
            if (NBRQSWQZZU >= BEYPVRCVHP) {
                JDMXYHYFFZ.append("...");
                break;
            }
            JDMXYHYFFZ.append(ICOMYKFNBX).append(HJIRJZMBKM[NBRQSWQZZU]);
            ICOMYKFNBX = ", ";
        }
        return JDMXYHYFFZ.toString();
    }

    /**
     * This method should handle all commands from Active namenode except
     * DNA_REGISTER which should be handled earlier itself.
     *
     * @param cmd
     * 		
     * @return true if further processing may be required or false otherwise.
     * @throws IOException
     * 		
     */
    private boolean processCommandFromActive(DatanodeCommand UXFUURVRJC, BPServiceActor IJFIPDGJWL) throws IOException {
        final BlockCommand NFBHMMAWOA = (UXFUURVRJC instanceof BlockCommand) ? ((BlockCommand) (UXFUURVRJC)) : null;
        final BlockIdCommand MENBLJBFZB = (UXFUURVRJC instanceof BlockIdCommand) ? ((BlockIdCommand) (UXFUURVRJC)) : null;
        switch (UXFUURVRJC.getAction()) {
            case DatanodeProtocol.DNA_TRANSFER :
                // Send a copy of a block to another datanode
                BLAEYSYTRZ.transferBlocks(NFBHMMAWOA.getBlockPoolId(), NFBHMMAWOA.getBlocks(), NFBHMMAWOA.getTargets(), NFBHMMAWOA.getTargetStorageTypes());
                BLAEYSYTRZ.metrics.incrBlocksReplicated(NFBHMMAWOA.getBlocks().length);
                break;
            case DatanodeProtocol.DNA_INVALIDATE :
                // 
                // Some local block(s) are obsolete and can be
                // safely garbage-collected.
                // 
                Block[] YFBHNBTAXF = NFBHMMAWOA.getBlocks();
                try {
                    if (BLAEYSYTRZ.blockScanner != null) {
                        BLAEYSYTRZ.blockScanner.deleteBlocks(NFBHMMAWOA.getBlockPoolId(), YFBHNBTAXF);
                    }
                    // using global fsdataset
                    BLAEYSYTRZ.getFSDataset().invalidate(NFBHMMAWOA.getBlockPoolId(), YFBHNBTAXF);
                } catch (IOException e) {
                    // Exceptions caught here are not expected to be disk-related.
                    throw e;
                }
                BLAEYSYTRZ.metrics.incrBlocksRemoved(YFBHNBTAXF.length);
                break;
            case DatanodeProtocol.DNA_CACHE :
                BPOfferService.HSVVPYDSHI.info(((("DatanodeCommand action: DNA_CACHE for " + MENBLJBFZB.getBlockPoolId()) + " of [") + blockIdArrayToString(MENBLJBFZB.getBlockIds())) + "]");
                BLAEYSYTRZ.getFSDataset().cache(MENBLJBFZB.getBlockPoolId(), MENBLJBFZB.getBlockIds());
                break;
            case DatanodeProtocol.DNA_UNCACHE :
                BPOfferService.HSVVPYDSHI.info(((("DatanodeCommand action: DNA_UNCACHE for " + MENBLJBFZB.getBlockPoolId()) + " of [") + blockIdArrayToString(MENBLJBFZB.getBlockIds())) + "]");
                BLAEYSYTRZ.getFSDataset().uncache(MENBLJBFZB.getBlockPoolId(), MENBLJBFZB.getBlockIds());
                break;
            case DatanodeProtocol.DNA_SHUTDOWN :
                // TODO: DNA_SHUTDOWN appears to be unused - the NN never sends this command
                // See HDFS-2987.
                throw new UnsupportedOperationException("Received unimplemented DNA_SHUTDOWN");
            case DatanodeProtocol.DNA_FINALIZE :
                String CCKNDFAIXI = ((FinalizeCommand) (UXFUURVRJC)).getBlockPoolId();
                BPOfferService.HSVVPYDSHI.info("Got finalize command for block pool " + CCKNDFAIXI);
                assert getBlockPoolId().equals(CCKNDFAIXI) : ((("BP " + getBlockPoolId()) + " received DNA_FINALIZE ") + "for other block pool ") + CCKNDFAIXI;
                BLAEYSYTRZ.finalizeUpgradeForPool(CCKNDFAIXI);
                break;
            case DatanodeProtocol.DNA_RECOVERBLOCK :
                String PFJKRWGVYP = "NameNode at " + IJFIPDGJWL.getNNSocketAddress();
                BLAEYSYTRZ.recoverBlocks(PFJKRWGVYP, ((BlockRecoveryCommand) (UXFUURVRJC)).getRecoveringBlocks());
                break;
            case DatanodeProtocol.DNA_ACCESSKEYUPDATE :
                BPOfferService.HSVVPYDSHI.info("DatanodeCommand action: DNA_ACCESSKEYUPDATE");
                if (BLAEYSYTRZ.isBlockTokenEnabled) {
                    BLAEYSYTRZ.blockPoolTokenSecretManager.addKeys(getBlockPoolId(), ((KeyUpdateCommand) (UXFUURVRJC)).getExportedKeys());
                }
                break;
            case DatanodeProtocol.DNA_BALANCERBANDWIDTHUPDATE :
                BPOfferService.HSVVPYDSHI.info("DatanodeCommand action: DNA_BALANCERBANDWIDTHUPDATE");
                long LBVYRMENFI = ((BalancerBandwidthCommand) (UXFUURVRJC)).getBalancerBandwidthValue();
                if (LBVYRMENFI > 0) {
                    DataXceiverServer CDHELQSVQR = ((DataXceiverServer) (BLAEYSYTRZ.dataXceiverServer.getRunnable()));
                    BPOfferService.HSVVPYDSHI.info((((("Updating balance throttler bandwidth from " + CDHELQSVQR.balanceThrottler.getBandwidth()) + " bytes/s ") + "to: ") + LBVYRMENFI) + " bytes/s.");
                    CDHELQSVQR.balanceThrottler.setBandwidth(LBVYRMENFI);
                }
                break;
            default :
                BPOfferService.HSVVPYDSHI.warn("Unknown DatanodeCommand action: " + UXFUURVRJC.getAction());
        }
        return true;
    }

    /**
     * This method should handle commands from Standby namenode except
     * DNA_REGISTER which should be handled earlier itself.
     */
    private boolean processCommandFromStandby(DatanodeCommand DZIMVDAQLX, BPServiceActor FTYZNZTIPJ) throws IOException {
        switch (DZIMVDAQLX.getAction()) {
            case DatanodeProtocol.DNA_ACCESSKEYUPDATE :
                BPOfferService.HSVVPYDSHI.info("DatanodeCommand action from standby: DNA_ACCESSKEYUPDATE");
                if (BLAEYSYTRZ.isBlockTokenEnabled) {
                    BLAEYSYTRZ.blockPoolTokenSecretManager.addKeys(getBlockPoolId(), ((KeyUpdateCommand) (DZIMVDAQLX)).getExportedKeys());
                }
                break;
            case DatanodeProtocol.DNA_TRANSFER :
            case DatanodeProtocol.DNA_INVALIDATE :
            case DatanodeProtocol.DNA_SHUTDOWN :
            case DatanodeProtocol.DNA_FINALIZE :
            case DatanodeProtocol.DNA_RECOVERBLOCK :
            case DatanodeProtocol.DNA_BALANCERBANDWIDTHUPDATE :
            case DatanodeProtocol.DNA_CACHE :
            case DatanodeProtocol.DNA_UNCACHE :
                BPOfferService.HSVVPYDSHI.warn("Got a command from standby NN - ignoring command:" + DZIMVDAQLX.getAction());
                break;
            default :
                BPOfferService.HSVVPYDSHI.warn("Unknown DatanodeCommand action: " + DZIMVDAQLX.getAction());
        }
        return true;
    }

    /* Let the actor retry for initialization until all namenodes of cluster have
    failed.
     */
    boolean shouldRetryInit() {
        if (hasBlockPoolId()) {
            // One of the namenode registered successfully. lets continue retry for
            // other.
            return true;
        }
        return isAlive();
    }
}