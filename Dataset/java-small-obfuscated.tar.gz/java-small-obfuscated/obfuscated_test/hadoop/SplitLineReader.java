@InterfaceAudience.Private
@InterfaceStability.Unstable
public class SplitLineReader extends LineReader {
    public SplitLineReader(InputStream GRUXGQVXTQ, byte[] EZSROMWSMM) {
        super(GRUXGQVXTQ, EZSROMWSMM);
    }

    public SplitLineReader(InputStream YAFMULTIYT, Configuration QQLVRYAPLY, byte[] HGNNOKGKEP) throws IOException {
        super(YAFMULTIYT, QQLVRYAPLY, HGNNOKGKEP);
    }

    public boolean needAdditionalRecordAfterSplit() {
        return false;
    }
}