/**
 * Utilities shared by schedulers.
 */
@Private
@Unstable
public class SchedulerUtils {
    private static final RecordFactory AZHEHVBVSX = RecordFactoryProvider.getRecordFactory(null);

    public static final String XBHIWMDIRN = "Container released by application";

    public static final String YMBIYAIYPE = "Container released on a *lost* node";

    public static final String AEPZQDTUTK = "Container preempted by scheduler";

    public static final String TKBKHOOCFT = "Container of a completed application";

    public static final String KOJPZBMJQL = "Container expired since it was unused";

    public static final String TOGRHYHYWR = "Container reservation no longer required.";

    /**
     * Utility to create a {@link ContainerStatus} during exceptional
     * circumstances.
     *
     * @param containerId
     * 		{@link ContainerId} of returned/released/lost container.
     * @param diagnostics
     * 		diagnostic message
     * @return <code>ContainerStatus</code> for an returned/released/lost
    container
     */
    public static ContainerStatus createAbnormalContainerStatus(ContainerId XUXDJOBONF, String BEXTJLEPTL) {
        return SchedulerUtils.createAbnormalContainerStatus(XUXDJOBONF, ABORTED, BEXTJLEPTL);
    }

    /**
     * Utility to create a {@link ContainerStatus} during exceptional
     * circumstances.
     *
     * @param containerId
     * 		{@link ContainerId} of returned/released/lost container.
     * @param diagnostics
     * 		diagnostic message
     * @return <code>ContainerStatus</code> for an returned/released/lost
    container
     */
    public static ContainerStatus createPreemptedContainerStatus(ContainerId AVCXDAGHTI, String GGVTVOXXAC) {
        return SchedulerUtils.createAbnormalContainerStatus(AVCXDAGHTI, PREEMPTED, GGVTVOXXAC);
    }

    /**
     * Utility to create a {@link ContainerStatus} during exceptional
     * circumstances.
     *
     * @param containerId
     * 		{@link ContainerId} of returned/released/lost container.
     * @param diagnostics
     * 		diagnostic message
     * @return <code>ContainerStatus</code> for an returned/released/lost
    container
     */
    private static ContainerStatus createAbnormalContainerStatus(ContainerId DBSNDWNDCI, int FMBIORWMGJ, String QGKPLJWFHM) {
        ContainerStatus ZYXGEGEMMB = SchedulerUtils.AZHEHVBVSX.newRecordInstance(ContainerStatus.class);
        ZYXGEGEMMB.setContainerId(DBSNDWNDCI);
        ZYXGEGEMMB.setDiagnostics(QGKPLJWFHM);
        ZYXGEGEMMB.setExitStatus(FMBIORWMGJ);
        ZYXGEGEMMB.setState(COMPLETE);
        return ZYXGEGEMMB;
    }

    /**
     * Utility method to normalize a list of resource requests, by insuring that
     * the memory for each request is a multiple of minMemory and is not zero.
     */
    public static void normalizeRequests(List<ResourceRequest> NZXMFYBFJX, ResourceCalculator ZUKQLIWMAX, Resource JFGRRPQXLR, Resource WTVNMJWKWI, Resource LNKKSYBVGT) {
        for (ResourceRequest QDDOQZPMGP : NZXMFYBFJX) {
            SchedulerUtils.normalizeRequest(QDDOQZPMGP, ZUKQLIWMAX, JFGRRPQXLR, WTVNMJWKWI, LNKKSYBVGT, WTVNMJWKWI);
        }
    }

    /**
     * Utility method to normalize a resource request, by insuring that the
     * requested memory is a multiple of minMemory and is not zero.
     */
    public static void normalizeRequest(ResourceRequest JUJNVTZVIK, ResourceCalculator LBMPVRTPXJ, Resource ZZCHVLEYIA, Resource DHQEGFDYUP, Resource JQWQXDBZBH) {
        Resource UZFBCPGSZR = Resources.normalize(LBMPVRTPXJ, JUJNVTZVIK.getCapability(), DHQEGFDYUP, JQWQXDBZBH, DHQEGFDYUP);
        JUJNVTZVIK.setCapability(UZFBCPGSZR);
    }

    /**
     * Update resource in SchedulerNode if any resource change in RMNode.
     *
     * @param node
     * 		SchedulerNode with old resource view
     * @param rmNode
     * 		RMNode with new resource view
     * @param clusterResource
     * 		the cluster's resource that need to update
     * @param log
     * 		Scheduler's log for resource change
     * @return true if the resources have changed
     */
    public static boolean updateResourceIfChanged(SchedulerNode JJEWOUFXLB, RMNode PJTZCQCPDY, Resource VJONMFTIKN, Log EYXYTPZPIQ) {
        boolean VLMGIESCVT = false;
        Resource KUTETVXZCU = JJEWOUFXLB.getAvailableResource();
        Resource UMSGEIGILZ = Resources.subtract(PJTZCQCPDY.getTotalCapability(), JJEWOUFXLB.getUsedResource());
        if (!UMSGEIGILZ.equals(KUTETVXZCU)) {
            VLMGIESCVT = true;
            Resource GBJQATYPSK = Resources.subtract(UMSGEIGILZ, KUTETVXZCU);
            // Reflect resource change to scheduler node.
            JJEWOUFXLB.applyDeltaOnAvailableResource(GBJQATYPSK);
            // Reflect resource change to clusterResource.
            Resources.addTo(VJONMFTIKN, GBJQATYPSK);
            // TODO process resource over-commitment case (allocated containers
            // > total capacity) in different option by getting value of
            // overCommitTimeoutMillis.
            // Log resource change
            EYXYTPZPIQ.info(((((("Resource change on node: " + PJTZCQCPDY.getNodeAddress()) + " with delta: CPU: ") + GBJQATYPSK.getMemory()) + "core, Memory: ") + GBJQATYPSK.getMemory()) + "MB");
        }
        return VLMGIESCVT;
    }

    /**
     * Utility method to normalize a list of resource requests, by insuring that
     * the memory for each request is a multiple of minMemory and is not zero.
     */
    public static void normalizeRequests(List<ResourceRequest> BLNOBNSSBN, ResourceCalculator DFZKXZDSCI, Resource RPAXPSJMOG, Resource RQQORPCFGP, Resource IEVXMDBAPX, Resource SQBVSIVHNA) {
        for (ResourceRequest MPLXUCWHWN : BLNOBNSSBN) {
            SchedulerUtils.normalizeRequest(MPLXUCWHWN, DFZKXZDSCI, RPAXPSJMOG, RQQORPCFGP, IEVXMDBAPX, SQBVSIVHNA);
        }
    }

    /**
     * Utility method to normalize a resource request, by insuring that the
     * requested memory is a multiple of minMemory and is not zero.
     */
    public static void normalizeRequest(ResourceRequest QWFKSXAAWF, ResourceCalculator MEAYCVJOTM, Resource TLWOMLDAZC, Resource DCHSFGWBRI, Resource OLKWDJBAFN, Resource RVBBIQPNYH) {
        Resource ACMUHGYUZF = Resources.normalize(MEAYCVJOTM, QWFKSXAAWF.getCapability(), DCHSFGWBRI, OLKWDJBAFN, RVBBIQPNYH);
        QWFKSXAAWF.setCapability(ACMUHGYUZF);
    }

    /**
     * Utility method to validate a resource request, by insuring that the
     * requested memory/vcore is non-negative and not greater than max
     *
     * @throws <code>InvalidResourceRequestException</code>
     * 		when there is invalid
     * 		request
     */
    public static void validateResourceRequest(ResourceRequest SWGOVSBCXF, Resource CLHGNWGGKH) throws InvalidResourceRequestException {
        if ((SWGOVSBCXF.getCapability().getMemory() < 0) || (SWGOVSBCXF.getCapability().getMemory() > CLHGNWGGKH.getMemory())) {
            throw new InvalidResourceRequestException(((("Invalid resource request" + ((", requested memory < 0" + ", or requested memory > max configured") + ", requestedMemory=")) + SWGOVSBCXF.getCapability().getMemory()) + ", maxMemory=") + CLHGNWGGKH.getMemory());
        }
        if ((SWGOVSBCXF.getCapability().getVirtualCores() < 0) || (SWGOVSBCXF.getCapability().getVirtualCores() > CLHGNWGGKH.getVirtualCores())) {
            throw new InvalidResourceRequestException(((("Invalid resource request" + ((", requested virtual cores < 0" + ", or requested virtual cores > max configured") + ", requestedVirtualCores=")) + SWGOVSBCXF.getCapability().getVirtualCores()) + ", maxVirtualCores=") + CLHGNWGGKH.getVirtualCores());
        }
    }
}