/**
 * This class tests commands from Trash.
 */
public class TestTrash extends TestCase {
    private static final Path JHUWWWMDAZ = new Path(new File(System.getProperty("test.build.data", "/tmp")).toURI().toString().replace(' ', '+'), "testTrash");

    protected static Path mkdir(FileSystem YPYTKHINIC, Path IZRQUBFZMQ) throws IOException {
        assertTrue(YPYTKHINIC.mkdirs(IZRQUBFZMQ));
        assertTrue(YPYTKHINIC.exists(IZRQUBFZMQ));
        assertTrue(YPYTKHINIC.getFileStatus(IZRQUBFZMQ).isDirectory());
        return IZRQUBFZMQ;
    }

    // check that the specified file is in Trash
    protected static void checkTrash(FileSystem XHCTOFFFNN, Path PLTLIPZLHY, Path PJYDMVZNYN) throws IOException {
        Path WNVXQGTDVA = Path.mergePaths(PLTLIPZLHY, PJYDMVZNYN);
        assertTrue("Could not find file in trash: " + WNVXQGTDVA, XHCTOFFFNN.exists(WNVXQGTDVA));
    }

    // counts how many instances of the file are in the Trash
    // they all are in format fileName*
    protected static int countSameDeletedFiles(FileSystem SROXCJOOAI, Path UCCVWWBFEG, Path ZKPGKDTYKK) throws IOException {
        final String PUPDPZAOAE = ZKPGKDTYKK.getName();
        System.out.println((("Counting " + ZKPGKDTYKK) + " in ") + UCCVWWBFEG.toString());
        // filter that matches all the files that start with fileName*
        PathFilter HEPHWMCSYE = new PathFilter() {
            @Override
            public boolean accept(Path FVBNSEXNTS) {
                return FVBNSEXNTS.getName().startsWith(PUPDPZAOAE);
            }
        };
        // run the filter
        FileStatus[] HIXBEWDXUS = SROXCJOOAI.listStatus(UCCVWWBFEG, HEPHWMCSYE);
        return HIXBEWDXUS == null ? 0 : HIXBEWDXUS.length;
    }

    // check that the specified file is not in Trash
    static void checkNotInTrash(FileSystem HLHXUKINPM, Path MZTQNZXSGN, String HACNSQIHWA) throws IOException {
        Path FXEOJXKEWJ = new Path((MZTQNZXSGN + "/") + new Path(HACNSQIHWA).getName());
        assertTrue(!HLHXUKINPM.exists(FXEOJXKEWJ));
    }

    /**
     * Test trash for the shell's delete command for the file system fs
     *
     * @param fs
     * 		
     * @param base
     * 		- the base path where files are created
     * @throws IOException
     * 		
     */
    public static void trashShell(final FileSystem OVHJDHEVFE, final Path LEEQNSXHMB) throws IOException {
        Configuration ANFCJOXBER = new Configuration();
        ANFCJOXBER.set("fs.defaultFS", OVHJDHEVFE.getUri().toString());
        TestTrash.trashShell(ANFCJOXBER, LEEQNSXHMB, null, null);
    }

    /**
     * Test trash for the shell's delete command for the default file system
     * specified in the paramter conf
     *
     * @param conf
     * 		
     * @param base
     * 		- the base path where files are created
     * @param trashRoot
     * 		- the expected place where the trashbin resides
     * @throws IOException
     * 		
     */
    public static void trashShell(final Configuration OOKFYTKBAI, final Path BQGDYZKVRT, FileSystem RFCXTERNBP, Path NLPBRCPQDS) throws IOException {
        FileSystem MNSZYOEFIB = FileSystem.get(OOKFYTKBAI);
        OOKFYTKBAI.setLong(FS_TRASH_INTERVAL_KEY, 0);// disabled

        assertFalse(new Trash(OOKFYTKBAI).isEnabled());
        OOKFYTKBAI.setLong(FS_TRASH_INTERVAL_KEY, 10);// 10 minute

        assertTrue(new Trash(OOKFYTKBAI).isEnabled());
        FsShell JBTMHGAZAV = new FsShell();
        JBTMHGAZAV.setConf(OOKFYTKBAI);
        if (NLPBRCPQDS == null) {
            NLPBRCPQDS = JBTMHGAZAV.getCurrentTrashDir();
        }
        if (RFCXTERNBP == null) {
            RFCXTERNBP = MNSZYOEFIB;
        }
        // First create a new directory with mkdirs
        Path ZTHRWVITCS = new Path(BQGDYZKVRT, "test/mkdirs");
        TestTrash.mkdir(MNSZYOEFIB, ZTHRWVITCS);
        // Second, create a file in that directory.
        Path NPMJYHZTPH = new Path(BQGDYZKVRT, "test/mkdirs/myFile");
        writeFile(MNSZYOEFIB, NPMJYHZTPH, 10);
        // Verify that expunge without Trash directory
        // won't throw Exception
        {
            String[] VRYHYPJXLW = new String[1];
            VRYHYPJXLW[0] = "-expunge";
            int LIVJBJBTFC = -1;
            try {
                LIVJBJBTFC = JBTMHGAZAV.run(VRYHYPJXLW);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(LIVJBJBTFC == 0);
        }
        // Verify that we succeed in removing the file we created.
        // This should go into Trash.
        {
            String[] YKXGTPTUSX = new String[2];
            YKXGTPTUSX[0] = "-rm";
            YKXGTPTUSX[1] = NPMJYHZTPH.toString();
            int ZJYPQEFTUP = -1;
            try {
                ZJYPQEFTUP = JBTMHGAZAV.run(YKXGTPTUSX);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(ZJYPQEFTUP == 0);
            TestTrash.checkTrash(RFCXTERNBP, NLPBRCPQDS, MNSZYOEFIB.makeQualified(NPMJYHZTPH));
        }
        // Verify that we can recreate the file
        writeFile(MNSZYOEFIB, NPMJYHZTPH, 10);
        // Verify that we succeed in removing the file we re-created
        {
            String[] QTDLLQCFOE = new String[2];
            QTDLLQCFOE[0] = "-rm";
            QTDLLQCFOE[1] = new Path(BQGDYZKVRT, "test/mkdirs/myFile").toString();
            int BEPGTPXHNK = -1;
            try {
                BEPGTPXHNK = JBTMHGAZAV.run(QTDLLQCFOE);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(BEPGTPXHNK == 0);
        }
        // Verify that we can recreate the file
        writeFile(MNSZYOEFIB, NPMJYHZTPH, 10);
        // Verify that we succeed in removing the whole directory
        // along with the file inside it.
        {
            String[] VPRYGBZIHL = new String[2];
            VPRYGBZIHL[0] = "-rmr";
            VPRYGBZIHL[1] = new Path(BQGDYZKVRT, "test/mkdirs").toString();
            int FZZWBIOESE = -1;
            try {
                FZZWBIOESE = JBTMHGAZAV.run(VPRYGBZIHL);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(FZZWBIOESE == 0);
        }
        // recreate directory
        TestTrash.mkdir(MNSZYOEFIB, ZTHRWVITCS);
        // Verify that we succeed in removing the whole directory
        {
            String[] WSTALDMUSQ = new String[2];
            WSTALDMUSQ[0] = "-rmr";
            WSTALDMUSQ[1] = new Path(BQGDYZKVRT, "test/mkdirs").toString();
            int PBVBCNPJZI = -1;
            try {
                PBVBCNPJZI = JBTMHGAZAV.run(WSTALDMUSQ);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(PBVBCNPJZI == 0);
        }
        // Check that we can delete a file from the trash
        {
            Path LMRJYHXXFI = new Path(NLPBRCPQDS, "toErase");
            int XFMUMMVPRH = -1;
            writeFile(RFCXTERNBP, LMRJYHXXFI, 10);
            try {
                XFMUMMVPRH = JBTMHGAZAV.run(new String[]{ "-rm", LMRJYHXXFI.toString() });
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(XFMUMMVPRH == 0);
            TestTrash.checkNotInTrash(RFCXTERNBP, NLPBRCPQDS, LMRJYHXXFI.toString());
            TestTrash.checkNotInTrash(RFCXTERNBP, NLPBRCPQDS, LMRJYHXXFI.toString() + ".1");
        }
        // simulate Trash removal
        {
            String[] HTEFWMNWHS = new String[1];
            HTEFWMNWHS[0] = "-expunge";
            int QSARRUJGZA = -1;
            try {
                QSARRUJGZA = JBTMHGAZAV.run(HTEFWMNWHS);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(QSARRUJGZA == 0);
        }
        // verify that after expunging the Trash, it really goes away
        TestTrash.checkNotInTrash(RFCXTERNBP, NLPBRCPQDS, new Path(BQGDYZKVRT, "test/mkdirs/myFile").toString());
        // recreate directory and file
        TestTrash.mkdir(MNSZYOEFIB, ZTHRWVITCS);
        writeFile(MNSZYOEFIB, NPMJYHZTPH, 10);
        // remove file first, then remove directory
        {
            String[] TVDQFZSOQK = new String[2];
            TVDQFZSOQK[0] = "-rm";
            TVDQFZSOQK[1] = NPMJYHZTPH.toString();
            int OCAZOTNVYE = -1;
            try {
                OCAZOTNVYE = JBTMHGAZAV.run(TVDQFZSOQK);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(OCAZOTNVYE == 0);
            TestTrash.checkTrash(RFCXTERNBP, NLPBRCPQDS, NPMJYHZTPH);
            TVDQFZSOQK = new String[2];
            TVDQFZSOQK[0] = "-rmr";
            TVDQFZSOQK[1] = ZTHRWVITCS.toString();
            OCAZOTNVYE = -1;
            try {
                OCAZOTNVYE = JBTMHGAZAV.run(TVDQFZSOQK);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(OCAZOTNVYE == 0);
            TestTrash.checkTrash(RFCXTERNBP, NLPBRCPQDS, ZTHRWVITCS);
        }
        // attempt to remove parent of trash
        {
            String[] BORISNZTNF = new String[2];
            BORISNZTNF[0] = "-rmr";
            BORISNZTNF[1] = NLPBRCPQDS.getParent().getParent().toString();
            int SWUPOKGFSX = -1;
            try {
                SWUPOKGFSX = JBTMHGAZAV.run(BORISNZTNF);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertEquals("exit code", 1, SWUPOKGFSX);
            assertTrue(RFCXTERNBP.exists(NLPBRCPQDS));
        }
        // Verify skip trash option really works
        // recreate directory and file
        TestTrash.mkdir(MNSZYOEFIB, ZTHRWVITCS);
        writeFile(MNSZYOEFIB, NPMJYHZTPH, 10);
        // Verify that skip trash option really skips the trash for files (rm)
        {
            String[] RLMDJAQTBS = new String[3];
            RLMDJAQTBS[0] = "-rm";
            RLMDJAQTBS[1] = "-skipTrash";
            RLMDJAQTBS[2] = NPMJYHZTPH.toString();
            int JSVZNZOECL = -1;
            try {
                // Clear out trash
                assertEquals("-expunge failed", 0, JBTMHGAZAV.run(new String[]{ "-expunge" }));
                JSVZNZOECL = JBTMHGAZAV.run(RLMDJAQTBS);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertFalse((("Expected TrashRoot (" + NLPBRCPQDS) + ") to exist in file system:") + RFCXTERNBP.getUri(), RFCXTERNBP.exists(NLPBRCPQDS));// No new Current should be created

            assertFalse(MNSZYOEFIB.exists(NPMJYHZTPH));
            assertTrue(JSVZNZOECL == 0);
        }
        // recreate directory and file
        TestTrash.mkdir(MNSZYOEFIB, ZTHRWVITCS);
        writeFile(MNSZYOEFIB, NPMJYHZTPH, 10);
        // Verify that skip trash option really skips the trash for rmr
        {
            String[] CJAPRSEBYK = new String[3];
            CJAPRSEBYK[0] = "-rmr";
            CJAPRSEBYK[1] = "-skipTrash";
            CJAPRSEBYK[2] = ZTHRWVITCS.toString();
            int YKUXZEZUMG = -1;
            try {
                // Clear out trash
                assertEquals(0, JBTMHGAZAV.run(new String[]{ "-expunge" }));
                YKUXZEZUMG = JBTMHGAZAV.run(CJAPRSEBYK);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertFalse(RFCXTERNBP.exists(NLPBRCPQDS));// No new Current should be created

            assertFalse(MNSZYOEFIB.exists(ZTHRWVITCS));
            assertFalse(MNSZYOEFIB.exists(NPMJYHZTPH));
            assertTrue(YKUXZEZUMG == 0);
        }
        // deleting same file multiple times
        {
            int YMHRDLRFTR = -1;
            TestTrash.mkdir(MNSZYOEFIB, ZTHRWVITCS);
            try {
                assertEquals(0, JBTMHGAZAV.run(new String[]{ "-expunge" }));
            } catch (Exception e) {
                System.err.println("Exception raised from fs expunge " + e.getLocalizedMessage());
            }
            // create a file in that directory.
            NPMJYHZTPH = new Path(BQGDYZKVRT, "test/mkdirs/myFile");
            String[] PXKPJIYTOL = new String[]{ "-rm", NPMJYHZTPH.toString() };
            int RGHJYOXSHI = 10;
            for (int HFMUJCJRCM = 0; HFMUJCJRCM < RGHJYOXSHI; HFMUJCJRCM++) {
                // create file
                writeFile(MNSZYOEFIB, NPMJYHZTPH, 10);
                // delete file
                try {
                    YMHRDLRFTR = JBTMHGAZAV.run(PXKPJIYTOL);
                } catch (Exception e) {
                    System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
                }
                assertTrue(YMHRDLRFTR == 0);
            }
            // current trash directory
            Path BKEZBHPFCJ = Path.mergePaths(new Path(NLPBRCPQDS.toUri().getPath()), new Path(NPMJYHZTPH.getParent().toUri().getPath()));
            System.out.println((((("Deleting same myFile: myFile.parent=" + NPMJYHZTPH.getParent().toUri().getPath()) + "; trashroot=") + NLPBRCPQDS.toUri().getPath()) + "; trashDir=") + BKEZBHPFCJ.toUri().getPath());
            int RYXKRMOMTJ = TestTrash.countSameDeletedFiles(MNSZYOEFIB, BKEZBHPFCJ, NPMJYHZTPH);
            System.out.println((((("counted " + RYXKRMOMTJ) + " files ") + NPMJYHZTPH.getName()) + "* in ") + BKEZBHPFCJ);
            assertTrue(RYXKRMOMTJ == RGHJYOXSHI);
        }
        // Verify skipTrash option is suggested when rm fails due to its absence
        {
            String[] YVQVUHJKYA = new String[2];
            YVQVUHJKYA[0] = "-rmr";
            YVQVUHJKYA[1] = "/";// This always contains trash directory

            PrintStream YNGAJVQVHX = System.out;
            PrintStream XBZCOSBNEU = System.err;
            ByteArrayOutputStream KHACWCAKMV = new ByteArrayOutputStream();
            PrintStream RUSVWFCNVW = new PrintStream(KHACWCAKMV);
            System.setOut(RUSVWFCNVW);
            System.setErr(RUSVWFCNVW);
            try {
                JBTMHGAZAV.run(YVQVUHJKYA);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            String MEOHUBPWLB = KHACWCAKMV.toString();
            System.setOut(YNGAJVQVHX);
            System.setErr(XBZCOSBNEU);
            assertTrue("skipTrash wasn't suggested as remedy to failed rm command" + " or we deleted / even though we could not get server defaults", (MEOHUBPWLB.indexOf("Consider using -skipTrash option") != (-1)) || (MEOHUBPWLB.indexOf("Failed to determine server trash configuration") != (-1)));
        }
        // Verify old checkpoint format is recognized
        {
            // emulate two old trash checkpoint directories, one that is old enough
            // to be deleted on the next expunge and one that isn't.
            long KVAXYFVQUR = OOKFYTKBAI.getLong(FS_TRASH_INTERVAL_KEY, FS_TRASH_INTERVAL_DEFAULT);
            long TGQZIQHCZX = Time.now();
            DateFormat SJIZHSTSYF = new SimpleDateFormat("yyMMddHHmm");
            Path IHYPEYBKTP = new Path(NLPBRCPQDS.getParent(), SJIZHSTSYF.format((TGQZIQHCZX - ((KVAXYFVQUR * 60) * 1000)) - 1));
            Path WASIDHRZZR = new Path(NLPBRCPQDS.getParent(), SJIZHSTSYF.format(TGQZIQHCZX));
            TestTrash.mkdir(RFCXTERNBP, IHYPEYBKTP);
            TestTrash.mkdir(RFCXTERNBP, WASIDHRZZR);
            // Clear out trash
            int LTIKEIDVVU = -1;
            try {
                LTIKEIDVVU = JBTMHGAZAV.run(new String[]{ "-expunge" });
            } catch (Exception e) {
                System.err.println("Exception raised from fs expunge " + e.getLocalizedMessage());
            }
            assertEquals(0, LTIKEIDVVU);
            assertFalse("old checkpoint format not recognized", RFCXTERNBP.exists(IHYPEYBKTP));
            assertTrue("old checkpoint format directory should not be removed", RFCXTERNBP.exists(WASIDHRZZR));
        }
    }

    public static void trashNonDefaultFS(Configuration VTNKXAXVOS) throws IOException {
        VTNKXAXVOS.setLong(FS_TRASH_INTERVAL_KEY, 10);// 10 minute

        // attempt non-default FileSystem trash
        {
            final FileSystem ELVPHCWHVW = FileSystem.getLocal(VTNKXAXVOS);
            Path IYVQBQOHDS = TestTrash.JHUWWWMDAZ;
            Path WXCYNFICQW = new Path(IYVQBQOHDS, "foo/bar");
            if (ELVPHCWHVW.exists(IYVQBQOHDS)) {
                ELVPHCWHVW.delete(IYVQBQOHDS, true);
            }
            try {
                writeFile(ELVPHCWHVW, WXCYNFICQW, 10);
                FileSystem.closeAll();
                FileSystem TVPBGVVEQR = FileSystem.get(URI.create("file:///"), VTNKXAXVOS);
                Trash YJPCPGSGGK = new Trash(TVPBGVVEQR, VTNKXAXVOS);
                YJPCPGSGGK.moveToTrash(WXCYNFICQW.getParent());
                TestTrash.checkTrash(TVPBGVVEQR, YJPCPGSGGK.getCurrentTrashDir(), WXCYNFICQW);
            } finally {
                if (ELVPHCWHVW.exists(IYVQBQOHDS)) {
                    ELVPHCWHVW.delete(IYVQBQOHDS, true);
                }
            }
        }
    }

    public void testTrash() throws IOException {
        Configuration KECCBBQLJD = new Configuration();
        KECCBBQLJD.setClass("fs.file.impl", TestTrash.TestLFS.class, FileSystem.class);
        TestTrash.trashShell(FileSystem.getLocal(KECCBBQLJD), TestTrash.JHUWWWMDAZ);
    }

    public void testNonDefaultFS() throws IOException {
        Configuration MHDGPXDHME = new Configuration();
        MHDGPXDHME.setClass("fs.file.impl", TestTrash.TestLFS.class, FileSystem.class);
        MHDGPXDHME.set("fs.defaultFS", "invalid://host/bar/foo");
        TestTrash.trashNonDefaultFS(MHDGPXDHME);
    }

    public void testPluggableTrash() throws IOException {
        Configuration QSPCCOCCNM = new Configuration();
        // Test plugged TrashPolicy
        QSPCCOCCNM.setClass("fs.trash.classname", TestTrash.TestTrashPolicy.class, TrashPolicy.class);
        Trash ZUCLWJKZOW = new Trash(QSPCCOCCNM);
        assertTrue(ZUCLWJKZOW.getTrashPolicy().getClass().equals(TestTrash.TestTrashPolicy.class));
    }

    public void testTrashEmptier() throws Exception {
        Configuration XBRGYWQHKT = new Configuration();
        // Trash with 12 second deletes and 6 seconds checkpoints
        XBRGYWQHKT.set(FS_TRASH_INTERVAL_KEY, "0.2");// 12 seconds

        XBRGYWQHKT.setClass("fs.file.impl", TestTrash.TestLFS.class, FileSystem.class);
        XBRGYWQHKT.set(FS_TRASH_CHECKPOINT_INTERVAL_KEY, "0.1");// 6 seconds

        FileSystem QNYHBVMDXE = FileSystem.getLocal(XBRGYWQHKT);
        XBRGYWQHKT.set("fs.default.name", QNYHBVMDXE.getUri().toString());
        Trash EOEVKPAJBA = new Trash(XBRGYWQHKT);
        // Start Emptier in background
        Runnable BUTPIUQYQA = EOEVKPAJBA.getEmptier();
        Thread NSVMFNRKKT = new Thread(BUTPIUQYQA);
        NSVMFNRKKT.start();
        FsShell CWAYXGRHQW = new FsShell();
        CWAYXGRHQW.setConf(XBRGYWQHKT);
        CWAYXGRHQW.init();
        // First create a new directory with mkdirs
        Path AVEFPRKOAJ = new Path(TestTrash.JHUWWWMDAZ, "test/mkdirs");
        TestTrash.mkdir(QNYHBVMDXE, AVEFPRKOAJ);
        int OQBQICRXFZ = 0;
        Set<String> YLFIFKDYOK = new HashSet<String>();
        while (true) {
            // Create a file with a new name
            Path FRIKDLVXIL = new Path(TestTrash.JHUWWWMDAZ, "test/mkdirs/myFile" + (OQBQICRXFZ++));
            writeFile(QNYHBVMDXE, FRIKDLVXIL, 10);
            // Delete the file to trash
            String[] GGYLPHNHEG = new String[2];
            GGYLPHNHEG[0] = "-rm";
            GGYLPHNHEG[1] = FRIKDLVXIL.toString();
            int LWWFENAXGQ = -1;
            try {
                LWWFENAXGQ = CWAYXGRHQW.run(GGYLPHNHEG);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
            }
            assertTrue(LWWFENAXGQ == 0);
            Path LCNYXAYVWB = CWAYXGRHQW.getCurrentTrashDir();
            FileStatus[] LNEGYMHHMH = QNYHBVMDXE.listStatus(LCNYXAYVWB.getParent());
            // Scan files in .Trash and add them to set of checkpoints
            for (FileStatus DJKJULMICE : LNEGYMHHMH) {
                String JVTRHRAYUN = DJKJULMICE.getPath().getName();
                YLFIFKDYOK.add(JVTRHRAYUN);
            }
            // If checkpoints has 4 objects it is Current + 3 checkpoint directories
            if (YLFIFKDYOK.size() == 4) {
                // The actual contents should be smaller since the last checkpoint
                // should've been deleted and Current might not have been recreated yet
                assertTrue(YLFIFKDYOK.size() > LNEGYMHHMH.length);
                break;
            }
            Thread.sleep(5000);
        } 
        NSVMFNRKKT.interrupt();
        NSVMFNRKKT.join();
    }

    /**
     *
     *
     * @see TestCase#tearDown()
     */
    @Override
    protected void tearDown() throws IOException {
        File FKWQKEIORZ = new File(TestTrash.JHUWWWMDAZ.toUri().getPath());
        if (FKWQKEIORZ.exists() && (!FileUtil.fullyDelete(FKWQKEIORZ))) {
            throw new IOException("Cannot remove data directory: " + FKWQKEIORZ);
        }
    }

    static class TestLFS extends LocalFileSystem {
        Path UWUXATASOX;

        TestLFS() {
            this(new Path(TestTrash.JHUWWWMDAZ, "user/test"));
        }

        TestLFS(Path home) {
            super();
            this.UWUXATASOX = home;
        }

        @Override
        public Path getHomeDirectory() {
            return UWUXATASOX;
        }
    }

    /**
     * test same file deletion - multiple time
     *  this is more of a performance test - shouldn't be run as a unit test
     *
     * @throws IOException
     * 		
     */
    public static void performanceTestDeleteSameFile() throws IOException {
        Path WTPQMGTELI = TestTrash.JHUWWWMDAZ;
        Configuration AGHYHQWBCC = new Configuration();
        AGHYHQWBCC.setClass("fs.file.impl", TestTrash.TestLFS.class, FileSystem.class);
        FileSystem VTHGBREAGU = FileSystem.getLocal(AGHYHQWBCC);
        AGHYHQWBCC.set("fs.defaultFS", VTHGBREAGU.getUri().toString());
        AGHYHQWBCC.setLong(FS_TRASH_INTERVAL_KEY, 10);// minutes..

        FsShell NJBUPKNEKH = new FsShell();
        NJBUPKNEKH.setConf(AGHYHQWBCC);
        // Path trashRoot = null;
        Path NASWIMMJRH = new Path(WTPQMGTELI, "test/mkdirs");
        TestTrash.mkdir(VTHGBREAGU, NASWIMMJRH);
        // create a file in that directory.
        Path KRUKQTEUKP;
        long LIQIRTTBDL;
        long EAFIDLZZPF = 0;
        int UJSXNYYAOC = 0;
        int EGVNUFLEIW = 10;// how much slower any of subsequent deletion can be

        KRUKQTEUKP = new Path(WTPQMGTELI, "test/mkdirs/myFile");
        String[] FBCYOXEEFL = new String[]{ "-rm", KRUKQTEUKP.toString() };
        int OOGDCJCDDY = 1000;
        for (int XJOEBDPLOB = 0; XJOEBDPLOB < OOGDCJCDDY; XJOEBDPLOB++) {
            writeFile(VTHGBREAGU, KRUKQTEUKP, 10);
            LIQIRTTBDL = Time.now();
            try {
                UJSXNYYAOC = NJBUPKNEKH.run(FBCYOXEEFL);
            } catch (Exception e) {
                System.err.println("Exception raised from Trash.run " + e.getLocalizedMessage());
                throw new IOException(e.getMessage());
            }
            assertTrue(UJSXNYYAOC == 0);
            long APFWFLLQVM = Time.now() - LIQIRTTBDL;
            // take median of the first 10 runs
            if (XJOEBDPLOB < 10) {
                if (XJOEBDPLOB == 0) {
                    EAFIDLZZPF = APFWFLLQVM;
                } else {
                    EAFIDLZZPF = (EAFIDLZZPF + APFWFLLQVM) / 2;
                }
            }
            // we don't want to print every iteration - let's do every 10th
            int KLJJOGSVSY = OOGDCJCDDY / 10;
            if (XJOEBDPLOB > 10) {
                if ((XJOEBDPLOB % KLJJOGSVSY) == 0)
                    System.out.println((((((((("iteration=" + XJOEBDPLOB) + ";res =") + UJSXNYYAOC) + "; start=") + LIQIRTTBDL) + "; iterTime = ") + APFWFLLQVM) + " vs. firstTime=") + EAFIDLZZPF);

                long GYBECKUAVX = EAFIDLZZPF * EGVNUFLEIW;
                assertTrue(APFWFLLQVM < GYBECKUAVX);// no more then twice of median first 10

            }
        }
    }

    public static void main(String[] SZXSMSERGP) throws IOException {
        // run performance piece as a separate test
        TestTrash.performanceTestDeleteSameFile();
    }

    // Test TrashPolicy. Don't care about implementation.
    public static class TestTrashPolicy extends TrashPolicy {
        public TestTrashPolicy() {
        }

        @Override
        public void initialize(Configuration conf, FileSystem fs, Path home) {
        }

        @Override
        public boolean isEnabled() {
            return false;
        }

        @Override
        public boolean moveToTrash(Path path) throws IOException {
            return false;
        }

        @Override
        public void createCheckpoint() throws IOException {
        }

        @Override
        public void deleteCheckpoint() throws IOException {
        }

        @Override
        public Path getCurrentTrashDir() {
            return null;
        }

        @Override
        public Runnable getEmptier() throws IOException {
            return null;
        }
    }
}