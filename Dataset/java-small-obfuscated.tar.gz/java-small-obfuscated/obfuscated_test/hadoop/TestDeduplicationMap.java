public class TestDeduplicationMap {
    @Test
    public void testDeduplicationMap() {
        DeduplicationMap<String> VRJVFJGWIS = DeduplicationMap.newMap();
        Assert.assertEquals(1, VRJVFJGWIS.getId("1"));
        Assert.assertEquals(2, VRJVFJGWIS.getId("2"));
        Assert.assertEquals(3, VRJVFJGWIS.getId("3"));
        Assert.assertEquals(1, VRJVFJGWIS.getId("1"));
        Assert.assertEquals(2, VRJVFJGWIS.getId("2"));
        Assert.assertEquals(3, VRJVFJGWIS.getId("3"));
    }
}