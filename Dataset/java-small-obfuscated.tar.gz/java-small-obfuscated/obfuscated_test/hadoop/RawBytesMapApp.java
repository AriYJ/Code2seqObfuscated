public class RawBytesMapApp {
    private String MLWTDUEEZQ;

    private DataOutputStream XBGMMGMMGK;

    public RawBytesMapApp(String PKLHXHIEIX) {
        this.MLWTDUEEZQ = PKLHXHIEIX;
        XBGMMGMMGK = new DataOutputStream(System.out);
    }

    public void go() throws IOException {
        BufferedReader JPXBJJPYUQ = new BufferedReader(new InputStreamReader(System.in));
        String JZYIIEYZNY;
        while ((JZYIIEYZNY = JPXBJJPYUQ.readLine()) != null) {
            for (String ARNEJNDAUY : JZYIIEYZNY.split(MLWTDUEEZQ)) {
                writeString(ARNEJNDAUY);// write key

                writeInt(1);// write value

            }
        } 
        System.out.flush();
    }

    public static void main(String[] WIRGQKAWRU) throws IOException {
        RawBytesMapApp BJVHHUIFBV = new RawBytesMapApp(WIRGQKAWRU[0].replace(".", "\\."));
        BJVHHUIFBV.go();
    }

    private void writeString(String UWAYRACTIB) throws IOException {
        byte[] CADUANSSGM = UWAYRACTIB.getBytes("UTF-8");
        XBGMMGMMGK.writeInt(CADUANSSGM.length);
        XBGMMGMMGK.write(CADUANSSGM);
    }

    private void writeInt(int TANIBTBNRI) throws IOException {
        XBGMMGMMGK.writeInt(4);
        IntWritable FBXSSPOPBC = new IntWritable(TANIBTBNRI);
        FBXSSPOPBC.write(XBGMMGMMGK);
    }
}