public class TestKMS {
    @Before
    public void cleanUp() {
        // resetting kerberos security
        Configuration YUAVTNYZTM = new Configuration();
        UserGroupInformation.setConfiguration(YUAVTNYZTM);
    }

    public static File getTestDir() throws Exception {
        File AOEPVFMIWJ = new File("dummy");
        AOEPVFMIWJ = AOEPVFMIWJ.getAbsoluteFile();
        AOEPVFMIWJ = AOEPVFMIWJ.getParentFile();
        AOEPVFMIWJ = new File(AOEPVFMIWJ, "target");
        AOEPVFMIWJ = new File(AOEPVFMIWJ, UUID.randomUUID().toString());
        if (!AOEPVFMIWJ.mkdirs()) {
            throw new RuntimeException("Could not create test directory: " + AOEPVFMIWJ);
        }
        return AOEPVFMIWJ;
    }

    public static Server createJettyServer(String AHKWCWLTDU, String VKNFTAVYQF) {
        try {
            boolean BGWCEOJIHS = AHKWCWLTDU != null;
            InetAddress VKUQFVZCVI = InetAddress.getByName("localhost");
            String UPEAQHRNPN = "localhost";
            ServerSocket LHUHAVOZJM = new ServerSocket(0, 50, VKUQFVZCVI);
            int AMQLOMMLLA = LHUHAVOZJM.getLocalPort();
            LHUHAVOZJM.close();
            Server BMXIHBFARD = new Server(0);
            if (!BGWCEOJIHS) {
                BMXIHBFARD.getConnectors()[0].setHost(UPEAQHRNPN);
                BMXIHBFARD.getConnectors()[0].setPort(AMQLOMMLLA);
            } else {
                SslSocketConnector DVDICIYFSS = new SslSocketConnector();
                DVDICIYFSS.setHost(UPEAQHRNPN);
                DVDICIYFSS.setPort(AMQLOMMLLA);
                DVDICIYFSS.setNeedClientAuth(false);
                DVDICIYFSS.setKeystore(AHKWCWLTDU);
                DVDICIYFSS.setKeystoreType("jks");
                DVDICIYFSS.setKeyPassword(VKNFTAVYQF);
                BMXIHBFARD.setConnectors(new Connector[]{ DVDICIYFSS });
            }
            return BMXIHBFARD;
        } catch (Exception ex) {
            throw new RuntimeException("Could not start embedded servlet container, " + ex.getMessage(), ex);
        }
    }

    public static URL getJettyURL(Server GKNDARKSCB) {
        boolean ZGKAHZSSTW = GKNDARKSCB.getConnectors()[0].getClass() == SslSocketConnector.class;
        try {
            String JALBFPVDTC = (ZGKAHZSSTW) ? "https" : "http";
            return new URL((((JALBFPVDTC + "://") + GKNDARKSCB.getConnectors()[0].getHost()) + ":") + GKNDARKSCB.getConnectors()[0].getPort());
        } catch (MalformedURLException ex) {
            throw new RuntimeException("It should never happen, " + ex.getMessage(), ex);
        }
    }

    public static abstract class KMSCallable implements Callable<Void> {
        private URL QEHINBVVZW;

        protected URL getKMSUrl() {
            return QEHINBVVZW;
        }
    }

    protected void runServer(String UNHLJNBAJQ, String RTSMEKZZRB, File BSEKGACFNW, TestKMS.KMSCallable JTILGUNBZX) throws Exception {
        System.setProperty(KMS_CONFIG_DIR, BSEKGACFNW.getAbsolutePath());
        System.setProperty("log4j.configuration", "log4j.properties");
        Server RNSKMLBBJP = TestKMS.createJettyServer(UNHLJNBAJQ, RTSMEKZZRB);
        try {
            ClassLoader ZWMQRLLPVA = Thread.currentThread().getContextClassLoader();
            URL PSDYDMIAER = ZWMQRLLPVA.getResource("webapp");
            if (PSDYDMIAER == null) {
                throw new RuntimeException("Could not find webapp/ dir in test classpath");
            }
            WebAppContext AQWMEQMLTZ = new WebAppContext(PSDYDMIAER.getPath(), "/kms");
            RNSKMLBBJP.addHandler(AQWMEQMLTZ);
            RNSKMLBBJP.start();
            PSDYDMIAER = new URL(TestKMS.getJettyURL(RNSKMLBBJP), "kms");
            System.out.println("Test KMS running at: " + PSDYDMIAER);
            JTILGUNBZX.QEHINBVVZW = PSDYDMIAER;
            JTILGUNBZX.call();
        } finally {
            if ((RNSKMLBBJP != null) && RNSKMLBBJP.isRunning()) {
                try {
                    RNSKMLBBJP.stop();
                } catch (Exception ex) {
                    throw new RuntimeException("Could not stop embedded Jetty, " + ex.getMessage(), ex);
                }
            }
        }
    }

    protected Configuration createBaseKMSConf(File UUBZNXUEAJ) throws Exception {
        Configuration GHKENLCFSG = new Configuration(false);
        GHKENLCFSG.set("hadoop.security.key.provider.path", ("jceks://file@/" + UUBZNXUEAJ.getAbsolutePath()) + "/kms.keystore");
        GHKENLCFSG.set("hadoop.kms.authentication.type", "simple");
        return GHKENLCFSG;
    }

    protected void writeConf(File TVQSLDAYJE, Configuration JHXXBOOULM) throws Exception {
        Writer ESLAQRPJXR = new FileWriter(new File(TVQSLDAYJE, KMSConfiguration.KMS_SITE_XML));
        JHXXBOOULM.writeXml(ESLAQRPJXR);
        ESLAQRPJXR.close();
        ESLAQRPJXR = new FileWriter(new File(TVQSLDAYJE, KMSConfiguration.KMS_ACLS_XML));
        JHXXBOOULM.writeXml(ESLAQRPJXR);
        ESLAQRPJXR.close();
        // create empty core-site.xml
        ESLAQRPJXR = new FileWriter(new File(TVQSLDAYJE, "core-site.xml"));
        new Configuration(false).writeXml(ESLAQRPJXR);
        ESLAQRPJXR.close();
    }

    protected URI createKMSUri(URL DZRJXJUHNI) throws Exception {
        String SVCCWZUJLA = DZRJXJUHNI.toString();
        SVCCWZUJLA = SVCCWZUJLA.replaceFirst("://", "@");
        return new URI("kms://" + SVCCWZUJLA);
    }

    private static class KerberosConfiguration extends javax.security.auth.login.Configuration {
        private String KUMYPJQTIQ;

        private String CDZOFJJSBC;

        private boolean NBMEYNERGR;

        private KerberosConfiguration(String principal, File keytab, boolean client) {
            this.KUMYPJQTIQ = principal;
            this.CDZOFJJSBC = keytab.getAbsolutePath();
            this.NBMEYNERGR = client;
        }

        public static javax.security.auth.login.Configuration createClientConfig(String principal, File keytab) {
            return new TestKMS.KerberosConfiguration(principal, keytab, true);
        }

        private static String getKrb5LoginModuleName() {
            return System.getProperty("java.vendor").contains("IBM") ? "com.ibm.security.auth.module.Krb5LoginModule" : "com.sun.security.auth.module.Krb5LoginModule";
        }

        @Override
        public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
            Map<String, String> options = new HashMap<String, String>();
            options.put("keyTab", CDZOFJJSBC);
            options.put("principal", KUMYPJQTIQ);
            options.put("useKeyTab", "true");
            options.put("storeKey", "true");
            options.put("doNotPrompt", "true");
            options.put("useTicketCache", "true");
            options.put("renewTGT", "true");
            options.put("refreshKrb5Config", "true");
            options.put("isInitiator", Boolean.toString(NBMEYNERGR));
            String ticketCache = System.getenv("KRB5CCNAME");
            if (ticketCache != null) {
                options.put("ticketCache", ticketCache);
            }
            options.put("debug", "true");
            return new AppConfigurationEntry[]{ new AppConfigurationEntry(TestKMS.KerberosConfiguration.getKrb5LoginModuleName(), AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, options) };
        }
    }

    private static MiniKdc QXVGGMAPRW;

    private static File HRZIHQZIEP;

    @BeforeClass
    public static void setUpMiniKdc() throws Exception {
        File BYQXEJTFML = TestKMS.getTestDir();
        Properties WSPBMBOLFP = MiniKdc.createConf();
        TestKMS.QXVGGMAPRW = new MiniKdc(WSPBMBOLFP, BYQXEJTFML);
        TestKMS.QXVGGMAPRW.start();
        TestKMS.HRZIHQZIEP = new File(BYQXEJTFML, "keytab");
        List<String> ODAAPWFZON = new ArrayList<String>();
        ODAAPWFZON.add("HTTP/localhost");
        ODAAPWFZON.add("client");
        ODAAPWFZON.add("client/host");
        ODAAPWFZON.add("client1");
        for (KMSACLs.Type PSMBEXCEVL : Type.values()) {
            ODAAPWFZON.add(PSMBEXCEVL.toString());
        }
        ODAAPWFZON.add("CREATE_MATERIAL");
        ODAAPWFZON.add("ROLLOVER_MATERIAL");
        TestKMS.QXVGGMAPRW.createPrincipal(TestKMS.HRZIHQZIEP, ODAAPWFZON.toArray(new String[ODAAPWFZON.size()]));
    }

    @AfterClass
    public static void tearDownMiniKdc() throws Exception {
        if (TestKMS.QXVGGMAPRW != null) {
            TestKMS.QXVGGMAPRW.stop();
        }
    }

    private <T> T doAs(String QDYIIRPWGT, final PrivilegedExceptionAction<T> HTJCOMDGZL) throws Exception {
        Set<Principal> OFKGHIFUTB = new HashSet<Principal>();
        OFKGHIFUTB.add(new KerberosPrincipal(QDYIIRPWGT));
        // client login
        Subject VZPSGEIPFZ = new Subject(false, OFKGHIFUTB, new HashSet<Object>(), new HashSet<Object>());
        LoginContext OQGYDVFJYZ = new LoginContext("", VZPSGEIPFZ, null, TestKMS.KerberosConfiguration.createClientConfig(QDYIIRPWGT, TestKMS.HRZIHQZIEP));
        try {
            OQGYDVFJYZ.login();
            VZPSGEIPFZ = OQGYDVFJYZ.getSubject();
            UserGroupInformation JTSPZRGCVT = UserGroupInformation.getUGIFromSubject(VZPSGEIPFZ);
            return JTSPZRGCVT.doAs(HTJCOMDGZL);
        } finally {
            OQGYDVFJYZ.logout();
        }
    }

    public void testStartStop(final boolean JKKNYRYXYS, final boolean DOHKABAXOB) throws Exception {
        Configuration MRBMPXDQOF = new Configuration();
        if (DOHKABAXOB) {
            MRBMPXDQOF.set("hadoop.security.authentication", "kerberos");
        }
        UserGroupInformation.setConfiguration(MRBMPXDQOF);
        File TXESVWWQUU = TestKMS.getTestDir();
        MRBMPXDQOF = createBaseKMSConf(TXESVWWQUU);
        final String GDFONMHZJS;
        final String CTSNWVWSFH;
        if (JKKNYRYXYS) {
            String VQDIKDTPVN = KeyStoreTestUtil.getClasspathDir(TestKMS.class);
            KeyStoreTestUtil.setupSSLConfig(TXESVWWQUU.getAbsolutePath(), VQDIKDTPVN, MRBMPXDQOF, false);
            GDFONMHZJS = TXESVWWQUU.getAbsolutePath() + "/serverKS.jks";
            CTSNWVWSFH = "serverP";
        } else {
            GDFONMHZJS = null;
            CTSNWVWSFH = null;
        }
        if (DOHKABAXOB) {
            MRBMPXDQOF.set("hadoop.kms.authentication.type", "kerberos");
            MRBMPXDQOF.set("hadoop.kms.authentication.kerberos.keytab", TestKMS.HRZIHQZIEP.getAbsolutePath());
            MRBMPXDQOF.set("hadoop.kms.authentication.kerberos.principal", "HTTP/localhost");
            MRBMPXDQOF.set("hadoop.kms.authentication.kerberos.name.rules", "DEFAULT");
        }
        writeConf(TXESVWWQUU, MRBMPXDQOF);
        runServer(GDFONMHZJS, CTSNWVWSFH, TXESVWWQUU, new TestKMS.KMSCallable() {
            @Override
            public Void call() throws Exception {
                final Configuration UPFXZSVFEB = new Configuration();
                URL EOQZGHASMG = getKMSUrl();
                Assert.assertEquals(GDFONMHZJS != null, EOQZGHASMG.getProtocol().equals("https"));
                final URI FMQGKLHCUT = createKMSUri(getKMSUrl());
                if (DOHKABAXOB) {
                    for (String GQIAYFKZNQ : new String[]{ "client", "client/host" }) {
                        doAs(GQIAYFKZNQ, new PrivilegedExceptionAction<Void>() {
                            @Override
                            public Void run() throws Exception {
                                final KeyProvider PDXRJCBLSL = new KMSClientProvider(FMQGKLHCUT, UPFXZSVFEB);
                                // getKeys() empty
                                Assert.assertTrue(PDXRJCBLSL.getKeys().isEmpty());
                                return null;
                            }
                        });
                    }
                } else {
                    KeyProvider BBCHGZZDEI = new KMSClientProvider(FMQGKLHCUT, UPFXZSVFEB);
                    // getKeys() empty
                    Assert.assertTrue(BBCHGZZDEI.getKeys().isEmpty());
                }
                return null;
            }
        });
    }

    @Test
    public void testStartStopHttpPseudo() throws Exception {
        testStartStop(false, false);
    }

    @Test
    public void testStartStopHttpsPseudo() throws Exception {
        testStartStop(true, false);
    }

    @Test
    public void testStartStopHttpKerberos() throws Exception {
        testStartStop(false, true);
    }

    @Test
    public void testStartStopHttpsKerberos() throws Exception {
        testStartStop(true, true);
    }

    @Test
    public void testKMSProvider() throws Exception {
        Configuration OHKDDZZOML = new Configuration();
        OHKDDZZOML.set("hadoop.security.authentication", "kerberos");
        UserGroupInformation.setConfiguration(OHKDDZZOML);
        File KPWHMKXWEY = TestKMS.getTestDir();
        OHKDDZZOML = createBaseKMSConf(KPWHMKXWEY);
        writeConf(KPWHMKXWEY, OHKDDZZOML);
        runServer(null, null, KPWHMKXWEY, new TestKMS.KMSCallable() {
            @Override
            public Void call() throws Exception {
                Date DDAAMPONVZ = new Date();
                Configuration QKFWDWQTGU = new Configuration();
                URI THFEIIKURF = createKMSUri(getKMSUrl());
                KeyProvider RFVCJKBNOG = new KMSClientProvider(THFEIIKURF, QKFWDWQTGU);
                // getKeys() empty
                Assert.assertTrue(RFVCJKBNOG.getKeys().isEmpty());
                // getKeysMetadata() empty
                Assert.assertEquals(0, RFVCJKBNOG.getKeysMetadata().length);
                // createKey()
                KeyProvider.Options BRYVBWOICP = new KeyProvider.Options(QKFWDWQTGU);
                BRYVBWOICP.setCipher("AES/CTR/NoPadding");
                BRYVBWOICP.setBitLength(128);
                BRYVBWOICP.setDescription("l1");
                KeyProvider.KeyVersion IAIEECPUYR = RFVCJKBNOG.createKey("k1", BRYVBWOICP);
                Assert.assertNotNull(IAIEECPUYR);
                Assert.assertNotNull(IAIEECPUYR.getVersionName());
                Assert.assertNotNull(IAIEECPUYR.getMaterial());
                // getKeyVersion()
                KeyProvider.KeyVersion BSLSYCBDCU = RFVCJKBNOG.getKeyVersion(IAIEECPUYR.getVersionName());
                Assert.assertEquals(IAIEECPUYR.getVersionName(), BSLSYCBDCU.getVersionName());
                Assert.assertNotNull(BSLSYCBDCU.getMaterial());
                // getCurrent()
                KeyProvider.KeyVersion IDNINTDMRB = RFVCJKBNOG.getCurrentKey("k1");
                Assert.assertEquals(IAIEECPUYR.getVersionName(), IDNINTDMRB.getVersionName());
                Assert.assertNotNull(IDNINTDMRB.getMaterial());
                // getKeyMetadata() 1 version
                KeyProvider.Metadata RDFYJRMUXD = RFVCJKBNOG.getMetadata("k1");
                Assert.assertEquals("AES/CTR/NoPadding", RDFYJRMUXD.getCipher());
                Assert.assertEquals("AES", RDFYJRMUXD.getAlgorithm());
                Assert.assertEquals(128, RDFYJRMUXD.getBitLength());
                Assert.assertEquals(1, RDFYJRMUXD.getVersions());
                Assert.assertNotNull(RDFYJRMUXD.getCreated());
                Assert.assertTrue(DDAAMPONVZ.before(RDFYJRMUXD.getCreated()));
                // getKeyVersions() 1 version
                List<KeyProvider.KeyVersion> OQXXBYTYKQ = RFVCJKBNOG.getKeyVersions("k1");
                Assert.assertEquals(1, OQXXBYTYKQ.size());
                Assert.assertEquals(IAIEECPUYR.getVersionName(), OQXXBYTYKQ.get(0).getVersionName());
                Assert.assertNotNull(BSLSYCBDCU.getMaterial());
                // rollNewVersion()
                KeyProvider.KeyVersion OQNESYTWNI = RFVCJKBNOG.rollNewVersion("k1");
                Assert.assertNotSame(IAIEECPUYR.getVersionName(), OQNESYTWNI.getVersionName());
                Assert.assertNotNull(OQNESYTWNI.getMaterial());
                // getKeyVersion()
                OQNESYTWNI = RFVCJKBNOG.getKeyVersion(OQNESYTWNI.getVersionName());
                boolean BSEIWZBDXU = true;
                for (int CXTFBJXMZQ = 0; CXTFBJXMZQ < BSLSYCBDCU.getMaterial().length; CXTFBJXMZQ++) {
                    BSEIWZBDXU = BSEIWZBDXU && (BSLSYCBDCU.getMaterial()[CXTFBJXMZQ] == OQNESYTWNI.getMaterial()[CXTFBJXMZQ]);
                }
                Assert.assertFalse(BSEIWZBDXU);
                // getCurrent()
                KeyProvider.KeyVersion YIBYUSMPNW = RFVCJKBNOG.getCurrentKey("k1");
                Assert.assertEquals(OQNESYTWNI.getVersionName(), YIBYUSMPNW.getVersionName());
                Assert.assertNotNull(YIBYUSMPNW.getMaterial());
                BSEIWZBDXU = true;
                for (int CZBXFKIBRI = 0; CZBXFKIBRI < BSLSYCBDCU.getMaterial().length; CZBXFKIBRI++) {
                    BSEIWZBDXU = BSEIWZBDXU && (YIBYUSMPNW.getMaterial()[CZBXFKIBRI] == OQNESYTWNI.getMaterial()[CZBXFKIBRI]);
                }
                Assert.assertTrue(BSEIWZBDXU);
                // getKeyVersions() 2 versions
                List<KeyProvider.KeyVersion> FHEVMXKRRS = RFVCJKBNOG.getKeyVersions("k1");
                Assert.assertEquals(2, FHEVMXKRRS.size());
                Assert.assertEquals(BSLSYCBDCU.getVersionName(), FHEVMXKRRS.get(0).getVersionName());
                Assert.assertNotNull(FHEVMXKRRS.get(0).getMaterial());
                Assert.assertEquals(OQNESYTWNI.getVersionName(), FHEVMXKRRS.get(1).getVersionName());
                Assert.assertNotNull(FHEVMXKRRS.get(1).getMaterial());
                // getKeyMetadata() 2 version
                KeyProvider.Metadata WXIPLWSJGV = RFVCJKBNOG.getMetadata("k1");
                Assert.assertEquals("AES/CTR/NoPadding", WXIPLWSJGV.getCipher());
                Assert.assertEquals("AES", WXIPLWSJGV.getAlgorithm());
                Assert.assertEquals(128, WXIPLWSJGV.getBitLength());
                Assert.assertEquals(2, WXIPLWSJGV.getVersions());
                Assert.assertNotNull(WXIPLWSJGV.getCreated());
                Assert.assertTrue(DDAAMPONVZ.before(WXIPLWSJGV.getCreated()));
                // getKeys() 1 key
                List<String> XEMYHDEOPQ = RFVCJKBNOG.getKeys();
                Assert.assertEquals(1, XEMYHDEOPQ.size());
                Assert.assertEquals("k1", XEMYHDEOPQ.get(0));
                // getKeysMetadata() 1 key 2 versions
                KeyProvider[] CKLJBICAQF = RFVCJKBNOG.getKeysMetadata("k1");
                Assert.assertEquals(1, CKLJBICAQF.length);
                Assert.assertEquals("AES/CTR/NoPadding", CKLJBICAQF[0].getCipher());
                Assert.assertEquals("AES", CKLJBICAQF[0].getAlgorithm());
                Assert.assertEquals(128, CKLJBICAQF[0].getBitLength());
                Assert.assertEquals(2, CKLJBICAQF[0].getVersions());
                Assert.assertNotNull(CKLJBICAQF[0].getCreated());
                Assert.assertTrue(DDAAMPONVZ.before(CKLJBICAQF[0].getCreated()));
                // test generate and decryption of EEK
                KeyProvider.KeyVersion SBIKWBZBRF = RFVCJKBNOG.getCurrentKey("k1");
                KeyProviderCryptoExtension DDXKVPABVF = KeyProviderCryptoExtension.createKeyProviderCryptoExtension(RFVCJKBNOG);
                EncryptedKeyVersion HZJBUCNFAF = DDXKVPABVF.generateEncryptedKey(SBIKWBZBRF.getName());
                Assert.assertEquals(EEK, HZJBUCNFAF.getEncryptedKeyVersion().getVersionName());
                Assert.assertNotNull(HZJBUCNFAF.getEncryptedKeyVersion().getMaterial());
                Assert.assertEquals(SBIKWBZBRF.getMaterial().length, HZJBUCNFAF.getEncryptedKeyVersion().getMaterial().length);
                KeyProvider.KeyVersion RLTGSRWSNU = DDXKVPABVF.decryptEncryptedKey(HZJBUCNFAF);
                Assert.assertEquals(EK, RLTGSRWSNU.getVersionName());
                KeyProvider.KeyVersion KDUTNQNPFX = DDXKVPABVF.decryptEncryptedKey(HZJBUCNFAF);
                Assert.assertArrayEquals(RLTGSRWSNU.getMaterial(), KDUTNQNPFX.getMaterial());
                Assert.assertEquals(SBIKWBZBRF.getMaterial().length, RLTGSRWSNU.getMaterial().length);
                EncryptedKeyVersion QFEOUTGHFL = DDXKVPABVF.generateEncryptedKey(SBIKWBZBRF.getName());
                KeyProvider.KeyVersion FWXJZZHANR = DDXKVPABVF.decryptEncryptedKey(QFEOUTGHFL);
                boolean HMHLVUFBOM = true;
                for (int QGZRCXWPFD = 0; HMHLVUFBOM && (QGZRCXWPFD < QFEOUTGHFL.getEncryptedKeyVersion().getMaterial().length); QGZRCXWPFD++) {
                    HMHLVUFBOM = FWXJZZHANR.getMaterial()[QGZRCXWPFD] == RLTGSRWSNU.getMaterial()[QGZRCXWPFD];
                }
                Assert.assertFalse(HMHLVUFBOM);
                // deleteKey()
                RFVCJKBNOG.deleteKey("k1");
                // getKey()
                Assert.assertNull(RFVCJKBNOG.getKeyVersion("k1"));
                // getKeyVersions()
                Assert.assertNull(RFVCJKBNOG.getKeyVersions("k1"));
                // getMetadata()
                Assert.assertNull(RFVCJKBNOG.getMetadata("k1"));
                // getKeys() empty
                Assert.assertTrue(RFVCJKBNOG.getKeys().isEmpty());
                // getKeysMetadata() empty
                Assert.assertEquals(0, RFVCJKBNOG.getKeysMetadata().length);
                // createKey() no description, no tags
                BRYVBWOICP = new KeyProvider.Options(QKFWDWQTGU);
                BRYVBWOICP.setCipher("AES/CTR/NoPadding");
                BRYVBWOICP.setBitLength(128);
                RFVCJKBNOG.createKey("k2", BRYVBWOICP);
                KeyProvider.Metadata LOLCEHIRNU = RFVCJKBNOG.getMetadata("k2");
                Assert.assertNull(LOLCEHIRNU.getDescription());
                Assert.assertTrue(LOLCEHIRNU.getAttributes().isEmpty());
                // createKey() description, no tags
                BRYVBWOICP = new KeyProvider.Options(QKFWDWQTGU);
                BRYVBWOICP.setCipher("AES/CTR/NoPadding");
                BRYVBWOICP.setBitLength(128);
                BRYVBWOICP.setDescription("d");
                RFVCJKBNOG.createKey("k3", BRYVBWOICP);
                LOLCEHIRNU = RFVCJKBNOG.getMetadata("k3");
                Assert.assertEquals("d", LOLCEHIRNU.getDescription());
                Assert.assertTrue(LOLCEHIRNU.getAttributes().isEmpty());
                Map<String, String> WEHQKZOMJB = new HashMap<String, String>();
                WEHQKZOMJB.put("a", "A");
                // createKey() no description, tags
                BRYVBWOICP = new KeyProvider.Options(QKFWDWQTGU);
                BRYVBWOICP.setCipher("AES/CTR/NoPadding");
                BRYVBWOICP.setBitLength(128);
                BRYVBWOICP.setAttributes(WEHQKZOMJB);
                RFVCJKBNOG.createKey("k4", BRYVBWOICP);
                LOLCEHIRNU = RFVCJKBNOG.getMetadata("k4");
                Assert.assertNull(LOLCEHIRNU.getDescription());
                Assert.assertEquals(WEHQKZOMJB, LOLCEHIRNU.getAttributes());
                // createKey() description, tags
                BRYVBWOICP = new KeyProvider.Options(QKFWDWQTGU);
                BRYVBWOICP.setCipher("AES/CTR/NoPadding");
                BRYVBWOICP.setBitLength(128);
                BRYVBWOICP.setDescription("d");
                BRYVBWOICP.setAttributes(WEHQKZOMJB);
                RFVCJKBNOG.createKey("k5", BRYVBWOICP);
                LOLCEHIRNU = RFVCJKBNOG.getMetadata("k5");
                Assert.assertEquals("d", LOLCEHIRNU.getDescription());
                Assert.assertEquals(WEHQKZOMJB, LOLCEHIRNU.getAttributes());
                KeyProviderDelegationTokenExtension PLEZEODPYD = KeyProviderDelegationTokenExtension.createKeyProviderDelegationTokenExtension(RFVCJKBNOG);
                Credentials KJOYGQQQXT = new Credentials();
                PLEZEODPYD.addDelegationTokens("foo", KJOYGQQQXT);
                Assert.assertEquals(1, KJOYGQQQXT.getAllTokens().size());
                InetSocketAddress BXCNVPMCMU = new InetSocketAddress(getKMSUrl().getHost(), getKMSUrl().getPort());
                Assert.assertEquals(new Text("kms-dt"), KJOYGQQQXT.getToken(org.apache.hadoop.security.SecurityUtil.buildTokenService(BXCNVPMCMU)).getKind());
                return null;
            }
        });
    }

    @Test
    public void testACLs() throws Exception {
        Configuration RVFRJDYFYC = new Configuration();
        RVFRJDYFYC.set("hadoop.security.authentication", "kerberos");
        UserGroupInformation.setConfiguration(RVFRJDYFYC);
        final File IVNPHDMILY = TestKMS.getTestDir();
        RVFRJDYFYC = createBaseKMSConf(IVNPHDMILY);
        RVFRJDYFYC.set("hadoop.kms.authentication.type", "kerberos");
        RVFRJDYFYC.set("hadoop.kms.authentication.kerberos.keytab", TestKMS.HRZIHQZIEP.getAbsolutePath());
        RVFRJDYFYC.set("hadoop.kms.authentication.kerberos.principal", "HTTP/localhost");
        RVFRJDYFYC.set("hadoop.kms.authentication.kerberos.name.rules", "DEFAULT");
        for (KMSACLs.Type YBIPTMIXWP : Type.values()) {
            RVFRJDYFYC.set(YBIPTMIXWP.getConfigKey(), YBIPTMIXWP.toString());
        }
        RVFRJDYFYC.set(CREATE.getConfigKey(), CREATE.toString() + ",SET_KEY_MATERIAL");
        RVFRJDYFYC.set(ROLLOVER.getConfigKey(), ROLLOVER.toString() + ",SET_KEY_MATERIAL");
        writeConf(IVNPHDMILY, RVFRJDYFYC);
        runServer(null, null, IVNPHDMILY, new TestKMS.KMSCallable() {
            @Override
            public Void call() throws Exception {
                final Configuration RZIOFAYHMB = new Configuration();
                RZIOFAYHMB.setInt(DEFAULT_BITLENGTH_NAME, 128);
                final URI YIJFPAGCJZ = createKMSUri(getKMSUrl());
                // nothing allowed
                doAs("client", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider ZXAMAHRTPU = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            ZXAMAHRTPU.createKey("k", new KeyProvider.Options(RZIOFAYHMB));
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            ZXAMAHRTPU.createKey("k", new byte[16], new KeyProvider.Options(RZIOFAYHMB));
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            ZXAMAHRTPU.rollNewVersion("k");
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            ZXAMAHRTPU.rollNewVersion("k", new byte[16]);
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            ZXAMAHRTPU.getKeys();
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            ZXAMAHRTPU.getKeysMetadata("k");
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            // we are using JavaKeyStoreProvider for testing, so we know how
                            // the keyversion is created.
                            ZXAMAHRTPU.getKeyVersion("k@0");
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            ZXAMAHRTPU.getCurrentKey("k");
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            ZXAMAHRTPU.getMetadata("k");
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        try {
                            ZXAMAHRTPU.getKeyVersions("k");
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                doAs("CREATE", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider SERHZTUKNG = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            KeyProvider.KeyVersion EWEJKZCOME = SERHZTUKNG.createKey("k0", new KeyProvider.Options(RZIOFAYHMB));
                            Assert.assertNull(EWEJKZCOME.getMaterial());
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                doAs("DELETE", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider KTKGMGZDZQ = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            KTKGMGZDZQ.deleteKey("k0");
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                doAs("SET_KEY_MATERIAL", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider THMCZKSWRY = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            KeyProvider.KeyVersion MXENUXGDIN = THMCZKSWRY.createKey("k1", new byte[16], new KeyProvider.Options(RZIOFAYHMB));
                            Assert.assertNull(MXENUXGDIN.getMaterial());
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                doAs("ROLLOVER", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider IJNMTYRANC = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            KeyProvider.KeyVersion SLDOXTNUAE = IJNMTYRANC.rollNewVersion("k1");
                            Assert.assertNull(SLDOXTNUAE.getMaterial());
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                doAs("SET_KEY_MATERIAL", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider TUDWYUKUGI = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            KeyProvider.KeyVersion FBIURNYGYT = TUDWYUKUGI.rollNewVersion("k1", new byte[16]);
                            Assert.assertNull(FBIURNYGYT.getMaterial());
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                final KeyVersion NCHDHJOJWS = doAs("GET", new PrivilegedExceptionAction<KeyVersion>() {
                    @Override
                    public KeyVersion run() throws Exception {
                        KeyProvider HVPJZUQYIN = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            HVPJZUQYIN.getKeyVersion("k1@0");
                            KeyVersion HSDELUHZAB = HVPJZUQYIN.getCurrentKey("k1");
                            return HSDELUHZAB;
                        } catch (Exception ex) {
                            Assert.fail(ex.toString());
                        }
                        return null;
                    }
                });
                final EncryptedKeyVersion YULWPVMQHZ = doAs("GENERATE_EEK", new PrivilegedExceptionAction<EncryptedKeyVersion>() {
                    @Override
                    public EncryptedKeyVersion run() throws Exception {
                        KeyProvider REPRFKBHDL = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            KeyProviderCryptoExtension EKZIIVVSAX = KeyProviderCryptoExtension.createKeyProviderCryptoExtension(REPRFKBHDL);
                            EncryptedKeyVersion ZHKBKYYXDW = EKZIIVVSAX.generateEncryptedKey(NCHDHJOJWS.getName());
                            return ZHKBKYYXDW;
                        } catch (Exception ex) {
                            Assert.fail(ex.toString());
                        }
                        return null;
                    }
                });
                doAs("DECRYPT_EEK", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider QSASRPPHQH = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            KeyProviderCryptoExtension EGDMWPABDB = KeyProviderCryptoExtension.createKeyProviderCryptoExtension(QSASRPPHQH);
                            EGDMWPABDB.decryptEncryptedKey(YULWPVMQHZ);
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                doAs("GET_KEYS", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider EISLGMFZII = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            EISLGMFZII.getKeys();
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                doAs("GET_METADATA", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider FZHZMTCVAF = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                        try {
                            FZHZMTCVAF.getMetadata("k1");
                            FZHZMTCVAF.getKeysMetadata("k1");
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                // stop the reloader, to avoid running while we are writing the new file
                KMSWebApp.getACLs().stopReloader();
                // test ACL reloading
                Thread.sleep(10);// to ensure the ACLs file modifiedTime is newer

                RZIOFAYHMB.set(CREATE.getConfigKey(), "foo");
                writeConf(IVNPHDMILY, RZIOFAYHMB);
                Thread.sleep(1000);
                KMSWebApp.getACLs().run();// forcing a reload by hand.

                // should not be able to create a key now
                doAs("CREATE", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        try {
                            KeyProvider MFWYFHFLHQ = new KMSClientProvider(YIJFPAGCJZ, RZIOFAYHMB);
                            KeyProvider.KeyVersion QAXZESQIBZ = MFWYFHFLHQ.createKey("k2", new KeyProvider.Options(RZIOFAYHMB));
                            Assert.fail();
                        } catch (AuthorizationException ex) {
                            // NOP
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                return null;
            }
        });
    }

    @Test
    public void testServicePrincipalACLs() throws Exception {
        Configuration ZSVUXBJWJL = new Configuration();
        ZSVUXBJWJL.set("hadoop.security.authentication", "kerberos");
        UserGroupInformation.setConfiguration(ZSVUXBJWJL);
        File DDBFGMILWI = TestKMS.getTestDir();
        ZSVUXBJWJL = createBaseKMSConf(DDBFGMILWI);
        ZSVUXBJWJL.set("hadoop.kms.authentication.type", "kerberos");
        ZSVUXBJWJL.set("hadoop.kms.authentication.kerberos.keytab", TestKMS.HRZIHQZIEP.getAbsolutePath());
        ZSVUXBJWJL.set("hadoop.kms.authentication.kerberos.principal", "HTTP/localhost");
        ZSVUXBJWJL.set("hadoop.kms.authentication.kerberos.name.rules", "DEFAULT");
        for (KMSACLs.Type LEHOMRIVJW : Type.values()) {
            ZSVUXBJWJL.set(LEHOMRIVJW.getConfigKey(), " ");
        }
        ZSVUXBJWJL.set(CREATE.getConfigKey(), "client");
        writeConf(DDBFGMILWI, ZSVUXBJWJL);
        runServer(null, null, DDBFGMILWI, new TestKMS.KMSCallable() {
            @Override
            public Void call() throws Exception {
                final Configuration ATOMPTLHLT = new Configuration();
                ATOMPTLHLT.setInt(DEFAULT_BITLENGTH_NAME, 128);
                ATOMPTLHLT.setInt(DEFAULT_BITLENGTH_NAME, 64);
                final URI XPEOLZIXKD = createKMSUri(getKMSUrl());
                doAs("client", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        try {
                            KeyProvider TMMTNLZQBK = new KMSClientProvider(XPEOLZIXKD, ATOMPTLHLT);
                            KeyProvider.KeyVersion RUONJLYARN = TMMTNLZQBK.createKey("ck0", new KeyProvider.Options(ATOMPTLHLT));
                            Assert.assertNull(RUONJLYARN.getMaterial());
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                doAs("client/host", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        try {
                            KeyProvider USESPIHIOO = new KMSClientProvider(XPEOLZIXKD, ATOMPTLHLT);
                            KeyProvider.KeyVersion PFGTRBXWTN = USESPIHIOO.createKey("ck1", new KeyProvider.Options(ATOMPTLHLT));
                            Assert.assertNull(PFGTRBXWTN.getMaterial());
                        } catch (Exception ex) {
                            Assert.fail(ex.getMessage());
                        }
                        return null;
                    }
                });
                return null;
            }
        });
    }

    /**
     * Test the configurable timeout in the KMSClientProvider.  Open up a
     * socket, but don't accept connections for it.  This leads to a timeout
     * when the KMS client attempts to connect.
     *
     * @throws Exception
     * 		
     */
    @Test
    public void testKMSTimeout() throws Exception {
        File FLVNNORCAM = TestKMS.getTestDir();
        Configuration TLCJCNQHAH = createBaseKMSConf(FLVNNORCAM);
        TLCJCNQHAH.setInt(TIMEOUT_ATTR, 1);
        writeConf(FLVNNORCAM, TLCJCNQHAH);
        ServerSocket QTOMDMHBFF;
        int QEYSOVBJCW;
        try {
            QTOMDMHBFF = new ServerSocket(0, 50, InetAddress.getByName("localhost"));
            QEYSOVBJCW = QTOMDMHBFF.getLocalPort();
        } catch (Exception e) {
            /* Problem creating socket?  Just bail. */
            return;
        }
        URL TIKROXYTLM = new URL(("http://localhost:" + QEYSOVBJCW) + "/kms");
        URI CZOFDZJCGM = createKMSUri(TIKROXYTLM);
        boolean VJXOAVTFXP = false;
        try {
            KeyProvider USOJNORTTT = new KMSClientProvider(CZOFDZJCGM, TLCJCNQHAH);
            USOJNORTTT.getKeys();
        } catch (SocketTimeoutException e) {
            VJXOAVTFXP = true;
        } catch (IOException e) {
            Assert.assertTrue("Caught unexpected exception" + e.toString(), false);
        }
        VJXOAVTFXP = false;
        try {
            KeyProvider XCKDUFQIRK = new KMSClientProvider(CZOFDZJCGM, TLCJCNQHAH);
            KeyProviderCryptoExtension.createKeyProviderCryptoExtension(XCKDUFQIRK).generateEncryptedKey("a");
        } catch (SocketTimeoutException e) {
            VJXOAVTFXP = true;
        } catch (IOException e) {
            Assert.assertTrue("Caught unexpected exception" + e.toString(), false);
        }
        VJXOAVTFXP = false;
        try {
            KeyProvider TWXDLWSHVA = new KMSClientProvider(CZOFDZJCGM, TLCJCNQHAH);
            KeyProviderCryptoExtension.createKeyProviderCryptoExtension(TWXDLWSHVA).decryptEncryptedKey(new KMSClientProvider.KMSEncryptedKeyVersion("a", "a", new byte[]{ 1, 2 }, "EEK", new byte[]{ 1, 2 }));
        } catch (SocketTimeoutException e) {
            VJXOAVTFXP = true;
        } catch (IOException e) {
            Assert.assertTrue("Caught unexpected exception" + e.toString(), false);
        }
        Assert.assertTrue(VJXOAVTFXP);
        QTOMDMHBFF.close();
    }

    @Test
    public void testDelegationTokenAccess() throws Exception {
        Configuration WGAGYIWBDO = new Configuration();
        WGAGYIWBDO.set("hadoop.security.authentication", "kerberos");
        UserGroupInformation.setConfiguration(WGAGYIWBDO);
        final File GWAYDOAJYD = TestKMS.getTestDir();
        WGAGYIWBDO = createBaseKMSConf(GWAYDOAJYD);
        WGAGYIWBDO.set("hadoop.kms.authentication.type", "kerberos");
        WGAGYIWBDO.set("hadoop.kms.authentication.kerberos.keytab", TestKMS.HRZIHQZIEP.getAbsolutePath());
        WGAGYIWBDO.set("hadoop.kms.authentication.kerberos.principal", "HTTP/localhost");
        WGAGYIWBDO.set("hadoop.kms.authentication.kerberos.name.rules", "DEFAULT");
        writeConf(GWAYDOAJYD, WGAGYIWBDO);
        runServer(null, null, GWAYDOAJYD, new TestKMS.KMSCallable() {
            @Override
            public Void call() throws Exception {
                final Configuration YTKZDDUALE = new Configuration();
                YTKZDDUALE.setInt(DEFAULT_BITLENGTH_NAME, 64);
                final URI CHSYFRGCTQ = createKMSUri(getKMSUrl());
                final Credentials GADBCOQENK = new Credentials();
                final UserGroupInformation OVNAQNGKHN = UserGroupInformation.getCurrentUser();
                try {
                    KeyProvider EANJUVEFCS = new KMSClientProvider(CHSYFRGCTQ, YTKZDDUALE);
                    EANJUVEFCS.createKey("kA", new KeyProvider.Options(YTKZDDUALE));
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
                doAs("client", new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider XQJLKATSWC = new KMSClientProvider(CHSYFRGCTQ, YTKZDDUALE);
                        KeyProviderDelegationTokenExtension FKVDYUJMOI = KeyProviderDelegationTokenExtension.createKeyProviderDelegationTokenExtension(XQJLKATSWC);
                        FKVDYUJMOI.addDelegationTokens("foo", GADBCOQENK);
                        return null;
                    }
                });
                OVNAQNGKHN.addCredentials(GADBCOQENK);
                try {
                    KeyProvider OIRMSZIUJU = new KMSClientProvider(CHSYFRGCTQ, YTKZDDUALE);
                    OIRMSZIUJU.createKey("kA", new KeyProvider.Options(YTKZDDUALE));
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
                OVNAQNGKHN.doAs(new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        KeyProvider GBFTEPYIHY = new KMSClientProvider(CHSYFRGCTQ, YTKZDDUALE);
                        GBFTEPYIHY.createKey("kD", new KeyProvider.Options(YTKZDDUALE));
                        return null;
                    }
                });
                return null;
            }
        });
    }

    @Test
    public void testProxyUser() throws Exception {
        Configuration IFCIBLPKAY = new Configuration();
        IFCIBLPKAY.set("hadoop.security.authentication", "kerberos");
        UserGroupInformation.setConfiguration(IFCIBLPKAY);
        final File STDKHQEUUM = TestKMS.getTestDir();
        IFCIBLPKAY = createBaseKMSConf(STDKHQEUUM);
        IFCIBLPKAY.set("hadoop.kms.authentication.type", "kerberos");
        IFCIBLPKAY.set("hadoop.kms.authentication.kerberos.keytab", TestKMS.HRZIHQZIEP.getAbsolutePath());
        IFCIBLPKAY.set("hadoop.kms.authentication.kerberos.principal", "HTTP/localhost");
        IFCIBLPKAY.set("hadoop.kms.authentication.kerberos.name.rules", "DEFAULT");
        IFCIBLPKAY.set("hadoop.kms.proxyuser.client.users", "foo");
        IFCIBLPKAY.set("hadoop.kms.proxyuser.client.hosts", "*");
        writeConf(STDKHQEUUM, IFCIBLPKAY);
        runServer(null, null, STDKHQEUUM, new TestKMS.KMSCallable() {
            @Override
            public Void call() throws Exception {
                final Configuration RPTWMYQIBD = new Configuration();
                RPTWMYQIBD.setInt(DEFAULT_BITLENGTH_NAME, 64);
                final URI VGKZSPQFVE = createKMSUri(getKMSUrl());
                // proxyuser client using kerberos credentials
                UserGroupInformation YULUHOBDZZ = UserGroupInformation.loginUserFromKeytabAndReturnUGI("client", TestKMS.HRZIHQZIEP.getAbsolutePath());
                YULUHOBDZZ.doAs(new PrivilegedExceptionAction<Void>() {
                    @Override
                    public Void run() throws Exception {
                        final KeyProvider TEKMBYHGCN = new KMSClientProvider(VGKZSPQFVE, RPTWMYQIBD);
                        TEKMBYHGCN.createKey("kAA", new KeyProvider.Options(RPTWMYQIBD));
                        // authorized proxyuser
                        UserGroupInformation VMTXXGKTBT = UserGroupInformation.createRemoteUser("foo");
                        VMTXXGKTBT.doAs(new PrivilegedExceptionAction<Void>() {
                            @Override
                            public Void run() throws Exception {
                                Assert.assertNotNull(TEKMBYHGCN.createKey("kBB", new KeyProvider.Options(RPTWMYQIBD)));
                                return null;
                            }
                        });
                        // unauthorized proxyuser
                        UserGroupInformation YYYREPSDQO = UserGroupInformation.createRemoteUser("foo1");
                        YYYREPSDQO.doAs(new PrivilegedExceptionAction<Void>() {
                            @Override
                            public Void run() throws Exception {
                                try {
                                    TEKMBYHGCN.createKey("kCC", new KeyProvider.Options(RPTWMYQIBD));
                                    Assert.fail();
                                } catch (AuthorizationException ex) {
                                    // OK
                                } catch (Exception ex) {
                                    Assert.fail(ex.getMessage());
                                }
                                return null;
                            }
                        });
                        return null;
                    }
                });
                return null;
            }
        });
    }
}