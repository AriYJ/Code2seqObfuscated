/**
 * Exception thrown to indicate that an operation performed
 * to modify the state of a service or application failed.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class ServiceFailedException extends IOException {
    private static final long JEKBGIWIDV = 1L;

    public ServiceFailedException(final String RMTNKXOVPZ) {
        super(RMTNKXOVPZ);
    }

    public ServiceFailedException(String AXZQVXDASE, Throwable WKTFWWHLBQ) {
        super(AXZQVXDASE, WKTFWWHLBQ);
    }
}