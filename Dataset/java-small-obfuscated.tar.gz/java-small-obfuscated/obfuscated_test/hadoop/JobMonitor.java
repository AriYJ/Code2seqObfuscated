/**
 * Component accepting submitted, running {@link Statistics.JobStats} and
 * responsible for monitoring jobs for success and failure. Once a job is
 * submitted, it is polled for status until complete. If a job is complete,
 * then the monitor thread returns immediately to the queue. If not, the monitor
 * will sleep for some duration.
 *
 * {@link JobMonitor} can be configured to use multiple threads for polling
 * the job statuses. Use {@link Gridmix#GRIDMIX_JOBMONITOR_THREADS} to specify
 * the total number of monitoring threads.
 *
 * The duration for which a monitoring thread sleeps if the first job in the
 * queue is running can also be configured. Use
 * {@link Gridmix#GRIDMIX_JOBMONITOR_SLEEPTIME_MILLIS} to specify a custom
 * value.
 */
class JobMonitor implements Gridmix.Component<JobStats> {
    public static final Log XQDXKGLSEQ = LogFactory.getLog(JobMonitor.class);

    private final Queue<JobStats> KIKLSPOJWF;

    private ExecutorService GEJKEHOYZM;

    private int TFQCBSLPQJ;

    private final BlockingQueue<JobStats> ENQAZPYWDI;

    private final long IOFERIZBMQ;

    private Statistics GMDWQLEQFY;

    private boolean BSYYBVQOUE = false;

    private boolean DAGLLPWQZK = false;

    /**
     * Create a JobMonitor that sleeps for the specified duration after
     * polling a still-running job.
     *
     * @param pollDelay
     * 		Delay after polling a running job
     * @param unit
     * 		Time unit for pollDelaySec (rounded to milliseconds)
     * @param statistics
     * 		StatCollector , listener to job completion.
     */
    public JobMonitor(int KMPATUAIVW, TimeUnit NOJPOEYKMG, Statistics VYZMSWQKJO, int KWWGFOFVXL) {
        GEJKEHOYZM = Executors.newCachedThreadPool();
        this.TFQCBSLPQJ = KWWGFOFVXL;
        ENQAZPYWDI = new LinkedBlockingQueue<JobStats>();
        KIKLSPOJWF = new LinkedList<JobStats>();
        this.IOFERIZBMQ = TimeUnit.MILLISECONDS.convert(KMPATUAIVW, NOJPOEYKMG);
        this.GMDWQLEQFY = VYZMSWQKJO;
    }

    /**
     * Add a running job's status to the polling queue.
     */
    public void add(JobStats ZWPZERAALI) throws InterruptedException {
        ENQAZPYWDI.put(ZWPZERAALI);
    }

    /**
     * Add a submission failed job's status, such that it can be communicated
     * back to serial.
     * TODO: Cleaner solution for this problem
     *
     * @param job
     * 		
     */
    public void submissionFailed(JobStats ONVIOZJGIW) {
        String OOFLBDREHS = ONVIOZJGIW.getJob().getConfiguration().get(Gridmix.ORIGINAL_JOB_ID);
        JobMonitor.XQDXKGLSEQ.info("Job submission failed notification for job " + OOFLBDREHS);
        synchronized(GMDWQLEQFY) {
            this.GMDWQLEQFY.add(ONVIOZJGIW);
        }
    }

    /**
     * Temporary hook for recording job success.
     */
    protected void onSuccess(Job IZMTMTVZBX) {
        JobMonitor.XQDXKGLSEQ.info((((IZMTMTVZBX.getJobName() + " (") + IZMTMTVZBX.getJobID()) + ")") + " success");
    }

    /**
     * Temporary hook for recording job failure.
     */
    protected void onFailure(Job VXFAHQKUXK) {
        JobMonitor.XQDXKGLSEQ.info((((VXFAHQKUXK.getJobName() + " (") + VXFAHQKUXK.getJobID()) + ")") + " failure");
    }

    /**
     * If shutdown before all jobs have completed, any still-running jobs
     * may be extracted from the component.
     *
     * @throws IllegalStateException
     * 		If monitoring thread is still running.
     * @return Any jobs submitted and not known to have completed.
     */
    List<JobStats> getRemainingJobs() {
        synchronized(KIKLSPOJWF) {
            return new ArrayList<JobStats>(KIKLSPOJWF);
        }
    }

    /**
     * Monitoring thread pulling running jobs from the component and into
     * a queue to be polled for status.
     */
    private class MonitorThread extends Thread {
        public MonitorThread(int i) {
            super("GridmixJobMonitor-" + i);
        }

        @Override
        public void run() {
            boolean graceful;
            boolean shutdown;
            while (true) {
                try {
                    synchronized(KIKLSPOJWF) {
                        graceful = JobMonitor.this.BSYYBVQOUE;
                        shutdown = JobMonitor.this.DAGLLPWQZK;
                        ENQAZPYWDI.drainTo(KIKLSPOJWF);
                    }
                    // shutdown conditions; either shutdown requested and all jobs
                    // have completed or abort requested and there are recently
                    // submitted jobs not in the monitored set
                    if (shutdown) {
                        if (!graceful) {
                            while (!ENQAZPYWDI.isEmpty()) {
                                synchronized(KIKLSPOJWF) {
                                    ENQAZPYWDI.drainTo(KIKLSPOJWF);
                                }
                            } 
                            break;
                        }
                        synchronized(KIKLSPOJWF) {
                            if (graceful && KIKLSPOJWF.isEmpty()) {
                                break;
                            }
                        }
                    }
                    JobStats jobStats = null;
                    synchronized(KIKLSPOJWF) {
                        jobStats = KIKLSPOJWF.poll();
                    }
                    while (jobStats != null) {
                        Job job = jobStats.getJob();
                        try {
                            // get the job status
                            long start = System.currentTimeMillis();
                            JobStatus status = job.getStatus();// cache the job status

                            long end = System.currentTimeMillis();
                            if (JobMonitor.XQDXKGLSEQ.isDebugEnabled()) {
                                JobMonitor.XQDXKGLSEQ.debug(((("Status polling for job " + job.getJobID()) + " took ") + (end - start)) + "ms.");
                            }
                            // update the job progress
                            jobStats.updateJobStatus(status);
                            // if the job is complete, let others know
                            if (status.isJobComplete()) {
                                if (status.getState() == State.SUCCEEDED) {
                                    onSuccess(job);
                                } else {
                                    onFailure(job);
                                }
                                synchronized(GMDWQLEQFY) {
                                    GMDWQLEQFY.add(jobStats);
                                }
                            } else {
                                // add the running job back and break
                                synchronized(KIKLSPOJWF) {
                                    if (!KIKLSPOJWF.offer(jobStats)) {
                                        JobMonitor.XQDXKGLSEQ.error("Lost job " + (null == job.getJobName() ? "<unknown>" : job.getJobName()));// should never

                                        // happen
                                    }
                                }
                                break;
                            }
                        } catch (IOException e) {
                            if (e.getCause() instanceof ClosedByInterruptException) {
                                // Job doesn't throw InterruptedException, but RPC socket layer
                                // is blocking and may throw a wrapped Exception if this thread
                                // is interrupted. Since the lower level cleared the flag,
                                // reset it here
                                Thread.currentThread().interrupt();
                            } else {
                                JobMonitor.XQDXKGLSEQ.warn("Lost job " + (null == job.getJobName() ? "<unknown>" : job.getJobName()), e);
                                synchronized(GMDWQLEQFY) {
                                    GMDWQLEQFY.add(jobStats);
                                }
                            }
                        }
                        // get the next job
                        synchronized(KIKLSPOJWF) {
                            jobStats = KIKLSPOJWF.poll();
                        }
                    } 
                    // sleep for a while before checking again
                    try {
                        TimeUnit.MILLISECONDS.sleep(IOFERIZBMQ);
                    } catch (InterruptedException e) {
                        shutdown = true;
                        continue;
                    }
                } catch (Throwable e) {
                    JobMonitor.XQDXKGLSEQ.warn("Unexpected exception: ", e);
                }
            } 
        }
    }

    /**
     * Start the internal, monitoring thread.
     */
    public void start() {
        for (int PDKYGGQBMW = 0; PDKYGGQBMW < TFQCBSLPQJ; ++PDKYGGQBMW) {
            GEJKEHOYZM.execute(new JobMonitor.MonitorThread(PDKYGGQBMW));
        }
    }

    /**
     * Wait for the monitor to halt, assuming shutdown or abort have been
     * called. Note that, since submission may be sporatic, this will hang
     * if no form of shutdown has been requested.
     */
    public void join(long EVFRIOENKP) throws InterruptedException {
        GEJKEHOYZM.awaitTermination(EVFRIOENKP, TimeUnit.MILLISECONDS);
    }

    /**
     * Drain all submitted jobs to a queue and stop the monitoring thread.
     * Upstream submitter is assumed dead.
     */
    public void abort() {
        synchronized(KIKLSPOJWF) {
            BSYYBVQOUE = false;
            DAGLLPWQZK = true;
        }
        GEJKEHOYZM.shutdown();
    }

    /**
     * When all monitored jobs have completed, stop the monitoring thread.
     * Upstream submitter is assumed dead.
     */
    public void shutdown() {
        synchronized(KIKLSPOJWF) {
            BSYYBVQOUE = true;
            DAGLLPWQZK = true;
        }
        GEJKEHOYZM.shutdown();
    }
}