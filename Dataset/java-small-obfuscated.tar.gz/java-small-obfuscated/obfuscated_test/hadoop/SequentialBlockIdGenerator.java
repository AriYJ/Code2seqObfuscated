/**
 * Generate the next valid block ID by incrementing the maximum block
 * ID allocated so far, starting at 2^30+1.
 *
 * Block IDs used to be allocated randomly in the past. Hence we may
 * find some conflicts while stepping through the ID space sequentially.
 * However given the sparsity of the ID space, conflicts should be rare
 * and can be skipped over when detected.
 */
@InterfaceAudience.Private
public class SequentialBlockIdGenerator extends SequentialNumber {
    /**
     * The last reserved block ID.
     */
    public static final long EQIRIWPXME = (1024L * 1024) * 1024;

    private final BlockManager TBWHBINGKD;

    SequentialBlockIdGenerator(BlockManager XXCPPSQMOI) {
        super(SequentialBlockIdGenerator.EQIRIWPXME);
        this.TBWHBINGKD = XXCPPSQMOI;
    }

    // NumberGenerator
    @Override
    public long nextValue() {
        Block JKGEBPVZVB = new Block(super.nextValue());
        // There may be an occasional conflict with randomly generated
        // block IDs. Skip over the conflicts.
        while (isValidBlock(JKGEBPVZVB)) {
            JKGEBPVZVB.setBlockId(super.nextValue());
        } 
        return JKGEBPVZVB.getBlockId();
    }

    /**
     * Returns whether the given block is one pointed-to by a file.
     */
    private boolean isValidBlock(Block YGRZNXPNWD) {
        return TBWHBINGKD.getBlockCollection(YGRZNXPNWD) != null;
    }
}