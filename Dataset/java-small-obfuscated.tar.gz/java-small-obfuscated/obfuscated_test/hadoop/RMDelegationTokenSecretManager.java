/**
 * A ResourceManager specific delegation token secret manager.
 * The secret manager is responsible for generating and accepting the password
 * for each token.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class RMDelegationTokenSecretManager extends AbstractDelegationTokenSecretManager<RMDelegationTokenIdentifier> implements Recoverable {
    private static final Log MPXJUQRPUM = LogFactory.getLog(RMDelegationTokenSecretManager.class);

    protected final RMContext HZASVSFWII;

    /**
     * Create a secret manager
     *
     * @param delegationKeyUpdateInterval
     * 		the number of seconds for rolling new
     * 		secret keys.
     * @param delegationTokenMaxLifetime
     * 		the maximum lifetime of the delegation
     * 		tokens
     * @param delegationTokenRenewInterval
     * 		how often the tokens must be renewed
     * @param delegationTokenRemoverScanInterval
     * 		how often the tokens are scanned
     * 		for expired tokens
     */
    public RMDelegationTokenSecretManager(long OYPVJCXZLA, long KOVAOUIJLZ, long LXIXJILQCM, long SWDVAINJYD, RMContext NGKKZMSSUY) {
        super(OYPVJCXZLA, KOVAOUIJLZ, LXIXJILQCM, SWDVAINJYD);
        this.HZASVSFWII = NGKKZMSSUY;
    }

    @Override
    public RMDelegationTokenIdentifier createIdentifier() {
        return new RMDelegationTokenIdentifier();
    }

    @Override
    protected void storeNewMasterKey(DelegationKey GHIBGLVGDV) {
        try {
            RMDelegationTokenSecretManager.MPXJUQRPUM.info("storing master key with keyID " + GHIBGLVGDV.getKeyId());
            HZASVSFWII.getStateStore().storeRMDTMasterKey(GHIBGLVGDV);
        } catch (Exception e) {
            RMDelegationTokenSecretManager.MPXJUQRPUM.error("Error in storing master key with KeyID: " + GHIBGLVGDV.getKeyId());
            ExitUtil.terminate(1, e);
        }
    }

    @Override
    protected void removeStoredMasterKey(DelegationKey IRMOLLDGNC) {
        try {
            RMDelegationTokenSecretManager.MPXJUQRPUM.info("removing master key with keyID " + IRMOLLDGNC.getKeyId());
            HZASVSFWII.getStateStore().removeRMDTMasterKey(IRMOLLDGNC);
        } catch (Exception e) {
            RMDelegationTokenSecretManager.MPXJUQRPUM.error("Error in removing master key with KeyID: " + IRMOLLDGNC.getKeyId());
            ExitUtil.terminate(1, e);
        }
    }

    @Override
    protected void storeNewToken(RMDelegationTokenIdentifier MADQDTBNXO, long PQAZWHBISE) {
        try {
            RMDelegationTokenSecretManager.MPXJUQRPUM.info("storing RMDelegation token with sequence number: " + MADQDTBNXO.getSequenceNumber());
            HZASVSFWII.getStateStore().storeRMDelegationTokenAndSequenceNumber(MADQDTBNXO, PQAZWHBISE, MADQDTBNXO.getSequenceNumber());
        } catch (Exception e) {
            RMDelegationTokenSecretManager.MPXJUQRPUM.error("Error in storing RMDelegationToken with sequence number: " + MADQDTBNXO.getSequenceNumber());
            ExitUtil.terminate(1, e);
        }
    }

    @Override
    protected void updateStoredToken(RMDelegationTokenIdentifier DRLFBBCMXK, long BZOFLDKYQE) {
        try {
            RMDelegationTokenSecretManager.MPXJUQRPUM.info("updating RMDelegation token with sequence number: " + DRLFBBCMXK.getSequenceNumber());
            HZASVSFWII.getStateStore().updateRMDelegationTokenAndSequenceNumber(DRLFBBCMXK, BZOFLDKYQE, DRLFBBCMXK.getSequenceNumber());
        } catch (Exception e) {
            RMDelegationTokenSecretManager.MPXJUQRPUM.error("Error in updating persisted RMDelegationToken with sequence number: " + DRLFBBCMXK.getSequenceNumber());
            ExitUtil.terminate(1, e);
        }
    }

    @Override
    protected void removeStoredToken(RMDelegationTokenIdentifier CDYOBNFSJW) throws IOException {
        try {
            RMDelegationTokenSecretManager.MPXJUQRPUM.info("removing RMDelegation token with sequence number: " + CDYOBNFSJW.getSequenceNumber());
            HZASVSFWII.getStateStore().removeRMDelegationToken(CDYOBNFSJW, delegationTokenSequenceNumber);
        } catch (Exception e) {
            RMDelegationTokenSecretManager.MPXJUQRPUM.error("Error in removing RMDelegationToken with sequence number: " + CDYOBNFSJW.getSequenceNumber());
            ExitUtil.terminate(1, e);
        }
    }

    @Private
    @VisibleForTesting
    public synchronized Set<DelegationKey> getAllMasterKeys() {
        HashSet<DelegationKey> XIESSMVTLY = new HashSet<DelegationKey>();
        XIESSMVTLY.addAll(allKeys.values());
        return XIESSMVTLY;
    }

    @Private
    @VisibleForTesting
    public synchronized Map<RMDelegationTokenIdentifier, Long> getAllTokens() {
        Map<RMDelegationTokenIdentifier, Long> LAAXRCNYVE = new HashMap<RMDelegationTokenIdentifier, Long>();
        for (Map.Entry<RMDelegationTokenIdentifier, DelegationTokenInformation> YUSCVZYCDL : currentTokens.entrySet()) {
            LAAXRCNYVE.put(YUSCVZYCDL.getKey(), YUSCVZYCDL.getValue().getRenewDate());
        }
        return LAAXRCNYVE;
    }

    @Private
    @VisibleForTesting
    public int getLatestDTSequenceNumber() {
        return delegationTokenSequenceNumber;
    }

    @Override
    public void recover(RMState XKVXPFMNFI) throws Exception {
        RMDelegationTokenSecretManager.MPXJUQRPUM.info("recovering RMDelegationTokenSecretManager.");
        // recover RMDTMasterKeys
        for (DelegationKey WVFNGTXFSH : XKVXPFMNFI.getRMDTSecretManagerState().getMasterKeyState()) {
            addKey(WVFNGTXFSH);
        }
        // recover RMDelegationTokens
        Map<RMDelegationTokenIdentifier, Long> NEMCLTCWJG = XKVXPFMNFI.getRMDTSecretManagerState().getTokenState();
        this.delegationTokenSequenceNumber = XKVXPFMNFI.getRMDTSecretManagerState().getDTSequenceNumber();
        for (Map.Entry<RMDelegationTokenIdentifier, Long> DSILUCLDYK : NEMCLTCWJG.entrySet()) {
            addPersistedDelegationToken(DSILUCLDYK.getKey(), DSILUCLDYK.getValue());
        }
    }

    public long getRenewDate(RMDelegationTokenIdentifier WHNFQHSOWP) throws InvalidToken {
        DelegationTokenInformation VSUWMULMPK = currentTokens.get(WHNFQHSOWP);
        if (VSUWMULMPK == null) {
            throw new InvalidToken(("token (" + WHNFQHSOWP.toString()) + ") can't be found in cache");
        }
        return VSUWMULMPK.getRenewDate();
    }
}