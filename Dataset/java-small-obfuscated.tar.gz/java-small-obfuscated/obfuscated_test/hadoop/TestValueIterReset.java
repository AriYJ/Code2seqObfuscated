/**
 * A JUnit test to test the Map-Reduce framework's support for the
 * "mark-reset" functionality in Reduce Values Iterator
 */
public class TestValueIterReset extends TestCase {
    private static final int IAMJDWEPFB = 1;

    private static final int REZCLRDIAB = 4;

    private static final int ECMZITSJYB = 40;

    private static Path SKRMCVYARC = new Path(System.getProperty("test.build.data", "/tmp"));

    private static Configuration NPWITNORUE = new Configuration();

    private static FileSystem KAACAKTLDX;

    static {
        try {
            TestValueIterReset.KAACAKTLDX = FileSystem.getLocal(TestValueIterReset.NPWITNORUE);
        } catch (IOException io) {
            throw new RuntimeException("problem getting local fs", io);
        }
    }

    private static final Log KREOFMENJJ = LogFactory.getLog(TestValueIterReset.class);

    public static class TestMapper extends Mapper<LongWritable, Text, IntWritable, IntWritable> {
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            IntWritable outKey = new IntWritable();
            IntWritable outValue = new IntWritable();
            for (int j = 0; j < TestValueIterReset.REZCLRDIAB; j++) {
                for (int i = 0; i < TestValueIterReset.ECMZITSJYB; i++) {
                    outKey.set(j);
                    outValue.set(i);
                    context.write(outKey, outValue);
                }
            }
        }
    }

    public static class TestReducer extends Reducer<IntWritable, IntWritable, IntWritable, IntWritable> {
        public void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int errors = 0;
            MarkableIterator<IntWritable> mitr = new MarkableIterator<IntWritable>(values.iterator());
            switch (key.get()) {
                case 0 :
                    errors += TestValueIterReset.test0(key, mitr);
                    break;
                case 1 :
                    errors += TestValueIterReset.test1(key, mitr);
                    break;
                case 2 :
                    errors += TestValueIterReset.test2(key, mitr);
                    break;
                case 3 :
                    errors += TestValueIterReset.test3(key, mitr);
                    break;
                default :
                    break;
            }
            context.write(key, new IntWritable(errors));
        }
    }

    /**
     * Test the most common use case. Mark before start of the iteration and
     * reset at the end to go over the entire list
     *
     * @param key
     * 		
     * @param values
     * 		
     * @return 
     * @throws IOException
     * 		
     */
    private static int test0(IntWritable CTIKXDSRNK, MarkableIterator<IntWritable> ZVLZXNUDQY) throws IOException {
        int YMXZFRNNAL = 0;
        IntWritable WUSSZZYKHV;
        ArrayList<IntWritable> EAQSDJYYII = new ArrayList<IntWritable>();
        TestValueIterReset.KREOFMENJJ.info("Executing TEST:0 for Key:" + CTIKXDSRNK.toString());
        ZVLZXNUDQY.mark();
        TestValueIterReset.KREOFMENJJ.info("TEST:0. Marking");
        while (ZVLZXNUDQY.hasNext()) {
            WUSSZZYKHV = ZVLZXNUDQY.next();
            EAQSDJYYII.add(WUSSZZYKHV);
            TestValueIterReset.KREOFMENJJ.info((CTIKXDSRNK + ":") + WUSSZZYKHV);
        } 
        ZVLZXNUDQY.reset();
        TestValueIterReset.KREOFMENJJ.info("TEST:0. Reset");
        int TCITYGSALQ = 0;
        while (ZVLZXNUDQY.hasNext()) {
            WUSSZZYKHV = ZVLZXNUDQY.next();
            TestValueIterReset.KREOFMENJJ.info((CTIKXDSRNK + ":") + WUSSZZYKHV);
            if (WUSSZZYKHV != EAQSDJYYII.get(TCITYGSALQ)) {
                TestValueIterReset.KREOFMENJJ.info((("TEST:0. Check:1 Expected: " + EAQSDJYYII.get(TCITYGSALQ)) + ", Got: ") + WUSSZZYKHV);
                YMXZFRNNAL++;
                return YMXZFRNNAL;
            }
            TCITYGSALQ++;
        } 
        TestValueIterReset.KREOFMENJJ.info("TEST:0 Done");
        return YMXZFRNNAL;
    }

    /**
     * Test the case where we do a mark outside of a reset. Test for both file
     * and memory caches
     *
     * @param key
     * 		
     * @param values
     * 		
     * @return 
     * @throws IOException
     * 		
     */
    private static int test1(IntWritable YLHYEEMXLI, MarkableIterator<IntWritable> NEHQCEDBEV) throws IOException {
        IntWritable UAFAJACVXU;
        int JJUKCVEEHB = 0;
        int RGLTLKXDGL = 0;
        ArrayList<IntWritable> TFNSRTEKWL = new ArrayList<IntWritable>();
        ArrayList<IntWritable> DNNPPUPFDI = new ArrayList<IntWritable>();
        TestValueIterReset.KREOFMENJJ.info("Executing TEST:1 for Key:" + YLHYEEMXLI);
        NEHQCEDBEV.mark();
        TestValueIterReset.KREOFMENJJ.info("TEST:1. Marking");
        while (NEHQCEDBEV.hasNext()) {
            UAFAJACVXU = NEHQCEDBEV.next();
            TestValueIterReset.KREOFMENJJ.info((YLHYEEMXLI + ":") + UAFAJACVXU);
            TFNSRTEKWL.add(UAFAJACVXU);
            if (RGLTLKXDGL == 2) {
                break;
            }
            RGLTLKXDGL++;
        } 
        NEHQCEDBEV.reset();
        TestValueIterReset.KREOFMENJJ.info("TEST:1. Reset");
        RGLTLKXDGL = 0;
        while (NEHQCEDBEV.hasNext()) {
            UAFAJACVXU = NEHQCEDBEV.next();
            TestValueIterReset.KREOFMENJJ.info((YLHYEEMXLI + ":") + UAFAJACVXU);
            if (RGLTLKXDGL < TFNSRTEKWL.size()) {
                if (UAFAJACVXU != TFNSRTEKWL.get(RGLTLKXDGL)) {
                    JJUKCVEEHB++;
                    TestValueIterReset.KREOFMENJJ.info((("TEST:1. Check:1 Expected: " + TFNSRTEKWL.get(RGLTLKXDGL)) + ", Got: ") + UAFAJACVXU);
                    return JJUKCVEEHB;
                }
            }
            // We have moved passed the first mark, but still in the memory cache
            if (RGLTLKXDGL == 3) {
                NEHQCEDBEV.mark();
                TestValueIterReset.KREOFMENJJ.info((("TEST:1. Marking -- " + YLHYEEMXLI) + ": ") + UAFAJACVXU);
            }
            if (RGLTLKXDGL >= 3) {
                DNNPPUPFDI.add(UAFAJACVXU);
            }
            if (RGLTLKXDGL == 5) {
                break;
            }
            RGLTLKXDGL++;
        } 
        if (RGLTLKXDGL < TFNSRTEKWL.size()) {
            TestValueIterReset.KREOFMENJJ.info("TEST:1 Check:2. Iterator returned lesser values");
            JJUKCVEEHB++;
            return JJUKCVEEHB;
        }
        NEHQCEDBEV.reset();
        RGLTLKXDGL = 0;
        TestValueIterReset.KREOFMENJJ.info("TEST:1. Reset");
        TFNSRTEKWL.clear();
        while (NEHQCEDBEV.hasNext()) {
            UAFAJACVXU = NEHQCEDBEV.next();
            TestValueIterReset.KREOFMENJJ.info((YLHYEEMXLI + ":") + UAFAJACVXU);
            if (RGLTLKXDGL < DNNPPUPFDI.size()) {
                if (UAFAJACVXU != DNNPPUPFDI.get(RGLTLKXDGL)) {
                    JJUKCVEEHB++;
                    TestValueIterReset.KREOFMENJJ.info((("TEST:1. Check:3 Expected: " + DNNPPUPFDI.get(RGLTLKXDGL)) + ", Got: ") + UAFAJACVXU);
                    return JJUKCVEEHB;
                }
            }
            // We have moved passed the previous mark, but now we are in the file
            // cache
            if (RGLTLKXDGL == 25) {
                NEHQCEDBEV.mark();
                TestValueIterReset.KREOFMENJJ.info((("TEST:1. Marking -- " + YLHYEEMXLI) + ":") + UAFAJACVXU);
            }
            if (RGLTLKXDGL >= 25) {
                TFNSRTEKWL.add(UAFAJACVXU);
            }
            RGLTLKXDGL++;
        } 
        if (RGLTLKXDGL < DNNPPUPFDI.size()) {
            TestValueIterReset.KREOFMENJJ.info("TEST:1 Check:4. Iterator returned fewer values");
            JJUKCVEEHB++;
            return JJUKCVEEHB;
        }
        NEHQCEDBEV.reset();
        TestValueIterReset.KREOFMENJJ.info("TEST:1. Reset");
        RGLTLKXDGL = 0;
        while (NEHQCEDBEV.hasNext()) {
            UAFAJACVXU = NEHQCEDBEV.next();
            TestValueIterReset.KREOFMENJJ.info((YLHYEEMXLI + ":") + UAFAJACVXU);
            if (UAFAJACVXU != TFNSRTEKWL.get(RGLTLKXDGL)) {
                JJUKCVEEHB++;
                TestValueIterReset.KREOFMENJJ.info((("TEST:1. Check:5 Expected: " + TFNSRTEKWL.get(RGLTLKXDGL)) + ", Got: ") + UAFAJACVXU);
                return JJUKCVEEHB;
            }
        } 
        TestValueIterReset.KREOFMENJJ.info("TEST:1 Done");
        return JJUKCVEEHB;
    }

    /**
     * Test the case where we do a mark inside a reset. Test for both file
     * and memory
     *
     * @param key
     * 		
     * @param values
     * 		
     * @return 
     * @throws IOException
     * 		
     */
    private static int test2(IntWritable SXHLWXZRQL, MarkableIterator<IntWritable> YJPVZSYWDP) throws IOException {
        IntWritable UPPOUSFDIO;
        int JLALSJLITX = 0;
        int QZYOZECGBQ = 0;
        ArrayList<IntWritable> VJDSKSLSNV = new ArrayList<IntWritable>();
        ArrayList<IntWritable> LHXZMQJNGJ = new ArrayList<IntWritable>();
        TestValueIterReset.KREOFMENJJ.info("Executing TEST:2 for Key:" + SXHLWXZRQL);
        YJPVZSYWDP.mark();
        TestValueIterReset.KREOFMENJJ.info("TEST:2 Marking");
        while (YJPVZSYWDP.hasNext()) {
            UPPOUSFDIO = YJPVZSYWDP.next();
            TestValueIterReset.KREOFMENJJ.info((SXHLWXZRQL + ":") + UPPOUSFDIO);
            VJDSKSLSNV.add(UPPOUSFDIO);
            if (QZYOZECGBQ == 8) {
                break;
            }
            QZYOZECGBQ++;
        } 
        YJPVZSYWDP.reset();
        QZYOZECGBQ = 0;
        TestValueIterReset.KREOFMENJJ.info("TEST:2 reset");
        while (YJPVZSYWDP.hasNext()) {
            UPPOUSFDIO = YJPVZSYWDP.next();
            TestValueIterReset.KREOFMENJJ.info((SXHLWXZRQL + ":") + UPPOUSFDIO);
            if (QZYOZECGBQ < VJDSKSLSNV.size()) {
                if (UPPOUSFDIO != VJDSKSLSNV.get(QZYOZECGBQ)) {
                    JLALSJLITX++;
                    TestValueIterReset.KREOFMENJJ.info((("TEST:2. Check:1 Expected: " + VJDSKSLSNV.get(QZYOZECGBQ)) + ", Got: ") + UPPOUSFDIO);
                    return JLALSJLITX;
                }
            }
            // We have moved passed the first mark, but still reading from the
            // memory cache
            if (QZYOZECGBQ == 3) {
                YJPVZSYWDP.mark();
                TestValueIterReset.KREOFMENJJ.info((("TEST:2. Marking -- " + SXHLWXZRQL) + ":") + UPPOUSFDIO);
            }
            if (QZYOZECGBQ >= 3) {
                LHXZMQJNGJ.add(UPPOUSFDIO);
            }
            QZYOZECGBQ++;
        } 
        YJPVZSYWDP.reset();
        TestValueIterReset.KREOFMENJJ.info("TEST:2. Reset");
        VJDSKSLSNV.clear();
        QZYOZECGBQ = 0;
        while (YJPVZSYWDP.hasNext()) {
            UPPOUSFDIO = YJPVZSYWDP.next();
            TestValueIterReset.KREOFMENJJ.info((SXHLWXZRQL + ":") + UPPOUSFDIO);
            if (QZYOZECGBQ < LHXZMQJNGJ.size()) {
                if (UPPOUSFDIO != LHXZMQJNGJ.get(QZYOZECGBQ)) {
                    JLALSJLITX++;
                    TestValueIterReset.KREOFMENJJ.info((("TEST:2. Check:2 Expected: " + LHXZMQJNGJ.get(QZYOZECGBQ)) + ", Got: ") + UPPOUSFDIO);
                    return JLALSJLITX;
                }
            }
            // We have moved passed the previous mark, but now we are in the file
            // cache
            if (QZYOZECGBQ == 20) {
                YJPVZSYWDP.mark();
                TestValueIterReset.KREOFMENJJ.info((("TEST:2. Marking -- " + SXHLWXZRQL) + ":") + UPPOUSFDIO);
            }
            if (QZYOZECGBQ >= 20) {
                VJDSKSLSNV.add(UPPOUSFDIO);
            }
            QZYOZECGBQ++;
        } 
        YJPVZSYWDP.reset();
        QZYOZECGBQ = 0;
        TestValueIterReset.KREOFMENJJ.info("TEST:2. Reset");
        while (YJPVZSYWDP.hasNext()) {
            UPPOUSFDIO = YJPVZSYWDP.next();
            TestValueIterReset.KREOFMENJJ.info((SXHLWXZRQL + ":") + UPPOUSFDIO);
            if (UPPOUSFDIO != VJDSKSLSNV.get(QZYOZECGBQ)) {
                JLALSJLITX++;
                TestValueIterReset.KREOFMENJJ.info((("TEST:2. Check:1 Expected: " + VJDSKSLSNV.get(QZYOZECGBQ)) + ", Got: ") + UPPOUSFDIO);
                return JLALSJLITX;
            }
        } 
        TestValueIterReset.KREOFMENJJ.info("TEST:2 Done");
        return JLALSJLITX;
    }

    /**
     * Test "clearMark"
     *
     * @param key
     * 		
     * @param values
     * 		
     * @return 
     * @throws IOException
     * 		
     */
    private static int test3(IntWritable MTRALJTZFS, MarkableIterator<IntWritable> KOBIGSZZUT) throws IOException {
        int BUOGKCXVTG = 0;
        IntWritable JPETAVCYIQ;
        ArrayList<IntWritable> DDOXEDSPRV = new ArrayList<IntWritable>();
        TestValueIterReset.KREOFMENJJ.info("Executing TEST:3 for Key:" + MTRALJTZFS);
        KOBIGSZZUT.mark();
        TestValueIterReset.KREOFMENJJ.info("TEST:3. Marking");
        int NXATIMIQHR = 0;
        while (KOBIGSZZUT.hasNext()) {
            JPETAVCYIQ = KOBIGSZZUT.next();
            TestValueIterReset.KREOFMENJJ.info((MTRALJTZFS + ":") + JPETAVCYIQ);
            if (NXATIMIQHR == 5) {
                TestValueIterReset.KREOFMENJJ.info("TEST:3. Clearing Mark");
                KOBIGSZZUT.clearMark();
            }
            if (NXATIMIQHR == 8) {
                TestValueIterReset.KREOFMENJJ.info((("TEST:3. Marking -- " + MTRALJTZFS) + ":") + JPETAVCYIQ);
                KOBIGSZZUT.mark();
            }
            if (NXATIMIQHR >= 8) {
                DDOXEDSPRV.add(JPETAVCYIQ);
            }
            NXATIMIQHR++;
        } 
        KOBIGSZZUT.reset();
        TestValueIterReset.KREOFMENJJ.info("TEST:3. After reset");
        if (!KOBIGSZZUT.hasNext()) {
            BUOGKCXVTG++;
            TestValueIterReset.KREOFMENJJ.info("TEST:3, Check:1. HasNext returned false");
            return BUOGKCXVTG;
        }
        NXATIMIQHR = 0;
        while (KOBIGSZZUT.hasNext()) {
            JPETAVCYIQ = KOBIGSZZUT.next();
            TestValueIterReset.KREOFMENJJ.info((MTRALJTZFS + ":") + JPETAVCYIQ);
            if (NXATIMIQHR < DDOXEDSPRV.size()) {
                if (JPETAVCYIQ != DDOXEDSPRV.get(NXATIMIQHR)) {
                    BUOGKCXVTG++;
                    TestValueIterReset.KREOFMENJJ.info((("TEST:2. Check:1 Expected: " + DDOXEDSPRV.get(NXATIMIQHR)) + ", Got: ") + JPETAVCYIQ);
                    return BUOGKCXVTG;
                }
            }
            if (NXATIMIQHR == 10) {
                KOBIGSZZUT.clearMark();
                TestValueIterReset.KREOFMENJJ.info("TEST:3. After clear mark");
            }
            NXATIMIQHR++;
        } 
        boolean ZAAUYWPMZE = false;
        try {
            TestValueIterReset.KREOFMENJJ.info("TEST:3. Before Reset");
            KOBIGSZZUT.reset();
        } catch (IOException e) {
            ZAAUYWPMZE = true;
        }
        if (!ZAAUYWPMZE) {
            TestValueIterReset.KREOFMENJJ.info("TEST:3 Check:4 reset was successfule even after clearMark");
            BUOGKCXVTG++;
            return BUOGKCXVTG;
        }
        TestValueIterReset.KREOFMENJJ.info("TEST:3 Done.");
        return BUOGKCXVTG;
    }

    public void createInput() throws Exception {
        // Just create one line files. We use this only to
        // control the number of map tasks
        for (int YPEIEMOIZW = 0; YPEIEMOIZW < TestValueIterReset.IAMJDWEPFB; YPEIEMOIZW++) {
            Path HEVTGCLBUR = new Path(TestValueIterReset.SKRMCVYARC + "/in", ("test" + YPEIEMOIZW) + ".txt");
            TestValueIterReset.KAACAKTLDX.delete(HEVTGCLBUR, false);
            OutputStream GTUGNANDUH = TestValueIterReset.KAACAKTLDX.create(HEVTGCLBUR);
            Writer XEYTRRKUQI = new OutputStreamWriter(GTUGNANDUH);
            XEYTRRKUQI.write("dummy");
            XEYTRRKUQI.close();
        }
    }

    public void testValueIterReset() {
        try {
            Configuration NIIAWPPQYM = new Configuration();
            Job OFABLPYGIU = Job.getInstance(NIIAWPPQYM, "TestValueIterReset");
            OFABLPYGIU.setJarByClass(TestValueIterReset.class);
            OFABLPYGIU.setMapperClass(TestValueIterReset.TestMapper.class);
            OFABLPYGIU.setReducerClass(TestValueIterReset.TestReducer.class);
            OFABLPYGIU.setNumReduceTasks(TestValueIterReset.REZCLRDIAB);
            OFABLPYGIU.setMapOutputKeyClass(IntWritable.class);
            OFABLPYGIU.setMapOutputValueClass(IntWritable.class);
            OFABLPYGIU.setOutputKeyClass(IntWritable.class);
            OFABLPYGIU.setOutputValueClass(IntWritable.class);
            OFABLPYGIU.getConfiguration().setInt(MRJobConfig.REDUCE_MARKRESET_BUFFER_SIZE, 128);
            OFABLPYGIU.setInputFormatClass(TextInputFormat.class);
            OFABLPYGIU.setOutputFormatClass(TextOutputFormat.class);
            FileInputFormat.addInputPath(OFABLPYGIU, new Path(TestValueIterReset.SKRMCVYARC + "/in"));
            Path RAIRPQWPOA = new Path(TestValueIterReset.SKRMCVYARC + "/out");
            TestValueIterReset.KAACAKTLDX.delete(RAIRPQWPOA, true);
            FileOutputFormat.setOutputPath(OFABLPYGIU, RAIRPQWPOA);
            createInput();
            assertTrue(OFABLPYGIU.waitForCompletion(true));
            validateOutput();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    private void validateOutput() throws IOException {
        Path[] TMDANITNVL = FileUtil.stat2Paths(TestValueIterReset.KAACAKTLDX.listStatus(new Path(TestValueIterReset.SKRMCVYARC + "/out"), new Utils.OutputFileUtils.OutputFilesFilter()));
        if (TMDANITNVL.length > 0) {
            InputStream DSPPWHHVHJ = TestValueIterReset.KAACAKTLDX.open(TMDANITNVL[0]);
            BufferedReader YJNIIJJLLZ = new BufferedReader(new InputStreamReader(DSPPWHHVHJ));
            String BVIIDYMUSV = YJNIIJJLLZ.readLine();
            while (BVIIDYMUSV != null) {
                StringTokenizer GWHIZIZCOQ = new StringTokenizer(BVIIDYMUSV, "\t");
                String SOMDXDAHWN = GWHIZIZCOQ.nextToken();
                String TFDCNJTAFL = GWHIZIZCOQ.nextToken();
                TestValueIterReset.KREOFMENJJ.info((("Output: key: " + SOMDXDAHWN) + " value: ") + TFDCNJTAFL);
                int ERTWPWVEKK = Integer.parseInt(TFDCNJTAFL);
                assertTrue(ERTWPWVEKK == 0);
                BVIIDYMUSV = YJNIIJJLLZ.readLine();
            } 
            YJNIIJJLLZ.close();
        }
    }
}