/**
 * Exception raised if a Swift endpoint returned a HTTP response indicating
 * the caller is being throttled.
 */
public class SwiftThrottledRequestException extends SwiftInvalidResponseException {
    public SwiftThrottledRequestException(String IXDXFYYBKD, String SJMVWOSNVQ, URI IKINVFCMCK, HttpMethod ILWKUQSLDR) {
        super(IXDXFYYBKD, SJMVWOSNVQ, IKINVFCMCK, ILWKUQSLDR);
    }
}