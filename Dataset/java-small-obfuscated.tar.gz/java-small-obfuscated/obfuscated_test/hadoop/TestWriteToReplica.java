/**
 * Test if FSDataset#append, writeToRbw, and writeToTmp
 */
public class TestWriteToReplica {
    private static final int UNTBJHHUPR = 0;

    private static final int ZKEWPAVQVQ = 1;

    private static final int OGFOBXRIYU = 2;

    private static final int WPCEGWSEJH = 3;

    private static final int GEEUCGGBOK = 4;

    private static final int SHGGJBYRHM = 5;

    // test close
    @Test
    public void testClose() throws Exception {
        MiniDFSCluster EDIVRSKGFE = new MiniDFSCluster.Builder(new org.apache.hadoop.hdfs.HdfsConfiguration()).build();
        try {
            EDIVRSKGFE.waitActive();
            DataNode GRYMZLTTGV = EDIVRSKGFE.getDataNodes().get(0);
            FsDatasetImpl SIUFJVNREV = ((FsDatasetImpl) (DataNodeTestUtils.getFSDataset(GRYMZLTTGV)));
            // set up replicasMap
            String PCCJMQFJLG = EDIVRSKGFE.getNamesystem().getBlockPoolId();
            ExtendedBlock[] UJOZPJUQXZ = setup(PCCJMQFJLG, SIUFJVNREV);
            // test close
            testClose(SIUFJVNREV, UJOZPJUQXZ);
        } finally {
            EDIVRSKGFE.shutdown();
        }
    }

    // test append
    @Test
    public void testAppend() throws Exception {
        MiniDFSCluster NWSYQKESVX = new MiniDFSCluster.Builder(new org.apache.hadoop.hdfs.HdfsConfiguration()).build();
        try {
            NWSYQKESVX.waitActive();
            DataNode WSYZJYZSXA = NWSYQKESVX.getDataNodes().get(0);
            FsDatasetImpl FRABBFGBEI = ((FsDatasetImpl) (DataNodeTestUtils.getFSDataset(WSYZJYZSXA)));
            // set up replicasMap
            String KYROVKHOWM = NWSYQKESVX.getNamesystem().getBlockPoolId();
            ExtendedBlock[] MPGOGMWCFP = setup(KYROVKHOWM, FRABBFGBEI);
            // test append
            testAppend(KYROVKHOWM, FRABBFGBEI, MPGOGMWCFP);
        } finally {
            NWSYQKESVX.shutdown();
        }
    }

    // test writeToRbw
    @Test
    public void testWriteToRbw() throws Exception {
        MiniDFSCluster QOFBDXFXAE = new MiniDFSCluster.Builder(new org.apache.hadoop.hdfs.HdfsConfiguration()).build();
        try {
            QOFBDXFXAE.waitActive();
            DataNode EDHRCTMYQL = QOFBDXFXAE.getDataNodes().get(0);
            FsDatasetImpl UAKRMBGKER = ((FsDatasetImpl) (DataNodeTestUtils.getFSDataset(EDHRCTMYQL)));
            // set up replicasMap
            String VINAOPZKNJ = QOFBDXFXAE.getNamesystem().getBlockPoolId();
            ExtendedBlock[] RFHIQWQYCT = setup(VINAOPZKNJ, UAKRMBGKER);
            // test writeToRbw
            testWriteToRbw(UAKRMBGKER, RFHIQWQYCT);
        } finally {
            QOFBDXFXAE.shutdown();
        }
    }

    // test writeToTemporary
    @Test
    public void testWriteToTempoary() throws Exception {
        MiniDFSCluster EECSQXXIHK = new MiniDFSCluster.Builder(new org.apache.hadoop.hdfs.HdfsConfiguration()).build();
        try {
            EECSQXXIHK.waitActive();
            DataNode RCDYACIPXE = EECSQXXIHK.getDataNodes().get(0);
            FsDatasetImpl RWUXCOZSBG = ((FsDatasetImpl) (DataNodeTestUtils.getFSDataset(RCDYACIPXE)));
            // set up replicasMap
            String ENTAXILXDR = EECSQXXIHK.getNamesystem().getBlockPoolId();
            ExtendedBlock[] PTOSAECSDX = setup(ENTAXILXDR, RWUXCOZSBG);
            // test writeToTemporary
            testWriteToTemporary(RWUXCOZSBG, PTOSAECSDX);
        } finally {
            EECSQXXIHK.shutdown();
        }
    }

    /**
     * Generate testing environment and return a collection of blocks
     * on which to run the tests.
     *
     * @param bpid
     * 		Block pool ID to generate blocks for
     * @param dataSet
     * 		Namespace in which to insert blocks
     * @return Contrived blocks for further testing.
     * @throws IOException
     * 		
     */
    private ExtendedBlock[] setup(String KVFJQMRHCQ, FsDatasetImpl KGSXVHXBFU) throws IOException {
        // setup replicas map
        ExtendedBlock[] CVAVYJBZPO = new ExtendedBlock[]{ new ExtendedBlock(KVFJQMRHCQ, 1, 1, 2001), new ExtendedBlock(KVFJQMRHCQ, 2, 1, 2002), new ExtendedBlock(KVFJQMRHCQ, 3, 1, 2003), new ExtendedBlock(KVFJQMRHCQ, 4, 1, 2004), new ExtendedBlock(KVFJQMRHCQ, 5, 1, 2005), new ExtendedBlock(KVFJQMRHCQ, 6, 1, 2006) };
        ReplicaMap JRIJONJLBU = KGSXVHXBFU.volumeMap;
        FsVolumeImpl QFIBCATHRS = KGSXVHXBFU.volumes.getNextVolume(DEFAULT, 0);
        ReplicaInfo RMVQMVTKKE = new org.apache.hadoop.hdfs.server.datanode.FinalizedReplica(CVAVYJBZPO[TestWriteToReplica.UNTBJHHUPR].getLocalBlock(), QFIBCATHRS, QFIBCATHRS.getCurrentDir().getParentFile());
        JRIJONJLBU.add(KVFJQMRHCQ, RMVQMVTKKE);
        RMVQMVTKKE.getBlockFile().createNewFile();
        RMVQMVTKKE.getMetaFile().createNewFile();
        JRIJONJLBU.add(KVFJQMRHCQ, new org.apache.hadoop.hdfs.server.datanode.ReplicaInPipeline(CVAVYJBZPO[TestWriteToReplica.ZKEWPAVQVQ].getBlockId(), CVAVYJBZPO[TestWriteToReplica.ZKEWPAVQVQ].getGenerationStamp(), QFIBCATHRS, QFIBCATHRS.createTmpFile(KVFJQMRHCQ, CVAVYJBZPO[TestWriteToReplica.ZKEWPAVQVQ].getLocalBlock()).getParentFile()));
        RMVQMVTKKE = new org.apache.hadoop.hdfs.server.datanode.ReplicaBeingWritten(CVAVYJBZPO[TestWriteToReplica.OGFOBXRIYU].getLocalBlock(), QFIBCATHRS, QFIBCATHRS.createRbwFile(KVFJQMRHCQ, CVAVYJBZPO[TestWriteToReplica.OGFOBXRIYU].getLocalBlock()).getParentFile(), null);
        JRIJONJLBU.add(KVFJQMRHCQ, RMVQMVTKKE);
        RMVQMVTKKE.getBlockFile().createNewFile();
        RMVQMVTKKE.getMetaFile().createNewFile();
        JRIJONJLBU.add(KVFJQMRHCQ, new org.apache.hadoop.hdfs.server.datanode.ReplicaWaitingToBeRecovered(CVAVYJBZPO[TestWriteToReplica.WPCEGWSEJH].getLocalBlock(), QFIBCATHRS, QFIBCATHRS.createRbwFile(KVFJQMRHCQ, CVAVYJBZPO[TestWriteToReplica.WPCEGWSEJH].getLocalBlock()).getParentFile()));
        JRIJONJLBU.add(KVFJQMRHCQ, new ReplicaUnderRecovery(new org.apache.hadoop.hdfs.server.datanode.FinalizedReplica(CVAVYJBZPO[TestWriteToReplica.GEEUCGGBOK].getLocalBlock(), QFIBCATHRS, QFIBCATHRS.getCurrentDir().getParentFile()), 2007));
        return CVAVYJBZPO;
    }

    private void testAppend(String HUCGNUKPXR, FsDatasetImpl WVLTXXJGJW, ExtendedBlock[] YESQKVUVFO) throws IOException {
        long WPVFFHYZSE = YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].getGenerationStamp() + 1;
        final FsVolumeImpl ZKGAFAFGNR = ((FsVolumeImpl) (WVLTXXJGJW.volumeMap.get(HUCGNUKPXR, YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].getLocalBlock()).getVolume()));
        long CHINMXXDNY = ZKGAFAFGNR.getCapacity() - ZKGAFAFGNR.getDfsUsed();
        long ZFCEWHOOIV = YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].getNumBytes();
        try {
            ZKGAFAFGNR.decDfsUsed(HUCGNUKPXR, -CHINMXXDNY);
            YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].setNumBytes(ZFCEWHOOIV + 100);
            WVLTXXJGJW.append(YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR], WPVFFHYZSE, ZFCEWHOOIV);
            Assert.fail("Should not have space to append to an RWR replica" + YESQKVUVFO[TestWriteToReplica.WPCEGWSEJH]);
        } catch (DiskOutOfSpaceException e) {
            Assert.assertTrue(e.getMessage().startsWith("Insufficient space for appending to "));
        }
        ZKGAFAFGNR.decDfsUsed(HUCGNUKPXR, CHINMXXDNY);
        YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].setNumBytes(ZFCEWHOOIV);
        WPVFFHYZSE = YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU].getGenerationStamp() + 1;
        WVLTXXJGJW.append(YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR], WPVFFHYZSE, YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].getNumBytes());// successful

        YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].setGenerationStamp(WPVFFHYZSE);
        try {
            WVLTXXJGJW.append(YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ], YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ].getGenerationStamp() + 1, YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ].getNumBytes());
            Assert.fail("Should not have appended to a temporary replica " + YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertEquals(ReplicaNotFoundException.UNFINALIZED_REPLICA + YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ], e.getMessage());
        }
        try {
            WVLTXXJGJW.append(YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU], YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU].getGenerationStamp() + 1, YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU].getNumBytes());
            Assert.fail("Should not have appended to an RBW replica" + YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertEquals(ReplicaNotFoundException.UNFINALIZED_REPLICA + YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU], e.getMessage());
        }
        try {
            WVLTXXJGJW.append(YESQKVUVFO[TestWriteToReplica.WPCEGWSEJH], YESQKVUVFO[TestWriteToReplica.WPCEGWSEJH].getGenerationStamp() + 1, YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU].getNumBytes());
            Assert.fail("Should not have appended to an RWR replica" + YESQKVUVFO[TestWriteToReplica.WPCEGWSEJH]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertEquals(ReplicaNotFoundException.UNFINALIZED_REPLICA + YESQKVUVFO[TestWriteToReplica.WPCEGWSEJH], e.getMessage());
        }
        try {
            WVLTXXJGJW.append(YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK], YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK].getGenerationStamp() + 1, YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK].getNumBytes());
            Assert.fail("Should not have appended to an RUR replica" + YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertEquals(ReplicaNotFoundException.UNFINALIZED_REPLICA + YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK], e.getMessage());
        }
        try {
            WVLTXXJGJW.append(YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM], YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM].getGenerationStamp(), YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM].getNumBytes());
            Assert.fail("Should not have appended to a non-existent replica " + YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertEquals(ReplicaNotFoundException.NON_EXISTENT_REPLICA + YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM], e.getMessage());
        }
        WPVFFHYZSE = YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].getGenerationStamp() + 1;
        WVLTXXJGJW.recoverAppend(YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR], WPVFFHYZSE, YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].getNumBytes());// successful

        YESQKVUVFO[TestWriteToReplica.UNTBJHHUPR].setGenerationStamp(WPVFFHYZSE);
        try {
            WVLTXXJGJW.recoverAppend(YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ], YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ].getGenerationStamp() + 1, YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ].getNumBytes());
            Assert.fail("Should not have appended to a temporary replica " + YESQKVUVFO[TestWriteToReplica.ZKEWPAVQVQ]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
        }
        WPVFFHYZSE = YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU].getGenerationStamp() + 1;
        WVLTXXJGJW.recoverAppend(YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU], WPVFFHYZSE, YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU].getNumBytes());
        YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU].setGenerationStamp(WPVFFHYZSE);
        try {
            WVLTXXJGJW.recoverAppend(YESQKVUVFO[TestWriteToReplica.WPCEGWSEJH], YESQKVUVFO[TestWriteToReplica.WPCEGWSEJH].getGenerationStamp() + 1, YESQKVUVFO[TestWriteToReplica.OGFOBXRIYU].getNumBytes());
            Assert.fail("Should not have appended to an RWR replica" + YESQKVUVFO[TestWriteToReplica.WPCEGWSEJH]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
        }
        try {
            WVLTXXJGJW.recoverAppend(YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK], YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK].getGenerationStamp() + 1, YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK].getNumBytes());
            Assert.fail("Should not have appended to an RUR replica" + YESQKVUVFO[TestWriteToReplica.GEEUCGGBOK]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
        }
        try {
            WVLTXXJGJW.recoverAppend(YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM], YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM].getGenerationStamp(), YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM].getNumBytes());
            Assert.fail("Should not have appended to a non-existent replica " + YESQKVUVFO[TestWriteToReplica.SHGGJBYRHM]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.NON_EXISTENT_REPLICA));
        }
    }

    private void testClose(FsDatasetImpl OOCHUTYXMW, ExtendedBlock[] BFRBQPIXJH) throws IOException {
        long OTXYXLHHWK = BFRBQPIXJH[TestWriteToReplica.UNTBJHHUPR].getGenerationStamp() + 1;
        OOCHUTYXMW.recoverClose(BFRBQPIXJH[TestWriteToReplica.UNTBJHHUPR], OTXYXLHHWK, BFRBQPIXJH[TestWriteToReplica.UNTBJHHUPR].getNumBytes());// successful

        BFRBQPIXJH[TestWriteToReplica.UNTBJHHUPR].setGenerationStamp(OTXYXLHHWK);
        try {
            OOCHUTYXMW.recoverClose(BFRBQPIXJH[TestWriteToReplica.ZKEWPAVQVQ], BFRBQPIXJH[TestWriteToReplica.ZKEWPAVQVQ].getGenerationStamp() + 1, BFRBQPIXJH[TestWriteToReplica.ZKEWPAVQVQ].getNumBytes());
            Assert.fail("Should not have recovered close a temporary replica " + BFRBQPIXJH[TestWriteToReplica.ZKEWPAVQVQ]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
        }
        OTXYXLHHWK = BFRBQPIXJH[TestWriteToReplica.OGFOBXRIYU].getGenerationStamp() + 1;
        OOCHUTYXMW.recoverClose(BFRBQPIXJH[TestWriteToReplica.OGFOBXRIYU], OTXYXLHHWK, BFRBQPIXJH[TestWriteToReplica.OGFOBXRIYU].getNumBytes());
        BFRBQPIXJH[TestWriteToReplica.OGFOBXRIYU].setGenerationStamp(OTXYXLHHWK);
        try {
            OOCHUTYXMW.recoverClose(BFRBQPIXJH[TestWriteToReplica.WPCEGWSEJH], BFRBQPIXJH[TestWriteToReplica.WPCEGWSEJH].getGenerationStamp() + 1, BFRBQPIXJH[TestWriteToReplica.OGFOBXRIYU].getNumBytes());
            Assert.fail("Should not have recovered close an RWR replica" + BFRBQPIXJH[TestWriteToReplica.WPCEGWSEJH]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
        }
        try {
            OOCHUTYXMW.recoverClose(BFRBQPIXJH[TestWriteToReplica.GEEUCGGBOK], BFRBQPIXJH[TestWriteToReplica.GEEUCGGBOK].getGenerationStamp() + 1, BFRBQPIXJH[TestWriteToReplica.GEEUCGGBOK].getNumBytes());
            Assert.fail("Should not have recovered close an RUR replica" + BFRBQPIXJH[TestWriteToReplica.GEEUCGGBOK]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.UNFINALIZED_AND_NONRBW_REPLICA));
        }
        try {
            OOCHUTYXMW.recoverClose(BFRBQPIXJH[TestWriteToReplica.SHGGJBYRHM], BFRBQPIXJH[TestWriteToReplica.SHGGJBYRHM].getGenerationStamp(), BFRBQPIXJH[TestWriteToReplica.SHGGJBYRHM].getNumBytes());
            Assert.fail("Should not have recovered close a non-existent replica " + BFRBQPIXJH[TestWriteToReplica.SHGGJBYRHM]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.NON_EXISTENT_REPLICA));
        }
    }

    private void testWriteToRbw(FsDatasetImpl VSTXGJCWMT, ExtendedBlock[] YDRRRXKBHE) throws IOException {
        try {
            VSTXGJCWMT.recoverRbw(YDRRRXKBHE[TestWriteToReplica.UNTBJHHUPR], YDRRRXKBHE[TestWriteToReplica.UNTBJHHUPR].getGenerationStamp() + 1, 0L, YDRRRXKBHE[TestWriteToReplica.UNTBJHHUPR].getNumBytes());
            Assert.fail("Should not have recovered a finalized replica " + YDRRRXKBHE[TestWriteToReplica.UNTBJHHUPR]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.NON_RBW_REPLICA));
        }
        try {
            VSTXGJCWMT.createRbw(DEFAULT, YDRRRXKBHE[TestWriteToReplica.UNTBJHHUPR]);
            Assert.fail(("Should not have created a replica that's already " + "finalized ") + YDRRRXKBHE[TestWriteToReplica.UNTBJHHUPR]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        try {
            VSTXGJCWMT.recoverRbw(YDRRRXKBHE[TestWriteToReplica.ZKEWPAVQVQ], YDRRRXKBHE[TestWriteToReplica.ZKEWPAVQVQ].getGenerationStamp() + 1, 0L, YDRRRXKBHE[TestWriteToReplica.ZKEWPAVQVQ].getNumBytes());
            Assert.fail("Should not have recovered a temporary replica " + YDRRRXKBHE[TestWriteToReplica.ZKEWPAVQVQ]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.NON_RBW_REPLICA));
        }
        try {
            VSTXGJCWMT.createRbw(DEFAULT, YDRRRXKBHE[TestWriteToReplica.ZKEWPAVQVQ]);
            Assert.fail(("Should not have created a replica that had created as " + "temporary ") + YDRRRXKBHE[TestWriteToReplica.ZKEWPAVQVQ]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        VSTXGJCWMT.recoverRbw(YDRRRXKBHE[TestWriteToReplica.OGFOBXRIYU], YDRRRXKBHE[TestWriteToReplica.OGFOBXRIYU].getGenerationStamp() + 1, 0L, YDRRRXKBHE[TestWriteToReplica.OGFOBXRIYU].getNumBytes());// expect to be successful

        try {
            VSTXGJCWMT.createRbw(DEFAULT, YDRRRXKBHE[TestWriteToReplica.OGFOBXRIYU]);
            Assert.fail("Should not have created a replica that had created as RBW " + YDRRRXKBHE[TestWriteToReplica.OGFOBXRIYU]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        try {
            VSTXGJCWMT.recoverRbw(YDRRRXKBHE[TestWriteToReplica.WPCEGWSEJH], YDRRRXKBHE[TestWriteToReplica.WPCEGWSEJH].getGenerationStamp() + 1, 0L, YDRRRXKBHE[TestWriteToReplica.WPCEGWSEJH].getNumBytes());
            Assert.fail("Should not have recovered a RWR replica " + YDRRRXKBHE[TestWriteToReplica.WPCEGWSEJH]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.NON_RBW_REPLICA));
        }
        try {
            VSTXGJCWMT.createRbw(DEFAULT, YDRRRXKBHE[TestWriteToReplica.WPCEGWSEJH]);
            Assert.fail(("Should not have created a replica that was waiting to be " + "recovered ") + YDRRRXKBHE[TestWriteToReplica.WPCEGWSEJH]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        try {
            VSTXGJCWMT.recoverRbw(YDRRRXKBHE[TestWriteToReplica.GEEUCGGBOK], YDRRRXKBHE[TestWriteToReplica.GEEUCGGBOK].getGenerationStamp() + 1, 0L, YDRRRXKBHE[TestWriteToReplica.GEEUCGGBOK].getNumBytes());
            Assert.fail("Should not have recovered a RUR replica " + YDRRRXKBHE[TestWriteToReplica.GEEUCGGBOK]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().startsWith(ReplicaNotFoundException.NON_RBW_REPLICA));
        }
        try {
            VSTXGJCWMT.createRbw(DEFAULT, YDRRRXKBHE[TestWriteToReplica.GEEUCGGBOK]);
            Assert.fail("Should not have created a replica that was under recovery " + YDRRRXKBHE[TestWriteToReplica.GEEUCGGBOK]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        try {
            VSTXGJCWMT.recoverRbw(YDRRRXKBHE[TestWriteToReplica.SHGGJBYRHM], YDRRRXKBHE[TestWriteToReplica.SHGGJBYRHM].getGenerationStamp() + 1, 0L, YDRRRXKBHE[TestWriteToReplica.SHGGJBYRHM].getNumBytes());
            Assert.fail("Cannot recover a non-existent replica " + YDRRRXKBHE[TestWriteToReplica.SHGGJBYRHM]);
        } catch (ReplicaNotFoundException e) {
            Assert.assertTrue(e.getMessage().contains(ReplicaNotFoundException.NON_EXISTENT_REPLICA));
        }
        VSTXGJCWMT.createRbw(DEFAULT, YDRRRXKBHE[TestWriteToReplica.SHGGJBYRHM]);
    }

    private void testWriteToTemporary(FsDatasetImpl HHGEJFLBBM, ExtendedBlock[] ESLBTGKYQO) throws IOException {
        try {
            HHGEJFLBBM.createTemporary(DEFAULT, ESLBTGKYQO[TestWriteToReplica.UNTBJHHUPR]);
            Assert.fail(("Should not have created a temporary replica that was " + "finalized ") + ESLBTGKYQO[TestWriteToReplica.UNTBJHHUPR]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        try {
            HHGEJFLBBM.createTemporary(DEFAULT, ESLBTGKYQO[TestWriteToReplica.ZKEWPAVQVQ]);
            Assert.fail(("Should not have created a replica that had created as" + "temporary ") + ESLBTGKYQO[TestWriteToReplica.ZKEWPAVQVQ]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        try {
            HHGEJFLBBM.createTemporary(DEFAULT, ESLBTGKYQO[TestWriteToReplica.OGFOBXRIYU]);
            Assert.fail("Should not have created a replica that had created as RBW " + ESLBTGKYQO[TestWriteToReplica.OGFOBXRIYU]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        try {
            HHGEJFLBBM.createTemporary(DEFAULT, ESLBTGKYQO[TestWriteToReplica.WPCEGWSEJH]);
            Assert.fail(("Should not have created a replica that was waiting to be " + "recovered ") + ESLBTGKYQO[TestWriteToReplica.WPCEGWSEJH]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        try {
            HHGEJFLBBM.createTemporary(DEFAULT, ESLBTGKYQO[TestWriteToReplica.GEEUCGGBOK]);
            Assert.fail("Should not have created a replica that was under recovery " + ESLBTGKYQO[TestWriteToReplica.GEEUCGGBOK]);
        } catch (ReplicaAlreadyExistsException e) {
        }
        HHGEJFLBBM.createTemporary(DEFAULT, ESLBTGKYQO[TestWriteToReplica.SHGGJBYRHM]);
    }
}