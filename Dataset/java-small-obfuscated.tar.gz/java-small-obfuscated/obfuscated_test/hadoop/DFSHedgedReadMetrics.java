/**
 * The client-side metrics for hedged read feature.
 * This class has a number of metrics variables that are publicly accessible,
 * we can grab them from client side, like HBase.
 */
public class DFSHedgedReadMetrics {
    public final AtomicLong TMZDQLRGHR = new AtomicLong();

    public final AtomicLong DOAJJMTAXG = new AtomicLong();

    public final AtomicLong HEYTVPCVCR = new AtomicLong();

    public void incHedgedReadOps() {
        TMZDQLRGHR.incrementAndGet();
    }

    public void incHedgedReadOpsInCurThread() {
        HEYTVPCVCR.incrementAndGet();
    }

    public void incHedgedReadWins() {
        DOAJJMTAXG.incrementAndGet();
    }

    public long getHedgedReadOps() {
        return TMZDQLRGHR.longValue();
    }

    public long getHedgedReadOpsInCurThread() {
        return HEYTVPCVCR.longValue();
    }

    public long getHedgedReadWins() {
        return DOAJJMTAXG.longValue();
    }
}