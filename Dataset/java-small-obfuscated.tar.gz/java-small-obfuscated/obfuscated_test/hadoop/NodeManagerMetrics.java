@Metrics(about = "Metrics for node manager", context = "yarn")
public class NodeManagerMetrics {
    @Metric
    MutableCounterInt SYIIJKETOA;

    @Metric
    MutableCounterInt DCAEPOSAPP;

    @Metric
    MutableCounterInt PDZPEEHOWI;

    @Metric
    MutableCounterInt QTEOLAZRFH;

    @Metric("# of initializing containers")
    MutableGaugeInt HZTUFKUOYP;

    @Metric
    MutableGaugeInt BTDIUUGQFP;

    @Metric("Current allocated memory in GB")
    MutableGaugeInt JBSJEOZNVY;

    @Metric("Current # of allocated containers")
    MutableGaugeInt RGMFHNFFJB;

    @Metric
    MutableGaugeInt XNLIZBUCDU;

    @Metric("Current allocated Virtual Cores")
    MutableGaugeInt ZBDMCFJBEJ;

    @Metric
    MutableGaugeInt UTKTNPQPWN;

    public static NodeManagerMetrics create() {
        return NodeManagerMetrics.create(DefaultMetricsSystem.instance());
    }

    static NodeManagerMetrics create(MetricsSystem EUQEQCYSKH) {
        JvmMetrics.create("NodeManager", null, EUQEQCYSKH);
        return EUQEQCYSKH.register(new NodeManagerMetrics());
    }

    // Potential instrumentation interface methods
    public void launchedContainer() {
        SYIIJKETOA.incr();
    }

    public void completedContainer() {
        DCAEPOSAPP.incr();
    }

    public void failedContainer() {
        PDZPEEHOWI.incr();
    }

    public void killedContainer() {
        QTEOLAZRFH.incr();
    }

    public void initingContainer() {
        HZTUFKUOYP.incr();
    }

    public void endInitingContainer() {
        HZTUFKUOYP.decr();
    }

    public void runningContainer() {
        BTDIUUGQFP.incr();
    }

    public void endRunningContainer() {
        BTDIUUGQFP.decr();
    }

    public void allocateContainer(Resource AIXNFEIJLA) {
        RGMFHNFFJB.incr();
        JBSJEOZNVY.incr(AIXNFEIJLA.getMemory() / 1024);
        XNLIZBUCDU.decr(AIXNFEIJLA.getMemory() / 1024);
        ZBDMCFJBEJ.incr(AIXNFEIJLA.getVirtualCores());
        UTKTNPQPWN.decr(AIXNFEIJLA.getVirtualCores());
    }

    public void releaseContainer(Resource XLQCCMHGUP) {
        RGMFHNFFJB.decr();
        JBSJEOZNVY.decr(XLQCCMHGUP.getMemory() / 1024);
        XNLIZBUCDU.incr(XLQCCMHGUP.getMemory() / 1024);
        ZBDMCFJBEJ.decr(XLQCCMHGUP.getVirtualCores());
        UTKTNPQPWN.incr(XLQCCMHGUP.getVirtualCores());
    }

    public void addResource(Resource OUVBNOGLTE) {
        XNLIZBUCDU.incr(OUVBNOGLTE.getMemory() / 1024);
        UTKTNPQPWN.incr(OUVBNOGLTE.getVirtualCores());
    }

    public int getRunningContainers() {
        return BTDIUUGQFP.value();
    }
}