/**
 * A InputFormat that reads input data from an SQL table.
 * Operates like DBInputFormat, but instead of using LIMIT and OFFSET to demarcate
 * splits, it tries to generate WHERE clauses which separate the data into roughly
 * equivalent shards.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class DataDrivenDBInputFormat<T extends DBWritable> extends DBInputFormat<T> implements Configurable {
    private static final Log ZUQDGOBDZM = LogFactory.getLog(DataDrivenDBInputFormat.class);

    /**
     * If users are providing their own query, the following string is expected to
     * appear in the WHERE clause, which will be substituted with a pair of conditions
     * on the input to allow input splits to parallelise the import.
     */
    public static final String RBRBVVZEJP = "$CONDITIONS";

    /**
     * A InputSplit that spans a set of rows
     */
    @InterfaceStability.Evolving
    public static class DataDrivenDBInputSplit extends DBInputFormat.DBInputSplit {
        private String USNMBTHUVE;

        private String NBLIFPYOBN;

        /**
         * Default Constructor
         */
        public DataDrivenDBInputSplit() {
        }

        /**
         * Convenience Constructor
         *
         * @param lower
         * 		the string to be put in the WHERE clause to guard on the 'lower' end
         * @param upper
         * 		the string to be put in the WHERE clause to guard on the 'upper' end
         */
        public DataDrivenDBInputSplit(final String lower, final String upper) {
            this.USNMBTHUVE = lower;
            this.NBLIFPYOBN = upper;
        }

        /**
         *
         *
         * @return The total row count in this split
         */
        public long getLength() throws IOException {
            return 0;// unfortunately, we don't know this.

        }

        /**
         * {@inheritDoc }
         */
        public void readFields(DataInput input) throws IOException {
            this.USNMBTHUVE = Text.readString(input);
            this.NBLIFPYOBN = Text.readString(input);
        }

        /**
         * {@inheritDoc }
         */
        public void write(DataOutput output) throws IOException {
            Text.writeString(output, this.USNMBTHUVE);
            Text.writeString(output, this.NBLIFPYOBN);
        }

        public String getLowerClause() {
            return USNMBTHUVE;
        }

        public String getUpperClause() {
            return NBLIFPYOBN;
        }
    }

    /**
     *
     *
     * @return the DBSplitter implementation to use to divide the table/query into InputSplits.
     */
    protected DBSplitter getSplitter(int DTPICWNRWT) {
        switch (DTPICWNRWT) {
            case Types.NUMERIC :
            case Types.DECIMAL :
                return new BigDecimalSplitter();
            case Types.BIT :
            case Types.BOOLEAN :
                return new BooleanSplitter();
            case Types.INTEGER :
            case Types.TINYINT :
            case Types.SMALLINT :
            case Types.BIGINT :
                return new IntegerSplitter();
            case Types.REAL :
            case Types.FLOAT :
            case Types.DOUBLE :
                return new FloatSplitter();
            case Types.CHAR :
            case Types.VARCHAR :
            case Types.LONGVARCHAR :
                return new TextSplitter();
            case Types.DATE :
            case Types.TIME :
            case Types.TIMESTAMP :
                return new DateSplitter();
            default :
                // TODO: Support BINARY, VARBINARY, LONGVARBINARY, DISTINCT, CLOB, BLOB, ARRAY
                // STRUCT, REF, DATALINK, and JAVA_OBJECT.
                return null;
        }
    }

    /**
     * {@inheritDoc }
     */
    public List<InputSplit> getSplits(JobContext RSQZVVLHWH) throws IOException {
        int RYAKSIJKPT = RSQZVVLHWH.getConfiguration().getInt(MRJobConfig.NUM_MAPS, 1);
        if (1 == RYAKSIJKPT) {
            // There's no need to run a bounding vals query; just return a split
            // that separates nothing. This can be considerably more optimal for a
            // large table with no index.
            List<InputSplit> ZUKMGXIADV = new ArrayList<InputSplit>();
            ZUKMGXIADV.add(new DataDrivenDBInputFormat.DataDrivenDBInputSplit("1=1", "1=1"));
            return ZUKMGXIADV;
        }
        ResultSet FHDQWVGSJT = null;
        Statement UQSDEHJOOZ = null;
        Connection YVOZOKDQSA = DataDrivenDBInputFormat.getConnection();
        try {
            UQSDEHJOOZ = YVOZOKDQSA.createStatement();
            FHDQWVGSJT = UQSDEHJOOZ.executeQuery(getBoundingValsQuery());
            FHDQWVGSJT.next();
            // Based on the type of the results, use a different mechanism
            // for interpolating split points (i.e., numeric splits, text splits,
            // dates, etc.)
            int ZUVJMYTMSB = FHDQWVGSJT.getMetaData().getColumnType(1);
            DBSplitter EZSMTFQDRF = getSplitter(ZUVJMYTMSB);
            if (null == EZSMTFQDRF) {
                throw new IOException("Unknown SQL data type: " + ZUVJMYTMSB);
            }
            return EZSMTFQDRF.split(RSQZVVLHWH.getConfiguration(), FHDQWVGSJT, DataDrivenDBInputFormat.getDBConf().getInputOrderBy());
        } catch (SQLException e) {
            throw new IOException(e.getMessage());
        } finally {
            // More-or-less ignore SQL exceptions here, but log in case we need it.
            try {
                if (null != FHDQWVGSJT) {
                    FHDQWVGSJT.close();
                }
            } catch (SQLException se) {
                DataDrivenDBInputFormat.ZUQDGOBDZM.debug("SQLException closing resultset: " + se.toString());
            }
            try {
                if (null != UQSDEHJOOZ) {
                    UQSDEHJOOZ.close();
                }
            } catch (SQLException se) {
                DataDrivenDBInputFormat.ZUQDGOBDZM.debug("SQLException closing statement: " + se.toString());
            }
            try {
                YVOZOKDQSA.commit();
                DataDrivenDBInputFormat.closeConnection();
            } catch (SQLException se) {
                DataDrivenDBInputFormat.ZUQDGOBDZM.debug("SQLException committing split transaction: " + se.toString());
            }
        }
    }

    /**
     *
     *
     * @return a query which returns the minimum and maximum values for
    the order-by column.

    The min value should be in the first column, and the
    max value should be in the second column of the results.
     */
    protected String getBoundingValsQuery() {
        // If the user has provided a query, use that instead.
        String JLNLSRCXTQ = DataDrivenDBInputFormat.getDBConf().getInputBoundingQuery();
        if (null != JLNLSRCXTQ) {
            return JLNLSRCXTQ;
        }
        // Auto-generate one based on the table name we've been provided with.
        StringBuilder JSVBSNWQYU = new StringBuilder();
        String OWNJSVGNKR = DataDrivenDBInputFormat.getDBConf().getInputOrderBy();
        JSVBSNWQYU.append("SELECT MIN(").append(OWNJSVGNKR).append("), ");
        JSVBSNWQYU.append("MAX(").append(OWNJSVGNKR).append(") FROM ");
        JSVBSNWQYU.append(DataDrivenDBInputFormat.getDBConf().getInputTableName());
        String KTXBGFOPJV = DataDrivenDBInputFormat.getDBConf().getInputConditions();
        if (null != KTXBGFOPJV) {
            JSVBSNWQYU.append((" WHERE ( " + KTXBGFOPJV) + " )");
        }
        return JSVBSNWQYU.toString();
    }

    /**
     * Set the user-defined bounding query to use with a user-defined query.
     * This *must* include the substring "$CONDITIONS"
     * (DataDrivenDBInputFormat.SUBSTITUTE_TOKEN) inside the WHERE clause,
     * so that DataDrivenDBInputFormat knows where to insert split clauses.
     * e.g., "SELECT foo FROM mytable WHERE $CONDITIONS"
     * This will be expanded to something like:
     * SELECT foo FROM mytable WHERE (id &gt; 100) AND (id &lt; 250)
     * inside each split.
     */
    public static void setBoundingQuery(Configuration LRZEUXSYLP, String UDIHKENRVI) {
        if (null != UDIHKENRVI) {
            // If the user's settng a query, warn if they don't allow conditions.
            if (UDIHKENRVI.indexOf(DataDrivenDBInputFormat.RBRBVVZEJP) == (-1)) {
                DataDrivenDBInputFormat.ZUQDGOBDZM.warn(((("Could not find " + DataDrivenDBInputFormat.RBRBVVZEJP) + " token in query: ") + UDIHKENRVI) + "; splits may not partition data.");
            }
        }
        LRZEUXSYLP.set(INPUT_BOUNDING_QUERY, UDIHKENRVI);
    }

    protected RecordReader<LongWritable, T> createDBRecordReader(DBInputSplit SJADBJJJSG, Configuration UUEUIMVLGP) throws IOException {
        DBConfiguration NMSXPQBCMP = DataDrivenDBInputFormat.getDBConf();
        @SuppressWarnings("unchecked")
        Class<T> CTVKPRJILA = ((Class<T>) (NMSXPQBCMP.getInputClass()));
        String XAIEYTJTTH = DataDrivenDBInputFormat.getDBProductName();
        DataDrivenDBInputFormat.ZUQDGOBDZM.debug("Creating db record reader for db product: " + XAIEYTJTTH);
        try {
            // use database product name to determine appropriate record reader.
            if (XAIEYTJTTH.startsWith("MYSQL")) {
                // use MySQL-specific db reader.
                return new MySQLDataDrivenDBRecordReader<T>(SJADBJJJSG, CTVKPRJILA, UUEUIMVLGP, DataDrivenDBInputFormat.getConnection(), NMSXPQBCMP, NMSXPQBCMP.getInputConditions(), NMSXPQBCMP.getInputFieldNames(), NMSXPQBCMP.getInputTableName());
            } else {
                // Generic reader.
                return new DataDrivenDBRecordReader<T>(SJADBJJJSG, CTVKPRJILA, UUEUIMVLGP, DataDrivenDBInputFormat.getConnection(), NMSXPQBCMP, NMSXPQBCMP.getInputConditions(), NMSXPQBCMP.getInputFieldNames(), NMSXPQBCMP.getInputTableName(), XAIEYTJTTH);
            }
        } catch (SQLException ex) {
            throw new IOException(ex.getMessage());
        }
    }

    // Configuration methods override superclass to ensure that the proper
    // DataDrivenDBInputFormat gets used.
    /**
     * Note that the "orderBy" column is called the "splitBy" in this version.
     * We reuse the same field, but it's not strictly ordering it -- just partitioning
     * the results.
     */
    public static void setInput(Job AZMHNUIWZQ, Class<? extends DBWritable> WJRAECXCJO, String CQMNFXFXIH, String WUISUYUYEV, String EFKETIELQB, String... AROKHCSASJ) {
        DBInputFormat.setInput(AZMHNUIWZQ, WJRAECXCJO, CQMNFXFXIH, WUISUYUYEV, EFKETIELQB, AROKHCSASJ);
        AZMHNUIWZQ.setInputFormatClass(DataDrivenDBInputFormat.class);
    }

    /**
     * setInput() takes a custom query and a separate "bounding query" to use
     * instead of the custom "count query" used by DBInputFormat.
     */
    public static void setInput(Job VIXXVVCVAV, Class<? extends DBWritable> WFZBQYOMFZ, String DAIJUDJFTS, String XKXIXSAQKV) {
        DBInputFormat.setInput(VIXXVVCVAV, WFZBQYOMFZ, DAIJUDJFTS, "");
        VIXXVVCVAV.getConfiguration().set(INPUT_BOUNDING_QUERY, XKXIXSAQKV);
        VIXXVVCVAV.setInputFormatClass(DataDrivenDBInputFormat.class);
    }
}