@Private
@Unstable
public class FinishApplicationMasterRequestPBImpl extends FinishApplicationMasterRequest {
    FinishApplicationMasterRequestProto GZAJNNAWPO = FinishApplicationMasterRequestProto.getDefaultInstance();

    Builder LIGLFXFRDS = null;

    boolean IZMDFRKOMO = false;

    public FinishApplicationMasterRequestPBImpl() {
        LIGLFXFRDS = FinishApplicationMasterRequestProto.newBuilder();
    }

    public FinishApplicationMasterRequestPBImpl(FinishApplicationMasterRequestProto FBHNRKUZZE) {
        this.GZAJNNAWPO = FBHNRKUZZE;
        IZMDFRKOMO = true;
    }

    public FinishApplicationMasterRequestProto getProto() {
        mergeLocalToProto();
        GZAJNNAWPO = (IZMDFRKOMO) ? GZAJNNAWPO : LIGLFXFRDS.build();
        IZMDFRKOMO = true;
        return GZAJNNAWPO;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object IEOMTPHVLZ) {
        if (IEOMTPHVLZ == null)
            return false;

        if (IEOMTPHVLZ.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(IEOMTPHVLZ).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }

    private void mergeLocalToBuilder() {
    }

    private void mergeLocalToProto() {
        if (IZMDFRKOMO)
            maybeInitBuilder();

        mergeLocalToBuilder();
        GZAJNNAWPO = LIGLFXFRDS.build();
        IZMDFRKOMO = true;
    }

    private void maybeInitBuilder() {
        if (IZMDFRKOMO || (LIGLFXFRDS == null)) {
            LIGLFXFRDS = FinishApplicationMasterRequestProto.newBuilder(GZAJNNAWPO);
        }
        IZMDFRKOMO = false;
    }

    @Override
    public String getDiagnostics() {
        FinishApplicationMasterRequestProtoOrBuilder XVMFYKYSJP = (IZMDFRKOMO) ? GZAJNNAWPO : LIGLFXFRDS;
        return XVMFYKYSJP.getDiagnostics();
    }

    @Override
    public void setDiagnostics(String YWEEBMCZXD) {
        maybeInitBuilder();
        if (YWEEBMCZXD == null) {
            LIGLFXFRDS.clearDiagnostics();
            return;
        }
        LIGLFXFRDS.setDiagnostics(YWEEBMCZXD);
    }

    @Override
    public String getTrackingUrl() {
        FinishApplicationMasterRequestProtoOrBuilder DLMEJZMTQN = (IZMDFRKOMO) ? GZAJNNAWPO : LIGLFXFRDS;
        return DLMEJZMTQN.getTrackingUrl();
    }

    @Override
    public void setTrackingUrl(String KNRTLJFLXA) {
        maybeInitBuilder();
        if (KNRTLJFLXA == null) {
            LIGLFXFRDS.clearTrackingUrl();
            return;
        }
        LIGLFXFRDS.setTrackingUrl(KNRTLJFLXA);
    }

    @Override
    public FinalApplicationStatus getFinalApplicationStatus() {
        FinishApplicationMasterRequestProtoOrBuilder BERIDUVXLZ = (IZMDFRKOMO) ? GZAJNNAWPO : LIGLFXFRDS;
        if (!BERIDUVXLZ.hasFinalApplicationStatus()) {
            return null;
        }
        return convertFromProtoFormat(BERIDUVXLZ.getFinalApplicationStatus());
    }

    @Override
    public void setFinalApplicationStatus(FinalApplicationStatus KCOLAMUVKE) {
        maybeInitBuilder();
        if (KCOLAMUVKE == null) {
            LIGLFXFRDS.clearFinalApplicationStatus();
            return;
        }
        LIGLFXFRDS.setFinalApplicationStatus(convertToProtoFormat(KCOLAMUVKE));
    }

    private FinalApplicationStatus convertFromProtoFormat(FinalApplicationStatusProto RUDPHNDIYK) {
        return ProtoUtils.convertFromProtoFormat(RUDPHNDIYK);
    }

    private FinalApplicationStatusProto convertToProtoFormat(FinalApplicationStatus SRMYQWHHTS) {
        return ProtoUtils.convertToProtoFormat(SRMYQWHHTS);
    }
}