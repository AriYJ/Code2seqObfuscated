/**
 * This exception is thrown when an application provides an invalid
 * {@link ResourceBlacklistRequest} specification for blacklisting of resources
 * in {@link ApplicationMasterProtocol#allocate(AllocateRequest)} API.
 *
 * Currently this exceptions is thrown when an application tries to
 * blacklist {@link ResourceRequest#ANY}.
 */
public class InvalidResourceBlacklistRequestException extends YarnException {
    private static final long HQONOAXUZV = 384957911L;

    public InvalidResourceBlacklistRequestException(Throwable OPLAPWRBMK) {
        super(OPLAPWRBMK);
    }

    public InvalidResourceBlacklistRequestException(String BMEWUVDORD) {
        super(BMEWUVDORD);
    }

    public InvalidResourceBlacklistRequestException(String TYPBGWYKZQ, Throwable PLJOZRUBGI) {
        super(TYPBGWYKZQ, PLJOZRUBGI);
    }
}