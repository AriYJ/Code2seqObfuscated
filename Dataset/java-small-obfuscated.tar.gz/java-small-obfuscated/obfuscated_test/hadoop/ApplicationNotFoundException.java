/**
 * This exception is thrown on
 * {@link ApplicationClientProtocol#getApplicationReport
 * (GetApplicationReportRequest)} API
 * when the Application doesn't exist in RM and AHS
 */
@Public
@Unstable
public class ApplicationNotFoundException extends YarnException {
    private static final long JOFKLQJMRG = 8694408L;

    public ApplicationNotFoundException(Throwable AXNJZHIGKL) {
        super(AXNJZHIGKL);
    }

    public ApplicationNotFoundException(String TSWWEILMRM) {
        super(TSWWEILMRM);
    }

    public ApplicationNotFoundException(String PJJQAFICEN, Throwable UFSTYWAVEA) {
        super(PJJQAFICEN, UFSTYWAVEA);
    }
}