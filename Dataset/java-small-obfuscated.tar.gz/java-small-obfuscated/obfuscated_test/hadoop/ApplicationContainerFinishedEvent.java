public class ApplicationContainerFinishedEvent extends ApplicationEvent {
    private ContainerId LFGFMGXABU;

    public ApplicationContainerFinishedEvent(ContainerId YBYNHOUUWN) {
        super(YBYNHOUUWN.getApplicationAttemptId().getApplicationId(), APPLICATION_CONTAINER_FINISHED);
        this.LFGFMGXABU = YBYNHOUUWN;
    }

    public ContainerId getContainerID() {
        return this.LFGFMGXABU;
    }
}