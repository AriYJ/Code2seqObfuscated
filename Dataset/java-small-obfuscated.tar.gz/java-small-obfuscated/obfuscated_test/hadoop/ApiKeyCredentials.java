/**
 * Describes credentials to log in Swift using Keystone authentication.
 * THIS FILE IS MAPPED BY JACKSON TO AND FROM JSON.
 * DO NOT RENAME OR MODIFY FIELDS AND THEIR ACCESSORS.
 */
public class ApiKeyCredentials {
    /**
     * user login
     */
    private String LYDXXHMVOT;

    /**
     * user password
     */
    private String PSXOYXOCOD;

    /**
     * default constructor
     */
    public ApiKeyCredentials() {
    }

    /**
     *
     *
     * @param username
     * 		user login
     * @param apikey
     * 		user api key
     */
    public ApiKeyCredentials(String PTHIDKSGXK, String VAVOGIPTHF) {
        this.LYDXXHMVOT = PTHIDKSGXK;
        this.PSXOYXOCOD = VAVOGIPTHF;
    }

    /**
     *
     *
     * @return user api key
     */
    public String getApiKey() {
        return PSXOYXOCOD;
    }

    /**
     *
     *
     * @param apikey
     * 		user api key
     */
    public void setApiKey(String YZBUBEBQXK) {
        this.PSXOYXOCOD = YZBUBEBQXK;
    }

    /**
     *
     *
     * @return login
     */
    public String getUsername() {
        return LYDXXHMVOT;
    }

    /**
     *
     *
     * @param username
     * 		login
     */
    public void setUsername(String TNAZUHNXLD) {
        this.LYDXXHMVOT = TNAZUHNXLD;
    }

    @Override
    public String toString() {
        return (((("user " + "'") + LYDXXHMVOT) + '\'') + " with key of length ") + (PSXOYXOCOD == null ? 0 : PSXOYXOCOD.length());
    }
}