/**
 * Class provides basic fault injection tests according to the test plan
 * of HDFS-265
 */
public class TestFiHFlush {
    /**
     * Methods initializes a test and sets required actions to be used later by
     * an injected advice
     *
     * @param conf
     * 		mini cluster configuration
     * @param methodName
     * 		String representation of a test method invoking this
     * 		method
     * @param block_size
     * 		needed size of file's block
     * @param a
     * 		is an action to be set for the set
     * @throws IOException
     * 		in case of any errors
     */
    private static void runDiskErrorTest(final Configuration XOSRRPLWGL, final String WJORTHIWQB, final int LOZEIYFIVP, DerrAction DRCURFVCYU, int OKLADEHVLY, boolean CGIHISLDIV) throws IOException {
        LOG.info(("Running " + WJORTHIWQB) + " ...");
        final HFlushTest RQOTXSUUJG = ((HFlushTest) (FiHFlushTestUtil.initTest()));
        RQOTXSUUJG.fiCallHFlush.set(DRCURFVCYU);
        RQOTXSUUJG.fiErrorOnCallHFlush.set(new DataTransferTestUtil.VerificationAction(WJORTHIWQB, OKLADEHVLY));
        TestHFlush.doTheJob(XOSRRPLWGL, WJORTHIWQB, LOZEIYFIVP, ((short) (3)));
        if (CGIHISLDIV)
            assertTrue("Some of expected conditions weren't detected", RQOTXSUUJG.isSuccess());

    }

    /**
     * The tests calls
     * {@link #runDiskErrorTest(Configuration, String, int, DerrAction, int, boolean)}
     * to make a number of writes within a block boundaries.
     * Although hflush() is called the test shouldn't expect an IOException
     * in this case because the invocation is happening after write() call
     * is complete when pipeline doesn't exist anymore.
     * Thus, injected fault won't be triggered for 0th datanode
     */
    @Test
    public void hFlushFi01_a() throws IOException {
        final String SPWZLYCWFF = FiTestUtil.getMethodName();
        TestFiHFlush.runDiskErrorTest(new HdfsConfiguration(), SPWZLYCWFF, BLOCK_SIZE, new DerrAction(SPWZLYCWFF, 0), 0, false);
    }

    /**
     * The tests calls
     * {@link #runDiskErrorTest(Configuration, String, int, DerrAction, int, boolean)}
     * to make a number of writes across a block boundaries.
     * hflush() is called after each write() during a pipeline life time.
     * Thus, injected fault ought to be triggered for 0th datanode
     */
    @Test
    public void hFlushFi01_b() throws IOException {
        final String PSYRTWOFDW = FiTestUtil.getMethodName();
        Configuration CGIWTTSLMY = new HdfsConfiguration();
        int ZPERSXHORF = 512;
        int MDAIFFXCWO = ZPERSXHORF * 3;
        CGIWTTSLMY.setInt(DFS_BYTES_PER_CHECKSUM_KEY, ZPERSXHORF);
        CGIWTTSLMY.setLong(DFS_BLOCK_SIZE_KEY, MDAIFFXCWO);
        TestFiHFlush.runDiskErrorTest(CGIWTTSLMY, PSYRTWOFDW, MDAIFFXCWO, new DerrAction(PSYRTWOFDW, 0), 0, true);
    }

    /**
     * Similar to {@link #hFlushFi01_b()} but writing happens
     * across block and checksum's boundaries
     */
    @Test
    public void hFlushFi01_c() throws Exception {
        final String DDDMAAICTB = FiTestUtil.getMethodName();
        Configuration PSKFPMFAHG = new HdfsConfiguration();
        int XSSBLPPWBY = 400;
        int RUBDJLOXCD = XSSBLPPWBY * 3;
        PSKFPMFAHG.setInt(DFS_BYTES_PER_CHECKSUM_KEY, XSSBLPPWBY);
        PSKFPMFAHG.setLong(DFS_BLOCK_SIZE_KEY, RUBDJLOXCD);
        TestFiHFlush.runDiskErrorTest(PSKFPMFAHG, DDDMAAICTB, RUBDJLOXCD, new DerrAction(DDDMAAICTB, 0), 0, true);
    }

    /**
     * Similar to {@link #hFlushFi01_a()} but for a pipeline's 1st datanode
     */
    @Test
    public void hFlushFi02_a() throws IOException {
        final String WAZBEUTCTK = FiTestUtil.getMethodName();
        TestFiHFlush.runDiskErrorTest(new HdfsConfiguration(), WAZBEUTCTK, BLOCK_SIZE, new DerrAction(WAZBEUTCTK, 1), 1, false);
    }

    /**
     * Similar to {@link #hFlushFi01_b()} but for a pipeline's 1st datanode
     */
    @Test
    public void hFlushFi02_b() throws IOException {
        final String RVQJAXXVTI = FiTestUtil.getMethodName();
        Configuration KFLHXQAFLB = new HdfsConfiguration();
        int CFSDKCKOSG = 512;
        int DMXWIIBLYM = CFSDKCKOSG * 3;
        KFLHXQAFLB.setInt(DFS_BYTES_PER_CHECKSUM_KEY, CFSDKCKOSG);
        KFLHXQAFLB.setLong(DFS_BLOCK_SIZE_KEY, DMXWIIBLYM);
        TestFiHFlush.runDiskErrorTest(KFLHXQAFLB, RVQJAXXVTI, DMXWIIBLYM, new DerrAction(RVQJAXXVTI, 1), 1, true);
    }

    /**
     * Similar to {@link #hFlushFi01_c()} but for a pipeline's 1st datanode
     */
    @Test
    public void hFlushFi02_c() throws IOException {
        final String GXVFRARCVC = FiTestUtil.getMethodName();
        Configuration HWHIFHRBRB = new HdfsConfiguration();
        int YXJSTUHXJS = 400;
        int QYEJVFTTBF = YXJSTUHXJS * 3;
        HWHIFHRBRB.setInt(DFS_BYTES_PER_CHECKSUM_KEY, YXJSTUHXJS);
        HWHIFHRBRB.setLong(DFS_BLOCK_SIZE_KEY, QYEJVFTTBF);
        TestFiHFlush.runDiskErrorTest(HWHIFHRBRB, GXVFRARCVC, QYEJVFTTBF, new DerrAction(GXVFRARCVC, 1), 1, true);
    }

    /**
     * Similar to {@link #hFlushFi01_a()} but for a pipeline's 2nd datanode
     */
    @Test
    public void hFlushFi03_a() throws IOException {
        final String YPYROHNQRU = FiTestUtil.getMethodName();
        TestFiHFlush.runDiskErrorTest(new HdfsConfiguration(), YPYROHNQRU, BLOCK_SIZE, new DerrAction(YPYROHNQRU, 2), 2, false);
    }

    /**
     * Similar to {@link #hFlushFi01_b()} but for a pipeline's 2nd datanode
     */
    @Test
    public void hFlushFi03_b() throws IOException {
        final String REHGPQTDTI = FiTestUtil.getMethodName();
        Configuration UYDAOENEIR = new HdfsConfiguration();
        int YMUIVOVEWD = 512;
        int RRPSKBUFKH = YMUIVOVEWD * 3;
        UYDAOENEIR.setInt(DFS_BYTES_PER_CHECKSUM_KEY, YMUIVOVEWD);
        UYDAOENEIR.setLong(DFS_BLOCK_SIZE_KEY, RRPSKBUFKH);
        TestFiHFlush.runDiskErrorTest(UYDAOENEIR, REHGPQTDTI, RRPSKBUFKH, new DerrAction(REHGPQTDTI, 2), 2, true);
    }

    /**
     * Similar to {@link #hFlushFi01_c()} but for a pipeline's 2nd datanode
     */
    @Test
    public void hFlushFi03_c() throws IOException {
        final String NYBLDKJVAT = FiTestUtil.getMethodName();
        Configuration QJPFCESDGZ = new HdfsConfiguration();
        int YENPHUJXAI = 400;
        int HJPSYAAVMQ = YENPHUJXAI * 3;
        QJPFCESDGZ.setInt(DFS_BYTES_PER_CHECKSUM_KEY, YENPHUJXAI);
        QJPFCESDGZ.setLong(DFS_BLOCK_SIZE_KEY, HJPSYAAVMQ);
        TestFiHFlush.runDiskErrorTest(QJPFCESDGZ, NYBLDKJVAT, HJPSYAAVMQ, new DerrAction(NYBLDKJVAT, 2), 2, true);
    }
}