/**
 * Test WebHDFS with multiple NameNodes
 */
public class TestWebHdfsWithMultipleNameNodes {
    static final Log VORBNLQXBW = WebHdfsTestUtil.LOG;

    private static void setLogLevel() {
        ((org.apache.commons.logging.impl.Log4JLogger) (TestWebHdfsWithMultipleNameNodes.VORBNLQXBW)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (NamenodeWebHdfsMethods.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (NameNode.stateChangeLog)).getLogger().setLevel(Level.OFF);
        ((org.apache.commons.logging.impl.Log4JLogger) (LeaseManager.LOG)).getLogger().setLevel(Level.OFF);
        ((org.apache.commons.logging.impl.Log4JLogger) (org.apache.commons.logging.LogFactory.getLog(org.apache.hadoop.hdfs.server.namenode.FSNamesystem.class))).getLogger().setLevel(Level.OFF);
    }

    private static final Configuration ESRLDRZLJQ = new HdfsConfiguration();

    private static MiniDFSCluster JCDSSNEAFL;

    private static WebHdfsFileSystem[] SVCXMJQXED;

    @BeforeClass
    public static void setupTest() {
        TestWebHdfsWithMultipleNameNodes.setLogLevel();
        try {
            TestWebHdfsWithMultipleNameNodes.setupCluster(4, 3);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void setupCluster(final int CYSEUWRKMF, final int NDOKNWWPRC) throws Exception {
        TestWebHdfsWithMultipleNameNodes.VORBNLQXBW.info((("nNameNodes=" + CYSEUWRKMF) + ", nDataNodes=") + NDOKNWWPRC);
        TestWebHdfsWithMultipleNameNodes.ESRLDRZLJQ.setBoolean(DFS_WEBHDFS_ENABLED_KEY, true);
        TestWebHdfsWithMultipleNameNodes.JCDSSNEAFL = new MiniDFSCluster.Builder(TestWebHdfsWithMultipleNameNodes.ESRLDRZLJQ).nnTopology(org.apache.hadoop.hdfs.MiniDFSNNTopology.simpleFederatedTopology(CYSEUWRKMF)).numDataNodes(NDOKNWWPRC).build();
        TestWebHdfsWithMultipleNameNodes.JCDSSNEAFL.waitActive();
        TestWebHdfsWithMultipleNameNodes.SVCXMJQXED = new WebHdfsFileSystem[CYSEUWRKMF];
        for (int BRZDZWYMRA = 0; BRZDZWYMRA < TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length; BRZDZWYMRA++) {
            final InetSocketAddress URLNDVVYIK = TestWebHdfsWithMultipleNameNodes.JCDSSNEAFL.getNameNode(BRZDZWYMRA).getHttpAddress();
            final String CRKNRLMGSY = ((((WebHdfsFileSystem.SCHEME + "://") + URLNDVVYIK.getHostName()) + ":") + URLNDVVYIK.getPort()) + "/";
            TestWebHdfsWithMultipleNameNodes.SVCXMJQXED[BRZDZWYMRA] = ((WebHdfsFileSystem) (FileSystem.get(new URI(CRKNRLMGSY), TestWebHdfsWithMultipleNameNodes.ESRLDRZLJQ)));
        }
    }

    @AfterClass
    public static void shutdownCluster() {
        if (TestWebHdfsWithMultipleNameNodes.JCDSSNEAFL != null) {
            TestWebHdfsWithMultipleNameNodes.JCDSSNEAFL.shutdown();
            TestWebHdfsWithMultipleNameNodes.JCDSSNEAFL = null;
        }
    }

    private static String createString(String MVHKAAYKWZ, int FYRJXUAAIB) {
        // The suffix is to make sure the strings have different lengths.
        final String WBQFTEGMIP = "*********************".substring(0, FYRJXUAAIB + 1);
        return ((MVHKAAYKWZ + FYRJXUAAIB) + WBQFTEGMIP) + "\n";
    }

    private static String[] createStrings(String GBPOHLPUTJ, String EQZYFXKJRE) {
        final String[] WMPTGPULMG = new String[TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length];
        for (int WGWUUYFNVG = 0; WGWUUYFNVG < TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length; WGWUUYFNVG++) {
            WMPTGPULMG[WGWUUYFNVG] = TestWebHdfsWithMultipleNameNodes.createString(GBPOHLPUTJ, WGWUUYFNVG);
            TestWebHdfsWithMultipleNameNodes.VORBNLQXBW.info((((EQZYFXKJRE + "[") + WGWUUYFNVG) + "] = ") + WMPTGPULMG[WGWUUYFNVG]);
        }
        return WMPTGPULMG;
    }

    @Test
    public void testRedirect() throws Exception {
        final String UFSGVKUFXX = "/testRedirect/";
        final String ZTSENEWKCY = "file";
        final Path FLIUMSLNWM = new Path(UFSGVKUFXX, ZTSENEWKCY);
        final String[] RRBGCYUFAJ = TestWebHdfsWithMultipleNameNodes.createStrings("write to webhdfs ", "write");
        final String[] QADTGLXQBM = TestWebHdfsWithMultipleNameNodes.createStrings("append to webhdfs ", "append");
        // test create: create a file for each namenode
        for (int ACXLUWQHIU = 0; ACXLUWQHIU < TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length; ACXLUWQHIU++) {
            final FSDataOutputStream YNAJYKPLQW = TestWebHdfsWithMultipleNameNodes.SVCXMJQXED[ACXLUWQHIU].create(FLIUMSLNWM);
            YNAJYKPLQW.write(RRBGCYUFAJ[ACXLUWQHIU].getBytes());
            YNAJYKPLQW.close();
        }
        for (int AYIGKLVLMJ = 0; AYIGKLVLMJ < TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length; AYIGKLVLMJ++) {
            // check file length
            final long YQTLPXPJND = RRBGCYUFAJ[AYIGKLVLMJ].length();
            Assert.assertEquals(YQTLPXPJND, TestWebHdfsWithMultipleNameNodes.SVCXMJQXED[AYIGKLVLMJ].getFileStatus(FLIUMSLNWM).getLen());
        }
        // test read: check file content for each namenode
        for (int PCIOGGZTOG = 0; PCIOGGZTOG < TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length; PCIOGGZTOG++) {
            final FSDataInputStream LNKRWVZEMK = TestWebHdfsWithMultipleNameNodes.SVCXMJQXED[PCIOGGZTOG].open(FLIUMSLNWM);
            for (int TJDJGIGUDT, PKDLZJBEGM = 0; (TJDJGIGUDT = LNKRWVZEMK.read()) != (-1); PKDLZJBEGM++) {
                Assert.assertEquals(RRBGCYUFAJ[PCIOGGZTOG].charAt(PKDLZJBEGM), TJDJGIGUDT);
            }
            LNKRWVZEMK.close();
        }
        // test append: append to the file for each namenode
        for (int RPHONKKCZV = 0; RPHONKKCZV < TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length; RPHONKKCZV++) {
            final FSDataOutputStream XMWKRIVZGA = TestWebHdfsWithMultipleNameNodes.SVCXMJQXED[RPHONKKCZV].append(FLIUMSLNWM);
            XMWKRIVZGA.write(QADTGLXQBM[RPHONKKCZV].getBytes());
            XMWKRIVZGA.close();
        }
        for (int TXFDOWEQXZ = 0; TXFDOWEQXZ < TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length; TXFDOWEQXZ++) {
            // check file length
            final long IGOEQDLQPW = RRBGCYUFAJ[TXFDOWEQXZ].length() + QADTGLXQBM[TXFDOWEQXZ].length();
            Assert.assertEquals(IGOEQDLQPW, TestWebHdfsWithMultipleNameNodes.SVCXMJQXED[TXFDOWEQXZ].getFileStatus(FLIUMSLNWM).getLen());
        }
        // test read: check file content for each namenode
        for (int QUKWENSFWU = 0; QUKWENSFWU < TestWebHdfsWithMultipleNameNodes.SVCXMJQXED.length; QUKWENSFWU++) {
            final StringBuilder GDVPLSNIAS = new StringBuilder();
            final FSDataInputStream MAJESFKWFD = TestWebHdfsWithMultipleNameNodes.SVCXMJQXED[QUKWENSFWU].open(FLIUMSLNWM);
            for (int IKRAOZYQAK; (IKRAOZYQAK = MAJESFKWFD.read()) != (-1);) {
                GDVPLSNIAS.append(((char) (IKRAOZYQAK)));
            }
            final int ZHZCCHUAIF = RRBGCYUFAJ[QUKWENSFWU].length();
            Assert.assertEquals(RRBGCYUFAJ[QUKWENSFWU], GDVPLSNIAS.substring(0, ZHZCCHUAIF));
            Assert.assertEquals(QADTGLXQBM[QUKWENSFWU], GDVPLSNIAS.substring(ZHZCCHUAIF));
            MAJESFKWFD.close();
        }
    }
}