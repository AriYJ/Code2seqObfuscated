/**
 * This partitioner rehashes values returned by {@link Object#hashCode()}
 *  to get smoother distribution between partitions which may improve
 *  reduce reduce time in some cases and should harm things in no cases.
 *  This partitioner is suggested with Integer and Long keys with simple
 *  patterns in their distributions.
 *
 * @since 2.0.3
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class RehashPartitioner<K, V> extends Partitioner<K, V> {
    /**
     * prime number seed for increasing hash quality
     */
    private static final int PZKLHCSRBQ = 1591267453;

    /**
     * Rehash {@link Object#hashCode()} to partition.
     */
    public int getPartition(K NMLYBXJELJ, V NKCIVTWCDZ, int QKKEJVYGTZ) {
        int IBZBOHSEII = RehashPartitioner.PZKLHCSRBQ ^ NMLYBXJELJ.hashCode();
        IBZBOHSEII ^= (IBZBOHSEII >>> 20) ^ (IBZBOHSEII >>> 12);
        IBZBOHSEII = (IBZBOHSEII ^ (IBZBOHSEII >>> 7)) ^ (IBZBOHSEII >>> 4);
        return (IBZBOHSEII & Integer.MAX_VALUE) % QKKEJVYGTZ;
    }
}