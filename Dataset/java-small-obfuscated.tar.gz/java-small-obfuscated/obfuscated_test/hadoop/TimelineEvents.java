/**
 * The class that hosts a list of events, which are categorized according to
 * their related entities.
 */
@XmlRootElement(name = "events")
@XmlAccessorType(XmlAccessType.NONE)
@Public
@Unstable
public class TimelineEvents {
    private List<TimelineEvents.EventsOfOneEntity> JUCVQBCUVZ = new ArrayList<TimelineEvents.EventsOfOneEntity>();

    public TimelineEvents() {
    }

    /**
     * Get a list of {@link EventsOfOneEntity} instances
     *
     * @return a list of {@link EventsOfOneEntity} instances
     */
    @XmlElement(name = "events")
    public List<TimelineEvents.EventsOfOneEntity> getAllEvents() {
        return JUCVQBCUVZ;
    }

    /**
     * Add a single {@link EventsOfOneEntity} instance into the existing list
     *
     * @param eventsOfOneEntity
     * 		a single {@link EventsOfOneEntity} instance
     */
    public void addEvent(TimelineEvents.EventsOfOneEntity IWGXGSMSAS) {
        JUCVQBCUVZ.add(IWGXGSMSAS);
    }

    /**
     * Add a list of {@link EventsOfOneEntity} instances into the existing list
     *
     * @param allEvents
     * 		a list of {@link EventsOfOneEntity} instances
     */
    public void addEvents(List<TimelineEvents.EventsOfOneEntity> NVLXQFMGEK) {
        this.JUCVQBCUVZ.addAll(NVLXQFMGEK);
    }

    /**
     * Set the list to the given list of {@link EventsOfOneEntity} instances
     *
     * @param allEvents
     * 		a list of {@link EventsOfOneEntity} instances
     */
    public void setEvents(List<TimelineEvents.EventsOfOneEntity> WCVSQQPOCB) {
        this.JUCVQBCUVZ.clear();
        this.JUCVQBCUVZ.addAll(WCVSQQPOCB);
    }

    /**
     * The class that hosts a list of events that are only related to one entity.
     */
    @XmlRootElement(name = "events")
    @XmlAccessorType(XmlAccessType.NONE)
    @Public
    @Unstable
    public static class EventsOfOneEntity {
        private String TRUAPKTQZP;

        private String MJNLOPGXEW;

        private List<TimelineEvent> ZBKWUMJWLE = new ArrayList<TimelineEvent>();

        public EventsOfOneEntity() {
        }

        /**
         * Get the entity Id
         *
         * @return the entity Id
         */
        @XmlElement(name = "entity")
        public String getEntityId() {
            return TRUAPKTQZP;
        }

        /**
         * Set the entity Id
         *
         * @param entityId
         * 		the entity Id
         */
        public void setEntityId(String entityId) {
            this.TRUAPKTQZP = entityId;
        }

        /**
         * Get the entity type
         *
         * @return the entity type
         */
        @XmlElement(name = "entitytype")
        public String getEntityType() {
            return MJNLOPGXEW;
        }

        /**
         * Set the entity type
         *
         * @param entityType
         * 		the entity type
         */
        public void setEntityType(String entityType) {
            this.MJNLOPGXEW = entityType;
        }

        /**
         * Get a list of events
         *
         * @return a list of events
         */
        @XmlElement(name = "events")
        public List<TimelineEvent> getEvents() {
            return ZBKWUMJWLE;
        }

        /**
         * Add a single event to the existing event list
         *
         * @param event
         * 		a single event
         */
        public void addEvent(TimelineEvent event) {
            ZBKWUMJWLE.add(event);
        }

        /**
         * Add a list of event to the existing event list
         *
         * @param events
         * 		a list of events
         */
        public void addEvents(List<TimelineEvent> events) {
            this.ZBKWUMJWLE.addAll(events);
        }

        /**
         * Set the event list to the given list of events
         *
         * @param events
         * 		a list of events
         */
        public void setEvents(List<TimelineEvent> events) {
            this.ZBKWUMJWLE = events;
        }
    }
}