public class TestKeyProviderCryptoExtension {
    private static final String CDLMMQWBZE = "AES";

    private static final String IJVNMMRIMD = "fooKey";

    private static Configuration DVRNEZPHDQ;

    private static KeyProvider JJZQJJDFXH;

    private static KeyProviderCryptoExtension EYCXMGKEQP;

    private static Options XGPDQNEOWT;

    private static KeyProvider.KeyVersion UGNJGQDAWW;

    @BeforeClass
    public static void setup() throws Exception {
        TestKeyProviderCryptoExtension.DVRNEZPHDQ = new Configuration();
        TestKeyProviderCryptoExtension.JJZQJJDFXH = new UserProvider.Factory().createProvider(new URI("user:///"), TestKeyProviderCryptoExtension.DVRNEZPHDQ);
        TestKeyProviderCryptoExtension.EYCXMGKEQP = KeyProviderCryptoExtension.createKeyProviderCryptoExtension(TestKeyProviderCryptoExtension.JJZQJJDFXH);
        TestKeyProviderCryptoExtension.XGPDQNEOWT = new KeyProvider.Options(TestKeyProviderCryptoExtension.DVRNEZPHDQ);
        TestKeyProviderCryptoExtension.XGPDQNEOWT.setCipher(TestKeyProviderCryptoExtension.CDLMMQWBZE);
        TestKeyProviderCryptoExtension.XGPDQNEOWT.setBitLength(128);
        TestKeyProviderCryptoExtension.UGNJGQDAWW = TestKeyProviderCryptoExtension.JJZQJJDFXH.createKey(TestKeyProviderCryptoExtension.IJVNMMRIMD, SecureRandom.getSeed(16), TestKeyProviderCryptoExtension.XGPDQNEOWT);
    }

    @Test
    public void testGenerateEncryptedKey() throws Exception {
        // Generate a new EEK and check it
        KeyProviderCryptoExtension.EncryptedKeyVersion NTUAKGDMUZ = TestKeyProviderCryptoExtension.EYCXMGKEQP.generateEncryptedKey(TestKeyProviderCryptoExtension.UGNJGQDAWW.getName());
        assertEquals("Version name of EEK should be EEK", KeyProviderCryptoExtension.EEK, NTUAKGDMUZ.getEncryptedKeyVersion().getVersionName());
        assertEquals("Name of EEK should be encryption key name", TestKeyProviderCryptoExtension.IJVNMMRIMD, NTUAKGDMUZ.getEncryptionKeyName());
        assertNotNull("Expected encrypted key material", NTUAKGDMUZ.getEncryptedKeyVersion().getMaterial());
        assertEquals("Length of encryption key material and EEK material should " + "be the same", TestKeyProviderCryptoExtension.UGNJGQDAWW.getMaterial().length, NTUAKGDMUZ.getEncryptedKeyVersion().getMaterial().length);
        // Decrypt EEK into an EK and check it
        KeyProvider.KeyVersion IIGNORQSYR = TestKeyProviderCryptoExtension.EYCXMGKEQP.decryptEncryptedKey(NTUAKGDMUZ);
        assertEquals(KeyProviderCryptoExtension.EK, IIGNORQSYR.getVersionName());
        assertEquals(TestKeyProviderCryptoExtension.UGNJGQDAWW.getMaterial().length, IIGNORQSYR.getMaterial().length);
        if (Arrays.equals(IIGNORQSYR.getMaterial(), TestKeyProviderCryptoExtension.UGNJGQDAWW.getMaterial())) {
            fail("Encrypted key material should not equal encryption key material");
        }
        if (Arrays.equals(NTUAKGDMUZ.getEncryptedKeyVersion().getMaterial(), TestKeyProviderCryptoExtension.UGNJGQDAWW.getMaterial())) {
            fail("Encrypted key material should not equal decrypted key material");
        }
        // Decrypt it again and it should be the same
        KeyProvider.KeyVersion BAXTBXAJXI = TestKeyProviderCryptoExtension.EYCXMGKEQP.decryptEncryptedKey(NTUAKGDMUZ);
        assertArrayEquals(IIGNORQSYR.getMaterial(), BAXTBXAJXI.getMaterial());
        // Generate another EEK and make sure it's different from the first
        KeyProviderCryptoExtension.EncryptedKeyVersion NIOAQYNDNK = TestKeyProviderCryptoExtension.EYCXMGKEQP.generateEncryptedKey(TestKeyProviderCryptoExtension.UGNJGQDAWW.getName());
        KeyProvider.KeyVersion USHWGJRVEE = TestKeyProviderCryptoExtension.EYCXMGKEQP.decryptEncryptedKey(NIOAQYNDNK);
        if (Arrays.equals(IIGNORQSYR.getMaterial(), USHWGJRVEE.getMaterial())) {
            fail("Generated EEKs should have different material!");
        }
        if (Arrays.equals(NTUAKGDMUZ.getEncryptedKeyIv(), NIOAQYNDNK.getEncryptedKeyIv())) {
            fail("Generated EEKs should have different IVs!");
        }
    }

    @Test
    public void testEncryptDecrypt() throws Exception {
        // Get an EEK
        KeyProviderCryptoExtension.EncryptedKeyVersion HNYSCKZIVK = TestKeyProviderCryptoExtension.EYCXMGKEQP.generateEncryptedKey(TestKeyProviderCryptoExtension.UGNJGQDAWW.getName());
        final byte[] HMOOAUFPDF = HNYSCKZIVK.getEncryptedKeyIv();
        final byte[] XTKDAZTHRQ = HNYSCKZIVK.getEncryptedKeyVersion().getMaterial();
        // Decrypt it manually
        Cipher GQTECQYHPV = Cipher.getInstance("AES/CTR/NoPadding");
        GQTECQYHPV.init(Cipher.DECRYPT_MODE, new SecretKeySpec(TestKeyProviderCryptoExtension.UGNJGQDAWW.getMaterial(), "AES"), new IvParameterSpec(KeyProviderCryptoExtension.EncryptedKeyVersion.deriveIV(HMOOAUFPDF)));
        final byte[] KNJAOIMGVH = GQTECQYHPV.doFinal(XTKDAZTHRQ);
        // Test the createForDecryption factory method
        EncryptedKeyVersion PKFVXLDSYL = EncryptedKeyVersion.createForDecryption(HNYSCKZIVK.getEncryptionKeyVersionName(), HNYSCKZIVK.getEncryptedKeyIv(), HNYSCKZIVK.getEncryptedKeyVersion().getMaterial());
        // Decrypt it with the API
        KeyProvider.KeyVersion GOQNDKYFKE = TestKeyProviderCryptoExtension.EYCXMGKEQP.decryptEncryptedKey(PKFVXLDSYL);
        final byte[] FSRGBHSTNK = GOQNDKYFKE.getMaterial();
        assertArrayEquals("Wrong key material from decryptEncryptedKey", KNJAOIMGVH, FSRGBHSTNK);
    }
}