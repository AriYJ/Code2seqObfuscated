/**
 * Manages caching for an FsDatasetImpl by using the mmap(2) and mlock(2)
 * system calls to lock blocks into memory. Block checksums are verified upon
 * entry into the cache.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class FsDatasetCache {
    /**
     * MappableBlocks that we know about.
     */
    private static final class Value {
        final FsDatasetCache.State ENXDAUFZSK;

        final MappableBlock FNAUMLDSHS;

        Value(MappableBlock mappableBlock, FsDatasetCache.State state) {
            this.FNAUMLDSHS = mappableBlock;
            this.ENXDAUFZSK = state;
        }
    }

    private enum State {

        /**
         * The MappableBlock is in the process of being cached.
         */
        CACHING,
        /**
         * The MappableBlock was in the process of being cached, but it was
         * cancelled.  Only the FsDatasetCache#WorkerTask can remove cancelled
         * MappableBlock objects.
         */
        CACHING_CANCELLED,
        /**
         * The MappableBlock is in the cache.
         */
        CACHED,
        /**
         * The MappableBlock is in the process of uncaching.
         */
        UNCACHING;
        /**
         * Whether we should advertise this block as cached to the NameNode and
         * clients.
         */
        public boolean shouldAdvertise() {
            return this == FsDatasetCache.State.CACHED;
        }
    }

    private static final Logger NACKZPRPTI = LoggerFactory.getLogger(FsDatasetCache.class);

    /**
     * Stores MappableBlock objects and the states they're in.
     */
    private final HashMap<ExtendedBlockId, FsDatasetCache.Value> FMCPIPKCOD = new HashMap<ExtendedBlockId, FsDatasetCache.Value>();

    private final AtomicLong RCAFHXLMTS = new AtomicLong(0);

    private final FsDatasetImpl JVGLHDBTQD;

    private final ThreadPoolExecutor ONOHSGHLEW;

    /**
     * The approximate amount of cache space in use.
     *
     * This number is an overestimate, counting bytes that will be used only
     * if pending caching operations succeed.  It does not take into account
     * pending uncaching operations.
     *
     * This overestimate is more useful to the NameNode than an underestimate,
     * since we don't want the NameNode to assign us more replicas than
     * we can cache, because of the current batch of operations.
     */
    private final FsDatasetCache.UsedBytesCount EWLYTQQNMP;

    public static class PageRounder {
        private final long SHHECMKIXR = NativeIO.POSIX.getCacheManipulator().getOperatingSystemPageSize();

        /**
         * Round up a number to the operating system page size.
         */
        public long round(long count) {
            long newCount = (count + (SHHECMKIXR - 1)) / SHHECMKIXR;
            return newCount * SHHECMKIXR;
        }
    }

    private class UsedBytesCount {
        private final AtomicLong OMLQDLKYNZ = new AtomicLong(0);

        private final FsDatasetCache.PageRounder UIZHXQGXFA = new FsDatasetCache.PageRounder();

        /**
         * Try to reserve more bytes.
         *
         * @param count
         * 		The number of bytes to add.  We will round this
         * 		up to the page size.
         * @return The new number of usedBytes if we succeeded;
        -1 if we failed.
         */
        long reserve(long count) {
            count = UIZHXQGXFA.round(count);
            while (true) {
                long cur = OMLQDLKYNZ.get();
                long next = cur + count;
                if (next > UOJJOMIQDI) {
                    return -1;
                }
                if (OMLQDLKYNZ.compareAndSet(cur, next)) {
                    return next;
                }
            } 
        }

        /**
         * Release some bytes that we're using.
         *
         * @param count
         * 		The number of bytes to release.  We will round this
         * 		up to the page size.
         * @return The new number of usedBytes.
         */
        long release(long count) {
            count = UIZHXQGXFA.round(count);
            return OMLQDLKYNZ.addAndGet(-count);
        }

        long get() {
            return OMLQDLKYNZ.get();
        }
    }

    /**
     * The total cache capacity in bytes.
     */
    private final long UOJJOMIQDI;

    /**
     * Number of cache commands that could not be completed successfully
     */
    final AtomicLong MTEUWAPAZB = new AtomicLong(0);

    /**
     * Number of uncache commands that could not be completed successfully
     */
    final AtomicLong NWDLBBDRVM = new AtomicLong(0);

    public FsDatasetCache(FsDatasetImpl JOBWIWDEKX) {
        this.JVGLHDBTQD = JOBWIWDEKX;
        this.UOJJOMIQDI = JOBWIWDEKX.datanode.getDnConf().getMaxLockedMemory();
        ThreadFactory QFTQDBDYMK = new com.google.common.util.concurrent.ThreadFactoryBuilder().setDaemon(true).setNameFormat("FsDatasetCache-%d-" + JOBWIWDEKX.toString()).build();
        this.EWLYTQQNMP = new FsDatasetCache.UsedBytesCount();
        this.ONOHSGHLEW = new ThreadPoolExecutor(0, 1, 60, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(), QFTQDBDYMK);
        this.ONOHSGHLEW.allowCoreThreadTimeOut(true);
    }

    /**
     *
     *
     * @return List of cached blocks suitable for translation into a
    {@link BlockListAsLongs} for a cache report.
     */
    synchronized List<Long> getCachedBlocks(String DKUXRHTJQQ) {
        List<Long> JMBGIUCTVI = new ArrayList<Long>();
        for (Iterator<Map.Entry<ExtendedBlockId, FsDatasetCache.Value>> JZUUVUYSFD = FMCPIPKCOD.entrySet().iterator(); JZUUVUYSFD.hasNext();) {
            Map.Entry<ExtendedBlockId, FsDatasetCache.Value> ITVWCDZYSE = JZUUVUYSFD.next();
            if (ITVWCDZYSE.getKey().getBlockPoolId().equals(DKUXRHTJQQ)) {
                if (ITVWCDZYSE.getValue().state.shouldAdvertise()) {
                    JMBGIUCTVI.add(ITVWCDZYSE.getKey().getBlockId());
                }
            }
        }
        return JMBGIUCTVI;
    }

    /**
     * Attempt to begin caching a block.
     */
    synchronized void cacheBlock(long UBFNTJXMFK, String XGGFIDLAUD, String TUIVBMMHZG, long QUPDQELJNB, long EXMDPDQZTA, Executor EQNOTDVOOP) {
        ExtendedBlockId BVQXHHQTTO = new ExtendedBlockId(UBFNTJXMFK, XGGFIDLAUD);
        FsDatasetCache.Value MQSQKFDXUR = FMCPIPKCOD.get(BVQXHHQTTO);
        if (MQSQKFDXUR != null) {
            FsDatasetCache.NACKZPRPTI.debug("Block with id {}, pool {} already exists in the " + "FsDatasetCache with state {}", UBFNTJXMFK, XGGFIDLAUD, MQSQKFDXUR.ENXDAUFZSK);
            MTEUWAPAZB.incrementAndGet();
            return;
        }
        FMCPIPKCOD.put(BVQXHHQTTO, new FsDatasetCache.Value(null, FsDatasetCache.State.CACHING));
        EQNOTDVOOP.execute(new FsDatasetCache.CachingTask(BVQXHHQTTO, TUIVBMMHZG, QUPDQELJNB, EXMDPDQZTA));
        FsDatasetCache.NACKZPRPTI.debug("Initiating caching for Block with id {}, pool {}", UBFNTJXMFK, XGGFIDLAUD);
    }

    synchronized void uncacheBlock(String VNOKICCFIY, long XDZPGIOTNA) {
        ExtendedBlockId QDWRNCCYFA = new ExtendedBlockId(XDZPGIOTNA, VNOKICCFIY);
        FsDatasetCache.Value UTMPCBLKLN = FMCPIPKCOD.get(QDWRNCCYFA);
        if (!JVGLHDBTQD.datanode.getShortCircuitRegistry().processBlockMunlockRequest(QDWRNCCYFA)) {
            // TODO: we probably want to forcibly uncache the block (and close the
            // shm) after a certain timeout has elapsed.
            FsDatasetCache.NACKZPRPTI.debug("{} is anchored, and can't be uncached now.", QDWRNCCYFA);
            return;
        }
        if (UTMPCBLKLN == null) {
            FsDatasetCache.NACKZPRPTI.debug("Block with id {}, pool {} does not need to be uncached, " + "because it is not currently in the mappableBlockMap.", XDZPGIOTNA, VNOKICCFIY);
            NWDLBBDRVM.incrementAndGet();
            return;
        }
        switch (UTMPCBLKLN.ENXDAUFZSK) {
            case CACHING :
                FsDatasetCache.NACKZPRPTI.debug("Cancelling caching for block with id {}, pool {}.", XDZPGIOTNA, VNOKICCFIY);
                FMCPIPKCOD.put(QDWRNCCYFA, new FsDatasetCache.Value(UTMPCBLKLN.FNAUMLDSHS, FsDatasetCache.State.CACHING_CANCELLED));
                break;
            case CACHED :
                FsDatasetCache.NACKZPRPTI.debug("Block with id {}, pool {} has been scheduled for uncaching" + ".", XDZPGIOTNA, VNOKICCFIY);
                FMCPIPKCOD.put(QDWRNCCYFA, new FsDatasetCache.Value(UTMPCBLKLN.FNAUMLDSHS, FsDatasetCache.State.UNCACHING));
                ONOHSGHLEW.execute(new FsDatasetCache.UncachingTask(QDWRNCCYFA));
                break;
            default :
                FsDatasetCache.NACKZPRPTI.debug("Block with id {}, pool {} does not need to be uncached, " + "because it is in state {}.", XDZPGIOTNA, VNOKICCFIY, UTMPCBLKLN.ENXDAUFZSK);
                NWDLBBDRVM.incrementAndGet();
                break;
        }
    }

    /**
     * Background worker that mmaps, mlocks, and checksums a block
     */
    private class CachingTask implements Runnable {
        private final ExtendedBlockId FUIZJSZBQE;

        private final String ZVKXHGYYHT;

        private final long WKYENQQUIS;

        private final long BBMWEXGTVK;

        CachingTask(ExtendedBlockId key, String blockFileName, long length, long genstamp) {
            this.FUIZJSZBQE = key;
            this.ZVKXHGYYHT = blockFileName;
            this.WKYENQQUIS = length;
            this.BBMWEXGTVK = genstamp;
        }

        @Override
        public void run() {
            boolean success = false;
            FileInputStream blockIn = null;
            FileInputStream metaIn = null;
            MappableBlock mappableBlock = null;
            ExtendedBlock extBlk = new ExtendedBlock(FUIZJSZBQE.getBlockPoolId(), FUIZJSZBQE.getBlockId(), WKYENQQUIS, BBMWEXGTVK);
            long newUsedBytes = EWLYTQQNMP.reserve(WKYENQQUIS);
            boolean reservedBytes = false;
            try {
                if (newUsedBytes < 0) {
                    FsDatasetCache.NACKZPRPTI.warn(((((((("Failed to cache " + FUIZJSZBQE) + ": could not reserve ") + WKYENQQUIS) + " more bytes in the cache: ") + DFSConfigKeys.DFS_DATANODE_MAX_LOCKED_MEMORY_KEY) + " of ") + UOJJOMIQDI) + " exceeded.");
                    return;
                }
                reservedBytes = true;
                try {
                    blockIn = ((FileInputStream) (JVGLHDBTQD.getBlockInputStream(extBlk, 0)));
                    metaIn = ((FileInputStream) (JVGLHDBTQD.getMetaDataInputStream(extBlk).getWrappedStream()));
                } catch (ClassCastException e) {
                    FsDatasetCache.NACKZPRPTI.warn(("Failed to cache " + FUIZJSZBQE) + ": Underlying blocks are not backed by files.", e);
                    return;
                } catch (FileNotFoundException e) {
                    FsDatasetCache.NACKZPRPTI.info((("Failed to cache " + FUIZJSZBQE) + ": failed to find backing ") + "files.");
                    return;
                } catch (IOException e) {
                    FsDatasetCache.NACKZPRPTI.warn(("Failed to cache " + FUIZJSZBQE) + ": failed to open file", e);
                    return;
                }
                try {
                    mappableBlock = MappableBlock.load(WKYENQQUIS, blockIn, metaIn, ZVKXHGYYHT);
                } catch (ChecksumException e) {
                    // Exception message is bogus since this wasn't caused by a file read
                    FsDatasetCache.NACKZPRPTI.warn(("Failed to cache " + FUIZJSZBQE) + ": checksum verification failed.");
                    return;
                } catch (IOException e) {
                    FsDatasetCache.NACKZPRPTI.warn("Failed to cache " + FUIZJSZBQE, e);
                    return;
                }
                synchronized(FsDatasetCache.this) {
                    FsDatasetCache.Value value = FMCPIPKCOD.get(FUIZJSZBQE);
                    Preconditions.checkNotNull(value);
                    Preconditions.checkState((value.ENXDAUFZSK == FsDatasetCache.State.CACHING) || (value.ENXDAUFZSK == FsDatasetCache.State.CACHING_CANCELLED));
                    if (value.ENXDAUFZSK == FsDatasetCache.State.CACHING_CANCELLED) {
                        FMCPIPKCOD.remove(FUIZJSZBQE);
                        FsDatasetCache.NACKZPRPTI.warn(("Caching of " + FUIZJSZBQE) + " was cancelled.");
                        return;
                    }
                    FMCPIPKCOD.put(FUIZJSZBQE, new FsDatasetCache.Value(mappableBlock, FsDatasetCache.State.CACHED));
                }
                FsDatasetCache.NACKZPRPTI.debug("Successfully cached {}.  We are now caching {} bytes in" + " total.", FUIZJSZBQE, newUsedBytes);
                JVGLHDBTQD.datanode.getShortCircuitRegistry().processBlockMlockEvent(FUIZJSZBQE);
                RCAFHXLMTS.addAndGet(1);
                JVGLHDBTQD.datanode.getMetrics().incrBlocksCached(1);
                success = true;
            } finally {
                IOUtils.closeQuietly(blockIn);
                IOUtils.closeQuietly(metaIn);
                if (!success) {
                    if (reservedBytes) {
                        EWLYTQQNMP.release(WKYENQQUIS);
                    }
                    FsDatasetCache.NACKZPRPTI.debug("Caching of {} was aborted.  We are now caching only {} " + "bytes in total.", FUIZJSZBQE, EWLYTQQNMP.get());
                    if (mappableBlock != null) {
                        mappableBlock.close();
                    }
                    MTEUWAPAZB.incrementAndGet();
                    synchronized(FsDatasetCache.this) {
                        FMCPIPKCOD.remove(FUIZJSZBQE);
                    }
                }
            }
        }
    }

    private class UncachingTask implements Runnable {
        private final ExtendedBlockId QPEMMRMHQA;

        UncachingTask(ExtendedBlockId key) {
            this.QPEMMRMHQA = key;
        }

        @Override
        public void run() {
            FsDatasetCache.Value value;
            synchronized(FsDatasetCache.this) {
                value = FMCPIPKCOD.get(QPEMMRMHQA);
            }
            Preconditions.checkNotNull(value);
            Preconditions.checkArgument(value.ENXDAUFZSK == FsDatasetCache.State.UNCACHING);
            // TODO: we will eventually need to do revocation here if any clients
            // are reading via mmap with checksums enabled.  See HDFS-5182.
            IOUtils.closeQuietly(value.FNAUMLDSHS);
            synchronized(FsDatasetCache.this) {
                FMCPIPKCOD.remove(QPEMMRMHQA);
            }
            long newUsedBytes = EWLYTQQNMP.release(value.FNAUMLDSHS.getLength());
            RCAFHXLMTS.addAndGet(-1);
            JVGLHDBTQD.datanode.getMetrics().incrBlocksUncached(1);
            FsDatasetCache.NACKZPRPTI.debug("Uncaching of {} completed. usedBytes = {}", QPEMMRMHQA, newUsedBytes);
        }
    }

    // Stats related methods for FSDatasetMBean
    /**
     * Get the approximate amount of cache space used.
     */
    public long getCacheUsed() {
        return EWLYTQQNMP.get();
    }

    /**
     * Get the maximum amount of bytes we can cache.  This is a constant.
     */
    public long getCacheCapacity() {
        return UOJJOMIQDI;
    }

    public long getNumBlocksFailedToCache() {
        return MTEUWAPAZB.get();
    }

    public long getNumBlocksFailedToUncache() {
        return NWDLBBDRVM.get();
    }

    public long getNumBlocksCached() {
        return RCAFHXLMTS.get();
    }

    public synchronized boolean isCached(String NGTUVDRRLG, long IZCVEIHITO) {
        ExtendedBlockId ZOPLHXYJYC = new ExtendedBlockId(IZCVEIHITO, NGTUVDRRLG);
        FsDatasetCache.Value PBMTSLGNML = FMCPIPKCOD.get(ZOPLHXYJYC);
        return (PBMTSLGNML != null) && PBMTSLGNML.ENXDAUFZSK.shouldAdvertise();
    }
}