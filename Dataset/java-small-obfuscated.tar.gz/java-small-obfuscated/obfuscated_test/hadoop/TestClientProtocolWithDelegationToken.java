/**
 * Unit tests for using Delegation Token over RPC.
 */
public class TestClientProtocolWithDelegationToken {
    private static final String HMJMRYHCPL = "0.0.0.0";

    public static final Log VODLYSJSQD = LogFactory.getLog(TestClientProtocolWithDelegationToken.class);

    private static final Configuration GOWFFFCHOT;

    static {
        GOWFFFCHOT = new Configuration();
        TestClientProtocolWithDelegationToken.GOWFFFCHOT.set(HADOOP_SECURITY_AUTHENTICATION, "kerberos");
        UserGroupInformation.setConfiguration(TestClientProtocolWithDelegationToken.GOWFFFCHOT);
    }

    static {
        ((org.apache.commons.logging.impl.Log4JLogger) (Client.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (Server.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (SaslRpcClient.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (SaslRpcServer.LOG)).getLogger().setLevel(Level.ALL);
        ((org.apache.commons.logging.impl.Log4JLogger) (SaslInputStream.LOG)).getLogger().setLevel(Level.ALL);
    }

    @Test
    public void testDelegationTokenRpc() throws Exception {
        ClientProtocol HFBVXQMLDI = mock(ClientProtocol.class);
        FSNamesystem BXSUPFVHWA = mock(FSNamesystem.class);
        DelegationTokenSecretManager UYSHZJASQN = new DelegationTokenSecretManager(DFSConfigKeys.DFS_NAMENODE_DELEGATION_KEY_UPDATE_INTERVAL_DEFAULT, DFSConfigKeys.DFS_NAMENODE_DELEGATION_KEY_UPDATE_INTERVAL_DEFAULT, DFSConfigKeys.DFS_NAMENODE_DELEGATION_TOKEN_MAX_LIFETIME_DEFAULT, 3600000, BXSUPFVHWA);
        UYSHZJASQN.startThreads();
        final Server QXJEXAKFQH = new RPC.Builder(TestClientProtocolWithDelegationToken.GOWFFFCHOT).setProtocol(ClientProtocol.class).setInstance(HFBVXQMLDI).setBindAddress(TestClientProtocolWithDelegationToken.HMJMRYHCPL).setPort(0).setNumHandlers(5).setVerbose(true).setSecretManager(UYSHZJASQN).build();
        QXJEXAKFQH.start();
        final UserGroupInformation DDKLXPSSSV = UserGroupInformation.getCurrentUser();
        final InetSocketAddress UQQXNQBXOE = NetUtils.getConnectAddress(QXJEXAKFQH);
        String MTDTRQIQBR = DDKLXPSSSV.getUserName();
        Text BMPGAOFIMK = new Text(MTDTRQIQBR);
        DelegationTokenIdentifier JJUYRGCYFL = new DelegationTokenIdentifier(BMPGAOFIMK, BMPGAOFIMK, null);
        Token<DelegationTokenIdentifier> KHWORVSFDT = new Token<DelegationTokenIdentifier>(JJUYRGCYFL, UYSHZJASQN);
        SecurityUtil.setTokenService(KHWORVSFDT, UQQXNQBXOE);
        TestClientProtocolWithDelegationToken.VODLYSJSQD.info("Service for token is " + KHWORVSFDT.getService());
        DDKLXPSSSV.addToken(KHWORVSFDT);
        DDKLXPSSSV.doAs(new PrivilegedExceptionAction<Object>() {
            @Override
            public Object run() throws Exception {
                ClientProtocol ZQICEYFKDR = null;
                try {
                    ZQICEYFKDR = RPC.getProxy(ClientProtocol.class, versionID, UQQXNQBXOE, TestClientProtocolWithDelegationToken.GOWFFFCHOT);
                    ZQICEYFKDR.getServerDefaults();
                } finally {
                    QXJEXAKFQH.stop();
                    if (ZQICEYFKDR != null) {
                        RPC.stopProxy(ZQICEYFKDR);
                    }
                }
                return null;
            }
        });
    }
}