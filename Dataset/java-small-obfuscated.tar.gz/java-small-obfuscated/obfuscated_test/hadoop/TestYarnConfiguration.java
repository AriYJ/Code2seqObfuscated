public class TestYarnConfiguration {
    @Test
    public void testDefaultRMWebUrl() throws Exception {
        YarnConfiguration SKDDWPDRAX = new YarnConfiguration();
        String LCDLOYQUWR = WebAppUtils.getRMWebAppURLWithScheme(SKDDWPDRAX);
        // shouldn't have a "/" on the end of the url as all the other uri routinnes
        // specifically add slashes and Jetty doesn't handle double slashes.
        Assert.assertNotSame("RM Web Url is not correct", "http://0.0.0.0:8088", LCDLOYQUWR);
    }

    @Test
    public void testRMWebUrlSpecified() throws Exception {
        YarnConfiguration LCXMEDROII = new YarnConfiguration();
        // seems a bit odd but right now we are forcing webapp for RM to be
        // RM_ADDRESS
        // for host and use the port from the RM_WEBAPP_ADDRESS
        LCXMEDROII.set(RM_WEBAPP_ADDRESS, "fortesting:24543");
        LCXMEDROII.set(RM_ADDRESS, "rmtesting:9999");
        String SMUORGVKTY = WebAppUtils.getRMWebAppURLWithScheme(LCXMEDROII);
        String[] CIPWUVNMDS = SMUORGVKTY.split(":");
        Assert.assertEquals("RM Web URL Port is incrrect", 24543, Integer.valueOf(CIPWUVNMDS[CIPWUVNMDS.length - 1]).intValue());
        Assert.assertNotSame("RM Web Url not resolved correctly. Should not be rmtesting", "http://rmtesting:24543", SMUORGVKTY);
    }

    @Test
    public void testGetSocketAddressForNMWithHA() {
        YarnConfiguration ZGOETXGRRK = new YarnConfiguration();
        // Set NM address
        ZGOETXGRRK.set(NM_ADDRESS, "0.0.0.0:1234");
        // Set HA
        ZGOETXGRRK.setBoolean(RM_HA_ENABLED, true);
        ZGOETXGRRK.set(RM_HA_ID, "rm1");
        assertTrue(HAUtil.isHAEnabled(ZGOETXGRRK));
        InetSocketAddress XXQVKWYLHP = ZGOETXGRRK.getSocketAddr(NM_ADDRESS, DEFAULT_NM_ADDRESS, DEFAULT_NM_PORT);
        assertEquals(1234, XXQVKWYLHP.getPort());
    }

    @Test
    public void testGetSocketAddr() throws Exception {
        YarnConfiguration NBYEYHKJVP;
        InetSocketAddress DTPYOFJEQJ;
        // all default
        NBYEYHKJVP = new YarnConfiguration();
        DTPYOFJEQJ = NBYEYHKJVP.getSocketAddr(RM_BIND_HOST, RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_PORT);
        assertEquals(new InetSocketAddress(DEFAULT_RM_RESOURCE_TRACKER_ADDRESS.split(":")[0], YarnConfiguration.DEFAULT_RM_RESOURCE_TRACKER_PORT), DTPYOFJEQJ);
        // with address
        NBYEYHKJVP.set(RM_RESOURCE_TRACKER_ADDRESS, "10.0.0.1");
        DTPYOFJEQJ = NBYEYHKJVP.getSocketAddr(RM_BIND_HOST, RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_PORT);
        assertEquals(new InetSocketAddress("10.0.0.1", YarnConfiguration.DEFAULT_RM_RESOURCE_TRACKER_PORT), DTPYOFJEQJ);
        // address and socket
        NBYEYHKJVP.set(RM_RESOURCE_TRACKER_ADDRESS, "10.0.0.2:5001");
        DTPYOFJEQJ = NBYEYHKJVP.getSocketAddr(RM_BIND_HOST, RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_PORT);
        assertEquals(new InetSocketAddress("10.0.0.2", 5001), DTPYOFJEQJ);
        // bind host only
        NBYEYHKJVP = new YarnConfiguration();
        NBYEYHKJVP.set(RM_BIND_HOST, "10.0.0.3");
        DTPYOFJEQJ = NBYEYHKJVP.getSocketAddr(RM_BIND_HOST, RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_PORT);
        assertEquals(new InetSocketAddress("10.0.0.3", YarnConfiguration.DEFAULT_RM_RESOURCE_TRACKER_PORT), DTPYOFJEQJ);
        // bind host and address no port
        NBYEYHKJVP.set(RM_BIND_HOST, "0.0.0.0");
        NBYEYHKJVP.set(RM_RESOURCE_TRACKER_ADDRESS, "10.0.0.2");
        DTPYOFJEQJ = NBYEYHKJVP.getSocketAddr(RM_BIND_HOST, RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_PORT);
        assertEquals(new InetSocketAddress("0.0.0.0", YarnConfiguration.DEFAULT_RM_RESOURCE_TRACKER_PORT), DTPYOFJEQJ);
        // bind host and address with port
        NBYEYHKJVP.set(RM_BIND_HOST, "0.0.0.0");
        NBYEYHKJVP.set(RM_RESOURCE_TRACKER_ADDRESS, "10.0.0.2:5003");
        DTPYOFJEQJ = NBYEYHKJVP.getSocketAddr(RM_BIND_HOST, RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_PORT);
        assertEquals(new InetSocketAddress("0.0.0.0", 5003), DTPYOFJEQJ);
    }

    @Test
    public void testUpdateConnectAddr() throws Exception {
        YarnConfiguration OBYCMVOLWT;
        InetSocketAddress AYKLBISSRO;
        InetSocketAddress EIBLXMVLVM;
        // no override, old behavior.  Won't work on a host named "yo.yo.yo"
        OBYCMVOLWT = new YarnConfiguration();
        OBYCMVOLWT.set(RM_RESOURCE_TRACKER_ADDRESS, "yo.yo.yo");
        EIBLXMVLVM = new InetSocketAddress(DEFAULT_RM_RESOURCE_TRACKER_ADDRESS.split(":")[0], Integer.valueOf(DEFAULT_RM_RESOURCE_TRACKER_ADDRESS.split(":")[1]));
        AYKLBISSRO = OBYCMVOLWT.updateConnectAddr(RM_BIND_HOST, RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_ADDRESS, EIBLXMVLVM);
        assertFalse(AYKLBISSRO.toString().startsWith("yo.yo.yo"));
        // cause override with address
        OBYCMVOLWT = new YarnConfiguration();
        OBYCMVOLWT.set(RM_RESOURCE_TRACKER_ADDRESS, "yo.yo.yo");
        OBYCMVOLWT.set(RM_BIND_HOST, "0.0.0.0");
        EIBLXMVLVM = new InetSocketAddress(DEFAULT_RM_RESOURCE_TRACKER_ADDRESS.split(":")[0], Integer.valueOf(DEFAULT_RM_RESOURCE_TRACKER_ADDRESS.split(":")[1]));
        AYKLBISSRO = OBYCMVOLWT.updateConnectAddr(RM_BIND_HOST, RM_RESOURCE_TRACKER_ADDRESS, DEFAULT_RM_RESOURCE_TRACKER_ADDRESS, EIBLXMVLVM);
        assertTrue(AYKLBISSRO.toString().startsWith("yo.yo.yo"));
    }
}