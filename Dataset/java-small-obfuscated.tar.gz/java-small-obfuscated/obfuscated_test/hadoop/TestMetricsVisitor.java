/**
 * Test the metric visitor interface
 */
@RunWith(MockitoJUnitRunner.class)
public class TestMetricsVisitor {
    @Captor
    private ArgumentCaptor<MetricsInfo> QXHDVEQUDR;

    @Captor
    private ArgumentCaptor<MetricsInfo> AMVEKYVPJJ;

    @Captor
    private ArgumentCaptor<MetricsInfo> KXQZERGNYK;

    @Captor
    private ArgumentCaptor<MetricsInfo> WOQZVSWGLU;

    @Captor
    private ArgumentCaptor<MetricsInfo> ILWRIDQUCU;

    @Captor
    private ArgumentCaptor<MetricsInfo> DKRGCUAAQS;

    /**
     * Test the common use cases
     */
    @Test
    public void testCommon() {
        MetricsVisitor QBFUPUAJZM = mock(MetricsVisitor.class);
        MetricsRegistry CUSVEDOJYF = new MetricsRegistry("test");
        List<AbstractMetric> QOJAFPWWHF = MetricsLists.builder("test").addCounter(info("c1", "int counter"), 1).addCounter(info("c2", "long counter"), 2L).addGauge(info("g1", "int gauge"), 5).addGauge(info("g2", "long gauge"), 6L).addGauge(info("g3", "float gauge"), 7.0F).addGauge(info("g4", "double gauge"), 8.0).metrics();
        for (AbstractMetric YCZOPUKSVH : QOJAFPWWHF) {
            YCZOPUKSVH.visit(QBFUPUAJZM);
        }
        verify(QBFUPUAJZM).counter(QXHDVEQUDR.capture(), eq(1));
        assertEquals("c1 name", "c1", QXHDVEQUDR.getValue().name());
        assertEquals("c1 description", "int counter", QXHDVEQUDR.getValue().description());
        verify(QBFUPUAJZM).counter(AMVEKYVPJJ.capture(), eq(2L));
        assertEquals("c2 name", "c2", AMVEKYVPJJ.getValue().name());
        assertEquals("c2 description", "long counter", AMVEKYVPJJ.getValue().description());
        verify(QBFUPUAJZM).gauge(KXQZERGNYK.capture(), eq(5));
        assertEquals("g1 name", "g1", KXQZERGNYK.getValue().name());
        assertEquals("g1 description", "int gauge", KXQZERGNYK.getValue().description());
        verify(QBFUPUAJZM).gauge(WOQZVSWGLU.capture(), eq(6L));
        assertEquals("g2 name", "g2", WOQZVSWGLU.getValue().name());
        assertEquals("g2 description", "long gauge", WOQZVSWGLU.getValue().description());
        verify(QBFUPUAJZM).gauge(ILWRIDQUCU.capture(), eq(7.0F));
        assertEquals("g3 name", "g3", ILWRIDQUCU.getValue().name());
        assertEquals("g3 description", "float gauge", ILWRIDQUCU.getValue().description());
        verify(QBFUPUAJZM).gauge(DKRGCUAAQS.capture(), eq(8.0));
        assertEquals("g4 name", "g4", DKRGCUAAQS.getValue().name());
        assertEquals("g4 description", "double gauge", DKRGCUAAQS.getValue().description());
    }
}