/**
 * Tests the state machine with respect to Job/Task/TaskAttempt kill scenarios.
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
public class TestKill {
    @Test
    public void testKillJob() throws Exception {
        final CountDownLatch BSQANVLSFN = new CountDownLatch(1);
        MRApp CSHJDUOBGR = new TestKill.BlockingMRApp(1, 0, BSQANVLSFN);
        // this will start the job but job won't complete as task is
        // blocked
        Job XCZSPSIAZV = CSHJDUOBGR.submit(new Configuration());
        // wait and vailidate for Job to become RUNNING
        CSHJDUOBGR.waitForState(XCZSPSIAZV, RUNNING);
        // send the kill signal to Job
        CSHJDUOBGR.getContext().getEventHandler().handle(new org.apache.hadoop.mapreduce.v2.app.job.event.JobEvent(XCZSPSIAZV.getID(), JobEventType.JOB_KILL));
        // unblock Task
        BSQANVLSFN.countDown();
        // wait and validate for Job to be KILLED
        CSHJDUOBGR.waitForState(XCZSPSIAZV, KILLED);
        Map<TaskId, Task> ZHUBHODUFP = XCZSPSIAZV.getTasks();
        Assert.assertEquals("No of tasks is not correct", 1, ZHUBHODUFP.size());
        Task GATBYIMXPP = ZHUBHODUFP.values().iterator().next();
        Assert.assertEquals("Task state not correct", TaskState.KILLED, GATBYIMXPP.getReport().getTaskState());
        Map<TaskAttemptId, TaskAttempt> COWMKRUFPV = ZHUBHODUFP.values().iterator().next().getAttempts();
        Assert.assertEquals("No of attempts is not correct", 1, COWMKRUFPV.size());
        Iterator<TaskAttempt> WTZSBHQAVM = COWMKRUFPV.values().iterator();
        Assert.assertEquals("Attempt state not correct", TaskAttemptState.KILLED, WTZSBHQAVM.next().getReport().getTaskAttemptState());
    }

    @Test
    public void testKillTask() throws Exception {
        final CountDownLatch EDTODXWIQQ = new CountDownLatch(1);
        MRApp ZPZMNPQTNK = new TestKill.BlockingMRApp(2, 0, EDTODXWIQQ);
        // this will start the job but job won't complete as Task is blocked
        Job SNHGFQQPWB = ZPZMNPQTNK.submit(new Configuration());
        // wait and vailidate for Job to become RUNNING
        ZPZMNPQTNK.waitForState(SNHGFQQPWB, RUNNING);
        Map<TaskId, Task> VXUMWLMRQP = SNHGFQQPWB.getTasks();
        Assert.assertEquals("No of tasks is not correct", 2, VXUMWLMRQP.size());
        Iterator<Task> RYZEDMTZTX = VXUMWLMRQP.values().iterator();
        Task EWAYAYQQEC = RYZEDMTZTX.next();
        Task CVFZEEKIOI = RYZEDMTZTX.next();
        // send the kill signal to the first Task
        ZPZMNPQTNK.getContext().getEventHandler().handle(new TaskEvent(EWAYAYQQEC.getID(), TaskEventType.T_KILL));
        // unblock Task
        EDTODXWIQQ.countDown();
        // wait and validate for Job to become SUCCEEDED
        ZPZMNPQTNK.waitForState(SNHGFQQPWB, SUCCEEDED);
        // first Task is killed and second is Succeeded
        // Job is succeeded
        Assert.assertEquals("Task state not correct", TaskState.KILLED, EWAYAYQQEC.getReport().getTaskState());
        Assert.assertEquals("Task state not correct", TaskState.SUCCEEDED, CVFZEEKIOI.getReport().getTaskState());
        Map<TaskAttemptId, TaskAttempt> LITJYFBRUK = EWAYAYQQEC.getAttempts();
        Assert.assertEquals("No of attempts is not correct", 1, LITJYFBRUK.size());
        Iterator<TaskAttempt> YVRSTXBMRD = LITJYFBRUK.values().iterator();
        Assert.assertEquals("Attempt state not correct", TaskAttemptState.KILLED, YVRSTXBMRD.next().getReport().getTaskAttemptState());
        LITJYFBRUK = CVFZEEKIOI.getAttempts();
        Assert.assertEquals("No of attempts is not correct", 1, LITJYFBRUK.size());
        YVRSTXBMRD = LITJYFBRUK.values().iterator();
        Assert.assertEquals("Attempt state not correct", TaskAttemptState.SUCCEEDED, YVRSTXBMRD.next().getReport().getTaskAttemptState());
    }

    @Test
    public void testKillTaskWait() throws Exception {
        final Dispatcher VTPDLXKVRZ = new AsyncDispatcher() {
            private TaskAttemptEvent QVUFXLMPJC;

            @Override
            protected void dispatch(Event TWTVPKZIUH) {
                if (TWTVPKZIUH instanceof TaskAttemptEvent) {
                    TaskAttemptEvent FVWLGETSJG = ((TaskAttemptEvent) (TWTVPKZIUH));
                    if (FVWLGETSJG.getType() == TaskAttemptEventType.TA_KILL) {
                        TaskAttemptId TFADOOBZWD = FVWLGETSJG.getTaskAttemptID();
                        if (((TFADOOBZWD.getTaskId().getTaskType() == TaskType.REDUCE) && (TFADOOBZWD.getTaskId().getId() == 0)) && (TFADOOBZWD.getId() == 0)) {
                            // Task is asking the reduce TA to kill itself. 'Create' a race
                            // condition. Make the task succeed and then inform the task that
                            // TA has succeeded. Once Task gets the TA succeeded event at
                            // KILL_WAIT, then relay the actual kill signal to TA
                            super.dispatch(new TaskAttemptEvent(TFADOOBZWD, TaskAttemptEventType.TA_DONE));
                            super.dispatch(new TaskAttemptEvent(TFADOOBZWD, TaskAttemptEventType.TA_CONTAINER_CLEANED));
                            super.dispatch(new org.apache.hadoop.mapreduce.v2.app.job.event.TaskTAttemptEvent(TFADOOBZWD, TaskEventType.T_ATTEMPT_SUCCEEDED));
                            this.QVUFXLMPJC = FVWLGETSJG;
                            return;
                        }
                    }
                } else
                    if (TWTVPKZIUH instanceof TaskEvent) {
                        TaskEvent PSEQLGBALM = ((TaskEvent) (TWTVPKZIUH));
                        if ((PSEQLGBALM.getType() == TaskEventType.T_ATTEMPT_SUCCEEDED) && (this.QVUFXLMPJC != null)) {
                            // When the TA comes and reports that it is done, send the
                            // cachedKillEvent
                            super.dispatch(this.QVUFXLMPJC);
                            return;
                        }
                    }

                super.dispatch(TWTVPKZIUH);
            }
        };
        MRApp TOBPXHNBXD = new MRApp(1, 1, false, this.getClass().getName(), true) {
            @Override
            public Dispatcher createDispatcher() {
                return VTPDLXKVRZ;
            }
        };
        Job FSXFFKCMTF = TOBPXHNBXD.submit(new Configuration());
        JobId RGQJMEATOT = TOBPXHNBXD.getJobId();
        TOBPXHNBXD.waitForState(FSXFFKCMTF, RUNNING);
        Assert.assertEquals("Num tasks not correct", 2, FSXFFKCMTF.getTasks().size());
        Iterator<Task> LDQYCNGWJO = FSXFFKCMTF.getTasks().values().iterator();
        Task LOHXYFKMNS = LDQYCNGWJO.next();
        Task IYNVAFRBLJ = LDQYCNGWJO.next();
        TOBPXHNBXD.waitForState(LOHXYFKMNS, TaskState.RUNNING);
        TOBPXHNBXD.waitForState(IYNVAFRBLJ, TaskState.RUNNING);
        TaskAttempt WSRDTRAUAL = LOHXYFKMNS.getAttempts().values().iterator().next();
        TOBPXHNBXD.waitForState(WSRDTRAUAL, TaskAttemptState.RUNNING);
        TaskAttempt BIDBCZTXJT = IYNVAFRBLJ.getAttempts().values().iterator().next();
        TOBPXHNBXD.waitForState(BIDBCZTXJT, TaskAttemptState.RUNNING);
        // Finish map
        TOBPXHNBXD.getContext().getEventHandler().handle(new TaskAttemptEvent(WSRDTRAUAL.getID(), TaskAttemptEventType.TA_DONE));
        TOBPXHNBXD.waitForState(LOHXYFKMNS, TaskState.SUCCEEDED);
        // Now kill the job
        TOBPXHNBXD.getContext().getEventHandler().handle(new org.apache.hadoop.mapreduce.v2.app.job.event.JobEvent(RGQJMEATOT, JobEventType.JOB_KILL));
        TOBPXHNBXD.waitForInternalState(((JobImpl) (FSXFFKCMTF)), JobStateInternal.KILLED);
    }

    static class MyAsyncDispatch extends AsyncDispatcher {
        private CountDownLatch JPSBFXWCPB;

        private TaskAttemptEventType GRWKDRYUNO;

        MyAsyncDispatch(CountDownLatch latch, TaskAttemptEventType attemptEventTypeToWait) {
            super();
            this.JPSBFXWCPB = latch;
            this.GRWKDRYUNO = attemptEventTypeToWait;
        }

        @Override
        protected void dispatch(Event event) {
            if (event instanceof TaskAttemptEvent) {
                TaskAttemptEvent attemptEvent = ((TaskAttemptEvent) (event));
                TaskAttemptId attemptID = ((TaskAttemptEvent) (event)).getTaskAttemptID();
                if (((attemptEvent.getType() == this.GRWKDRYUNO) && (attemptID.getTaskId().getId() == 0)) && (attemptID.getId() == 0)) {
                    try {
                        JPSBFXWCPB.await();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
            super.dispatch(event);
        }
    }

    // This is to test a race condition where JobEventType.JOB_KILL is generated
    // right after TaskAttemptEventType.TA_DONE is generated.
    // TaskImpl's state machine might receive both T_ATTEMPT_SUCCEEDED
    // and T_ATTEMPT_KILLED from the same attempt.
    @Test
    public void testKillTaskWaitKillJobAfterTA_DONE() throws Exception {
        CountDownLatch JJHGDOUHDN = new CountDownLatch(1);
        final Dispatcher OTVAQSMODD = new TestKill.MyAsyncDispatch(JJHGDOUHDN, TaskAttemptEventType.TA_DONE);
        MRApp FHHFQTAYYC = new MRApp(1, 1, false, this.getClass().getName(), true) {
            @Override
            public Dispatcher createDispatcher() {
                return OTVAQSMODD;
            }
        };
        Job WRIDAVARPV = FHHFQTAYYC.submit(new Configuration());
        JobId BFTQPKGQWK = FHHFQTAYYC.getJobId();
        FHHFQTAYYC.waitForState(WRIDAVARPV, RUNNING);
        Assert.assertEquals("Num tasks not correct", 2, WRIDAVARPV.getTasks().size());
        Iterator<Task> LLRAGXPKEX = WRIDAVARPV.getTasks().values().iterator();
        Task QYEWWFBIKM = LLRAGXPKEX.next();
        Task AYQUXQJWRK = LLRAGXPKEX.next();
        FHHFQTAYYC.waitForState(QYEWWFBIKM, TaskState.RUNNING);
        FHHFQTAYYC.waitForState(AYQUXQJWRK, TaskState.RUNNING);
        TaskAttempt SYIAQAYKNO = QYEWWFBIKM.getAttempts().values().iterator().next();
        FHHFQTAYYC.waitForState(SYIAQAYKNO, TaskAttemptState.RUNNING);
        TaskAttempt LWENCIQEAI = AYQUXQJWRK.getAttempts().values().iterator().next();
        FHHFQTAYYC.waitForState(LWENCIQEAI, TaskAttemptState.RUNNING);
        // The order in the dispatch event queue, from the oldest to the newest
        // TA_DONE
        // JOB_KILL
        // CONTAINER_REMOTE_CLEANUP ( from TA_DONE's handling )
        // T_KILL ( from JOB_KILL's handling )
        // TA_CONTAINER_CLEANED ( from CONTAINER_REMOTE_CLEANUP's handling )
        // TA_KILL ( from T_KILL's handling )
        // T_ATTEMPT_SUCCEEDED ( from TA_CONTAINER_CLEANED's handling )
        // T_ATTEMPT_KILLED ( from TA_KILL's handling )
        // Finish map
        FHHFQTAYYC.getContext().getEventHandler().handle(new TaskAttemptEvent(SYIAQAYKNO.getID(), TaskAttemptEventType.TA_DONE));
        // Now kill the job
        FHHFQTAYYC.getContext().getEventHandler().handle(new org.apache.hadoop.mapreduce.v2.app.job.event.JobEvent(BFTQPKGQWK, JobEventType.JOB_KILL));
        // unblock
        JJHGDOUHDN.countDown();
        FHHFQTAYYC.waitForInternalState(((JobImpl) (WRIDAVARPV)), JobStateInternal.KILLED);
    }

    @Test
    public void testKillTaskAttempt() throws Exception {
        final CountDownLatch RQPCLIPPFV = new CountDownLatch(1);
        MRApp RKVUIILEZH = new TestKill.BlockingMRApp(2, 0, RQPCLIPPFV);
        // this will start the job but job won't complete as Task is blocked
        Job PRFKSOXQOL = RKVUIILEZH.submit(new Configuration());
        // wait and vailidate for Job to become RUNNING
        RKVUIILEZH.waitForState(PRFKSOXQOL, RUNNING);
        Map<TaskId, Task> LBIQKQSYGV = PRFKSOXQOL.getTasks();
        Assert.assertEquals("No of tasks is not correct", 2, LBIQKQSYGV.size());
        Iterator<Task> HNVRZFOJXG = LBIQKQSYGV.values().iterator();
        Task LLOSLSGPMD = HNVRZFOJXG.next();
        Task HNITPFDPYU = HNVRZFOJXG.next();
        // wait for tasks to become running
        RKVUIILEZH.waitForState(LLOSLSGPMD, SCHEDULED);
        RKVUIILEZH.waitForState(HNITPFDPYU, SCHEDULED);
        // send the kill signal to the first Task's attempt
        TaskAttempt RWNFBJAZCC = LLOSLSGPMD.getAttempts().values().iterator().next();
        RKVUIILEZH.getContext().getEventHandler().handle(new TaskAttemptEvent(RWNFBJAZCC.getID(), TaskAttemptEventType.TA_KILL));
        // unblock
        RQPCLIPPFV.countDown();
        // wait and validate for Job to become SUCCEEDED
        // job will still succeed
        RKVUIILEZH.waitForState(PRFKSOXQOL, SUCCEEDED);
        // first Task will have two attempts 1st is killed, 2nd Succeeds
        // both Tasks and Job succeeds
        Assert.assertEquals("Task state not correct", TaskState.SUCCEEDED, LLOSLSGPMD.getReport().getTaskState());
        Assert.assertEquals("Task state not correct", TaskState.SUCCEEDED, HNITPFDPYU.getReport().getTaskState());
        Map<TaskAttemptId, TaskAttempt> XJKLRZLKKU = LLOSLSGPMD.getAttempts();
        Assert.assertEquals("No of attempts is not correct", 2, XJKLRZLKKU.size());
        Iterator<TaskAttempt> DAZRXLNSDN = XJKLRZLKKU.values().iterator();
        Assert.assertEquals("Attempt state not correct", TaskAttemptState.KILLED, DAZRXLNSDN.next().getReport().getTaskAttemptState());
        Assert.assertEquals("Attempt state not correct", TaskAttemptState.SUCCEEDED, DAZRXLNSDN.next().getReport().getTaskAttemptState());
        XJKLRZLKKU = HNITPFDPYU.getAttempts();
        Assert.assertEquals("No of attempts is not correct", 1, XJKLRZLKKU.size());
        DAZRXLNSDN = XJKLRZLKKU.values().iterator();
        Assert.assertEquals("Attempt state not correct", TaskAttemptState.SUCCEEDED, DAZRXLNSDN.next().getReport().getTaskAttemptState());
    }

    static class BlockingMRApp extends MRApp {
        private CountDownLatch CYZBQUPWCF;

        BlockingMRApp(int maps, int reduces, CountDownLatch latch) {
            super(maps, reduces, true, "testKill", true);
            this.CYZBQUPWCF = latch;
        }

        @Override
        protected void attemptLaunched(TaskAttemptId attemptID) {
            if ((attemptID.getTaskId().getId() == 0) && (attemptID.getId() == 0)) {
                // this blocks the first task's first attempt
                // the subsequent ones are completed
                try {
                    CYZBQUPWCF.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } else {
                getContext().getEventHandler().handle(new TaskAttemptEvent(attemptID, TaskAttemptEventType.TA_DONE));
            }
        }
    }

    public static void main(String[] CDWHSEGYUQ) throws Exception {
        TestKill UYDKMLGGPW = new TestKill();
        UYDKMLGGPW.testKillJob();
        UYDKMLGGPW.testKillTask();
        UYDKMLGGPW.testKillTaskAttempt();
    }
}