/**
 * Helper for writing snapshot related tests
 */
public class SnapshotTestHelper {
    public static final Log PFPZNUPMNY = LogFactory.getLog(SnapshotTestHelper.class);

    /**
     * Disable the logs that are not very useful for snapshot related tests.
     */
    public static void disableLogs() {
        final String[] PVXDYOVGXT = new String[]{ "org.apache.hadoop.hdfs.server.datanode.BlockPoolSliceScanner", "org.apache.hadoop.hdfs.server.datanode.fsdataset.impl.FsDatasetImpl", "org.apache.hadoop.hdfs.server.datanode.fsdataset.impl.FsDatasetAsyncDiskService" };
        for (String IIFBQPYQOA : PVXDYOVGXT) {
            SnapshotTestHelper.setLevel2OFF(LogFactory.getLog(IIFBQPYQOA));
        }
        SnapshotTestHelper.setLevel2OFF(LogFactory.getLog(UserGroupInformation.class));
        SnapshotTestHelper.setLevel2OFF(LogFactory.getLog(BlockManager.class));
        SnapshotTestHelper.setLevel2OFF(LogFactory.getLog(FSNamesystem.class));
        SnapshotTestHelper.setLevel2OFF(LogFactory.getLog(DirectoryScanner.class));
        SnapshotTestHelper.setLevel2OFF(LogFactory.getLog(MetricsSystemImpl.class));
        SnapshotTestHelper.setLevel2OFF(LOG);
        SnapshotTestHelper.setLevel2OFF(HttpServer2.LOG);
        SnapshotTestHelper.setLevel2OFF(DataNode.LOG);
        SnapshotTestHelper.setLevel2OFF(BlockPoolSliceStorage.LOG);
        SnapshotTestHelper.setLevel2OFF(LeaseManager.LOG);
        SnapshotTestHelper.setLevel2OFF(stateChangeLog);
        SnapshotTestHelper.setLevel2OFF(blockStateChangeLog);
        SnapshotTestHelper.setLevel2OFF(DFSClient.LOG);
        SnapshotTestHelper.setLevel2OFF(Server.LOG);
    }

    static void setLevel2OFF(Object RDWPJNAQII) {
        ((org.apache.commons.logging.impl.Log4JLogger) (RDWPJNAQII)).getLogger().setLevel(Level.OFF);
    }

    private SnapshotTestHelper() {
        // Cannot be instantinatied
    }

    public static Path getSnapshotRoot(Path TDMXDJKVPO, String XIYZGWSOLJ) {
        return new Path(TDMXDJKVPO, (HdfsConstants.DOT_SNAPSHOT_DIR + "/") + XIYZGWSOLJ);
    }

    public static Path getSnapshotPath(Path UUFMFCJVIL, String IIFYHRGDCD, String SEVYHZIMNA) {
        return new Path(SnapshotTestHelper.getSnapshotRoot(UUFMFCJVIL, IIFYHRGDCD), SEVYHZIMNA);
    }

    /**
     * Create snapshot for a dir using a given snapshot name
     *
     * @param hdfs
     * 		DistributedFileSystem instance
     * @param snapshotRoot
     * 		The dir to be snapshotted
     * @param snapshotName
     * 		The name of the snapshot
     * @return The path of the snapshot root
     */
    public static Path createSnapshot(DistributedFileSystem TZKEZKHQUY, Path MXEPLEKIPX, String PNRVLEFUKI) throws Exception {
        SnapshotTestHelper.PFPZNUPMNY.info((("createSnapshot " + PNRVLEFUKI) + " for ") + MXEPLEKIPX);
        assertTrue(TZKEZKHQUY.exists(MXEPLEKIPX));
        TZKEZKHQUY.allowSnapshot(MXEPLEKIPX);
        TZKEZKHQUY.createSnapshot(MXEPLEKIPX, PNRVLEFUKI);
        // set quota to a large value for testing counts
        TZKEZKHQUY.setQuota(MXEPLEKIPX, Long.MAX_VALUE - 1, Long.MAX_VALUE - 1);
        return SnapshotTestHelper.getSnapshotRoot(MXEPLEKIPX, PNRVLEFUKI);
    }

    /**
     * Check the functionality of a snapshot.
     *
     * @param hdfs
     * 		DistributedFileSystem instance
     * @param snapshotRoot
     * 		The root of the snapshot
     * @param snapshottedDir
     * 		The snapshotted directory
     */
    public static void checkSnapshotCreation(DistributedFileSystem FGCETRECFM, Path THUVWPHXOP, Path YNADNYGSEQ) throws Exception {
        // Currently we only check if the snapshot was created successfully
        assertTrue(FGCETRECFM.exists(THUVWPHXOP));
        // Compare the snapshot with the current dir
        FileStatus[] ZBNKKAPECK = FGCETRECFM.listStatus(YNADNYGSEQ);
        FileStatus[] LIWXWFKSXO = FGCETRECFM.listStatus(THUVWPHXOP);
        assertEquals((("snapshottedDir=" + YNADNYGSEQ) + ", snapshotRoot=") + THUVWPHXOP, ZBNKKAPECK.length, LIWXWFKSXO.length);
    }

    /**
     * Compare two dumped trees that are stored in two files. The following is an
     * example of the dumped tree:
     *
     * <pre>
     * information of root
     * +- the first child of root (e.g., /foo)
     *   +- the first child of /foo
     *   ...
     *   \- the last child of /foo (e.g., /foo/bar)
     *     +- the first child of /foo/bar
     *     ...
     *   snapshots of /foo
     *   +- snapshot s_1
     *   ...
     *   \- snapshot s_n
     * +- second child of root
     *   ...
     * \- last child of root
     *
     * The following information is dumped for each inode:
     * localName (className@hashCode) parent permission group user
     *
     * Specific information for different types of INode:
     * {@link INodeDirectory}:childrenSize
     * {@link INodeFile}: fileSize, block list. Check {@link BlockInfo#toString()}
     * and {@link BlockInfoUnderConstruction#toString()} for detailed information.
     * {@link FileWithSnapshot}: next link
     * </pre>
     *
     * @see INode#dumpTreeRecursively()
     */
    public static void compareDumpedTreeInFile(File BGWGUXTRTJ, File DJSUGZJVVW, boolean VYNNUMWFOT) throws IOException {
        try {
            SnapshotTestHelper.compareDumpedTreeInFile(BGWGUXTRTJ, DJSUGZJVVW, VYNNUMWFOT, false);
        } catch (Throwable t) {
            SnapshotTestHelper.PFPZNUPMNY.info(((("FAILED compareDumpedTreeInFile(" + BGWGUXTRTJ) + ", ") + DJSUGZJVVW) + ")", t);
            SnapshotTestHelper.compareDumpedTreeInFile(BGWGUXTRTJ, DJSUGZJVVW, VYNNUMWFOT, true);
        }
    }

    private static void compareDumpedTreeInFile(File CXQCLPXEXK, File COHZGZDJTV, boolean KOLFSUGQTJ, boolean NSLIDBQZKW) throws IOException {
        if (NSLIDBQZKW) {
            SnapshotTestHelper.printFile(CXQCLPXEXK);
            SnapshotTestHelper.printFile(COHZGZDJTV);
        }
        BufferedReader WLUZIJQHVZ = new BufferedReader(new FileReader(CXQCLPXEXK));
        BufferedReader UQORFSNAVH = new BufferedReader(new FileReader(COHZGZDJTV));
        try {
            String PSXRIFWYAC = "";
            String HLGFXNBMEJ = "";
            while (((PSXRIFWYAC = WLUZIJQHVZ.readLine()) != null) && ((HLGFXNBMEJ = UQORFSNAVH.readLine()) != null)) {
                if (NSLIDBQZKW) {
                    System.out.println();
                    System.out.println("1) " + PSXRIFWYAC);
                    System.out.println("2) " + HLGFXNBMEJ);
                }
                // skip the hashCode part of the object string during the comparison,
                // also ignore the difference between INodeFile/INodeFileWithSnapshot
                PSXRIFWYAC = PSXRIFWYAC.replaceAll("INodeFileWithSnapshot", "INodeFile");
                HLGFXNBMEJ = HLGFXNBMEJ.replaceAll("INodeFileWithSnapshot", "INodeFile");
                PSXRIFWYAC = PSXRIFWYAC.replaceAll("@[\\dabcdef]+", "");
                HLGFXNBMEJ = HLGFXNBMEJ.replaceAll("@[\\dabcdef]+", "");
                // skip the replica field of the last block of an
                // INodeFileUnderConstruction
                PSXRIFWYAC = PSXRIFWYAC.replaceAll("replicas=\\[.*\\]", "replicas=[]");
                HLGFXNBMEJ = HLGFXNBMEJ.replaceAll("replicas=\\[.*\\]", "replicas=[]");
                if (!KOLFSUGQTJ) {
                    PSXRIFWYAC = PSXRIFWYAC.replaceAll("Quota\\[.*\\]", "Quota[]");
                    HLGFXNBMEJ = HLGFXNBMEJ.replaceAll("Quota\\[.*\\]", "Quota[]");
                }
                // skip the specific fields of BlockInfoUnderConstruction when the node
                // is an INodeFileSnapshot or an INodeFileUnderConstructionSnapshot
                if (PSXRIFWYAC.contains("(INodeFileSnapshot)") || PSXRIFWYAC.contains("(INodeFileUnderConstructionSnapshot)")) {
                    PSXRIFWYAC = PSXRIFWYAC.replaceAll("\\{blockUCState=\\w+, primaryNodeIndex=[-\\d]+, replicas=\\[\\]\\}", "");
                    HLGFXNBMEJ = HLGFXNBMEJ.replaceAll("\\{blockUCState=\\w+, primaryNodeIndex=[-\\d]+, replicas=\\[\\]\\}", "");
                }
                assertEquals(PSXRIFWYAC, HLGFXNBMEJ);
            } 
            Assert.assertNull(WLUZIJQHVZ.readLine());
            Assert.assertNull(UQORFSNAVH.readLine());
        } finally {
            WLUZIJQHVZ.close();
            UQORFSNAVH.close();
        }
    }

    static void printFile(File ELQILWVBIA) throws IOException {
        System.out.println();
        System.out.println("File: " + ELQILWVBIA);
        BufferedReader UGEDFFRSWW = new BufferedReader(new FileReader(ELQILWVBIA));
        try {
            for (String PXCYDRUPLU; (PXCYDRUPLU = UGEDFFRSWW.readLine()) != null;) {
                System.out.println(PXCYDRUPLU);
            }
        } finally {
            UGEDFFRSWW.close();
        }
    }

    public static void dumpTree2File(FSDirectory YMJQXMMYCA, File ZNMIKZTPQO) throws IOException {
        final PrintWriter TFBCICFZVL = new PrintWriter(new FileWriter(ZNMIKZTPQO, false), true);
        YMJQXMMYCA.getINode("/").dumpTreeRecursively(TFBCICFZVL, new StringBuilder(), Snapshot.CURRENT_STATE_ID);
        TFBCICFZVL.close();
    }

    /**
     * Generate the path for a snapshot file.
     *
     * @param snapshotRoot
     * 		of format
     * 		{@literal <snapshottble_dir>/.snapshot/<snapshot_name>}
     * @param file
     * 		path to a file
     * @return The path of the snapshot of the file assuming the file has a
    snapshot under the snapshot root of format
    {@literal <snapshottble_dir>/.snapshot/<snapshot_name>/<path_to_file_inside_snapshot>}
    . Null if the file is not under the directory associated with the
    snapshot root.
     */
    static Path getSnapshotFile(Path EUNNBUSPJA, Path BBKEMAIUFT) {
        Path ASGFPPKZNS = EUNNBUSPJA.getParent();
        if ((ASGFPPKZNS != null) && ASGFPPKZNS.getName().equals(".snapshot")) {
            Path AKVVSVDLJA = ASGFPPKZNS.getParent();
            if (BBKEMAIUFT.toString().contains(AKVVSVDLJA.toString()) && (!BBKEMAIUFT.equals(AKVVSVDLJA))) {
                String XWWHJRPBWE = BBKEMAIUFT.toString().substring(AKVVSVDLJA.toString().length() + 1);
                Path PSMLBUHKFA = new Path(EUNNBUSPJA, XWWHJRPBWE);
                return PSMLBUHKFA;
            }
        }
        return null;
    }

    /**
     * A class creating directories trees for snapshot testing. For simplicity,
     * the directory tree is a binary tree, i.e., each directory has two children
     * as snapshottable directories.
     */
    static class TestDirectoryTree {
        /**
         * Height of the directory tree
         */
        final int SBBKDHFWDQ;

        /**
         * Top node of the directory tree
         */
        final SnapshotTestHelper.TestDirectoryTree.Node CEUGFDFICM;

        /**
         * A map recording nodes for each tree level
         */
        final Map<Integer, ArrayList<SnapshotTestHelper.TestDirectoryTree.Node>> BDNVFVGPSF;

        /**
         * Constructor to build a tree of given {@code height}
         */
        TestDirectoryTree(int height, FileSystem fs) throws Exception {
            this.SBBKDHFWDQ = height;
            this.CEUGFDFICM = new SnapshotTestHelper.TestDirectoryTree.Node(new Path("/TestSnapshot"), 0, null, fs);
            this.BDNVFVGPSF = new HashMap<Integer, ArrayList<SnapshotTestHelper.TestDirectoryTree.Node>>();
            addDirNode(CEUGFDFICM, 0);
            genChildren(CEUGFDFICM, height - 1, fs);
        }

        /**
         * Add a node into the levelMap
         */
        private void addDirNode(SnapshotTestHelper.TestDirectoryTree.Node node, int atLevel) {
            ArrayList<SnapshotTestHelper.TestDirectoryTree.Node> list = BDNVFVGPSF.get(atLevel);
            if (list == null) {
                list = new ArrayList<SnapshotTestHelper.TestDirectoryTree.Node>();
                BDNVFVGPSF.put(atLevel, list);
            }
            list.add(node);
        }

        int GDPXRXIPVC = 0;

        /**
         * Recursively generate the tree based on the height.
         *
         * @param parent
         * 		The parent node
         * @param level
         * 		The remaining levels to generate
         * @param fs
         * 		The FileSystem where to generate the files/dirs
         * @throws Exception
         * 		
         */
        private void genChildren(SnapshotTestHelper.TestDirectoryTree.Node parent, int level, FileSystem fs) throws Exception {
            if (level == 0) {
                return;
            }
            parent.ONPOWWCMUI = new SnapshotTestHelper.TestDirectoryTree.Node(new Path(parent.GIURBCDWRN, "left" + (++GDPXRXIPVC)), SBBKDHFWDQ - level, parent, fs);
            parent.OFACHBGXFU = new SnapshotTestHelper.TestDirectoryTree.Node(new Path(parent.GIURBCDWRN, "right" + (++GDPXRXIPVC)), SBBKDHFWDQ - level, parent, fs);
            addDirNode(parent.ONPOWWCMUI, parent.ONPOWWCMUI.ALJTULCQKD);
            addDirNode(parent.OFACHBGXFU, parent.OFACHBGXFU.ALJTULCQKD);
            genChildren(parent.ONPOWWCMUI, level - 1, fs);
            genChildren(parent.OFACHBGXFU, level - 1, fs);
        }

        /**
         * Randomly retrieve a node from the directory tree.
         *
         * @param random
         * 		A random instance passed by user.
         * @param excludedList
         * 		Excluded list, i.e., the randomly generated node
         * 		cannot be one of the nodes in this list.
         * @return a random node from the tree.
         */
        SnapshotTestHelper.TestDirectoryTree.Node getRandomDirNode(Random random, List<SnapshotTestHelper.TestDirectoryTree.Node> excludedList) {
            while (true) {
                int level = random.nextInt(SBBKDHFWDQ);
                ArrayList<SnapshotTestHelper.TestDirectoryTree.Node> levelList = BDNVFVGPSF.get(level);
                int index = random.nextInt(levelList.size());
                SnapshotTestHelper.TestDirectoryTree.Node randomNode = levelList.get(index);
                if ((excludedList == null) || (!excludedList.contains(randomNode))) {
                    return randomNode;
                }
            } 
        }

        /**
         * The class representing a node in {@link TestDirectoryTree}.
         * <br>
         * This contains:
         * <ul>
         * <li>Two children representing the two snapshottable directories</li>
         * <li>A list of files for testing, so that we can check snapshots
         * after file creation/deletion/modification.</li>
         * <li>A list of non-snapshottable directories, to test snapshots with
         * directory creation/deletion. Note that this is needed because the
         * deletion of a snapshottale directory with snapshots is not allowed.</li>
         * </ul>
         */
        static class Node {
            /**
             * The level of this node in the directory tree
             */
            final int ALJTULCQKD;

            /**
             * Children
             */
            SnapshotTestHelper.TestDirectoryTree.Node ONPOWWCMUI;

            SnapshotTestHelper.TestDirectoryTree.Node OFACHBGXFU;

            /**
             * Parent node of the node
             */
            final SnapshotTestHelper.TestDirectoryTree.Node VLGCRJZIZJ;

            /**
             * File path of the node
             */
            final Path GIURBCDWRN;

            /**
             * The file path list for testing snapshots before/after file
             * creation/deletion/modification
             */
            ArrayList<Path> BKFTUKBFBB;

            /**
             * Each time for testing snapshots with file creation, since we do not
             * want to insert new files into the fileList, we always create the file
             * that was deleted last time. Thus we record the index for deleted file
             * in the fileList, and roll the file modification forward in the list.
             */
            int VJHUDOLHRT = 0;

            /**
             * A list of non-snapshottable directories for testing snapshots with
             * directory creation/deletion
             */
            final ArrayList<SnapshotTestHelper.TestDirectoryTree.Node> BLGLFVFPCM;

            Node(Path path, int level, SnapshotTestHelper.TestDirectoryTree.Node parent, FileSystem fs) throws Exception {
                this.GIURBCDWRN = path;
                this.ALJTULCQKD = level;
                this.VLGCRJZIZJ = parent;
                this.BLGLFVFPCM = new ArrayList<SnapshotTestHelper.TestDirectoryTree.Node>();
                fs.mkdirs(GIURBCDWRN);
            }

            /**
             * Create files and add them in the fileList. Initially the last element
             * in the fileList is set to null (where we start file creation).
             */
            void initFileList(FileSystem fs, String namePrefix, long fileLen, short replication, long seed, int numFiles) throws Exception {
                BKFTUKBFBB = new ArrayList<Path>(numFiles);
                for (int i = 0; i < numFiles; i++) {
                    Path file = new Path(GIURBCDWRN, (namePrefix + "-f") + i);
                    BKFTUKBFBB.add(file);
                    if (i < (numFiles - 1)) {
                        DFSTestUtil.createFile(fs, file, fileLen, replication, seed);
                    }
                }
                VJHUDOLHRT = numFiles - 1;
            }

            @Override
            public boolean equals(Object o) {
                if ((o != null) && (o instanceof SnapshotTestHelper.TestDirectoryTree.Node)) {
                    SnapshotTestHelper.TestDirectoryTree.Node node = ((SnapshotTestHelper.TestDirectoryTree.Node) (o));
                    return node.GIURBCDWRN.equals(GIURBCDWRN);
                }
                return false;
            }

            @Override
            public int hashCode() {
                return GIURBCDWRN.hashCode();
            }
        }
    }

    public static void dumpTree(String VZLUSWNJPR, MiniDFSCluster XINCNMARMD) throws UnresolvedLinkException {
        System.out.println("XXX " + VZLUSWNJPR);
        XINCNMARMD.getNameNode().getNamesystem().getFSDirectory().getINode("/").dumpTreeRecursively(System.out);
    }
}