/**
 * Test enumerations in TestHdfsServerConstants.
 */
public class TestHdfsServerConstants {
    /**
     * Verify that parsing a StartupOption string gives the expected results.
     * If a RollingUpgradeStartupOption is specified than it is also checked.
     *
     * @param value
     * 		
     * @param expectedOption
     * 		
     * @param expectedRollupOption
     * 		optional, may be null.
     */
    private static void verifyStartupOptionResult(String BCUNMWITZK, StartupOption SVJPAMNBDE, RollingUpgradeStartupOption JTCDTVYMFS) {
        StartupOption TFRLVZUCZH = StartupOption.getEnum(BCUNMWITZK);
        assertThat(TFRLVZUCZH, is(SVJPAMNBDE));
        if (JTCDTVYMFS != null) {
            assertThat(TFRLVZUCZH.getRollingUpgradeStartupOption(), is(JTCDTVYMFS));
        }
    }

    /**
     * Test that we can parse a StartupOption string without the optional
     * RollingUpgradeStartupOption.
     */
    @Test
    public void testStartupOptionParsing() {
        TestHdfsServerConstants.verifyStartupOptionResult("FORMAT", FORMAT, null);
        TestHdfsServerConstants.verifyStartupOptionResult("REGULAR", REGULAR, null);
        TestHdfsServerConstants.verifyStartupOptionResult("CHECKPOINT", CHECKPOINT, null);
        TestHdfsServerConstants.verifyStartupOptionResult("UPGRADE", UPGRADE, null);
        TestHdfsServerConstants.verifyStartupOptionResult("ROLLBACK", ROLLBACK, null);
        TestHdfsServerConstants.verifyStartupOptionResult("FINALIZE", FINALIZE, null);
        TestHdfsServerConstants.verifyStartupOptionResult("ROLLINGUPGRADE", ROLLINGUPGRADE, null);
        TestHdfsServerConstants.verifyStartupOptionResult("IMPORT", IMPORT, null);
        TestHdfsServerConstants.verifyStartupOptionResult("INITIALIZESHAREDEDITS", INITIALIZESHAREDEDITS, null);
        try {
            TestHdfsServerConstants.verifyStartupOptionResult("UNKNOWN(UNKNOWNOPTION)", FORMAT, null);
            fail("Failed to get expected IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
            // Expected!
        }
    }

    /**
     * Test that we can parse a StartupOption string with a
     * RollingUpgradeStartupOption.
     */
    @Test
    public void testRollingUpgradeStartupOptionParsing() {
        TestHdfsServerConstants.verifyStartupOptionResult("ROLLINGUPGRADE(ROLLBACK)", ROLLINGUPGRADE, RollingUpgradeStartupOption.ROLLBACK);
        TestHdfsServerConstants.verifyStartupOptionResult("ROLLINGUPGRADE(DOWNGRADE)", ROLLINGUPGRADE, DOWNGRADE);
        try {
            TestHdfsServerConstants.verifyStartupOptionResult("ROLLINGUPGRADE(UNKNOWNOPTION)", ROLLINGUPGRADE, null);
            fail("Failed to get expected IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
            // Expected!
        }
    }
}