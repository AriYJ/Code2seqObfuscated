/**
 * test JobConf
 */
public class TestJobConf {
    /**
     * test getters and setters of JobConf
     */
    @SuppressWarnings("deprecation")
    @Test(timeout = 5000)
    public void testJobConf() {
        JobConf EWJDQTSTAP = new JobConf();
        // test default value
        Pattern BSVYKZLCWD = EWJDQTSTAP.getJarUnpackPattern();
        assertEquals(Pattern.compile("(?:classes/|lib/).*").toString(), BSVYKZLCWD.toString());
        // default value
        assertFalse(EWJDQTSTAP.getKeepFailedTaskFiles());
        EWJDQTSTAP.setKeepFailedTaskFiles(true);
        assertTrue(EWJDQTSTAP.getKeepFailedTaskFiles());
        // default value
        assertNull(EWJDQTSTAP.getKeepTaskFilesPattern());
        EWJDQTSTAP.setKeepTaskFilesPattern("123454");
        assertEquals("123454", EWJDQTSTAP.getKeepTaskFilesPattern());
        // default value
        assertNotNull(EWJDQTSTAP.getWorkingDirectory());
        EWJDQTSTAP.setWorkingDirectory(new Path("test"));
        assertTrue(EWJDQTSTAP.getWorkingDirectory().toString().endsWith("test"));
        // default value
        assertEquals(1, EWJDQTSTAP.getNumTasksToExecutePerJvm());
        // default value
        assertNull(EWJDQTSTAP.getKeyFieldComparatorOption());
        EWJDQTSTAP.setKeyFieldComparatorOptions("keySpec");
        assertEquals("keySpec", EWJDQTSTAP.getKeyFieldComparatorOption());
        // default value
        assertFalse(EWJDQTSTAP.getUseNewReducer());
        EWJDQTSTAP.setUseNewReducer(true);
        assertTrue(EWJDQTSTAP.getUseNewReducer());
        // default
        assertTrue(EWJDQTSTAP.getMapSpeculativeExecution());
        assertTrue(EWJDQTSTAP.getReduceSpeculativeExecution());
        assertTrue(EWJDQTSTAP.getSpeculativeExecution());
        EWJDQTSTAP.setReduceSpeculativeExecution(false);
        assertTrue(EWJDQTSTAP.getSpeculativeExecution());
        EWJDQTSTAP.setMapSpeculativeExecution(false);
        assertFalse(EWJDQTSTAP.getSpeculativeExecution());
        assertFalse(EWJDQTSTAP.getMapSpeculativeExecution());
        assertFalse(EWJDQTSTAP.getReduceSpeculativeExecution());
        EWJDQTSTAP.setSessionId("ses");
        assertEquals("ses", EWJDQTSTAP.getSessionId());
        assertEquals(3, EWJDQTSTAP.getMaxTaskFailuresPerTracker());
        EWJDQTSTAP.setMaxTaskFailuresPerTracker(2);
        assertEquals(2, EWJDQTSTAP.getMaxTaskFailuresPerTracker());
        assertEquals(0, EWJDQTSTAP.getMaxMapTaskFailuresPercent());
        EWJDQTSTAP.setMaxMapTaskFailuresPercent(50);
        assertEquals(50, EWJDQTSTAP.getMaxMapTaskFailuresPercent());
        assertEquals(0, EWJDQTSTAP.getMaxReduceTaskFailuresPercent());
        EWJDQTSTAP.setMaxReduceTaskFailuresPercent(70);
        assertEquals(70, EWJDQTSTAP.getMaxReduceTaskFailuresPercent());
        // by default
        assertEquals(NORMAL.name(), EWJDQTSTAP.getJobPriority().name());
        EWJDQTSTAP.setJobPriority(HIGH);
        assertEquals(HIGH.name(), EWJDQTSTAP.getJobPriority().name());
        assertNull(EWJDQTSTAP.getJobSubmitHostName());
        EWJDQTSTAP.setJobSubmitHostName("hostname");
        assertEquals("hostname", EWJDQTSTAP.getJobSubmitHostName());
        // default
        assertNull(EWJDQTSTAP.getJobSubmitHostAddress());
        EWJDQTSTAP.setJobSubmitHostAddress("ww");
        assertEquals("ww", EWJDQTSTAP.getJobSubmitHostAddress());
        // default value
        assertFalse(EWJDQTSTAP.getProfileEnabled());
        EWJDQTSTAP.setProfileEnabled(true);
        assertTrue(EWJDQTSTAP.getProfileEnabled());
        // default value
        assertEquals(EWJDQTSTAP.getProfileTaskRange(true).toString(), "0-2");
        assertEquals(EWJDQTSTAP.getProfileTaskRange(false).toString(), "0-2");
        EWJDQTSTAP.setProfileTaskRange(true, "0-3");
        assertEquals(EWJDQTSTAP.getProfileTaskRange(false).toString(), "0-2");
        assertEquals(EWJDQTSTAP.getProfileTaskRange(true).toString(), "0-3");
        // default value
        assertNull(EWJDQTSTAP.getMapDebugScript());
        EWJDQTSTAP.setMapDebugScript("mDbgScript");
        assertEquals("mDbgScript", EWJDQTSTAP.getMapDebugScript());
        // default value
        assertNull(EWJDQTSTAP.getReduceDebugScript());
        EWJDQTSTAP.setReduceDebugScript("rDbgScript");
        assertEquals("rDbgScript", EWJDQTSTAP.getReduceDebugScript());
        // default value
        assertNull(EWJDQTSTAP.getJobLocalDir());
        assertEquals("default", EWJDQTSTAP.getQueueName());
        EWJDQTSTAP.setQueueName("qname");
        assertEquals("qname", EWJDQTSTAP.getQueueName());
        EWJDQTSTAP.setMemoryForMapTask(100 * 1000);
        assertEquals(100 * 1000, EWJDQTSTAP.getMemoryForMapTask());
        EWJDQTSTAP.setMemoryForReduceTask(1000 * 1000);
        assertEquals(1000 * 1000, EWJDQTSTAP.getMemoryForReduceTask());
        assertEquals(-1, EWJDQTSTAP.getMaxPhysicalMemoryForTask());
        assertEquals("The variable key is no longer used.", JobConf.deprecatedString("key"));
        // make sure mapreduce.map|reduce.java.opts are not set by default
        // so that they won't override mapred.child.java.opts
        assertEquals("mapreduce.map.java.opts should not be set by default", null, EWJDQTSTAP.get(MAPRED_MAP_TASK_JAVA_OPTS));
        assertEquals("mapreduce.reduce.java.opts should not be set by default", null, EWJDQTSTAP.get(MAPRED_REDUCE_TASK_JAVA_OPTS));
    }

    /**
     * Ensure that M/R 1.x applications can get and set task virtual memory with
     * old property names
     */
    @SuppressWarnings("deprecation")
    @Test(timeout = 1000)
    public void testDeprecatedPropertyNameForTaskVmem() {
        JobConf OBSRGWRUGF = new JobConf();
        OBSRGWRUGF.setLong(MAPRED_JOB_MAP_MEMORY_MB_PROPERTY, 1024);
        OBSRGWRUGF.setLong(MAPRED_JOB_REDUCE_MEMORY_MB_PROPERTY, 1024);
        Assert.assertEquals(1024, OBSRGWRUGF.getMemoryForMapTask());
        Assert.assertEquals(1024, OBSRGWRUGF.getMemoryForReduceTask());
        // Make sure new property names aren't broken by the old ones
        OBSRGWRUGF.setLong(MAPREDUCE_JOB_MAP_MEMORY_MB_PROPERTY, 1025);
        OBSRGWRUGF.setLong(MAPREDUCE_JOB_REDUCE_MEMORY_MB_PROPERTY, 1025);
        Assert.assertEquals(1025, OBSRGWRUGF.getMemoryForMapTask());
        Assert.assertEquals(1025, OBSRGWRUGF.getMemoryForReduceTask());
        OBSRGWRUGF.setMemoryForMapTask(2048);
        OBSRGWRUGF.setMemoryForReduceTask(2048);
        Assert.assertEquals(2048, OBSRGWRUGF.getLong(MAPRED_JOB_MAP_MEMORY_MB_PROPERTY, -1));
        Assert.assertEquals(2048, OBSRGWRUGF.getLong(MAPRED_JOB_REDUCE_MEMORY_MB_PROPERTY, -1));
        // Make sure new property names aren't broken by the old ones
        Assert.assertEquals(2048, OBSRGWRUGF.getLong(MAPREDUCE_JOB_MAP_MEMORY_MB_PROPERTY, -1));
        Assert.assertEquals(2048, OBSRGWRUGF.getLong(MAPREDUCE_JOB_REDUCE_MEMORY_MB_PROPERTY, -1));
    }
}