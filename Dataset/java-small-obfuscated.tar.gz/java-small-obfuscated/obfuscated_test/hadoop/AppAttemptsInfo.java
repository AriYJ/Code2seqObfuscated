@XmlRootElement(name = "appAttempts")
@XmlAccessorType(XmlAccessType.FIELD)
public class AppAttemptsInfo {
    @XmlElement(name = "appAttempt")
    protected ArrayList<AppAttemptInfo> HAPQBOBJZX = new ArrayList<AppAttemptInfo>();

    // JAXB needs this
    public AppAttemptsInfo() {
    }

    public void add(AppAttemptInfo HKUVQSVNSK) {
        this.HAPQBOBJZX.add(HKUVQSVNSK);
    }

    public ArrayList<AppAttemptInfo> getAttempts() {
        return this.HAPQBOBJZX;
    }
}