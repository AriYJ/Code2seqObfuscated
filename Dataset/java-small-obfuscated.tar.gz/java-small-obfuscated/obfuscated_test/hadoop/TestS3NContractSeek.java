public class TestS3NContractSeek extends AbstractContractSeekTest {
    @Override
    protected AbstractFSContract createContract(Configuration ZKSKJEKJQH) {
        return new NativeS3Contract(ZKSKJEKJQH);
    }
}