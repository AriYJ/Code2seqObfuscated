/**
 * A Convenience class that creates output lazily.
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LazyOutputFormat<K, V> extends FilterOutputFormat<K, V> {
    /**
     * Set the underlying output format for LazyOutputFormat.
     *
     * @param job
     * 		the {@link JobConf} to modify
     * @param theClass
     * 		the underlying class
     */
    @SuppressWarnings("unchecked")
    public static void setOutputFormatClass(JobConf ZJNCTDGVDR, Class<? extends OutputFormat> QKHWWGKQFB) {
        ZJNCTDGVDR.setOutputFormat(LazyOutputFormat.class);
        ZJNCTDGVDR.setClass("mapreduce.output.lazyoutputformat.outputformat", QKHWWGKQFB, OutputFormat.class);
    }

    @Override
    public RecordWriter<K, V> getRecordWriter(FileSystem USWSUOBFNT, JobConf UBWLDIAJHL, String HFDNBGSQEV, Progressable FBHGFBPJCB) throws IOException {
        if (baseOut == null) {
            getBaseOutputFormat(UBWLDIAJHL);
        }
        return new LazyOutputFormat.LazyRecordWriter<K, V>(UBWLDIAJHL, baseOut, HFDNBGSQEV, FBHGFBPJCB);
    }

    @Override
    public void checkOutputSpecs(FileSystem QRNQXQDUDY, JobConf ZETGVRDENQ) throws IOException {
        if (baseOut == null) {
            getBaseOutputFormat(ZETGVRDENQ);
        }
        super.checkOutputSpecs(QRNQXQDUDY, ZETGVRDENQ);
    }

    @SuppressWarnings("unchecked")
    private void getBaseOutputFormat(JobConf WZUTLCNYOO) throws IOException {
        baseOut = ReflectionUtils.newInstance(WZUTLCNYOO.getClass("mapreduce.output.lazyoutputformat.outputformat", null, OutputFormat.class), WZUTLCNYOO);
        if (baseOut == null) {
            throw new IOException("Ouput format not set for LazyOutputFormat");
        }
    }

    /**
     * <code>LazyRecordWriter</code> is a convenience
     * class that works with LazyOutputFormat.
     */
    private static class LazyRecordWriter<K, V> extends FilterRecordWriter<K, V> {
        final OutputFormat BDYFMZLTVR;

        final String UEVYDHJFWO;

        final Progressable BIBFIMMXRF;

        final JobConf QBEHOLCHXE;

        public LazyRecordWriter(JobConf job, OutputFormat of, String name, Progressable progress) throws IOException {
            this.of = of;
            this.job = job;
            this.name = name;
            this.progress = progress;
        }

        @Override
        public void close(Reporter reporter) throws IOException {
            if (rawWriter != null) {
                rawWriter.close(reporter);
            }
        }

        @Override
        public void write(K key, V value) throws IOException {
            if (rawWriter == null) {
                createRecordWriter();
            }
            super.write(key, value);
        }

        @SuppressWarnings("unchecked")
        private void createRecordWriter() throws IOException {
            FileSystem fs = FileSystem.get(QBEHOLCHXE);
            rawWriter = BDYFMZLTVR.getRecordWriter(fs, QBEHOLCHXE, UEVYDHJFWO, BIBFIMMXRF);
        }
    }
}