/**
 * Response from KeyStone deserialized into AuthenticationResponse class.
 * THIS FILE IS MAPPED BY JACKSON TO AND FROM JSON.
 * DO NOT RENAME OR MODIFY FIELDS AND THEIR ACCESSORS.
 */
public class AuthenticationResponse {
    private Object WPEKMWCCVW;

    private List<Catalog> YADRKFOPBG;

    private User LCLGFAOEQK;

    private AccessToken GMZCITOSDI;

    public Object getMetadata() {
        return WPEKMWCCVW;
    }

    public void setMetadata(Object LPHRHDSDTR) {
        this.WPEKMWCCVW = LPHRHDSDTR;
    }

    public List<Catalog> getServiceCatalog() {
        return YADRKFOPBG;
    }

    public void setServiceCatalog(List<Catalog> ZDHNJACJTI) {
        this.YADRKFOPBG = ZDHNJACJTI;
    }

    public User getUser() {
        return LCLGFAOEQK;
    }

    public void setUser(User VGQAAEAVJG) {
        this.LCLGFAOEQK = VGQAAEAVJG;
    }

    public AccessToken getToken() {
        return GMZCITOSDI;
    }

    public void setToken(AccessToken VFBQYNIGRP) {
        this.GMZCITOSDI = VFBQYNIGRP;
    }
}