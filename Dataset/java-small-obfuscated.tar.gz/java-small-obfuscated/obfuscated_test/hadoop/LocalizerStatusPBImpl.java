public class LocalizerStatusPBImpl extends ProtoBase<LocalizerStatusProto> implements LocalizerStatus {
    LocalizerStatusProto IUQMEBXEPD = LocalizerStatusProto.getDefaultInstance();

    Builder TVTKGWTAOD = null;

    boolean YBJANLIQOS = false;

    private List<LocalResourceStatus> GIKBFSMLJT = null;

    public LocalizerStatusPBImpl() {
        TVTKGWTAOD = LocalizerStatusProto.newBuilder();
    }

    public LocalizerStatusPBImpl(LocalizerStatusProto VBPMKVROIC) {
        this.IUQMEBXEPD = VBPMKVROIC;
        YBJANLIQOS = true;
    }

    public LocalizerStatusProto getProto() {
        mergeLocalToProto();
        IUQMEBXEPD = (YBJANLIQOS) ? IUQMEBXEPD : TVTKGWTAOD.build();
        YBJANLIQOS = true;
        return IUQMEBXEPD;
    }

    private void mergeLocalToBuilder() {
        if (this.GIKBFSMLJT != null) {
            addResourcesToProto();
        }
    }

    private void mergeLocalToProto() {
        if (YBJANLIQOS)
            maybeInitBuilder();

        mergeLocalToBuilder();
        IUQMEBXEPD = TVTKGWTAOD.build();
        YBJANLIQOS = true;
    }

    private void maybeInitBuilder() {
        if (YBJANLIQOS || (TVTKGWTAOD == null)) {
            TVTKGWTAOD = LocalizerStatusProto.newBuilder(IUQMEBXEPD);
        }
        YBJANLIQOS = false;
    }

    @Override
    public String getLocalizerId() {
        LocalizerStatusProtoOrBuilder RJUYZDYFJU = (YBJANLIQOS) ? IUQMEBXEPD : TVTKGWTAOD;
        if (!RJUYZDYFJU.hasLocalizerId()) {
            return null;
        }
        return RJUYZDYFJU.getLocalizerId();
    }

    @Override
    public List<LocalResourceStatus> getResources() {
        initResources();
        return this.GIKBFSMLJT;
    }

    @Override
    public void setLocalizerId(String RFMABZOAIG) {
        maybeInitBuilder();
        if (RFMABZOAIG == null) {
            TVTKGWTAOD.clearLocalizerId();
            return;
        }
        TVTKGWTAOD.setLocalizerId(RFMABZOAIG);
    }

    private void initResources() {
        if (this.GIKBFSMLJT != null) {
            return;
        }
        LocalizerStatusProtoOrBuilder KUKQNGVDAE = (YBJANLIQOS) ? IUQMEBXEPD : TVTKGWTAOD;
        List<LocalResourceStatusProto> XBYHUWVHNO = KUKQNGVDAE.getResourcesList();
        this.GIKBFSMLJT = new ArrayList<LocalResourceStatus>();
        for (LocalResourceStatusProto OLXSQZQXEP : XBYHUWVHNO) {
            this.GIKBFSMLJT.add(convertFromProtoFormat(OLXSQZQXEP));
        }
    }

    private void addResourcesToProto() {
        maybeInitBuilder();
        TVTKGWTAOD.clearResources();
        if (this.GIKBFSMLJT == null)
            return;

        Iterable<LocalResourceStatusProto> STWJCIPNTQ = new Iterable<LocalResourceStatusProto>() {
            @Override
            public Iterator<LocalResourceStatusProto> iterator() {
                return new Iterator<LocalResourceStatusProto>() {
                    Iterator<LocalResourceStatus> EAMSIUXFXX = GIKBFSMLJT.iterator();

                    @Override
                    public boolean hasNext() {
                        return EAMSIUXFXX.hasNext();
                    }

                    @Override
                    public LocalResourceStatusProto next() {
                        return convertToProtoFormat(EAMSIUXFXX.next());
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        };
        TVTKGWTAOD.addAllResources(STWJCIPNTQ);
    }

    @Override
    public void addAllResources(List<LocalResourceStatus> UTQPYBQZTQ) {
        if (UTQPYBQZTQ == null)
            return;

        initResources();
        this.GIKBFSMLJT.addAll(UTQPYBQZTQ);
    }

    @Override
    public LocalResourceStatus getResourceStatus(int RKHLJLGEYH) {
        initResources();
        return this.GIKBFSMLJT.get(RKHLJLGEYH);
    }

    @Override
    public void addResourceStatus(LocalResourceStatus FYPZPYBBFY) {
        initResources();
        this.GIKBFSMLJT.add(FYPZPYBBFY);
    }

    @Override
    public void removeResource(int ELVRCEWQAA) {
        initResources();
        this.GIKBFSMLJT.remove(ELVRCEWQAA);
    }

    @Override
    public void clearResources() {
        initResources();
        this.GIKBFSMLJT.clear();
    }

    private LocalResourceStatus convertFromProtoFormat(LocalResourceStatusProto RZBMPOXUAS) {
        return new LocalResourceStatusPBImpl(RZBMPOXUAS);
    }

    private LocalResourceStatusProto convertToProtoFormat(LocalResourceStatus IXQJLRFLAP) {
        return ((LocalResourceStatusPBImpl) (IXQJLRFLAP)).getProto();
    }
}