/**
 * An operation provides these abstractions and if it desires to perform any
 * operations it must implement a override of the run() function to provide
 * varying output to be captured.
 */
abstract class Operation {
    private ConfigExtractor PGBHSBURVY;

    private PathFinder VVBFXDSZIN;

    private String STDXGMNJSH;

    private Random LWMDKKTTDI;

    protected Operation(String NFWHGMQVXJ, ConfigExtractor FPGYYPPOBZ, Random MJQUONKWGL) {
        this.PGBHSBURVY = FPGYYPPOBZ;
        this.STDXGMNJSH = NFWHGMQVXJ;
        this.LWMDKKTTDI = MJQUONKWGL;
        // Use a new Random instance so that the sequence of file names produced is
        // the same even in case of unsuccessful operations
        this.VVBFXDSZIN = new PathFinder(FPGYYPPOBZ, new Random(MJQUONKWGL.nextInt()));
    }

    /**
     * Gets the configuration object this class is using
     *
     * @return ConfigExtractor
     */
    protected ConfigExtractor getConfig() {
        return this.PGBHSBURVY;
    }

    /**
     * Gets the random number generator to use for this operation
     *
     * @return Random
     */
    protected Random getRandom() {
        return this.LWMDKKTTDI;
    }

    /**
     * Gets the type of operation that this class belongs to
     *
     * @return String
     */
    String getType() {
        return STDXGMNJSH;
    }

    /**
     * Gets the path finding/generating instance that this class is using
     *
     * @return PathFinder
     */
    protected PathFinder getFinder() {
        return this.VVBFXDSZIN;
    }

    /* (non-Javadoc)

    @see java.lang.Object#toString()
     */
    public String toString() {
        return getType();
    }

    /**
     * This run() method simply sets up the default output container and adds in a
     * data member to keep track of the number of operations that occurred
     *
     * @param fs
     * 		FileSystem object to perform operations with
     * @return List of operation outputs to be collected and output in the overall
    map reduce operation (or empty or null if none)
     */
    List<OperationOutput> run(FileSystem LJFJXBVXHU) {
        List<OperationOutput> EGCXBXGYVK = new LinkedList<OperationOutput>();
        EGCXBXGYVK.add(new OperationOutput(OutputType.LONG, getType(), ReportWriter.OP_COUNT, 1L));
        return EGCXBXGYVK;
    }
}