public class RMNodeStatusEvent extends RMNodeEvent {
    private final NodeHealthStatus SLXWJBEPRZ;

    private final List<ContainerStatus> KPBYZZWAPM;

    private final NodeHeartbeatResponse STBWREZYWG;

    private final List<ApplicationId> THBJBGTREM;

    public RMNodeStatusEvent(NodeId IDSSXYHQWA, NodeHealthStatus CKYONZKLQX, List<ContainerStatus> EJBZZCBNQA, List<ApplicationId> HTQJKZENVK, NodeHeartbeatResponse ZDSXOBYEVH) {
        super(IDSSXYHQWA, STATUS_UPDATE);
        this.SLXWJBEPRZ = CKYONZKLQX;
        this.KPBYZZWAPM = EJBZZCBNQA;
        this.THBJBGTREM = HTQJKZENVK;
        this.STBWREZYWG = ZDSXOBYEVH;
    }

    public NodeHealthStatus getNodeHealthStatus() {
        return this.SLXWJBEPRZ;
    }

    public List<ContainerStatus> getContainers() {
        return this.KPBYZZWAPM;
    }

    public NodeHeartbeatResponse getLatestResponse() {
        return this.STBWREZYWG;
    }

    public List<ApplicationId> getKeepAliveAppIds() {
        return this.THBJBGTREM;
    }
}