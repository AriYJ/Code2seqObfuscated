/**
 * **************************************************************
 * A <code>FilterFileSystem</code> contains
 * some other file system, which it uses as
 * its  basic file system, possibly transforming
 * the data along the way or providing  additional
 * functionality. The class <code>FilterFileSystem</code>
 * itself simply overrides all  methods of
 * <code>FileSystem</code> with versions that
 * pass all requests to the contained  file
 * system. Subclasses of <code>FilterFileSystem</code>
 * may further override some of  these methods
 * and may also provide additional methods
 * and fields.
 *
 * ***************************************************************
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class FilterFileSystem extends FileSystem {
    protected java.io.FileSystem UBWRIZFBAY;

    protected String IAUPEOQBRW;

    /* so that extending classes can define it */
    public FilterFileSystem() {
    }

    public FilterFileSystem(FileSystem HTCPTMUZKF) {
        this.UBWRIZFBAY = HTCPTMUZKF;
        this.statistics = HTCPTMUZKF.statistics;
    }

    /**
     * Get the raw file system
     *
     * @return FileSystem being filtered
     */
    public java.io.FileSystem getRawFileSystem() {
        return UBWRIZFBAY;
    }

    /**
     * Called after a new FileSystem instance is constructed.
     *
     * @param name
     * 		a uri whose authority section names the host, port, etc.
     * 		for this FileSystem
     * @param conf
     * 		the configuration
     */
    @Override
    public void initialize(URI LGWFXATHUE, Configuration VGNXTZBPZC) throws IOException {
        super.initialize(LGWFXATHUE, VGNXTZBPZC);
        // this is less than ideal, but existing filesystems sometimes neglect
        // to initialize the embedded filesystem
        if (UBWRIZFBAY.getConf() == null) {
            UBWRIZFBAY.initialize(LGWFXATHUE, VGNXTZBPZC);
        }
        String OHJEYSPUZI = LGWFXATHUE.getScheme();
        if (!OHJEYSPUZI.equals(UBWRIZFBAY.getUri().getScheme())) {
            IAUPEOQBRW = OHJEYSPUZI;
        }
    }

    /**
     * Returns a URI whose scheme and authority identify this FileSystem.
     */
    @Override
    public URI getUri() {
        return UBWRIZFBAY.getUri();
    }

    @Override
    protected URI getCanonicalUri() {
        return UBWRIZFBAY.getCanonicalUri();
    }

    @Override
    protected URI canonicalizeUri(URI LYLZSFSSLZ) {
        return UBWRIZFBAY.canonicalizeUri(LYLZSFSSLZ);
    }

    /**
     * Make sure that a path specifies a FileSystem.
     */
    @Override
    public Path makeQualified(Path HOLVNNLWKG) {
        Path GMVPYCKMZV = UBWRIZFBAY.makeQualified(HOLVNNLWKG);
        // swap in our scheme if the filtered fs is using a different scheme
        if (IAUPEOQBRW != null) {
            try {
                // NOTE: should deal with authority, but too much other stuff is broken
                GMVPYCKMZV = new Path(new URI(IAUPEOQBRW, GMVPYCKMZV.toUri().getSchemeSpecificPart(), null));
            } catch (URISyntaxException e) {
                throw new IllegalArgumentException(e);
            }
        }
        return GMVPYCKMZV;
    }

    // /////////////////////////////////////////////////////////////
    // FileSystem
    // /////////////////////////////////////////////////////////////
    /**
     * Check that a Path belongs to this FileSystem.
     */
    @Override
    protected void checkPath(Path OGDQCZXWYS) {
        UBWRIZFBAY.checkPath(OGDQCZXWYS);
    }

    @Override
    public BlockLocation[] getFileBlockLocations(FileStatus RIQNXFDSDK, long ZJPOWETPVH, long DCWFOYIJDQ) throws IOException {
        return UBWRIZFBAY.getFileBlockLocations(RIQNXFDSDK, ZJPOWETPVH, DCWFOYIJDQ);
    }

    @Override
    public Path resolvePath(final Path ASSXYBKPYQ) throws IOException {
        return UBWRIZFBAY.resolvePath(ASSXYBKPYQ);
    }

    /**
     * Opens an FSDataInputStream at the indicated Path.
     *
     * @param f
     * 		the file name to open
     * @param bufferSize
     * 		the size of the buffer to be used.
     */
    @Override
    public FSDataInputStream open(Path RXRSHWXKDN, int ZPEVTLRRJG) throws IOException {
        return UBWRIZFBAY.open(RXRSHWXKDN, ZPEVTLRRJG);
    }

    @Override
    public FSDataOutputStream append(Path PEIVLEAHLB, int ASNMFDLGWF, Progressable CEDJGZUSLM) throws IOException {
        return UBWRIZFBAY.append(PEIVLEAHLB, ASNMFDLGWF, CEDJGZUSLM);
    }

    @Override
    public void concat(Path PWUJNSHCAL, Path[] NIFGWSQFTG) throws IOException {
        UBWRIZFBAY.concat(PWUJNSHCAL, NIFGWSQFTG);
    }

    @Override
    public FSDataOutputStream create(Path AEAHVRASSZ, FsPermission FOANPTICWH, boolean JUEFDFDPUC, int OKEBUMJUYN, short BMSDXIXAIV, long QOAKBAVQNS, Progressable MPXKOBOHIF) throws IOException {
        return UBWRIZFBAY.create(AEAHVRASSZ, FOANPTICWH, JUEFDFDPUC, OKEBUMJUYN, BMSDXIXAIV, QOAKBAVQNS, MPXKOBOHIF);
    }

    @Override
    @Deprecated
    public FSDataOutputStream createNonRecursive(Path LJHWGPDCRR, FsPermission JRSEZMLITT, EnumSet<CreateFlag> XIHBCJOJUK, int WYMIZESTMY, short FMRLAPRPPR, long EJCCUAAFWS, Progressable LUYCHLASZP) throws IOException {
        return UBWRIZFBAY.createNonRecursive(LJHWGPDCRR, JRSEZMLITT, XIHBCJOJUK, WYMIZESTMY, FMRLAPRPPR, EJCCUAAFWS, LUYCHLASZP);
    }

    /**
     * Set replication for an existing file.
     *
     * @param src
     * 		file name
     * @param replication
     * 		new replication
     * @throws IOException
     * 		
     * @return true if successful;
    false if file does not exist or is a directory
     */
    @Override
    public boolean setReplication(Path SRWSFQBWGM, short BCPGPFRYEB) throws IOException {
        return UBWRIZFBAY.setReplication(SRWSFQBWGM, BCPGPFRYEB);
    }

    /**
     * Renames Path src to Path dst.  Can take place on local fs
     * or remote DFS.
     */
    @Override
    public boolean rename(Path EVIILXBXZQ, Path KKILPYPYIK) throws IOException {
        return UBWRIZFBAY.rename(EVIILXBXZQ, KKILPYPYIK);
    }

    /**
     * Delete a file
     */
    @Override
    public boolean delete(Path SCNPSCKYRO, boolean NAJXAVWXFO) throws IOException {
        return UBWRIZFBAY.delete(SCNPSCKYRO, NAJXAVWXFO);
    }

    /**
     * List files in a directory.
     */
    @Override
    public FileStatus[] listStatus(Path OCGYFFJVBZ) throws IOException {
        return UBWRIZFBAY.listStatus(OCGYFFJVBZ);
    }

    @Override
    public RemoteIterator<Path> listCorruptFileBlocks(Path HSEGARTACE) throws IOException {
        return UBWRIZFBAY.listCorruptFileBlocks(HSEGARTACE);
    }

    /**
     * List files and its block locations in a directory.
     */
    @Override
    public RemoteIterator<LocatedFileStatus> listLocatedStatus(Path JSBERHCXRT) throws IOException {
        return UBWRIZFBAY.listLocatedStatus(JSBERHCXRT);
    }

    @Override
    public Path getHomeDirectory() {
        return UBWRIZFBAY.getHomeDirectory();
    }

    /**
     * Set the current working directory for the given file system. All relative
     * paths will be resolved relative to it.
     *
     * @param newDir
     * 		
     */
    @Override
    public void setWorkingDirectory(Path GYWFGKUZLU) {
        UBWRIZFBAY.setWorkingDirectory(GYWFGKUZLU);
    }

    /**
     * Get the current working directory for the given file system
     *
     * @return the directory pathname
     */
    @Override
    public Path getWorkingDirectory() {
        return UBWRIZFBAY.getWorkingDirectory();
    }

    @Override
    protected Path getInitialWorkingDirectory() {
        return UBWRIZFBAY.getInitialWorkingDirectory();
    }

    @Override
    public FsStatus getStatus(Path BNNIJGHBAX) throws IOException {
        return UBWRIZFBAY.getStatus(BNNIJGHBAX);
    }

    @Override
    public boolean mkdirs(Path XZJIFVZRCP, FsPermission ZUAVLHNLYV) throws IOException {
        return UBWRIZFBAY.mkdirs(XZJIFVZRCP, ZUAVLHNLYV);
    }

    /**
     * The src file is on the local disk.  Add it to FS at
     * the given dst name.
     * delSrc indicates if the source should be removed
     */
    @Override
    public void copyFromLocalFile(boolean KYCNSZQZQP, Path ETNJOFSNRJ, Path HUVBSGJGYS) throws IOException {
        UBWRIZFBAY.copyFromLocalFile(KYCNSZQZQP, ETNJOFSNRJ, HUVBSGJGYS);
    }

    /**
     * The src files are on the local disk.  Add it to FS at
     * the given dst name.
     * delSrc indicates if the source should be removed
     */
    @Override
    public void copyFromLocalFile(boolean CJICJHVMRH, boolean FXXGCXNKYW, Path[] YKUMYGWCEH, Path TSCGYWINJJ) throws IOException {
        UBWRIZFBAY.copyFromLocalFile(CJICJHVMRH, FXXGCXNKYW, YKUMYGWCEH, TSCGYWINJJ);
    }

    /**
     * The src file is on the local disk.  Add it to FS at
     * the given dst name.
     * delSrc indicates if the source should be removed
     */
    @Override
    public void copyFromLocalFile(boolean DMVPNQLJAO, boolean ABZMDTKZYU, Path IKHWTRDNXH, Path YBPGVQWQRY) throws IOException {
        UBWRIZFBAY.copyFromLocalFile(DMVPNQLJAO, ABZMDTKZYU, IKHWTRDNXH, YBPGVQWQRY);
    }

    /**
     * The src file is under FS, and the dst is on the local disk.
     * Copy it from FS control to the local dst name.
     * delSrc indicates if the src will be removed or not.
     */
    @Override
    public void copyToLocalFile(boolean UPDLLFUNET, Path WWDAWQBZOK, Path LQPKXWWBWS) throws IOException {
        UBWRIZFBAY.copyToLocalFile(UPDLLFUNET, WWDAWQBZOK, LQPKXWWBWS);
    }

    /**
     * Returns a local File that the user can write output to.  The caller
     * provides both the eventual FS target name and the local working
     * file.  If the FS is local, we write directly into the target.  If
     * the FS is remote, we write into the tmp local area.
     */
    @Override
    public Path startLocalOutput(Path MJFVJADJJB, Path FDBQBBATDP) throws IOException {
        return UBWRIZFBAY.startLocalOutput(MJFVJADJJB, FDBQBBATDP);
    }

    /**
     * Called when we're all done writing to the target.  A local FS will
     * do nothing, because we've written to exactly the right place.  A remote
     * FS will copy the contents of tmpLocalFile to the correct target at
     * fsOutputFile.
     */
    @Override
    public void completeLocalOutput(Path BEECIMRPRF, Path PPFXJIMRNV) throws IOException {
        UBWRIZFBAY.completeLocalOutput(BEECIMRPRF, PPFXJIMRNV);
    }

    /**
     * Return the total size of all files in the filesystem.
     */
    @Override
    public long getUsed() throws IOException {
        return UBWRIZFBAY.getUsed();
    }

    @Override
    public long getDefaultBlockSize() {
        return UBWRIZFBAY.getDefaultBlockSize();
    }

    @Override
    public short getDefaultReplication() {
        return UBWRIZFBAY.getDefaultReplication();
    }

    @Override
    public FsServerDefaults getServerDefaults() throws IOException {
        return UBWRIZFBAY.getServerDefaults();
    }

    // path variants delegate to underlying filesystem
    @Override
    public long getDefaultBlockSize(Path ONWELCCGSV) {
        return UBWRIZFBAY.getDefaultBlockSize(ONWELCCGSV);
    }

    @Override
    public short getDefaultReplication(Path HHVWYUHOCP) {
        return UBWRIZFBAY.getDefaultReplication(HHVWYUHOCP);
    }

    @Override
    public FsServerDefaults getServerDefaults(Path VILXOADPNP) throws IOException {
        return UBWRIZFBAY.getServerDefaults(VILXOADPNP);
    }

    /**
     * Get file status.
     */
    @Override
    public FileStatus getFileStatus(Path RHLUOGBDUX) throws IOException {
        return UBWRIZFBAY.getFileStatus(RHLUOGBDUX);
    }

    @Override
    public void access(Path NAOKLIRXCM, FsAction ZXTAFKZRVB) throws FileNotFoundException, IOException, AccessControlException {
        UBWRIZFBAY.access(NAOKLIRXCM, ZXTAFKZRVB);
    }

    public void createSymlink(final Path STPNTMLOHE, final Path BAVYJVFJVJ, final boolean LWKMULZDUS) throws FileNotFoundException, IOException, FileAlreadyExistsException, ParentNotDirectoryException, UnsupportedFileSystemException, AccessControlException {
        UBWRIZFBAY.createSymlink(STPNTMLOHE, BAVYJVFJVJ, LWKMULZDUS);
    }

    public FileStatus getFileLinkStatus(final Path NMVSFDEJDN) throws FileNotFoundException, IOException, UnsupportedFileSystemException, AccessControlException {
        return UBWRIZFBAY.getFileLinkStatus(NMVSFDEJDN);
    }

    public boolean supportsSymlinks() {
        return UBWRIZFBAY.supportsSymlinks();
    }

    public Path getLinkTarget(Path GHBXMFBHZA) throws IOException {
        return UBWRIZFBAY.getLinkTarget(GHBXMFBHZA);
    }

    protected Path resolveLink(Path NAXMFANMVF) throws IOException {
        return UBWRIZFBAY.resolveLink(NAXMFANMVF);
    }

    @Override
    public FileChecksum getFileChecksum(Path TOCUVHYZWN) throws IOException {
        return UBWRIZFBAY.getFileChecksum(TOCUVHYZWN);
    }

    @Override
    public FileChecksum getFileChecksum(Path NWAWAKAJCD, long MOSEVPFEGX) throws IOException {
        return UBWRIZFBAY.getFileChecksum(NWAWAKAJCD, MOSEVPFEGX);
    }

    @Override
    public void setVerifyChecksum(boolean YCKDIGCWCD) {
        UBWRIZFBAY.setVerifyChecksum(YCKDIGCWCD);
    }

    @Override
    public void setWriteChecksum(boolean WERCIWAXMJ) {
        UBWRIZFBAY.setWriteChecksum(WERCIWAXMJ);
    }

    @Override
    public Configuration getConf() {
        return UBWRIZFBAY.getConf();
    }

    @Override
    public void close() throws IOException {
        super.close();
        UBWRIZFBAY.close();
    }

    @Override
    public void setOwner(Path SBTKNIKFXF, String FDPOLFMBLJ, String URQJUUEXSE) throws IOException {
        UBWRIZFBAY.setOwner(SBTKNIKFXF, FDPOLFMBLJ, URQJUUEXSE);
    }

    @Override
    public void setTimes(Path FYZITYMSIG, long WPZLSVYXKK, long ADVTPUEPUS) throws IOException {
        UBWRIZFBAY.setTimes(FYZITYMSIG, WPZLSVYXKK, ADVTPUEPUS);
    }

    @Override
    public void setPermission(Path ZNISSQUNVX, FsPermission KBDAWLIKMQ) throws IOException {
        UBWRIZFBAY.setPermission(ZNISSQUNVX, KBDAWLIKMQ);
    }

    @Override
    protected FSDataOutputStream primitiveCreate(Path LHLFQUIYTK, FsPermission QDCRSWRDMA, EnumSet<CreateFlag> JWJALTEDXS, int IGGYQISTOX, short IWIMYQLYBS, long CQEZDVTEKA, Progressable XWDBGPEZAA, ChecksumOpt DGIFNUGFHQ) throws IOException {
        return UBWRIZFBAY.primitiveCreate(LHLFQUIYTK, QDCRSWRDMA, JWJALTEDXS, IGGYQISTOX, IWIMYQLYBS, CQEZDVTEKA, XWDBGPEZAA, DGIFNUGFHQ);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected boolean primitiveMkdir(Path ECROANJKOY, FsPermission UVGVVHPLAM) throws IOException {
        return UBWRIZFBAY.primitiveMkdir(ECROANJKOY, UVGVVHPLAM);
    }

    // FileSystem
    @Override
    public java.io.FileSystem[] getChildFileSystems() {
        return new FileSystem[]{ UBWRIZFBAY };
    }

    // FileSystem
    @Override
    public Path createSnapshot(Path LQTUSWDLKA, String KAJUIGBAIE) throws IOException {
        return UBWRIZFBAY.createSnapshot(LQTUSWDLKA, KAJUIGBAIE);
    }

    // FileSystem
    @Override
    public void renameSnapshot(Path JQIHJCMBER, String EUZCMYCYSO, String AVUUMMJXNY) throws IOException {
        UBWRIZFBAY.renameSnapshot(JQIHJCMBER, EUZCMYCYSO, AVUUMMJXNY);
    }

    // FileSystem
    @Override
    public void deleteSnapshot(Path KPJUATRAKR, String FLPZPWPWAJ) throws IOException {
        UBWRIZFBAY.deleteSnapshot(KPJUATRAKR, FLPZPWPWAJ);
    }

    @Override
    public void modifyAclEntries(Path GCUYSFUUDC, List<AclEntry> FPYTBHHYMS) throws IOException {
        UBWRIZFBAY.modifyAclEntries(GCUYSFUUDC, FPYTBHHYMS);
    }

    @Override
    public void removeAclEntries(Path JTZPRQRRAW, List<AclEntry> HSYQOSNMMW) throws IOException {
        UBWRIZFBAY.removeAclEntries(JTZPRQRRAW, HSYQOSNMMW);
    }

    @Override
    public void removeDefaultAcl(Path FRFEBNIZZD) throws IOException {
        UBWRIZFBAY.removeDefaultAcl(FRFEBNIZZD);
    }

    @Override
    public void removeAcl(Path RZUTCROFCF) throws IOException {
        UBWRIZFBAY.removeAcl(RZUTCROFCF);
    }

    @Override
    public void setAcl(Path UWCFTXJAQJ, List<AclEntry> GOKNKFRSTK) throws IOException {
        UBWRIZFBAY.setAcl(UWCFTXJAQJ, GOKNKFRSTK);
    }

    @Override
    public AclStatus getAclStatus(Path TNKGIFAEAL) throws IOException {
        return UBWRIZFBAY.getAclStatus(TNKGIFAEAL);
    }

    @Override
    public void setXAttr(Path NSFFSEGEKB, String PVZSJDGMAG, byte[] AAEALGIANS) throws IOException {
        UBWRIZFBAY.setXAttr(NSFFSEGEKB, PVZSJDGMAG, AAEALGIANS);
    }

    @Override
    public void setXAttr(Path YDXUKPYSGC, String VZTYWHAPML, byte[] SIOMDUQPLD, EnumSet<XAttrSetFlag> FOSLCWWCQZ) throws IOException {
        UBWRIZFBAY.setXAttr(YDXUKPYSGC, VZTYWHAPML, SIOMDUQPLD, FOSLCWWCQZ);
    }

    @Override
    public byte[] getXAttr(Path CPTEMEJQXS, String MOMFNBOILN) throws IOException {
        return UBWRIZFBAY.getXAttr(CPTEMEJQXS, MOMFNBOILN);
    }

    @Override
    public Map<String, byte[]> getXAttrs(Path CMLHWDOQSN) throws IOException {
        return UBWRIZFBAY.getXAttrs(CMLHWDOQSN);
    }

    @Override
    public Map<String, byte[]> getXAttrs(Path SQNYNQOPCS, List<String> TYVPDRIBUB) throws IOException {
        return UBWRIZFBAY.getXAttrs(SQNYNQOPCS, TYVPDRIBUB);
    }

    @Override
    public List<String> listXAttrs(Path TRPAYFDYAP) throws IOException {
        return UBWRIZFBAY.listXAttrs(TRPAYFDYAP);
    }

    @Override
    public void removeXAttr(Path CWJXSQFBAF, String DBAZVLXCSH) throws IOException {
        UBWRIZFBAY.removeXAttr(CWJXSQFBAF, DBAZVLXCSH);
    }
}