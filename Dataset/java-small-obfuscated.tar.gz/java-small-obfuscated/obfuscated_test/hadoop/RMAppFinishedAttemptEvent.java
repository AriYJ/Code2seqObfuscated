public class RMAppFinishedAttemptEvent extends RMAppEvent {
    private final String AZWAIEDSTP;

    public RMAppFinishedAttemptEvent(ApplicationId JOICPNQIIN, String CDYDHOVCJL) {
        super(JOICPNQIIN, ATTEMPT_FINISHED);
        this.AZWAIEDSTP = CDYDHOVCJL;
    }

    public String getDiagnostics() {
        return this.AZWAIEDSTP;
    }
}