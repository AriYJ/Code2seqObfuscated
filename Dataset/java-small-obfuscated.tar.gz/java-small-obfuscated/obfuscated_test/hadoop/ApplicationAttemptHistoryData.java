/**
 * The class contains all the fields that are stored persistently for
 * <code>RMAppAttempt</code>.
 */
@Public
@Unstable
public class ApplicationAttemptHistoryData {
    private ApplicationAttemptId VPJDDJXAKH;

    private String PFOLBDXSHE;

    private int LRTKDBWENV;

    private String DMCSPWCEWX;

    private String SLSUFPYCEL;

    private FinalApplicationStatus MAHFTXVKGT;

    private ContainerId NGWUSRMRCS;

    private YarnApplicationAttemptState YNSIYVZIYI;

    @Public
    @Unstable
    public static ApplicationAttemptHistoryData newInstance(ApplicationAttemptId RLMOZWQQJI, String LJDAZUBVXC, int ZSUHDXFOWU, ContainerId GWWNIPXWQU, String ICLCSNXEJY, String PHBMZXRAMP, FinalApplicationStatus NBMLMDKRCP, YarnApplicationAttemptState IHBXDXCDXO) {
        ApplicationAttemptHistoryData VWGFBHAITH = new ApplicationAttemptHistoryData();
        VWGFBHAITH.setApplicationAttemptId(RLMOZWQQJI);
        VWGFBHAITH.setHost(LJDAZUBVXC);
        VWGFBHAITH.setRPCPort(ZSUHDXFOWU);
        VWGFBHAITH.setMasterContainerId(GWWNIPXWQU);
        VWGFBHAITH.setDiagnosticsInfo(ICLCSNXEJY);
        VWGFBHAITH.setTrackingURL(PHBMZXRAMP);
        VWGFBHAITH.setFinalApplicationStatus(NBMLMDKRCP);
        VWGFBHAITH.setYarnApplicationAttemptState(IHBXDXCDXO);
        return VWGFBHAITH;
    }

    @Public
    @Unstable
    public ApplicationAttemptId getApplicationAttemptId() {
        return VPJDDJXAKH;
    }

    @Public
    @Unstable
    public void setApplicationAttemptId(ApplicationAttemptId JGADNIWEHH) {
        this.VPJDDJXAKH = JGADNIWEHH;
    }

    @Public
    @Unstable
    public String getHost() {
        return PFOLBDXSHE;
    }

    @Public
    @Unstable
    public void setHost(String ICNOPNLKBS) {
        this.PFOLBDXSHE = ICNOPNLKBS;
    }

    @Public
    @Unstable
    public int getRPCPort() {
        return LRTKDBWENV;
    }

    @Public
    @Unstable
    public void setRPCPort(int FCODHDSFFF) {
        this.LRTKDBWENV = FCODHDSFFF;
    }

    @Public
    @Unstable
    public String getTrackingURL() {
        return DMCSPWCEWX;
    }

    @Public
    @Unstable
    public void setTrackingURL(String LHZGPDXCWE) {
        this.DMCSPWCEWX = LHZGPDXCWE;
    }

    @Public
    @Unstable
    public String getDiagnosticsInfo() {
        return SLSUFPYCEL;
    }

    @Public
    @Unstable
    public void setDiagnosticsInfo(String DTJOMZZGRF) {
        this.SLSUFPYCEL = DTJOMZZGRF;
    }

    @Public
    @Unstable
    public FinalApplicationStatus getFinalApplicationStatus() {
        return MAHFTXVKGT;
    }

    @Public
    @Unstable
    public void setFinalApplicationStatus(FinalApplicationStatus PKREZORULO) {
        this.MAHFTXVKGT = PKREZORULO;
    }

    @Public
    @Unstable
    public ContainerId getMasterContainerId() {
        return NGWUSRMRCS;
    }

    @Public
    @Unstable
    public void setMasterContainerId(ContainerId FLPYJGYHZU) {
        this.NGWUSRMRCS = FLPYJGYHZU;
    }

    @Public
    @Unstable
    public YarnApplicationAttemptState getYarnApplicationAttemptState() {
        return YNSIYVZIYI;
    }

    @Public
    @Unstable
    public void setYarnApplicationAttemptState(YarnApplicationAttemptState YUPYTSKOUM) {
        this.YNSIYVZIYI = YUPYTSKOUM;
    }
}