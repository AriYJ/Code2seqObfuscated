/**
 * BlockForTest publishes constructor for test
 */
public class BlockForTest extends HtmlBlock.Block {
    public BlockForTest(HtmlBlock JUOBKWGPST, PrintWriter BMFTKRTANM, int WWNGLVRZYG, boolean EIOZAQLSQQ) {
        JUOBKWGPST.super(BMFTKRTANM, WWNGLVRZYG, EIOZAQLSQQ);
    }
}