/**
 * Indicates a failure manipulating an ACL.
 */
@InterfaceAudience.Private
public class AclException extends IOException {
    private static final long GXAJTPRQOT = 1L;

    /**
     * Creates a new AclException.
     *
     * @param message
     * 		String message
     */
    public AclException(String TBYNXCFSSK) {
        super(TBYNXCFSSK);
    }
}