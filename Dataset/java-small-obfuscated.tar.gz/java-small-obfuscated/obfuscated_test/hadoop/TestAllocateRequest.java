public class TestAllocateRequest {
    @Test
    public void testAllcoateRequestWithIncrease() {
        List<ContainerResourceIncreaseRequest> UBSGNUSXIH = new ArrayList<ContainerResourceIncreaseRequest>();
        for (int XQZMRZOIQU = 0; XQZMRZOIQU < 3; XQZMRZOIQU++) {
            UBSGNUSXIH.add(ContainerResourceIncreaseRequest.newInstance(null, Resource.newInstance(0, XQZMRZOIQU)));
        }
        AllocateRequest LNSHHLMNMO = AllocateRequest.newInstance(123, 0.0F, null, null, null, UBSGNUSXIH);
        // serde
        AllocateRequestProto JPVOXADPAB = ((org.apache.hadoop.yarn.api.protocolrecords.impl.pb.AllocateRequestPBImpl) (LNSHHLMNMO)).getProto();
        LNSHHLMNMO = new org.apache.hadoop.yarn.api.protocolrecords.impl.pb.AllocateRequestPBImpl(JPVOXADPAB);
        // check value
        Assert.assertEquals(123, LNSHHLMNMO.getResponseId());
        Assert.assertEquals(UBSGNUSXIH.size(), LNSHHLMNMO.getIncreaseRequests().size());
        for (int EFNCFIZNZR = 0; EFNCFIZNZR < UBSGNUSXIH.size(); EFNCFIZNZR++) {
            Assert.assertEquals(LNSHHLMNMO.getIncreaseRequests().get(EFNCFIZNZR).getCapability().getVirtualCores(), UBSGNUSXIH.get(EFNCFIZNZR).getCapability().getVirtualCores());
        }
    }

    @Test
    public void testAllcoateRequestWithoutIncrease() {
        AllocateRequest JGRROOMROQ = AllocateRequest.newInstance(123, 0.0F, null, null, null, null);
        // serde
        AllocateRequestProto ILUXXJOTFE = ((org.apache.hadoop.yarn.api.protocolrecords.impl.pb.AllocateRequestPBImpl) (JGRROOMROQ)).getProto();
        JGRROOMROQ = new org.apache.hadoop.yarn.api.protocolrecords.impl.pb.AllocateRequestPBImpl(ILUXXJOTFE);
        // check value
        Assert.assertEquals(123, JGRROOMROQ.getResponseId());
        Assert.assertEquals(0, JGRROOMROQ.getIncreaseRequests().size());
    }
}