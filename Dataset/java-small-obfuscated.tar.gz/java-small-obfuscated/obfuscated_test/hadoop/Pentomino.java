public class Pentomino {
    public static final String SQXIWSYFOF = "mapreduce.pentomino.depth";

    public static final String OCDGJZAJZM = "mapreduce.pentomino.width";

    public static final String AJSBDURKTO = "mapreduce.pentomino.height";

    public static final String HRLSBHDZZB = "mapreduce.pentomino.class";

    /**
     * This interface just is a marker for what types I expect to get back
     * as column names.
     */
    // NOTHING
    protected static interface ColumnName {}

    /**
     * Maintain information about a puzzle piece.
     */
    protected static class Piece implements Pentomino.ColumnName {
        private String IEFXSEUBOP;

        private boolean[][] NQMTVCGZZQ;

        private int[] BLPPWJMVZZ;

        private boolean IBMKTJBFLQ;

        public Piece(String name, String shape, boolean flippable, int[] rotations) {
            this.IEFXSEUBOP = name;
            this.BLPPWJMVZZ = rotations;
            this.IBMKTJBFLQ = flippable;
            StringTokenizer parser = new StringTokenizer(shape, "/");
            List<boolean[]> lines = new ArrayList<boolean[]>();
            while (parser.hasMoreTokens()) {
                String token = parser.nextToken();
                boolean[] line = new boolean[token.length()];
                for (int i = 0; i < line.length; ++i) {
                    line[i] = token.charAt(i) == 'x';
                }
                lines.add(line);
            } 
            this.NQMTVCGZZQ = new boolean[lines.size()][];
            for (int i = 0; i < lines.size(); i++) {
                this.NQMTVCGZZQ[i] = lines.get(i);
            }
        }

        public String getName() {
            return IEFXSEUBOP;
        }

        public int[] getRotations() {
            return BLPPWJMVZZ.clone();
        }

        public boolean getFlippable() {
            return IBMKTJBFLQ;
        }

        private int doFlip(boolean flip, int x, int max) {
            if (flip) {
                return (max - x) - 1;
            } else {
                return x;
            }
        }

        public boolean[][] getShape(boolean flip, int rotate) {
            boolean[][] result;
            if ((rotate % 2) == 0) {
                int height = NQMTVCGZZQ.length;
                int width = NQMTVCGZZQ[0].length;
                result = new boolean[height][];
                boolean flipX = rotate == 2;
                boolean flipY = flip ^ (rotate == 2);
                for (int y = 0; y < height; ++y) {
                    result[y] = new boolean[width];
                    for (int x = 0; x < width; ++x) {
                        result[y][x] = NQMTVCGZZQ[doFlip(flipY, y, height)][doFlip(flipX, x, width)];
                    }
                }
            } else {
                int height = NQMTVCGZZQ[0].length;
                int width = NQMTVCGZZQ.length;
                result = new boolean[height][];
                boolean flipX = rotate == 3;
                boolean flipY = flip ^ (rotate == 1);
                for (int y = 0; y < height; ++y) {
                    result[y] = new boolean[width];
                    for (int x = 0; x < width; ++x) {
                        result[y][x] = NQMTVCGZZQ[doFlip(flipX, x, width)][doFlip(flipY, y, height)];
                    }
                }
            }
            return result;
        }
    }

    /**
     * A point in the puzzle board. This represents a placement of a piece into
     * a given point on the board.
     */
    static class Point implements Pentomino.ColumnName {
        int QOCEZKZUMR;

        int CGKHPKZSWL;

        Point(int x, int y) {
            this.QOCEZKZUMR = x;
            this.CGKHPKZSWL = y;
        }
    }

    /**
     * Convert a solution to the puzzle returned by the model into a string
     * that represents the placement of the pieces onto the board.
     *
     * @param width
     * 		the width of the puzzle board
     * @param height
     * 		the height of the puzzle board
     * @param solution
     * 		the list of column names that were selected in the model
     * @return a string representation of completed puzzle board
     */
    public static String stringifySolution(int CFLHUTIQKG, int SQYTIMZGDF, List<List<Pentomino.ColumnName>> YMSGKKXLOE) {
        String[][] SAHAEVHEDO = new String[SQYTIMZGDF][CFLHUTIQKG];
        StringBuffer BODJCDYLQR = new StringBuffer();
        // for each piece placement...
        for (List<Pentomino.ColumnName> CVAREGAPCU : YMSGKKXLOE) {
            // go through to find which piece was placed
            Pentomino.Piece FWRMIZKUOU = null;
            for (Pentomino.ColumnName EZILRQENWJ : CVAREGAPCU) {
                if (EZILRQENWJ instanceof Pentomino.Piece) {
                    FWRMIZKUOU = ((Pentomino.Piece) (EZILRQENWJ));
                    break;
                }
            }
            // for each point where the piece was placed, mark it with the piece name
            for (Pentomino.ColumnName BXAVRSPXIZ : CVAREGAPCU) {
                if (BXAVRSPXIZ instanceof Pentomino.Point) {
                    Pentomino.Point PRMZEVVPBD = ((Pentomino.Point) (BXAVRSPXIZ));
                    SAHAEVHEDO[PRMZEVVPBD.CGKHPKZSWL][PRMZEVVPBD.QOCEZKZUMR] = FWRMIZKUOU.getName();
                }
            }
        }
        // put the string together
        for (int HJCKAKPBQR = 0; HJCKAKPBQR < SAHAEVHEDO.length; ++HJCKAKPBQR) {
            for (int OFLPUCQCMC = 0; OFLPUCQCMC < SAHAEVHEDO[HJCKAKPBQR].length; ++OFLPUCQCMC) {
                BODJCDYLQR.append(SAHAEVHEDO[HJCKAKPBQR][OFLPUCQCMC]);
            }
            BODJCDYLQR.append("\n");
        }
        return BODJCDYLQR.toString();
    }

    public enum SolutionCategory {

        UPPER_LEFT,
        MID_X,
        MID_Y,
        CENTER;}

    /**
     * Find whether the solution has the x in the upper left quadrant, the
     * x-midline, the y-midline or in the center.
     *
     * @param names
     * 		the solution to check
     * @return the catagory of the solution
     */
    public Pentomino.SolutionCategory getCategory(List<List<Pentomino.ColumnName>> FENSGJXEPY) {
        Pentomino.Piece ABUVRGZKBA = null;
        // find the "x" piece
        for (Pentomino.Piece XQUXDMYPBB : RFMIRBMCUG) {
            if ("x".equals(XQUXDMYPBB.IEFXSEUBOP)) {
                ABUVRGZKBA = XQUXDMYPBB;
                break;
            }
        }
        // find the row containing the "x"
        for (List<Pentomino.ColumnName> UXXVHJCLGY : FENSGJXEPY) {
            if (UXXVHJCLGY.contains(ABUVRGZKBA)) {
                // figure out where the "x" is located
                int RHLGOXBJGR = BNELMTNKLA;
                int MDRQUHBRCJ = 0;
                int HQFVADCYZY = MYOFHYKJLE;
                int OFXPTQSDNN = 0;
                for (Pentomino.ColumnName CAWZOFVYTJ : UXXVHJCLGY) {
                    if (CAWZOFVYTJ instanceof Pentomino.Point) {
                        int PEKFERHVWS = ((Pentomino.Point) (CAWZOFVYTJ)).QOCEZKZUMR;
                        int CULCYONFNR = ((Pentomino.Point) (CAWZOFVYTJ)).CGKHPKZSWL;
                        if (PEKFERHVWS < RHLGOXBJGR) {
                            RHLGOXBJGR = PEKFERHVWS;
                        }
                        if (PEKFERHVWS > MDRQUHBRCJ) {
                            MDRQUHBRCJ = PEKFERHVWS;
                        }
                        if (CULCYONFNR < HQFVADCYZY) {
                            HQFVADCYZY = CULCYONFNR;
                        }
                        if (CULCYONFNR > OFXPTQSDNN) {
                            OFXPTQSDNN = CULCYONFNR;
                        }
                    }
                }
                boolean MFNVJYODCL = (RHLGOXBJGR + MDRQUHBRCJ) == (BNELMTNKLA - 1);
                boolean IRKNLEXDVD = (HQFVADCYZY + OFXPTQSDNN) == (MYOFHYKJLE - 1);
                if (MFNVJYODCL && IRKNLEXDVD) {
                    return Pentomino.SolutionCategory.CENTER;
                } else
                    if (MFNVJYODCL) {
                        return Pentomino.SolutionCategory.MID_X;
                    } else
                        if (IRKNLEXDVD) {
                            return Pentomino.SolutionCategory.MID_Y;
                        }


                break;
            }
        }
        return Pentomino.SolutionCategory.UPPER_LEFT;
    }

    /**
     * A solution printer that just writes the solution to stdout.
     */
    private static class SolutionPrinter implements DancingLinks.SolutionAcceptor<Pentomino.ColumnName> {
        int TIQXQUNVXI;

        int ZFSMIVLHPW;

        public SolutionPrinter(int width, int height) {
            this.TIQXQUNVXI = width;
            this.ZFSMIVLHPW = height;
        }

        public void solution(List<List<Pentomino.ColumnName>> names) {
            System.out.println(Pentomino.stringifySolution(TIQXQUNVXI, ZFSMIVLHPW, names));
        }
    }

    protected int BNELMTNKLA;

    protected int MYOFHYKJLE;

    protected List<Pentomino.Piece> RFMIRBMCUG = new ArrayList<Pentomino.Piece>();

    /**
     * Is the piece fixed under rotation?
     */
    protected static final int[] FNOIGWQWJO = new int[]{ 0 };

    /**
     * Is the piece identical if rotated 180 degrees?
     */
    protected static final int[] AQGMTQEQKV = new int[]{ 0, 1 };

    /**
     * Are all 4 rotations unique?
     */
    protected static final int[] TSUEZJMMOQ = new int[]{ 0, 1, 2, 3 };

    /**
     * Fill in the pieces list.
     */
    protected void initializePieces() {
        RFMIRBMCUG.add(new Pentomino.Piece("x", " x /xxx/ x ", false, Pentomino.FNOIGWQWJO));
        RFMIRBMCUG.add(new Pentomino.Piece("v", "x  /x  /xxx", false, Pentomino.TSUEZJMMOQ));
        RFMIRBMCUG.add(new Pentomino.Piece("t", "xxx/ x / x ", false, Pentomino.TSUEZJMMOQ));
        RFMIRBMCUG.add(new Pentomino.Piece("w", "  x/ xx/xx ", false, Pentomino.TSUEZJMMOQ));
        RFMIRBMCUG.add(new Pentomino.Piece("u", "x x/xxx", false, Pentomino.TSUEZJMMOQ));
        RFMIRBMCUG.add(new Pentomino.Piece("i", "xxxxx", false, Pentomino.AQGMTQEQKV));
        RFMIRBMCUG.add(new Pentomino.Piece("f", " xx/xx / x ", true, Pentomino.TSUEZJMMOQ));
        RFMIRBMCUG.add(new Pentomino.Piece("p", "xx/xx/x ", true, Pentomino.TSUEZJMMOQ));
        RFMIRBMCUG.add(new Pentomino.Piece("z", "xx / x / xx", true, Pentomino.AQGMTQEQKV));
        RFMIRBMCUG.add(new Pentomino.Piece("n", "xx  / xxx", true, Pentomino.TSUEZJMMOQ));
        RFMIRBMCUG.add(new Pentomino.Piece("y", "  x /xxxx", true, Pentomino.TSUEZJMMOQ));
        RFMIRBMCUG.add(new Pentomino.Piece("l", "   x/xxxx", true, Pentomino.TSUEZJMMOQ));
    }

    /**
     * Is the middle of piece on the upper/left side of the board with
     * a given offset and size of the piece? This only checks in one
     * dimension.
     *
     * @param offset
     * 		the offset of the piece
     * @param shapeSize
     * 		the size of the piece
     * @param board
     * 		the size of the board
     * @return is it in the upper/left?
     */
    private static boolean isSide(int WAAJFZYQQR, int ISEEMDMDCG, int GUQEOFSGJN) {
        return ((2 * WAAJFZYQQR) + ISEEMDMDCG) <= GUQEOFSGJN;
    }

    /**
     * For a given piece, generate all of the potential placements and add them
     * as rows to the model.
     *
     * @param dancer
     * 		the problem model
     * @param piece
     * 		the piece we are trying to place
     * @param width
     * 		the width of the board
     * @param height
     * 		the height of the board
     * @param flip
     * 		is the piece flipped over?
     * @param row
     * 		a workspace the length of the each row in the table
     * @param upperLeft
     * 		is the piece constrained to the upper left of the board?
     * 		this is used on a single piece to eliminate most of the trivial
     * 		roations of the solution.
     */
    private static void generateRows(DancingLinks APXBECNUCC, Pentomino.Piece UNYKUWIPMX, int LSFFTYLTWC, int BWSMZJBYZC, boolean TUPICGNFFL, boolean[] NVXFVJFWCJ, boolean URMJAWEQHG) {
        // for each rotation
        int[] TPEGWYLJMY = UNYKUWIPMX.getRotations();
        for (int TMXUAQTPHJ = 0; TMXUAQTPHJ < TPEGWYLJMY.length; ++TMXUAQTPHJ) {
            // get the shape
            boolean[][] EIZCIUXSXA = UNYKUWIPMX.getShape(TUPICGNFFL, TPEGWYLJMY[TMXUAQTPHJ]);
            // find all of the valid offsets
            for (int UFPRJYKLID = 0; UFPRJYKLID < LSFFTYLTWC; ++UFPRJYKLID) {
                for (int FINCJIVYYN = 0; FINCJIVYYN < BWSMZJBYZC; ++FINCJIVYYN) {
                    if ((((FINCJIVYYN + EIZCIUXSXA.length) <= BWSMZJBYZC) && ((UFPRJYKLID + EIZCIUXSXA[0].length) <= LSFFTYLTWC)) && ((!URMJAWEQHG) || (Pentomino.isSide(UFPRJYKLID, EIZCIUXSXA[0].length, LSFFTYLTWC) && Pentomino.isSide(FINCJIVYYN, EIZCIUXSXA.length, BWSMZJBYZC)))) {
                        // clear the columns related to the points on the board
                        for (int QLSENBIFLU = 0; QLSENBIFLU < (LSFFTYLTWC * BWSMZJBYZC); ++QLSENBIFLU) {
                            NVXFVJFWCJ[QLSENBIFLU] = false;
                        }
                        // mark the shape
                        for (int NVTUCRDJCI = 0; NVTUCRDJCI < EIZCIUXSXA.length; ++NVTUCRDJCI) {
                            for (int BKOHGHMHND = 0; BKOHGHMHND < EIZCIUXSXA[0].length; ++BKOHGHMHND) {
                                NVXFVJFWCJ[(((FINCJIVYYN + NVTUCRDJCI) * LSFFTYLTWC) + UFPRJYKLID) + BKOHGHMHND] = EIZCIUXSXA[NVTUCRDJCI][BKOHGHMHND];
                            }
                        }
                        APXBECNUCC.addRow(NVXFVJFWCJ);
                    }
                }
            }
        }
    }

    private DancingLinks<Pentomino.ColumnName> SJGPIVAJUC = new DancingLinks<Pentomino.ColumnName>();

    private DancingLinks.SolutionAcceptor<Pentomino.ColumnName> VWDYMTPHZP;

    {
        initializePieces();
    }

    /**
     * Create the model for a given pentomino set of pieces and board size.
     *
     * @param width
     * 		the width of the board in squares
     * @param height
     * 		the height of the board in squares
     */
    public Pentomino(int IKHTXXXUGO, int DBFLLIGWPP) {
        initialize(IKHTXXXUGO, DBFLLIGWPP);
    }

    /**
     * Create the object without initialization.
     */
    public Pentomino() {
    }

    void initialize(int YKOUOSPRCE, int BBTNTUNVRO) {
        this.BNELMTNKLA = YKOUOSPRCE;
        this.MYOFHYKJLE = BBTNTUNVRO;
        for (int SVZBTUGSVO = 0; SVZBTUGSVO < BBTNTUNVRO; ++SVZBTUGSVO) {
            for (int YRLNQPTZUK = 0; YRLNQPTZUK < YKOUOSPRCE; ++YRLNQPTZUK) {
                SJGPIVAJUC.addColumn(new Pentomino.Point(YRLNQPTZUK, SVZBTUGSVO));
            }
        }
        int KOROVXRNYW = SJGPIVAJUC.getNumberColumns();
        for (Pentomino.Piece NEELXVAJYN : RFMIRBMCUG) {
            SJGPIVAJUC.addColumn(NEELXVAJYN);
        }
        boolean[] CBKDXIZXNM = new boolean[SJGPIVAJUC.getNumberColumns()];
        for (int CRJRXFWRJS = 0; CRJRXFWRJS < RFMIRBMCUG.size(); ++CRJRXFWRJS) {
            Pentomino.Piece ZXWHTTMJTM = RFMIRBMCUG.get(CRJRXFWRJS);
            CBKDXIZXNM[CRJRXFWRJS + KOROVXRNYW] = true;
            Pentomino.generateRows(SJGPIVAJUC, ZXWHTTMJTM, YKOUOSPRCE, BBTNTUNVRO, false, CBKDXIZXNM, CRJRXFWRJS == 0);
            if (ZXWHTTMJTM.getFlippable()) {
                Pentomino.generateRows(SJGPIVAJUC, ZXWHTTMJTM, YKOUOSPRCE, BBTNTUNVRO, true, CBKDXIZXNM, CRJRXFWRJS == 0);
            }
            CBKDXIZXNM[CRJRXFWRJS + KOROVXRNYW] = false;
        }
        printer = new Pentomino.SolutionPrinter(YKOUOSPRCE, BBTNTUNVRO);
    }

    /**
     * Generate a list of prefixes to a given depth
     *
     * @param depth
     * 		the length of each prefix
     * @return a list of arrays of ints, which are potential prefixes
     */
    public List<int[]> getSplits(int KFEVVNPOKB) {
        return SJGPIVAJUC.split(KFEVVNPOKB);
    }

    /**
     * Find all of the solutions that start with the given prefix. The printer
     * is given each solution as it is found.
     *
     * @param split
     * 		a list of row indexes that should be choosen for each row
     * 		in order
     * @return the number of solutions found
     */
    public int solve(int[] IFKWSAVZCG) {
        return SJGPIVAJUC.solve(IFKWSAVZCG, printer);
    }

    /**
     * Find all of the solutions to the puzzle.
     *
     * @return the number of solutions found
     */
    public int solve() {
        return SJGPIVAJUC.solve(printer);
    }

    /**
     * Set the printer for the puzzle.
     *
     * @param printer
     * 		A call-back object that is given each solution as it is
     * 		found.
     */
    public void setPrinter(DancingLinks.SolutionAcceptor<Pentomino.ColumnName> SMVIQIQGTS) {
        this.printer = SMVIQIQGTS;
    }

    /**
     * Solve the 6x10 pentomino puzzle.
     */
    public static void main(String[] EXZOYDJPFZ) {
        int FFMCXVHXVY = 6;
        int YVFGSRIRXL = 10;
        Pentomino WNREYVFZIT = new Pentomino(FFMCXVHXVY, YVFGSRIRXL);
        List FHRCWPRKPX = WNREYVFZIT.getSplits(2);
        for (Iterator IISUSCEIFM = FHRCWPRKPX.iterator(); IISUSCEIFM.hasNext();) {
            int[] TRQKJSAJMQ = ((int[]) (IISUSCEIFM.next()));
            System.out.print("split:");
            for (int WMHYNMHKNX = 0; WMHYNMHKNX < TRQKJSAJMQ.length; ++WMHYNMHKNX) {
                System.out.print(" " + TRQKJSAJMQ[WMHYNMHKNX]);
            }
            System.out.println();
            System.out.println(WNREYVFZIT.solve(TRQKJSAJMQ) + " solutions found.");
        }
    }
}