public class TestHAUtil {
    private Configuration ISKZOOSFRL;

    private static final String BZTARFBKOV = "  \t\t\n 1.2.3.4:8021  \n\t ";

    private static final String EICYGCWHPB = TestHAUtil.BZTARFBKOV.trim();

    private static final String CFCBAITDGE = "localhost:8022";

    private static final String EEETQUJKPH = "localhost:8033";

    private static final String JOSBFIEGEE = "rm1 ";

    private static final String ZVUKNFOGJU = TestHAUtil.JOSBFIEGEE.trim();

    private static final String WWKZGKARXA = "rm2";

    private static final String JPZXUXRUGO = "rm3";

    private static final String WKBDTTLOGA = ".rm";

    private static final String LQISKDIXFK = (TestHAUtil.JOSBFIEGEE + ",") + TestHAUtil.WWKZGKARXA;

    private static final String LBTFWXSIXM = (TestHAUtil.ZVUKNFOGJU + ",") + TestHAUtil.WWKZGKARXA;

    @Before
    public void setUp() {
        ISKZOOSFRL = new Configuration();
        ISKZOOSFRL.set(RM_HA_IDS, TestHAUtil.LQISKDIXFK);
        ISKZOOSFRL.set(RM_HA_ID, TestHAUtil.JOSBFIEGEE);
        for (String JZHUQSQKME : YarnConfiguration.getServiceAddressConfKeys(ISKZOOSFRL)) {
            // configuration key itself cannot contains space/tab/return chars.
            ISKZOOSFRL.set(HAUtil.addSuffix(JZHUQSQKME, TestHAUtil.ZVUKNFOGJU), TestHAUtil.BZTARFBKOV);
            ISKZOOSFRL.set(HAUtil.addSuffix(JZHUQSQKME, TestHAUtil.WWKZGKARXA), TestHAUtil.CFCBAITDGE);
        }
    }

    @Test
    public void testGetRMServiceId() throws Exception {
        ISKZOOSFRL.set(RM_HA_IDS, (TestHAUtil.ZVUKNFOGJU + ",") + TestHAUtil.WWKZGKARXA);
        Collection<String> SLUSRHRCCH = HAUtil.getRMHAIds(ISKZOOSFRL);
        assertEquals(2, SLUSRHRCCH.size());
        String[] ZTZBOOOLXI = SLUSRHRCCH.toArray(new String[0]);
        assertEquals(TestHAUtil.ZVUKNFOGJU, ZTZBOOOLXI[0]);
        assertEquals(TestHAUtil.WWKZGKARXA, ZTZBOOOLXI[1]);
    }

    @Test
    public void testGetRMId() throws Exception {
        ISKZOOSFRL.set(RM_HA_ID, TestHAUtil.ZVUKNFOGJU);
        assertEquals("Does not honor " + YarnConfiguration.RM_HA_ID, TestHAUtil.ZVUKNFOGJU, HAUtil.getRMHAId(ISKZOOSFRL));
        ISKZOOSFRL.clear();
        assertNull(("Return null when " + YarnConfiguration.RM_HA_ID) + " is not set", HAUtil.getRMHAId(ISKZOOSFRL));
    }

    @Test
    public void testVerifyAndSetConfiguration() throws Exception {
        try {
            HAUtil.verifyAndSetConfiguration(ISKZOOSFRL);
        } catch (YarnRuntimeException e) {
            fail("Should not throw any exceptions.");
        }
        assertEquals("Should be saved as Trimmed collection", StringUtils.getStringCollection(TestHAUtil.LBTFWXSIXM), HAUtil.getRMHAIds(ISKZOOSFRL));
        assertEquals("Should be saved as Trimmed string", TestHAUtil.ZVUKNFOGJU, HAUtil.getRMHAId(ISKZOOSFRL));
        for (String ZOKWWBLKSA : YarnConfiguration.getServiceAddressConfKeys(ISKZOOSFRL)) {
            assertEquals("RPC address not set for " + ZOKWWBLKSA, TestHAUtil.EICYGCWHPB, ISKZOOSFRL.get(ZOKWWBLKSA));
        }
        ISKZOOSFRL.clear();
        ISKZOOSFRL.set(RM_HA_IDS, TestHAUtil.ZVUKNFOGJU);
        try {
            HAUtil.verifyAndSetConfiguration(ISKZOOSFRL);
        } catch (YarnRuntimeException e) {
            assertEquals("YarnRuntimeException by verifyAndSetRMHAIds()", HAUtil.BAD_CONFIG_MESSAGE_PREFIX + HAUtil.getInvalidValueMessage(RM_HA_IDS, ISKZOOSFRL.get(RM_HA_IDS) + "\nHA mode requires atleast two RMs"), e.getMessage());
        }
        ISKZOOSFRL.clear();
        // simulate the case YarnConfiguration.RM_HA_ID is not set
        ISKZOOSFRL.set(RM_HA_IDS, (TestHAUtil.ZVUKNFOGJU + ",") + TestHAUtil.WWKZGKARXA);
        for (String DUFYTZBRBZ : YarnConfiguration.getServiceAddressConfKeys(ISKZOOSFRL)) {
            ISKZOOSFRL.set(HAUtil.addSuffix(DUFYTZBRBZ, TestHAUtil.ZVUKNFOGJU), TestHAUtil.EICYGCWHPB);
            ISKZOOSFRL.set(HAUtil.addSuffix(DUFYTZBRBZ, TestHAUtil.WWKZGKARXA), TestHAUtil.CFCBAITDGE);
        }
        try {
            HAUtil.verifyAndSetConfiguration(ISKZOOSFRL);
        } catch (YarnRuntimeException e) {
            assertEquals("YarnRuntimeException by getRMId()", HAUtil.BAD_CONFIG_MESSAGE_PREFIX + HAUtil.getNeedToSetValueMessage(RM_HA_ID), e.getMessage());
        }
        ISKZOOSFRL.clear();
        ISKZOOSFRL.set(RM_HA_ID, TestHAUtil.WKBDTTLOGA);
        ISKZOOSFRL.set(RM_HA_IDS, (TestHAUtil.WKBDTTLOGA + ",") + TestHAUtil.ZVUKNFOGJU);
        for (String NBUMSMBILK : YarnConfiguration.getServiceAddressConfKeys(ISKZOOSFRL)) {
            // simulate xml with invalid node id
            ISKZOOSFRL.set(NBUMSMBILK + TestHAUtil.WKBDTTLOGA, TestHAUtil.WKBDTTLOGA);
        }
        try {
            HAUtil.verifyAndSetConfiguration(ISKZOOSFRL);
        } catch (YarnRuntimeException e) {
            assertEquals("YarnRuntimeException by addSuffix()", HAUtil.BAD_CONFIG_MESSAGE_PREFIX + HAUtil.getInvalidValueMessage(RM_HA_ID, TestHAUtil.WKBDTTLOGA), e.getMessage());
        }
        ISKZOOSFRL.clear();
        // simulate the case HAUtil.RM_RPC_ADDRESS_CONF_KEYS are not set
        ISKZOOSFRL.set(RM_HA_ID, TestHAUtil.ZVUKNFOGJU);
        ISKZOOSFRL.set(RM_HA_IDS, (TestHAUtil.ZVUKNFOGJU + ",") + TestHAUtil.WWKZGKARXA);
        try {
            HAUtil.verifyAndSetConfiguration(ISKZOOSFRL);
            fail("Should throw YarnRuntimeException. by Configuration#set()");
        } catch (YarnRuntimeException e) {
            String VOZLTCGEPN = HAUtil.addSuffix(RM_ADDRESS, TestHAUtil.ZVUKNFOGJU);
            assertEquals("YarnRuntimeException by Configuration#set()", HAUtil.BAD_CONFIG_MESSAGE_PREFIX + HAUtil.getNeedToSetValueMessage((HAUtil.addSuffix(RM_HOSTNAME, TestHAUtil.ZVUKNFOGJU) + " or ") + VOZLTCGEPN), e.getMessage());
        }
        // simulate the case YarnConfiguration.RM_HA_IDS doesn't contain
        // the value of YarnConfiguration.RM_HA_ID
        ISKZOOSFRL.clear();
        ISKZOOSFRL.set(RM_HA_IDS, (TestHAUtil.WWKZGKARXA + ",") + TestHAUtil.JPZXUXRUGO);
        ISKZOOSFRL.set(RM_HA_ID, TestHAUtil.JOSBFIEGEE);
        for (String QPTGKDKMTZ : YarnConfiguration.getServiceAddressConfKeys(ISKZOOSFRL)) {
            ISKZOOSFRL.set(HAUtil.addSuffix(QPTGKDKMTZ, TestHAUtil.ZVUKNFOGJU), TestHAUtil.BZTARFBKOV);
            ISKZOOSFRL.set(HAUtil.addSuffix(QPTGKDKMTZ, TestHAUtil.WWKZGKARXA), TestHAUtil.CFCBAITDGE);
            ISKZOOSFRL.set(HAUtil.addSuffix(QPTGKDKMTZ, TestHAUtil.JPZXUXRUGO), TestHAUtil.EEETQUJKPH);
        }
        try {
            HAUtil.verifyAndSetConfiguration(ISKZOOSFRL);
        } catch (YarnRuntimeException e) {
            assertEquals("YarnRuntimeException by getRMId()'s validation", HAUtil.BAD_CONFIG_MESSAGE_PREFIX + HAUtil.getRMHAIdNeedToBeIncludedMessage("[rm2, rm3]", TestHAUtil.ZVUKNFOGJU), e.getMessage());
        }
    }

    @Test
    public void testGetConfKeyForRMInstance() {
        assertTrue("RM instance id is not suffixed", HAUtil.getConfKeyForRMInstance(RM_ADDRESS, ISKZOOSFRL).contains(HAUtil.getRMHAId(ISKZOOSFRL)));
        assertFalse("RM instance id is suffixed", HAUtil.getConfKeyForRMInstance(YarnConfiguration.NM_ADDRESS, ISKZOOSFRL).contains(HAUtil.getRMHAId(ISKZOOSFRL)));
    }
}