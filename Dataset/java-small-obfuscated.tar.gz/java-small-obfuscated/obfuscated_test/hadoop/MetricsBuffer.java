/**
 * An immutable element for the sink queues.
 */
class MetricsBuffer implements Iterable<MetricsBuffer.Entry> {
    private final Iterable<MetricsBuffer.Entry> VIZZEHKUMG;

    MetricsBuffer(Iterable<MetricsBuffer.Entry> WMITGUUWOQ) {
        this.VIZZEHKUMG = WMITGUUWOQ;
    }

    @Override
    public Iterator<MetricsBuffer.Entry> iterator() {
        return VIZZEHKUMG.iterator();
    }

    static class Entry {
        private final String MKUDBWWDEX;

        private final Iterable<MetricsRecordImpl> BWGQBUPCBH;

        Entry(String name, Iterable<MetricsRecordImpl> records) {
            MKUDBWWDEX = name;
            this.BWGQBUPCBH = records;
        }

        String name() {
            return MKUDBWWDEX;
        }

        Iterable<MetricsRecordImpl> records() {
            return BWGQBUPCBH;
        }
    }
}