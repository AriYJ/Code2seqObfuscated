public class TestEpochsAreUnique {
    private static final Log LRYDQINZKT = LogFactory.getLog(TestEpochsAreUnique.class);

    private static final String SRVYDRIWHW = "testEpochsAreUnique-jid";

    private static final NamespaceInfo CPBJETIVGL = new NamespaceInfo(12345, "mycluster", "my-bp", 0L);

    private final Random NMIIWCQWVE = new Random();

    @Test
    public void testSingleThreaded() throws IOException {
        Configuration RELVQUHMSI = new Configuration();
        MiniJournalCluster UFRDXSHCVG = new MiniJournalCluster.Builder(RELVQUHMSI).build();
        URI SFZCLIBCZC = UFRDXSHCVG.getQuorumJournalURI(TestEpochsAreUnique.SRVYDRIWHW);
        QuorumJournalManager OLJJSGKAUU = new QuorumJournalManager(RELVQUHMSI, SFZCLIBCZC, TestEpochsAreUnique.CPBJETIVGL);
        try {
            OLJJSGKAUU.format(TestEpochsAreUnique.CPBJETIVGL);
        } finally {
            OLJJSGKAUU.close();
        }
        try {
            // With no failures or contention, epochs should increase one-by-one
            for (int OKMQHHIRIV = 0; OKMQHHIRIV < 5; OKMQHHIRIV++) {
                OLJJSGKAUU = new QuorumJournalManager(RELVQUHMSI, SFZCLIBCZC, TestEpochsAreUnique.CPBJETIVGL);
                try {
                    OLJJSGKAUU.createNewUniqueEpoch();
                    assertEquals(OKMQHHIRIV + 1, OLJJSGKAUU.getLoggerSetForTests().getEpoch());
                } finally {
                    OLJJSGKAUU.close();
                }
            }
            long QBSFISCABN = 5;
            // With some failures injected, it should still always increase, perhaps
            // skipping some
            for (int SSKCWYTTLA = 0; SSKCWYTTLA < 20; SSKCWYTTLA++) {
                long VSOKBVPPJM = -1;
                while (true) {
                    OLJJSGKAUU = new QuorumJournalManager(RELVQUHMSI, SFZCLIBCZC, TestEpochsAreUnique.CPBJETIVGL, new TestEpochsAreUnique.FaultyLoggerFactory());
                    try {
                        OLJJSGKAUU.createNewUniqueEpoch();
                        VSOKBVPPJM = OLJJSGKAUU.getLoggerSetForTests().getEpoch();
                        break;
                    } catch (IOException ioe) {
                        // It's OK to fail to create an epoch, since we randomly inject
                        // faults. It's possible we'll inject faults in too many of the
                        // underlying nodes, and a failure is expected in that case
                    } finally {
                        OLJJSGKAUU.close();
                    }
                } 
                TestEpochsAreUnique.LRYDQINZKT.info("Created epoch " + VSOKBVPPJM);
                assertTrue((("New epoch " + VSOKBVPPJM) + " should be greater than previous ") + QBSFISCABN, VSOKBVPPJM > QBSFISCABN);
                QBSFISCABN = VSOKBVPPJM;
            }
        } finally {
            UFRDXSHCVG.shutdown();
        }
    }

    private class FaultyLoggerFactory implements AsyncLogger.Factory {
        @Override
        public AsyncLogger createLogger(Configuration conf, NamespaceInfo nsInfo, String journalId, InetSocketAddress addr) {
            AsyncLogger ch = FACTORY.createLogger(conf, nsInfo, journalId, addr);
            AsyncLogger spy = Mockito.spy(ch);
            Mockito.doAnswer(new TestEpochsAreUnique.SometimesFaulty<Long>(0.1F)).when(spy).getJournalState();
            Mockito.doAnswer(new TestEpochsAreUnique.SometimesFaulty<Void>(0.4F)).when(spy).newEpoch(Mockito.anyLong());
            return spy;
        }
    }

    private class SometimesFaulty<T> implements Answer<ListenableFuture<T>> {
        private final float OTINAZZHBN;

        public SometimesFaulty(float faultProbability) {
            this.faultProbability = faultProbability;
        }

        @SuppressWarnings("unchecked")
        @Override
        public ListenableFuture<T> answer(InvocationOnMock invocation) throws Throwable {
            if (NMIIWCQWVE.nextFloat() < OTINAZZHBN) {
                return Futures.immediateFailedFuture(new IOException("Injected fault"));
            }
            return ((ListenableFuture<T>) (invocation.callRealMethod()));
        }
    }
}