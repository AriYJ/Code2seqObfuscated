public class TestAHSWebServices extends JerseyTest {
    private static ApplicationHistoryManager TZYTOYQESA;

    private Injector DMFJETHKZY = Guice.createInjector(new ServletModule() {
        @Override
        protected void configureServlets() {
            bind(JAXBContextResolver.class);
            bind(AHSWebServices.class);
            bind(GenericExceptionHandler.class);
            try {
                TestAHSWebServices.TZYTOYQESA = mockApplicationHistoryManager();
            } catch (Exception e) {
                Assert.fail();
            }
            bind(org.apache.hadoop.yarn.server.api.ApplicationContext.class).toInstance(TestAHSWebServices.TZYTOYQESA);
            serve("/*").with(GuiceContainer.class);
        }
    });

    public class GuiceServletConfig extends GuiceServletContextListener {
        @Override
        protected Injector getInjector() {
            return DMFJETHKZY;
        }
    }

    private ApplicationHistoryManager mockApplicationHistoryManager() throws Exception {
        ApplicationHistoryStore BBBPVZEAMM = new MemoryApplicationHistoryStore();
        TestAHSWebApp RAEZHRJMYX = new TestAHSWebApp();
        RAEZHRJMYX.setApplicationHistoryStore(BBBPVZEAMM);
        ApplicationHistoryManager QMWBYJLWXP = RAEZHRJMYX.mockApplicationHistoryManager(5, 5, 5);
        return QMWBYJLWXP;
    }

    public TestAHSWebServices() {
        super(new com.sun.jersey.test.framework.WebAppDescriptor.Builder("org.apache.hadoop.yarn.server.applicationhistoryservice.webapp").contextListenerClass(TestAHSWebServices.GuiceServletConfig.class).filterClass(com.google.inject.servlet.GuiceFilter.class).contextPath("jersey-guice-filter").servletPath("/").build());
    }

    @Before
    @Override
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testInvalidUri() throws Exception, JSONException {
        WebResource LRGDFVTJRV = resource();
        String YXMYAPOWNG = "";
        try {
            YXMYAPOWNG = LRGDFVTJRV.path("ws").path("v1").path("applicationhistory").path("bogus").accept(MediaType.APPLICATION_JSON).get(String.class);
            fail("should have thrown exception on invalid uri");
        } catch (UniformInterfaceException ue) {
            ClientResponse GFPLVIFZBE = ue.getResponse();
            assertEquals(Status.NOT_FOUND, GFPLVIFZBE.getClientResponseStatus());
            WebServicesTestUtils.checkStringMatch("error string exists and shouldn't", "", YXMYAPOWNG);
        }
    }

    @Test
    public void testInvalidUri2() throws Exception, JSONException {
        WebResource LRKUFJFMHJ = resource();
        String EBCDVWZWAB = "";
        try {
            EBCDVWZWAB = LRKUFJFMHJ.accept(MediaType.APPLICATION_JSON).get(String.class);
            fail("should have thrown exception on invalid uri");
        } catch (UniformInterfaceException ue) {
            ClientResponse SCMZRMEACQ = ue.getResponse();
            assertEquals(Status.NOT_FOUND, SCMZRMEACQ.getClientResponseStatus());
            WebServicesTestUtils.checkStringMatch("error string exists and shouldn't", "", EBCDVWZWAB);
        }
    }

    @Test
    public void testInvalidAccept() throws Exception, JSONException {
        WebResource TTWBHMIXPT = resource();
        String QBFJHKPMPS = "";
        try {
            QBFJHKPMPS = TTWBHMIXPT.path("ws").path("v1").path("applicationhistory").accept(MediaType.TEXT_PLAIN).get(String.class);
            fail("should have thrown exception on invalid uri");
        } catch (UniformInterfaceException ue) {
            ClientResponse EHSVFOVMPV = ue.getResponse();
            assertEquals(Status.INTERNAL_SERVER_ERROR, EHSVFOVMPV.getClientResponseStatus());
            WebServicesTestUtils.checkStringMatch("error string exists and shouldn't", "", QBFJHKPMPS);
        }
    }

    @Test
    public void testAppsQuery() throws Exception {
        WebResource CEDZEEAOVG = resource();
        ClientResponse CQJQNXMQXI = CEDZEEAOVG.path("ws").path("v1").path("applicationhistory").path("apps").queryParam("state", FINISHED.toString()).accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        assertEquals(MediaType.APPLICATION_JSON_TYPE, CQJQNXMQXI.getType());
        JSONObject CHKIYGLHNX = CQJQNXMQXI.getEntity(JSONObject.class);
        assertEquals("incorrect number of elements", 1, CHKIYGLHNX.length());
        JSONObject LYJZQULTRM = CHKIYGLHNX.getJSONObject("apps");
        assertEquals("incorrect number of elements", 1, LYJZQULTRM.length());
        JSONArray VRTXSCDGLI = LYJZQULTRM.getJSONArray("app");
        assertEquals("incorrect number of elements", 5, VRTXSCDGLI.length());
    }

    @Test
    public void testSingleApp() throws Exception {
        ApplicationId VBQRWWSSDU = ApplicationId.newInstance(0, 1);
        WebResource ORMXQSCIVD = resource();
        ClientResponse BSJESCTBJR = ORMXQSCIVD.path("ws").path("v1").path("applicationhistory").path("apps").path(VBQRWWSSDU.toString()).accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        assertEquals(MediaType.APPLICATION_JSON_TYPE, BSJESCTBJR.getType());
        JSONObject FIMJTYBIXZ = BSJESCTBJR.getEntity(JSONObject.class);
        assertEquals("incorrect number of elements", 1, FIMJTYBIXZ.length());
        JSONObject QKOIZKXGPW = FIMJTYBIXZ.getJSONObject("app");
        assertEquals(VBQRWWSSDU.toString(), QKOIZKXGPW.getString("appId"));
        assertEquals(VBQRWWSSDU.toString(), QKOIZKXGPW.get("name"));
        assertEquals(VBQRWWSSDU.toString(), QKOIZKXGPW.get("diagnosticsInfo"));
        assertEquals("test queue", QKOIZKXGPW.get("queue"));
        assertEquals("test user", QKOIZKXGPW.get("user"));
        assertEquals("test type", QKOIZKXGPW.get("type"));
        assertEquals(UNDEFINED.toString(), QKOIZKXGPW.get("finalAppStatus"));
        assertEquals(FINISHED.toString(), QKOIZKXGPW.get("appState"));
    }

    @Test
    public void testMultipleAttempts() throws Exception {
        ApplicationId CMMQLWULJM = ApplicationId.newInstance(0, 1);
        WebResource ULIMYJLZSJ = resource();
        ClientResponse UNSFEDSPWG = ULIMYJLZSJ.path("ws").path("v1").path("applicationhistory").path("apps").path(CMMQLWULJM.toString()).path("appattempts").accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        assertEquals(MediaType.APPLICATION_JSON_TYPE, UNSFEDSPWG.getType());
        JSONObject JTOGFHGJOG = UNSFEDSPWG.getEntity(JSONObject.class);
        assertEquals("incorrect number of elements", 1, JTOGFHGJOG.length());
        JSONObject MLIPUCXNDO = JTOGFHGJOG.getJSONObject("appAttempts");
        assertEquals("incorrect number of elements", 1, MLIPUCXNDO.length());
        JSONArray YLOGYFINBK = MLIPUCXNDO.getJSONArray("appAttempt");
        assertEquals("incorrect number of elements", 5, YLOGYFINBK.length());
    }

    @Test
    public void testSingleAttempt() throws Exception {
        ApplicationId IAIBIVWWOH = ApplicationId.newInstance(0, 1);
        ApplicationAttemptId WFODEAXPUX = ApplicationAttemptId.newInstance(IAIBIVWWOH, 1);
        WebResource KZXXNXPXXG = resource();
        ClientResponse TUQPVERZOX = KZXXNXPXXG.path("ws").path("v1").path("applicationhistory").path("apps").path(IAIBIVWWOH.toString()).path("appattempts").path(WFODEAXPUX.toString()).accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        assertEquals(MediaType.APPLICATION_JSON_TYPE, TUQPVERZOX.getType());
        JSONObject TLXNDOPHUK = TUQPVERZOX.getEntity(JSONObject.class);
        assertEquals("incorrect number of elements", 1, TLXNDOPHUK.length());
        JSONObject GOSQEXLTIR = TLXNDOPHUK.getJSONObject("appAttempt");
        assertEquals(WFODEAXPUX.toString(), GOSQEXLTIR.getString("appAttemptId"));
        assertEquals(WFODEAXPUX.toString(), GOSQEXLTIR.getString("host"));
        assertEquals(WFODEAXPUX.toString(), GOSQEXLTIR.getString("diagnosticsInfo"));
        assertEquals("test tracking url", GOSQEXLTIR.getString("trackingUrl"));
        assertEquals(YarnApplicationAttemptState.FINISHED.toString(), GOSQEXLTIR.get("appAttemptState"));
    }

    @Test
    public void testMultipleContainers() throws Exception {
        ApplicationId SOVRMWIWFL = ApplicationId.newInstance(0, 1);
        ApplicationAttemptId UOQCFXOXTL = ApplicationAttemptId.newInstance(SOVRMWIWFL, 1);
        WebResource AUCRWZQVRD = resource();
        ClientResponse RAUKVGNSUU = AUCRWZQVRD.path("ws").path("v1").path("applicationhistory").path("apps").path(SOVRMWIWFL.toString()).path("appattempts").path(UOQCFXOXTL.toString()).path("containers").accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        assertEquals(MediaType.APPLICATION_JSON_TYPE, RAUKVGNSUU.getType());
        JSONObject IPAGMDARKS = RAUKVGNSUU.getEntity(JSONObject.class);
        assertEquals("incorrect number of elements", 1, IPAGMDARKS.length());
        JSONObject GXGPSKZFDT = IPAGMDARKS.getJSONObject("containers");
        assertEquals("incorrect number of elements", 1, GXGPSKZFDT.length());
        JSONArray PVYDSOQNYO = GXGPSKZFDT.getJSONArray("container");
        assertEquals("incorrect number of elements", 5, PVYDSOQNYO.length());
    }

    @Test
    public void testSingleContainer() throws Exception {
        ApplicationId FLSHDETLIX = ApplicationId.newInstance(0, 1);
        ApplicationAttemptId JUFXUGAGXA = ApplicationAttemptId.newInstance(FLSHDETLIX, 1);
        ContainerId EPLJXCWXAA = ContainerId.newInstance(JUFXUGAGXA, 1);
        WebResource HYBSGDHFYI = resource();
        ClientResponse ZZEGDKDSRN = HYBSGDHFYI.path("ws").path("v1").path("applicationhistory").path("apps").path(FLSHDETLIX.toString()).path("appattempts").path(JUFXUGAGXA.toString()).path("containers").path(EPLJXCWXAA.toString()).accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
        assertEquals(MediaType.APPLICATION_JSON_TYPE, ZZEGDKDSRN.getType());
        JSONObject JILKBWNLFX = ZZEGDKDSRN.getEntity(JSONObject.class);
        assertEquals("incorrect number of elements", 1, JILKBWNLFX.length());
        JSONObject UWCXBHTHQC = JILKBWNLFX.getJSONObject("container");
        assertEquals(EPLJXCWXAA.toString(), UWCXBHTHQC.getString("containerId"));
        assertEquals(EPLJXCWXAA.toString(), UWCXBHTHQC.getString("diagnosticsInfo"));
        assertEquals("0", UWCXBHTHQC.getString("allocatedMB"));
        assertEquals("0", UWCXBHTHQC.getString("allocatedVCores"));
        assertEquals(NodeId.newInstance("localhost", 0).toString(), UWCXBHTHQC.getString("assignedNodeId"));
        assertEquals(Priority.newInstance(EPLJXCWXAA.getId()).toString(), UWCXBHTHQC.getString("priority"));
        Configuration TFGPQGPEEY = new YarnConfiguration();
        assertEquals(((WebAppUtils.getHttpSchemePrefix(TFGPQGPEEY) + WebAppUtils.getAHSWebAppURLWithoutScheme(TFGPQGPEEY)) + "/applicationhistory/logs/localhost:0/container_0_0001_01_000001/") + "container_0_0001_01_000001/test user", UWCXBHTHQC.getString("logUrl"));
        assertEquals(COMPLETE.toString(), UWCXBHTHQC.getString("containerState"));
    }
}