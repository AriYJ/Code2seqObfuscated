/**
 * Helpers to create an embedded webapp.
 *
 * <h4>Quick start:</h4>
 * <pre>
 *   WebApp wa = WebApps.$for(myApp).start();</pre>
 * Starts a webapp with default routes binds to 0.0.0.0 (all network interfaces)
 * on an ephemeral port, which can be obtained with:<pre>
 *   int port = wa.port();</pre>
 * <h4>With more options:</h4>
 * <pre>
 *   WebApp wa = WebApps.$for(myApp).at(address, port).
 *                        with(configuration).
 *                        start(new WebApp() {
 *     &#064;Override public void setup() {
 *       route("/foo/action", FooController.class);
 *       route("/foo/:id", FooController.class, "show");
 *     }
 *   });</pre>
 */
@InterfaceAudience.LimitedPrivate({ "YARN", "MapReduce" })
public class WebApps {
    static final Logger VYETUEXKJE = LoggerFactory.getLogger(WebApps.class);

    public static class Builder<T> {
        static class ServletStruct {
            public Class<? extends HttpServlet> IWWFRJWDCA;

            public String DPOGERGHMH;

            public String ATGDSNKULG;
        }

        final String RGEYJXJNKC;

        final String XAWNEOQKHQ;

        final Class<T> IRBHYUZETX;

        final T KIJVIDOPQJ;

        String EOIZODXZYX = "0.0.0.0";

        int FPWTJDZXFN = 0;

        boolean XSEMVHWAFN = false;

        Configuration AKVCWZPIUB;

        Policy CZCDGYNJVQ = null;

        boolean WPZFOLFYIF = false;

        private String BGGPLOYNUV;

        private String QRZMOGTXUP;

        private final HashSet<WebApps.Builder.ServletStruct> AQRMHHRRFG = new HashSet<WebApps.Builder.ServletStruct>();

        private final HashMap<String, Object> GGQNRKRLBT = new HashMap<String, Object>();

        Builder(String name, Class<T> api, T application, String wsName) {
            this.name = name;
            this.api = api;
            this.application = application;
            this.wsName = wsName;
        }

        Builder(String name, Class<T> api, T application) {
            this(name, api, application, null);
        }

        public WebApps.Builder<T> at(String bindAddress) {
            String[] parts = StringUtils.split(bindAddress, ':');
            if (parts.length == 2) {
                int port = Integer.parseInt(parts[1]);
                return at(parts[0], port, port == 0);
            }
            return at(bindAddress, 0, true);
        }

        public WebApps.Builder<T> at(int port) {
            return at("0.0.0.0", port, port == 0);
        }

        public WebApps.Builder<T> at(String address, int port, boolean findPort) {
            this.bindAddress = WebApps.Builder.checkNotNull(address, "bind address");
            this.port = port;
            this.findPort = findPort;
            return this;
        }

        public WebApps.Builder<T> withAttribute(String key, Object value) {
            GGQNRKRLBT.put(key, value);
            return this;
        }

        public WebApps.Builder<T> withServlet(String name, String pathSpec, Class<? extends HttpServlet> servlet) {
            WebApps.Builder.ServletStruct struct = new WebApps.Builder.ServletStruct();
            struct.IWWFRJWDCA = servlet;
            struct.DPOGERGHMH = name;
            struct.ATGDSNKULG = pathSpec;
            AQRMHHRRFG.add(struct);
            return this;
        }

        public WebApps.Builder<T> with(Configuration conf) {
            this.conf = conf;
            return this;
        }

        public WebApps.Builder<T> withHttpPolicy(Configuration conf, Policy httpPolicy) {
            this.conf = conf;
            this.httpPolicy = httpPolicy;
            return this;
        }

        public WebApps.Builder<T> withHttpSpnegoPrincipalKey(String spnegoPrincipalKey) {
            this.spnegoPrincipalKey = spnegoPrincipalKey;
            return this;
        }

        public WebApps.Builder<T> withHttpSpnegoKeytabKey(String spnegoKeytabKey) {
            this.spnegoKeytabKey = spnegoKeytabKey;
            return this;
        }

        public WebApps.Builder<T> inDevMode() {
            WPZFOLFYIF = true;
            return this;
        }

        public WebApp start(WebApp webapp) {
            if (webapp == null) {
                webapp = new WebApp() {
                    @Override
                    public void setup() {
                        // Defaults should be fine in usual cases
                    }
                };
            }
            webapp.setName(RGEYJXJNKC);
            webapp.setWebServices(XAWNEOQKHQ);
            String basePath = "/" + RGEYJXJNKC;
            webapp.setRedirectPath(basePath);
            List<String> pathList = new ArrayList<String>();
            if (basePath.equals("/")) {
                webapp.addServePathSpec("/*");
                pathList.add("/*");
            } else {
                webapp.addServePathSpec(basePath);
                webapp.addServePathSpec(basePath + "/*");
                pathList.add(basePath + "/*");
            }
            if ((XAWNEOQKHQ != null) && (!XAWNEOQKHQ.equals(basePath))) {
                if (XAWNEOQKHQ.equals("/")) {
                    webapp.addServePathSpec("/*");
                    pathList.add("/*");
                } else {
                    webapp.addServePathSpec("/" + XAWNEOQKHQ);
                    webapp.addServePathSpec(("/" + XAWNEOQKHQ) + "/*");
                    pathList.add(("/" + XAWNEOQKHQ) + "/*");
                }
            }
            if (AKVCWZPIUB == null) {
                AKVCWZPIUB = new Configuration();
            }
            try {
                if (KIJVIDOPQJ != null) {
                    webapp.setHostClass(KIJVIDOPQJ.getClass());
                } else {
                    String cls = inferHostClass();
                    WebApps.VYETUEXKJE.debug("setting webapp host class to {}", cls);
                    webapp.setHostClass(Class.forName(cls));
                }
                if (WPZFOLFYIF) {
                    if (FPWTJDZXFN > 0) {
                        try {
                            new URL(("http://localhost:" + FPWTJDZXFN) + "/__stop").getContent();
                            WebApps.VYETUEXKJE.info("stopping existing webapp instance");
                            Thread.sleep(100);
                        } catch (ConnectException e) {
                            WebApps.VYETUEXKJE.info("no existing webapp instance found: {}", e.toString());
                        } catch (Exception e) {
                            // should not be fatal
                            WebApps.VYETUEXKJE.warn("error stopping existing instance: {}", e.toString());
                        }
                    } else {
                        WebApps.VYETUEXKJE.error("dev mode does NOT work with ephemeral port!");
                        System.exit(1);
                    }
                }
                String httpScheme;
                if (this.httpPolicy == null) {
                    httpScheme = WebAppUtils.getHttpSchemePrefix(AKVCWZPIUB);
                } else {
                    httpScheme = (CZCDGYNJVQ == Policy.HTTPS_ONLY) ? WebAppUtils.HTTPS_PREFIX : WebAppUtils.HTTP_PREFIX;
                }
                HttpServer2.Builder builder = new HttpServer2.Builder().setName(RGEYJXJNKC).addEndpoint(java.net.URI.create(((httpScheme + EOIZODXZYX) + ":") + FPWTJDZXFN)).setConf(AKVCWZPIUB).setFindPort(XSEMVHWAFN).setACL(new org.apache.hadoop.yarn.security.AdminACLsManager(AKVCWZPIUB).getAdminAcl()).setPathSpec(pathList.toArray(new String[0]));
                boolean hasSpnegoConf = (((BGGPLOYNUV != null) && (AKVCWZPIUB.get(BGGPLOYNUV) != null)) && (QRZMOGTXUP != null)) && (AKVCWZPIUB.get(QRZMOGTXUP) != null);
                if (hasSpnegoConf) {
                    builder.setUsernameConfKey(BGGPLOYNUV).setKeytabConfKey(QRZMOGTXUP).setSecurityEnabled(UserGroupInformation.isSecurityEnabled());
                }
                if (httpScheme.equals(HTTPS_PREFIX)) {
                    WebAppUtils.loadSslConfiguration(builder);
                }
                HttpServer2 server = builder.build();
                for (WebApps.Builder.ServletStruct struct : AQRMHHRRFG) {
                    server.addServlet(struct.DPOGERGHMH, struct.ATGDSNKULG, struct.IWWFRJWDCA);
                }
                for (Map.Entry<String, Object> entry : GGQNRKRLBT.entrySet()) {
                    server.setAttribute(entry.getKey(), entry.getValue());
                }
                HttpServer2.defineFilter(server.getWebAppContext(), "guice", GuiceFilter.class.getName(), null, new String[]{ "/*" });
                webapp.setConf(AKVCWZPIUB);
                webapp.setHttpServer(server);
                server.start();
                WebApps.VYETUEXKJE.info((("Web app /" + RGEYJXJNKC) + " started at ") + server.getConnectorAddress(0).getPort());
            } catch (ClassNotFoundException e) {
                throw new WebAppException("Error starting http server", e);
            } catch (IOException e) {
                throw new WebAppException("Error starting http server", e);
            }
            Injector injector = Guice.createInjector(webapp, new AbstractModule() {
                @Override
                protected void configure() {
                    if (IRBHYUZETX != null) {
                        bind(IRBHYUZETX).toInstance(KIJVIDOPQJ);
                    }
                }
            });
            WebApps.VYETUEXKJE.info("Registered webapp guice modules");
            // save a guice filter instance for webapp stop (mostly for unit tests)
            webapp.setGuiceFilter(injector.getInstance(GuiceFilter.class));
            if (WPZFOLFYIF) {
                injector.getInstance(Dispatcher.class).setDevMode(WPZFOLFYIF);
                WebApps.VYETUEXKJE.info("in dev mode!");
            }
            return webapp;
        }

        public WebApp start() {
            return start(null);
        }

        private String inferHostClass() {
            String thisClass = this.getClass().getName();
            Throwable t = new Throwable();
            for (StackTraceElement e : t.getStackTrace()) {
                if (e.getClassName().equals(thisClass))
                    continue;

                return e.getClassName();
            }
            WebApps.VYETUEXKJE.warn("could not infer host class from", t);
            return thisClass;
        }
    }

    /**
     * Create a new webapp builder.
     *
     * @see WebApps for a complete example
     * @param <T>
     * 		application (holding the embedded webapp) type
     * @param prefix
     * 		of the webapp
     * @param api
     * 		the api class for the application
     * @param app
     * 		the application instance
     * @param wsPrefix
     * 		the prefix for the webservice api for this app
     * @return a webapp builder
     */
    public static <T> WebApps.Builder<T> $for(String AJGDBVXMIL, Class<T> OOUBNVMJJC, T XWEJTACHUH, String JMRGLGQDWN) {
        return new WebApps.Builder<T>(AJGDBVXMIL, OOUBNVMJJC, XWEJTACHUH, JMRGLGQDWN);
    }

    /**
     * Create a new webapp builder.
     *
     * @see WebApps for a complete example
     * @param <T>
     * 		application (holding the embedded webapp) type
     * @param prefix
     * 		of the webapp
     * @param api
     * 		the api class for the application
     * @param app
     * 		the application instance
     * @return a webapp builder
     */
    public static <T> WebApps.Builder<T> $for(String CAXHQYIPID, Class<T> EEHZCMRCOC, T IHSGFAJSHO) {
        return new WebApps.Builder<T>(CAXHQYIPID, EEHZCMRCOC, IHSGFAJSHO);
    }

    // Short cut mostly for tests/demos
    @SuppressWarnings("unchecked")
    public static <T> WebApps.Builder<T> $for(String RCDEKFJXZP, T WCBVZRPSYX) {
        return WebApps.$for(RCDEKFJXZP, ((Class<T>) (WCBVZRPSYX.getClass())), WCBVZRPSYX);
    }

    // Ditto
    public static <T> WebApps.Builder<T> $for(T FPMBTLNSDL) {
        return WebApps.$for("", FPMBTLNSDL);
    }

    public static <T> WebApps.Builder<T> $for(String XGFUHRKVJA) {
        return WebApps.$for(XGFUHRKVJA, null, null);
    }
}