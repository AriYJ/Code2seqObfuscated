class MetricGaugeFloat extends AbstractMetric {
    final float SKVITBSQAN;

    MetricGaugeFloat(MetricsInfo QTUNSIYJBZ, float AZCIWWOSHF) {
        super(QTUNSIYJBZ);
        this.SKVITBSQAN = AZCIWWOSHF;
    }

    @Override
    public Float value() {
        return SKVITBSQAN;
    }

    @Override
    public MetricType type() {
        return MetricType.GAUGE;
    }

    @Override
    public void visit(MetricsVisitor RNDZRRUWJX) {
        RNDZRRUWJX.gauge(this, SKVITBSQAN);
    }
}