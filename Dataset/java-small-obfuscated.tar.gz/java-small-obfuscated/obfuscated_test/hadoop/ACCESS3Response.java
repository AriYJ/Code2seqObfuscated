/**
 * ACCESS3 Response
 */
public class ACCESS3Response extends NFS3Response {
    /* A bit mask of access permissions indicating access rights for the
    authentication credentials provided with the request.
     */
    private final int VCRPYWOHWX;

    private final Nfs3FileAttributes GHTMEYGRVG;

    public ACCESS3Response(int SUAYEZIXLV) {
        this(SUAYEZIXLV, new Nfs3FileAttributes(), 0);
    }

    public ACCESS3Response(int WEEIRYVDFH, Nfs3FileAttributes DVSPZVODHG, int WHPESTFZRG) {
        super(WEEIRYVDFH);
        this.GHTMEYGRVG = DVSPZVODHG;
        this.VCRPYWOHWX = WHPESTFZRG;
    }

    @Override
    public XDR writeHeaderAndResponse(XDR PZJLLBVAKU, int UBNJKJABQZ, Verifier DIMZKCAGPV) {
        super.writeHeaderAndResponse(PZJLLBVAKU, UBNJKJABQZ, DIMZKCAGPV);
        if (this.getStatus() == Nfs3Status.NFS3_OK) {
            PZJLLBVAKU.writeBoolean(true);
            GHTMEYGRVG.serialize(PZJLLBVAKU);
            PZJLLBVAKU.writeInt(VCRPYWOHWX);
        } else {
            PZJLLBVAKU.writeBoolean(false);
        }
        return PZJLLBVAKU;
    }
}