public class TestHAFsck {
    static {
        ((org.apache.commons.logging.impl.Log4JLogger) (org.apache.commons.logging.LogFactory.getLog(org.apache.hadoop.hdfs.DFSUtil.class))).getLogger().setLevel(Level.ALL);
    }

    /**
     * Test that fsck still works with HA enabled.
     */
    @Test
    public void testHaFsck() throws Exception {
        Configuration IKXLTQHXYI = new Configuration();
        // need some HTTP ports
        MiniDFSNNTopology BEPROKHTLL = new MiniDFSNNTopology().addNameservice(new MiniDFSNNTopology.NSConf("ha-nn-uri-0").addNN(new MiniDFSNNTopology.NNConf("nn1").setHttpPort(10051)).addNN(new MiniDFSNNTopology.NNConf("nn2").setHttpPort(10052)));
        MiniDFSCluster JGSPQOJBQX = new MiniDFSCluster.Builder(IKXLTQHXYI).nnTopology(BEPROKHTLL).numDataNodes(0).build();
        FileSystem EQGKTQKSQI = null;
        try {
            JGSPQOJBQX.waitActive();
            JGSPQOJBQX.transitionToActive(0);
            // Make sure conf has the relevant HA configs.
            HATestUtil.setFailoverConfigurations(JGSPQOJBQX, IKXLTQHXYI, "ha-nn-uri-0", 0);
            EQGKTQKSQI = HATestUtil.configureFailoverFs(JGSPQOJBQX, IKXLTQHXYI);
            EQGKTQKSQI.mkdirs(new Path("/test1"));
            EQGKTQKSQI.mkdirs(new Path("/test2"));
            TestHAFsck.runFsck(IKXLTQHXYI);
            JGSPQOJBQX.transitionToStandby(0);
            JGSPQOJBQX.transitionToActive(1);
            TestHAFsck.runFsck(IKXLTQHXYI);
        } finally {
            if (EQGKTQKSQI != null) {
                EQGKTQKSQI.close();
            }
            if (JGSPQOJBQX != null) {
                JGSPQOJBQX.shutdown();
            }
        }
    }

    static void runFsck(Configuration QYVJRZWDPR) throws Exception {
        ByteArrayOutputStream LZOETRMRHP = new ByteArrayOutputStream();
        PrintStream SAKXQVWHMP = new PrintStream(LZOETRMRHP, true);
        int TXQHYCAUXC = ToolRunner.run(new org.apache.hadoop.hdfs.tools.DFSck(QYVJRZWDPR, SAKXQVWHMP), new String[]{ "/", "-files" });
        String UVHIDTECKO = LZOETRMRHP.toString();
        System.out.println("output from fsck:\n" + UVHIDTECKO);
        assertEquals(0, TXQHYCAUXC);
        assertTrue(UVHIDTECKO.contains("/test1"));
        assertTrue(UVHIDTECKO.contains("/test2"));
    }
}