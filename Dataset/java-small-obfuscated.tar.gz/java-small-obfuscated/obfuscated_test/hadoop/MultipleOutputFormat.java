/**
 * This abstract class extends the FileOutputFormat, allowing to write the
 * output data to different output files. There are three basic use cases for
 * this class.
 *
 * Case one: This class is used for a map reduce job with at least one reducer.
 * The reducer wants to write data to different files depending on the actual
 * keys. It is assumed that a key (or value) encodes the actual key (value)
 * and the desired location for the actual key (value).
 *
 * Case two: This class is used for a map only job. The job wants to use an
 * output file name that is either a part of the input file name of the input
 * data, or some derivation of it.
 *
 * Case three: This class is used for a map only job. The job wants to use an
 * output file name that depends on both the keys and the input file name,
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public abstract class MultipleOutputFormat<K, V> extends FileOutputFormat<K, V> {
    /**
     * Create a composite record writer that can write key/value data to different
     * output files
     *
     * @param fs
     * 		the file system to use
     * @param job
     * 		the job conf for the job
     * @param name
     * 		the leaf file name for the output file (such as part-00000")
     * @param arg3
     * 		a progressable for reporting progress.
     * @return a composite record writer
     * @throws IOException
     * 		
     */
    public RecordWriter<K, V> getRecordWriter(FileSystem XTWUZSVYWN, JobConf TVZQXKHADV, String QRDYJUHLAA, Progressable GJXRVNCWOQ) throws IOException {
        final FileSystem RNOAINABDR = XTWUZSVYWN;
        final String BACZTYOHJF = generateLeafFileName(QRDYJUHLAA);
        final JobConf MFAEVMUKCM = TVZQXKHADV;
        final Progressable KUAPWDGMKH = GJXRVNCWOQ;
        return new RecordWriter<K, V>() {
            // a cache storing the record writers for different output files.
            TreeMap<String, RecordWriter<K, V>> ATKHGXHEET = new TreeMap<String, RecordWriter<K, V>>();

            public void write(K TSXZNAXNJN, V HSWWERGPFQ) throws IOException {
                // get the file name based on the key
                String LDCXBKPZZG = generateFileNameForKeyValue(TSXZNAXNJN, HSWWERGPFQ, BACZTYOHJF);
                // get the file name based on the input file name
                String RBESKXNTPT = getInputFileBasedOutputFileName(MFAEVMUKCM, LDCXBKPZZG);
                // get the actual key
                K LNTPUTSHBT = generateActualKey(TSXZNAXNJN, HSWWERGPFQ);
                V RFMTWTMMTQ = generateActualValue(TSXZNAXNJN, HSWWERGPFQ);
                RecordWriter<K, V> YYQHRMGCZY = this.ATKHGXHEET.get(RBESKXNTPT);
                if (YYQHRMGCZY == null) {
                    // if we don't have the record writer yet for the final path, create
                    // one
                    // and add it to the cache
                    YYQHRMGCZY = getBaseRecordWriter(RNOAINABDR, MFAEVMUKCM, RBESKXNTPT, KUAPWDGMKH);
                    this.ATKHGXHEET.put(RBESKXNTPT, YYQHRMGCZY);
                }
                YYQHRMGCZY.write(LNTPUTSHBT, RFMTWTMMTQ);
            }

            public void close(Reporter RTSAGLEPHF) throws IOException {
                Iterator<String> YZFGEQRNAR = this.ATKHGXHEET.keySet().iterator();
                while (YZFGEQRNAR.hasNext()) {
                    RecordWriter<K, V> BTFEBRYLMC = this.ATKHGXHEET.get(YZFGEQRNAR.next());
                    BTFEBRYLMC.close(RTSAGLEPHF);
                } 
                this.ATKHGXHEET.clear();
            }
        };
    }

    /**
     * Generate the leaf name for the output file name. The default behavior does
     * not change the leaf file name (such as part-00000)
     *
     * @param name
     * 		the leaf file name for the output file
     * @return the given leaf file name
     */
    protected String generateLeafFileName(String FQDJCUTSGS) {
        return FQDJCUTSGS;
    }

    /**
     * Generate the file output file name based on the given key and the leaf file
     * name. The default behavior is that the file name does not depend on the
     * key.
     *
     * @param key
     * 		the key of the output data
     * @param name
     * 		the leaf file name
     * @return generated file name
     */
    protected String generateFileNameForKeyValue(K POCYVYXHUI, V HIVSICTERF, String UNCTRCRLLQ) {
        return UNCTRCRLLQ;
    }

    /**
     * Generate the actual key from the given key/value. The default behavior is that
     * the actual key is equal to the given key
     *
     * @param key
     * 		the key of the output data
     * @param value
     * 		the value of the output data
     * @return the actual key derived from the given key/value
     */
    protected K generateActualKey(K PMVIZAWGMJ, V UQZGLZNZOX) {
        return PMVIZAWGMJ;
    }

    /**
     * Generate the actual value from the given key and value. The default behavior is that
     * the actual value is equal to the given value
     *
     * @param key
     * 		the key of the output data
     * @param value
     * 		the value of the output data
     * @return the actual value derived from the given key/value
     */
    protected V generateActualValue(K HXQPJHDVIZ, V XGQLALSQKW) {
        return XGQLALSQKW;
    }

    /**
     * Generate the outfile name based on a given anme and the input file name. If
     * the {@link JobContext#MAP_INPUT_FILE} does not exists (i.e. this is not for a map only job),
     * the given name is returned unchanged. If the config value for
     * "num.of.trailing.legs.to.use" is not set, or set 0 or negative, the given
     * name is returned unchanged. Otherwise, return a file name consisting of the
     * N trailing legs of the input file name where N is the config value for
     * "num.of.trailing.legs.to.use".
     *
     * @param job
     * 		the job config
     * @param name
     * 		the output file name
     * @return the outfile name based on a given anme and the input file name.
     */
    protected String getInputFileBasedOutputFileName(JobConf WYMYJARZFM, String CNOHFGSXDE) {
        String UDNCIGYPKQ = WYMYJARZFM.get(MAP_INPUT_FILE);
        if (UDNCIGYPKQ == null) {
            // if the {@link JobContext#MAP_INPUT_FILE} does not exists,
            // then return the given name
            return CNOHFGSXDE;
        }
        int BUNDBLURGF = WYMYJARZFM.getInt("mapred.outputformat.numOfTrailingLegs", 0);
        if (BUNDBLURGF <= 0) {
            return CNOHFGSXDE;
        }
        Path MQXAXZDLQC = new Path(UDNCIGYPKQ);
        Path XSZCEAZZZW = MQXAXZDLQC.getParent();
        String TDTAGITAJW = MQXAXZDLQC.getName();
        Path IYYTGJBNAL = new Path(TDTAGITAJW);
        for (int BZMKZMZRDE = 1; BZMKZMZRDE < BUNDBLURGF; BZMKZMZRDE++) {
            if (XSZCEAZZZW == null)
                break;

            TDTAGITAJW = XSZCEAZZZW.getName();
            if (TDTAGITAJW.length() == 0)
                break;

            XSZCEAZZZW = XSZCEAZZZW.getParent();
            IYYTGJBNAL = new Path(TDTAGITAJW, IYYTGJBNAL);
        }
        return IYYTGJBNAL.toString();
    }

    /**
     *
     *
     * @param fs
     * 		the file system to use
     * @param job
     * 		a job conf object
     * @param name
     * 		the name of the file over which a record writer object will be
     * 		constructed
     * @param arg3
     * 		a progressable object
     * @return A RecordWriter object over the given file
     * @throws IOException
     * 		
     */
    protected abstract RecordWriter<K, V> getBaseRecordWriter(FileSystem XGPBYEXBCH, JobConf ODGHGFIIKM, String APTCMTBSHM, Progressable IKGFIEROFR) throws IOException;
}