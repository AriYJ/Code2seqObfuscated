public class TestZKRMStateStore extends RMStateStoreTestBase {
    public static final Log XSADAXEHMN = LogFactory.getLog(TestZKRMStateStore.class);

    private static final int YKUJIKEFXY = 1000;

    class TestZKRMStateStoreTester implements RMStateStoreHelper {
        ZooKeeper KVHMQMEAHO;

        TestZKRMStateStore.TestZKRMStateStoreTester.TestZKRMStateStoreInternal WJQWEWVMHN;

        String VCZJWVDZLA;

        class TestZKRMStateStoreInternal extends ZKRMStateStore {
            public TestZKRMStateStoreInternal(Configuration conf, String workingZnode) throws Exception {
                init(conf);
                start();
                assertTrue(znodeWorkingPath.equals(workingZnode));
            }

            @Override
            public ZooKeeper getNewZooKeeper() throws IOException {
                return KVHMQMEAHO;
            }

            public String getVersionNode() {
                return (((znodeWorkingPath + "/") + ROOT_ZNODE_NAME) + "/") + VERSION_NODE;
            }

            public Version getCurrentVersion() {
                return CURRENT_VERSION_INFO;
            }

            public String getAppNode(String appId) {
                return (((((VCZJWVDZLA + "/") + ROOT_ZNODE_NAME) + "/") + RM_APP_ROOT) + "/") + appId;
            }
        }

        public RMStateStore getRMStateStore() throws Exception {
            YarnConfiguration conf = new YarnConfiguration();
            VCZJWVDZLA = "/Test";
            conf.set(RM_ZK_ADDRESS, hostPort);
            conf.set(ZK_RM_STATE_STORE_PARENT_PATH, VCZJWVDZLA);
            this.KVHMQMEAHO = createClient();
            this.WJQWEWVMHN = new TestZKRMStateStore.TestZKRMStateStoreTester.TestZKRMStateStoreInternal(conf, VCZJWVDZLA);
            return this.WJQWEWVMHN;
        }

        @Override
        public boolean isFinalStateValid() throws Exception {
            List<String> nodes = KVHMQMEAHO.getChildren(WJQWEWVMHN.znodeWorkingPath, false);
            return nodes.size() == 1;
        }

        @Override
        public void writeVersion(Version version) throws Exception {
            KVHMQMEAHO.setData(WJQWEWVMHN.getVersionNode(), ((org.apache.hadoop.yarn.server.records.impl.pb.VersionPBImpl) (version)).getProto().toByteArray(), -1);
        }

        @Override
        public Version getCurrentVersion() throws Exception {
            return WJQWEWVMHN.getCurrentVersion();
        }

        public boolean appExists(RMApp app) throws Exception {
            Stat node = KVHMQMEAHO.exists(WJQWEWVMHN.getAppNode(app.getApplicationId().toString()), false);
            return node != null;
        }
    }

    @Test(timeout = 60000)
    public void testZKRMStateStoreRealZK() throws Exception {
        TestZKRMStateStore.TestZKRMStateStoreTester SPCGUZLXNW = new TestZKRMStateStore.TestZKRMStateStoreTester();
        testRMAppStateStore(SPCGUZLXNW);
        testRMDTSecretManagerStateStore(SPCGUZLXNW);
        testCheckVersion(SPCGUZLXNW);
        testEpoch(SPCGUZLXNW);
        testAppDeletion(SPCGUZLXNW);
        testDeleteStore(SPCGUZLXNW);
        testAMRMTokenSecretManagerStateStore(SPCGUZLXNW);
    }

    private Configuration createHARMConf(String USBDMOGZFH, String FRFMRISTJW, int LVDUHLQKYF) {
        Configuration KXLGJLWMCF = new YarnConfiguration();
        KXLGJLWMCF.setBoolean(RM_HA_ENABLED, true);
        KXLGJLWMCF.set(RM_HA_IDS, USBDMOGZFH);
        KXLGJLWMCF.setBoolean(RECOVERY_ENABLED, true);
        KXLGJLWMCF.set(RM_STORE, ZKRMStateStore.class.getName());
        KXLGJLWMCF.set(RM_ZK_ADDRESS, hostPort);
        KXLGJLWMCF.setInt(RM_ZK_TIMEOUT_MS, TestZKRMStateStore.YKUJIKEFXY);
        KXLGJLWMCF.set(RM_HA_ID, FRFMRISTJW);
        KXLGJLWMCF.set(RM_WEBAPP_ADDRESS, "localhost:0");
        for (String CZBGAILJOL : YarnConfiguration.getServiceAddressConfKeys(KXLGJLWMCF)) {
            for (String AZVASTSTAX : HAUtil.getRMHAIds(KXLGJLWMCF)) {
                KXLGJLWMCF.set(HAUtil.addSuffix(CZBGAILJOL, AZVASTSTAX), "localhost:0");
            }
        }
        KXLGJLWMCF.set(HAUtil.addSuffix(RM_ADMIN_ADDRESS, FRFMRISTJW), "localhost:" + LVDUHLQKYF);
        return KXLGJLWMCF;
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFencing() throws Exception {
        StateChangeRequestInfo GEDSBMAJUV = new StateChangeRequestInfo(RequestSource.REQUEST_BY_USER);
        Configuration SCAYXVTJCN = createHARMConf("rm1,rm2", "rm1", 1234);
        SCAYXVTJCN.setBoolean(AUTO_FAILOVER_ENABLED, false);
        ResourceManager VIWXJUPHEO = new ResourceManager();
        VIWXJUPHEO.init(SCAYXVTJCN);
        VIWXJUPHEO.start();
        VIWXJUPHEO.getRMContext().getRMAdminService().transitionToActive(GEDSBMAJUV);
        assertEquals("RM with ZKStore didn't start", Service.STATE.STARTED, VIWXJUPHEO.getServiceState());
        assertEquals("RM should be Active", HAServiceProtocol.HAServiceState.ACTIVE, VIWXJUPHEO.getRMContext().getRMAdminService().getServiceStatus().getState());
        Configuration VOZIOLYRVG = createHARMConf("rm1,rm2", "rm2", 5678);
        VOZIOLYRVG.setBoolean(AUTO_FAILOVER_ENABLED, false);
        ResourceManager YOFPLDULTS = new ResourceManager();
        YOFPLDULTS.init(VOZIOLYRVG);
        YOFPLDULTS.start();
        YOFPLDULTS.getRMContext().getRMAdminService().transitionToActive(GEDSBMAJUV);
        assertEquals("RM with ZKStore didn't start", Service.STATE.STARTED, YOFPLDULTS.getServiceState());
        assertEquals("RM should be Active", HAServiceProtocol.HAServiceState.ACTIVE, YOFPLDULTS.getRMContext().getRMAdminService().getServiceStatus().getState());
        for (int NGNYOBICCS = 0; NGNYOBICCS < (TestZKRMStateStore.YKUJIKEFXY / 50); NGNYOBICCS++) {
            if (HAServiceState.ACTIVE == VIWXJUPHEO.getRMContext().getRMAdminService().getServiceStatus().getState()) {
                Thread.sleep(100);
            }
        }
        assertEquals("RM should have been fenced", HAServiceProtocol.HAServiceState.STANDBY, VIWXJUPHEO.getRMContext().getRMAdminService().getServiceStatus().getState());
        assertEquals("RM should be Active", HAServiceProtocol.HAServiceState.ACTIVE, YOFPLDULTS.getRMContext().getRMAdminService().getServiceStatus().getState());
    }
}