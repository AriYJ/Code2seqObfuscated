public class TestGroupsCaching {
    public static final Log FZJBFXIEDB = LogFactory.getLog(TestGroupsCaching.class);

    private static String[] SPUHRGCHYJ = new String[]{ "grp1", "grp2" };

    private Configuration FOJGOYDVJZ;

    @Before
    public void setup() {
        FOJGOYDVJZ = new Configuration();
        FOJGOYDVJZ.setClass(HADOOP_SECURITY_GROUP_MAPPING, TestGroupsCaching.FakeGroupMapping.class, ShellBasedUnixGroupsMapping.class);
    }

    public static class FakeGroupMapping extends ShellBasedUnixGroupsMapping {
        // any to n mapping
        private static Set<String> BUCFFTDULN = new HashSet<String>();

        private static Set<String> HBORLDRCLD = new HashSet<String>();

        @Override
        public List<String> getGroups(String user) throws IOException {
            TestGroupsCaching.FZJBFXIEDB.info("Getting groups for " + user);
            if (TestGroupsCaching.FakeGroupMapping.HBORLDRCLD.contains(user)) {
                return new LinkedList<String>();
            }
            return new LinkedList<String>(TestGroupsCaching.FakeGroupMapping.BUCFFTDULN);
        }

        @Override
        public void cacheGroupsRefresh() throws IOException {
            TestGroupsCaching.FZJBFXIEDB.info("Cache is being refreshed.");
            TestGroupsCaching.FakeGroupMapping.clearBlackList();
            return;
        }

        public static void clearBlackList() throws IOException {
            TestGroupsCaching.FZJBFXIEDB.info("Clearing the blacklist");
            TestGroupsCaching.FakeGroupMapping.HBORLDRCLD.clear();
        }

        @Override
        public void cacheGroupsAdd(List<String> groups) throws IOException {
            TestGroupsCaching.FZJBFXIEDB.info(("Adding " + groups) + " to groups.");
            TestGroupsCaching.FakeGroupMapping.BUCFFTDULN.addAll(groups);
        }

        public static void addToBlackList(String user) throws IOException {
            TestGroupsCaching.FZJBFXIEDB.info(("Adding " + user) + " to the blacklist");
            TestGroupsCaching.FakeGroupMapping.HBORLDRCLD.add(user);
        }
    }

    @Test
    public void testGroupsCaching() throws Exception {
        // Disable negative cache.
        FOJGOYDVJZ.setLong(HADOOP_SECURITY_GROUPS_NEGATIVE_CACHE_SECS, 0);
        Groups FHTMAFVLAC = new Groups(FOJGOYDVJZ);
        FHTMAFVLAC.cacheGroupsAdd(Arrays.asList(TestGroupsCaching.SPUHRGCHYJ));
        FHTMAFVLAC.refresh();
        TestGroupsCaching.FakeGroupMapping.clearBlackList();
        TestGroupsCaching.FakeGroupMapping.addToBlackList("user1");
        // regular entry
        assertTrue(FHTMAFVLAC.getGroups("me").size() == 2);
        // this must be cached. blacklisting should have no effect.
        TestGroupsCaching.FakeGroupMapping.addToBlackList("me");
        assertTrue(FHTMAFVLAC.getGroups("me").size() == 2);
        // ask for a negative entry
        try {
            TestGroupsCaching.FZJBFXIEDB.error("We are not supposed to get here." + FHTMAFVLAC.getGroups("user1").toString());
            fail();
        } catch (IOException ioe) {
            if (!ioe.getMessage().startsWith("No groups found")) {
                TestGroupsCaching.FZJBFXIEDB.error("Got unexpected exception: " + ioe.getMessage());
                fail();
            }
        }
        // this shouldn't be cached. remove from the black list and retry.
        TestGroupsCaching.FakeGroupMapping.clearBlackList();
        assertTrue(FHTMAFVLAC.getGroups("user1").size() == 2);
    }

    public static class FakeunPrivilegedGroupMapping extends TestGroupsCaching.FakeGroupMapping {
        private static boolean SLFEIUGELP = false;

        @Override
        public List<String> getGroups(String user) throws IOException {
            TestGroupsCaching.FakeunPrivilegedGroupMapping.SLFEIUGELP = true;
            return super.getGroups(user);
        }
    }

    /* Group lookup should not happen for static users */
    @Test
    public void testGroupLookupForStaticUsers() throws Exception {
        FOJGOYDVJZ.setClass(HADOOP_SECURITY_GROUP_MAPPING, TestGroupsCaching.FakeunPrivilegedGroupMapping.class, ShellBasedUnixGroupsMapping.class);
        FOJGOYDVJZ.set(HADOOP_USER_GROUP_STATIC_OVERRIDES, "me=;user1=group1;user2=group1,group2");
        Groups OLTGZSCGZV = new Groups(FOJGOYDVJZ);
        List<String> YTEFBEBFON = OLTGZSCGZV.getGroups("me");
        assertTrue("non-empty groups for static user", YTEFBEBFON.isEmpty());
        assertFalse("group lookup done for static user", TestGroupsCaching.FakeunPrivilegedGroupMapping.SLFEIUGELP);
        List<String> NIKNEPMEPW = new ArrayList<String>();
        NIKNEPMEPW.add("group1");
        TestGroupsCaching.FakeunPrivilegedGroupMapping.SLFEIUGELP = false;
        YTEFBEBFON = OLTGZSCGZV.getGroups("user1");
        assertTrue("groups not correct", NIKNEPMEPW.equals(YTEFBEBFON));
        assertFalse("group lookup done for unprivileged user", TestGroupsCaching.FakeunPrivilegedGroupMapping.SLFEIUGELP);
        NIKNEPMEPW.add("group2");
        TestGroupsCaching.FakeunPrivilegedGroupMapping.SLFEIUGELP = false;
        YTEFBEBFON = OLTGZSCGZV.getGroups("user2");
        assertTrue("groups not correct", NIKNEPMEPW.equals(YTEFBEBFON));
        assertFalse("group lookup done for unprivileged user", TestGroupsCaching.FakeunPrivilegedGroupMapping.SLFEIUGELP);
    }

    @Test
    public void testNegativeGroupCaching() throws Exception {
        final String PNRYYTWJZO = "negcache";
        final String SGYJRERGGB = "Did not throw IOException: ";
        FOJGOYDVJZ.setLong(HADOOP_SECURITY_GROUPS_NEGATIVE_CACHE_SECS, 2);
        FakeTimer DZJDLQVQPT = new FakeTimer();
        Groups KTVNAPFBYB = new Groups(FOJGOYDVJZ, DZJDLQVQPT);
        KTVNAPFBYB.cacheGroupsAdd(Arrays.asList(TestGroupsCaching.SPUHRGCHYJ));
        KTVNAPFBYB.refresh();
        TestGroupsCaching.FakeGroupMapping.addToBlackList(PNRYYTWJZO);
        // In the first attempt, the user will be put in the negative cache.
        try {
            KTVNAPFBYB.getGroups(PNRYYTWJZO);
            fail(SGYJRERGGB + "Failed to obtain groups from FakeGroupMapping.");
        } catch (IOException e) {
            // Expects to raise exception for the first time. But the user will be
            // put into the negative cache
            GenericTestUtils.assertExceptionContains("No groups found for user", e);
        }
        // The second time, the user is in the negative cache.
        try {
            KTVNAPFBYB.getGroups(PNRYYTWJZO);
            fail(SGYJRERGGB + "The user is in the negative cache.");
        } catch (IOException e) {
            GenericTestUtils.assertExceptionContains("No groups found for user", e);
        }
        // Brings back the backend user-group mapping service.
        TestGroupsCaching.FakeGroupMapping.clearBlackList();
        // It should still get groups from the negative cache.
        try {
            KTVNAPFBYB.getGroups(PNRYYTWJZO);
            fail((SGYJRERGGB + "The user is still in the negative cache, even ") + "FakeGroupMapping has resumed.");
        } catch (IOException e) {
            GenericTestUtils.assertExceptionContains("No groups found for user", e);
        }
        // Let the elements in the negative cache expire.
        DZJDLQVQPT.advance(4 * 1000);
        // The groups for the user is expired in the negative cache, a new copy of
        // groups for the user is fetched.
        assertEquals(Arrays.asList(TestGroupsCaching.SPUHRGCHYJ), KTVNAPFBYB.getGroups(PNRYYTWJZO));
    }
}