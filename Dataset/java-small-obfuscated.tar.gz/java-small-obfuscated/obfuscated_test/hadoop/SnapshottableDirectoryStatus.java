/**
 * Metadata about a snapshottable directory
 */
public class SnapshottableDirectoryStatus {
    /**
     * Compare the statuses by full paths.
     */
    public static final Comparator<SnapshottableDirectoryStatus> KDAJMLTXEY = new Comparator<SnapshottableDirectoryStatus>() {
        @Override
        public int compare(SnapshottableDirectoryStatus left, SnapshottableDirectoryStatus right) {
            int d = DFSUtil.compareBytes(left.LYHBUTPOKZ, right.LYHBUTPOKZ);
            return d != 0 ? d : DFSUtil.compareBytes(left.NPOLXXSAHK.getLocalNameInBytes(), right.NPOLXXSAHK.getLocalNameInBytes());
        }
    };

    /**
     * Basic information of the snapshottable directory
     */
    private final HdfsFileStatus NPOLXXSAHK;

    /**
     * Number of snapshots that have been taken
     */
    private final int IYLSLSSKOS;

    /**
     * Number of snapshots allowed.
     */
    private final int NGUWCOXHFD;

    /**
     * Full path of the parent.
     */
    private final byte[] LYHBUTPOKZ;

    public SnapshottableDirectoryStatus(long LNDUYOCDEN, long BMDFMKLTXM, FsPermission MEYGFRHBQE, String HLHCGMEQSA, String VMYOKHHBSW, byte[] MHCVMBHION, long BNIPJEPYUB, int VOICPGTXZQ, int VAVIDCTHMZ, int QJXHZLMZBT, byte[] OFGCGGDTFD) {
        this.NPOLXXSAHK = new HdfsFileStatus(0, true, 0, 0, LNDUYOCDEN, BMDFMKLTXM, MEYGFRHBQE, HLHCGMEQSA, VMYOKHHBSW, null, MHCVMBHION, BNIPJEPYUB, VOICPGTXZQ, null);
        this.IYLSLSSKOS = VAVIDCTHMZ;
        this.NGUWCOXHFD = QJXHZLMZBT;
        this.LYHBUTPOKZ = OFGCGGDTFD;
    }

    /**
     *
     *
     * @return Number of snapshots that have been taken for the directory
     */
    public int getSnapshotNumber() {
        return IYLSLSSKOS;
    }

    /**
     *
     *
     * @return Number of snapshots allowed for the directory
     */
    public int getSnapshotQuota() {
        return NGUWCOXHFD;
    }

    /**
     *
     *
     * @return Full path of the parent
     */
    public byte[] getParentFullPath() {
        return LYHBUTPOKZ;
    }

    /**
     *
     *
     * @return The basic information of the directory
     */
    public HdfsFileStatus getDirStatus() {
        return NPOLXXSAHK;
    }

    /**
     *
     *
     * @return Full path of the file
     */
    public Path getFullPath() {
        String TIOYPWAGFS = ((LYHBUTPOKZ == null) || (LYHBUTPOKZ.length == 0)) ? null : DFSUtil.bytes2String(LYHBUTPOKZ);
        if ((TIOYPWAGFS == null) && (NPOLXXSAHK.getLocalNameInBytes().length == 0)) {
            // root
            return new Path("/");
        } else {
            return TIOYPWAGFS == null ? new Path(NPOLXXSAHK.getLocalName()) : new Path(TIOYPWAGFS, NPOLXXSAHK.getLocalName());
        }
    }

    /**
     * Print a list of {@link SnapshottableDirectoryStatus} out to a given stream.
     *
     * @param stats
     * 		The list of {@link SnapshottableDirectoryStatus}
     * @param out
     * 		The given stream for printing.
     */
    public static void print(SnapshottableDirectoryStatus[] RRXAQEREMP, PrintStream VZEDBDBGBI) {
        if ((RRXAQEREMP == null) || (RRXAQEREMP.length == 0)) {
            VZEDBDBGBI.println();
            return;
        }
        int RXMOKBNLJH = 0;
        int MOCXPPJNFI = 0;
        int IKZTYYZGKT = 0;
        int NSVCNYQICK = 0;
        int HLEWUCWOXG = 0;
        int IODYVLVBMU = 0;
        for (SnapshottableDirectoryStatus LVKHUOZKHS : RRXAQEREMP) {
            RXMOKBNLJH = SnapshottableDirectoryStatus.maxLength(RXMOKBNLJH, LVKHUOZKHS.NPOLXXSAHK.getReplication());
            MOCXPPJNFI = SnapshottableDirectoryStatus.maxLength(MOCXPPJNFI, LVKHUOZKHS.NPOLXXSAHK.getLen());
            IKZTYYZGKT = SnapshottableDirectoryStatus.maxLength(IKZTYYZGKT, LVKHUOZKHS.NPOLXXSAHK.getOwner());
            NSVCNYQICK = SnapshottableDirectoryStatus.maxLength(NSVCNYQICK, LVKHUOZKHS.NPOLXXSAHK.getGroup());
            HLEWUCWOXG = SnapshottableDirectoryStatus.maxLength(HLEWUCWOXG, LVKHUOZKHS.IYLSLSSKOS);
            IODYVLVBMU = SnapshottableDirectoryStatus.maxLength(IODYVLVBMU, LVKHUOZKHS.NGUWCOXHFD);
        }
        StringBuilder RMXWAGEEOW = new StringBuilder();
        RMXWAGEEOW.append("%s%s ");// permission string

        RMXWAGEEOW.append(("%" + RXMOKBNLJH) + "s ");
        RMXWAGEEOW.append(IKZTYYZGKT > 0 ? ("%-" + IKZTYYZGKT) + "s " : "%s");
        RMXWAGEEOW.append(NSVCNYQICK > 0 ? ("%-" + NSVCNYQICK) + "s " : "%s");
        RMXWAGEEOW.append(("%" + MOCXPPJNFI) + "s ");
        RMXWAGEEOW.append("%s ");// mod time

        RMXWAGEEOW.append(("%" + HLEWUCWOXG) + "s ");
        RMXWAGEEOW.append(("%" + IODYVLVBMU) + "s ");
        RMXWAGEEOW.append("%s");// path

        String LDRMQSHLYS = RMXWAGEEOW.toString();
        SimpleDateFormat HBFRDPCXQS = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        for (SnapshottableDirectoryStatus EXLKLJWNBP : RRXAQEREMP) {
            String OWNGFSOHMZ = String.format(LDRMQSHLYS, "d", EXLKLJWNBP.NPOLXXSAHK.getPermission(), EXLKLJWNBP.NPOLXXSAHK.getReplication(), EXLKLJWNBP.NPOLXXSAHK.getOwner(), EXLKLJWNBP.NPOLXXSAHK.getGroup(), String.valueOf(EXLKLJWNBP.NPOLXXSAHK.getLen()), HBFRDPCXQS.format(new Date(EXLKLJWNBP.NPOLXXSAHK.getModificationTime())), EXLKLJWNBP.IYLSLSSKOS, EXLKLJWNBP.NGUWCOXHFD, EXLKLJWNBP.getFullPath().toString());
            VZEDBDBGBI.println(OWNGFSOHMZ);
        }
    }

    private static int maxLength(int QNZPSDKNYY, Object NDMMEIJIHI) {
        return Math.max(QNZPSDKNYY, String.valueOf(NDMMEIJIHI).length());
    }

    public static class Bean {
        private final String EMFPBZCERL;

        private final int VZRXJGBPYU;

        private final int OERTWWEEOT;

        private final long VOOSJSQKTW;

        private final short ONOZQRHBYX;

        private final String SOTFNIDOOQ;

        private final String NZYUQFPQAZ;

        public Bean(String path, int snapshotNumber, int snapshotQuota, long modificationTime, short permission, String owner, String group) {
            this.EMFPBZCERL = path;
            this.VZRXJGBPYU = snapshotNumber;
            this.OERTWWEEOT = snapshotQuota;
            this.VOOSJSQKTW = modificationTime;
            this.ONOZQRHBYX = permission;
            this.SOTFNIDOOQ = owner;
            this.NZYUQFPQAZ = group;
        }

        public String getPath() {
            return EMFPBZCERL;
        }

        public int getSnapshotNumber() {
            return VZRXJGBPYU;
        }

        public int getSnapshotQuota() {
            return OERTWWEEOT;
        }

        public long getModificationTime() {
            return VOOSJSQKTW;
        }

        public short getPermission() {
            return ONOZQRHBYX;
        }

        public String getOwner() {
            return SOTFNIDOOQ;
        }

        public String getGroup() {
            return NZYUQFPQAZ;
        }
    }
}