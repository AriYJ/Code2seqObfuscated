public class MapReduceTrackingUriPlugin extends TrackingUriPlugin implements Configurable {
    @Override
    public void setConf(Configuration WEWAVAYYWJ) {
        Configuration LAXJSWJRDK = null;
        // Force loading of mapred configuration.
        if (WEWAVAYYWJ != null) {
            LAXJSWJRDK = new JobConf(WEWAVAYYWJ);
        } else {
            LAXJSWJRDK = new JobConf();
        }
        super.setConf(LAXJSWJRDK);
    }

    /**
     * Gets the URI to access the given application on MapReduce history server
     *
     * @param id
     * 		the ID for which a URI is returned
     * @return the tracking URI
     * @throws URISyntaxException
     * 		
     */
    @Override
    public URI getTrackingUri(ApplicationId TIFXCBDRHF) throws URISyntaxException {
        String OIMZFJSQTH = TIFXCBDRHF.toString().replaceFirst("^application_", "job_");
        String OLGBILNQHS = MRWebAppUtil.getJHSWebappURLWithScheme(getConf());
        return new URI((OLGBILNQHS + "/jobhistory/job/") + OIMZFJSQTH);
    }
}