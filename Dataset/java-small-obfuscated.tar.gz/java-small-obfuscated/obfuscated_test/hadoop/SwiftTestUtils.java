/**
 * Utilities used across test cases
 */
public class SwiftTestUtils extends Assert {
    private static final Log TROIDBSSRD = LogFactory.getLog(SwiftTestUtils.class);

    public static final String CPDHDAZZHR = "test.fs.swift.name";

    public static final String PNFYIDRBEM = "io.file.buffer.size";

    /**
     * Get the test URI
     *
     * @param conf
     * 		configuration
     * @throws SwiftConfigurationException
     * 		missing parameter or bad URI
     */
    public static URI getServiceURI(Configuration XNHTDSETJT) throws SwiftConfigurationException {
        String VUPJFHXEVF = XNHTDSETJT.get(SwiftTestUtils.CPDHDAZZHR);
        if (VUPJFHXEVF == null) {
            throw new SwiftConfigurationException("Missing configuration entry " + SwiftTestUtils.CPDHDAZZHR);
        }
        try {
            return new URI(VUPJFHXEVF);
        } catch (URISyntaxException e) {
            throw new SwiftConfigurationException("Bad URI: " + VUPJFHXEVF);
        }
    }

    public static boolean hasServiceURI(Configuration AELZKXTWHI) {
        String HQJVQSSYGY = AELZKXTWHI.get(SwiftTestUtils.CPDHDAZZHR);
        return HQJVQSSYGY != null;
    }

    /**
     * Assert that a property in the property set matches the expected value
     *
     * @param props
     * 		property set
     * @param key
     * 		property name
     * @param expected
     * 		expected value. If null, the property must not be in the set
     */
    public static void assertPropertyEquals(Properties CMABFYIPWN, String OQAMRHORJJ, String QIYCBFRZCQ) {
        String SYEWLBAGAN = CMABFYIPWN.getProperty(OQAMRHORJJ);
        if (QIYCBFRZCQ == null) {
            assertNull((("Non null property " + OQAMRHORJJ) + " = ") + SYEWLBAGAN, SYEWLBAGAN);
        } else {
            assertEquals((("property " + OQAMRHORJJ) + " = ") + SYEWLBAGAN, QIYCBFRZCQ, SYEWLBAGAN);
        }
    }

    /**
     * Write a file and read it in, validating the result. Optional flags control
     * whether file overwrite operations should be enabled, and whether the
     * file should be deleted afterwards.
     *
     * If there is a mismatch between what was written and what was expected,
     * a small range of bytes either side of the first error are logged to aid
     * diagnosing what problem occurred -whether it was a previous file
     * or a corrupting of the current file. This assumes that two
     * sequential runs to the same path use datasets with different character
     * moduli.
     *
     * @param fs
     * 		filesystem
     * @param path
     * 		path to write to
     * @param len
     * 		length of data
     * @param overwrite
     * 		should the create option allow overwrites?
     * @param delete
     * 		should the file be deleted afterwards? -with a verification
     * 		that it worked. Deletion is not attempted if an assertion has failed
     * 		earlier -it is not in a <code>finally{}</code> block.
     * @throws IOException
     * 		IO problems
     */
    public static void writeAndRead(FileSystem RVXZNDYTRB, Path HKOKNVBYBE, byte[] MWDWFVRAGS, int IEXYAPTKUH, int AGYZHXWYBY, boolean PQXZWOMKVX, boolean KIIEFXOZCG) throws IOException {
        RVXZNDYTRB.mkdirs(HKOKNVBYBE.getParent());
        SwiftTestUtils.writeDataset(RVXZNDYTRB, HKOKNVBYBE, MWDWFVRAGS, IEXYAPTKUH, AGYZHXWYBY, PQXZWOMKVX);
        byte[] WQEDYDDIVE = SwiftTestUtils.readDataset(RVXZNDYTRB, HKOKNVBYBE, IEXYAPTKUH);
        SwiftTestUtils.compareByteArrays(MWDWFVRAGS, WQEDYDDIVE, IEXYAPTKUH);
        if (KIIEFXOZCG) {
            boolean FKJAGBEARU = RVXZNDYTRB.delete(HKOKNVBYBE, false);
            assertTrue("Deleted", FKJAGBEARU);
            SwiftTestUtils.assertPathDoesNotExist(RVXZNDYTRB, "Cleanup failed", HKOKNVBYBE);
        }
    }

    /**
     * Write a file.
     * Optional flags control
     * whether file overwrite operations should be enabled
     *
     * @param fs
     * 		filesystem
     * @param path
     * 		path to write to
     * @param len
     * 		length of data
     * @param overwrite
     * 		should the create option allow overwrites?
     * @throws IOException
     * 		IO problems
     */
    public static void writeDataset(FileSystem XUQSSAMXRR, Path FWVENXXACX, byte[] NGQDMESZIK, int EUQTREAKTA, int MWIGUJAIIP, boolean HZESMULMHY) throws IOException {
        assertTrue(("Not enough data in source array to write " + EUQTREAKTA) + " bytes", NGQDMESZIK.length >= EUQTREAKTA);
        FSDataOutputStream BQGYONTKEO = XUQSSAMXRR.create(FWVENXXACX, HZESMULMHY, XUQSSAMXRR.getConf().getInt(SwiftTestUtils.PNFYIDRBEM, 4096), ((short) (1)), MWIGUJAIIP);
        BQGYONTKEO.write(NGQDMESZIK, 0, EUQTREAKTA);
        BQGYONTKEO.close();
        SwiftTestUtils.assertFileHasLength(XUQSSAMXRR, FWVENXXACX, EUQTREAKTA);
    }

    /**
     * Read the file and convert to a byte dataaset
     *
     * @param fs
     * 		filesystem
     * @param path
     * 		path to read from
     * @param len
     * 		length of data to read
     * @return the bytes
     * @throws IOException
     * 		IO problems
     */
    public static byte[] readDataset(FileSystem OXJSHVOUHB, Path EJXQBCPRLA, int NBGENGDIVY) throws IOException {
        FSDataInputStream EBWVGRWZSA = OXJSHVOUHB.open(EJXQBCPRLA);
        byte[] UUTTCWAEUN = new byte[NBGENGDIVY];
        try {
            EBWVGRWZSA.readFully(0, UUTTCWAEUN);
        } finally {
            EBWVGRWZSA.close();
        }
        return UUTTCWAEUN;
    }

    /**
     * Assert that tthe array src[0..len] and dest[] are equal
     *
     * @param src
     * 		source data
     * @param dest
     * 		actual
     * @param len
     * 		length of bytes to compare
     */
    public static void compareByteArrays(byte[] JDVGTFHRSK, byte[] OCOYKJGTAV, int GCTFPYCRKW) {
        assertEquals("Number of bytes read != number written", GCTFPYCRKW, OCOYKJGTAV.length);
        int UOIIHIITYB = 0;
        int JUZLELKLJB = -1;
        for (int FIZTAVZPBR = 0; FIZTAVZPBR < GCTFPYCRKW; FIZTAVZPBR++) {
            if (JDVGTFHRSK[FIZTAVZPBR] != OCOYKJGTAV[FIZTAVZPBR]) {
                if (UOIIHIITYB == 0) {
                    JUZLELKLJB = FIZTAVZPBR;
                }
                UOIIHIITYB++;
            }
        }
        if (UOIIHIITYB > 0) {
            String FCBQVOVTOP = String.format(" %d errors in file of length %d", UOIIHIITYB, GCTFPYCRKW);
            SwiftTestUtils.TROIDBSSRD.warn(FCBQVOVTOP);
            // the range either side of the first error to print
            // this is a purely arbitrary number, to aid user debugging
            final int SVRPBPKTCF = 10;
            for (int NJVRSLHVCM = Math.max(0, JUZLELKLJB - SVRPBPKTCF); NJVRSLHVCM < Math.min(JUZLELKLJB + SVRPBPKTCF, GCTFPYCRKW); NJVRSLHVCM++) {
                byte ZJUCODFMYV = OCOYKJGTAV[NJVRSLHVCM];
                byte HUQCUJNDYU = JDVGTFHRSK[NJVRSLHVCM];
                String WDAOZNRMIC = SwiftTestUtils.toChar(ZJUCODFMYV);
                String OQNXDKCQJM = String.format("[%04d] %2x %s\n", NJVRSLHVCM, ZJUCODFMYV, WDAOZNRMIC);
                if (HUQCUJNDYU != ZJUCODFMYV) {
                    OQNXDKCQJM = String.format("[%04d] %2x %s -expected %2x %s\n", NJVRSLHVCM, ZJUCODFMYV, WDAOZNRMIC, HUQCUJNDYU, SwiftTestUtils.toChar(HUQCUJNDYU));
                }
                SwiftTestUtils.TROIDBSSRD.warn(OQNXDKCQJM);
            }
            fail(FCBQVOVTOP);
        }
    }

    /**
     * Convert a byte to a character for printing. If the
     * byte value is < 32 -and hence unprintable- the byte is
     * returned as a two digit hex value
     *
     * @param b
     * 		byte
     * @return the printable character string
     */
    public static String toChar(byte PUVOYUMELC) {
        if (PUVOYUMELC >= 0x20) {
            return Character.toString(((char) (PUVOYUMELC)));
        } else {
            return String.format("%02x", PUVOYUMELC);
        }
    }

    public static String toChar(byte[] CYCPMCEUXQ) {
        StringBuilder QSPZYNXSWY = new StringBuilder(CYCPMCEUXQ.length);
        for (byte AYABVZYVRR : CYCPMCEUXQ) {
            QSPZYNXSWY.append(SwiftTestUtils.toChar(AYABVZYVRR));
        }
        return QSPZYNXSWY.toString();
    }

    public static byte[] toAsciiByteArray(String CLIKGKNRQS) {
        char[] VAMAHALDDI = CLIKGKNRQS.toCharArray();
        int FIVPMOPNMB = VAMAHALDDI.length;
        byte[] VHCWOKSJSM = new byte[FIVPMOPNMB];
        for (int CRYVIPTKQD = 0; CRYVIPTKQD < FIVPMOPNMB; CRYVIPTKQD++) {
            VHCWOKSJSM[CRYVIPTKQD] = ((byte) (VAMAHALDDI[CRYVIPTKQD] & 0xff));
        }
        return VHCWOKSJSM;
    }

    public static void cleanupInTeardown(FileSystem RPRRXIXGQD, String LYDRKVQXKU) {
        SwiftTestUtils.cleanup("TEARDOWN", RPRRXIXGQD, LYDRKVQXKU);
    }

    public static void cleanup(String XXFWZFMKKP, FileSystem UXDPQMONEI, String NKKDHRAFMA) {
        SwiftTestUtils.noteAction(XXFWZFMKKP);
        try {
            if (UXDPQMONEI != null) {
                UXDPQMONEI.delete(new Path(NKKDHRAFMA).makeQualified(UXDPQMONEI), true);
            }
        } catch (Exception e) {
            SwiftTestUtils.TROIDBSSRD.error((((("Error deleting in " + XXFWZFMKKP) + " - ") + NKKDHRAFMA) + ": ") + e, e);
        }
    }

    public static void noteAction(String DERYPTNECO) {
        if (SwiftTestUtils.TROIDBSSRD.isDebugEnabled()) {
            SwiftTestUtils.TROIDBSSRD.debug(("==============  " + DERYPTNECO) + " =============");
        }
    }

    /**
     * downgrade a failure to a message and a warning, then an
     * exception for the Junit test runner to mark as failed
     *
     * @param message
     * 		text message
     * @param failure
     * 		what failed
     * @throws AssumptionViolatedException
     * 		always
     */
    public static void downgrade(String DZVLFTJMIU, Throwable KNIEOJKDVJ) {
        SwiftTestUtils.TROIDBSSRD.warn("Downgrading test " + DZVLFTJMIU, KNIEOJKDVJ);
        AssumptionViolatedException BZBLUIXZVF = new AssumptionViolatedException(KNIEOJKDVJ, null);
        throw BZBLUIXZVF;
    }

    /**
     * report an overridden test as unsupported
     *
     * @param message
     * 		message to use in the text
     * @throws AssumptionViolatedException
     * 		always
     */
    public static void unsupported(String MVFCZWFPCI) {
        throw new AssumptionViolatedException(MVFCZWFPCI);
    }

    /**
     * report a test has been skipped for some reason
     *
     * @param message
     * 		message to use in the text
     * @throws AssumptionViolatedException
     * 		always
     */
    public static void skip(String CJLKXABVPR) {
        throw new AssumptionViolatedException(CJLKXABVPR);
    }

    /**
     * Make an assertion about the length of a file
     *
     * @param fs
     * 		filesystem
     * @param path
     * 		path of the file
     * @param expected
     * 		expected length
     * @throws IOException
     * 		on File IO problems
     */
    public static void assertFileHasLength(FileSystem RWTHTNWNIU, Path HWRVJMQLRZ, int YTEMLZIFBZ) throws IOException {
        FileStatus YPMCWBDHJA = RWTHTNWNIU.getFileStatus(HWRVJMQLRZ);
        assertEquals((("Wrong file length of file " + HWRVJMQLRZ) + " status: ") + YPMCWBDHJA, YTEMLZIFBZ, YPMCWBDHJA.getLen());
    }

    /**
     * Assert that a path refers to a directory
     *
     * @param fs
     * 		filesystem
     * @param path
     * 		path of the directory
     * @throws IOException
     * 		on File IO problems
     */
    public static void assertIsDirectory(FileSystem VCDWWBBHTR, Path YGBMPRUTQA) throws IOException {
        FileStatus KHLGOHHYSD = VCDWWBBHTR.getFileStatus(YGBMPRUTQA);
        SwiftTestUtils.assertIsDirectory(KHLGOHHYSD);
    }

    /**
     * Assert that a path refers to a directory
     *
     * @param fileStatus
     * 		stats to check
     */
    public static void assertIsDirectory(FileStatus HQUONXWBBX) {
        assertTrue("Should be a dir -but isn't: " + HQUONXWBBX, HQUONXWBBX.isDirectory());
    }

    /**
     * Write the text to a file, returning the converted byte array
     * for use in validating the round trip
     *
     * @param fs
     * 		filesystem
     * @param path
     * 		path of file
     * @param text
     * 		text to write
     * @param overwrite
     * 		should the operation overwrite any existing file?
     * @return the read bytes
     * @throws IOException
     * 		on IO problems
     */
    public static byte[] writeTextFile(FileSystem SHWDEGLTZH, Path XHZYHBFVNM, String NDDCDHFYKL, boolean UTZZALJNKP) throws IOException {
        FSDataOutputStream UADZICRXLE = SHWDEGLTZH.create(XHZYHBFVNM, UTZZALJNKP);
        byte[] UIKINWTUAL = new byte[0];
        if (NDDCDHFYKL != null) {
            UIKINWTUAL = SwiftTestUtils.toAsciiByteArray(NDDCDHFYKL);
            UADZICRXLE.write(UIKINWTUAL);
        }
        UADZICRXLE.close();
        return UIKINWTUAL;
    }

    /**
     * Touch a file: fails if it is already there
     *
     * @param fs
     * 		filesystem
     * @param path
     * 		path
     * @throws IOException
     * 		IO problems
     */
    public static void touch(FileSystem ELTKEPDZHV, Path SPIDTMJEMZ) throws IOException {
        ELTKEPDZHV.delete(SPIDTMJEMZ, true);
        SwiftTestUtils.writeTextFile(ELTKEPDZHV, SPIDTMJEMZ, null, false);
    }

    public static void assertDeleted(FileSystem HUCZWNFKKS, Path LFODLRIYVD, boolean KWIAWETQXN) throws IOException {
        SwiftTestUtils.assertPathExists(HUCZWNFKKS, "about to be deleted file", LFODLRIYVD);
        boolean WDVGJTAGJY = HUCZWNFKKS.delete(LFODLRIYVD, KWIAWETQXN);
        String RBSMYAGBNY = SwiftTestUtils.ls(HUCZWNFKKS, LFODLRIYVD.getParent());
        assertTrue((("Delete failed on " + LFODLRIYVD) + ": ") + RBSMYAGBNY, WDVGJTAGJY);
        SwiftTestUtils.assertPathDoesNotExist(HUCZWNFKKS, "Deleted file", LFODLRIYVD);
    }

    /**
     * Read in "length" bytes, convert to an ascii string
     *
     * @param fs
     * 		filesystem
     * @param path
     * 		path to read
     * @param length
     * 		#of bytes to read.
     * @return the bytes read and converted to a string
     * @throws IOException
     * 		
     */
    public static String readBytesToString(FileSystem ZXCXRDGJLF, Path VKRAZDWCGA, int AOCFYRWTMD) throws IOException {
        FSDataInputStream ESGYXFFBNX = ZXCXRDGJLF.open(VKRAZDWCGA);
        try {
            byte[] NFPCQOVHDS = new byte[AOCFYRWTMD];
            ESGYXFFBNX.readFully(0, NFPCQOVHDS);
            return SwiftTestUtils.toChar(NFPCQOVHDS);
        } finally {
            ESGYXFFBNX.close();
        }
    }

    public static String getDefaultWorkingDirectory() {
        return "/user/" + System.getProperty("user.name");
    }

    public static String ls(FileSystem EXUMFRMETX, Path VITVGQSBLJ) throws IOException {
        return SwiftUtils.ls(EXUMFRMETX, VITVGQSBLJ);
    }

    public static String dumpStats(String LMRVRGWTUV, FileStatus[] AARGZXDVXL) {
        return LMRVRGWTUV + SwiftUtils.fileStatsToString(AARGZXDVXL, "\n");
    }

    /**
     * Assert that a file exists and whose {@link FileStatus} entry
     * declares that this is a file and not a symlink or directory.
     *
     * @param fileSystem
     * 		filesystem to resolve path against
     * @param filename
     * 		name of the file
     * @throws IOException
     * 		IO problems during file operations
     */
    public static void assertIsFile(FileSystem NAAYYDFWKK, Path JWITPJOGCL) throws IOException {
        SwiftTestUtils.assertPathExists(NAAYYDFWKK, "Expected file", JWITPJOGCL);
        FileStatus RERZJVPBHP = NAAYYDFWKK.getFileStatus(JWITPJOGCL);
        String TKZXITJCVU = (JWITPJOGCL + "  ") + RERZJVPBHP;
        assertFalse("File claims to be a directory " + TKZXITJCVU, RERZJVPBHP.isDirectory());
        /* disabled for Hadoop v1 compatibility
        assertFalse("File claims to be a symlink " + fileInfo,
        status.isSymlink());
         */
    }

    /**
     * Create a dataset for use in the tests; all data is in the range
     * base to (base+modulo-1) inclusive
     *
     * @param len
     * 		length of data
     * @param base
     * 		base of the data
     * @param modulo
     * 		the modulo
     * @return the newly generated dataset
     */
    public static byte[] dataset(int PHRWULJFBS, int WTVYMAWIDZ, int ROCRWTHYNH) {
        byte[] RYZTUADHWX = new byte[PHRWULJFBS];
        for (int OPFRDOUUCN = 0; OPFRDOUUCN < PHRWULJFBS; OPFRDOUUCN++) {
            RYZTUADHWX[OPFRDOUUCN] = ((byte) (WTVYMAWIDZ + (OPFRDOUUCN % ROCRWTHYNH)));
        }
        return RYZTUADHWX;
    }

    /**
     * Assert that a path exists -but make no assertions as to the
     * type of that entry
     *
     * @param fileSystem
     * 		filesystem to examine
     * @param message
     * 		message to include in the assertion failure message
     * @param path
     * 		path in the filesystem
     * @throws IOException
     * 		IO problems
     */
    public static void assertPathExists(FileSystem SATWLKVURV, String IEOMMIYJDM, Path PQYPOFTMXP) throws IOException {
        if (!SATWLKVURV.exists(PQYPOFTMXP)) {
            // failure, report it
            fail((((IEOMMIYJDM + ": not found ") + PQYPOFTMXP) + " in ") + PQYPOFTMXP.getParent());
            SwiftTestUtils.ls(SATWLKVURV, PQYPOFTMXP.getParent());
        }
    }

    /**
     * Assert that a path does not exist
     *
     * @param fileSystem
     * 		filesystem to examine
     * @param message
     * 		message to include in the assertion failure message
     * @param path
     * 		path in the filesystem
     * @throws IOException
     * 		IO problems
     */
    public static void assertPathDoesNotExist(FileSystem YCJEECCWON, String YTEWPRMKKG, Path BDDVKANFAM) throws IOException {
        try {
            FileStatus NJNSFHMDCT = YCJEECCWON.getFileStatus(BDDVKANFAM);
            fail((((YTEWPRMKKG + ": unexpectedly found ") + BDDVKANFAM) + " as  ") + NJNSFHMDCT);
        } catch (FileNotFoundException expected) {
            // this is expected
        }
    }

    /**
     * Assert that a FileSystem.listStatus on a dir finds the subdir/child entry
     *
     * @param fs
     * 		filesystem
     * @param dir
     * 		directory to scan
     * @param subdir
     * 		full path to look for
     * @throws IOException
     * 		IO probles
     */
    public static void assertListStatusFinds(FileSystem UVFRPFMTDD, Path ZDWOMHOJMZ, Path TUVNBSAPIA) throws IOException {
        FileStatus[] XSJETGFWOY = UVFRPFMTDD.listStatus(ZDWOMHOJMZ);
        boolean LVCTNYEPAY = false;
        StringBuilder CPMDFLSNFD = new StringBuilder();
        for (FileStatus KAGTQRIGZQ : XSJETGFWOY) {
            CPMDFLSNFD.append(KAGTQRIGZQ.toString()).append('\n');
            if (KAGTQRIGZQ.getPath().equals(TUVNBSAPIA)) {
                LVCTNYEPAY = true;
            }
        }
        assertTrue((((("Path " + TUVNBSAPIA) + " not found in directory ") + ZDWOMHOJMZ) + ":") + CPMDFLSNFD, LVCTNYEPAY);
    }
}