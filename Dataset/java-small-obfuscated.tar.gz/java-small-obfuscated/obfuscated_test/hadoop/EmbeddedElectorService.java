@InterfaceAudience.Private
@InterfaceStability.Unstable
public class EmbeddedElectorService extends AbstractService implements ActiveStandbyElector.ActiveStandbyElectorCallback {
    private static final Log DPEYHSHXOT = LogFactory.getLog(EmbeddedElectorService.class.getName());

    private static final StateChangeRequestInfo VFBHJJNTBM = new org.apache.hadoop.ha.HAServiceProtocol.StateChangeRequestInfo(RequestSource.REQUEST_BY_ZKFC);

    private RMContext SIZMUPWKUW;

    private byte[] FGQWIILRBT;

    private ActiveStandbyElector MMFYBSJDCQ;

    EmbeddedElectorService(RMContext EQMAGMSLDM) {
        super(EmbeddedElectorService.class.getName());
        this.SIZMUPWKUW = EQMAGMSLDM;
    }

    @Override
    protected void serviceInit(Configuration RSHEYQXWGH) throws Exception {
        RSHEYQXWGH = (RSHEYQXWGH instanceof YarnConfiguration) ? RSHEYQXWGH : new YarnConfiguration(RSHEYQXWGH);
        String DIBBJDEOCN = RSHEYQXWGH.get(RM_ZK_ADDRESS);
        if (DIBBJDEOCN == null) {
            throw new org.apache.hadoop.yarn.exceptions.YarnRuntimeException((("Embedded automatic failover " + "is enabled, but ") + YarnConfiguration.RM_ZK_ADDRESS) + " is not set");
        }
        String PNGSGMBPYV = HAUtil.getRMHAId(RSHEYQXWGH);
        String XBVYPXIEDQ = YarnConfiguration.getClusterId(RSHEYQXWGH);
        FGQWIILRBT = EmbeddedElectorService.createActiveNodeInfo(XBVYPXIEDQ, PNGSGMBPYV);
        String UXDZERWJAN = RSHEYQXWGH.get(AUTO_FAILOVER_ZK_BASE_PATH, DEFAULT_AUTO_FAILOVER_ZK_BASE_PATH);
        String MDYKQTGNGI = (UXDZERWJAN + "/") + XBVYPXIEDQ;
        long JZTEAAFZCZ = RSHEYQXWGH.getLong(RM_ZK_TIMEOUT_MS, DEFAULT_RM_ZK_TIMEOUT_MS);
        List<ACL> QJKZOHAHMK = RMZKUtils.getZKAcls(RSHEYQXWGH);
        List<ZKUtil.ZKAuthInfo> MRAKKNONZM = RMZKUtils.getZKAuths(RSHEYQXWGH);
        int QCIXOVGAOW = RSHEYQXWGH.getInt(HA_FC_ELECTOR_ZK_OP_RETRIES_KEY, HA_FC_ELECTOR_ZK_OP_RETRIES_DEFAULT);
        MMFYBSJDCQ = new ActiveStandbyElector(DIBBJDEOCN, ((int) (JZTEAAFZCZ)), MDYKQTGNGI, QJKZOHAHMK, MRAKKNONZM, this, QCIXOVGAOW);
        MMFYBSJDCQ.ensureParentZNode();
        if (!isParentZnodeSafe(XBVYPXIEDQ)) {
            notifyFatalError((MDYKQTGNGI + " znode has invalid data! ") + "Might need formatting!");
        }
        super.serviceInit(RSHEYQXWGH);
    }

    @Override
    protected void serviceStart() throws Exception {
        MMFYBSJDCQ.joinElection(FGQWIILRBT);
        super.serviceStart();
    }

    @Override
    protected void serviceStop() throws Exception {
        /**
         * When error occurs in serviceInit(), serviceStop() can be called.
         * We need null check for the case.
         */
        if (MMFYBSJDCQ != null) {
            MMFYBSJDCQ.quitElection(false);
            MMFYBSJDCQ.terminateConnection();
        }
        super.serviceStop();
    }

    @Override
    public void becomeActive() throws ServiceFailedException {
        try {
            SIZMUPWKUW.getRMAdminService().transitionToActive(EmbeddedElectorService.VFBHJJNTBM);
        } catch (Exception e) {
            throw new ServiceFailedException("RM could not transition to Active", e);
        }
    }

    @Override
    public void becomeStandby() {
        try {
            SIZMUPWKUW.getRMAdminService().transitionToStandby(EmbeddedElectorService.VFBHJJNTBM);
        } catch (Exception e) {
            EmbeddedElectorService.DPEYHSHXOT.error("RM could not transition to Standby", e);
        }
    }

    @Override
    public void enterNeutralMode() {
        /**
         * Possibly due to transient connection issues. Do nothing.
         * TODO: Might want to keep track of how long in this state and transition
         * to standby.
         */
    }

    @SuppressWarnings("unchecked")
    @Override
    public void notifyFatalError(String HFZUZMXCZC) {
        SIZMUPWKUW.getDispatcher().getEventHandler().handle(new RMFatalEvent(RMFatalEventType.EMBEDDED_ELECTOR_FAILED, HFZUZMXCZC));
    }

    @Override
    public void fenceOldActive(byte[] XIGDIWHTLY) {
        if (EmbeddedElectorService.DPEYHSHXOT.isDebugEnabled()) {
            EmbeddedElectorService.DPEYHSHXOT.debug("Request to fence old active being ignored, " + "as embedded leader election doesn't support fencing");
        }
    }

    private static byte[] createActiveNodeInfo(String LQYAQFYKXB, String CVMBNQTJDS) throws IOException {
        return ActiveRMInfoProto.newBuilder().setClusterId(LQYAQFYKXB).setRmId(CVMBNQTJDS).build().toByteArray();
    }

    private boolean isParentZnodeSafe(String LXWKUSKJKD) throws IOException, InterruptedException, KeeperException {
        byte[] OSKMQICZEO;
        try {
            OSKMQICZEO = MMFYBSJDCQ.getActiveData();
        } catch (ActiveStandbyElector e) {
            // no active found, parent znode is safe
            return true;
        }
        YarnServerResourceManagerServiceProtos.ActiveRMInfoProto FFBTVINOZU;
        try {
            FFBTVINOZU = ActiveRMInfoProto.parseFrom(OSKMQICZEO);
        } catch (InvalidProtocolBufferException e) {
            EmbeddedElectorService.DPEYHSHXOT.error("Invalid data in ZK: " + StringUtils.byteToHexString(OSKMQICZEO));
            return false;
        }
        // Check if the passed proto corresponds to an RM in the same cluster
        if (!FFBTVINOZU.getClusterId().equals(LXWKUSKJKD)) {
            EmbeddedElectorService.DPEYHSHXOT.error(((("Mismatched cluster! The other RM seems " + "to be from a different cluster. Current cluster = ") + LXWKUSKJKD) + "Other RM's cluster = ") + FFBTVINOZU.getClusterId());
            return false;
        }
        return true;
    }

    public void resetLeaderElection() {
        MMFYBSJDCQ.quitElection(false);
        MMFYBSJDCQ.joinElection(FGQWIILRBT);
    }
}