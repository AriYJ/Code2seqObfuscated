public abstract class HFSTestCase extends HTestCase {
    @Rule
    public MethodRule JPUURNYNGT = new TestHdfsHelper();
}