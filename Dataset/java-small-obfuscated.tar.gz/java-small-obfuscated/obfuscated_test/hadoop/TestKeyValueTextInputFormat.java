public class TestKeyValueTextInputFormat extends TestCase {
    private static final Log HCKQTCKSBH = LogFactory.getLog(TestKeyValueTextInputFormat.class.getName());

    private static int PSAZBIBUYK = 10000;

    private static JobConf AGRDZLMCHB = new JobConf();

    private static java.io.FileSystem TGMRSKKNJQ = null;

    static {
        try {
            TestKeyValueTextInputFormat.TGMRSKKNJQ = FileSystem.getLocal(TestKeyValueTextInputFormat.AGRDZLMCHB);
        } catch (IOException e) {
            throw new RuntimeException("init failure", e);
        }
    }

    private static Path RJHFXDLDHY = new Path(new Path(System.getProperty("test.build.data", "."), "data"), "TestKeyValueTextInputFormat");

    public void testFormat() throws Exception {
        JobConf FCRKRXUCEQ = new JobConf();
        Path NTHIEVJORP = new Path(TestKeyValueTextInputFormat.RJHFXDLDHY, "test.txt");
        // A reporter that does nothing
        Reporter IJMCTQRGXG = Reporter.NULL;
        int MJEVEROIGX = new Random().nextInt();
        TestKeyValueTextInputFormat.HCKQTCKSBH.info("seed = " + MJEVEROIGX);
        Random VEEKPGJKYJ = new Random(MJEVEROIGX);
        TestKeyValueTextInputFormat.TGMRSKKNJQ.delete(TestKeyValueTextInputFormat.RJHFXDLDHY, true);
        FileInputFormat.setInputPaths(FCRKRXUCEQ, TestKeyValueTextInputFormat.RJHFXDLDHY);
        // for a variety of lengths
        for (int GAGLLNERIF = 0; GAGLLNERIF < TestKeyValueTextInputFormat.PSAZBIBUYK; GAGLLNERIF += VEEKPGJKYJ.nextInt(TestKeyValueTextInputFormat.PSAZBIBUYK / 10) + 1) {
            TestKeyValueTextInputFormat.HCKQTCKSBH.debug("creating; entries = " + GAGLLNERIF);
            // create a file with length entries
            Writer LMHFMBGMMJ = new OutputStreamWriter(TestKeyValueTextInputFormat.TGMRSKKNJQ.create(NTHIEVJORP));
            try {
                for (int FZVGEHCEBL = 0; FZVGEHCEBL < GAGLLNERIF; FZVGEHCEBL++) {
                    LMHFMBGMMJ.write(Integer.toString(FZVGEHCEBL * 2));
                    LMHFMBGMMJ.write("\t");
                    LMHFMBGMMJ.write(Integer.toString(FZVGEHCEBL));
                    LMHFMBGMMJ.write("\n");
                }
            } finally {
                LMHFMBGMMJ.close();
            }
            // try splitting the file in a variety of sizes
            KeyValueTextInputFormat UXVFUFBGND = new KeyValueTextInputFormat();
            UXVFUFBGND.configure(FCRKRXUCEQ);
            for (int ZRQBDJJAIS = 0; ZRQBDJJAIS < 3; ZRQBDJJAIS++) {
                int EXOODWLBEZ = VEEKPGJKYJ.nextInt(TestKeyValueTextInputFormat.PSAZBIBUYK / 20) + 1;
                TestKeyValueTextInputFormat.HCKQTCKSBH.debug("splitting: requesting = " + EXOODWLBEZ);
                InputSplit[] FFRGSHQFLX = UXVFUFBGND.getSplits(FCRKRXUCEQ, EXOODWLBEZ);
                TestKeyValueTextInputFormat.HCKQTCKSBH.debug("splitting: got =        " + FFRGSHQFLX.length);
                // check each split
                BitSet HPTMCEJJNY = new BitSet(GAGLLNERIF);
                for (int YLJMSHSUIP = 0; YLJMSHSUIP < FFRGSHQFLX.length; YLJMSHSUIP++) {
                    TestKeyValueTextInputFormat.HCKQTCKSBH.debug((("split[" + YLJMSHSUIP) + "]= ") + FFRGSHQFLX[YLJMSHSUIP]);
                    RecordReader<Text, Text> QCSYQNCOMJ = UXVFUFBGND.getRecordReader(FFRGSHQFLX[YLJMSHSUIP], FCRKRXUCEQ, IJMCTQRGXG);
                    Class UOSNKEQLAB = QCSYQNCOMJ.getClass();
                    assertEquals("reader class is KeyValueLineRecordReader.", KeyValueLineRecordReader.class, UOSNKEQLAB);
                    Text PIVWMXDILU = QCSYQNCOMJ.createKey();
                    Class LBXEHMQYNJ = PIVWMXDILU.getClass();
                    Text ZVONRNFWPN = QCSYQNCOMJ.createValue();
                    Class KHPZTDODJZ = ZVONRNFWPN.getClass();
                    assertEquals("Key class is Text.", Text.class, LBXEHMQYNJ);
                    assertEquals("Value class is Text.", Text.class, KHPZTDODJZ);
                    try {
                        int HUVQIYHJGQ = 0;
                        while (QCSYQNCOMJ.next(PIVWMXDILU, ZVONRNFWPN)) {
                            int PZPWWMYQIL = Integer.parseInt(ZVONRNFWPN.toString());
                            TestKeyValueTextInputFormat.HCKQTCKSBH.debug("read " + PZPWWMYQIL);
                            if (HPTMCEJJNY.get(PZPWWMYQIL)) {
                                TestKeyValueTextInputFormat.HCKQTCKSBH.warn((((("conflict with " + PZPWWMYQIL) + " in split ") + YLJMSHSUIP) + " at position ") + QCSYQNCOMJ.getPos());
                            }
                            assertFalse("Key in multiple partitions.", HPTMCEJJNY.get(PZPWWMYQIL));
                            HPTMCEJJNY.set(PZPWWMYQIL);
                            HUVQIYHJGQ++;
                        } 
                        TestKeyValueTextInputFormat.HCKQTCKSBH.debug((((("splits[" + YLJMSHSUIP) + "]=") + FFRGSHQFLX[YLJMSHSUIP]) + " count=") + HUVQIYHJGQ);
                    } finally {
                        QCSYQNCOMJ.close();
                    }
                }
                assertEquals("Some keys in no partition.", GAGLLNERIF, HPTMCEJJNY.cardinality());
            }
        }
    }

    private LineReader makeStream(String XOXNGMMNVV) throws IOException {
        return new LineReader(new ByteArrayInputStream(XOXNGMMNVV.getBytes("UTF-8")), TestKeyValueTextInputFormat.AGRDZLMCHB);
    }

    public void testUTF8() throws Exception {
        LineReader TIYPXBCZQX = null;
        try {
            TIYPXBCZQX = makeStream("abcd\u20acbdcd\u20ac");
            Text USJWJEQJIJ = new Text();
            TIYPXBCZQX.readLine(USJWJEQJIJ);
            assertEquals("readLine changed utf8 characters", "abcd\u20acbdcd\u20ac", USJWJEQJIJ.toString());
            TIYPXBCZQX = makeStream("abc\u200axyz");
            TIYPXBCZQX.readLine(USJWJEQJIJ);
            assertEquals("split on fake newline", "abc\u200axyz", USJWJEQJIJ.toString());
        } finally {
            if (TIYPXBCZQX != null) {
                TIYPXBCZQX.close();
            }
        }
    }

    public void testNewLines() throws Exception {
        LineReader CHPACPGWOY = null;
        try {
            CHPACPGWOY = makeStream("a\nbb\n\nccc\rdddd\r\neeeee");
            Text HVECEVPEOQ = new Text();
            CHPACPGWOY.readLine(HVECEVPEOQ);
            assertEquals("line1 length", 1, HVECEVPEOQ.getLength());
            CHPACPGWOY.readLine(HVECEVPEOQ);
            assertEquals("line2 length", 2, HVECEVPEOQ.getLength());
            CHPACPGWOY.readLine(HVECEVPEOQ);
            assertEquals("line3 length", 0, HVECEVPEOQ.getLength());
            CHPACPGWOY.readLine(HVECEVPEOQ);
            assertEquals("line4 length", 3, HVECEVPEOQ.getLength());
            CHPACPGWOY.readLine(HVECEVPEOQ);
            assertEquals("line5 length", 4, HVECEVPEOQ.getLength());
            CHPACPGWOY.readLine(HVECEVPEOQ);
            assertEquals("line5 length", 5, HVECEVPEOQ.getLength());
            assertEquals("end of file", 0, CHPACPGWOY.readLine(HVECEVPEOQ));
        } finally {
            if (CHPACPGWOY != null) {
                CHPACPGWOY.close();
            }
        }
    }

    private static void writeFile(FileSystem ALXJPGGGFB, Path JDVXGKWDOG, CompressionCodec HUTICHWPUV, String HRPZLDDGEZ) throws IOException {
        OutputStream USAULKDNNC;
        if (HUTICHWPUV == null) {
            USAULKDNNC = ALXJPGGGFB.create(JDVXGKWDOG);
        } else {
            USAULKDNNC = HUTICHWPUV.createOutputStream(ALXJPGGGFB.create(JDVXGKWDOG));
        }
        USAULKDNNC.write(HRPZLDDGEZ.getBytes());
        USAULKDNNC.close();
    }

    private static final Reporter OKYIZXOYTP = Reporter.NULL;

    private static List<Text> readSplit(KeyValueTextInputFormat CSGJVKWUCT, InputSplit DYVXKLJCLP, JobConf PAICMATTAH) throws IOException {
        List<Text> SPUTLTNVVV = new ArrayList<Text>();
        RecordReader<Text, Text> EVZNWNGQXR = null;
        try {
            EVZNWNGQXR = CSGJVKWUCT.getRecordReader(DYVXKLJCLP, PAICMATTAH, TestKeyValueTextInputFormat.OKYIZXOYTP);
            Text HSFSPQKJAJ = EVZNWNGQXR.createKey();
            Text ZDQEOCPYLW = EVZNWNGQXR.createValue();
            while (EVZNWNGQXR.next(HSFSPQKJAJ, ZDQEOCPYLW)) {
                SPUTLTNVVV.add(ZDQEOCPYLW);
                ZDQEOCPYLW = ((Text) (EVZNWNGQXR.createValue()));
            } 
        } finally {
            if (EVZNWNGQXR != null) {
                EVZNWNGQXR.close();
            }
        }
        return SPUTLTNVVV;
    }

    /**
     * Test using the gzip codec for reading
     */
    public static void testGzip() throws IOException {
        JobConf JFKISUERHH = new JobConf();
        CompressionCodec VCQUIYBKWC = new GzipCodec();
        ReflectionUtils.setConf(VCQUIYBKWC, JFKISUERHH);
        TestKeyValueTextInputFormat.TGMRSKKNJQ.delete(TestKeyValueTextInputFormat.RJHFXDLDHY, true);
        TestKeyValueTextInputFormat.writeFile(TestKeyValueTextInputFormat.TGMRSKKNJQ, new Path(TestKeyValueTextInputFormat.RJHFXDLDHY, "part1.txt.gz"), VCQUIYBKWC, "line-1\tthe quick\nline-2\tbrown\nline-3\tfox jumped\nline-4\tover\nline-5\t the lazy\nline-6\t dog\n");
        TestKeyValueTextInputFormat.writeFile(TestKeyValueTextInputFormat.TGMRSKKNJQ, new Path(TestKeyValueTextInputFormat.RJHFXDLDHY, "part2.txt.gz"), VCQUIYBKWC, "line-1\tthis is a test\nline-1\tof gzip\n");
        FileInputFormat.setInputPaths(JFKISUERHH, TestKeyValueTextInputFormat.RJHFXDLDHY);
        KeyValueTextInputFormat MWZFUBLVXI = new KeyValueTextInputFormat();
        MWZFUBLVXI.configure(JFKISUERHH);
        InputSplit[] FXDWRBQHMM = MWZFUBLVXI.getSplits(JFKISUERHH, 100);
        assertEquals("compressed splits == 2", 2, FXDWRBQHMM.length);
        FileSplit JAUNYJHOSF = ((FileSplit) (FXDWRBQHMM[0]));
        if (JAUNYJHOSF.getPath().getName().equals("part2.txt.gz")) {
            FXDWRBQHMM[0] = FXDWRBQHMM[1];
            FXDWRBQHMM[1] = JAUNYJHOSF;
        }
        List<Text> PTBIPSRULG = TestKeyValueTextInputFormat.readSplit(MWZFUBLVXI, FXDWRBQHMM[0], JFKISUERHH);
        assertEquals("splits[0] length", 6, PTBIPSRULG.size());
        assertEquals("splits[0][5]", " dog", PTBIPSRULG.get(5).toString());
        PTBIPSRULG = TestKeyValueTextInputFormat.readSplit(MWZFUBLVXI, FXDWRBQHMM[1], JFKISUERHH);
        assertEquals("splits[1] length", 2, PTBIPSRULG.size());
        assertEquals("splits[1][0]", "this is a test", PTBIPSRULG.get(0).toString());
        assertEquals("splits[1][1]", "of gzip", PTBIPSRULG.get(1).toString());
    }

    public static void main(String[] RAXGCKBMWV) throws Exception {
        new TestKeyValueTextInputFormat().testFormat();
    }
}