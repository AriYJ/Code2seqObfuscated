/**
 *
 *
 * @see TestDelegatingInputFormat
 */
public class TestMultipleInputs extends HadoopTestCase {
    public TestMultipleInputs() throws IOException {
        super(LOCAL_MR, LOCAL_FS, 1, 1);
    }

    private static final Path LMZGCCMAJQ = new Path("testing/mo");

    private static final Path KAAPXXBTTT = new Path(TestMultipleInputs.LMZGCCMAJQ, "input1");

    private static final Path EBQXVODNHZ = new Path(TestMultipleInputs.LMZGCCMAJQ, "input2");

    private static final Path ANVTLEIMTZ = new Path(TestMultipleInputs.LMZGCCMAJQ, "output");

    private Path getDir(Path DTXUDPCTQM) {
        // Hack for local FS that does not have the concept of a 'mounting point'
        if (isLocalFS()) {
            String MNMUCEMMNB = System.getProperty("test.build.data", "/tmp").replace(' ', '+');
            DTXUDPCTQM = new Path(MNMUCEMMNB, DTXUDPCTQM);
        }
        return DTXUDPCTQM;
    }

    @Before
    public void setUp() throws Exception {
        super.setUp();
        Path OXRJHEIDYO = getDir(TestMultipleInputs.LMZGCCMAJQ);
        Path JLUUUNZZUH = getDir(TestMultipleInputs.KAAPXXBTTT);
        Path OCORGSRUXX = getDir(TestMultipleInputs.EBQXVODNHZ);
        Configuration HLPZWYLBWD = createJobConf();
        FileSystem BKONKBMUCY = FileSystem.get(HLPZWYLBWD);
        BKONKBMUCY.delete(OXRJHEIDYO, true);
        if (!BKONKBMUCY.mkdirs(JLUUUNZZUH)) {
            throw new IOException("Mkdirs failed to create " + JLUUUNZZUH.toString());
        }
        if (!BKONKBMUCY.mkdirs(OCORGSRUXX)) {
            throw new IOException("Mkdirs failed to create " + OCORGSRUXX.toString());
        }
    }

    @Test
    public void testDoMultipleInputs() throws IOException {
        Path ESDMYZIDPM = getDir(TestMultipleInputs.KAAPXXBTTT);
        Path YQDEYCFTQS = getDir(TestMultipleInputs.EBQXVODNHZ);
        Path SBGJIULBRP = getDir(TestMultipleInputs.ANVTLEIMTZ);
        Configuration UVDANHBJOJ = createJobConf();
        FileSystem KCKHADDFJE = FileSystem.get(UVDANHBJOJ);
        KCKHADDFJE.delete(SBGJIULBRP, true);
        DataOutputStream MBIVPQQYOJ = KCKHADDFJE.create(new Path(ESDMYZIDPM, "part-0"));
        MBIVPQQYOJ.writeBytes("a\nb\nc\nd\ne");
        MBIVPQQYOJ.close();
        // write tab delimited to second file because we're doing
        // KeyValueInputFormat
        DataOutputStream NXREKDBVOA = KCKHADDFJE.create(new Path(YQDEYCFTQS, "part-0"));
        NXREKDBVOA.writeBytes("a\tblah\nb\tblah\nc\tblah\nd\tblah\ne\tblah");
        NXREKDBVOA.close();
        Job HJQOPLXQZV = Job.getInstance(UVDANHBJOJ);
        HJQOPLXQZV.setJobName("mi");
        MultipleInputs.addInputPath(HJQOPLXQZV, ESDMYZIDPM, TextInputFormat.class, TestMultipleInputs.MapClass.class);
        MultipleInputs.addInputPath(HJQOPLXQZV, YQDEYCFTQS, KeyValueTextInputFormat.class, TestMultipleInputs.KeyValueMapClass.class);
        HJQOPLXQZV.setMapOutputKeyClass(Text.class);
        HJQOPLXQZV.setMapOutputValueClass(Text.class);
        HJQOPLXQZV.setOutputKeyClass(NullWritable.class);
        HJQOPLXQZV.setOutputValueClass(Text.class);
        HJQOPLXQZV.setReducerClass(TestMultipleInputs.ReducerClass.class);
        FileOutputFormat.setOutputPath(HJQOPLXQZV, SBGJIULBRP);
        boolean CDSUEMNJYP = false;
        try {
            CDSUEMNJYP = HJQOPLXQZV.waitForCompletion(true);
        } catch (InterruptedException ie) {
            throw new RuntimeException(ie);
        } catch (ClassNotFoundException instante) {
            throw new RuntimeException(instante);
        }
        if (!CDSUEMNJYP)
            throw new RuntimeException("Job failed!");

        // copy bytes a bunch of times for the ease of readLine() - whatever
        BufferedReader CDVLTDREMA = new BufferedReader(new InputStreamReader(KCKHADDFJE.open(new Path(SBGJIULBRP, "part-r-00000"))));
        // reducer should have counted one key from each file
        assertTrue(CDVLTDREMA.readLine().equals("a 2"));
        assertTrue(CDVLTDREMA.readLine().equals("b 2"));
        assertTrue(CDVLTDREMA.readLine().equals("c 2"));
        assertTrue(CDVLTDREMA.readLine().equals("d 2"));
        assertTrue(CDVLTDREMA.readLine().equals("e 2"));
    }

    @SuppressWarnings("unchecked")
    public void testAddInputPathWithFormat() throws IOException {
        final Job LUHZSQXYVJ = Job.getInstance();
        MultipleInputs.addInputPath(LUHZSQXYVJ, new Path("/foo"), TextInputFormat.class);
        MultipleInputs.addInputPath(LUHZSQXYVJ, new Path("/bar"), KeyValueTextInputFormat.class);
        final Map<Path, InputFormat> DCASGOJXPW = MultipleInputs.getInputFormatMap(LUHZSQXYVJ);
        assertEquals(TextInputFormat.class, DCASGOJXPW.get(new Path("/foo")).getClass());
        assertEquals(KeyValueTextInputFormat.class, DCASGOJXPW.get(new Path("/bar")).getClass());
    }

    @SuppressWarnings("unchecked")
    public void testAddInputPathWithMapper() throws IOException {
        final Job DEWETABVQE = Job.getInstance();
        MultipleInputs.addInputPath(DEWETABVQE, new Path("/foo"), TextInputFormat.class, TestMultipleInputs.MapClass.class);
        MultipleInputs.addInputPath(DEWETABVQE, new Path("/bar"), KeyValueTextInputFormat.class, TestMultipleInputs.KeyValueMapClass.class);
        final Map<Path, InputFormat> XENBFYYMDW = MultipleInputs.getInputFormatMap(DEWETABVQE);
        final Map<Path, Class<? extends Mapper>> RHSCQCLLKW = MultipleInputs.getMapperTypeMap(DEWETABVQE);
        assertEquals(TextInputFormat.class, XENBFYYMDW.get(new Path("/foo")).getClass());
        assertEquals(KeyValueTextInputFormat.class, XENBFYYMDW.get(new Path("/bar")).getClass());
        assertEquals(TestMultipleInputs.MapClass.class, RHSCQCLLKW.get(new Path("/foo")));
        assertEquals(TestMultipleInputs.KeyValueMapClass.class, RHSCQCLLKW.get(new Path("/bar")));
    }

    static final Text WJZNNFBWDE = new Text("blah");

    // these 3 classes do a reduce side join with 2 different mappers
    static class MapClass extends Mapper<LongWritable, Text, Text, Text> {
        // receives "a", "b", "c" as values
        @Override
        public void map(LongWritable key, Text value, Context ctx) throws IOException, InterruptedException {
            ctx.write(value, TestMultipleInputs.WJZNNFBWDE);
        }
    }

    static class KeyValueMapClass extends Mapper<Text, Text, Text, Text> {
        // receives "a", "b", "c" as keys
        @Override
        public void map(Text key, Text value, Context ctx) throws IOException, InterruptedException {
            ctx.write(key, TestMultipleInputs.WJZNNFBWDE);
        }
    }

    static class ReducerClass extends Reducer<Text, Text, NullWritable, Text> {
        // should receive 2 rows for each key
        int OWTZMXFIVA = 0;

        @Override
        public void reduce(Text key, Iterable<Text> values, Context ctx) throws IOException, InterruptedException {
            OWTZMXFIVA = 0;
            for (Text value : values)
                OWTZMXFIVA++;

            ctx.write(NullWritable.get(), new Text((key.toString() + " ") + OWTZMXFIVA));
        }
    }
}