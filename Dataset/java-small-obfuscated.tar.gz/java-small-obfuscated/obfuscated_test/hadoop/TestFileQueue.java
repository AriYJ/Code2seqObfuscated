public class TestFileQueue {
    static final Log ICJAGZENLH = LogFactory.getLog(TestFileQueue.class);

    static final int TUYYNCSROQ = 4;

    static final int TCYMKZJDTU = 256;

    static final Path[] MEJUKLRINB = new Path[TestFileQueue.TUYYNCSROQ];

    static final String[] TQAZLMZMIQ = new String[TestFileQueue.TUYYNCSROQ];

    static final long[] BOZXTLQHRI = new long[TestFileQueue.TUYYNCSROQ];

    static final long[] DHPYERGBPG = new long[TestFileQueue.TUYYNCSROQ];

    @BeforeClass
    public static void setup() throws IOException {
        final Configuration ZVNNMIVBKE = new Configuration();
        final FileSystem QXYVPIEJIV = FileSystem.getLocal(ZVNNMIVBKE).getRaw();
        final Path DBKHHXJCXK = new Path(System.getProperty("test.build.data", "/tmp"), "testFileQueue").makeQualified(QXYVPIEJIV);
        QXYVPIEJIV.delete(DBKHHXJCXK, true);
        final byte[] TJCWDXYTPB = new byte[TestFileQueue.TCYMKZJDTU];
        for (int PKYNUQIVAM = 0; PKYNUQIVAM < TestFileQueue.TUYYNCSROQ; ++PKYNUQIVAM) {
            Arrays.fill(TJCWDXYTPB, ((byte) ('A' + PKYNUQIVAM)));
            TestFileQueue.MEJUKLRINB[PKYNUQIVAM] = new Path(DBKHHXJCXK, "" + ((char) ('A' + PKYNUQIVAM)));
            OutputStream KJEINOHWMM = null;
            try {
                KJEINOHWMM = QXYVPIEJIV.create(TestFileQueue.MEJUKLRINB[PKYNUQIVAM]);
                KJEINOHWMM.write(TJCWDXYTPB);
            } finally {
                if (KJEINOHWMM != null) {
                    KJEINOHWMM.close();
                }
            }
        }
    }

    @AfterClass
    public static void cleanup() throws IOException {
        final Configuration WEHGIXIVIV = new Configuration();
        final FileSystem WHNQXAIVBZ = FileSystem.getLocal(WEHGIXIVIV).getRaw();
        final Path KLVGTDHKUF = new Path(System.getProperty("test.build.data", "/tmp"), "testFileQueue").makeQualified(WHNQXAIVBZ);
        WHNQXAIVBZ.delete(KLVGTDHKUF, true);
    }

    static ByteArrayOutputStream fillVerif() throws IOException {
        final byte[] YISTBKEULF = new byte[TestFileQueue.TCYMKZJDTU];
        final ByteArrayOutputStream EENBECFHTW = new ByteArrayOutputStream();
        for (int FYTXLOKUXF = 0; FYTXLOKUXF < TestFileQueue.TUYYNCSROQ; ++FYTXLOKUXF) {
            Arrays.fill(YISTBKEULF, ((byte) ('A' + FYTXLOKUXF)));
            EENBECFHTW.write(YISTBKEULF, 0, ((int) (TestFileQueue.DHPYERGBPG[FYTXLOKUXF])));
        }
        return EENBECFHTW;
    }

    @Test
    public void testRepeat() throws Exception {
        final Configuration EZANUNEQQS = new Configuration();
        Arrays.fill(TestFileQueue.TQAZLMZMIQ, "");
        Arrays.fill(TestFileQueue.BOZXTLQHRI, 0L);
        Arrays.fill(TestFileQueue.DHPYERGBPG, TestFileQueue.TCYMKZJDTU);
        final ByteArrayOutputStream KSPEYARRLL = TestFileQueue.fillVerif();
        final FileQueue WKZWGNUHIW = new FileQueue(new org.apache.hadoop.mapreduce.lib.input.CombineFileSplit(TestFileQueue.MEJUKLRINB, TestFileQueue.BOZXTLQHRI, TestFileQueue.DHPYERGBPG, TestFileQueue.TQAZLMZMIQ), EZANUNEQQS);
        final byte[] CAVUWCCEEY = KSPEYARRLL.toByteArray();
        final byte[] ZVPEZHUYPO = new byte[(2 * TestFileQueue.TUYYNCSROQ) * TestFileQueue.TCYMKZJDTU];
        WKZWGNUHIW.read(ZVPEZHUYPO, 0, TestFileQueue.TUYYNCSROQ * TestFileQueue.TCYMKZJDTU);
        assertArrayEquals(CAVUWCCEEY, Arrays.copyOf(ZVPEZHUYPO, TestFileQueue.TUYYNCSROQ * TestFileQueue.TCYMKZJDTU));
        final byte[] ALIQFFZFUV = new byte[(2 * TestFileQueue.TUYYNCSROQ) * TestFileQueue.TCYMKZJDTU];
        System.arraycopy(CAVUWCCEEY, 0, ALIQFFZFUV, 0, CAVUWCCEEY.length);
        System.arraycopy(CAVUWCCEEY, 0, ALIQFFZFUV, CAVUWCCEEY.length, CAVUWCCEEY.length);
        WKZWGNUHIW.read(ZVPEZHUYPO, 0, (2 * TestFileQueue.TUYYNCSROQ) * TestFileQueue.TCYMKZJDTU);
        assertArrayEquals(ALIQFFZFUV, ZVPEZHUYPO);
    }

    @Test
    public void testUneven() throws Exception {
        final Configuration PFRHBWUKOG = new Configuration();
        Arrays.fill(TestFileQueue.TQAZLMZMIQ, "");
        Arrays.fill(TestFileQueue.BOZXTLQHRI, 0L);
        Arrays.fill(TestFileQueue.DHPYERGBPG, TestFileQueue.TCYMKZJDTU);
        final int IRGHNALCRI = TestFileQueue.TCYMKZJDTU / 2;
        for (int OWNIXHZYXT = 0; OWNIXHZYXT < TestFileQueue.TUYYNCSROQ; OWNIXHZYXT += 2) {
            TestFileQueue.BOZXTLQHRI[OWNIXHZYXT] += IRGHNALCRI;
            TestFileQueue.DHPYERGBPG[OWNIXHZYXT] -= IRGHNALCRI;
        }
        final FileQueue KQEWZGDSEC = new FileQueue(new org.apache.hadoop.mapreduce.lib.input.CombineFileSplit(TestFileQueue.MEJUKLRINB, TestFileQueue.BOZXTLQHRI, TestFileQueue.DHPYERGBPG, TestFileQueue.TQAZLMZMIQ), PFRHBWUKOG);
        final ByteArrayOutputStream QDDQEEOPCI = TestFileQueue.fillVerif();
        final byte[] JBNACSGJBB = QDDQEEOPCI.toByteArray();
        final byte[] ZZZHVOGXCI = new byte[((TestFileQueue.TUYYNCSROQ / 2) * TestFileQueue.TCYMKZJDTU) + ((TestFileQueue.TUYYNCSROQ / 2) * IRGHNALCRI)];
        KQEWZGDSEC.read(ZZZHVOGXCI, 0, JBNACSGJBB.length);
        assertArrayEquals(JBNACSGJBB, Arrays.copyOf(ZZZHVOGXCI, JBNACSGJBB.length));
        KQEWZGDSEC.read(ZZZHVOGXCI, 0, JBNACSGJBB.length);
        assertArrayEquals(JBNACSGJBB, Arrays.copyOf(ZZZHVOGXCI, JBNACSGJBB.length));
    }

    @Test
    public void testEmpty() throws Exception {
        final Configuration VIDVPXDQXF = new Configuration();
        // verify OK if unused
        final FileQueue JWUMBPDGUM = new FileQueue(new org.apache.hadoop.mapreduce.lib.input.CombineFileSplit(new Path[0], new long[0], new long[0], new String[0]), VIDVPXDQXF);
    }
}