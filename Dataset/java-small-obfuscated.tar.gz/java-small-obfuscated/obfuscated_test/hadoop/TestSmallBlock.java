/**
 * This class tests the creation of files with block-size
 * smaller than the default buffer size of 4K.
 */
public class TestSmallBlock {
    static final long DLNSKZDDPW = 0xdeadbeefL;

    static final int UWTAGPEIJE = 1;

    static final int IFXLLYIWTK = 20;

    boolean ACIMYVIWAV = false;

    private void checkAndEraseData(byte[] NVVTXFEYCC, int WBRCDKIZQO, byte[] REFXUTNAGC, String IGCWEUNQHM) {
        for (int JPPBVFEBUP = 0; JPPBVFEBUP < NVVTXFEYCC.length; JPPBVFEBUP++) {
            assertEquals((((((IGCWEUNQHM + " byte ") + (WBRCDKIZQO + JPPBVFEBUP)) + " differs. expected ") + REFXUTNAGC[WBRCDKIZQO + JPPBVFEBUP]) + " actual ") + NVVTXFEYCC[JPPBVFEBUP], NVVTXFEYCC[JPPBVFEBUP], REFXUTNAGC[WBRCDKIZQO + JPPBVFEBUP]);
            NVVTXFEYCC[JPPBVFEBUP] = 0;
        }
    }

    private void checkFile(FileSystem IZHFFQZHNT, Path LLITVMJEXM) throws IOException {
        BlockLocation[] YXFMTARASU = IZHFFQZHNT.getFileBlockLocations(IZHFFQZHNT.getFileStatus(LLITVMJEXM), 0, TestSmallBlock.IFXLLYIWTK);
        assertEquals("Number of blocks", TestSmallBlock.IFXLLYIWTK, YXFMTARASU.length);
        FSDataInputStream IVNGFOVQDM = IZHFFQZHNT.open(LLITVMJEXM);
        byte[] TIZKCBDGWA = new byte[TestSmallBlock.IFXLLYIWTK];
        if (ACIMYVIWAV) {
            for (int WMPQSTXTIQ = 0; WMPQSTXTIQ < TIZKCBDGWA.length; ++WMPQSTXTIQ) {
                TIZKCBDGWA[WMPQSTXTIQ] = SimulatedFSDataset.DEFAULT_DATABYTE;
            }
        } else {
            Random JZMOZWMWJU = new Random(TestSmallBlock.DLNSKZDDPW);
            JZMOZWMWJU.nextBytes(TIZKCBDGWA);
        }
        // do a sanity check. Read the file
        byte[] FSYDFTNAIE = new byte[TestSmallBlock.IFXLLYIWTK];
        IVNGFOVQDM.readFully(0, FSYDFTNAIE);
        checkAndEraseData(FSYDFTNAIE, 0, TIZKCBDGWA, "Read Sanity Test");
        IVNGFOVQDM.close();
    }

    private void cleanupFile(FileSystem COXORMDQVQ, Path LMGNCVCHQO) throws IOException {
        assertTrue(COXORMDQVQ.exists(LMGNCVCHQO));
        COXORMDQVQ.delete(LMGNCVCHQO, true);
        assertTrue(!COXORMDQVQ.exists(LMGNCVCHQO));
    }

    /**
     * Tests small block size in in DFS.
     */
    @Test
    public void testSmallBlock() throws IOException {
        Configuration CJWQHZFIPO = new HdfsConfiguration();
        if (ACIMYVIWAV) {
            SimulatedFSDataset.setFactory(CJWQHZFIPO);
        }
        CJWQHZFIPO.set(DFS_BYTES_PER_CHECKSUM_KEY, "1");
        MiniDFSCluster PHFCYQGJKY = new MiniDFSCluster.Builder(CJWQHZFIPO).build();
        FileSystem NPJWJVLZDD = PHFCYQGJKY.getFileSystem();
        try {
            Path AKEQDJDMVS = new Path("smallblocktest.dat");
            DFSTestUtil.createFile(NPJWJVLZDD, AKEQDJDMVS, TestSmallBlock.IFXLLYIWTK, TestSmallBlock.IFXLLYIWTK, TestSmallBlock.UWTAGPEIJE, ((short) (1)), TestSmallBlock.DLNSKZDDPW);
            checkFile(NPJWJVLZDD, AKEQDJDMVS);
            cleanupFile(NPJWJVLZDD, AKEQDJDMVS);
        } finally {
            NPJWJVLZDD.close();
            PHFCYQGJKY.shutdown();
        }
    }

    @Test
    public void testSmallBlockSimulatedStorage() throws IOException {
        ACIMYVIWAV = true;
        testSmallBlock();
        ACIMYVIWAV = false;
    }
}