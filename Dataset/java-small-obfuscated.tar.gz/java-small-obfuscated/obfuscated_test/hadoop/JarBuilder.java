/**
 * This class is the main class for generating job.jar
 * for Hadoop Streaming jobs. It includes the files specified
 * with the -file option and includes them in the jar. Also,
 * hadoop-streaming is a user level appplication, so all the classes
 * with hadoop-streaming that are needed in the job are also included
 * in the job.jar.
 */
public class JarBuilder {
    public JarBuilder() {
    }

    public void setVerbose(boolean QONVTQJIZJ) {
        this.MRKAUNFDTT = QONVTQJIZJ;
    }

    public void merge(List CPXPOKWQMQ, List BVVGXMJQKW, String PTNLMJMURD) throws IOException {
        String UVXKXWTHLN = null;
        JarOutputStream BTXIPZUMNB = null;
        JarFile XQHTOQOUDA = null;
        BTXIPZUMNB = new JarOutputStream(new FileOutputStream(PTNLMJMURD));
        boolean QNUWUYKNSQ = false;
        try {
            if (CPXPOKWQMQ != null) {
                Iterator NDPTYPAXYM = CPXPOKWQMQ.iterator();
                while (NDPTYPAXYM.hasNext()) {
                    UVXKXWTHLN = ((String) (NDPTYPAXYM.next()));
                    File GTBKRGEAGP = new File(UVXKXWTHLN);
                    String DBDPLVLFLG = getBasePathInJarOut(UVXKXWTHLN);
                    if (!GTBKRGEAGP.exists()) {
                        QNUWUYKNSQ = true;
                        throw new FileNotFoundException(GTBKRGEAGP.getAbsolutePath());
                    }
                    if (GTBKRGEAGP.isDirectory()) {
                        addDirectory(BTXIPZUMNB, DBDPLVLFLG, GTBKRGEAGP, 0);
                    } else {
                        addFileStream(BTXIPZUMNB, DBDPLVLFLG, GTBKRGEAGP);
                    }
                } 
            }
            if (BVVGXMJQKW != null) {
                Iterator PGLXVADQHE = BVVGXMJQKW.iterator();
                while (PGLXVADQHE.hasNext()) {
                    UVXKXWTHLN = ((String) (PGLXVADQHE.next()));
                    XQHTOQOUDA = new JarFile(UVXKXWTHLN);
                    addJarEntries(BTXIPZUMNB, XQHTOQOUDA);
                    XQHTOQOUDA.close();
                } 
            }
        } finally {
            try {
                BTXIPZUMNB.close();
            } catch (ZipException z) {
                if (!QNUWUYKNSQ) {
                    throw new IOException(z.toString());
                }
            }
        }
    }

    protected String fileExtension(String PXJQHTEKSU) {
        int HHLOJMIATI = PXJQHTEKSU.lastIndexOf('/');
        if (HHLOJMIATI == (PXJQHTEKSU.length() - 1))
            return "";

        String EYRHOCZERA = PXJQHTEKSU.substring(HHLOJMIATI + 1);
        int QSKPKXRGZA = EYRHOCZERA.lastIndexOf('.');
        if (QSKPKXRGZA == (-1))
            return "";

        String OXJLNLTAYK = EYRHOCZERA.substring(QSKPKXRGZA + 1);
        return OXJLNLTAYK;
    }

    /**
     *
     *
     * @return empty or a jar base path. Must not start with '/'
     */
    protected String getBasePathInJarOut(String FLSBKIVPWN) {
        // TaskRunner will unjar and append to classpath: .:classes/:lib/*
        String YJDKEMGQER = fileExtension(FLSBKIVPWN);
        if (YJDKEMGQER.equals("class")) {
            return "classes/";// or ""

        } else
            if (YJDKEMGQER.equals("jar") || YJDKEMGQER.equals("zip")) {
                return "lib/";
            } else {
                return "";
            }

    }

    private void addJarEntries(JarOutputStream TYQIFSZWQY, JarFile YOGEPXAGGT) throws IOException {
        Enumeration OLQOUMVOJC = YOGEPXAGGT.entries();
        JarEntry UYVGKHNNWN = null;
        while (OLQOUMVOJC.hasMoreElements()) {
            UYVGKHNNWN = ((JarEntry) (OLQOUMVOJC.nextElement()));
            // if (entry.getName().startsWith("META-INF/")) continue;
            InputStream KTMVLEIFMV = YOGEPXAGGT.getInputStream(UYVGKHNNWN);
            addNamedStream(TYQIFSZWQY, UYVGKHNNWN.getName(), KTMVLEIFMV);
        } 
    }

    /**
     *
     *
     * @param name
     * 		path in jar for this jar element. Must not start with '/'
     */
    void addNamedStream(JarOutputStream YRSQFOSTRW, String VUWTDHEOPF, InputStream FAMLFUTRZA) throws IOException {
        if (MRKAUNFDTT) {
            System.err.println("JarBuilder.addNamedStream " + VUWTDHEOPF);
        }
        try {
            YRSQFOSTRW.putNextEntry(new JarEntry(VUWTDHEOPF));
            int QWZZFUEUND = 0;
            while ((QWZZFUEUND = FAMLFUTRZA.read(COYSQKJTXR, 0, JarBuilder.YYQXBQRIAZ)) != (-1)) {
                YRSQFOSTRW.write(COYSQKJTXR, 0, QWZZFUEUND);
            } 
        } catch (ZipException ze) {
            if (ze.getMessage().indexOf("duplicate entry") >= 0) {
                if (MRKAUNFDTT) {
                    System.err.println((ze + " Skip duplicate entry ") + VUWTDHEOPF);
                }
            } else {
                throw ze;
            }
        } finally {
            FAMLFUTRZA.close();
            YRSQFOSTRW.flush();
            YRSQFOSTRW.closeEntry();
        }
    }

    void addFileStream(JarOutputStream BDZPFNOYAT, String UFULAPAJNL, File UYWHCMUUUE) throws IOException {
        FileInputStream OQDPEHXZBR = new FileInputStream(UYWHCMUUUE);
        try {
            String ZMKYENMTIN = UFULAPAJNL + UYWHCMUUUE.getName();
            addNamedStream(BDZPFNOYAT, ZMKYENMTIN, OQDPEHXZBR);
        } finally {
            OQDPEHXZBR.close();
        }
    }

    void addDirectory(JarOutputStream XQFGKVFLRX, String KLGGBPSPAN, File BPOQVTCXRM, int ADNOFSABTS) throws IOException {
        File[] HGLEFXNAWX = BPOQVTCXRM.listFiles();
        if (HGLEFXNAWX != null) {
            for (int LOUHHJUYKF = 0; LOUHHJUYKF < HGLEFXNAWX.length; LOUHHJUYKF++) {
                File EMRAIBZPLZ = HGLEFXNAWX[LOUHHJUYKF];
                String YTTJXWEWUH = (ADNOFSABTS == 0) ? "" : BPOQVTCXRM.getName();
                if (KLGGBPSPAN.length() > 0) {
                    YTTJXWEWUH = (KLGGBPSPAN + "/") + YTTJXWEWUH;
                }
                if (EMRAIBZPLZ.isDirectory()) {
                    addDirectory(XQFGKVFLRX, YTTJXWEWUH, EMRAIBZPLZ, ADNOFSABTS + 1);
                } else {
                    addFileStream(XQFGKVFLRX, YTTJXWEWUH + "/", EMRAIBZPLZ);
                }
            }
        }
    }

    /**
     * Test program
     */
    public static void main(String[] LCTUQCIMYB) {
        // args = new String[] { "C:/Temp/merged.jar", "C:/jdk1.5.0/jre/lib/ext/dnsns.jar",  "/Temp/addtojar2.log", "C:/jdk1.5.0/jre/lib/ext/mtest.jar", "C:/Temp/base"};
        if (LCTUQCIMYB.length < 2) {
            System.err.println("Usage: JarFiles merged.jar [src.jar | dir | file ]+");
        } else {
            JarBuilder VKTJVEVICS = new JarBuilder();
            List KLBQZNLSEV = new ArrayList();
            List YPNFKHQFZB = new ArrayList();
            for (int LQMXKBFNEU = 1; LQMXKBFNEU < LCTUQCIMYB.length; LQMXKBFNEU++) {
                String CSZODTZTCM = LCTUQCIMYB[LQMXKBFNEU];
                String VPDDRJUKDJ = VKTJVEVICS.fileExtension(CSZODTZTCM);
                boolean OBWYPIVYRR = VPDDRJUKDJ.equals("jar") || VPDDRJUKDJ.equals("zip");
                if (OBWYPIVYRR) {
                    YPNFKHQFZB.add(CSZODTZTCM);
                } else {
                    KLBQZNLSEV.add(CSZODTZTCM);
                }
            }
            try {
                VKTJVEVICS.merge(KLBQZNLSEV, YPNFKHQFZB, LCTUQCIMYB[0]);
                Date YPPWYHJKKA = new Date(new File(LCTUQCIMYB[0]).lastModified());
                System.out.println((("Merge done to " + LCTUQCIMYB[0]) + " ") + YPPWYHJKKA);
            } catch (Exception ge) {
                ge.printStackTrace(System.err);
            }
        }
    }

    private static final int YYQXBQRIAZ = 32 * 1024;

    private byte[] COYSQKJTXR = new byte[JarBuilder.YYQXBQRIAZ];

    protected boolean MRKAUNFDTT = false;
}