/**
 * An ApplicationMaster for executing shell commands on a set of launched
 * containers using the YARN framework.
 *
 * <p>
 * This class is meant to act as an example on how to write yarn-based
 * application masters.
 * </p>
 *
 * <p>
 * The ApplicationMaster is started on a container by the
 * <code>ResourceManager</code>'s launcher. The first thing that the
 * <code>ApplicationMaster</code> needs to do is to connect and register itself
 * with the <code>ResourceManager</code>. The registration sets up information
 * within the <code>ResourceManager</code> regarding what host:port the
 * ApplicationMaster is listening on to provide any form of functionality to a
 * client as well as a tracking url that a client can use to keep track of
 * status/job history if needed. However, in the distributedshell, trackingurl
 * and appMasterHost:appMasterRpcPort are not supported.
 * </p>
 *
 * <p>
 * The <code>ApplicationMaster</code> needs to send a heartbeat to the
 * <code>ResourceManager</code> at regular intervals to inform the
 * <code>ResourceManager</code> that it is up and alive. The
 * {@link ApplicationMasterProtocol#allocate} to the <code>ResourceManager</code> from the
 * <code>ApplicationMaster</code> acts as a heartbeat.
 *
 * <p>
 * For the actual handling of the job, the <code>ApplicationMaster</code> has to
 * request the <code>ResourceManager</code> via {@link AllocateRequest} for the
 * required no. of containers using {@link ResourceRequest} with the necessary
 * resource specifications such as node location, computational
 * (memory/disk/cpu) resource requirements. The <code>ResourceManager</code>
 * responds with an {@link AllocateResponse} that informs the
 * <code>ApplicationMaster</code> of the set of newly allocated containers,
 * completed containers as well as current state of available resources.
 * </p>
 *
 * <p>
 * For each allocated container, the <code>ApplicationMaster</code> can then set
 * up the necessary launch context via {@link ContainerLaunchContext} to specify
 * the allocated container id, local resources required by the executable, the
 * environment to be setup for the executable, commands to execute, etc. and
 * submit a {@link StartContainerRequest} to the {@link ContainerManagementProtocol} to
 * launch and execute the defined commands on the given allocated container.
 * </p>
 *
 * <p>
 * The <code>ApplicationMaster</code> can monitor the launched container by
 * either querying the <code>ResourceManager</code> using
 * {@link ApplicationMasterProtocol#allocate} to get updates on completed containers or via
 * the {@link ContainerManagementProtocol} by querying for the status of the allocated
 * container's {@link ContainerId}.
 *
 * <p>
 * After the job has been completed, the <code>ApplicationMaster</code> has to
 * send a {@link FinishApplicationMasterRequest} to the
 * <code>ResourceManager</code> to inform it that the
 * <code>ApplicationMaster</code> has been completed.
 */
@InterfaceAudience.Public
@InterfaceStability.Unstable
public class ApplicationMaster {
    private static final Log JLCTWAWOJJ = LogFactory.getLog(ApplicationMaster.class);

    @VisibleForTesting
    @Private
    public static enum DSEvent {

        DS_APP_ATTEMPT_START,
        DS_APP_ATTEMPT_END,
        DS_CONTAINER_START,
        DS_CONTAINER_END;}

    @VisibleForTesting
    @Private
    public static enum DSEntity {

        DS_APP_ATTEMPT,
        DS_CONTAINER;}

    // Configuration
    private Configuration AMTRAFVDGJ;

    // Handle to communicate with the Resource Manager
    @SuppressWarnings("rawtypes")
    private AMRMClientAsync WHQBPGUAWH;

    // In both secure and non-secure modes, this points to the job-submitter.
    private UserGroupInformation TZMPCFHCKY;

    // Handle to communicate with the Node Manager
    private NMClientAsync LODCKRKLOY;

    // Listen to process the response from the Node Manager
    private ApplicationMaster.NMCallbackHandler HUHVAHFNKP;

    // Application Attempt Id ( combination of attemptId and fail count )
    @VisibleForTesting
    protected ApplicationAttemptId FOKWWRHVYH;

    // TODO
    // For status update for clients - yet to be implemented
    // Hostname of the container
    private String LTOAUQLMRJ = "";

    // Port on which the app master listens for status updates from clients
    private int QIYJZBADVZ = -1;

    // Tracking url to which app master publishes info for clients to monitor
    private String LHIPOFBGBR = "";

    // App Master configuration
    // No. of containers to run shell command on
    @VisibleForTesting
    protected int KYTQZQOELY = 1;

    // Memory to request for the container on which the shell command will run
    private int IMYEXYNCLR = 10;

    // VirtualCores to request for the container on which the shell command will run
    private int VWOXDYFMDE = 1;

    // Priority of the request
    private int XIGLWXGOYD;

    // Counter for completed containers ( complete denotes successful or failed )
    private AtomicInteger REFHKLCMVF = new AtomicInteger();

    // Allocated container count so that we know how many containers has the RM
    // allocated to us
    @VisibleForTesting
    protected AtomicInteger YWFQWIOSOP = new AtomicInteger();

    // Count of failed containers
    private AtomicInteger WUSIGYCWQE = new AtomicInteger();

    // Count of containers already requested from the RM
    // Needed as once requested, we should not request for containers again.
    // Only request for more if the original requirement changes.
    @VisibleForTesting
    protected AtomicInteger FCKVXYCMGQ = new AtomicInteger();

    // Shell command to be executed
    private String JKIUXZQNGH = "";

    // Args to be passed to the shell command
    private String QEWXZLXDPG = "";

    // Env variables to be setup for the shell command
    private Map<String, String> YQYBKALSMQ = new HashMap<String, String>();

    // Location of shell script ( obtained from info set in env )
    // Shell script path in fs
    private String VGAXMSPLNW = "";

    // Timestamp needed for creating a local resource
    private long JETAHWUXRG = 0;

    // File length needed for local resource
    private long URWJXJJEPZ = 0;

    // Hardcoded path to shell script in launch container's local env
    private static final String ATGPBHNEUG = Client.SCRIPT_PATH + ".sh";

    private static final String IEAGPHAZEU = Client.SCRIPT_PATH + ".bat";

    // Hardcoded path to custom log_properties
    private static final String HNVPBUKVAL = "log4j.properties";

    private static final String UEYKQCLBSV = "shellCommands";

    private static final String OILPLWMEJU = "shellArgs";

    private volatile boolean MGYVASKHKI;

    private ByteBuffer LJEFENIYAI;

    // Launch threads
    private List<Thread> ZOYEQZLOKT = new ArrayList<Thread>();

    // Timeline Client
    private TimelineClient HMVKHCKZSX;

    private final String NWGBIJQUCE = "bash";

    private final String KSMKFSMUFS = "cmd /c";

    /**
     *
     *
     * @param args
     * 		Command line args
     */
    public static void main(String[] PIYOJPZCRQ) {
        boolean GWHUSCHYAR = false;
        try {
            ApplicationMaster FNDQQIDEMF = new ApplicationMaster();
            ApplicationMaster.JLCTWAWOJJ.info("Initializing ApplicationMaster");
            boolean QWDYPCIESP = FNDQQIDEMF.init(PIYOJPZCRQ);
            if (!QWDYPCIESP) {
                System.exit(0);
            }
            FNDQQIDEMF.run();
            GWHUSCHYAR = FNDQQIDEMF.finish();
        } catch (Throwable t) {
            ApplicationMaster.JLCTWAWOJJ.fatal("Error running ApplicationMaster", t);
            LogManager.shutdown();
            ExitUtil.terminate(1, t);
        }
        if (GWHUSCHYAR) {
            ApplicationMaster.JLCTWAWOJJ.info("Application Master completed successfully. exiting");
            System.exit(0);
        } else {
            ApplicationMaster.JLCTWAWOJJ.info("Application Master failed. exiting");
            System.exit(2);
        }
    }

    /**
     * Dump out contents of $CWD and the environment to stdout for debugging
     */
    private void dumpOutDebugInfo() {
        ApplicationMaster.JLCTWAWOJJ.info("Dump debug output");
        Map<String, String> LTDUMLORVW = System.getenv();
        for (Map.Entry<String, String> ZILEYJZGES : LTDUMLORVW.entrySet()) {
            ApplicationMaster.JLCTWAWOJJ.info((("System env: key=" + ZILEYJZGES.getKey()) + ", val=") + ZILEYJZGES.getValue());
            System.out.println((("System env: key=" + ZILEYJZGES.getKey()) + ", val=") + ZILEYJZGES.getValue());
        }
        BufferedReader PFOYYGDNSC = null;
        try {
            String GZDRFBEZHE = (Shell.WINDOWS) ? Shell.execCommand("cmd", "/c", "dir") : Shell.execCommand("ls", "-al");
            PFOYYGDNSC = new BufferedReader(new StringReader(GZDRFBEZHE));
            String AFHIYQUSHB = "";
            while ((AFHIYQUSHB = PFOYYGDNSC.readLine()) != null) {
                ApplicationMaster.JLCTWAWOJJ.info("System CWD content: " + AFHIYQUSHB);
                System.out.println("System CWD content: " + AFHIYQUSHB);
            } 
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            IOUtils.cleanup(ApplicationMaster.JLCTWAWOJJ, PFOYYGDNSC);
        }
    }

    public ApplicationMaster() {
        // Set up the configuration
        AMTRAFVDGJ = new YarnConfiguration();
    }

    /**
     * Parse command line options
     *
     * @param args
     * 		Command line args
     * @return Whether init successful and run should be invoked
     * @throws ParseException
     * 		
     * @throws IOException
     * 		
     */
    public boolean init(String[] DASCWOUBXT) throws IOException, ParseException {
        Options APVAZIPJVJ = new Options();
        APVAZIPJVJ.addOption("app_attempt_id", true, "App Attempt ID. Not to be used unless for testing purposes");
        APVAZIPJVJ.addOption("shell_env", true, "Environment for shell script. Specified as env_key=env_val pairs");
        APVAZIPJVJ.addOption("container_memory", true, "Amount of memory in MB to be requested to run the shell command");
        APVAZIPJVJ.addOption("container_vcores", true, "Amount of virtual cores to be requested to run the shell command");
        APVAZIPJVJ.addOption("num_containers", true, "No. of containers on which the shell command needs to be executed");
        APVAZIPJVJ.addOption("priority", true, "Application Priority. Default 0");
        APVAZIPJVJ.addOption("debug", false, "Dump out debug information");
        APVAZIPJVJ.addOption("help", false, "Print usage");
        CommandLine SXOYKUTNZB = new GnuParser().parse(APVAZIPJVJ, DASCWOUBXT);
        if (DASCWOUBXT.length == 0) {
            printUsage(APVAZIPJVJ);
            throw new IllegalArgumentException("No args specified for application master to initialize");
        }
        // Check whether customer log4j.properties file exists
        if (fileExist(ApplicationMaster.HNVPBUKVAL)) {
            try {
                Log4jPropertyHelper.updateLog4jConfiguration(ApplicationMaster.class, ApplicationMaster.HNVPBUKVAL);
            } catch (Exception e) {
                ApplicationMaster.JLCTWAWOJJ.warn("Can not set up custom log4j properties. " + e);
            }
        }
        if (SXOYKUTNZB.hasOption("help")) {
            printUsage(APVAZIPJVJ);
            return false;
        }
        if (SXOYKUTNZB.hasOption("debug")) {
            dumpOutDebugInfo();
        }
        Map<String, String> XSIRTCHEHF = System.getenv();
        if (!XSIRTCHEHF.containsKey(CONTAINER_ID.name())) {
            if (SXOYKUTNZB.hasOption("app_attempt_id")) {
                String UWZFXCSQSH = SXOYKUTNZB.getOptionValue("app_attempt_id", "");
                FOKWWRHVYH = ConverterUtils.toApplicationAttemptId(UWZFXCSQSH);
            } else {
                throw new IllegalArgumentException("Application Attempt Id not set in the environment");
            }
        } else {
            ContainerId XKKQWEWQDE = ConverterUtils.toContainerId(XSIRTCHEHF.get(CONTAINER_ID.name()));
            FOKWWRHVYH = XKKQWEWQDE.getApplicationAttemptId();
        }
        if (!XSIRTCHEHF.containsKey(APP_SUBMIT_TIME_ENV)) {
            throw new RuntimeException(ApplicationConstants.APP_SUBMIT_TIME_ENV + " not set in the environment");
        }
        if (!XSIRTCHEHF.containsKey(NM_HOST.name())) {
            throw new RuntimeException(NM_HOST.name() + " not set in the environment");
        }
        if (!XSIRTCHEHF.containsKey(NM_HTTP_PORT.name())) {
            throw new RuntimeException(Environment.NM_HTTP_PORT + " not set in the environment");
        }
        if (!XSIRTCHEHF.containsKey(NM_PORT.name())) {
            throw new RuntimeException(NM_PORT.name() + " not set in the environment");
        }
        ApplicationMaster.JLCTWAWOJJ.info(((((("Application master for app" + ", appId=") + FOKWWRHVYH.getApplicationId().getId()) + ", clustertimestamp=") + FOKWWRHVYH.getApplicationId().getClusterTimestamp()) + ", attemptId=") + FOKWWRHVYH.getAttemptId());
        if ((!fileExist(ApplicationMaster.UEYKQCLBSV)) && XSIRTCHEHF.get(DISTRIBUTEDSHELLSCRIPTLOCATION).isEmpty()) {
            throw new IllegalArgumentException("No shell command or shell script specified to be executed by application master");
        }
        if (fileExist(ApplicationMaster.UEYKQCLBSV)) {
            JKIUXZQNGH = readContent(ApplicationMaster.UEYKQCLBSV);
        }
        if (fileExist(ApplicationMaster.OILPLWMEJU)) {
            QEWXZLXDPG = readContent(ApplicationMaster.OILPLWMEJU);
        }
        if (SXOYKUTNZB.hasOption("shell_env")) {
            String[] PXUFFDFIAH = SXOYKUTNZB.getOptionValues("shell_env");
            for (String PCRKFHCKOL : PXUFFDFIAH) {
                PCRKFHCKOL = PCRKFHCKOL.trim();
                int DSKDRMBQWA = PCRKFHCKOL.indexOf('=');
                if (DSKDRMBQWA == (-1)) {
                    YQYBKALSMQ.put(PCRKFHCKOL, "");
                    continue;
                }
                String PGDMIFUYMI = PCRKFHCKOL.substring(0, DSKDRMBQWA);
                String YMTQAKGTUB = "";
                if (DSKDRMBQWA < (PCRKFHCKOL.length() - 1)) {
                    YMTQAKGTUB = PCRKFHCKOL.substring(DSKDRMBQWA + 1);
                }
                YQYBKALSMQ.put(PGDMIFUYMI, YMTQAKGTUB);
            }
        }
        if (XSIRTCHEHF.containsKey(DISTRIBUTEDSHELLSCRIPTLOCATION)) {
            VGAXMSPLNW = XSIRTCHEHF.get(DISTRIBUTEDSHELLSCRIPTLOCATION);
            if (XSIRTCHEHF.containsKey(DISTRIBUTEDSHELLSCRIPTTIMESTAMP)) {
                JETAHWUXRG = Long.valueOf(XSIRTCHEHF.get(DISTRIBUTEDSHELLSCRIPTTIMESTAMP));
            }
            if (XSIRTCHEHF.containsKey(DISTRIBUTEDSHELLSCRIPTLEN)) {
                URWJXJJEPZ = Long.valueOf(XSIRTCHEHF.get(DISTRIBUTEDSHELLSCRIPTLEN));
            }
            if ((!VGAXMSPLNW.isEmpty()) && ((JETAHWUXRG <= 0) || (URWJXJJEPZ <= 0))) {
                ApplicationMaster.JLCTWAWOJJ.error(((((("Illegal values in env for shell script path" + ", path=") + VGAXMSPLNW) + ", len=") + URWJXJJEPZ) + ", timestamp=") + JETAHWUXRG);
                throw new IllegalArgumentException("Illegal values in env for shell script path");
            }
        }
        IMYEXYNCLR = Integer.parseInt(SXOYKUTNZB.getOptionValue("container_memory", "10"));
        VWOXDYFMDE = Integer.parseInt(SXOYKUTNZB.getOptionValue("container_vcores", "1"));
        KYTQZQOELY = Integer.parseInt(SXOYKUTNZB.getOptionValue("num_containers", "1"));
        if (KYTQZQOELY == 0) {
            throw new IllegalArgumentException("Cannot run distributed shell with no containers");
        }
        XIGLWXGOYD = Integer.parseInt(SXOYKUTNZB.getOptionValue("priority", "0"));
        // Creating the Timeline Client
        HMVKHCKZSX = TimelineClient.createTimelineClient();
        HMVKHCKZSX.init(AMTRAFVDGJ);
        HMVKHCKZSX.start();
        return true;
    }

    /**
     * Helper function to print usage
     *
     * @param opts
     * 		Parsed command line options
     */
    private void printUsage(Options QWRHRDCZJV) {
        new HelpFormatter().printHelp("ApplicationMaster", QWRHRDCZJV);
    }

    /**
     * Main run function for the application master
     *
     * @throws YarnException
     * 		
     * @throws IOException
     * 		
     */
    @SuppressWarnings({ "unchecked" })
    public void run() throws IOException, YarnException {
        ApplicationMaster.JLCTWAWOJJ.info("Starting ApplicationMaster");
        try {
            ApplicationMaster.publishApplicationAttemptEvent(HMVKHCKZSX, FOKWWRHVYH.toString(), ApplicationMaster.DSEvent.DS_APP_ATTEMPT_START);
        } catch (Exception e) {
            ApplicationMaster.JLCTWAWOJJ.error("App Attempt start event coud not be pulished for " + FOKWWRHVYH.toString(), e);
        }
        // Note: Credentials, Token, UserGroupInformation, DataOutputBuffer class
        // are marked as LimitedPrivate
        Credentials DFOCTOXTGO = UserGroupInformation.getCurrentUser().getCredentials();
        DataOutputBuffer CETBWGBLLA = new DataOutputBuffer();
        DFOCTOXTGO.writeTokenStorageToStream(CETBWGBLLA);
        // Now remove the AM->RM token so that containers cannot access it.
        Iterator<Token<?>> ZTPWDBSVJY = DFOCTOXTGO.getAllTokens().iterator();
        ApplicationMaster.JLCTWAWOJJ.info("Executing with tokens:");
        while (ZTPWDBSVJY.hasNext()) {
            Token<?> AFFSRHNCAQ = ZTPWDBSVJY.next();
            ApplicationMaster.JLCTWAWOJJ.info(AFFSRHNCAQ);
            if (AFFSRHNCAQ.getKind().equals(KIND_NAME)) {
                ZTPWDBSVJY.remove();
            }
        } 
        LJEFENIYAI = ByteBuffer.wrap(CETBWGBLLA.getData(), 0, CETBWGBLLA.getLength());
        // Create appSubmitterUgi and add original tokens to it
        String AEBGSZLYUK = System.getenv(USER.name());
        TZMPCFHCKY = UserGroupInformation.createRemoteUser(AEBGSZLYUK);
        TZMPCFHCKY.addCredentials(DFOCTOXTGO);
        AMRMClientAsync.CallbackHandler ABGGHROXSA = new ApplicationMaster.RMCallbackHandler();
        WHQBPGUAWH = AMRMClientAsync.createAMRMClientAsync(1000, ABGGHROXSA);
        WHQBPGUAWH.init(AMTRAFVDGJ);
        WHQBPGUAWH.start();
        HUHVAHFNKP = createNMCallbackHandler();
        LODCKRKLOY = new NMClientAsyncImpl(HUHVAHFNKP);
        LODCKRKLOY.init(AMTRAFVDGJ);
        LODCKRKLOY.start();
        // Setup local RPC Server to accept status requests directly from clients
        // TODO need to setup a protocol for client to be able to communicate to
        // the RPC server
        // TODO use the rpc port info to register with the RM for the client to
        // send requests to this app master
        // Register self with ResourceManager
        // This will start heartbeating to the RM
        LTOAUQLMRJ = NetUtils.getHostname();
        RegisterApplicationMasterResponse EOCFSEZHOR = WHQBPGUAWH.registerApplicationMaster(LTOAUQLMRJ, QIYJZBADVZ, LHIPOFBGBR);
        // Dump out information about cluster capability as seen by the
        // resource manager
        int YIGRRDCWKC = EOCFSEZHOR.getMaximumResourceCapability().getMemory();
        ApplicationMaster.JLCTWAWOJJ.info("Max mem capabililty of resources in this cluster " + YIGRRDCWKC);
        int ZFYIJYDIND = EOCFSEZHOR.getMaximumResourceCapability().getVirtualCores();
        ApplicationMaster.JLCTWAWOJJ.info("Max vcores capabililty of resources in this cluster " + ZFYIJYDIND);
        // A resource ask cannot exceed the max.
        if (IMYEXYNCLR > YIGRRDCWKC) {
            ApplicationMaster.JLCTWAWOJJ.info(((("Container memory specified above max threshold of cluster." + (" Using max value." + ", specified=")) + IMYEXYNCLR) + ", max=") + YIGRRDCWKC);
            IMYEXYNCLR = YIGRRDCWKC;
        }
        if (VWOXDYFMDE > ZFYIJYDIND) {
            ApplicationMaster.JLCTWAWOJJ.info(((("Container virtual cores specified above max threshold of cluster." + (" Using max value." + ", specified=")) + VWOXDYFMDE) + ", max=") + ZFYIJYDIND);
            VWOXDYFMDE = ZFYIJYDIND;
        }
        List<Container> DGOGWDZLNZ = EOCFSEZHOR.getContainersFromPreviousAttempts();
        ApplicationMaster.JLCTWAWOJJ.info(((FOKWWRHVYH + " received ") + DGOGWDZLNZ.size()) + " previous attempts' running containers on AM registration.");
        YWFQWIOSOP.addAndGet(DGOGWDZLNZ.size());
        int BRQPMGZJNY = KYTQZQOELY - DGOGWDZLNZ.size();
        // Setup ask for containers from RM
        // Send request for containers to RM
        // Until we get our fully allocated quota, we keep on polling RM for
        // containers
        // Keep looping until all the containers are launched and shell script
        // executed on them ( regardless of success/failure).
        for (int QNTEQUSAQZ = 0; QNTEQUSAQZ < BRQPMGZJNY; ++QNTEQUSAQZ) {
            ContainerRequest WATEJNUXRH = setupContainerAskForRM();
            WHQBPGUAWH.addContainerRequest(WATEJNUXRH);
        }
        FCKVXYCMGQ.set(KYTQZQOELY);
        try {
            ApplicationMaster.publishApplicationAttemptEvent(HMVKHCKZSX, FOKWWRHVYH.toString(), ApplicationMaster.DSEvent.DS_APP_ATTEMPT_END);
        } catch (Exception e) {
            ApplicationMaster.JLCTWAWOJJ.error("App Attempt start event coud not be pulished for " + FOKWWRHVYH.toString(), e);
        }
    }

    @VisibleForTesting
    ApplicationMaster.NMCallbackHandler createNMCallbackHandler() {
        return new ApplicationMaster.NMCallbackHandler(this);
    }

    @VisibleForTesting
    protected boolean finish() {
        // wait for completion.
        while ((!MGYVASKHKI) && (REFHKLCMVF.get() != KYTQZQOELY)) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException ex) {
            }
        } 
        // Join all launched threads
        // needed for when we time out
        // and we need to release containers
        for (Thread FMZXCBBSMC : ZOYEQZLOKT) {
            try {
                FMZXCBBSMC.join(10000);
            } catch (InterruptedException e) {
                ApplicationMaster.JLCTWAWOJJ.info("Exception thrown in thread join: " + e.getMessage());
                e.printStackTrace();
            }
        }
        // When the application completes, it should stop all running containers
        ApplicationMaster.JLCTWAWOJJ.info("Application completed. Stopping running containers");
        LODCKRKLOY.stop();
        // When the application completes, it should send a finish application
        // signal to the RM
        ApplicationMaster.JLCTWAWOJJ.info("Application completed. Signalling finish to RM");
        FinalApplicationStatus JSTZMDXRSY;
        String ITBZOTNOXL = null;
        boolean XETRZCOVRH = true;
        if ((WUSIGYCWQE.get() == 0) && (REFHKLCMVF.get() == KYTQZQOELY)) {
            JSTZMDXRSY = FinalApplicationStatus.SUCCEEDED;
        } else {
            JSTZMDXRSY = FinalApplicationStatus.FAILED;
            ITBZOTNOXL = ((((((("Diagnostics." + ", total=") + KYTQZQOELY) + ", completed=") + REFHKLCMVF.get()) + ", allocated=") + YWFQWIOSOP.get()) + ", failed=") + WUSIGYCWQE.get();
            XETRZCOVRH = false;
        }
        try {
            WHQBPGUAWH.unregisterApplicationMaster(JSTZMDXRSY, ITBZOTNOXL, null);
        } catch (YarnException ex) {
            ApplicationMaster.JLCTWAWOJJ.error("Failed to unregister application", ex);
        } catch (IOException e) {
            ApplicationMaster.JLCTWAWOJJ.error("Failed to unregister application", e);
        }
        WHQBPGUAWH.stop();
        return XETRZCOVRH;
    }

    private class RMCallbackHandler implements AMRMClientAsync.CallbackHandler {
        @SuppressWarnings("unchecked")
        @Override
        public void onContainersCompleted(List<ContainerStatus> completedContainers) {
            ApplicationMaster.JLCTWAWOJJ.info("Got response from RM for container ask, completedCnt=" + completedContainers.size());
            for (ContainerStatus containerStatus : completedContainers) {
                ApplicationMaster.JLCTWAWOJJ.info((((((((FOKWWRHVYH + " got container status for containerID=") + containerStatus.getContainerId()) + ", state=") + containerStatus.getState()) + ", exitStatus=") + containerStatus.getExitStatus()) + ", diagnostics=") + containerStatus.getDiagnostics());
                // non complete containers should not be here
                assert containerStatus.getState() == ContainerState.COMPLETE;
                // increment counters for completed/failed containers
                int exitStatus = containerStatus.getExitStatus();
                if (0 != exitStatus) {
                    // container failed
                    if (ContainerExitStatus.ABORTED != exitStatus) {
                        // shell script failed
                        // counts as completed
                        REFHKLCMVF.incrementAndGet();
                        WUSIGYCWQE.incrementAndGet();
                    } else {
                        // container was killed by framework, possibly preempted
                        // we should re-try as the container was lost for some reason
                        YWFQWIOSOP.decrementAndGet();
                        FCKVXYCMGQ.decrementAndGet();
                        // we do not need to release the container as it would be done
                        // by the RM
                    }
                } else {
                    // nothing to do
                    // container completed successfully
                    REFHKLCMVF.incrementAndGet();
                    ApplicationMaster.JLCTWAWOJJ.info(("Container completed successfully." + ", containerId=") + containerStatus.getContainerId());
                }
                try {
                    ApplicationMaster.publishContainerEndEvent(HMVKHCKZSX, containerStatus);
                } catch (Exception e) {
                    ApplicationMaster.JLCTWAWOJJ.error("Container start event could not be pulished for " + containerStatus.getContainerId().toString(), e);
                }
            }
            // ask for more containers if any failed
            int askCount = KYTQZQOELY - FCKVXYCMGQ.get();
            FCKVXYCMGQ.addAndGet(askCount);
            if (askCount > 0) {
                for (int i = 0; i < askCount; ++i) {
                    ContainerRequest containerAsk = setupContainerAskForRM();
                    WHQBPGUAWH.addContainerRequest(containerAsk);
                }
            }
            if (REFHKLCMVF.get() == KYTQZQOELY) {
                MGYVASKHKI = true;
            }
        }

        @Override
        public void onContainersAllocated(List<Container> allocatedContainers) {
            ApplicationMaster.JLCTWAWOJJ.info("Got response from RM for container ask, allocatedCnt=" + allocatedContainers.size());
            YWFQWIOSOP.addAndGet(allocatedContainers.size());
            for (Container allocatedContainer : allocatedContainers) {
                ApplicationMaster.JLCTWAWOJJ.info(((((((((((("Launching shell command on a new container." + ", containerId=") + allocatedContainer.getId()) + ", containerNode=") + allocatedContainer.getNodeId().getHost()) + ":") + allocatedContainer.getNodeId().getPort()) + ", containerNodeURI=") + allocatedContainer.getNodeHttpAddress()) + ", containerResourceMemory") + allocatedContainer.getResource().getMemory()) + ", containerResourceVirtualCores") + allocatedContainer.getResource().getVirtualCores());
                // + ", containerToken"
                // +allocatedContainer.getContainerToken().getIdentifier().toString());
                ApplicationMaster.LaunchContainerRunnable runnableLaunchContainer = new ApplicationMaster.LaunchContainerRunnable(allocatedContainer, HUHVAHFNKP);
                Thread launchThread = new Thread(runnableLaunchContainer);
                // launch and start the container on a separate thread to keep
                // the main thread unblocked
                // as all containers may not be allocated at one go.
                ZOYEQZLOKT.add(launchThread);
                launchThread.start();
            }
        }

        @Override
        public void onShutdownRequest() {
            MGYVASKHKI = true;
        }

        @Override
        public void onNodesUpdated(List<NodeReport> updatedNodes) {
        }

        @Override
        public float getProgress() {
            // set progress to deliver to RM on next heartbeat
            float progress = ((float) (REFHKLCMVF.get())) / KYTQZQOELY;
            return progress;
        }

        @Override
        public void onError(Throwable e) {
            MGYVASKHKI = true;
            WHQBPGUAWH.stop();
        }
    }

    @VisibleForTesting
    static class NMCallbackHandler implements NMClientAsync.CallbackHandler {
        private ConcurrentMap<ContainerId, Container> UXNYDSGWFZ = new ConcurrentHashMap<ContainerId, Container>();

        private final ApplicationMaster ZTFHYVOAQS;

        public NMCallbackHandler(ApplicationMaster applicationMaster) {
            this.ZTFHYVOAQS = applicationMaster;
        }

        public void addContainer(ContainerId containerId, Container container) {
            UXNYDSGWFZ.putIfAbsent(containerId, container);
        }

        @Override
        public void onContainerStopped(ContainerId containerId) {
            if (ApplicationMaster.JLCTWAWOJJ.isDebugEnabled()) {
                ApplicationMaster.JLCTWAWOJJ.debug("Succeeded to stop Container " + containerId);
            }
            UXNYDSGWFZ.remove(containerId);
        }

        @Override
        public void onContainerStatusReceived(ContainerId containerId, ContainerStatus containerStatus) {
            if (ApplicationMaster.JLCTWAWOJJ.isDebugEnabled()) {
                ApplicationMaster.JLCTWAWOJJ.debug((("Container Status: id=" + containerId) + ", status=") + containerStatus);
            }
        }

        @Override
        public void onContainerStarted(ContainerId containerId, Map<String, ByteBuffer> allServiceResponse) {
            if (ApplicationMaster.JLCTWAWOJJ.isDebugEnabled()) {
                ApplicationMaster.JLCTWAWOJJ.debug("Succeeded to start Container " + containerId);
            }
            Container container = UXNYDSGWFZ.get(containerId);
            if (container != null) {
                ZTFHYVOAQS.LODCKRKLOY.getContainerStatusAsync(containerId, container.getNodeId());
            }
            try {
                ApplicationMaster.publishContainerStartEvent(ZTFHYVOAQS.HMVKHCKZSX, container);
            } catch (Exception e) {
                ApplicationMaster.JLCTWAWOJJ.error("Container start event coud not be pulished for " + container.getId().toString(), e);
            }
        }

        @Override
        public void onStartContainerError(ContainerId containerId, Throwable t) {
            ApplicationMaster.JLCTWAWOJJ.error("Failed to start Container " + containerId);
            UXNYDSGWFZ.remove(containerId);
            ZTFHYVOAQS.REFHKLCMVF.incrementAndGet();
            ZTFHYVOAQS.WUSIGYCWQE.incrementAndGet();
        }

        @Override
        public void onGetContainerStatusError(ContainerId containerId, Throwable t) {
            ApplicationMaster.JLCTWAWOJJ.error("Failed to query the status of Container " + containerId);
        }

        @Override
        public void onStopContainerError(ContainerId containerId, Throwable t) {
            ApplicationMaster.JLCTWAWOJJ.error("Failed to stop Container " + containerId);
            UXNYDSGWFZ.remove(containerId);
        }
    }

    /**
     * Thread to connect to the {@link ContainerManagementProtocol} and launch the container
     * that will execute the shell command.
     */
    private class LaunchContainerRunnable implements Runnable {
        // Allocated container
        Container JPTWIQMNKS;

        ApplicationMaster.NMCallbackHandler WQOHTZLZHE;

        /**
         *
         *
         * @param lcontainer
         * 		Allocated container
         * @param containerListener
         * 		Callback handler of the container
         */
        public LaunchContainerRunnable(Container lcontainer, ApplicationMaster.NMCallbackHandler containerListener) {
            this.JPTWIQMNKS = lcontainer;
            this.WQOHTZLZHE = containerListener;
        }

        /**
         * Connects to CM, sets up container launch context
         * for shell command and eventually dispatches the container
         * start request to the CM.
         */
        @Override
        public void run() {
            ApplicationMaster.JLCTWAWOJJ.info("Setting up container launch container for containerid=" + JPTWIQMNKS.getId());
            // Set the local resources
            Map<String, LocalResource> localResources = new HashMap<String, LocalResource>();
            // The container for the eventual shell commands needs its own local
            // resources too.
            // In this scenario, if a shell script is specified, we need to have it
            // copied and made available to the container.
            if (!VGAXMSPLNW.isEmpty()) {
                Path renamedScriptPath = null;
                if (Shell.WINDOWS) {
                    renamedScriptPath = new Path(VGAXMSPLNW + ".bat");
                } else {
                    renamedScriptPath = new Path(VGAXMSPLNW + ".sh");
                }
                try {
                    // rename the script file based on the underlying OS syntax.
                    renameScriptFile(renamedScriptPath);
                } catch (Exception e) {
                    ApplicationMaster.JLCTWAWOJJ.error("Not able to add suffix (.bat/.sh) to the shell script filename", e);
                    // We know we cannot continue launching the container
                    // so we should release it.
                    REFHKLCMVF.incrementAndGet();
                    WUSIGYCWQE.incrementAndGet();
                    return;
                }
                URL yarnUrl = null;
                try {
                    yarnUrl = ConverterUtils.getYarnUrlFromURI(new URI(renamedScriptPath.toString()));
                } catch (URISyntaxException e) {
                    ApplicationMaster.JLCTWAWOJJ.error(("Error when trying to use shell script path specified" + " in env, path=") + renamedScriptPath, e);
                    // A failure scenario on bad input such as invalid shell script path
                    // We know we cannot continue launching the container
                    // so we should release it.
                    // TODO
                    REFHKLCMVF.incrementAndGet();
                    WUSIGYCWQE.incrementAndGet();
                    return;
                }
                LocalResource shellRsrc = LocalResource.newInstance(yarnUrl, FILE, APPLICATION, URWJXJJEPZ, JETAHWUXRG);
                localResources.put(Shell.WINDOWS ? ApplicationMaster.IEAGPHAZEU : ApplicationMaster.ATGPBHNEUG, shellRsrc);
                JKIUXZQNGH = (Shell.WINDOWS) ? KSMKFSMUFS : NWGBIJQUCE;
            }
            // Set the necessary command to execute on the allocated container
            Vector<CharSequence> vargs = new Vector<CharSequence>(5);
            // Set executable command
            vargs.add(JKIUXZQNGH);
            // Set shell script path
            if (!VGAXMSPLNW.isEmpty()) {
                vargs.add(Shell.WINDOWS ? ApplicationMaster.IEAGPHAZEU : ApplicationMaster.ATGPBHNEUG);
            }
            // Set args for the shell command if any
            vargs.add(QEWXZLXDPG);
            // Add log redirect params
            vargs.add(("1>" + ApplicationConstants.LOG_DIR_EXPANSION_VAR) + "/stdout");
            vargs.add(("2>" + ApplicationConstants.LOG_DIR_EXPANSION_VAR) + "/stderr");
            // Get final commmand
            StringBuilder command = new StringBuilder();
            for (CharSequence str : vargs) {
                command.append(str).append(" ");
            }
            List<String> commands = new ArrayList<String>();
            commands.add(command.toString());
            // Set up ContainerLaunchContext, setting local resource, environment,
            // command and token for constructor.
            // Note for tokens: Set up tokens for the container too. Today, for normal
            // shell commands, the container in distribute-shell doesn't need any
            // tokens. We are populating them mainly for NodeManagers to be able to
            // download anyfiles in the distributed file-system. The tokens are
            // otherwise also useful in cases, for e.g., when one is running a
            // "hadoop dfs" command inside the distributed shell.
            ContainerLaunchContext ctx = ContainerLaunchContext.newInstance(localResources, YQYBKALSMQ, commands, null, LJEFENIYAI.duplicate(), null);
            WQOHTZLZHE.addContainer(JPTWIQMNKS.getId(), JPTWIQMNKS);
            LODCKRKLOY.startContainerAsync(JPTWIQMNKS, ctx);
        }
    }

    private void renameScriptFile(final Path RNKTQTHXUF) throws IOException, InterruptedException {
        TZMPCFHCKY.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws IOException {
                FileSystem JKZPWVYRZY = RNKTQTHXUF.getFileSystem(AMTRAFVDGJ);
                JKZPWVYRZY.rename(new Path(VGAXMSPLNW), RNKTQTHXUF);
                return null;
            }
        });
        ApplicationMaster.JLCTWAWOJJ.info((("User " + TZMPCFHCKY.getUserName()) + " added suffix(.sh/.bat) to script file as ") + RNKTQTHXUF);
    }

    /**
     * Setup the request that will be sent to the RM for the container ask.
     *
     * @return the setup ResourceRequest to be sent to RM
     */
    private ContainerRequest setupContainerAskForRM() {
        // setup requirements for hosts
        // using * as any host will do for the distributed shell app
        // set the priority for the request
        // TODO - what is the range for priority? how to decide?
        Priority FSMBSDIYGY = Priority.newInstance(XIGLWXGOYD);
        // Set up resource type requirements
        // For now, memory and CPU are supported so we set memory and cpu requirements
        Resource AJEZHVZFYQ = Resource.newInstance(IMYEXYNCLR, VWOXDYFMDE);
        ContainerRequest VXMHWCBTER = new ContainerRequest(AJEZHVZFYQ, null, null, FSMBSDIYGY);
        ApplicationMaster.JLCTWAWOJJ.info("Requested container ask: " + VXMHWCBTER.toString());
        return VXMHWCBTER;
    }

    private boolean fileExist(String ZNNCQLURSB) {
        return new File(ZNNCQLURSB).exists();
    }

    private String readContent(String HEXKOJCZAN) throws IOException {
        DataInputStream IPFTUDWLAK = null;
        try {
            IPFTUDWLAK = new DataInputStream(new FileInputStream(HEXKOJCZAN));
            return IPFTUDWLAK.readUTF();
        } finally {
            org.apache.commons.io.IOUtils.closeQuietly(IPFTUDWLAK);
        }
    }

    private static void publishContainerStartEvent(TimelineClient NGTRYUCAAQ, Container VVJJREGNTQ) throws IOException, YarnException {
        TimelineEntity JFHVSSUPAM = new TimelineEntity();
        JFHVSSUPAM.setEntityId(VVJJREGNTQ.getId().toString());
        JFHVSSUPAM.setEntityType(ApplicationMaster.DSEntity.DS_CONTAINER.toString());
        JFHVSSUPAM.addPrimaryFilter("user", UserGroupInformation.getCurrentUser().getShortUserName());
        TimelineEvent FCOUXKZLDH = new TimelineEvent();
        FCOUXKZLDH.setTimestamp(System.currentTimeMillis());
        FCOUXKZLDH.setEventType(ApplicationMaster.DSEvent.DS_CONTAINER_START.toString());
        FCOUXKZLDH.addEventInfo("Node", VVJJREGNTQ.getNodeId().toString());
        FCOUXKZLDH.addEventInfo("Resources", VVJJREGNTQ.getResource().toString());
        JFHVSSUPAM.addEvent(FCOUXKZLDH);
        NGTRYUCAAQ.putEntities(JFHVSSUPAM);
    }

    private static void publishContainerEndEvent(TimelineClient NRWFKSTEUQ, ContainerStatus EAEQIZHPPD) throws IOException, YarnException {
        TimelineEntity TRUWDHVVNL = new TimelineEntity();
        TRUWDHVVNL.setEntityId(EAEQIZHPPD.getContainerId().toString());
        TRUWDHVVNL.setEntityType(ApplicationMaster.DSEntity.DS_CONTAINER.toString());
        TRUWDHVVNL.addPrimaryFilter("user", UserGroupInformation.getCurrentUser().getShortUserName());
        TimelineEvent RCKYPVNVSZ = new TimelineEvent();
        RCKYPVNVSZ.setTimestamp(System.currentTimeMillis());
        RCKYPVNVSZ.setEventType(ApplicationMaster.DSEvent.DS_CONTAINER_END.toString());
        RCKYPVNVSZ.addEventInfo("State", EAEQIZHPPD.getState().name());
        RCKYPVNVSZ.addEventInfo("Exit Status", EAEQIZHPPD.getExitStatus());
        TRUWDHVVNL.addEvent(RCKYPVNVSZ);
        NRWFKSTEUQ.putEntities(TRUWDHVVNL);
    }

    private static void publishApplicationAttemptEvent(TimelineClient GBDDNCEMTY, String HIPIKHDHSX, ApplicationMaster.DSEvent COFJGVAZBV) throws IOException, YarnException {
        TimelineEntity QLSYCOKLHC = new TimelineEntity();
        QLSYCOKLHC.setEntityId(HIPIKHDHSX);
        QLSYCOKLHC.setEntityType(ApplicationMaster.DSEntity.DS_APP_ATTEMPT.toString());
        QLSYCOKLHC.addPrimaryFilter("user", UserGroupInformation.getCurrentUser().getShortUserName());
        TimelineEvent BTHETERAFP = new TimelineEvent();
        BTHETERAFP.setEventType(COFJGVAZBV.toString());
        BTHETERAFP.setTimestamp(System.currentTimeMillis());
        QLSYCOKLHC.addEvent(BTHETERAFP);
        GBDDNCEMTY.putEntities(QLSYCOKLHC);
    }
}