/**
 * Interface that represents the over the wire information
 * including block locations for a file.
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public class HdfsLocatedFileStatus extends HdfsFileStatus {
    private final LocatedBlocks UGVXOFXJBE;

    /**
     * Constructor
     *
     * @param length
     * 		size
     * @param isdir
     * 		if this is directory
     * @param block_replication
     * 		the file's replication factor
     * @param blocksize
     * 		the file's block size
     * @param modification_time
     * 		most recent modification time
     * @param access_time
     * 		most recent access time
     * @param permission
     * 		permission
     * @param owner
     * 		owner
     * @param group
     * 		group
     * @param symlink
     * 		symbolic link
     * @param path
     * 		local path name in java UTF8 format
     * @param fileId
     * 		the file id
     * @param locations
     * 		block locations
     * @param feInfo
     * 		file encryption info
     */
    public HdfsLocatedFileStatus(long DHKLZEHVSY, boolean AVGQQKOBDO, int RLQZLCCXEJ, long UEXPWUWBYE, long NTHRQUKROL, long ZJMNLIPWMJ, FsPermission HVUWJZUDVI, String GGONTTFVPZ, String GIQHPQFAFB, byte[] GEVZKKSNAI, byte[] NVYWBPKPOM, long OBSWQQNVRS, LocatedBlocks AZEYRUCTIF, int MNCBNDWHVP, FileEncryptionInfo DZKMBASTBP) {
        super(DHKLZEHVSY, AVGQQKOBDO, RLQZLCCXEJ, UEXPWUWBYE, NTHRQUKROL, ZJMNLIPWMJ, HVUWJZUDVI, GGONTTFVPZ, GIQHPQFAFB, GEVZKKSNAI, NVYWBPKPOM, OBSWQQNVRS, MNCBNDWHVP, DZKMBASTBP);
        this.UGVXOFXJBE = AZEYRUCTIF;
    }

    public LocatedBlocks getBlockLocations() {
        return UGVXOFXJBE;
    }

    public final LocatedFileStatus makeQualifiedLocated(URI GSYRPAKODN, Path COQANVWAMT) {
        return // fully-qualify path
        new LocatedFileStatus(getLen(), isDir(), getReplication(), getBlockSize(), getModificationTime(), getAccessTime(), getPermission(), getOwner(), getGroup(), isSymlink() ? new Path(getSymlink()) : null, getFullPath(COQANVWAMT).makeQualified(GSYRPAKODN, null), DFSUtil.locatedBlocks2Locations(getBlockLocations()));
    }
}