/**
 * <p>
 * <code>ContainerReport</code> is a report of an container.
 * </p>
 *
 * <p>
 * It includes details such as:
 * <ul>
 * <li>{@link ContainerId} of the container.</li>
 * <li>Allocated Resources to the container.</li>
 * <li>Assigned Node id.</li>
 * <li>Assigned Priority.</li>
 * <li>Creation Time.</li>
 * <li>Finish Time.</li>
 * <li>Container Exit Status.</li>
 * <li>{@link ContainerState} of the container.</li>
 * <li>Diagnostic information in case of errors.</li>
 * <li>Log URL.</li>
 * </ul>
 * </p>
 */
@Public
@Unstable
public abstract class ContainerReport {
    @Private
    @Unstable
    public static ContainerReport newInstance(ContainerId XNILECUYZY, Resource EGURXWWKNL, NodeId DFGHVPZBNF, Priority WIFROKRRUM, long LIDELAWASO, long VDDDIKAWFL, String TYSADADFML, String CHHITVXARU, int PASKVNSXQK, ContainerState RMLYMXISUF) {
        ContainerReport OBLCQFYHMG = Records.newRecord(ContainerReport.class);
        OBLCQFYHMG.setContainerId(XNILECUYZY);
        OBLCQFYHMG.setAllocatedResource(EGURXWWKNL);
        OBLCQFYHMG.setAssignedNode(DFGHVPZBNF);
        OBLCQFYHMG.setPriority(WIFROKRRUM);
        OBLCQFYHMG.setCreationTime(LIDELAWASO);
        OBLCQFYHMG.setFinishTime(VDDDIKAWFL);
        OBLCQFYHMG.setDiagnosticsInfo(TYSADADFML);
        OBLCQFYHMG.setLogUrl(CHHITVXARU);
        OBLCQFYHMG.setContainerExitStatus(PASKVNSXQK);
        OBLCQFYHMG.setContainerState(RMLYMXISUF);
        return OBLCQFYHMG;
    }

    /**
     * Get the <code>ContainerId</code> of the container.
     *
     * @return <code>ContainerId</code> of the container.
     */
    @Public
    @Unstable
    public abstract ContainerId getContainerId();

    @Public
    @Unstable
    public abstract void setContainerId(ContainerId KGUABPLAJK);

    /**
     * Get the allocated <code>Resource</code> of the container.
     *
     * @return allocated <code>Resource</code> of the container.
     */
    @Public
    @Unstable
    public abstract Resource getAllocatedResource();

    @Public
    @Unstable
    public abstract void setAllocatedResource(Resource CNYUHBDOHX);

    /**
     * Get the allocated <code>NodeId</code> where container is running.
     *
     * @return allocated <code>NodeId</code> where container is running.
     */
    @Public
    @Unstable
    public abstract NodeId getAssignedNode();

    @Public
    @Unstable
    public abstract void setAssignedNode(NodeId UNZKYOGPWD);

    /**
     * Get the allocated <code>Priority</code> of the container.
     *
     * @return allocated <code>Priority</code> of the container.
     */
    @Public
    @Unstable
    public abstract Priority getPriority();

    @Public
    @Unstable
    public abstract void setPriority(Priority JNSWGWRKVH);

    /**
     * Get the creation time of the container.
     *
     * @return creation time of the container
     */
    @Public
    @Unstable
    public abstract long getCreationTime();

    @Public
    @Unstable
    public abstract void setCreationTime(long JWLSFBZCAM);

    /**
     * Get the Finish time of the container.
     *
     * @return Finish time of the container
     */
    @Public
    @Unstable
    public abstract long getFinishTime();

    @Public
    @Unstable
    public abstract void setFinishTime(long HDXNPBTOVT);

    /**
     * Get the DiagnosticsInfo of the container.
     *
     * @return DiagnosticsInfo of the container
     */
    @Public
    @Unstable
    public abstract String getDiagnosticsInfo();

    @Public
    @Unstable
    public abstract void setDiagnosticsInfo(String AGQKFOBIMO);

    /**
     * Get the LogURL of the container.
     *
     * @return LogURL of the container
     */
    @Public
    @Unstable
    public abstract String getLogUrl();

    @Public
    @Unstable
    public abstract void setLogUrl(String INWJDDTJBP);

    /**
     * Get the final <code>ContainerState</code> of the container.
     *
     * @return final <code>ContainerState</code> of the container.
     */
    @Public
    @Unstable
    public abstract ContainerState getContainerState();

    @Public
    @Unstable
    public abstract void setContainerState(ContainerState APTHVCMCDF);

    /**
     * Get the final <code>exit status</code> of the container.
     *
     * @return final <code>exit status</code> of the container.
     */
    @Public
    @Unstable
    public abstract int getContainerExitStatus();

    @Public
    @Unstable
    public abstract void setContainerExitStatus(int JIEXIKQNHR);
}