public class TaskRecoverEvent extends TaskEvent {
    private TaskInfo OKNYTFQBNW;

    private OutputCommitter MVSPXKAPKT;

    private boolean TZLUGZEMIF;

    public TaskRecoverEvent(TaskId KXNBAPNZDV, TaskInfo BAZFBAQMTF, OutputCommitter AEBEUQEHGY, boolean HPLUUTCVXD) {
        super(KXNBAPNZDV, T_RECOVER);
        this.OKNYTFQBNW = BAZFBAQMTF;
        this.MVSPXKAPKT = AEBEUQEHGY;
        this.TZLUGZEMIF = HPLUUTCVXD;
    }

    public TaskInfo getTaskInfo() {
        return OKNYTFQBNW;
    }

    public OutputCommitter getOutputCommitter() {
        return MVSPXKAPKT;
    }

    public boolean getRecoverTaskOutput() {
        return TZLUGZEMIF;
    }
}