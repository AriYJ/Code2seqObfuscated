public class GetContainersRequestPBImpl extends GetContainersRequest {
    GetContainersRequestProto HXTSRAORUD = GetContainersRequestProto.getDefaultInstance();

    Builder TPPQACSULQ = null;

    boolean HJIPLMRICQ = false;

    private ApplicationAttemptId HRUNTOJCJX = null;

    public GetContainersRequestPBImpl() {
        TPPQACSULQ = GetContainersRequestProto.newBuilder();
    }

    public GetContainersRequestPBImpl(GetContainersRequestProto WWAFPHDVTB) {
        this.HXTSRAORUD = WWAFPHDVTB;
        HJIPLMRICQ = true;
    }

    public GetContainersRequestProto getProto() {
        mergeLocalToProto();
        HXTSRAORUD = (HJIPLMRICQ) ? HXTSRAORUD : TPPQACSULQ.build();
        HJIPLMRICQ = true;
        return HXTSRAORUD;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object NWRDYDWMIL) {
        if (NWRDYDWMIL == null) {
            return false;
        }
        if (NWRDYDWMIL.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(NWRDYDWMIL).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }

    private void mergeLocalToBuilder() {
        if (HRUNTOJCJX != null) {
            TPPQACSULQ.setApplicationAttemptId(convertToProtoFormat(this.HRUNTOJCJX));
        }
    }

    private void mergeLocalToProto() {
        if (HJIPLMRICQ) {
            maybeInitBuilder();
        }
        mergeLocalToBuilder();
        HXTSRAORUD = TPPQACSULQ.build();
        HJIPLMRICQ = true;
    }

    private void maybeInitBuilder() {
        if (HJIPLMRICQ || (TPPQACSULQ == null)) {
            TPPQACSULQ = GetContainersRequestProto.newBuilder(HXTSRAORUD);
        }
        HJIPLMRICQ = false;
    }

    @Override
    public ApplicationAttemptId getApplicationAttemptId() {
        if (this.HRUNTOJCJX != null) {
            return this.HRUNTOJCJX;
        }
        GetContainersRequestProtoOrBuilder YZTFNPXIUB = (HJIPLMRICQ) ? HXTSRAORUD : TPPQACSULQ;
        if (!YZTFNPXIUB.hasApplicationAttemptId()) {
            return null;
        }
        this.HRUNTOJCJX = convertFromProtoFormat(YZTFNPXIUB.getApplicationAttemptId());
        return this.HRUNTOJCJX;
    }

    @Override
    public void setApplicationAttemptId(ApplicationAttemptId HWZODILVRP) {
        maybeInitBuilder();
        if (HWZODILVRP == null) {
            TPPQACSULQ.clearApplicationAttemptId();
        }
        this.HRUNTOJCJX = HWZODILVRP;
    }

    private ApplicationAttemptIdPBImpl convertFromProtoFormat(ApplicationAttemptIdProto YCLCELGFHL) {
        return new ApplicationAttemptIdPBImpl(YCLCELGFHL);
    }

    private ApplicationAttemptIdProto convertToProtoFormat(ApplicationAttemptId EJZDLPZLRK) {
        return ((ApplicationAttemptIdPBImpl) (EJZDLPZLRK)).getProto();
    }
}