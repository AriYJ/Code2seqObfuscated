public class TestINode extends TestCase {
    public void testSerializeFileWithSingleBlock() throws IOException {
        Block[] LHQHFJMXRS = new Block[]{ new Block(849282477840258181L, 128L) };
        INode IDSDUPUAEJ = new INode(FileType.FILE, LHQHFJMXRS);
        assertEquals("Length", (1L + 4) + 16, IDSDUPUAEJ.getSerializedLength());
        InputStream RVLLCCGDKI = IDSDUPUAEJ.serialize();
        INode PIYNFHWIUK = INode.deserialize(RVLLCCGDKI);
        assertEquals("FileType", IDSDUPUAEJ.getFileType(), PIYNFHWIUK.getFileType());
        Block[] JIBFPXKNZV = PIYNFHWIUK.getBlocks();
        assertEquals("Length", 1, JIBFPXKNZV.length);
        assertEquals("Id", LHQHFJMXRS[0].getId(), JIBFPXKNZV[0].getId());
        assertEquals("Length", LHQHFJMXRS[0].getLength(), JIBFPXKNZV[0].getLength());
    }

    public void testSerializeDirectory() throws IOException {
        INode DXWMGUPVKJ = INode.DIRECTORY_INODE;
        assertEquals("Length", 1L, DXWMGUPVKJ.getSerializedLength());
        InputStream SXSFGMKIBD = DXWMGUPVKJ.serialize();
        INode BGVTRNXPYA = INode.deserialize(SXSFGMKIBD);
        assertSame(INode.DIRECTORY_INODE, BGVTRNXPYA);
    }

    public void testDeserializeNull() throws IOException {
        assertNull(INode.deserialize(null));
    }
}