@InterfaceAudience.Private
@InterfaceStability.Evolving
public final class NSQuotaExceededException extends QuotaExceededException {
    protected static final long CRZGGDVADR = 1L;

    private String QNJFQYRSCZ;

    public NSQuotaExceededException() {
    }

    public NSQuotaExceededException(String GRUHPKVIFH) {
        super(GRUHPKVIFH);
    }

    public NSQuotaExceededException(long BGNVBSADXH, long GDHUGAFLGM) {
        super(BGNVBSADXH, GDHUGAFLGM);
    }

    @Override
    public String getMessage() {
        String KTJGHYJUCG = super.getMessage();
        if (KTJGHYJUCG == null) {
            KTJGHYJUCG = (((("The NameSpace quota (directories and files)" + (pathName == null ? "" : " of directory " + pathName)) + " is exceeded: quota=") + quota) + " file count=") + count;
            if (QNJFQYRSCZ != null) {
                KTJGHYJUCG = (QNJFQYRSCZ + ": ") + KTJGHYJUCG;
            }
        }
        return KTJGHYJUCG;
    }

    /**
     * Set a prefix for the error message.
     */
    public void setMessagePrefix(final String EDWZDZVLFN) {
        this.QNJFQYRSCZ = EDWZDZVLFN;
    }
}