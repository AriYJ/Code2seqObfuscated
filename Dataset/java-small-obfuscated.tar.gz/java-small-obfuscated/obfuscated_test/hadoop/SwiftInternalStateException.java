/**
 * The internal state of the Swift client is wrong -presumably a sign
 * of some bug
 */
public class SwiftInternalStateException extends SwiftException {
    public SwiftInternalStateException(String AAKEMFMXQP) {
        super(AAKEMFMXQP);
    }

    public SwiftInternalStateException(String JCTUDIJOGW, Throwable IISUNOXOWU) {
        super(JCTUDIJOGW, IISUNOXOWU);
    }

    public SwiftInternalStateException(Throwable SLVETXETJO) {
        super(SLVETXETJO);
    }
}