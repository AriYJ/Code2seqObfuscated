public class TestDistCpUtils {
    private static final Log OCDXVBGRWS = LogFactory.getLog(TestDistCpUtils.class);

    private static final Configuration PTJZSENXWW = new Configuration();

    private static MiniDFSCluster OHNOLWDQTS;

    @BeforeClass
    public static void create() throws IOException {
        TestDistCpUtils.OHNOLWDQTS = new MiniDFSCluster.Builder(TestDistCpUtils.PTJZSENXWW).numDataNodes(1).format(true).build();
    }

    @AfterClass
    public static void destroy() {
        if (TestDistCpUtils.OHNOLWDQTS != null) {
            TestDistCpUtils.OHNOLWDQTS.shutdown();
        }
    }

    @Test
    public void testGetRelativePathRoot() {
        Path JXFDBSOTKD = new Path("/tmp/abc");
        Path SAYSJRMKKA = new Path("/tmp/abc/xyz/file");
        Assert.assertEquals(DistCpUtils.getRelativePath(JXFDBSOTKD, SAYSJRMKKA), "/xyz/file");
        JXFDBSOTKD = new Path("/");
        SAYSJRMKKA = new Path("/a");
        Assert.assertEquals(DistCpUtils.getRelativePath(JXFDBSOTKD, SAYSJRMKKA), "/a");
    }

    @Test
    public void testPackAttributes() {
        EnumSet<FileAttribute> QSSIIIZSGH = EnumSet.noneOf(FileAttribute.class);
        Assert.assertEquals(DistCpUtils.packAttributes(QSSIIIZSGH), "");
        QSSIIIZSGH.add(REPLICATION);
        Assert.assertEquals(DistCpUtils.packAttributes(QSSIIIZSGH), "R");
        Assert.assertEquals(QSSIIIZSGH, DistCpUtils.unpackAttributes("R"));
        QSSIIIZSGH.add(BLOCKSIZE);
        Assert.assertEquals(DistCpUtils.packAttributes(QSSIIIZSGH), "RB");
        Assert.assertEquals(QSSIIIZSGH, DistCpUtils.unpackAttributes("RB"));
        QSSIIIZSGH.add(USER);
        Assert.assertEquals(DistCpUtils.packAttributes(QSSIIIZSGH), "RBU");
        Assert.assertEquals(QSSIIIZSGH, DistCpUtils.unpackAttributes("RBU"));
        QSSIIIZSGH.add(GROUP);
        Assert.assertEquals(DistCpUtils.packAttributes(QSSIIIZSGH), "RBUG");
        Assert.assertEquals(QSSIIIZSGH, DistCpUtils.unpackAttributes("RBUG"));
        QSSIIIZSGH.add(PERMISSION);
        Assert.assertEquals(DistCpUtils.packAttributes(QSSIIIZSGH), "RBUGP");
        Assert.assertEquals(QSSIIIZSGH, DistCpUtils.unpackAttributes("RBUGP"));
    }

    @Test
    public void testPreserve() {
        try {
            FileSystem QTLOIWODYN = FileSystem.get(TestDistCpUtils.PTJZSENXWW);
            EnumSet<FileAttribute> TQKQGJGKMH = EnumSet.noneOf(FileAttribute.class);
            Path BUVKGIJUXR = new Path("/tmp/abc");
            Path BPKAYLUGQV = new Path("/tmp/src");
            QTLOIWODYN.mkdirs(BUVKGIJUXR);
            QTLOIWODYN.mkdirs(BPKAYLUGQV);
            CopyListingFileStatus TOEOYYCDBR = new CopyListingFileStatus(QTLOIWODYN.getFileStatus(BPKAYLUGQV));
            FsPermission LDOTSPTUIK = new FsPermission(((short) (0)));
            QTLOIWODYN.setPermission(BUVKGIJUXR, LDOTSPTUIK);
            QTLOIWODYN.setOwner(BUVKGIJUXR, "nobody", "nobody");
            DistCpUtils.preserve(QTLOIWODYN, BUVKGIJUXR, TOEOYYCDBR, TQKQGJGKMH, false);
            FileStatus BQMOHXCZAB = QTLOIWODYN.getFileStatus(BUVKGIJUXR);
            Assert.assertEquals(BQMOHXCZAB.getPermission(), LDOTSPTUIK);
            Assert.assertEquals(BQMOHXCZAB.getOwner(), "nobody");
            Assert.assertEquals(BQMOHXCZAB.getGroup(), "nobody");
            TQKQGJGKMH.add(PERMISSION);
            DistCpUtils.preserve(QTLOIWODYN, BUVKGIJUXR, TOEOYYCDBR, TQKQGJGKMH, false);
            BQMOHXCZAB = QTLOIWODYN.getFileStatus(BUVKGIJUXR);
            Assert.assertEquals(BQMOHXCZAB.getPermission(), TOEOYYCDBR.getPermission());
            Assert.assertEquals(BQMOHXCZAB.getOwner(), "nobody");
            Assert.assertEquals(BQMOHXCZAB.getGroup(), "nobody");
            TQKQGJGKMH.add(GROUP);
            TQKQGJGKMH.add(USER);
            DistCpUtils.preserve(QTLOIWODYN, BUVKGIJUXR, TOEOYYCDBR, TQKQGJGKMH, false);
            BQMOHXCZAB = QTLOIWODYN.getFileStatus(BUVKGIJUXR);
            Assert.assertEquals(BQMOHXCZAB.getPermission(), TOEOYYCDBR.getPermission());
            Assert.assertEquals(BQMOHXCZAB.getOwner(), TOEOYYCDBR.getOwner());
            Assert.assertEquals(BQMOHXCZAB.getGroup(), TOEOYYCDBR.getGroup());
            QTLOIWODYN.delete(BUVKGIJUXR, true);
            QTLOIWODYN.delete(BPKAYLUGQV, true);
        } catch (IOException e) {
            TestDistCpUtils.OCDXVBGRWS.error("Exception encountered ", e);
            Assert.fail("Preserve test failure");
        }
    }

    private static Random SEEVCRBBBM = new Random();

    public static String createTestSetup(FileSystem WKXGGMJFAP) throws IOException {
        return TestDistCpUtils.createTestSetup("/tmp1", WKXGGMJFAP, FsPermission.getDefault());
    }

    public static String createTestSetup(FileSystem QITUUDOVRW, FsPermission IMXOTPAHMG) throws IOException {
        return TestDistCpUtils.createTestSetup("/tmp1", QITUUDOVRW, IMXOTPAHMG);
    }

    public static String createTestSetup(String DTNIZQAKMJ, FileSystem XAYOSCBZBX, FsPermission JTYJXZCFMX) throws IOException {
        String OZDYORWOVR = TestDistCpUtils.getBase(DTNIZQAKMJ);
        XAYOSCBZBX.mkdirs(new Path(OZDYORWOVR + "/newTest/hello/world1"));
        XAYOSCBZBX.mkdirs(new Path(OZDYORWOVR + "/newTest/hello/world2/newworld"));
        XAYOSCBZBX.mkdirs(new Path(OZDYORWOVR + "/newTest/hello/world3/oldworld"));
        XAYOSCBZBX.setPermission(new Path(OZDYORWOVR + "/newTest"), JTYJXZCFMX);
        XAYOSCBZBX.setPermission(new Path(OZDYORWOVR + "/newTest/hello"), JTYJXZCFMX);
        XAYOSCBZBX.setPermission(new Path(OZDYORWOVR + "/newTest/hello/world1"), JTYJXZCFMX);
        XAYOSCBZBX.setPermission(new Path(OZDYORWOVR + "/newTest/hello/world2"), JTYJXZCFMX);
        XAYOSCBZBX.setPermission(new Path(OZDYORWOVR + "/newTest/hello/world2/newworld"), JTYJXZCFMX);
        XAYOSCBZBX.setPermission(new Path(OZDYORWOVR + "/newTest/hello/world3"), JTYJXZCFMX);
        XAYOSCBZBX.setPermission(new Path(OZDYORWOVR + "/newTest/hello/world3/oldworld"), JTYJXZCFMX);
        TestDistCpUtils.createFile(XAYOSCBZBX, OZDYORWOVR + "/newTest/1");
        TestDistCpUtils.createFile(XAYOSCBZBX, OZDYORWOVR + "/newTest/hello/2");
        TestDistCpUtils.createFile(XAYOSCBZBX, OZDYORWOVR + "/newTest/hello/world3/oldworld/3");
        TestDistCpUtils.createFile(XAYOSCBZBX, OZDYORWOVR + "/newTest/hello/world2/4");
        return OZDYORWOVR;
    }

    private static String getBase(String LBXOTPHLSL) {
        String YPEXIFWKWT = String.valueOf(TestDistCpUtils.SEEVCRBBBM.nextLong());
        return (LBXOTPHLSL + "/") + YPEXIFWKWT;
    }

    public static void delete(FileSystem QVKMRMLEFZ, String HJEWAZWTQE) {
        try {
            if (QVKMRMLEFZ != null) {
                if (HJEWAZWTQE != null) {
                    QVKMRMLEFZ.delete(new Path(HJEWAZWTQE), true);
                }
            }
        } catch (IOException e) {
            TestDistCpUtils.OCDXVBGRWS.warn("Exception encountered ", e);
        }
    }

    public static void createFile(FileSystem LXFNXOFQDU, String KWMVFYTQTZ) throws IOException {
        OutputStream QONIETSYQO = LXFNXOFQDU.create(new Path(KWMVFYTQTZ));
        IOUtils.closeStream(QONIETSYQO);
    }

    public static boolean checkIfFoldersAreInSync(FileSystem QATCRXFTFB, String YKUWWUBNPS, String HUMIYLLDKA) throws IOException {
        Path WQPAHFDHLH = new Path(YKUWWUBNPS);
        Stack<Path> ROCURUTFXB = new Stack<Path>();
        ROCURUTFXB.push(WQPAHFDHLH);
        while (!ROCURUTFXB.isEmpty()) {
            Path HTUUONIHPD = ROCURUTFXB.pop();
            if (!QATCRXFTFB.exists(HTUUONIHPD))
                continue;

            FileStatus[] HWIALCKXRU = QATCRXFTFB.listStatus(HTUUONIHPD);
            if ((HWIALCKXRU == null) || (HWIALCKXRU.length == 0))
                continue;

            for (FileStatus ODXNSCSCNC : HWIALCKXRU) {
                if (ODXNSCSCNC.isDirectory()) {
                    ROCURUTFXB.push(ODXNSCSCNC.getPath());
                }
                Assert.assertTrue(QATCRXFTFB.exists(new Path((HUMIYLLDKA + "/") + DistCpUtils.getRelativePath(new Path(YKUWWUBNPS), ODXNSCSCNC.getPath()))));
            }
        } 
        return true;
    }
}