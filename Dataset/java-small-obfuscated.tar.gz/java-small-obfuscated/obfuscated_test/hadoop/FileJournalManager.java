/**
 * Journal manager for the common case of edits files being written
 * to a storage directory.
 *
 * Note: this class is not thread-safe and should be externally
 * synchronized.
 */
@InterfaceAudience.Private
public class FileJournalManager implements JournalManager {
    private static final Log ELIRHCUWKV = LogFactory.getLog(FileJournalManager.class);

    private final Configuration BGGLMIEIUB;

    private final StorageDirectory RDNPOPHPKL;

    private final StorageErrorReporter MDAKMRHFXS;

    private int ODLKDNGSVU = 512 * 1024;

    private static final Pattern HEYVGDJZJJ = Pattern.compile(EDITS.getName() + "_(\\d+)-(\\d+)");

    private static final Pattern GDZAVAXRPN = Pattern.compile(EDITS_INPROGRESS.getName() + "_(\\d+)");

    private static final Pattern LJUQFNHXZL = Pattern.compile(EDITS_INPROGRESS.getName() + "_(\\d+).*(\\S+)");

    private File XVKASSCZIJ = null;

    @VisibleForTesting
    StoragePurger RXYKUPFYKH = new NNStorageRetentionManager.DeletionStoragePurger();

    public FileJournalManager(Configuration PIGIEPRZQC, StorageDirectory GDFIZYJBMW, StorageErrorReporter JXJSOKRSWW) {
        this.BGGLMIEIUB = PIGIEPRZQC;
        this.RDNPOPHPKL = GDFIZYJBMW;
        this.MDAKMRHFXS = JXJSOKRSWW;
    }

    @Override
    public void close() throws IOException {
    }

    @Override
    public void format(NamespaceInfo XVSSYGKNZN) throws IOException {
        // Formatting file journals is done by the StorageDirectory
        // format code, since they may share their directory with
        // checkpoints, etc.
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean hasSomeData() {
        // Formatting file journals is done by the StorageDirectory
        // format code, since they may share their directory with
        // checkpoints, etc.
        throw new UnsupportedOperationException();
    }

    @Override
    public synchronized EditLogOutputStream startLogSegment(long CYWVJEOOER, int NEZMCOBAPY) throws IOException {
        try {
            XVKASSCZIJ = NNStorage.getInProgressEditsFile(RDNPOPHPKL, CYWVJEOOER);
            EditLogOutputStream ICRATYBUSY = new EditLogFileOutputStream(BGGLMIEIUB, XVKASSCZIJ, ODLKDNGSVU);
            ICRATYBUSY.create(NEZMCOBAPY);
            return ICRATYBUSY;
        } catch (IOException e) {
            FileJournalManager.ELIRHCUWKV.warn((((("Unable to start log segment " + CYWVJEOOER) + " at ") + XVKASSCZIJ) + ": ") + e.getLocalizedMessage());
            MDAKMRHFXS.reportErrorOnFile(XVKASSCZIJ);
            throw e;
        }
    }

    @Override
    public synchronized void finalizeLogSegment(long ODDFNUUFSB, long ZOOOZDEVJV) throws IOException {
        File BDTRJFDIGO = NNStorage.getInProgressEditsFile(RDNPOPHPKL, ODDFNUUFSB);
        File AWEONWPGVG = NNStorage.getFinalizedEditsFile(RDNPOPHPKL, ODDFNUUFSB, ZOOOZDEVJV);
        FileJournalManager.ELIRHCUWKV.info((("Finalizing edits file " + BDTRJFDIGO) + " -> ") + AWEONWPGVG);
        Preconditions.checkState(!AWEONWPGVG.exists(), (("Can't finalize edits file " + BDTRJFDIGO) + " since finalized file ") + "already exists");
        try {
            NativeIO.renameTo(BDTRJFDIGO, AWEONWPGVG);
        } catch (IOException e) {
            MDAKMRHFXS.reportErrorOnFile(AWEONWPGVG);
            throw new IllegalStateException("Unable to finalize edits file " + BDTRJFDIGO, e);
        }
        if (BDTRJFDIGO.equals(XVKASSCZIJ)) {
            XVKASSCZIJ = null;
        }
    }

    @VisibleForTesting
    public StorageDirectory getStorageDirectory() {
        return RDNPOPHPKL;
    }

    @Override
    public synchronized void setOutputBufferCapacity(int FBNPCTVCUH) {
        this.ODLKDNGSVU = FBNPCTVCUH;
    }

    @Override
    public void purgeLogsOlderThan(long VRWPKDWYZY) throws IOException {
        FileJournalManager.ELIRHCUWKV.info("Purging logs older than " + VRWPKDWYZY);
        File[] EIOJTMWZWJ = FileUtil.listFiles(RDNPOPHPKL.getCurrentDir());
        List<FileJournalManager.EditLogFile> DPHYTCOTPU = FileJournalManager.matchEditLogs(EIOJTMWZWJ, true);
        for (FileJournalManager.EditLogFile XNMKXXNRIV : DPHYTCOTPU) {
            if ((XNMKXXNRIV.getFirstTxId() < VRWPKDWYZY) && (XNMKXXNRIV.getLastTxId() < VRWPKDWYZY)) {
                RXYKUPFYKH.purgeLog(XNMKXXNRIV);
            }
        }
    }

    /**
     * Find all editlog segments starting at or above the given txid.
     *
     * @param firstTxId
     * 		the txnid which to start looking
     * @param inProgressOk
     * 		whether or not to include the in-progress edit log
     * 		segment
     * @return a list of remote edit logs
     * @throws IOException
     * 		if edit logs cannot be listed.
     */
    public List<RemoteEditLog> getRemoteEditLogs(long CMIDKWVXWG, boolean RIEBPCAHZH) throws IOException {
        File SWUIIEGDSS = RDNPOPHPKL.getCurrentDir();
        List<FileJournalManager.EditLogFile> ZAEPVDIIKL = FileJournalManager.matchEditLogs(SWUIIEGDSS);
        List<RemoteEditLog> QQQCPXQTGN = Lists.newArrayListWithCapacity(ZAEPVDIIKL.size());
        for (FileJournalManager.EditLogFile UGXDHMMNZB : ZAEPVDIIKL) {
            if (UGXDHMMNZB.hasCorruptHeader() || ((!RIEBPCAHZH) && UGXDHMMNZB.isInProgress())) {
                continue;
            }
            if (UGXDHMMNZB.getFirstTxId() >= CMIDKWVXWG) {
                QQQCPXQTGN.add(new RemoteEditLog(UGXDHMMNZB.VXJTKFLDVT, UGXDHMMNZB.XCJFSQPYTM));
            } else
                if ((UGXDHMMNZB.getFirstTxId() < CMIDKWVXWG) && (CMIDKWVXWG <= UGXDHMMNZB.getLastTxId())) {
                    // If the firstTxId is in the middle of an edit log segment. Return this
                    // anyway and let the caller figure out whether it wants to use it.
                    QQQCPXQTGN.add(new RemoteEditLog(UGXDHMMNZB.VXJTKFLDVT, UGXDHMMNZB.XCJFSQPYTM));
                }

        }
        Collections.sort(QQQCPXQTGN);
        return QQQCPXQTGN;
    }

    /**
     * Discard all editlog segments whose first txid is greater than or equal to
     * the given txid, by renaming them with suffix ".trash".
     */
    private void discardEditLogSegments(long YZJUXNIAIY) throws IOException {
        File RZSFPSFTBK = RDNPOPHPKL.getCurrentDir();
        List<FileJournalManager.EditLogFile> QASMLGITSD = FileJournalManager.matchEditLogs(RZSFPSFTBK);
        List<FileJournalManager.EditLogFile> YBEJWKNFXY = Lists.newArrayList();
        FileJournalManager.ELIRHCUWKV.info("Discard the EditLog files, the given start txid is " + YZJUXNIAIY);
        // go through the editlog files to make sure the startTxId is right at the
        // segment boundary
        for (FileJournalManager.EditLogFile IQWMSJDBPZ : QASMLGITSD) {
            if (IQWMSJDBPZ.getFirstTxId() >= YZJUXNIAIY) {
                YBEJWKNFXY.add(IQWMSJDBPZ);
            } else {
                Preconditions.checkState(IQWMSJDBPZ.getLastTxId() < YZJUXNIAIY);
            }
        }
        for (FileJournalManager.EditLogFile ICXKSJTHWW : YBEJWKNFXY) {
            // rename these editlog file as .trash
            ICXKSJTHWW.moveAsideTrashFile(YZJUXNIAIY);
            FileJournalManager.ELIRHCUWKV.info("Trash the EditLog file " + ICXKSJTHWW);
        }
    }

    /**
     * returns matching edit logs via the log directory. Simple helper function
     * that lists the files in the logDir and calls matchEditLogs(File[])
     *
     * @param logDir
     * 		directory to match edit logs in
     * @return matched edit logs
     * @throws IOException
     * 		IOException thrown for invalid logDir
     */
    public static List<FileJournalManager.EditLogFile> matchEditLogs(File XSHVMBCBHN) throws IOException {
        return FileJournalManager.matchEditLogs(FileUtil.listFiles(XSHVMBCBHN));
    }

    static List<FileJournalManager.EditLogFile> matchEditLogs(File[] ZCGUWWVSEX) {
        return FileJournalManager.matchEditLogs(ZCGUWWVSEX, false);
    }

    private static List<FileJournalManager.EditLogFile> matchEditLogs(File[] MXXGTTKGEB, boolean RMIXTGKQYZ) {
        List<FileJournalManager.EditLogFile> WEZSHUKHZB = Lists.newArrayList();
        for (File CLDFYABFCN : MXXGTTKGEB) {
            String GBSTYXWSCB = CLDFYABFCN.getName();
            // Check for edits
            Matcher DFPRGIYDSJ = FileJournalManager.HEYVGDJZJJ.matcher(GBSTYXWSCB);
            if (DFPRGIYDSJ.matches()) {
                try {
                    long AJTKJLDWGK = Long.parseLong(DFPRGIYDSJ.group(1));
                    long PTEPXRURQE = Long.parseLong(DFPRGIYDSJ.group(2));
                    WEZSHUKHZB.add(new FileJournalManager.EditLogFile(CLDFYABFCN, AJTKJLDWGK, PTEPXRURQE));
                    continue;
                } catch (NumberFormatException nfe) {
                    FileJournalManager.ELIRHCUWKV.error((("Edits file " + CLDFYABFCN) + " has improperly formatted ") + "transaction ID");
                    // skip
                }
            }
            // Check for in-progress edits
            Matcher AKIKVVWDTL = FileJournalManager.GDZAVAXRPN.matcher(GBSTYXWSCB);
            if (AKIKVVWDTL.matches()) {
                try {
                    long TWFTHUPXBM = Long.parseLong(AKIKVVWDTL.group(1));
                    WEZSHUKHZB.add(new FileJournalManager.EditLogFile(CLDFYABFCN, TWFTHUPXBM, HdfsConstants.INVALID_TXID, true));
                    continue;
                } catch (NumberFormatException nfe) {
                    FileJournalManager.ELIRHCUWKV.error((("In-progress edits file " + CLDFYABFCN) + " has improperly ") + "formatted transaction ID");
                    // skip
                }
            }
            if (RMIXTGKQYZ) {
                // Check for in-progress stale edits
                Matcher PRVIJHFDYY = FileJournalManager.LJUQFNHXZL.matcher(GBSTYXWSCB);
                if (PRVIJHFDYY.matches()) {
                    try {
                        long CDMUVOPUGI = Long.valueOf(PRVIJHFDYY.group(1));
                        WEZSHUKHZB.add(new FileJournalManager.EditLogFile(CLDFYABFCN, CDMUVOPUGI, HdfsConstants.INVALID_TXID, true));
                        continue;
                    } catch (NumberFormatException nfe) {
                        FileJournalManager.ELIRHCUWKV.error((("In-progress stale edits file " + CLDFYABFCN) + " has improperly ") + "formatted transaction ID");
                        // skip
                    }
                }
            }
        }
        return WEZSHUKHZB;
    }

    @Override
    public synchronized void selectInputStreams(Collection<EditLogInputStream> SMUASFHDBR, long UWBOBOXENZ, boolean AYJPGNRWUV) throws IOException {
        List<FileJournalManager.EditLogFile> HHKMKMOFBJ = FileJournalManager.matchEditLogs(RDNPOPHPKL.getCurrentDir());
        FileJournalManager.ELIRHCUWKV.debug((((((this + ": selecting input streams starting at ") + UWBOBOXENZ) + (AYJPGNRWUV ? " (inProgress ok) " : " (excluding inProgress) ")) + "from among ") + HHKMKMOFBJ.size()) + " candidate file(s)");
        FileJournalManager.addStreamsToCollectionFromFiles(HHKMKMOFBJ, SMUASFHDBR, UWBOBOXENZ, AYJPGNRWUV);
    }

    static void addStreamsToCollectionFromFiles(Collection<FileJournalManager.EditLogFile> SBJAUHKCJV, Collection<EditLogInputStream> KPKMUZNEFC, long IJXEPTAFOJ, boolean CRCAFVJZOB) {
        for (FileJournalManager.EditLogFile MTABCUDLWR : SBJAUHKCJV) {
            if (MTABCUDLWR.isInProgress()) {
                if (!CRCAFVJZOB) {
                    FileJournalManager.ELIRHCUWKV.debug((("passing over " + MTABCUDLWR) + " because it is in progress ") + "and we are ignoring in-progress logs.");
                    continue;
                }
                try {
                    MTABCUDLWR.validateLog();
                } catch (IOException e) {
                    FileJournalManager.ELIRHCUWKV.error(("got IOException while trying to validate header of " + MTABCUDLWR) + ".  Skipping.", e);
                    continue;
                }
            }
            if (MTABCUDLWR.XCJFSQPYTM < IJXEPTAFOJ) {
                assert MTABCUDLWR.XCJFSQPYTM != HdfsConstants.INVALID_TXID;
                FileJournalManager.ELIRHCUWKV.debug(((((("passing over " + MTABCUDLWR) + " because it ends at ") + MTABCUDLWR.XCJFSQPYTM) + ", but we only care about transactions ") + "as new as ") + IJXEPTAFOJ);
                continue;
            }
            EditLogFileInputStream QKRTBPYVJV = new EditLogFileInputStream(MTABCUDLWR.getFile(), MTABCUDLWR.getFirstTxId(), MTABCUDLWR.getLastTxId(), MTABCUDLWR.isInProgress());
            FileJournalManager.ELIRHCUWKV.debug("selecting edit log stream " + MTABCUDLWR);
            KPKMUZNEFC.add(QKRTBPYVJV);
        }
    }

    @Override
    public synchronized void recoverUnfinalizedSegments() throws IOException {
        File KPMQIBXUVY = RDNPOPHPKL.getCurrentDir();
        FileJournalManager.ELIRHCUWKV.info("Recovering unfinalized segments in " + KPMQIBXUVY);
        List<FileJournalManager.EditLogFile> WQUYJLFJKI = FileJournalManager.matchEditLogs(KPMQIBXUVY);
        for (FileJournalManager.EditLogFile JEWMBMFQOD : WQUYJLFJKI) {
            if (JEWMBMFQOD.getFile().equals(XVKASSCZIJ)) {
                continue;
            }
            if (JEWMBMFQOD.isInProgress()) {
                // If the file is zero-length, we likely just crashed after opening the
                // file, but before writing anything to it. Safe to delete it.
                if (JEWMBMFQOD.getFile().length() == 0) {
                    FileJournalManager.ELIRHCUWKV.info("Deleting zero-length edit log file " + JEWMBMFQOD);
                    if (!JEWMBMFQOD.getFile().delete()) {
                        throw new IOException("Unable to delete file " + JEWMBMFQOD.getFile());
                    }
                    continue;
                }
                JEWMBMFQOD.validateLog();
                if (JEWMBMFQOD.hasCorruptHeader()) {
                    JEWMBMFQOD.moveAsideCorruptFile();
                    throw new CorruptionException("In-progress edit log file is corrupt: " + JEWMBMFQOD);
                }
                if (JEWMBMFQOD.getLastTxId() == HdfsConstants.INVALID_TXID) {
                    // If the file has a valid header (isn't corrupt) but contains no
                    // transactions, we likely just crashed after opening the file and
                    // writing the header, but before syncing any transactions. Safe to
                    // delete the file.
                    FileJournalManager.ELIRHCUWKV.info(("Moving aside edit log file that seems to have zero " + "transactions ") + JEWMBMFQOD);
                    JEWMBMFQOD.moveAsideEmptyFile();
                    continue;
                }
                finalizeLogSegment(JEWMBMFQOD.getFirstTxId(), JEWMBMFQOD.getLastTxId());
            }
        }
    }

    public List<FileJournalManager.EditLogFile> getLogFiles(long WOQUDCJGWU) throws IOException {
        File PTIMCXUEDX = RDNPOPHPKL.getCurrentDir();
        List<FileJournalManager.EditLogFile> QMOQBWMTRM = FileJournalManager.matchEditLogs(PTIMCXUEDX);
        List<FileJournalManager.EditLogFile> EWCDOIEZNB = Lists.newArrayList();
        for (FileJournalManager.EditLogFile JJGPRTNCSJ : QMOQBWMTRM) {
            if ((WOQUDCJGWU <= JJGPRTNCSJ.getFirstTxId()) || JJGPRTNCSJ.containsTxId(WOQUDCJGWU)) {
                EWCDOIEZNB.add(JJGPRTNCSJ);
            }
        }
        Collections.sort(EWCDOIEZNB, FileJournalManager.EditLogFile.YQJCOQHCBS);
        return EWCDOIEZNB;
    }

    public FileJournalManager.EditLogFile getLogFile(long EUKSKGLRCN) throws IOException {
        return FileJournalManager.getLogFile(RDNPOPHPKL.getCurrentDir(), EUKSKGLRCN);
    }

    public static FileJournalManager.EditLogFile getLogFile(File VDXKPDSYBM, long DZWSICGORM) throws IOException {
        List<FileJournalManager.EditLogFile> YMVWAEXATT = FileJournalManager.matchEditLogs(VDXKPDSYBM);
        List<FileJournalManager.EditLogFile> KKNTSOEXFT = Lists.newLinkedList();
        for (FileJournalManager.EditLogFile ZCGYOVTTEX : YMVWAEXATT) {
            if (ZCGYOVTTEX.getFirstTxId() == DZWSICGORM) {
                KKNTSOEXFT.add(ZCGYOVTTEX);
            }
        }
        if (KKNTSOEXFT.isEmpty()) {
            // no matches
            return null;
        } else
            if (KKNTSOEXFT.size() == 1) {
                return KKNTSOEXFT.get(0);
            } else {
                throw new IllegalStateException((((("More than one log segment in " + VDXKPDSYBM) + " starting at txid ") + DZWSICGORM) + ": ") + com.google.common.base.Joiner.on(", ").join(KKNTSOEXFT));
            }

    }

    @Override
    public String toString() {
        return String.format("FileJournalManager(root=%s)", RDNPOPHPKL.getRoot());
    }

    /**
     * Record of an edit log that has been located and had its filename parsed.
     */
    @InterfaceAudience.Private
    public static class EditLogFile {
        private File JVTDUUBPJJ;

        private final long VXJTKFLDVT;

        private long XCJFSQPYTM;

        private boolean RMLALCACPE = false;

        private final boolean LNBFTJVBWP;

        static final Comparator<FileJournalManager.EditLogFile> YQJCOQHCBS = new Comparator<FileJournalManager.EditLogFile>() {
            @Override
            public int compare(FileJournalManager.EditLogFile a, FileJournalManager.EditLogFile b) {
                return com.google.common.collect.ComparisonChain.start().compare(a.getFirstTxId(), b.getFirstTxId()).compare(a.getLastTxId(), b.getLastTxId()).result();
            }
        };

        EditLogFile(File file, long firstTxId, long lastTxId) {
            this(file, firstTxId, lastTxId, false);
            assert (lastTxId != HdfsConstants.INVALID_TXID) && (lastTxId >= firstTxId);
        }

        EditLogFile(File file, long firstTxId, long lastTxId, boolean isInProgress) {
            assert ((lastTxId == HdfsConstants.INVALID_TXID) && isInProgress) || ((lastTxId != HdfsConstants.INVALID_TXID) && (lastTxId >= firstTxId));
            assert (firstTxId > 0) || (firstTxId == HdfsConstants.INVALID_TXID);
            assert file != null;
            Preconditions.checkArgument((!isInProgress) || (lastTxId == HdfsConstants.INVALID_TXID));
            this.VXJTKFLDVT = firstTxId;
            this.XCJFSQPYTM = lastTxId;
            this.JVTDUUBPJJ = file;
            this.LNBFTJVBWP = isInProgress;
        }

        public long getFirstTxId() {
            return VXJTKFLDVT;
        }

        public long getLastTxId() {
            return XCJFSQPYTM;
        }

        boolean containsTxId(long txId) {
            return (VXJTKFLDVT <= txId) && (txId <= XCJFSQPYTM);
        }

        /**
         * Find out where the edit log ends.
         * This will update the lastTxId of the EditLogFile or
         * mark it as corrupt if it is.
         */
        public void validateLog() throws IOException {
            EditLogValidation val = EditLogFileInputStream.validateEditLog(JVTDUUBPJJ);
            this.XCJFSQPYTM = val.getEndTxId();
            this.RMLALCACPE = val.hasCorruptHeader();
        }

        public void scanLog() throws IOException {
            EditLogValidation val = EditLogFileInputStream.scanEditLog(JVTDUUBPJJ);
            this.XCJFSQPYTM = val.getEndTxId();
            this.RMLALCACPE = val.hasCorruptHeader();
        }

        public boolean isInProgress() {
            return LNBFTJVBWP;
        }

        public File getFile() {
            return JVTDUUBPJJ;
        }

        boolean hasCorruptHeader() {
            return RMLALCACPE;
        }

        void moveAsideCorruptFile() throws IOException {
            assert RMLALCACPE;
            renameSelf(".corrupt");
        }

        void moveAsideTrashFile(long markerTxid) throws IOException {
            assert this.getFirstTxId() >= markerTxid;
            renameSelf(".trash");
        }

        public void moveAsideEmptyFile() throws IOException {
            assert XCJFSQPYTM == HdfsConstants.INVALID_TXID;
            renameSelf(".empty");
        }

        private void renameSelf(String newSuffix) throws IOException {
            File src = JVTDUUBPJJ;
            File dst = new File(src.getParent(), src.getName() + newSuffix);
            // renameTo fails on Windows if the destination file already exists.
            try {
                if (dst.exists()) {
                    if (!dst.delete()) {
                        throw new IOException("Couldn't delete " + dst);
                    }
                }
                NativeIO.renameTo(src, dst);
            } catch (IOException e) {
                throw new IOException((("Couldn't rename log " + src) + " to ") + dst, e);
            }
            JVTDUUBPJJ = dst;
        }

        @Override
        public String toString() {
            return String.format("EditLogFile(file=%s,first=%019d,last=%019d," + "inProgress=%b,hasCorruptHeader=%b)", JVTDUUBPJJ.toString(), VXJTKFLDVT, XCJFSQPYTM, isInProgress(), RMLALCACPE);
        }
    }

    @Override
    public void doPreUpgrade() throws IOException {
        FileJournalManager.ELIRHCUWKV.info("Starting upgrade of edits directory " + RDNPOPHPKL.getRoot());
        try {
            NNUpgradeUtil.doPreUpgrade(RDNPOPHPKL);
        } catch (IOException ioe) {
            FileJournalManager.ELIRHCUWKV.error(("Failed to move aside pre-upgrade storage " + "in image directory ") + RDNPOPHPKL.getRoot(), ioe);
            throw ioe;
        }
    }

    /**
     * This method assumes that the fields of the {@link Storage} object have
     * already been updated to the appropriate new values for the upgrade.
     */
    @Override
    public void doUpgrade(Storage XXRLVZVZLQ) throws IOException {
        NNUpgradeUtil.doUpgrade(RDNPOPHPKL, XXRLVZVZLQ);
    }

    @Override
    public void doFinalize() throws IOException {
        NNUpgradeUtil.doFinalize(RDNPOPHPKL);
    }

    @Override
    public boolean canRollBack(StorageInfo IEZDGOFDNO, StorageInfo ENLWAFHLSW, int NUBZCPLMYK) throws IOException {
        return NNUpgradeUtil.canRollBack(RDNPOPHPKL, IEZDGOFDNO, ENLWAFHLSW, NUBZCPLMYK);
    }

    @Override
    public void doRollback() throws IOException {
        NNUpgradeUtil.doRollBack(RDNPOPHPKL);
    }

    @Override
    public void discardSegments(long IKCFLUNIXS) throws IOException {
        discardEditLogSegments(IKCFLUNIXS);
    }

    @Override
    public long getJournalCTime() throws IOException {
        StorageInfo LHHIMHJIGG = new StorageInfo(((NodeType) (null)));
        LHHIMHJIGG.readProperties(RDNPOPHPKL);
        return LHHIMHJIGG.getCTime();
    }
}