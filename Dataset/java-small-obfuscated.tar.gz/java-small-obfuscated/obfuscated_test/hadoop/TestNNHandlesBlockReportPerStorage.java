/**
 * Runs all tests in BlockReportTestBase, sending one block per storage.
 * This is the default DataNode behavior post HDFS-2832.
 */
public class TestNNHandlesBlockReportPerStorage extends BlockReportTestBase {
    @Override
    protected void sendBlockReports(DatanodeRegistration ADMRVKFMZC, String LRYKGNOOEO, StorageBlockReport[] TVHIPPGOCB) throws IOException {
        for (StorageBlockReport FGFYKWKOYL : TVHIPPGOCB) {
            LOG.info("Sending block report for storage " + FGFYKWKOYL.getStorage().getStorageID());
            StorageBlockReport[] XBLFKAJVSG = new StorageBlockReport[]{ FGFYKWKOYL };
            cluster.getNameNodeRpc().blockReport(ADMRVKFMZC, LRYKGNOOEO, XBLFKAJVSG);
        }
    }
}