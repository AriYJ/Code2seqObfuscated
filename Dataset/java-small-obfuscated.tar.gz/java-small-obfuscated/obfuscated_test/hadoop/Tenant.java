/**
 * Tenant is abstraction in Openstack which describes all account
 * information and user privileges in system.
 * THIS FILE IS MAPPED BY JACKSON TO AND FROM JSON.
 * DO NOT RENAME OR MODIFY FIELDS AND THEIR ACCESSORS.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Tenant {
    /**
     * tenant id
     */
    private String YSGDGRCGPL;

    /**
     * tenant short description which Keystone returns
     */
    private String VDKKSNWVZC;

    /**
     * boolean enabled user account or no
     */
    private boolean JTJTAFHCWS;

    /**
     * tenant human readable name
     */
    private String YTFMBOUDUL;

    /**
     *
     *
     * @return tenant name
     */
    public String getName() {
        return YTFMBOUDUL;
    }

    /**
     *
     *
     * @param name
     * 		tenant name
     */
    public void setName(String GKXHMGHPTU) {
        this.YTFMBOUDUL = GKXHMGHPTU;
    }

    /**
     *
     *
     * @return true if account enabled and false otherwise
     */
    public boolean isEnabled() {
        return JTJTAFHCWS;
    }

    /**
     *
     *
     * @param enabled
     * 		enable or disable
     */
    public void setEnabled(boolean TWDDFKBLAB) {
        this.JTJTAFHCWS = TWDDFKBLAB;
    }

    /**
     *
     *
     * @return account short description
     */
    public String getDescription() {
        return VDKKSNWVZC;
    }

    /**
     *
     *
     * @param description
     * 		set account description
     */
    public void setDescription(String UIFZRDTNMQ) {
        this.VDKKSNWVZC = UIFZRDTNMQ;
    }

    /**
     *
     *
     * @return set tenant id
     */
    public String getId() {
        return YSGDGRCGPL;
    }

    /**
     *
     *
     * @param id
     * 		tenant id
     */
    public void setId(String DAFNGHPOON) {
        this.YSGDGRCGPL = DAFNGHPOON;
    }
}