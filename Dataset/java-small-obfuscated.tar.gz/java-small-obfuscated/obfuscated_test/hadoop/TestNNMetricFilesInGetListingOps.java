/**
 * Test case for FilesInGetListingOps metric in Namenode
 */
public class TestNNMetricFilesInGetListingOps {
    private static final Configuration XHWDAPMGPF = new HdfsConfiguration();

    private static final String DBXKXCRJTE = "NameNodeActivity";

    static {
        TestNNMetricFilesInGetListingOps.XHWDAPMGPF.setLong(DFS_BLOCK_SIZE_KEY, 100);
        TestNNMetricFilesInGetListingOps.XHWDAPMGPF.setInt(DFS_BYTES_PER_CHECKSUM_KEY, 1);
        TestNNMetricFilesInGetListingOps.XHWDAPMGPF.setLong(DFS_HEARTBEAT_INTERVAL_KEY, 1L);
        TestNNMetricFilesInGetListingOps.XHWDAPMGPF.setInt(DFS_NAMENODE_REPLICATION_INTERVAL_KEY, 1);
    }

    private MiniDFSCluster PYDPDERLJS;

    private DistributedFileSystem GAHLCURTEC;

    private final Random CGKBRGKCXF = new Random();

    @Before
    public void setUp() throws Exception {
        PYDPDERLJS = new MiniDFSCluster.Builder(TestNNMetricFilesInGetListingOps.XHWDAPMGPF).build();
        PYDPDERLJS.waitActive();
        PYDPDERLJS.getNameNode();
        GAHLCURTEC = PYDPDERLJS.getFileSystem();
    }

    @After
    public void tearDown() throws Exception {
        PYDPDERLJS.shutdown();
    }

    /**
     * create a file with a length of <code>fileLen</code>
     */
    private void createFile(String GOJNMXKPVB, long EHZTPYPHIE, short FAJEDECRHX) throws IOException {
        Path SRDXJLMJLI = new Path(GOJNMXKPVB);
        DFSTestUtil.createFile(GAHLCURTEC, SRDXJLMJLI, EHZTPYPHIE, FAJEDECRHX, CGKBRGKCXF.nextLong());
    }

    @Test
    public void testFilesInGetListingOps() throws Exception {
        createFile("/tmp1/t1", 3200, ((short) (3)));
        createFile("/tmp1/t2", 3200, ((short) (3)));
        createFile("/tmp2/t1", 3200, ((short) (3)));
        createFile("/tmp2/t2", 3200, ((short) (3)));
        PYDPDERLJS.getNameNodeRpc().getListing("/tmp1", HdfsFileStatus.EMPTY_NAME, false);
        assertCounter("FilesInGetListingOps", 2L, getMetrics(TestNNMetricFilesInGetListingOps.DBXKXCRJTE));
        PYDPDERLJS.getNameNodeRpc().getListing("/tmp2", HdfsFileStatus.EMPTY_NAME, false);
        assertCounter("FilesInGetListingOps", 4L, getMetrics(TestNNMetricFilesInGetListingOps.DBXKXCRJTE));
    }
}