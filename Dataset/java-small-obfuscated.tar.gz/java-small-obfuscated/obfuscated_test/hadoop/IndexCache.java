class IndexCache {
    private final JobConf MIPJUDMQGR;

    private final int NWOPSEEOXJ;

    private AtomicInteger QHYFCAMRNU = new AtomicInteger();

    private static final Log VXUSIQMVDK = LogFactory.getLog(IndexCache.class);

    private final ConcurrentHashMap<String, IndexCache.IndexInformation> JLBOVKECEW = new ConcurrentHashMap<String, IndexCache.IndexInformation>();

    private final LinkedBlockingQueue<String> DJXFENJACV = new LinkedBlockingQueue<String>();

    public IndexCache(JobConf OEKYZICFHE) {
        this.MIPJUDMQGR = OEKYZICFHE;
        NWOPSEEOXJ = (OEKYZICFHE.getInt(TT_INDEX_CACHE, 10) * 1024) * 1024;
        IndexCache.VXUSIQMVDK.info("IndexCache created with max memory = " + NWOPSEEOXJ);
    }

    /**
     * This method gets the index information for the given mapId and reduce.
     * It reads the index file into cache if it is not already present.
     *
     * @param mapId
     * 		
     * @param reduce
     * 		
     * @param fileName
     * 		The file to read the index information from if it is not
     * 		already present in the cache
     * @param expectedIndexOwner
     * 		The expected owner of the index file
     * @return The Index Information
     * @throws IOException
     * 		
     */
    public IndexRecord getIndexInformation(String OFAHTFGQFE, int GIXMEFNBVK, Path RBPEWLFSRW, String FUZQEZTBTX) throws IOException {
        IndexCache.IndexInformation RTWFHIWGHE = JLBOVKECEW.get(OFAHTFGQFE);
        if (RTWFHIWGHE == null) {
            RTWFHIWGHE = readIndexFileToCache(RBPEWLFSRW, OFAHTFGQFE, FUZQEZTBTX);
        } else {
            synchronized(RTWFHIWGHE) {
                while (isUnderConstruction(RTWFHIWGHE)) {
                    try {
                        RTWFHIWGHE.wait();
                    } catch (InterruptedException e) {
                        throw new IOException("Interrupted waiting for construction", e);
                    }
                } 
            }
            IndexCache.VXUSIQMVDK.debug(("IndexCache HIT: MapId " + OFAHTFGQFE) + " found");
        }
        if ((RTWFHIWGHE.BXDTQJLAUZ.size() == 0) || (RTWFHIWGHE.BXDTQJLAUZ.size() <= GIXMEFNBVK)) {
            throw new IOException(((((("Invalid request " + " Map Id = ") + OFAHTFGQFE) + " Reducer = ") + GIXMEFNBVK) + " Index Info Length = ") + RTWFHIWGHE.BXDTQJLAUZ.size());
        }
        return RTWFHIWGHE.BXDTQJLAUZ.getIndex(GIXMEFNBVK);
    }

    private boolean isUnderConstruction(IndexCache.IndexInformation KUKTLZMWKN) {
        synchronized(KUKTLZMWKN) {
            return null == KUKTLZMWKN.BXDTQJLAUZ;
        }
    }

    private IndexCache.IndexInformation readIndexFileToCache(Path DPQOAUOMJN, String WVVLWNCBUF, String XNWEKWGCKM) throws IOException {
        IndexCache.IndexInformation FDMMFHBRSQ;
        IndexCache.IndexInformation YENGACGXHS = new IndexCache.IndexInformation();
        if ((FDMMFHBRSQ = JLBOVKECEW.putIfAbsent(WVVLWNCBUF, YENGACGXHS)) != null) {
            synchronized(FDMMFHBRSQ) {
                while (isUnderConstruction(FDMMFHBRSQ)) {
                    try {
                        FDMMFHBRSQ.wait();
                    } catch (InterruptedException e) {
                        throw new IOException("Interrupted waiting for construction", e);
                    }
                } 
            }
            IndexCache.VXUSIQMVDK.debug(("IndexCache HIT: MapId " + WVVLWNCBUF) + " found");
            return FDMMFHBRSQ;
        }
        IndexCache.VXUSIQMVDK.debug(("IndexCache MISS: MapId " + WVVLWNCBUF) + " not found");
        SpillRecord BZOSEITDHX = null;
        try {
            BZOSEITDHX = new SpillRecord(DPQOAUOMJN, MIPJUDMQGR, XNWEKWGCKM);
        } catch (Throwable e) {
            BZOSEITDHX = new SpillRecord(0);
            JLBOVKECEW.remove(WVVLWNCBUF);
            throw new IOException("Error Reading IndexFile", e);
        } finally {
            synchronized(YENGACGXHS) {
                YENGACGXHS.BXDTQJLAUZ = BZOSEITDHX;
                YENGACGXHS.notifyAll();
            }
        }
        DJXFENJACV.add(WVVLWNCBUF);
        if (QHYFCAMRNU.addAndGet(YENGACGXHS.getSize()) > NWOPSEEOXJ) {
            freeIndexInformation();
        }
        return YENGACGXHS;
    }

    /**
     * This method removes the map from the cache if index information for this
     * map is loaded(size>0), index information entry in cache will not be
     * removed if it is in the loading phrase(size=0), this prevents corruption
     * of totalMemoryUsed. It should be called when a map output on this tracker
     * is discarded.
     *
     * @param mapId
     * 		The taskID of this map.
     */
    public void removeMap(String ZZMQQCNVKD) {
        IndexCache.IndexInformation QXMJMGPNSU = JLBOVKECEW.get(ZZMQQCNVKD);
        if ((QXMJMGPNSU == null) || ((QXMJMGPNSU != null) && isUnderConstruction(QXMJMGPNSU))) {
            return;
        }
        QXMJMGPNSU = JLBOVKECEW.remove(ZZMQQCNVKD);
        if (QXMJMGPNSU != null) {
            QHYFCAMRNU.addAndGet(-QXMJMGPNSU.getSize());
            if (!DJXFENJACV.remove(ZZMQQCNVKD)) {
                IndexCache.VXUSIQMVDK.warn(("Map ID" + ZZMQQCNVKD) + " not found in queue!!");
            }
        } else {
            IndexCache.VXUSIQMVDK.info(("Map ID " + ZZMQQCNVKD) + " not found in cache");
        }
    }

    /**
     * This method checks if cache and totolMemoryUsed is consistent.
     * It is only used for unit test.
     *
     * @return True if cache and totolMemoryUsed is consistent
     */
    boolean checkTotalMemoryUsed() {
        int JHVFDGJCLV = 0;
        for (IndexCache.IndexInformation YZMJZEVRJW : JLBOVKECEW.values()) {
            JHVFDGJCLV += YZMJZEVRJW.getSize();
        }
        return JHVFDGJCLV == QHYFCAMRNU.get();
    }

    /**
     * Bring memory usage below totalMemoryAllowed.
     */
    private synchronized void freeIndexInformation() {
        while (QHYFCAMRNU.get() > NWOPSEEOXJ) {
            String JEPHIDFVBX = DJXFENJACV.remove();
            IndexCache.IndexInformation DOQPPYIZOQ = JLBOVKECEW.remove(JEPHIDFVBX);
            if (DOQPPYIZOQ != null) {
                QHYFCAMRNU.addAndGet(-DOQPPYIZOQ.getSize());
            }
        } 
    }

    private static class IndexInformation {
        SpillRecord BXDTQJLAUZ;

        int getSize() {
            return BXDTQJLAUZ == null ? 0 : BXDTQJLAUZ.size() * MapTask.MAP_OUTPUT_INDEX_RECORD_LENGTH;
        }
    }
}