/**
 * Information about TaskTracker.
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class TaskTrackerInfo implements Writable {
    String OWIOGIZRKS;

    boolean IJVSPECSUJ = false;

    String HHHBPJCQZT = "";

    String CVOBUFZETB = "";

    public TaskTrackerInfo() {
    }

    // construct an active tracker
    public TaskTrackerInfo(String OHTEJTENFS) {
        this.OWIOGIZRKS = OHTEJTENFS;
    }

    // construct blacklisted tracker
    public TaskTrackerInfo(String PLBWWFJUWW, String QXWZMNLSEZ, String ZEGKXLNXFE) {
        this.OWIOGIZRKS = PLBWWFJUWW;
        this.IJVSPECSUJ = true;
        this.HHHBPJCQZT = QXWZMNLSEZ;
        this.CVOBUFZETB = ZEGKXLNXFE;
    }

    /**
     * Gets the tasktracker's name.
     *
     * @return tracker's name.
     */
    public String getTaskTrackerName() {
        return OWIOGIZRKS;
    }

    /**
     * Whether tracker is blacklisted
     *
     * @return true if tracker is blacklisted
    false otherwise
     */
    public boolean isBlacklisted() {
        return IJVSPECSUJ;
    }

    /**
     * Gets the reason for which the tasktracker was blacklisted.
     *
     * @return reason which tracker was blacklisted
     */
    public String getReasonForBlacklist() {
        return HHHBPJCQZT;
    }

    /**
     * Gets a descriptive report about why the tasktracker was blacklisted.
     *
     * @return report describing why the tasktracker was blacklisted.
     */
    public String getBlacklistReport() {
        return CVOBUFZETB;
    }

    @Override
    public void readFields(DataInput YPHWXMSHTA) throws IOException {
        OWIOGIZRKS = Text.readString(YPHWXMSHTA);
        IJVSPECSUJ = YPHWXMSHTA.readBoolean();
        HHHBPJCQZT = Text.readString(YPHWXMSHTA);
        CVOBUFZETB = Text.readString(YPHWXMSHTA);
    }

    @Override
    public void write(DataOutput LURDKGSMRY) throws IOException {
        Text.writeString(LURDKGSMRY, OWIOGIZRKS);
        LURDKGSMRY.writeBoolean(IJVSPECSUJ);
        Text.writeString(LURDKGSMRY, HHHBPJCQZT);
        Text.writeString(LURDKGSMRY, CVOBUFZETB);
    }
}