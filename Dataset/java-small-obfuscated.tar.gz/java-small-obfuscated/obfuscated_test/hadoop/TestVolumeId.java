public class TestVolumeId {
    @Test
    public void testEquality() {
        final VolumeId TFTQLOXXBM = new HdfsVolumeId(new byte[]{ ((byte) (0)), ((byte) (0)) });
        testEq(true, TFTQLOXXBM, TFTQLOXXBM);
        final VolumeId AGERMMWKDA = new HdfsVolumeId(new byte[]{ ((byte) (0)), ((byte) (1)) });
        testEq(true, AGERMMWKDA, AGERMMWKDA);
        testEq(false, TFTQLOXXBM, AGERMMWKDA);
        final VolumeId WLNTFWTNNR = new HdfsVolumeId(new byte[]{ ((byte) (1)), ((byte) (0)) });
        testEq(true, WLNTFWTNNR, WLNTFWTNNR);
        testEq(false, TFTQLOXXBM, WLNTFWTNNR);
        // same as 2, but "invalid":
        final VolumeId JYEEUIJRRO = new HdfsVolumeId(new byte[]{ ((byte) (0)), ((byte) (1)) });
        testEq(true, AGERMMWKDA, JYEEUIJRRO);
        // same as 2copy1:
        final VolumeId GWAWSGCHRW = new HdfsVolumeId(new byte[]{ ((byte) (0)), ((byte) (1)) });
        testEq(true, AGERMMWKDA, GWAWSGCHRW);
        testEqMany(true, new VolumeId[]{ AGERMMWKDA, JYEEUIJRRO, GWAWSGCHRW });
        testEqMany(false, new VolumeId[]{ TFTQLOXXBM, AGERMMWKDA, WLNTFWTNNR });
    }

    @SuppressWarnings("unchecked")
    private <T> void testEq(final boolean AQMTOJGXYY, Comparable<T> HEJEPWGTFZ, Comparable<T> WSTVQFCWUL) {
        final int DMSVGAZQZE = HEJEPWGTFZ.hashCode();
        final int FVRLBXJPVJ = WSTVQFCWUL.hashCode();
        // eq reflectivity:
        assertTrue(HEJEPWGTFZ.equals(HEJEPWGTFZ));
        assertTrue(WSTVQFCWUL.equals(WSTVQFCWUL));
        assertEquals(0, HEJEPWGTFZ.compareTo(((T) (HEJEPWGTFZ))));
        assertEquals(0, WSTVQFCWUL.compareTo(((T) (WSTVQFCWUL))));
        // eq symmetry:
        assertEquals(AQMTOJGXYY, HEJEPWGTFZ.equals(WSTVQFCWUL));
        assertEquals(AQMTOJGXYY, WSTVQFCWUL.equals(HEJEPWGTFZ));
        // null comparison:
        assertFalse(HEJEPWGTFZ.equals(null));
        assertFalse(WSTVQFCWUL.equals(null));
        // compareTo:
        assertEquals(AQMTOJGXYY, 0 == HEJEPWGTFZ.compareTo(((T) (WSTVQFCWUL))));
        assertEquals(AQMTOJGXYY, 0 == WSTVQFCWUL.compareTo(((T) (HEJEPWGTFZ))));
        // compareTo must be antisymmetric:
        assertEquals(TestVolumeId.sign(HEJEPWGTFZ.compareTo(((T) (WSTVQFCWUL)))), -TestVolumeId.sign(WSTVQFCWUL.compareTo(((T) (HEJEPWGTFZ)))));
        // compare with null should never return 0 to be consistent with #equals():
        assertTrue(HEJEPWGTFZ.compareTo(null) != 0);
        assertTrue(WSTVQFCWUL.compareTo(null) != 0);
        // check that hash codes did not change:
        assertEquals(DMSVGAZQZE, HEJEPWGTFZ.hashCode());
        assertEquals(FVRLBXJPVJ, WSTVQFCWUL.hashCode());
        if (AQMTOJGXYY) {
            // in this case the hash codes must be the same:
            assertEquals(DMSVGAZQZE, FVRLBXJPVJ);
        }
    }

    private static int sign(int WKMFOBKEDV) {
        if (WKMFOBKEDV == 0) {
            return 0;
        } else
            if (WKMFOBKEDV > 0) {
                return 1;
            } else {
                return -1;
            }

    }

    @SuppressWarnings("unchecked")
    private <T> void testEqMany(final boolean FRMWUVRJHZ, Comparable<T>... IMIESFFLDE) {
        Comparable<T> XJGPGOJWIO;
        int OBGBEDSWID = 0;
        for (int CXPAYXCFUI = 0; CXPAYXCFUI < IMIESFFLDE.length; CXPAYXCFUI++) {
            if (CXPAYXCFUI == (IMIESFFLDE.length - 1)) {
                XJGPGOJWIO = IMIESFFLDE[0];
            } else {
                XJGPGOJWIO = IMIESFFLDE[CXPAYXCFUI + 1];
            }
            testEq(FRMWUVRJHZ, IMIESFFLDE[CXPAYXCFUI], XJGPGOJWIO);
            OBGBEDSWID += TestVolumeId.sign(IMIESFFLDE[CXPAYXCFUI].compareTo(((T) (XJGPGOJWIO))));
        }
        // the comparison relationship must always be acyclic:
        assertTrue(OBGBEDSWID < IMIESFFLDE.length);
    }

    /* Test HdfsVolumeId(new byte[0]) instances: show that we permit such
    objects, they are still valid, and obey the same equality
    rules other objects do.
     */
    @Test
    public void testIdEmptyBytes() {
        final VolumeId MKRHLQWFOK = new HdfsVolumeId(new byte[0]);
        final VolumeId EMHTAVWQEF = new HdfsVolumeId(new byte[0]);
        final VolumeId CNQQMWPRKZ = new HdfsVolumeId(new byte[]{ ((byte) (1)) });
        testEq(true, MKRHLQWFOK, EMHTAVWQEF);
        testEq(false, MKRHLQWFOK, CNQQMWPRKZ);
        testEq(false, EMHTAVWQEF, CNQQMWPRKZ);
    }

    /* test #toString() for typical VolumeId equality classes */
    @Test
    public void testToString() {
        String TNFTZGLNYQ = new HdfsVolumeId(new byte[]{  }).toString();
        assertNotNull(TNFTZGLNYQ);
        String WZBHRKHNWM = new HdfsVolumeId(new byte[]{ ((byte) (1)) }).toString();
        assertNotNull(WZBHRKHNWM);
    }
}