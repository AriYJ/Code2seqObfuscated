public class TestHDFSFileContextMainOperations extends FileContextMainOperationsBaseTest {
    private static MiniDFSCluster JKHLFREYYO;

    private static Path DQJPEZARRU;

    private static final HdfsConfiguration QCYWJNTXLS = new HdfsConfiguration();

    @Override
    protected FileContextTestHelper createFileContextHelper() {
        return new FileContextTestHelper("/tmp/TestHDFSFileContextMainOperations");
    }

    @BeforeClass
    public static void clusterSetupAtBegining() throws IOException, URISyntaxException, LoginException {
        TestHDFSFileContextMainOperations.JKHLFREYYO = new MiniDFSCluster.Builder(TestHDFSFileContextMainOperations.QCYWJNTXLS).numDataNodes(2).build();
        TestHDFSFileContextMainOperations.JKHLFREYYO.waitClusterUp();
        URI YIMWVWGECD = TestHDFSFileContextMainOperations.JKHLFREYYO.getURI(0);
        fc = FileContext.getFileContext(YIMWVWGECD, TestHDFSFileContextMainOperations.QCYWJNTXLS);
        TestHDFSFileContextMainOperations.DQJPEZARRU = fc.makeQualified(new Path("/user/" + org.apache.hadoop.security.UserGroupInformation.getCurrentUser().getShortUserName()));
        fc.mkdir(TestHDFSFileContextMainOperations.DQJPEZARRU, DEFAULT_PERM, true);
    }

    private static void restartCluster() throws IOException, LoginException {
        if (TestHDFSFileContextMainOperations.JKHLFREYYO != null) {
            TestHDFSFileContextMainOperations.JKHLFREYYO.shutdown();
            TestHDFSFileContextMainOperations.JKHLFREYYO = null;
        }
        TestHDFSFileContextMainOperations.JKHLFREYYO = new MiniDFSCluster.Builder(TestHDFSFileContextMainOperations.QCYWJNTXLS).numDataNodes(1).format(false).build();
        TestHDFSFileContextMainOperations.JKHLFREYYO.waitClusterUp();
        fc = FileContext.getFileContext(TestHDFSFileContextMainOperations.JKHLFREYYO.getURI(0), TestHDFSFileContextMainOperations.QCYWJNTXLS);
        TestHDFSFileContextMainOperations.DQJPEZARRU = fc.makeQualified(new Path("/user/" + org.apache.hadoop.security.UserGroupInformation.getCurrentUser().getShortUserName()));
        fc.mkdir(TestHDFSFileContextMainOperations.DQJPEZARRU, DEFAULT_PERM, true);
    }

    @AfterClass
    public static void ClusterShutdownAtEnd() throws Exception {
        if (TestHDFSFileContextMainOperations.JKHLFREYYO != null) {
            TestHDFSFileContextMainOperations.JKHLFREYYO.shutdown();
            TestHDFSFileContextMainOperations.JKHLFREYYO = null;
        }
    }

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Override
    @After
    public void tearDown() throws Exception {
        super.tearDown();
    }

    @Override
    protected Path getDefaultWorkingDirectory() {
        return TestHDFSFileContextMainOperations.DQJPEZARRU;
    }

    @Override
    protected IOException unwrapException(IOException YJEYHSNGLK) {
        if (YJEYHSNGLK instanceof RemoteException) {
            return ((RemoteException) (YJEYHSNGLK)).unwrapRemoteException();
        }
        return YJEYHSNGLK;
    }

    private Path getTestRootPath(FileContext SUMZIXZTEY, String ACMZNSDBPB) {
        return fileContextTestHelper.getTestRootPath(SUMZIXZTEY, ACMZNSDBPB);
    }

    @Test
    public void testOldRenameWithQuota() throws Exception {
        DistributedFileSystem RJYXOZWGXH = TestHDFSFileContextMainOperations.JKHLFREYYO.getFileSystem();
        Path WPINIWXMTL = getTestRootPath(fc, "test/testOldRenameWithQuota/srcdir/src1");
        Path SUQOXTQCEK = getTestRootPath(fc, "test/testOldRenameWithQuota/srcdir/src2");
        Path NTBXWBDFBF = getTestRootPath(fc, "test/testOldRenameWithQuota/dstdir/dst1");
        Path HFUAZNBDKO = getTestRootPath(fc, "test/testOldRenameWithQuota/dstdir/dst2");
        createFile(WPINIWXMTL);
        createFile(SUQOXTQCEK);
        RJYXOZWGXH.setQuota(WPINIWXMTL.getParent(), QUOTA_DONT_SET, QUOTA_DONT_SET);
        fc.mkdir(NTBXWBDFBF.getParent(), DEFAULT_PERM, true);
        RJYXOZWGXH.setQuota(NTBXWBDFBF.getParent(), 2, QUOTA_DONT_SET);
        /* Test1: src does not exceed quota and dst has no quota check and hence 
        accommodates rename
         */
        oldRename(WPINIWXMTL, NTBXWBDFBF, true, false);
        /* Test2: src does not exceed quota and dst has *no* quota to accommodate 
        rename.
         */
        // dstDir quota = 1 and dst1 already uses it
        oldRename(SUQOXTQCEK, HFUAZNBDKO, false, true);
        /* Test3: src exceeds quota and dst has *no* quota to accommodate rename */
        // src1 has no quota to accommodate new rename node
        RJYXOZWGXH.setQuota(WPINIWXMTL.getParent(), 1, QUOTA_DONT_SET);
        oldRename(NTBXWBDFBF, WPINIWXMTL, false, true);
    }

    @Test
    public void testRenameWithQuota() throws Exception {
        DistributedFileSystem CSEBWETLKY = TestHDFSFileContextMainOperations.JKHLFREYYO.getFileSystem();
        Path XRGOBMOIWF = getTestRootPath(fc, "test/testRenameWithQuota/srcdir/src1");
        Path DBFTCDJQST = getTestRootPath(fc, "test/testRenameWithQuota/srcdir/src2");
        Path ZDOGFLMMMB = getTestRootPath(fc, "test/testRenameWithQuota/dstdir/dst1");
        Path UJSWMFRRAV = getTestRootPath(fc, "test/testRenameWithQuota/dstdir/dst2");
        createFile(XRGOBMOIWF);
        createFile(DBFTCDJQST);
        CSEBWETLKY.setQuota(XRGOBMOIWF.getParent(), QUOTA_DONT_SET, QUOTA_DONT_SET);
        fc.mkdir(ZDOGFLMMMB.getParent(), DEFAULT_PERM, true);
        CSEBWETLKY.setQuota(ZDOGFLMMMB.getParent(), 2, QUOTA_DONT_SET);
        /* Test1: src does not exceed quota and dst has no quota check and hence 
        accommodates rename
         */
        // rename uses dstdir quota=1
        rename(XRGOBMOIWF, ZDOGFLMMMB, false, true, false, NONE);
        // rename reuses dstdir quota=1
        rename(DBFTCDJQST, ZDOGFLMMMB, true, true, false, OVERWRITE);
        /* Test2: src does not exceed quota and dst has *no* quota to accommodate 
        rename.
         */
        // dstDir quota = 1 and dst1 already uses it
        createFile(DBFTCDJQST);
        rename(DBFTCDJQST, UJSWMFRRAV, false, false, true, NONE);
        /* Test3: src exceeds quota and dst has *no* quota to accommodate rename
        rename to a destination that does not exist
         */
        // src1 has no quota to accommodate new rename node
        CSEBWETLKY.setQuota(XRGOBMOIWF.getParent(), 1, QUOTA_DONT_SET);
        rename(ZDOGFLMMMB, XRGOBMOIWF, false, false, true, NONE);
        /* Test4: src exceeds quota and dst has *no* quota to accommodate rename
        rename to a destination that exists and quota freed by deletion of dst
        is same as quota needed by src.
         */
        // src1 has no quota to accommodate new rename node
        CSEBWETLKY.setQuota(XRGOBMOIWF.getParent(), 100, QUOTA_DONT_SET);
        createFile(XRGOBMOIWF);
        CSEBWETLKY.setQuota(XRGOBMOIWF.getParent(), 1, QUOTA_DONT_SET);
        rename(ZDOGFLMMMB, XRGOBMOIWF, true, true, false, OVERWRITE);
    }

    @Test
    public void testRenameRoot() throws Exception {
        Path MQHHVZPTWJ = getTestRootPath(fc, "test/testRenameRoot/srcdir/src1");
        Path FPWYHMYWXK = new Path("/");
        createFile(MQHHVZPTWJ);
        rename(MQHHVZPTWJ, FPWYHMYWXK, true, false, true, OVERWRITE);
        rename(FPWYHMYWXK, MQHHVZPTWJ, true, false, true, OVERWRITE);
    }

    /**
     * Perform operations such as setting quota, deletion of files, rename and
     * ensure system can apply edits log during startup.
     */
    @Test
    public void testEditsLogOldRename() throws Exception {
        DistributedFileSystem MQELEAKLAP = TestHDFSFileContextMainOperations.JKHLFREYYO.getFileSystem();
        Path JOUAZMXCWS = getTestRootPath(fc, "testEditsLogOldRename/srcdir/src1");
        Path JQUAXSPSPU = getTestRootPath(fc, "testEditsLogOldRename/dstdir/dst1");
        createFile(JOUAZMXCWS);
        MQELEAKLAP.mkdirs(JQUAXSPSPU.getParent());
        createFile(JQUAXSPSPU);
        // Set quota so that dst1 parent cannot allow under it new files/directories
        MQELEAKLAP.setQuota(JQUAXSPSPU.getParent(), 2, QUOTA_DONT_SET);
        // Free up quota for a subsequent rename
        MQELEAKLAP.delete(JQUAXSPSPU, true);
        oldRename(JOUAZMXCWS, JQUAXSPSPU, true, false);
        // Restart the cluster and ensure the above operations can be
        // loaded from the edits log
        TestHDFSFileContextMainOperations.restartCluster();
        MQELEAKLAP = TestHDFSFileContextMainOperations.JKHLFREYYO.getFileSystem();
        JOUAZMXCWS = getTestRootPath(fc, "testEditsLogOldRename/srcdir/src1");
        JQUAXSPSPU = getTestRootPath(fc, "testEditsLogOldRename/dstdir/dst1");
        Assert.assertFalse(MQELEAKLAP.exists(JOUAZMXCWS));// ensure src1 is already renamed

        Assert.assertTrue(MQELEAKLAP.exists(JQUAXSPSPU));// ensure rename dst exists

    }

    /**
     * Perform operations such as setting quota, deletion of files, rename and
     * ensure system can apply edits log during startup.
     */
    @Test
    public void testEditsLogRename() throws Exception {
        DistributedFileSystem HNHQJTLMQK = TestHDFSFileContextMainOperations.JKHLFREYYO.getFileSystem();
        Path UERYIYOWPJ = getTestRootPath(fc, "testEditsLogRename/srcdir/src1");
        Path AECKYPMFPQ = getTestRootPath(fc, "testEditsLogRename/dstdir/dst1");
        createFile(UERYIYOWPJ);
        HNHQJTLMQK.mkdirs(AECKYPMFPQ.getParent());
        createFile(AECKYPMFPQ);
        // Set quota so that dst1 parent cannot allow under it new files/directories
        HNHQJTLMQK.setQuota(AECKYPMFPQ.getParent(), 2, QUOTA_DONT_SET);
        // Free up quota for a subsequent rename
        HNHQJTLMQK.delete(AECKYPMFPQ, true);
        rename(UERYIYOWPJ, AECKYPMFPQ, true, true, false, OVERWRITE);
        // Restart the cluster and ensure the above operations can be
        // loaded from the edits log
        TestHDFSFileContextMainOperations.restartCluster();
        HNHQJTLMQK = TestHDFSFileContextMainOperations.JKHLFREYYO.getFileSystem();
        UERYIYOWPJ = getTestRootPath(fc, "testEditsLogRename/srcdir/src1");
        AECKYPMFPQ = getTestRootPath(fc, "testEditsLogRename/dstdir/dst1");
        Assert.assertFalse(HNHQJTLMQK.exists(UERYIYOWPJ));// ensure src1 is already renamed

        Assert.assertTrue(HNHQJTLMQK.exists(AECKYPMFPQ));// ensure rename dst exists

    }

    @Test
    public void testIsValidNameInvalidNames() {
        String[] WZZVRUFTSB = new String[]{ "/foo/../bar", "/foo/./bar", "/foo/:/bar", "/foo:bar" };
        for (String LJLRJOUWYM : WZZVRUFTSB) {
            Assert.assertFalse(LJLRJOUWYM + " is not valid", fc.getDefaultFileSystem().isValidName(LJLRJOUWYM));
        }
    }

    private void oldRename(Path ELBPVKMGPK, Path DIRDHVNNFN, boolean NVPVTFDEZY, boolean TNBFNJVTTT) throws Exception {
        DistributedFileSystem MVKONDWPVK = TestHDFSFileContextMainOperations.JKHLFREYYO.getFileSystem();
        try {
            Assert.assertEquals(NVPVTFDEZY, MVKONDWPVK.rename(ELBPVKMGPK, DIRDHVNNFN));
        } catch (Exception ex) {
            Assert.assertTrue(TNBFNJVTTT);
        }
        Assert.assertEquals(NVPVTFDEZY, !FileContextTestHelper.exists(fc, ELBPVKMGPK));
        Assert.assertEquals(NVPVTFDEZY, FileContextTestHelper.exists(fc, DIRDHVNNFN));
    }

    private void rename(Path OYFQQCDLIB, Path CTDWTZZHCM, boolean MNKLFWVQPY, boolean DTNPJBGFBX, boolean LLXTGEPRLN, Options... GRAJGOTNYG) throws Exception {
        try {
            fc.rename(OYFQQCDLIB, CTDWTZZHCM, GRAJGOTNYG);
            Assert.assertTrue(DTNPJBGFBX);
        } catch (Exception ex) {
            Assert.assertTrue(LLXTGEPRLN);
        }
        Assert.assertEquals(DTNPJBGFBX, !FileContextTestHelper.exists(fc, OYFQQCDLIB));
        Assert.assertEquals(MNKLFWVQPY || DTNPJBGFBX, FileContextTestHelper.exists(fc, CTDWTZZHCM));
    }

    @Override
    protected boolean listCorruptedBlocksSupported() {
        return true;
    }

    @Test
    public void testCrossFileSystemRename() throws IOException {
        try {
            fc.rename(new Path("hdfs://127.0.0.1/aaa/bbb/Foo"), new Path("file://aaa/bbb/Moo"), Options.Rename.OVERWRITE);
            fail("IOexception expected.");
        } catch (IOException ioe) {
            // okay
        }
    }
}