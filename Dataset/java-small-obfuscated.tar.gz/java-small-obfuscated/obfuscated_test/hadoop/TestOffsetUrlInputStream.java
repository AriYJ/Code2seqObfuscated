public class TestOffsetUrlInputStream {
    @Test
    public void testRemoveOffset() throws IOException {
        {
            // no offset
            String FGNMNURRND = "http://test/Abc?Length=99";
            assertEquals(FGNMNURRND, WebHdfsFileSystem.removeOffsetParam(new URL(FGNMNURRND)).toString());
        }
        {
            // no parameters
            String KHPJTJHSXZ = "http://test/Abc";
            assertEquals(KHPJTJHSXZ, WebHdfsFileSystem.removeOffsetParam(new URL(KHPJTJHSXZ)).toString());
        }
        {
            // offset as first parameter
            String AFZBJJKUMD = "http://test/Abc?offset=10&Length=99";
            assertEquals("http://test/Abc?Length=99", WebHdfsFileSystem.removeOffsetParam(new URL(AFZBJJKUMD)).toString());
        }
        {
            // offset as second parameter
            String IWWKOJWQQN = "http://test/Abc?op=read&OFFset=10&Length=99";
            assertEquals("http://test/Abc?op=read&Length=99", WebHdfsFileSystem.removeOffsetParam(new URL(IWWKOJWQQN)).toString());
        }
        {
            // offset as last parameter
            String CLYEKPNWEJ = "http://test/Abc?Length=99&offset=10";
            assertEquals("http://test/Abc?Length=99", WebHdfsFileSystem.removeOffsetParam(new URL(CLYEKPNWEJ)).toString());
        }
        {
            // offset as the only parameter
            String ZJABRSAVWM = "http://test/Abc?offset=10";
            assertEquals("http://test/Abc", WebHdfsFileSystem.removeOffsetParam(new URL(ZJABRSAVWM)).toString());
        }
    }
}