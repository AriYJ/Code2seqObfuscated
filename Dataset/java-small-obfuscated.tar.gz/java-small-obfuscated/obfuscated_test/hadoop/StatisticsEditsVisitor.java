/**
 * StatisticsEditsVisitor implements text version of EditsVisitor
 * that aggregates counts of op codes processed
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class StatisticsEditsVisitor implements OfflineEditsVisitor {
    private final PrintWriter NWIOMOXNVW;

    private int JYPKSHXHBY = -1;

    private final Map<FSEditLogOpCodes, Long> AXVZMFVALC = new HashMap<FSEditLogOpCodes, Long>();

    /**
     * Create a processor that writes to the file named and may or may not
     * also output to the screen, as specified.
     *
     * @param filename
     * 		Name of file to write output to
     * @param tokenizer
     * 		Input tokenizer
     * @param printToScreen
     * 		Mirror output to screen?
     */
    public StatisticsEditsVisitor(OutputStream AGKQIAZIJT) throws IOException {
        this.NWIOMOXNVW = new PrintWriter(new OutputStreamWriter(AGKQIAZIJT, Charsets.UTF_8));
    }

    /**
     * Start the visitor
     */
    @Override
    public void start(int PSPXQRCXSM) throws IOException {
        this.JYPKSHXHBY = PSPXQRCXSM;
    }

    /**
     * Close the visitor
     */
    @Override
    public void close(Throwable AEPEEPMFKP) throws IOException {
        NWIOMOXNVW.print(getStatisticsString());
        if (AEPEEPMFKP != null) {
            NWIOMOXNVW.print(("EXITING ON ERROR: " + AEPEEPMFKP.toString()) + "\n");
        }
        NWIOMOXNVW.close();
    }

    @Override
    public void visitOp(FSEditLogOp MVQSWEPWBC) throws IOException {
        incrementOpCodeCount(MVQSWEPWBC.opCode);
    }

    /**
     * Increment the op code counter
     *
     * @param opCode
     * 		opCode for which to increment count
     */
    private void incrementOpCodeCount(FSEditLogOpCodes KTMKPBWIUA) {
        if (!AXVZMFVALC.containsKey(KTMKPBWIUA)) {
            AXVZMFVALC.put(KTMKPBWIUA, 0L);
        }
        Long XKVXNLLNTS = AXVZMFVALC.get(KTMKPBWIUA) + 1;
        AXVZMFVALC.put(KTMKPBWIUA, XKVXNLLNTS);
    }

    /**
     * Get statistics
     *
     * @return statistics, map of counts per opCode
     */
    public Map<FSEditLogOpCodes, Long> getStatistics() {
        return AXVZMFVALC;
    }

    /**
     * Get the statistics in string format, suitable for printing
     *
     * @return statistics in in string format, suitable for printing
     */
    public String getStatisticsString() {
        StringBuffer NUYXFPPHXV = new StringBuffer();
        NUYXFPPHXV.append(String.format("    %-30.30s      : %d%n", "VERSION", JYPKSHXHBY));
        for (FSEditLogOpCodes HEMRCYFOWI : FSEditLogOpCodes.values()) {
            NUYXFPPHXV.append(String.format("    %-30.30s (%3d): %d%n", HEMRCYFOWI.toString(), HEMRCYFOWI.getOpCode(), AXVZMFVALC.get(HEMRCYFOWI)));
        }
        return NUYXFPPHXV.toString();
    }
}