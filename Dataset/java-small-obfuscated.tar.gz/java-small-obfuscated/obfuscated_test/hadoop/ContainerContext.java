/**
 * Base context class for {@link AuxiliaryService} initializing and stopping a
 * container.
 */
@Public
@Evolving
public class ContainerContext {
    private final String WNBWMFDBUR;

    private final ContainerId GHUETMXZRF;

    private final Resource CBEFSLRGAR;

    @Private
    @Unstable
    public ContainerContext(String XEPDTFFFNU, ContainerId IWRKJPYSJG, Resource YZRDQVMWVM) {
        this.WNBWMFDBUR = XEPDTFFFNU;
        this.GHUETMXZRF = IWRKJPYSJG;
        this.CBEFSLRGAR = YZRDQVMWVM;
    }

    /**
     * Get user of the container being initialized or stopped.
     *
     * @return the user
     */
    public String getUser() {
        return WNBWMFDBUR;
    }

    /**
     * Get {@link ContainerId} of the container being initialized or stopped.
     *
     * @return the container ID
     */
    public ContainerId getContainerId() {
        return GHUETMXZRF;
    }

    /**
     * Get {@link Resource} the resource capability allocated to the container
     * being initialized or stopped.
     *
     * @return the resource capability.
     */
    public Resource getResource() {
        return CBEFSLRGAR;
    }
}