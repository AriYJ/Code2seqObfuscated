/**
 * This class tests the creation and validation of a checkpoint.
 */
public class TestSecurityTokenEditLog {
    static final int ONNZACNZNH = 1;

    // This test creates NUM_THREADS threads and each thread does
    // 2 * NUM_TRANSACTIONS Transactions concurrently.
    static final int UGTHEQJIFJ = 100;

    static final int BWYNUCKNJL = 100;

    static final int KTEFHYQUDI = 3;

    static {
        // No need to fsync for the purposes of tests. This makes
        // the tests run much faster.
        EditLogFileOutputStream.setShouldSkipFsyncForTesting(true);
    }

    // 
    // an object that does a bunch of transactions
    // 
    static class Transactions implements Runnable {
        final FSNamesystem LQTYLIKVIO;

        final int QPPYWVRPCL;

        short MXFSOLSMPY = 3;

        long RWQCYUPKRR = 64;

        Transactions(FSNamesystem ns, int num) {
            LQTYLIKVIO = ns;
            QPPYWVRPCL = num;
        }

        // add a bunch of transactions.
        @Override
        public void run() {
            FSEditLog editLog = LQTYLIKVIO.getEditLog();
            for (int i = 0; i < QPPYWVRPCL; i++) {
                try {
                    String renewer = org.apache.hadoop.security.UserGroupInformation.getLoginUser().getUserName();
                    Token<DelegationTokenIdentifier> token = LQTYLIKVIO.getDelegationToken(new Text(renewer));
                    LQTYLIKVIO.renewDelegationToken(token);
                    LQTYLIKVIO.cancelDelegationToken(token);
                    editLog.logSync();
                } catch (IOException e) {
                    System.out.println((("Transaction " + i) + " encountered exception ") + e);
                }
            }
        }
    }

    /**
     * Tests transaction logging in dfs.
     */
    @Test
    public void testEditLog() throws IOException {
        // start a cluster
        Configuration MORRKBHODM = new HdfsConfiguration();
        MiniDFSCluster WNZQLPFJNW = null;
        FileSystem KYVSVFQOOU = null;
        try {
            MORRKBHODM.setBoolean(DFS_NAMENODE_DELEGATION_TOKEN_ALWAYS_USE_KEY, true);
            WNZQLPFJNW = new MiniDFSCluster.Builder(MORRKBHODM).numDataNodes(TestSecurityTokenEditLog.ONNZACNZNH).build();
            WNZQLPFJNW.waitActive();
            KYVSVFQOOU = WNZQLPFJNW.getFileSystem();
            final FSNamesystem KOIGIITNKG = WNZQLPFJNW.getNamesystem();
            for (Iterator<URI> TDLUMWWPPT = WNZQLPFJNW.getNameDirs(0).iterator(); TDLUMWWPPT.hasNext();) {
                File XVTSELDHTY = new File(TDLUMWWPPT.next().getPath());
                System.out.println(XVTSELDHTY);
            }
            FSImage UOXUJXXEJM = KOIGIITNKG.getFSImage();
            FSEditLog ACMPCTIVZX = UOXUJXXEJM.getEditLog();
            // set small size of flush buffer
            ACMPCTIVZX.setOutputBufferCapacity(2048);
            // Create threads and make them run transactions concurrently.
            Thread[] ZBJAQFKMUV = new Thread[TestSecurityTokenEditLog.BWYNUCKNJL];
            for (int JCHBMVSMGF = 0; JCHBMVSMGF < TestSecurityTokenEditLog.BWYNUCKNJL; JCHBMVSMGF++) {
                TestSecurityTokenEditLog.Transactions ZIHMNTZNJW = new TestSecurityTokenEditLog.Transactions(KOIGIITNKG, TestSecurityTokenEditLog.UGTHEQJIFJ);
                ZBJAQFKMUV[JCHBMVSMGF] = new Thread(ZIHMNTZNJW, "TransactionThread-" + JCHBMVSMGF);
                ZBJAQFKMUV[JCHBMVSMGF].start();
            }
            // wait for all transactions to get over
            for (int LABWXXXJCA = 0; LABWXXXJCA < TestSecurityTokenEditLog.BWYNUCKNJL; LABWXXXJCA++) {
                try {
                    ZBJAQFKMUV[LABWXXXJCA].join();
                } catch (InterruptedException e) {
                    LABWXXXJCA--;// retry

                }
            }
            ACMPCTIVZX.close();
            // Verify that we can read in all the transactions that we have written.
            // If there were any corruptions, it is likely that the reading in
            // of these transactions will throw an exception.
            // 
            KOIGIITNKG.getDelegationTokenSecretManager().stopThreads();
            int JZQFCCWYUD = KOIGIITNKG.getDelegationTokenSecretManager().getNumberOfKeys();
            int YKNHKJQYNS = (((TestSecurityTokenEditLog.BWYNUCKNJL * TestSecurityTokenEditLog.KTEFHYQUDI) * TestSecurityTokenEditLog.UGTHEQJIFJ) + JZQFCCWYUD) + 2;// + 2 for BEGIN and END txns

            for (StorageDirectory WUSAKHXZSC : UOXUJXXEJM.getStorage().dirIterable(NameNodeDirType.EDITS)) {
                File GEWWNXAKVH = NNStorage.getFinalizedEditsFile(WUSAKHXZSC, 1, (1 + YKNHKJQYNS) - 1);
                System.out.println("Verifying file: " + GEWWNXAKVH);
                FSEditLogLoader DRHZWVDHQJ = new FSEditLogLoader(KOIGIITNKG, 0);
                long IRVYCLPFNF = DRHZWVDHQJ.loadFSEdits(new EditLogFileInputStream(GEWWNXAKVH), 1);
                assertEquals("Verification for " + GEWWNXAKVH, YKNHKJQYNS, IRVYCLPFNF);
            }
        } finally {
            if (KYVSVFQOOU != null)
                KYVSVFQOOU.close();

            if (WNZQLPFJNW != null)
                WNZQLPFJNW.shutdown();

        }
    }

    @Test(timeout = 10000)
    public void testEditsForCancelOnTokenExpire() throws IOException, InterruptedException {
        long ITAYOIBWDG = 2000;
        Configuration IYUBBSRDNC = new Configuration();
        IYUBBSRDNC.setBoolean(DFS_NAMENODE_DELEGATION_TOKEN_ALWAYS_USE_KEY, true);
        IYUBBSRDNC.setLong(DFS_NAMENODE_DELEGATION_TOKEN_RENEW_INTERVAL_KEY, ITAYOIBWDG);
        IYUBBSRDNC.setLong(DFS_NAMENODE_DELEGATION_TOKEN_MAX_LIFETIME_KEY, ITAYOIBWDG * 2);
        Text CQFCLEEESD = new Text(org.apache.hadoop.security.UserGroupInformation.getCurrentUser().getUserName());
        FSImage NMHYNITQEM = mock(FSImage.class);
        FSEditLog IDCZQGBUXE = mock(FSEditLog.class);
        doReturn(IDCZQGBUXE).when(NMHYNITQEM).getEditLog();
        FSNamesystem WGNVNSCMFX = new FSNamesystem(IYUBBSRDNC, NMHYNITQEM);
        DelegationTokenSecretManager RAUMTJCTXJ = WGNVNSCMFX.getDelegationTokenSecretManager();
        try {
            RAUMTJCTXJ.startThreads();
            // get two tokens
            Token<DelegationTokenIdentifier> KQIZGADIET = WGNVNSCMFX.getDelegationToken(CQFCLEEESD);
            Token<DelegationTokenIdentifier> ENAKOMOJFJ = WGNVNSCMFX.getDelegationToken(CQFCLEEESD);
            DelegationTokenIdentifier FOGPSVFEPN = KQIZGADIET.decodeIdentifier();
            DelegationTokenIdentifier DWJYYFIWLS = ENAKOMOJFJ.decodeIdentifier();
            // verify we got the tokens
            verify(IDCZQGBUXE, times(1)).logGetDelegationToken(eq(FOGPSVFEPN), anyLong());
            verify(IDCZQGBUXE, times(1)).logGetDelegationToken(eq(DWJYYFIWLS), anyLong());
            // this is a little tricky because DTSM doesn't let us set scan interval
            // so need to periodically sleep, then stop/start threads to force scan
            // renew first token 1/2 to expire
            Thread.sleep(ITAYOIBWDG / 2);
            WGNVNSCMFX.renewDelegationToken(ENAKOMOJFJ);
            verify(IDCZQGBUXE, times(1)).logRenewDelegationToken(eq(DWJYYFIWLS), anyLong());
            // force scan and give it a little time to complete
            RAUMTJCTXJ.stopThreads();
            RAUMTJCTXJ.startThreads();
            Thread.sleep(250);
            // no token has expired yet
            verify(IDCZQGBUXE, times(0)).logCancelDelegationToken(eq(FOGPSVFEPN));
            verify(IDCZQGBUXE, times(0)).logCancelDelegationToken(eq(DWJYYFIWLS));
            // sleep past expiration of 1st non-renewed token
            Thread.sleep(ITAYOIBWDG / 2);
            RAUMTJCTXJ.stopThreads();
            RAUMTJCTXJ.startThreads();
            Thread.sleep(250);
            // non-renewed token should have implicitly been cancelled
            verify(IDCZQGBUXE, times(1)).logCancelDelegationToken(eq(FOGPSVFEPN));
            verify(IDCZQGBUXE, times(0)).logCancelDelegationToken(eq(DWJYYFIWLS));
            // sleep past expiration of 2nd renewed token
            Thread.sleep(ITAYOIBWDG / 2);
            RAUMTJCTXJ.stopThreads();
            RAUMTJCTXJ.startThreads();
            Thread.sleep(250);
            // both tokens should have been implicitly cancelled by now
            verify(IDCZQGBUXE, times(1)).logCancelDelegationToken(eq(FOGPSVFEPN));
            verify(IDCZQGBUXE, times(1)).logCancelDelegationToken(eq(DWJYYFIWLS));
        } finally {
            RAUMTJCTXJ.stopThreads();
        }
    }
}