/**
 * Ensure during large directory delete, namenode does not block until the
 * deletion completes and handles new requests from other clients
 */
public class TestLargeDirectoryDelete {
    private static final Log QSPMATNPQZ = LogFactory.getLog(TestLargeDirectoryDelete.class);

    private static final Configuration YIUQRZCWSI = new HdfsConfiguration();

    private static final int WRCITGMVDW = 10000;

    private MiniDFSCluster HHQKLMPCHL = null;

    private int RKBBKEOIXN = 0;

    private int GRKNRSGETI = 0;

    static {
        TestLargeDirectoryDelete.YIUQRZCWSI.setLong(DFS_BLOCK_SIZE_KEY, 1);
        TestLargeDirectoryDelete.YIUQRZCWSI.setInt(DFS_BYTES_PER_CHECKSUM_KEY, 1);
    }

    /**
     * create a file with a length of <code>filelen</code>
     */
    private void createFile(final String ZCIXWBYOPK, final long DPGHKOHLOL) throws IOException {
        FileSystem LHKCNVKYBT = HHQKLMPCHL.getFileSystem();
        Path MHTJAKHMLG = new Path(ZCIXWBYOPK);
        DFSTestUtil.createFile(LHKCNVKYBT, MHTJAKHMLG, DPGHKOHLOL, ((short) (1)), 0);
    }

    /**
     * Create a large number of directories and files
     */
    private void createFiles() throws IOException {
        Random ANWSAEKFMR = new Random();
        // Create files in a directory with random depth
        // ranging from 0-10.
        for (int CJETQLNQAJ = 0; CJETQLNQAJ < TestLargeDirectoryDelete.WRCITGMVDW; CJETQLNQAJ += 100) {
            String FNDPZJDNHU = "/root/";
            int PHSYXJWYYT = ANWSAEKFMR.nextInt(10);// Depth of the directory

            for (int GIQGASTZJV = CJETQLNQAJ; GIQGASTZJV >= (CJETQLNQAJ - PHSYXJWYYT); GIQGASTZJV--) {
                FNDPZJDNHU += GIQGASTZJV + "/";
            }
            FNDPZJDNHU += "file" + CJETQLNQAJ;
            createFile(FNDPZJDNHU, 100);
        }
    }

    private int getBlockCount() {
        Assert.assertNotNull("Null cluster", HHQKLMPCHL);
        Assert.assertNotNull("No Namenode in cluster", HHQKLMPCHL.getNameNode());
        FSNamesystem WBCAIBBQTQ = HHQKLMPCHL.getNamesystem();
        Assert.assertNotNull("Null Namesystem in cluster", WBCAIBBQTQ);
        Assert.assertNotNull("Null Namesystem.blockmanager", WBCAIBBQTQ.getBlockManager());
        return ((int) (WBCAIBBQTQ.getBlocksTotal()));
    }

    /**
     * Run multiple threads doing simultaneous operations on the namenode
     * while a large directory is being deleted.
     */
    private void runThreads() throws Throwable {
        final TestLargeDirectoryDelete.TestThread[] LPJDXZXSRQ = new TestLargeDirectoryDelete.TestThread[2];
        // Thread for creating files
        LPJDXZXSRQ[0] = new TestLargeDirectoryDelete.TestThread() {
            @Override
            protected void execute() throws Throwable {
                while (EJAOSMWIKK) {
                    try {
                        int TEFUTVXKBD = getBlockCount();
                        if ((TEFUTVXKBD < TestLargeDirectoryDelete.WRCITGMVDW) && (TEFUTVXKBD > 0)) {
                            String YHRSSXSKKR = "/tmp" + RKBBKEOIXN;
                            createFile(YHRSSXSKKR, 1);
                            HHQKLMPCHL.getFileSystem().delete(new Path(YHRSSXSKKR), true);
                            RKBBKEOIXN++;
                        }
                    } catch (IOException ex) {
                        TestLargeDirectoryDelete.QSPMATNPQZ.info("createFile exception ", ex);
                        break;
                    }
                } 
            }
        };
        // Thread that periodically acquires the FSNamesystem lock
        LPJDXZXSRQ[1] = new TestLargeDirectoryDelete.TestThread() {
            @Override
            protected void execute() throws Throwable {
                while (EJAOSMWIKK) {
                    try {
                        int DISIQAWUJP = getBlockCount();
                        if ((DISIQAWUJP < TestLargeDirectoryDelete.WRCITGMVDW) && (DISIQAWUJP > 0)) {
                            HHQKLMPCHL.getNamesystem().writeLock();
                            try {
                                GRKNRSGETI++;
                            } finally {
                                HHQKLMPCHL.getNamesystem().writeUnlock();
                            }
                            Thread.sleep(1);
                        }
                    } catch (InterruptedException ex) {
                        TestLargeDirectoryDelete.QSPMATNPQZ.info("lockOperation exception ", ex);
                        break;
                    }
                } 
            }
        };
        LPJDXZXSRQ[0].start();
        LPJDXZXSRQ[1].start();
        final long VGPHTJKBPI = Time.now();
        FSNamesystem.BLOCK_DELETION_INCREMENT = 1;
        HHQKLMPCHL.getFileSystem().delete(new Path("/root"), true);// recursive delete

        final long EWDVZRPUYS = Time.now();
        LPJDXZXSRQ[0].endThread();
        LPJDXZXSRQ[1].endThread();
        TestLargeDirectoryDelete.QSPMATNPQZ.info(("Deletion took " + (EWDVZRPUYS - VGPHTJKBPI)) + "msecs");
        TestLargeDirectoryDelete.QSPMATNPQZ.info("createOperations " + RKBBKEOIXN);
        TestLargeDirectoryDelete.QSPMATNPQZ.info("lockOperations " + GRKNRSGETI);
        Assert.assertTrue((GRKNRSGETI + RKBBKEOIXN) > 0);
        LPJDXZXSRQ[0].rethrow();
        LPJDXZXSRQ[1].rethrow();
    }

    /**
     * An abstract class for tests that catches exceptions and can
     * rethrow them on a different thread, and has an {@link #endThread()}
     * operation that flips a volatile boolean before interrupting the thread.
     * Also: after running the implementation of {@link #execute()} in the
     * implementation class, the thread is notified: other threads can wait
     * for it to terminate
     */
    private abstract class TestThread extends Thread {
        volatile Throwable IETJBWJUZX;

        protected volatile boolean EJAOSMWIKK = true;

        @Override
        public void run() {
            try {
                execute();
            } catch (Throwable throwable) {
                TestLargeDirectoryDelete.QSPMATNPQZ.warn(throwable);
                setThrown(throwable);
            } finally {
                synchronized(this) {
                    this.notify();
                }
            }
        }

        protected abstract void execute() throws Throwable;

        protected synchronized void setThrown(Throwable thrown) {
            this.IETJBWJUZX = thrown;
        }

        /**
         * Rethrow anything caught
         *
         * @throws Throwable
         * 		any non-null throwable raised by the execute method.
         */
        public synchronized void rethrow() throws Throwable {
            if (IETJBWJUZX != null) {
                throw IETJBWJUZX;
            }
        }

        /**
         * End the thread by setting the live p
         */
        public synchronized void endThread() {
            EJAOSMWIKK = false;
            interrupt();
            try {
                wait();
            } catch (InterruptedException e) {
                if (TestLargeDirectoryDelete.QSPMATNPQZ.isDebugEnabled()) {
                    TestLargeDirectoryDelete.QSPMATNPQZ.debug("Ignoring " + e, e);
                }
            }
        }
    }

    @Test
    public void largeDelete() throws Throwable {
        HHQKLMPCHL = new MiniDFSCluster.Builder(TestLargeDirectoryDelete.YIUQRZCWSI).build();
        try {
            HHQKLMPCHL.waitActive();
            Assert.assertNotNull("No Namenode in cluster", HHQKLMPCHL.getNameNode());
            createFiles();
            Assert.assertEquals(TestLargeDirectoryDelete.WRCITGMVDW, getBlockCount());
            runThreads();
        } finally {
            HHQKLMPCHL.shutdown();
        }
    }
}