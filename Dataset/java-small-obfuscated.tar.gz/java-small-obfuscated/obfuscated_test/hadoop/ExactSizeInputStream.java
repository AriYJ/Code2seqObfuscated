/**
 * An InputStream implementations which reads from some other InputStream
 * but expects an exact number of bytes. Any attempts to read past the
 * specified number of bytes will return as if the end of the stream
 * was reached. If the end of the underlying stream is reached prior to
 * the specified number of bytes, an EOFException is thrown.
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public class ExactSizeInputStream extends FilterInputStream {
    private int CMJPMSCDFF;

    /**
     * Construct an input stream that will read no more than
     * 'numBytes' bytes.
     *
     * If an EOF occurs on the underlying stream before numBytes
     * bytes have been read, an EOFException will be thrown.
     *
     * @param in
     * 		the inputstream to wrap
     * @param numBytes
     * 		the number of bytes to read
     */
    public ExactSizeInputStream(InputStream MLVVQSXGBH, int YTGZTNRPXG) {
        super(MLVVQSXGBH);
        Preconditions.checkArgument(YTGZTNRPXG >= 0, "Negative expected bytes: ", YTGZTNRPXG);
        this.CMJPMSCDFF = YTGZTNRPXG;
    }

    @Override
    public int available() throws IOException {
        return Math.min(super.available(), CMJPMSCDFF);
    }

    @Override
    public int read() throws IOException {
        // EOF if we reached our limit
        if (CMJPMSCDFF <= 0) {
            return -1;
        }
        final int EJMCTBWMMD = super.read();
        if (EJMCTBWMMD >= 0) {
            --CMJPMSCDFF;
        } else
            if (CMJPMSCDFF > 0) {
                // Underlying stream reached EOF but we haven't read the expected
                // number of bytes.
                throw new EOFException(("Premature EOF. Expected " + CMJPMSCDFF) + "more bytes");
            }

        return EJMCTBWMMD;
    }

    @Override
    public int read(final byte[] TUDXBUJMWO, final int MQMHLSJBSW, int SOLHAZYUFX) throws IOException {
        if (CMJPMSCDFF <= 0) {
            return -1;
        }
        SOLHAZYUFX = Math.min(SOLHAZYUFX, CMJPMSCDFF);
        final int SXEKPXIQTZ = super.read(TUDXBUJMWO, MQMHLSJBSW, SOLHAZYUFX);
        if (SXEKPXIQTZ >= 0) {
            CMJPMSCDFF -= SXEKPXIQTZ;
        } else
            if (CMJPMSCDFF > 0) {
                // Underlying stream reached EOF but we haven't read the expected
                // number of bytes.
                throw new EOFException(("Premature EOF. Expected " + CMJPMSCDFF) + "more bytes");
            }

        return SXEKPXIQTZ;
    }

    @Override
    public long skip(final long XGCMFEMOSC) throws IOException {
        final long PYQCMOKGDF = super.skip(Math.min(XGCMFEMOSC, CMJPMSCDFF));
        if (PYQCMOKGDF > 0) {
            CMJPMSCDFF -= PYQCMOKGDF;
        } else
            if (CMJPMSCDFF > 0) {
                // Underlying stream reached EOF but we haven't read the expected
                // number of bytes.
                throw new EOFException(("Premature EOF. Expected " + CMJPMSCDFF) + "more bytes");
            }

        return PYQCMOKGDF;
    }

    @Override
    public boolean markSupported() {
        return false;
    }

    @Override
    public void mark(int KTCHFVUBBJ) {
        throw new UnsupportedOperationException();
    }
}