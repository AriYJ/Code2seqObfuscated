/**
 * Contains the input streams for the data and checksum of a replica.
 */
public class ReplicaInputStreams implements Closeable {
    private final InputStream XZNHYJEITG;

    private final InputStream BBBTNFYCIE;

    /**
     * Create an object with a data input stream and a checksum input stream.
     */
    public ReplicaInputStreams(FileDescriptor XFKNFCGWOO, FileDescriptor XKCHMJZVYR) {
        this.XZNHYJEITG = new FileInputStream(XFKNFCGWOO);
        this.BBBTNFYCIE = new FileInputStream(XKCHMJZVYR);
    }

    /**
     *
     *
     * @return the data input stream.
     */
    public InputStream getDataIn() {
        return XZNHYJEITG;
    }

    /**
     *
     *
     * @return the checksum input stream.
     */
    public InputStream getChecksumIn() {
        return BBBTNFYCIE;
    }

    @Override
    public void close() {
        IOUtils.closeStream(XZNHYJEITG);
        IOUtils.closeStream(BBBTNFYCIE);
    }
}