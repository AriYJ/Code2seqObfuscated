@InterfaceAudience.Public
@InterfaceStability.Stable
public class JobControl extends org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl {
    /**
     * Construct a job control for a group of jobs.
     *
     * @param groupName
     * 		a name identifying this group
     */
    public JobControl(String LLKXMJGJBH) {
        super(LLKXMJGJBH);
    }

    static ArrayList<Job> castToJobList(List<ControlledJob> ROLQKNLPCK) {
        ArrayList<Job> VRWOSTHEER = new ArrayList<Job>();
        for (ControlledJob SYVPIPVYUD : ROLQKNLPCK) {
            VRWOSTHEER.add(((Job) (SYVPIPVYUD)));
        }
        return VRWOSTHEER;
    }

    /**
     *
     *
     * @return the jobs in the waiting state
     */
    public ArrayList<Job> getWaitingJobs() {
        return JobControl.castToJobList(super.getWaitingJobList());
    }

    /**
     *
     *
     * @return the jobs in the running state
     */
    public ArrayList<Job> getRunningJobs() {
        return JobControl.castToJobList(super.getRunningJobList());
    }

    /**
     *
     *
     * @return the jobs in the ready state
     */
    public ArrayList<Job> getReadyJobs() {
        return JobControl.castToJobList(super.getReadyJobsList());
    }

    /**
     *
     *
     * @return the jobs in the success state
     */
    public ArrayList<Job> getSuccessfulJobs() {
        return JobControl.castToJobList(super.getSuccessfulJobList());
    }

    public ArrayList<Job> getFailedJobs() {
        return JobControl.castToJobList(super.getFailedJobList());
    }

    /**
     * Add a collection of jobs
     *
     * @param jobs
     * 		
     */
    public void addJobs(Collection<Job> SUKDUGJPRG) {
        for (Job GEVAYLVZZH : SUKDUGJPRG) {
            addJob(GEVAYLVZZH);
        }
    }

    /**
     *
     *
     * @return the thread state
     */
    public int getState() {
        ThreadState WWAFHNFAXE = super.getThreadState();
        if (WWAFHNFAXE == ThreadState.RUNNING) {
            return 0;
        }
        if (WWAFHNFAXE == ThreadState.SUSPENDED) {
            return 1;
        }
        if (WWAFHNFAXE == ThreadState.STOPPED) {
            return 2;
        }
        if (WWAFHNFAXE == ThreadState.STOPPING) {
            return 3;
        }
        if (WWAFHNFAXE == ThreadState.READY) {
            return 4;
        }
        return -1;
    }
}