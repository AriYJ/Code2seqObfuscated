@XmlRootElement
@XmlSeeAlso({ CapacitySchedulerInfo.class, FairSchedulerInfo.class, FifoSchedulerInfo.class })
public class SchedulerInfo {
    // JAXB needs this
    public SchedulerInfo() {
    }
}