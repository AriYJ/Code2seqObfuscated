/**
 * The client interface to the Resource Manager. This module handles all the rpc
 * interfaces to the resource manager from the client.
 */
public class ClientRMService extends AbstractService implements ApplicationClientProtocol {
    private static final ArrayList<ApplicationReport> LDIUBMXDDM = new ArrayList<ApplicationReport>();

    private static final Log WTFAFLYYKD = LogFactory.getLog(ClientRMService.class);

    private final AtomicInteger RPOZCCQWKB = new AtomicInteger(0);

    private final YarnScheduler VZKAPODUDQ;

    private final RMContext BJUBGVDGLS;

    private final RMAppManager VUTLECGJMV;

    private Server RYKBLCALTJ;

    protected RMDelegationTokenSecretManager YVCQDFLOSA;

    private final RecordFactory KTHOCBGAOR = RecordFactoryProvider.getRecordFactory(null);

    InetSocketAddress ZVVYUPHWPX;

    private final ApplicationACLsManager IZXCJDODCE;

    private final QueueACLsManager AZCOLMZEAC;

    public ClientRMService(RMContext XRVFYJADAM, YarnScheduler GKZQGYMPQB, RMAppManager LDYNDBDXDC, ApplicationACLsManager RVKNKXMKYR, QueueACLsManager YOWPCGRKRI, RMDelegationTokenSecretManager QKPNICESBA) {
        super(ClientRMService.class.getName());
        this.VZKAPODUDQ = GKZQGYMPQB;
        this.BJUBGVDGLS = XRVFYJADAM;
        this.VUTLECGJMV = LDYNDBDXDC;
        this.IZXCJDODCE = RVKNKXMKYR;
        this.AZCOLMZEAC = YOWPCGRKRI;
        this.YVCQDFLOSA = QKPNICESBA;
    }

    @Override
    protected void serviceInit(Configuration COTEXKCJLX) throws Exception {
        ZVVYUPHWPX = getBindAddress(COTEXKCJLX);
        super.serviceInit(COTEXKCJLX);
    }

    @Override
    protected void serviceStart() throws Exception {
        Configuration FQWWHTWPNZ = getConfig();
        YarnRPC QAMSAFBMPV = YarnRPC.create(FQWWHTWPNZ);
        this.RYKBLCALTJ = QAMSAFBMPV.getServer(ApplicationClientProtocol.class, this, ZVVYUPHWPX, FQWWHTWPNZ, this.YVCQDFLOSA, FQWWHTWPNZ.getInt(RM_CLIENT_THREAD_COUNT, DEFAULT_RM_CLIENT_THREAD_COUNT));
        // Enable service authorization?
        if (FQWWHTWPNZ.getBoolean(HADOOP_SECURITY_AUTHORIZATION, false)) {
            InputStream HSSDLVCGCU = this.BJUBGVDGLS.getConfigurationProvider().getConfigurationInputStream(FQWWHTWPNZ, YarnConfiguration.HADOOP_POLICY_CONFIGURATION_FILE);
            if (HSSDLVCGCU != null) {
                FQWWHTWPNZ.addResource(HSSDLVCGCU);
            }
            refreshServiceAcls(FQWWHTWPNZ, RMPolicyProvider.getInstance());
        }
        this.RYKBLCALTJ.start();
        ZVVYUPHWPX = FQWWHTWPNZ.updateConnectAddr(RM_BIND_HOST, RM_ADDRESS, DEFAULT_RM_ADDRESS, RYKBLCALTJ.getListenerAddress());
        super.serviceStart();
    }

    @Override
    protected void serviceStop() throws Exception {
        if (this.RYKBLCALTJ != null) {
            this.RYKBLCALTJ.stop();
        }
        super.serviceStop();
    }

    InetSocketAddress getBindAddress(Configuration GLRXVGHMCH) {
        return GLRXVGHMCH.getSocketAddr(RM_BIND_HOST, RM_ADDRESS, DEFAULT_RM_ADDRESS, DEFAULT_RM_PORT);
    }

    @Private
    public InetSocketAddress getBindAddress() {
        return ZVVYUPHWPX;
    }

    /**
     * check if the calling user has the access to application information.
     *
     * @param callerUGI
     * 		
     * @param owner
     * 		
     * @param operationPerformed
     * 		
     * @param application
     * 		
     * @return 
     */
    private boolean checkAccess(UserGroupInformation ALMLRELJPI, String ZECAZXMOXC, ApplicationAccessType CXXQJNWUPO, RMApp ZIOGBNVASX) {
        return IZXCJDODCE.checkAccess(ALMLRELJPI, CXXQJNWUPO, ZECAZXMOXC, ZIOGBNVASX.getApplicationId()) || AZCOLMZEAC.checkAccess(ALMLRELJPI, ADMINISTER_QUEUE, ZIOGBNVASX.getQueue());
    }

    ApplicationId getNewApplicationId() {
        ApplicationId QODLQJKXRQ = BuilderUtils.newApplicationId(KTHOCBGAOR, ResourceManager.getClusterTimeStamp(), RPOZCCQWKB.incrementAndGet());
        ClientRMService.WTFAFLYYKD.info("Allocated new applicationId: " + QODLQJKXRQ.getId());
        return QODLQJKXRQ;
    }

    @Override
    public GetNewApplicationResponse getNewApplication(GetNewApplicationRequest SDJMIXCPQF) throws YarnException {
        GetNewApplicationResponse OLQBTWJGQP = KTHOCBGAOR.newRecordInstance(GetNewApplicationResponse.class);
        OLQBTWJGQP.setApplicationId(getNewApplicationId());
        // Pick up min/max resource from scheduler...
        OLQBTWJGQP.setMaximumResourceCapability(VZKAPODUDQ.getMaximumResourceCapability());
        return OLQBTWJGQP;
    }

    /**
     * It gives response which includes application report if the application
     * present otherwise throws ApplicationNotFoundException.
     */
    @Override
    public GetApplicationReportResponse getApplicationReport(GetApplicationReportRequest ODBWIVGSOQ) throws YarnException {
        ApplicationId QNPLJJKSMC = ODBWIVGSOQ.getApplicationId();
        UserGroupInformation FSDNSQBTNP;
        try {
            FSDNSQBTNP = UserGroupInformation.getCurrentUser();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.info("Error getting UGI ", ie);
            throw RPCUtil.getRemoteException(ie);
        }
        RMApp GBFPEMMEVJ = this.BJUBGVDGLS.getRMApps().get(QNPLJJKSMC);
        if (GBFPEMMEVJ == null) {
            // If the RM doesn't have the application, throw
            // ApplicationNotFoundException and let client to handle.
            throw new org.apache.hadoop.yarn.exceptions.ApplicationNotFoundException(("Application with id '" + QNPLJJKSMC) + "' doesn't exist in RM.");
        }
        boolean JCTMGEAKWM = checkAccess(FSDNSQBTNP, GBFPEMMEVJ.getUser(), VIEW_APP, GBFPEMMEVJ);
        ApplicationReport NWXGPFJQFA = GBFPEMMEVJ.createAndGetApplicationReport(FSDNSQBTNP.getUserName(), JCTMGEAKWM);
        GetApplicationReportResponse MYVVCZCLNN = KTHOCBGAOR.newRecordInstance(GetApplicationReportResponse.class);
        MYVVCZCLNN.setApplicationReport(NWXGPFJQFA);
        return MYVVCZCLNN;
    }

    @Override
    public GetApplicationAttemptReportResponse getApplicationAttemptReport(GetApplicationAttemptReportRequest ELEWNZEUFC) throws IOException, YarnException {
        ApplicationAttemptId XVFBYFZQZS = ELEWNZEUFC.getApplicationAttemptId();
        UserGroupInformation CKJSFIERBW;
        try {
            CKJSFIERBW = UserGroupInformation.getCurrentUser();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.info("Error getting UGI ", ie);
            throw RPCUtil.getRemoteException(ie);
        }
        RMApp TBKBOLZGQD = this.BJUBGVDGLS.getRMApps().get(XVFBYFZQZS.getApplicationId());
        if (TBKBOLZGQD == null) {
            // If the RM doesn't have the application, throw
            // ApplicationNotFoundException and let client to handle.
            throw new org.apache.hadoop.yarn.exceptions.ApplicationNotFoundException(("Application with id '" + ELEWNZEUFC.getApplicationAttemptId().getApplicationId()) + "' doesn't exist in RM.");
        }
        boolean SNWSRTFXSY = checkAccess(CKJSFIERBW, TBKBOLZGQD.getUser(), VIEW_APP, TBKBOLZGQD);
        GetApplicationAttemptReportResponse RDSETZPTSK = null;
        if (SNWSRTFXSY) {
            RMAppAttempt KUCMIOPCCJ = TBKBOLZGQD.getAppAttempts().get(XVFBYFZQZS);
            if (KUCMIOPCCJ == null) {
                throw new org.apache.hadoop.yarn.exceptions.ApplicationAttemptNotFoundException(("ApplicationAttempt " + XVFBYFZQZS) + " Not Found in RM");
            }
            ApplicationAttemptReport SALMBZHRLU = KUCMIOPCCJ.createApplicationAttemptReport();
            RDSETZPTSK = GetApplicationAttemptReportResponse.newInstance(SALMBZHRLU);
        } else {
            throw new YarnException((("User " + CKJSFIERBW.getShortUserName()) + " does not have privilage to see this attempt ") + XVFBYFZQZS);
        }
        return RDSETZPTSK;
    }

    @Override
    public GetApplicationAttemptsResponse getApplicationAttempts(GetApplicationAttemptsRequest GSLPWDIZFU) throws IOException, YarnException {
        ApplicationId ERYCHZVKXJ = GSLPWDIZFU.getApplicationId();
        UserGroupInformation BRQPOTIRGS;
        try {
            BRQPOTIRGS = UserGroupInformation.getCurrentUser();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.info("Error getting UGI ", ie);
            throw RPCUtil.getRemoteException(ie);
        }
        RMApp SHNUMJZQJD = this.BJUBGVDGLS.getRMApps().get(ERYCHZVKXJ);
        if (SHNUMJZQJD == null) {
            // If the RM doesn't have the application, throw
            // ApplicationNotFoundException and let client to handle.
            throw new org.apache.hadoop.yarn.exceptions.ApplicationNotFoundException(("Application with id '" + ERYCHZVKXJ) + "' doesn't exist in RM.");
        }
        boolean LDMFEUFMCH = checkAccess(BRQPOTIRGS, SHNUMJZQJD.getUser(), VIEW_APP, SHNUMJZQJD);
        GetApplicationAttemptsResponse GKHKQOMZVR = null;
        if (LDMFEUFMCH) {
            Map<ApplicationAttemptId, RMAppAttempt> LAJPKWWDFF = SHNUMJZQJD.getAppAttempts();
            List<ApplicationAttemptReport> RGCXXCKHYG = new ArrayList<ApplicationAttemptReport>();
            Iterator<Map.Entry<ApplicationAttemptId, RMAppAttempt>> ZMGGKJKNWK = LAJPKWWDFF.entrySet().iterator();
            while (ZMGGKJKNWK.hasNext()) {
                RGCXXCKHYG.add(ZMGGKJKNWK.next().getValue().createApplicationAttemptReport());
            } 
            GKHKQOMZVR = GetApplicationAttemptsResponse.newInstance(RGCXXCKHYG);
        } else {
            throw new YarnException((("User " + BRQPOTIRGS.getShortUserName()) + " does not have privilage to see this aplication ") + ERYCHZVKXJ);
        }
        return GKHKQOMZVR;
    }

    /* (non-Javadoc)

    we're going to fix the issue of showing non-running containers of the
    running application in YARN-1794
     */
    @Override
    public GetContainerReportResponse getContainerReport(GetContainerReportRequest EBMDCQHHBZ) throws IOException, YarnException {
        ContainerId DPHETPDTPS = EBMDCQHHBZ.getContainerId();
        ApplicationAttemptId YAMPWDVFCT = DPHETPDTPS.getApplicationAttemptId();
        ApplicationId NIBDYRPHSJ = YAMPWDVFCT.getApplicationId();
        UserGroupInformation HMQVNHSPIM;
        try {
            HMQVNHSPIM = UserGroupInformation.getCurrentUser();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.info("Error getting UGI ", ie);
            throw RPCUtil.getRemoteException(ie);
        }
        RMApp XNNIOUZFKY = this.BJUBGVDGLS.getRMApps().get(NIBDYRPHSJ);
        if (XNNIOUZFKY == null) {
            // If the RM doesn't have the application, throw
            // ApplicationNotFoundException and let client to handle.
            throw new org.apache.hadoop.yarn.exceptions.ApplicationNotFoundException(("Application with id '" + NIBDYRPHSJ) + "' doesn't exist in RM.");
        }
        boolean CZHKIEENJE = checkAccess(HMQVNHSPIM, XNNIOUZFKY.getUser(), VIEW_APP, XNNIOUZFKY);
        GetContainerReportResponse ULGZLFDYVW = null;
        if (CZHKIEENJE) {
            RMAppAttempt DIYCVNMVXN = XNNIOUZFKY.getAppAttempts().get(YAMPWDVFCT);
            if (DIYCVNMVXN == null) {
                throw new org.apache.hadoop.yarn.exceptions.ApplicationAttemptNotFoundException(("ApplicationAttempt " + YAMPWDVFCT) + " Not Found in RM");
            }
            RMContainer VFQNSPXAFF = this.BJUBGVDGLS.getScheduler().getRMContainer(DPHETPDTPS);
            if (VFQNSPXAFF == null) {
                throw new org.apache.hadoop.yarn.exceptions.ContainerNotFoundException(("Container with id " + DPHETPDTPS) + " not found");
            }
            ULGZLFDYVW = GetContainerReportResponse.newInstance(VFQNSPXAFF.createContainerReport());
        } else {
            throw new YarnException((("User " + HMQVNHSPIM.getShortUserName()) + " does not have privilage to see this aplication ") + NIBDYRPHSJ);
        }
        return ULGZLFDYVW;
    }

    /* (non-Javadoc)

    we're going to fix the issue of showing non-running containers of the
    running application in YARN-1794"
     */
    @Override
    public GetContainersResponse getContainers(GetContainersRequest AJTWTNEZHI) throws IOException, YarnException {
        ApplicationAttemptId WZBMQQMUWC = AJTWTNEZHI.getApplicationAttemptId();
        ApplicationId VMIRVPIDDX = WZBMQQMUWC.getApplicationId();
        UserGroupInformation LSTCCQFTMH;
        try {
            LSTCCQFTMH = UserGroupInformation.getCurrentUser();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.info("Error getting UGI ", ie);
            throw RPCUtil.getRemoteException(ie);
        }
        RMApp XTKCMELQEP = this.BJUBGVDGLS.getRMApps().get(VMIRVPIDDX);
        if (XTKCMELQEP == null) {
            // If the RM doesn't have the application, throw
            // ApplicationNotFoundException and let client to handle.
            throw new org.apache.hadoop.yarn.exceptions.ApplicationNotFoundException(("Application with id '" + VMIRVPIDDX) + "' doesn't exist in RM.");
        }
        boolean GZTJLFOYVV = checkAccess(LSTCCQFTMH, XTKCMELQEP.getUser(), VIEW_APP, XTKCMELQEP);
        GetContainersResponse WZAPOKNQBW = null;
        if (GZTJLFOYVV) {
            RMAppAttempt MTXWECYAHA = XTKCMELQEP.getAppAttempts().get(WZBMQQMUWC);
            if (MTXWECYAHA == null) {
                throw new org.apache.hadoop.yarn.exceptions.ApplicationAttemptNotFoundException(("ApplicationAttempt " + WZBMQQMUWC) + " Not Found in RM");
            }
            Collection<RMContainer> OBUJFBNXYR = Collections.emptyList();
            SchedulerAppReport GKWDLLCYZT = this.BJUBGVDGLS.getScheduler().getSchedulerAppInfo(WZBMQQMUWC);
            if (GKWDLLCYZT != null) {
                OBUJFBNXYR = GKWDLLCYZT.getLiveContainers();
            }
            List<ContainerReport> NVAQJZVGNG = new ArrayList<ContainerReport>();
            for (RMContainer APFINYNGVX : OBUJFBNXYR) {
                NVAQJZVGNG.add(APFINYNGVX.createContainerReport());
            }
            WZAPOKNQBW = GetContainersResponse.newInstance(NVAQJZVGNG);
        } else {
            throw new YarnException((("User " + LSTCCQFTMH.getShortUserName()) + " does not have privilage to see this aplication ") + VMIRVPIDDX);
        }
        return WZAPOKNQBW;
    }

    @Override
    public SubmitApplicationResponse submitApplication(SubmitApplicationRequest QSHDLAWUVT) throws YarnException {
        ApplicationSubmissionContext PCQDVQPAQY = QSHDLAWUVT.getApplicationSubmissionContext();
        ApplicationId BUIHJJMOUW = PCQDVQPAQY.getApplicationId();
        // ApplicationSubmissionContext needs to be validated for safety - only
        // those fields that are independent of the RM's configuration will be
        // checked here, those that are dependent on RM configuration are validated
        // in RMAppManager.
        String VHPDFDCJZF = null;
        try {
            // Safety
            VHPDFDCJZF = UserGroupInformation.getCurrentUser().getShortUserName();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.warn("Unable to get the current user.", ie);
            RMAuditLogger.logFailure(VHPDFDCJZF, SUBMIT_APP_REQUEST, ie.getMessage(), "ClientRMService", "Exception in submitting application", BUIHJJMOUW);
            throw RPCUtil.getRemoteException(ie);
        }
        // Check whether app has already been put into rmContext,
        // If it is, simply return the response
        if (BJUBGVDGLS.getRMApps().get(BUIHJJMOUW) != null) {
            ClientRMService.WTFAFLYYKD.info("This is an earlier submitted application: " + BUIHJJMOUW);
            return SubmitApplicationResponse.newInstance();
        }
        if (PCQDVQPAQY.getQueue() == null) {
            PCQDVQPAQY.setQueue(DEFAULT_QUEUE_NAME);
        }
        if (PCQDVQPAQY.getApplicationName() == null) {
            PCQDVQPAQY.setApplicationName(DEFAULT_APPLICATION_NAME);
        }
        if (PCQDVQPAQY.getApplicationType() == null) {
            PCQDVQPAQY.setApplicationType(DEFAULT_APPLICATION_TYPE);
        } else {
            if (PCQDVQPAQY.getApplicationType().length() > YarnConfiguration.APPLICATION_TYPE_LENGTH) {
                PCQDVQPAQY.setApplicationType(PCQDVQPAQY.getApplicationType().substring(0, YarnConfiguration.APPLICATION_TYPE_LENGTH));
            }
        }
        try {
            // call RMAppManager to submit application directly
            VUTLECGJMV.submitApplication(PCQDVQPAQY, System.currentTimeMillis(), VHPDFDCJZF);
            ClientRMService.WTFAFLYYKD.info((("Application with id " + BUIHJJMOUW.getId()) + " submitted by user ") + VHPDFDCJZF);
            RMAuditLogger.logSuccess(VHPDFDCJZF, SUBMIT_APP_REQUEST, "ClientRMService", BUIHJJMOUW);
        } catch (YarnException e) {
            ClientRMService.WTFAFLYYKD.info("Exception in submitting application with id " + BUIHJJMOUW.getId(), e);
            RMAuditLogger.logFailure(VHPDFDCJZF, SUBMIT_APP_REQUEST, e.getMessage(), "ClientRMService", "Exception in submitting application", BUIHJJMOUW);
            throw e;
        }
        SubmitApplicationResponse NDKPZHZUZM = KTHOCBGAOR.newRecordInstance(SubmitApplicationResponse.class);
        return NDKPZHZUZM;
    }

    @SuppressWarnings("unchecked")
    @Override
    public KillApplicationResponse forceKillApplication(KillApplicationRequest XYWRAFQJWW) throws YarnException {
        ApplicationId FPLNBJUIFW = XYWRAFQJWW.getApplicationId();
        UserGroupInformation OZPYSKDDZA;
        try {
            OZPYSKDDZA = UserGroupInformation.getCurrentUser();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.info("Error getting UGI ", ie);
            RMAuditLogger.logFailure("UNKNOWN", KILL_APP_REQUEST, "UNKNOWN", "ClientRMService", "Error getting UGI", FPLNBJUIFW);
            throw RPCUtil.getRemoteException(ie);
        }
        RMApp VJJQKTEHRC = this.BJUBGVDGLS.getRMApps().get(FPLNBJUIFW);
        if (VJJQKTEHRC == null) {
            RMAuditLogger.logFailure(OZPYSKDDZA.getUserName(), KILL_APP_REQUEST, "UNKNOWN", "ClientRMService", "Trying to kill an absent application", FPLNBJUIFW);
            throw new org.apache.hadoop.yarn.exceptions.ApplicationNotFoundException(("Trying to kill an absent" + " application ") + FPLNBJUIFW);
        }
        if (!checkAccess(OZPYSKDDZA, VJJQKTEHRC.getUser(), MODIFY_APP, VJJQKTEHRC)) {
            RMAuditLogger.logFailure(OZPYSKDDZA.getShortUserName(), KILL_APP_REQUEST, "User doesn't have permissions to " + MODIFY_APP.toString(), "ClientRMService", UNAUTHORIZED_USER, FPLNBJUIFW);
            throw RPCUtil.getRemoteException(new AccessControlException((((("User " + OZPYSKDDZA.getShortUserName()) + " cannot perform operation ") + MODIFY_APP.name()) + " on ") + FPLNBJUIFW));
        }
        if (VJJQKTEHRC.isAppFinalStateStored()) {
            RMAuditLogger.logSuccess(OZPYSKDDZA.getShortUserName(), KILL_APP_REQUEST, "ClientRMService", FPLNBJUIFW);
            return KillApplicationResponse.newInstance(true);
        }
        this.BJUBGVDGLS.getDispatcher().getEventHandler().handle(new org.apache.hadoop.yarn.server.resourcemanager.rmapp.RMAppEvent(FPLNBJUIFW, RMAppEventType.KILL));
        // For UnmanagedAMs, return true so they don't retry
        return KillApplicationResponse.newInstance(VJJQKTEHRC.getApplicationSubmissionContext().getUnmanagedAM());
    }

    @Override
    public GetClusterMetricsResponse getClusterMetrics(GetClusterMetricsRequest BMFPTSRYFI) throws YarnException {
        GetClusterMetricsResponse DUCTSLNWAH = KTHOCBGAOR.newRecordInstance(GetClusterMetricsResponse.class);
        YarnClusterMetrics QZRFKLVKZT = KTHOCBGAOR.newRecordInstance(YarnClusterMetrics.class);
        QZRFKLVKZT.setNumNodeManagers(this.BJUBGVDGLS.getRMNodes().size());
        DUCTSLNWAH.setClusterMetrics(QZRFKLVKZT);
        return DUCTSLNWAH;
    }

    @Override
    public GetApplicationsResponse getApplications(GetApplicationsRequest QXLMNBCNZP) throws YarnException {
        return getApplications(QXLMNBCNZP, true);
    }

    /**
     * Get applications matching the {@link GetApplicationsRequest}. If
     * caseSensitive is set to false, applicationTypes in
     * GetApplicationRequest are expected to be in all-lowercase
     */
    @Private
    public GetApplicationsResponse getApplications(GetApplicationsRequest XIFXYMMTVY, boolean MYYSPIQWDT) throws YarnException {
        UserGroupInformation OFADUHFTRV;
        try {
            OFADUHFTRV = UserGroupInformation.getCurrentUser();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.info("Error getting UGI ", ie);
            throw RPCUtil.getRemoteException(ie);
        }
        Set<String> XDTAZMJLCK = XIFXYMMTVY.getApplicationTypes();
        EnumSet<YarnApplicationState> ZWXAVJQGQH = XIFXYMMTVY.getApplicationStates();
        Set<String> QYWYAWDGWS = XIFXYMMTVY.getUsers();
        Set<String> QOFSKAUTOJ = XIFXYMMTVY.getQueues();
        Set<String> GAGGUEGDUZ = XIFXYMMTVY.getApplicationTags();
        long IMBRQGHACX = XIFXYMMTVY.getLimit();
        LongRange PAXHIMBGXZ = XIFXYMMTVY.getStartRange();
        LongRange YQRDLUANFQ = XIFXYMMTVY.getFinishRange();
        ApplicationsRequestScope KDHZUGLVCN = XIFXYMMTVY.getScope();
        final Map<ApplicationId, RMApp> CQTUUDSRIN = BJUBGVDGLS.getRMApps();
        Iterator<RMApp> GWYYDYYTWH;
        // If the query filters by queues, we can avoid considering apps outside
        // of those queues by asking the scheduler for the apps in those queues.
        if ((QOFSKAUTOJ != null) && (!QOFSKAUTOJ.isEmpty())) {
            // Construct an iterator over apps in given queues
            // Collect list of lists to avoid copying all apps
            final List<List<ApplicationAttemptId>> CMTJCGGIQU = new ArrayList<List<ApplicationAttemptId>>();
            for (String IUVKJISLMD : QOFSKAUTOJ) {
                List<ApplicationAttemptId> SNKXMZJOLT = VZKAPODUDQ.getAppsInQueue(IUVKJISLMD);
                if ((SNKXMZJOLT != null) && (!SNKXMZJOLT.isEmpty())) {
                    CMTJCGGIQU.add(SNKXMZJOLT);
                }
            }
            GWYYDYYTWH = new Iterator<RMApp>() {
                Iterator<List<ApplicationAttemptId>> XYTFXPHVEO = CMTJCGGIQU.iterator();

                Iterator<ApplicationAttemptId> GTBFVEMLRR;

                @Override
                public boolean hasNext() {
                    // Because queueAppLists has no empty lists, hasNext is whether the
                    // current list hasNext or whether there are any remaining lists
                    return ((GTBFVEMLRR != null) && GTBFVEMLRR.hasNext()) || XYTFXPHVEO.hasNext();
                }

                @Override
                public RMApp next() {
                    if ((GTBFVEMLRR == null) || (!GTBFVEMLRR.hasNext())) {
                        GTBFVEMLRR = XYTFXPHVEO.next().iterator();
                    }
                    return CQTUUDSRIN.get(GTBFVEMLRR.next().getApplicationId());
                }

                @Override
                public void remove() {
                    throw new UnsupportedOperationException("Remove not supported");
                }
            };
        } else {
            GWYYDYYTWH = CQTUUDSRIN.values().iterator();
        }
        List<ApplicationReport> RJIZOXRDEP = new ArrayList<ApplicationReport>();
        while (GWYYDYYTWH.hasNext() && (RJIZOXRDEP.size() < IMBRQGHACX)) {
            RMApp BTYZUQHNCQ = GWYYDYYTWH.next();
            // Check if current application falls under the specified scope
            boolean EZTDRZBWGU = checkAccess(OFADUHFTRV, BTYZUQHNCQ.getUser(), VIEW_APP, BTYZUQHNCQ);
            if ((KDHZUGLVCN == ApplicationsRequestScope.OWN) && (!OFADUHFTRV.getUserName().equals(BTYZUQHNCQ.getUser()))) {
                continue;
            } else
                if ((KDHZUGLVCN == ApplicationsRequestScope.VIEWABLE) && (!EZTDRZBWGU)) {
                    continue;
                }

            if ((XDTAZMJLCK != null) && (!XDTAZMJLCK.isEmpty())) {
                String ZWCRWWKURT = (MYYSPIQWDT) ? BTYZUQHNCQ.getApplicationType() : BTYZUQHNCQ.getApplicationType().toLowerCase();
                if (!XDTAZMJLCK.contains(ZWCRWWKURT)) {
                    continue;
                }
            }
            if ((ZWXAVJQGQH != null) && (!ZWXAVJQGQH.isEmpty())) {
                if (!ZWXAVJQGQH.contains(BTYZUQHNCQ.createApplicationState())) {
                    continue;
                }
            }
            if (((QYWYAWDGWS != null) && (!QYWYAWDGWS.isEmpty())) && (!QYWYAWDGWS.contains(BTYZUQHNCQ.getUser()))) {
                continue;
            }
            if ((PAXHIMBGXZ != null) && (!PAXHIMBGXZ.containsLong(BTYZUQHNCQ.getStartTime()))) {
                continue;
            }
            if ((YQRDLUANFQ != null) && (!YQRDLUANFQ.containsLong(BTYZUQHNCQ.getFinishTime()))) {
                continue;
            }
            if ((GAGGUEGDUZ != null) && (!GAGGUEGDUZ.isEmpty())) {
                Set<String> RJEUBMGRKD = BTYZUQHNCQ.getApplicationTags();
                if ((RJEUBMGRKD == null) || RJEUBMGRKD.isEmpty()) {
                    continue;
                }
                boolean OVKOMBASCJ = false;
                for (String IKPXWROYPR : GAGGUEGDUZ) {
                    if (RJEUBMGRKD.contains(IKPXWROYPR)) {
                        OVKOMBASCJ = true;
                        break;
                    }
                }
                if (!OVKOMBASCJ) {
                    continue;
                }
            }
            RJIZOXRDEP.add(BTYZUQHNCQ.createAndGetApplicationReport(OFADUHFTRV.getUserName(), EZTDRZBWGU));
        } 
        GetApplicationsResponse LTZMAOHRGW = KTHOCBGAOR.newRecordInstance(GetApplicationsResponse.class);
        LTZMAOHRGW.setApplicationList(RJIZOXRDEP);
        return LTZMAOHRGW;
    }

    @Override
    public GetClusterNodesResponse getClusterNodes(GetClusterNodesRequest LDLRQWUMWF) throws YarnException {
        GetClusterNodesResponse RYOTUGGRYS = KTHOCBGAOR.newRecordInstance(GetClusterNodesResponse.class);
        EnumSet<NodeState> HCFPAVUNWS = LDLRQWUMWF.getNodeStates();
        if ((HCFPAVUNWS == null) || HCFPAVUNWS.isEmpty()) {
            HCFPAVUNWS = EnumSet.allOf(NodeState.class);
        }
        Collection<RMNode> SNMBXMRJWP = RMServerUtils.queryRMNodes(BJUBGVDGLS, HCFPAVUNWS);
        List<NodeReport> PNRFIRVANA = new ArrayList<NodeReport>(SNMBXMRJWP.size());
        for (RMNode OEEEZICMGS : SNMBXMRJWP) {
            PNRFIRVANA.add(createNodeReports(OEEEZICMGS));
        }
        RYOTUGGRYS.setNodeReports(PNRFIRVANA);
        return RYOTUGGRYS;
    }

    @Override
    public GetQueueInfoResponse getQueueInfo(GetQueueInfoRequest BSRLGAUCDE) throws YarnException {
        GetQueueInfoResponse CGHGIURGVJ = KTHOCBGAOR.newRecordInstance(GetQueueInfoResponse.class);
        try {
            QueueInfo ZCMXRELTHW = VZKAPODUDQ.getQueueInfo(BSRLGAUCDE.getQueueName(), BSRLGAUCDE.getIncludeChildQueues(), BSRLGAUCDE.getRecursive());
            List<ApplicationReport> HXXWFZSOSO = ClientRMService.LDIUBMXDDM;
            if (BSRLGAUCDE.getIncludeApplications()) {
                List<ApplicationAttemptId> DNTHMYORRT = VZKAPODUDQ.getAppsInQueue(BSRLGAUCDE.getQueueName());
                HXXWFZSOSO = new ArrayList<ApplicationReport>(DNTHMYORRT.size());
                for (ApplicationAttemptId KRUDVGUXIO : DNTHMYORRT) {
                    RMApp MQNAFIQQEA = BJUBGVDGLS.getRMApps().get(KRUDVGUXIO.getApplicationId());
                    HXXWFZSOSO.add(MQNAFIQQEA.createAndGetApplicationReport(null, true));
                }
            }
            ZCMXRELTHW.setApplications(HXXWFZSOSO);
            CGHGIURGVJ.setQueueInfo(ZCMXRELTHW);
        } catch (IOException ioe) {
            ClientRMService.WTFAFLYYKD.info("Failed to getQueueInfo for " + BSRLGAUCDE.getQueueName(), ioe);
        }
        return CGHGIURGVJ;
    }

    private NodeReport createNodeReports(RMNode PUKNHLOLBF) {
        SchedulerNodeReport ZBAQEVOPRT = VZKAPODUDQ.getNodeReport(PUKNHLOLBF.getNodeID());
        Resource BKPXIIACBF = BuilderUtils.newResource(0, 0);
        int JZGAWFOXQH = 0;
        if (ZBAQEVOPRT != null) {
            BKPXIIACBF = ZBAQEVOPRT.getUsedResource();
            JZGAWFOXQH = ZBAQEVOPRT.getNumContainers();
        }
        NodeReport PZIZNCNQZA = BuilderUtils.newNodeReport(PUKNHLOLBF.getNodeID(), PUKNHLOLBF.getState(), PUKNHLOLBF.getHttpAddress(), PUKNHLOLBF.getRackName(), BKPXIIACBF, PUKNHLOLBF.getTotalCapability(), JZGAWFOXQH, PUKNHLOLBF.getHealthReport(), PUKNHLOLBF.getLastHealthReportTime());
        return PZIZNCNQZA;
    }

    @Override
    public GetQueueUserAclsInfoResponse getQueueUserAcls(GetQueueUserAclsInfoRequest VWQHZCRNDZ) throws YarnException {
        GetQueueUserAclsInfoResponse YIDFAXQGRF = KTHOCBGAOR.newRecordInstance(GetQueueUserAclsInfoResponse.class);
        YIDFAXQGRF.setUserAclsInfoList(VZKAPODUDQ.getQueueUserAclInfo());
        return YIDFAXQGRF;
    }

    @Override
    public GetDelegationTokenResponse getDelegationToken(GetDelegationTokenRequest UWXKVIQKPO) throws YarnException {
        try {
            // Verify that the connection is kerberos authenticated
            if (!isAllowedDelegationTokenOp()) {
                throw new IOException("Delegation Token can be issued only with kerberos authentication");
            }
            GetDelegationTokenResponse ATTUBATZRJ = KTHOCBGAOR.newRecordInstance(GetDelegationTokenResponse.class);
            UserGroupInformation WLOMUFSUKS = UserGroupInformation.getCurrentUser();
            Text TXVQWEBGYW = new Text(WLOMUFSUKS.getUserName());
            Text TRWWYZRPKJ = null;
            if (WLOMUFSUKS.getRealUser() != null) {
                TRWWYZRPKJ = new Text(WLOMUFSUKS.getRealUser().getUserName());
            }
            RMDelegationTokenIdentifier PFXWFAFQRQ = new RMDelegationTokenIdentifier(TXVQWEBGYW, new Text(UWXKVIQKPO.getRenewer()), TRWWYZRPKJ);
            Token<RMDelegationTokenIdentifier> DPYDDBIHUM = new Token<RMDelegationTokenIdentifier>(PFXWFAFQRQ, this.YVCQDFLOSA);
            ATTUBATZRJ.setRMDelegationToken(BuilderUtils.newDelegationToken(DPYDDBIHUM.getIdentifier(), DPYDDBIHUM.getKind().toString(), DPYDDBIHUM.getPassword(), DPYDDBIHUM.getService().toString()));
            return ATTUBATZRJ;
        } catch (IOException io) {
            throw RPCUtil.getRemoteException(io);
        }
    }

    @Override
    public RenewDelegationTokenResponse renewDelegationToken(RenewDelegationTokenRequest VIVLEFVPTF) throws YarnException {
        try {
            if (!isAllowedDelegationTokenOp()) {
                throw new IOException("Delegation Token can be renewed only with kerberos authentication");
            }
            org.apache.hadoop.yarn.api.records.Token DCCDWJISHH = VIVLEFVPTF.getDelegationToken();
            Token<RMDelegationTokenIdentifier> SLWUIQAZTG = new Token<RMDelegationTokenIdentifier>(DCCDWJISHH.getIdentifier().array(), DCCDWJISHH.getPassword().array(), new Text(DCCDWJISHH.getKind()), new Text(DCCDWJISHH.getService()));
            String JURYJRKZEB = getRenewerForToken(SLWUIQAZTG);
            long QTJUGBXDAN = YVCQDFLOSA.renewToken(SLWUIQAZTG, JURYJRKZEB);
            RenewDelegationTokenResponse HERBPNCVMA = Records.newRecord(RenewDelegationTokenResponse.class);
            HERBPNCVMA.setNextExpirationTime(QTJUGBXDAN);
            return HERBPNCVMA;
        } catch (IOException e) {
            throw RPCUtil.getRemoteException(e);
        }
    }

    @Override
    public CancelDelegationTokenResponse cancelDelegationToken(CancelDelegationTokenRequest BTSFQZYEFG) throws YarnException {
        try {
            if (!isAllowedDelegationTokenOp()) {
                throw new IOException("Delegation Token can be cancelled only with kerberos authentication");
            }
            org.apache.hadoop.yarn.api.records.Token YXHKHFPELI = BTSFQZYEFG.getDelegationToken();
            Token<RMDelegationTokenIdentifier> CBNJBFMDJI = new Token<RMDelegationTokenIdentifier>(YXHKHFPELI.getIdentifier().array(), YXHKHFPELI.getPassword().array(), new Text(YXHKHFPELI.getKind()), new Text(YXHKHFPELI.getService()));
            String GJUEWYVJGP = UserGroupInformation.getCurrentUser().getUserName();
            YVCQDFLOSA.cancelToken(CBNJBFMDJI, GJUEWYVJGP);
            return Records.newRecord(CancelDelegationTokenResponse.class);
        } catch (IOException e) {
            throw RPCUtil.getRemoteException(e);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public MoveApplicationAcrossQueuesResponse moveApplicationAcrossQueues(MoveApplicationAcrossQueuesRequest NNIUGXDJIA) throws YarnException {
        ApplicationId KIMOBPPXZL = NNIUGXDJIA.getApplicationId();
        UserGroupInformation QXOSMHXDMP;
        try {
            QXOSMHXDMP = UserGroupInformation.getCurrentUser();
        } catch (IOException ie) {
            ClientRMService.WTFAFLYYKD.info("Error getting UGI ", ie);
            RMAuditLogger.logFailure("UNKNOWN", MOVE_APP_REQUEST, "UNKNOWN", "ClientRMService", "Error getting UGI", KIMOBPPXZL);
            throw RPCUtil.getRemoteException(ie);
        }
        RMApp EGHPRTFRKM = this.BJUBGVDGLS.getRMApps().get(KIMOBPPXZL);
        if (EGHPRTFRKM == null) {
            RMAuditLogger.logFailure(QXOSMHXDMP.getUserName(), MOVE_APP_REQUEST, "UNKNOWN", "ClientRMService", "Trying to move an absent application", KIMOBPPXZL);
            throw new org.apache.hadoop.yarn.exceptions.ApplicationNotFoundException(("Trying to move an absent" + " application ") + KIMOBPPXZL);
        }
        if (!checkAccess(QXOSMHXDMP, EGHPRTFRKM.getUser(), MODIFY_APP, EGHPRTFRKM)) {
            RMAuditLogger.logFailure(QXOSMHXDMP.getShortUserName(), MOVE_APP_REQUEST, "User doesn't have permissions to " + MODIFY_APP.toString(), "ClientRMService", UNAUTHORIZED_USER, KIMOBPPXZL);
            throw RPCUtil.getRemoteException(new AccessControlException((((("User " + QXOSMHXDMP.getShortUserName()) + " cannot perform operation ") + MODIFY_APP.name()) + " on ") + KIMOBPPXZL));
        }
        // Moves only allowed when app is in a state that means it is tracked by
        // the scheduler
        if (EnumSet.of(RMAppState.NEW, RMAppState.NEW_SAVING, RMAppState.FAILED, RMAppState.FINAL_SAVING, RMAppState.FINISHING, RMAppState.FINISHED, RMAppState.KILLED, RMAppState.KILLING, RMAppState.FAILED).contains(EGHPRTFRKM.getState())) {
            String TZFCLQVVCC = ("App in " + EGHPRTFRKM.getState()) + " state cannot be moved.";
            RMAuditLogger.logFailure(QXOSMHXDMP.getShortUserName(), MOVE_APP_REQUEST, "UNKNOWN", "ClientRMService", TZFCLQVVCC);
            throw new YarnException(TZFCLQVVCC);
        }
        SettableFuture<Object> ICYFWYGFIM = SettableFuture.create();
        this.BJUBGVDGLS.getDispatcher().getEventHandler().handle(new org.apache.hadoop.yarn.server.resourcemanager.rmapp.RMAppMoveEvent(KIMOBPPXZL, NNIUGXDJIA.getTargetQueue(), ICYFWYGFIM));
        try {
            Futures.get(ICYFWYGFIM, YarnException.class);
        } catch (YarnException ex) {
            RMAuditLogger.logFailure(QXOSMHXDMP.getShortUserName(), MOVE_APP_REQUEST, "UNKNOWN", "ClientRMService", ex.getMessage());
            throw ex;
        }
        RMAuditLogger.logSuccess(QXOSMHXDMP.getShortUserName(), MOVE_APP_REQUEST, "ClientRMService", KIMOBPPXZL);
        MoveApplicationAcrossQueuesResponse VXVCNKPROE = KTHOCBGAOR.newRecordInstance(MoveApplicationAcrossQueuesResponse.class);
        return VXVCNKPROE;
    }

    private String getRenewerForToken(Token<RMDelegationTokenIdentifier> KPPEPRTAWE) throws IOException {
        UserGroupInformation UQHWOPVXXO = UserGroupInformation.getCurrentUser();
        UserGroupInformation ZCOVZDGBYH = UserGroupInformation.getLoginUser();
        // we can always renew our own tokens
        return ZCOVZDGBYH.getUserName().equals(UQHWOPVXXO.getUserName()) ? KPPEPRTAWE.decodeIdentifier().getRenewer().toString() : UQHWOPVXXO.getShortUserName();
    }

    void refreshServiceAcls(Configuration QEAXROLBKL, PolicyProvider VGMPJSAXDO) {
        this.RYKBLCALTJ.refreshServiceAclWithLoadedConfiguration(QEAXROLBKL, VGMPJSAXDO);
    }

    private boolean isAllowedDelegationTokenOp() throws IOException {
        if (UserGroupInformation.isSecurityEnabled()) {
            return EnumSet.of(AuthenticationMethod.KERBEROS, AuthenticationMethod.KERBEROS_SSL, AuthenticationMethod.CERTIFICATE).contains(UserGroupInformation.getCurrentUser().getRealAuthenticationMethod());
        } else {
            return true;
        }
    }

    @VisibleForTesting
    public Server getServer() {
        return this.RYKBLCALTJ;
    }
}