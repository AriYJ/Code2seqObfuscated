/**
 * Namenode RPC address parameter.
 */
public class NamenodeAddressParam extends StringParam {
    /**
     * Parameter name.
     */
    public static final String BBOOYPQSLJ = "namenoderpcaddress";

    /**
     * Default parameter value.
     */
    public static final String KSHYFGHUZF = "";

    private static final Domain HZHRXRVHMK = new Domain(NamenodeAddressParam.BBOOYPQSLJ, null);

    /**
     * Constructor.
     *
     * @param str
     * 		a string representation of the parameter value.
     */
    public NamenodeAddressParam(final String XUATOWCNNC) {
        super(NamenodeAddressParam.HZHRXRVHMK, (XUATOWCNNC == null) || XUATOWCNNC.equals(NamenodeAddressParam.KSHYFGHUZF) ? null : NamenodeAddressParam.HZHRXRVHMK.parse(XUATOWCNNC));
    }

    /**
     * Construct an object using the RPC address of the given namenode.
     */
    public NamenodeAddressParam(final NameNode YESAUZORBH) {
        super(NamenodeAddressParam.HZHRXRVHMK, YESAUZORBH.getTokenServiceName());
    }

    @Override
    public String getName() {
        return NamenodeAddressParam.BBOOYPQSLJ;
    }
}