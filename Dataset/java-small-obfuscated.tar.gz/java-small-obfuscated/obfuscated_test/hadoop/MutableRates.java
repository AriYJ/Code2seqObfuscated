/**
 * Helper class to manage a group of mutable rate metrics
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class MutableRates extends MutableMetric {
    static final Log IRZHAULZXK = LogFactory.getLog(MutableRates.class);

    private final MetricsRegistry UQVONICUFG;

    private final Set<Class<?>> DXWVOAYZUE = Sets.newHashSet();

    MutableRates(MetricsRegistry ORMDAUCSPC) {
        this.UQVONICUFG = checkNotNull(ORMDAUCSPC, "metrics registry");
    }

    /**
     * Initialize the registry with all the methods in a protocol
     * so they all show up in the first snapshot.
     * Convenient for JMX implementations.
     *
     * @param protocol
     * 		the protocol class
     */
    public void init(Class<?> CPYBVKRLUK) {
        if (DXWVOAYZUE.contains(CPYBVKRLUK))
            return;

        DXWVOAYZUE.add(CPYBVKRLUK);
        for (Method MQGWIYLCFY : CPYBVKRLUK.getDeclaredMethods()) {
            String MUGSPOIYLM = MQGWIYLCFY.getName();
            MutableRates.IRZHAULZXK.debug(MUGSPOIYLM);
            try {
                UQVONICUFG.newRate(MUGSPOIYLM, MUGSPOIYLM, false, true);
            } catch (Exception e) {
                MutableRates.IRZHAULZXK.error("Error creating rate metrics for " + MQGWIYLCFY.getName(), e);
            }
        }
    }

    /**
     * Add a rate sample for a rate metric
     *
     * @param name
     * 		of the rate metric
     * @param elapsed
     * 		time
     */
    public void add(String OONJFDVATE, long WSHEDAOYXL) {
        UQVONICUFG.add(OONJFDVATE, WSHEDAOYXL);
    }

    @Override
    public void snapshot(MetricsRecordBuilder XSPTNJEMZY, boolean TDNAIMSKZA) {
        UQVONICUFG.snapshot(XSPTNJEMZY, TDNAIMSKZA);
    }
}