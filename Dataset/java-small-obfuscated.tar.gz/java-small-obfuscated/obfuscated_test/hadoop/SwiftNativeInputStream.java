/**
 * The input stream from remote Swift blobs.
 * The class attempts to be buffer aware, and react to a forward seek operation
 * by trying to scan ahead through the current block of data to find it.
 * This accelerates some operations that do a lot of seek()/read() actions,
 * including work (such as in the MR engine) that do a seek() immediately after
 * an open().
 */
class SwiftNativeInputStream extends FSInputStream {
    private static final Log FDZGGLOBXP = LogFactory.getLog(SwiftNativeInputStream.class);

    /**
     * range requested off the server: {@value }
     */
    private final long SSFRDHHQNE;

    /**
     * File nativeStore instance
     */
    private final SwiftNativeFileSystemStore DJHEVARXON;

    /**
     * Hadoop statistics. Used to get info about number of reads, writes, etc.
     */
    private final Statistics KUJPXGCPOA;

    /**
     * Data input stream
     */
    private HttpInputStreamWithRelease FYEPNKNJHD;

    /**
     * File path
     */
    private final Path NCJHYHCHTW;

    /**
     * Current position
     */
    private long DXMDKTCTOX = 0;

    /**
     * Length of the file picked up at start time
     */
    private long QZPFMKOKFK = -1;

    /**
     * Why the stream is closed
     */
    private String FNHNPBMQRE = "unopened";

    /**
     * Offset in the range requested last
     */
    private long UBZNUZTNRV = 0;

    public SwiftNativeInputStream(SwiftNativeFileSystemStore GKIGVODOYC, FileSystem.Statistics LFAXVKQZUE, Path RPRUVWOHQN, long DDFWVJMZGP) throws IOException {
        this.DJHEVARXON = GKIGVODOYC;
        this.KUJPXGCPOA = LFAXVKQZUE;
        this.NCJHYHCHTW = RPRUVWOHQN;
        if (DDFWVJMZGP <= 0) {
            throw new IllegalArgumentException("Invalid buffer size");
        }
        this.SSFRDHHQNE = DDFWVJMZGP;
        // initial buffer fill
        this.FYEPNKNJHD = GKIGVODOYC.getObject(RPRUVWOHQN).getInputStream();
        // fillBuffer(0);
    }

    /**
     * Move to a new position within the file relative to where the pointer is now.
     * Always call from a synchronized clause
     *
     * @param offset
     * 		offset
     */
    private synchronized void incPos(int EFLXCDCVVM) {
        DXMDKTCTOX += EFLXCDCVVM;
        UBZNUZTNRV += EFLXCDCVVM;
        SwiftUtils.trace(SwiftNativeInputStream.FDZGGLOBXP, "Inc: pos=%d bufferOffset=%d", DXMDKTCTOX, UBZNUZTNRV);
    }

    /**
     * Update the start of the buffer; always call from a sync'd clause
     *
     * @param seekPos
     * 		position sought.
     * @param contentLength
     * 		content length provided by response (may be -1)
     */
    private synchronized void updateStartOfBufferPosition(long VVKELRXIKZ, long WPDXCLJPOV) {
        // reset the seek pointer
        DXMDKTCTOX = VVKELRXIKZ;
        // and put the buffer offset to 0
        UBZNUZTNRV = 0;
        this.QZPFMKOKFK = WPDXCLJPOV;
        SwiftUtils.trace(SwiftNativeInputStream.FDZGGLOBXP, "Move: pos=%d; bufferOffset=%d; contentLength=%d", DXMDKTCTOX, UBZNUZTNRV, WPDXCLJPOV);
    }

    @Override
    public synchronized int read() throws IOException {
        verifyOpen();
        int WIRHYQCNLR = -1;
        try {
            WIRHYQCNLR = FYEPNKNJHD.read();
        } catch (IOException e) {
            String OXLBXQSFNF = ((("IOException while reading " + NCJHYHCHTW) + ": ") + e) + ", attempting to reopen.";
            SwiftNativeInputStream.FDZGGLOBXP.debug(OXLBXQSFNF, e);
            if (reopenBuffer()) {
                WIRHYQCNLR = FYEPNKNJHD.read();
            }
        }
        if (WIRHYQCNLR != (-1)) {
            incPos(1);
        }
        if ((KUJPXGCPOA != null) && (WIRHYQCNLR != (-1))) {
            KUJPXGCPOA.incrementBytesRead(1);
        }
        return WIRHYQCNLR;
    }

    @Override
    public synchronized int read(byte[] FKPVFJAUEC, int HGBTVEEYMD, int KRWVNHZGKB) throws IOException {
        SwiftUtils.debug(SwiftNativeInputStream.FDZGGLOBXP, "read(buffer, %d, %d)", HGBTVEEYMD, KRWVNHZGKB);
        SwiftUtils.validateReadArgs(FKPVFJAUEC, HGBTVEEYMD, KRWVNHZGKB);
        int ZDWPJSBRTY = -1;
        try {
            verifyOpen();
            ZDWPJSBRTY = FYEPNKNJHD.read(FKPVFJAUEC, HGBTVEEYMD, KRWVNHZGKB);
        } catch (IOException e) {
            // other IO problems are viewed as transient and re-attempted
            SwiftNativeInputStream.FDZGGLOBXP.info((("Received IOException while reading '" + NCJHYHCHTW) + "', attempting to reopen: ") + e);
            SwiftNativeInputStream.FDZGGLOBXP.debug("IOE on read()" + e, e);
            if (reopenBuffer()) {
                ZDWPJSBRTY = FYEPNKNJHD.read(FKPVFJAUEC, HGBTVEEYMD, KRWVNHZGKB);
            }
        }
        if (ZDWPJSBRTY > 0) {
            incPos(ZDWPJSBRTY);
            if (KUJPXGCPOA != null) {
                KUJPXGCPOA.incrementBytesRead(ZDWPJSBRTY);
            }
        }
        return ZDWPJSBRTY;
    }

    /**
     * Re-open the buffer
     *
     * @return true iff more data could be added to the buffer
     * @throws IOException
     * 		if not
     */
    private boolean reopenBuffer() throws IOException {
        innerClose("reopening buffer to trigger refresh");
        boolean YJCJELHVLP = false;
        try {
            fillBuffer(DXMDKTCTOX);
            YJCJELHVLP = true;
        } catch (EOFException eof) {
            // the EOF has been reached
            this.FNHNPBMQRE = "End of file";
        }
        return YJCJELHVLP;
    }

    /**
     * close the stream. After this the stream is not usable -unless and until
     * it is re-opened (which can happen on some of the buffer ops)
     * This method is thread-safe and idempotent.
     *
     * @throws IOException
     * 		on IO problems.
     */
    @Override
    public synchronized void close() throws IOException {
        innerClose("closed");
    }

    private void innerClose(String NGXOQDDWOM) throws IOException {
        try {
            if (FYEPNKNJHD != null) {
                FNHNPBMQRE = NGXOQDDWOM;
                if (SwiftNativeInputStream.FDZGGLOBXP.isDebugEnabled()) {
                    SwiftNativeInputStream.FDZGGLOBXP.debug("Closing HTTP input stream : " + NGXOQDDWOM);
                }
                FYEPNKNJHD.close();
            }
        } finally {
            FYEPNKNJHD = null;
        }
    }

    /**
     * Assume that the connection is not closed: throws an exception if it is
     *
     * @throws SwiftConnectionClosedException
     * 		
     */
    private void verifyOpen() throws SwiftConnectionClosedException {
        if (FYEPNKNJHD == null) {
            throw new SwiftConnectionClosedException(FNHNPBMQRE);
        }
    }

    @Override
    public synchronized String toString() {
        return ((((("SwiftNativeInputStream" + " position=") + DXMDKTCTOX) + " buffer size = ") + SSFRDHHQNE) + " ") + (FYEPNKNJHD != null ? FYEPNKNJHD.toString() : " no input stream: " + FNHNPBMQRE);
    }

    /**
     * Treats any finalize() call without the input stream being closed
     * as a serious problem, logging at error level
     *
     * @throws Throwable
     * 		n/a
     */
    @Override
    protected void finalize() throws Throwable {
        if (FYEPNKNJHD != null) {
            SwiftNativeInputStream.FDZGGLOBXP.error("Input stream is leaking handles by not being closed() properly: " + FYEPNKNJHD.toString());
        }
    }

    /**
     * Read through the specified number of bytes.
     * The implementation iterates a byte a time, which may seem inefficient
     * compared to the read(bytes[]) method offered by input streams.
     * However, if you look at the code that implements that method, it comes
     * down to read() one char at a time -only here the return value is discarded.
     *
     * <p/>
     * This is a no-op if the stream is closed
     *
     * @param bytes
     * 		number of bytes to read.
     * @throws IOException
     * 		IO problems
     * @throws SwiftException
     * 		if a read returned -1.
     */
    private int chompBytes(long MUOSAPJYDE) throws IOException {
        int OWGRMZNEXH = 0;
        if (FYEPNKNJHD != null) {
            int XQVWLAEJGJ;
            for (long BZQKPCRTGA = 0; BZQKPCRTGA < MUOSAPJYDE; BZQKPCRTGA++) {
                XQVWLAEJGJ = FYEPNKNJHD.read();
                if (XQVWLAEJGJ < 0) {
                    throw new SwiftException("Received error code while chomping input");
                }
                OWGRMZNEXH++;
                incPos(1);
            }
        }
        return OWGRMZNEXH;
    }

    /**
     * Seek to an offset. If the data is already in the buffer, move to it
     *
     * @param targetPos
     * 		target position
     * @throws IOException
     * 		on any problem
     */
    @Override
    public synchronized void seek(long QEMAQQSOJC) throws IOException {
        if (QEMAQQSOJC < 0) {
            throw new EOFException(FSExceptionMessages.NEGATIVE_SEEK);
        }
        // there's some special handling of near-local data
        // as the seek can be omitted if it is in/adjacent
        long DUDMIBMFAX = QEMAQQSOJC - DXMDKTCTOX;
        if (SwiftNativeInputStream.FDZGGLOBXP.isDebugEnabled()) {
            SwiftNativeInputStream.FDZGGLOBXP.debug((((("Seek to " + QEMAQQSOJC) + "; current pos =") + DXMDKTCTOX) + "; offset=") + DUDMIBMFAX);
        }
        if (DUDMIBMFAX == 0) {
            SwiftNativeInputStream.FDZGGLOBXP.debug("seek is no-op");
            return;
        }
        if (DUDMIBMFAX < 0) {
            SwiftNativeInputStream.FDZGGLOBXP.debug("seek is backwards");
        } else
            if ((UBZNUZTNRV + DUDMIBMFAX) < SSFRDHHQNE) {
                // if the seek is in  range of that requested, scan forwards
                // instead of closing and re-opening a new HTTP connection
                SwiftUtils.debug(SwiftNativeInputStream.FDZGGLOBXP, "seek is within current stream" + ("; pos= %d ; targetPos=%d; " + "offset= %d ; bufferOffset=%d"), DXMDKTCTOX, QEMAQQSOJC, DUDMIBMFAX, UBZNUZTNRV);
                try {
                    SwiftNativeInputStream.FDZGGLOBXP.debug("chomping ");
                    chompBytes(DUDMIBMFAX);
                } catch (IOException e) {
                    // this is assumed to be recoverable with a seek -or more likely to fail
                    SwiftNativeInputStream.FDZGGLOBXP.debug("while chomping ", e);
                }
                if ((QEMAQQSOJC - DXMDKTCTOX) == 0) {
                    SwiftNativeInputStream.FDZGGLOBXP.trace("chomping successful");
                    return;
                }
                SwiftNativeInputStream.FDZGGLOBXP.trace("chomping failed");
            } else {
                if (SwiftNativeInputStream.FDZGGLOBXP.isDebugEnabled()) {
                    SwiftNativeInputStream.FDZGGLOBXP.debug("Seek is beyond buffer size of " + SSFRDHHQNE);
                }
            }

        innerClose("seeking to " + QEMAQQSOJC);
        fillBuffer(QEMAQQSOJC);
    }

    /**
     * Fill the buffer from the target position
     * If the target position == current position, the
     * read still goes ahead; this is a way of handling partial read failures
     *
     * @param targetPos
     * 		target position
     * @throws IOException
     * 		IO problems on the read
     */
    private void fillBuffer(long JHDKSOYZDI) throws IOException {
        long STLXQIPLKF = JHDKSOYZDI + SSFRDHHQNE;
        SwiftUtils.debug(SwiftNativeInputStream.FDZGGLOBXP, "Fetching %d bytes starting at %d", STLXQIPLKF, JHDKSOYZDI);
        HttpBodyContent UPQZEITVRL = DJHEVARXON.getObject(NCJHYHCHTW, JHDKSOYZDI, STLXQIPLKF);
        FYEPNKNJHD = UPQZEITVRL.getInputStream();
        updateStartOfBufferPosition(JHDKSOYZDI, UPQZEITVRL.getContentLength());
    }

    @Override
    public synchronized long getPos() throws IOException {
        return DXMDKTCTOX;
    }

    /**
     * This FS doesn't explicitly support multiple data sources, so
     * return false here.
     *
     * @param targetPos
     * 		the desired target position
     * @return true if a new source of the data has been set up
    as the source of future reads
     * @throws IOException
     * 		IO problems
     */
    @Override
    public boolean seekToNewSource(long OZMSXTDOLQ) throws IOException {
        return false;
    }
}