public class TestGenericsUtil extends TestCase {
    public void testToArray() {
        // test a list of size 10
        List<Integer> IWIFDRQTXL = new ArrayList<Integer>();
        for (int RKXIYPCZMH = 0; RKXIYPCZMH < 10; RKXIYPCZMH++) {
            IWIFDRQTXL.add(RKXIYPCZMH);
        }
        Integer[] KDYPBARGZC = GenericsUtil.toArray(IWIFDRQTXL);
        for (int QUTUKSQPMA = 0; QUTUKSQPMA < KDYPBARGZC.length; QUTUKSQPMA++) {
            assertEquals("Array has identical elements as input list", IWIFDRQTXL.get(QUTUKSQPMA), KDYPBARGZC[QUTUKSQPMA]);
        }
    }

    public void testWithEmptyList() {
        try {
            List<String> MWCGCNKVZU = new ArrayList<String>();
            String[] SFCEXYBPXW = GenericsUtil.toArray(MWCGCNKVZU);
            fail("Empty array should throw exception");
            System.out.println(SFCEXYBPXW);// use arr so that compiler will not complain

        } catch (IndexOutOfBoundsException ex) {
            // test case is successful
        }
    }

    public void testWithEmptyList2() {
        List<String> WZOLMNFRQO = new ArrayList<String>();
        // this method should not throw IndexOutOfBoundsException
        String[] EYKEWKLWFI = GenericsUtil.<String>toArray(String.class, WZOLMNFRQO);
        assertEquals("Assert list creation w/ no elements results in length 0", 0, EYKEWKLWFI.length);
    }

    /**
     * This class uses generics
     */
    private class GenericClass<T> {
        T KJMTJFXCAA;

        List<T> BQSXQCHPOD = new ArrayList<T>();

        void add(T item) {
            BQSXQCHPOD.add(item);
        }

        T[] funcThatUsesToArray() {
            T[] arr = GenericsUtil.toArray(BQSXQCHPOD);
            return arr;
        }
    }

    public void testWithGenericClass() {
        TestGenericsUtil.GenericClass<String> XFKSNXQTFM = new TestGenericsUtil.GenericClass<String>();
        XFKSNXQTFM.add("test1");
        XFKSNXQTFM.add("test2");
        try {
            // this cast would fail, if we had not used GenericsUtil.toArray, since the
            // rmethod would return Object[] rather than String[]
            String[] ONDNBWWMQR = XFKSNXQTFM.funcThatUsesToArray();
            assertEquals("test1", ONDNBWWMQR[0]);
            assertEquals("test2", ONDNBWWMQR[1]);
        } catch (ClassCastException ex) {
            fail("GenericsUtil#toArray() is not working for generic classes");
        }
    }

    public void testGenericOptionsParser() throws Exception {
        GenericOptionsParser JSSTSGJPQL = new GenericOptionsParser(new Configuration(), new String[]{ "-jt" });
        assertEquals(0, JSSTSGJPQL.getRemainingArgs().length);
        // test if -D accepts -Dx=y=z
        JSSTSGJPQL = new GenericOptionsParser(new Configuration(), new String[]{ "-Dx=y=z" });
        assertEquals("Options parser gets entire ='s expresion", "y=z", JSSTSGJPQL.getConfiguration().get("x"));
    }

    public void testGetClass() {
        // test with Integer
        Integer ZZZLHUSJBY = new Integer(42);
        Class<Integer> VVFHCIQTSK = GenericsUtil.getClass(ZZZLHUSJBY);
        assertEquals("Correct generic type is acquired from object", Integer.class, VVFHCIQTSK);
        // test with GenericClass<Integer>
        TestGenericsUtil.GenericClass<Integer> NMMARYEDBL = new TestGenericsUtil.GenericClass<Integer>();
        Class<TestGenericsUtil.GenericClass<Integer>> JPRPFESSMG = GenericsUtil.getClass(NMMARYEDBL);
        assertEquals("Inner generics are acquired from object.", TestGenericsUtil.GenericClass.class, JPRPFESSMG);
    }
}