/**
 * Test dir operations on a the local FS.
 */
public class TestHDFSContractConcat extends AbstractContractConcatTest {
    @BeforeClass
    public static void createCluster() throws IOException {
        HDFSContract.createCluster();
        // perform a simple operation on the cluster to verify it is up
        HDFSContract.getCluster().getFileSystem().getDefaultBlockSize();
    }

    @AfterClass
    public static void teardownCluster() throws IOException {
        HDFSContract.destroyCluster();
    }

    @Override
    protected AbstractFSContract createContract(Configuration JISKQEPUYF) {
        return new HDFSContract(JISKQEPUYF);
    }
}