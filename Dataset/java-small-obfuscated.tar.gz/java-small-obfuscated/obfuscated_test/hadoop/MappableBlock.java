/**
 * Represents an HDFS block that is mmapped by the DataNode.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class MappableBlock implements Closeable {
    private MappedByteBuffer LEKFCICUVH;

    private final long BEOZBDLNBK;

    MappableBlock(MappedByteBuffer BDWJSQDFNW, long LELBIHSXVQ) {
        this.LEKFCICUVH = BDWJSQDFNW;
        this.BEOZBDLNBK = LELBIHSXVQ;
        assert LELBIHSXVQ > 0;
    }

    public long getLength() {
        return BEOZBDLNBK;
    }

    /**
     * Load the block.
     *
     * mmap and mlock the block, and then verify its checksum.
     *
     * @param length
     * 		The current length of the block.
     * @param blockIn
     * 		The block input stream.  Should be positioned at the
     * 		start.  The caller must close this.
     * @param metaIn
     * 		The meta file input stream.  Should be positioned at
     * 		the start.  The caller must close this.
     * @param blockFileName
     * 		The block file name, for logging purposes.
     * @return The Mappable block.
     */
    public static MappableBlock load(long OXVPXSAUYD, FileInputStream MPPDTGJZWP, FileInputStream ODYMDDUQCV, String HAIQWOEVTZ) throws IOException {
        MappableBlock HVHJURVHJE = null;
        MappedByteBuffer ASMSGPXWZN = null;
        FileChannel VYRXKTIYJN = null;
        try {
            VYRXKTIYJN = MPPDTGJZWP.getChannel();
            if (VYRXKTIYJN == null) {
                throw new IOException("Block InputStream has no FileChannel.");
            }
            ASMSGPXWZN = VYRXKTIYJN.map(FileChannel.MapMode.READ_ONLY, 0, OXVPXSAUYD);
            POSIX.getCacheManipulator().mlock(HAIQWOEVTZ, ASMSGPXWZN, OXVPXSAUYD);
            MappableBlock.verifyChecksum(OXVPXSAUYD, ODYMDDUQCV, VYRXKTIYJN, HAIQWOEVTZ);
            HVHJURVHJE = new MappableBlock(ASMSGPXWZN, OXVPXSAUYD);
        } finally {
            IOUtils.closeQuietly(VYRXKTIYJN);
            if (HVHJURVHJE == null) {
                if (ASMSGPXWZN != null) {
                    POSIX.munmap(ASMSGPXWZN);// unmapping also unlocks

                }
            }
        }
        return HVHJURVHJE;
    }

    /**
     * Verifies the block's checksum. This is an I/O intensive operation.
     */
    private static void verifyChecksum(long UTYBZLFDZC, FileInputStream UNYHUKICIZ, FileChannel FECIMSWJCD, String APAWPGLZHU) throws IOException, ChecksumException {
        // Verify the checksum from the block's meta file
        // Get the DataChecksum from the meta file header
        BlockMetadataHeader IGPKRWESOM = BlockMetadataHeader.readHeader(new DataInputStream(new BufferedInputStream(UNYHUKICIZ, BlockMetadataHeader.getHeaderSize())));
        FileChannel HEPFBRVSDJ = null;
        try {
            HEPFBRVSDJ = UNYHUKICIZ.getChannel();
            if (HEPFBRVSDJ == null) {
                throw new IOException("Block InputStream meta file has no FileChannel.");
            }
            DataChecksum GGKHKJSGPO = IGPKRWESOM.getChecksum();
            final int OYLZVUROEW = GGKHKJSGPO.getBytesPerChecksum();
            final int HDJYFPGOAK = GGKHKJSGPO.getChecksumSize();
            final int BZOUFNYSVC = ((8 * 1024) * 1024) / OYLZVUROEW;
            ByteBuffer NTNPXCHSZI = ByteBuffer.allocate(BZOUFNYSVC * OYLZVUROEW);
            ByteBuffer PXFCZZSOGS = ByteBuffer.allocate(BZOUFNYSVC * HDJYFPGOAK);
            // Verify the checksum
            int DUDWWIMGWY = 0;
            while (DUDWWIMGWY < UTYBZLFDZC) {
                Preconditions.checkState((DUDWWIMGWY % OYLZVUROEW) == 0, "Unexpected partial chunk before EOF");
                assert (DUDWWIMGWY % OYLZVUROEW) == 0;
                int ESVMXXMWVT = MappableBlock.fillBuffer(FECIMSWJCD, NTNPXCHSZI);
                if (ESVMXXMWVT == (-1)) {
                    throw new IOException("checksum verification failed: premature EOF");
                }
                NTNPXCHSZI.flip();
                // Number of read chunks, including partial chunk at end
                int DNANKUKMKU = ((ESVMXXMWVT + OYLZVUROEW) - 1) / OYLZVUROEW;
                PXFCZZSOGS.limit(DNANKUKMKU * HDJYFPGOAK);
                MappableBlock.fillBuffer(HEPFBRVSDJ, PXFCZZSOGS);
                PXFCZZSOGS.flip();
                GGKHKJSGPO.verifyChunkedSums(NTNPXCHSZI, PXFCZZSOGS, APAWPGLZHU, DUDWWIMGWY);
                // Success
                DUDWWIMGWY += ESVMXXMWVT;
                NTNPXCHSZI.clear();
                PXFCZZSOGS.clear();
            } 
        } finally {
            IOUtils.closeQuietly(HEPFBRVSDJ);
        }
    }

    /**
     * Reads bytes into a buffer until EOF or the buffer's limit is reached
     */
    private static int fillBuffer(FileChannel NOKKFNYXJN, ByteBuffer ZDDEDDSYXI) throws IOException {
        int JFHNUCQCFW = NOKKFNYXJN.read(ZDDEDDSYXI);
        if (JFHNUCQCFW < 0) {
            // EOF
            return JFHNUCQCFW;
        }
        while (ZDDEDDSYXI.remaining() > 0) {
            int PWDEBISJPT = NOKKFNYXJN.read(ZDDEDDSYXI);
            if (PWDEBISJPT < 0) {
                // EOF
                return JFHNUCQCFW;
            }
            JFHNUCQCFW += PWDEBISJPT;
        } 
        return JFHNUCQCFW;
    }

    @Override
    public void close() {
        if (LEKFCICUVH != null) {
            POSIX.munmap(LEKFCICUVH);
            LEKFCICUVH = null;
        }
    }
}