public class MockAppContext implements AppContext {
    final ApplicationAttemptId ZQSWGCVTXS;

    final ApplicationId ELSUTZVMBO;

    final String WBHEKLQNBQ = MockJobs.newUserName();

    final Map<JobId, Job> WNYUMTEXVL;

    final long QAERGZAQYY = System.currentTimeMillis();

    Set<String> ADBUPMDFXX;

    String LQHPSYIOBM;

    public MockAppContext(int XQINTFFQHG) {
        ELSUTZVMBO = MockJobs.newAppID(XQINTFFQHG);
        ZQSWGCVTXS = ApplicationAttemptId.newInstance(ELSUTZVMBO, 0);
        WNYUMTEXVL = null;
    }

    public MockAppContext(int LGLRZRDUSI, int NSRVDYCCHP, int IBWPISLRQK, Path ZZFVCBTJCM) {
        ELSUTZVMBO = MockJobs.newAppID(LGLRZRDUSI);
        ZQSWGCVTXS = ApplicationAttemptId.newInstance(ELSUTZVMBO, 0);
        Map<JobId, Job> AOQCZNJYXO = Maps.newHashMap();
        Job NYKNPYOIWO = MockJobs.newJob(ELSUTZVMBO, 0, NSRVDYCCHP, IBWPISLRQK, ZZFVCBTJCM);
        AOQCZNJYXO.put(NYKNPYOIWO.getID(), NYKNPYOIWO);
        WNYUMTEXVL = AOQCZNJYXO;
    }

    public MockAppContext(int RENPDBTRZH, int BJHEIUFFEA, int WXLPSRPNZN, int ASAYBMOCMR) {
        this(RENPDBTRZH, BJHEIUFFEA, WXLPSRPNZN, ASAYBMOCMR, false);
    }

    public MockAppContext(int LSPPXGABWW, int ZXIZJMREEL, int HAIKLHKDMZ, int MFOIPKXZUQ, boolean CEIGEZDVDT) {
        ELSUTZVMBO = MockJobs.newAppID(LSPPXGABWW);
        ZQSWGCVTXS = ApplicationAttemptId.newInstance(ELSUTZVMBO, 0);
        WNYUMTEXVL = MockJobs.newJobs(ELSUTZVMBO, ZXIZJMREEL, HAIKLHKDMZ, MFOIPKXZUQ, CEIGEZDVDT);
    }

    @Override
    public ApplicationAttemptId getApplicationAttemptId() {
        return ZQSWGCVTXS;
    }

    @Override
    public ApplicationId getApplicationID() {
        return ELSUTZVMBO;
    }

    @Override
    public CharSequence getUser() {
        return WBHEKLQNBQ;
    }

    @Override
    public Job getJob(JobId HNYVDZENLB) {
        return WNYUMTEXVL.get(HNYVDZENLB);
    }

    @Override
    public Map<JobId, Job> getAllJobs() {
        return WNYUMTEXVL;// OK

    }

    @SuppressWarnings("rawtypes")
    @Override
    public EventHandler getEventHandler() {
        return null;
    }

    @Override
    public Clock getClock() {
        return null;
    }

    @Override
    public String getApplicationName() {
        return "TestApp";
    }

    @Override
    public long getStartTime() {
        return QAERGZAQYY;
    }

    @Override
    public ClusterInfo getClusterInfo() {
        return null;
    }

    @Override
    public Set<String> getBlacklistedNodes() {
        return ADBUPMDFXX;
    }

    public void setBlacklistedNodes(Set<String> VKPPXDHBGF) {
        this.ADBUPMDFXX = VKPPXDHBGF;
    }

    public ClientToAMTokenSecretManager getClientToAMTokenSecretManager() {
        // Not implemented
        return null;
    }

    @Override
    public boolean isLastAMRetry() {
        return false;
    }

    @Override
    public boolean hasSuccessfullyUnregistered() {
        // bogus - Not Required
        return true;
    }

    @Override
    public String getNMHostname() {
        // bogus - Not Required
        return null;
    }
}