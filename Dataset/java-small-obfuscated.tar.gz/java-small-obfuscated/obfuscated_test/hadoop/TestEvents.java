public class TestEvents {
    /**
     * test a getters of TaskAttemptFinishedEvent and TaskAttemptFinished
     *
     * @throws Exception
     * 		
     */
    @Test(timeout = 10000)
    public void testTaskAttemptFinishedEvent() throws Exception {
        JobID QWRJXVCQAJ = new JobID("001", 1);
        TaskID JVNPTUREFE = new TaskID(QWRJXVCQAJ, TaskType.REDUCE, 2);
        TaskAttemptID SNMIKRUBKR = new TaskAttemptID(JVNPTUREFE, 3);
        Counters MHBKPYKNCD = new Counters();
        TaskAttemptFinishedEvent JAJWDATQPY = new TaskAttemptFinishedEvent(SNMIKRUBKR, TaskType.REDUCE, "TEST", 123L, "RAKNAME", "HOSTNAME", "STATUS", MHBKPYKNCD);
        assertEquals(JAJWDATQPY.getAttemptId().toString(), SNMIKRUBKR.toString());
        assertEquals(JAJWDATQPY.getCounters(), MHBKPYKNCD);
        assertEquals(JAJWDATQPY.getFinishTime(), 123L);
        assertEquals(JAJWDATQPY.getHostname(), "HOSTNAME");
        assertEquals(JAJWDATQPY.getRackName(), "RAKNAME");
        assertEquals(JAJWDATQPY.getState(), "STATUS");
        assertEquals(JAJWDATQPY.getTaskId(), JVNPTUREFE);
        assertEquals(JAJWDATQPY.getTaskStatus(), "TEST");
        assertEquals(JAJWDATQPY.getTaskType(), TaskType.REDUCE);
    }

    /**
     * simple test JobPriorityChangeEvent and JobPriorityChange
     *
     * @throws Exception
     * 		
     */
    @Test(timeout = 10000)
    public void testJobPriorityChange() throws Exception {
        org.apache.hadoop.mapreduce.JobID XGOSWHTYBP = new JobID("001", 1);
        JobPriorityChangeEvent HVWTHGZVWD = new JobPriorityChangeEvent(XGOSWHTYBP, JobPriority.LOW);
        assertEquals(HVWTHGZVWD.getJobId().toString(), XGOSWHTYBP.toString());
        assertEquals(HVWTHGZVWD.getPriority(), JobPriority.LOW);
    }

    @Test(timeout = 10000)
    public void testJobQueueChange() throws Exception {
        org.apache.hadoop.mapreduce.JobID JJOWXZRXJS = new JobID("001", 1);
        JobQueueChangeEvent HZSLQZBEIV = new JobQueueChangeEvent(JJOWXZRXJS, "newqueue");
        assertEquals(HZSLQZBEIV.getJobId().toString(), JJOWXZRXJS.toString());
        assertEquals(HZSLQZBEIV.getJobQueueName(), "newqueue");
    }

    /**
     * simple test TaskUpdatedEvent and TaskUpdated
     *
     * @throws Exception
     * 		
     */
    @Test(timeout = 10000)
    public void testTaskUpdated() throws Exception {
        JobID HWIZRNRPBQ = new JobID("001", 1);
        TaskID QJRCVMHGUV = new TaskID(HWIZRNRPBQ, TaskType.REDUCE, 2);
        TaskUpdatedEvent FUVMZJLIXN = new TaskUpdatedEvent(QJRCVMHGUV, 1234L);
        assertEquals(FUVMZJLIXN.getTaskId().toString(), QJRCVMHGUV.toString());
        assertEquals(FUVMZJLIXN.getFinishTime(), 1234L);
    }

    /* test EventReader EventReader should read the list of events and return
    instance of HistoryEvent Different HistoryEvent should have a different
    datum.
     */
    @Test(timeout = 10000)
    public void testEvents() throws Exception {
        EventReader KLRTNQQKYV = new EventReader(new DataInputStream(new ByteArrayInputStream(getEvents())));
        HistoryEvent DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(JOB_PRIORITY_CHANGED));
        assertEquals("ID", ((JobPriorityChange) (DVIQCXNQVO.getDatum())).jobid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(JOB_STATUS_CHANGED));
        assertEquals("ID", ((JobStatusChanged) (DVIQCXNQVO.getDatum())).jobid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(TASK_UPDATED));
        assertEquals("ID", ((TaskUpdated) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_KILLED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptUnsuccessfulCompletion) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(JOB_KILLED));
        assertEquals("ID", ((JobUnsuccessfulCompletion) (DVIQCXNQVO.getDatum())).jobid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_STARTED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptStarted) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_FINISHED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptFinished) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_KILLED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptUnsuccessfulCompletion) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_KILLED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptUnsuccessfulCompletion) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_STARTED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptStarted) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_FINISHED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptFinished) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_KILLED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptUnsuccessfulCompletion) (DVIQCXNQVO.getDatum())).taskid.toString());
        DVIQCXNQVO = KLRTNQQKYV.getNextEvent();
        assertTrue(DVIQCXNQVO.getEventType().equals(REDUCE_ATTEMPT_KILLED));
        assertEquals("task_1_2_r03_4", ((TaskAttemptUnsuccessfulCompletion) (DVIQCXNQVO.getDatum())).taskid.toString());
        KLRTNQQKYV.close();
    }

    /* makes array of bytes with History events */
    private byte[] getEvents() throws Exception {
        ByteArrayOutputStream DKYTYKUZIM = new ByteArrayOutputStream();
        FSDataOutputStream HDRUHZWQPB = new FSDataOutputStream(DKYTYKUZIM, new FileSystem.Statistics("scheme"));
        EventWriter PFEYKBXAKD = new EventWriter(HDRUHZWQPB);
        PFEYKBXAKD.write(getJobPriorityChangedEvent());
        PFEYKBXAKD.write(getJobStatusChangedEvent());
        PFEYKBXAKD.write(getTaskUpdatedEvent());
        PFEYKBXAKD.write(getReduceAttemptKilledEvent());
        PFEYKBXAKD.write(getJobKilledEvent());
        PFEYKBXAKD.write(getSetupAttemptStartedEvent());
        PFEYKBXAKD.write(getTaskAttemptFinishedEvent());
        PFEYKBXAKD.write(getSetupAttemptFieledEvent());
        PFEYKBXAKD.write(getSetupAttemptKilledEvent());
        PFEYKBXAKD.write(getCleanupAttemptStartedEvent());
        PFEYKBXAKD.write(getCleanupAttemptFinishedEvent());
        PFEYKBXAKD.write(getCleanupAttemptFiledEvent());
        PFEYKBXAKD.write(getCleanupAttemptKilledEvent());
        PFEYKBXAKD.flush();
        PFEYKBXAKD.close();
        return DKYTYKUZIM.toByteArray();
    }

    private TestEvents.FakeEvent getCleanupAttemptKilledEvent() {
        TestEvents.FakeEvent FOEEGJXBEC = new TestEvents.FakeEvent(EventType.CLEANUP_ATTEMPT_KILLED);
        FOEEGJXBEC.setDatum(getTaskAttemptUnsuccessfulCompletion());
        return FOEEGJXBEC;
    }

    private TestEvents.FakeEvent getCleanupAttemptFiledEvent() {
        TestEvents.FakeEvent EBMJCCRGNE = new TestEvents.FakeEvent(EventType.CLEANUP_ATTEMPT_FAILED);
        EBMJCCRGNE.setDatum(getTaskAttemptUnsuccessfulCompletion());
        return EBMJCCRGNE;
    }

    private TaskAttemptUnsuccessfulCompletion getTaskAttemptUnsuccessfulCompletion() {
        TaskAttemptUnsuccessfulCompletion ZMAPFUQRKB = new TaskAttemptUnsuccessfulCompletion();
        ZMAPFUQRKB.attemptId = "attempt_1_2_r3_4_5";
        ZMAPFUQRKB.clockSplits = Arrays.asList(1, 2, 3);
        ZMAPFUQRKB.cpuUsages = Arrays.asList(100, 200, 300);
        ZMAPFUQRKB.error = "Error";
        ZMAPFUQRKB.finishTime = 2;
        ZMAPFUQRKB.hostname = "hostname";
        ZMAPFUQRKB.rackname = "rackname";
        ZMAPFUQRKB.physMemKbytes = Arrays.asList(1000, 2000, 3000);
        ZMAPFUQRKB.taskid = "task_1_2_r03_4";
        ZMAPFUQRKB.port = 1000;
        ZMAPFUQRKB.taskType = "REDUCE";
        ZMAPFUQRKB.status = "STATUS";
        ZMAPFUQRKB.counters = getCounters();
        ZMAPFUQRKB.vMemKbytes = Arrays.asList(1000, 2000, 3000);
        return ZMAPFUQRKB;
    }

    private JhCounters getCounters() {
        JhCounters WCCUTUBPMM = new JhCounters();
        WCCUTUBPMM.groups = new ArrayList<JhCounterGroup>(0);
        WCCUTUBPMM.name = "name";
        return WCCUTUBPMM;
    }

    private TestEvents.FakeEvent getCleanupAttemptFinishedEvent() {
        TestEvents.FakeEvent AFKZSULPHJ = new TestEvents.FakeEvent(EventType.CLEANUP_ATTEMPT_FINISHED);
        TaskAttemptFinished HNOAOENZNQ = new TaskAttemptFinished();
        HNOAOENZNQ.attemptId = "attempt_1_2_r3_4_5";
        HNOAOENZNQ.counters = getCounters();
        HNOAOENZNQ.finishTime = 2;
        HNOAOENZNQ.hostname = "hostname";
        HNOAOENZNQ.rackname = "rackName";
        HNOAOENZNQ.state = "state";
        HNOAOENZNQ.taskid = "task_1_2_r03_4";
        HNOAOENZNQ.taskStatus = "taskStatus";
        HNOAOENZNQ.taskType = "REDUCE";
        AFKZSULPHJ.setDatum(HNOAOENZNQ);
        return AFKZSULPHJ;
    }

    private TestEvents.FakeEvent getCleanupAttemptStartedEvent() {
        TestEvents.FakeEvent XUBSYZQLDC = new TestEvents.FakeEvent(EventType.CLEANUP_ATTEMPT_STARTED);
        TaskAttemptStarted JZNMYSGEJD = new TaskAttemptStarted();
        JZNMYSGEJD.attemptId = "attempt_1_2_r3_4_5";
        JZNMYSGEJD.avataar = "avatar";
        JZNMYSGEJD.containerId = "containerId";
        JZNMYSGEJD.httpPort = 10000;
        JZNMYSGEJD.locality = "locality";
        JZNMYSGEJD.shufflePort = 10001;
        JZNMYSGEJD.startTime = 1;
        JZNMYSGEJD.taskid = "task_1_2_r03_4";
        JZNMYSGEJD.taskType = "taskType";
        JZNMYSGEJD.trackerName = "trackerName";
        XUBSYZQLDC.setDatum(JZNMYSGEJD);
        return XUBSYZQLDC;
    }

    private TestEvents.FakeEvent getSetupAttemptKilledEvent() {
        TestEvents.FakeEvent OMZYZIWTIS = new TestEvents.FakeEvent(EventType.SETUP_ATTEMPT_KILLED);
        OMZYZIWTIS.setDatum(getTaskAttemptUnsuccessfulCompletion());
        return OMZYZIWTIS;
    }

    private TestEvents.FakeEvent getSetupAttemptFieledEvent() {
        TestEvents.FakeEvent EFAMBEJDVQ = new TestEvents.FakeEvent(EventType.SETUP_ATTEMPT_FAILED);
        EFAMBEJDVQ.setDatum(getTaskAttemptUnsuccessfulCompletion());
        return EFAMBEJDVQ;
    }

    private TestEvents.FakeEvent getTaskAttemptFinishedEvent() {
        TestEvents.FakeEvent OUNWXPKMUL = new TestEvents.FakeEvent(EventType.SETUP_ATTEMPT_FINISHED);
        TaskAttemptFinished CNAKJDJNCC = new TaskAttemptFinished();
        CNAKJDJNCC.attemptId = "attempt_1_2_r3_4_5";
        CNAKJDJNCC.counters = getCounters();
        CNAKJDJNCC.finishTime = 2;
        CNAKJDJNCC.hostname = "hostname";
        CNAKJDJNCC.rackname = "rackname";
        CNAKJDJNCC.state = "state";
        CNAKJDJNCC.taskid = "task_1_2_r03_4";
        CNAKJDJNCC.taskStatus = "taskStatus";
        CNAKJDJNCC.taskType = "REDUCE";
        OUNWXPKMUL.setDatum(CNAKJDJNCC);
        return OUNWXPKMUL;
    }

    private TestEvents.FakeEvent getSetupAttemptStartedEvent() {
        TestEvents.FakeEvent LFWCILAOTP = new TestEvents.FakeEvent(EventType.SETUP_ATTEMPT_STARTED);
        TaskAttemptStarted AWZZKDKJVN = new TaskAttemptStarted();
        AWZZKDKJVN.attemptId = "ID";
        AWZZKDKJVN.avataar = "avataar";
        AWZZKDKJVN.containerId = "containerId";
        AWZZKDKJVN.httpPort = 10000;
        AWZZKDKJVN.locality = "locality";
        AWZZKDKJVN.shufflePort = 10001;
        AWZZKDKJVN.startTime = 1;
        AWZZKDKJVN.taskid = "task_1_2_r03_4";
        AWZZKDKJVN.taskType = "taskType";
        AWZZKDKJVN.trackerName = "trackerName";
        LFWCILAOTP.setDatum(AWZZKDKJVN);
        return LFWCILAOTP;
    }

    private TestEvents.FakeEvent getJobKilledEvent() {
        TestEvents.FakeEvent ERLVAZYAZC = new TestEvents.FakeEvent(EventType.JOB_KILLED);
        JobUnsuccessfulCompletion QEXQRFZUHZ = new JobUnsuccessfulCompletion();
        QEXQRFZUHZ.setFinishedMaps(1);
        QEXQRFZUHZ.setFinishedReduces(2);
        QEXQRFZUHZ.setFinishTime(3L);
        QEXQRFZUHZ.setJobid("ID");
        QEXQRFZUHZ.setJobStatus("STATUS");
        QEXQRFZUHZ.setDiagnostics(JOB_KILLED_DIAG);
        ERLVAZYAZC.setDatum(QEXQRFZUHZ);
        return ERLVAZYAZC;
    }

    private TestEvents.FakeEvent getReduceAttemptKilledEvent() {
        TestEvents.FakeEvent WJWZATOWAF = new TestEvents.FakeEvent(EventType.REDUCE_ATTEMPT_KILLED);
        WJWZATOWAF.setDatum(getTaskAttemptUnsuccessfulCompletion());
        return WJWZATOWAF;
    }

    private TestEvents.FakeEvent getJobPriorityChangedEvent() {
        TestEvents.FakeEvent SOLJZVYATK = new TestEvents.FakeEvent(EventType.JOB_PRIORITY_CHANGED);
        JobPriorityChange IEZYJKZRUJ = new JobPriorityChange();
        IEZYJKZRUJ.jobid = "ID";
        IEZYJKZRUJ.priority = "priority";
        SOLJZVYATK.setDatum(IEZYJKZRUJ);
        return SOLJZVYATK;
    }

    private TestEvents.FakeEvent getJobStatusChangedEvent() {
        TestEvents.FakeEvent DXYGQAWLXG = new TestEvents.FakeEvent(EventType.JOB_STATUS_CHANGED);
        JobStatusChanged LXSHGCVABD = new JobStatusChanged();
        LXSHGCVABD.jobid = "ID";
        LXSHGCVABD.jobStatus = "newStatus";
        DXYGQAWLXG.setDatum(LXSHGCVABD);
        return DXYGQAWLXG;
    }

    private TestEvents.FakeEvent getTaskUpdatedEvent() {
        TestEvents.FakeEvent OTZQZMBMUU = new TestEvents.FakeEvent(EventType.TASK_UPDATED);
        TaskUpdated XDBSPBEOUE = new TaskUpdated();
        XDBSPBEOUE.finishTime = 2;
        XDBSPBEOUE.taskid = "ID";
        OTZQZMBMUU.setDatum(XDBSPBEOUE);
        return OTZQZMBMUU;
    }

    private class FakeEvent implements HistoryEvent {
        private EventType ARRGPZBNXC;

        private Object FFMUQWCIIW;

        public FakeEvent(EventType eventType) {
            this.ARRGPZBNXC = eventType;
        }

        @Override
        public EventType getEventType() {
            return ARRGPZBNXC;
        }

        @Override
        public Object getDatum() {
            return FFMUQWCIIW;
        }

        @Override
        public void setDatum(Object datum) {
            this.FFMUQWCIIW = datum;
        }
    }
}