/**
 * A shared memory segment used to implement short-circuit reads.
 */
public class ShortCircuitShm {
    private static final Log URBJLGDAAH = LogFactory.getLog(ShortCircuitShm.class);

    protected static final int PJLAXRXXJT = 64;

    private static final Unsafe JVFQMPCHHQ = ShortCircuitShm.safetyDance();

    private static Unsafe safetyDance() {
        try {
            Field IFTZMCZMJA = Unsafe.class.getDeclaredField("theUnsafe");
            IFTZMCZMJA.setAccessible(true);
            return ((Unsafe) (IFTZMCZMJA.get(null)));
        } catch (Throwable e) {
            ShortCircuitShm.URBJLGDAAH.error("failed to load misc.Unsafe", e);
        }
        return null;
    }

    /**
     * Calculate the usable size of a shared memory segment.
     * We round down to a multiple of the slot size and do some validation.
     *
     * @param stream
     * 		The stream we're using.
     * @return The usable size of the shared memory segment.
     */
    private static int getUsableLength(FileInputStream FOAUMRZZIP) throws IOException {
        int OBPDSXYHMF = Ints.checkedCast(FOAUMRZZIP.getChannel().size());
        int NSSXQZNJHK = OBPDSXYHMF / ShortCircuitShm.PJLAXRXXJT;
        if (NSSXQZNJHK == 0) {
            throw new IOException(("size of shared memory segment was " + OBPDSXYHMF) + ", but that is not enough to hold even one slot.");
        }
        return NSSXQZNJHK * ShortCircuitShm.PJLAXRXXJT;
    }

    /**
     * Identifies a DfsClientShm.
     */
    public static class ShmId implements Comparable<ShortCircuitShm.ShmId> {
        private static final Random JPHOPZACVN = new Random();

        private final long MENZDCOTJE;

        private final long MANGJZYGFC;

        /**
         * Generate a random ShmId.
         *
         * We generate ShmIds randomly to prevent a malicious client from
         * successfully guessing one and using that to interfere with another
         * client.
         */
        public static ShortCircuitShm.ShmId createRandom() {
            return new ShortCircuitShm.ShmId(ShortCircuitShm.ShmId.JPHOPZACVN.nextLong(), ShortCircuitShm.ShmId.JPHOPZACVN.nextLong());
        }

        public ShmId(long hi, long lo) {
            this.MENZDCOTJE = hi;
            this.MANGJZYGFC = lo;
        }

        public long getHi() {
            return MENZDCOTJE;
        }

        public long getLo() {
            return MANGJZYGFC;
        }

        @Override
        public boolean equals(Object o) {
            if ((o == null) || (o.getClass() != this.getClass())) {
                return false;
            }
            ShortCircuitShm.ShmId other = ((ShortCircuitShm.ShmId) (o));
            return new org.apache.commons.lang.builder.EqualsBuilder().append(MENZDCOTJE, other.MENZDCOTJE).append(MANGJZYGFC, other.MANGJZYGFC).isEquals();
        }

        @Override
        public int hashCode() {
            return new org.apache.commons.lang.builder.HashCodeBuilder().append(this.MENZDCOTJE).append(this.MANGJZYGFC).toHashCode();
        }

        @Override
        public String toString() {
            return String.format("%016x%016x", MENZDCOTJE, MANGJZYGFC);
        }

        @Override
        public int compareTo(ShortCircuitShm.ShmId other) {
            return com.google.common.collect.ComparisonChain.start().compare(MENZDCOTJE, other.MENZDCOTJE).compare(MANGJZYGFC, other.MANGJZYGFC).result();
        }
    }

    /**
     * Uniquely identifies a slot.
     */
    public static class SlotId {
        private final ShortCircuitShm.ShmId THSXKICSJH;

        private final int CPFBWVIBCG;

        public SlotId(ShortCircuitShm.ShmId shmId, int slotIdx) {
            this.THSXKICSJH = shmId;
            this.CPFBWVIBCG = slotIdx;
        }

        public ShortCircuitShm.ShmId getShmId() {
            return THSXKICSJH;
        }

        public int getSlotIdx() {
            return CPFBWVIBCG;
        }

        @Override
        public boolean equals(Object o) {
            if ((o == null) || (o.getClass() != this.getClass())) {
                return false;
            }
            ShortCircuitShm.SlotId other = ((ShortCircuitShm.SlotId) (o));
            return new org.apache.commons.lang.builder.EqualsBuilder().append(THSXKICSJH, other.THSXKICSJH).append(CPFBWVIBCG, other.CPFBWVIBCG).isEquals();
        }

        @Override
        public int hashCode() {
            return new org.apache.commons.lang.builder.HashCodeBuilder().append(this.THSXKICSJH).append(this.CPFBWVIBCG).toHashCode();
        }

        @Override
        public String toString() {
            return String.format("SlotId(%s:%d)", THSXKICSJH.toString(), CPFBWVIBCG);
        }
    }

    public class SlotIterator implements Iterator<ShortCircuitShm.Slot> {
        int ISWIWQLUPZ = -1;

        @Override
        public boolean hasNext() {
            synchronized(ShortCircuitShm.this) {
                return RJDDFZAGJS.nextSetBit(ISWIWQLUPZ + 1) != (-1);
            }
        }

        @Override
        public ShortCircuitShm.Slot next() {
            synchronized(ShortCircuitShm.this) {
                int nextSlotIdx = RJDDFZAGJS.nextSetBit(ISWIWQLUPZ + 1);
                if (nextSlotIdx == (-1)) {
                    throw new NoSuchElementException();
                }
                ISWIWQLUPZ = nextSlotIdx;
                return FFANJXYBCX[nextSlotIdx];
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("SlotIterator " + "doesn't support removal");
        }
    }

    /**
     * A slot containing information about a replica.
     *
     * The format is:
     * word 0
     *   bit 0:32   Slot flags (see below).
     *   bit 33:63  Anchor count.
     * word 1:7
     *   Reserved for future use, such as statistics.
     *   Padding is also useful for avoiding false sharing.
     *
     * Little-endian versus big-endian is not relevant here since both the client
     * and the server reside on the same computer and use the same orientation.
     */
    public class Slot {
        /**
         * Flag indicating that the slot is valid.
         *
         * The DFSClient sets this flag when it allocates a new slot within one of
         * its shared memory regions.
         *
         * The DataNode clears this flag when the replica associated with this slot
         * is no longer valid.  The client itself also clears this flag when it
         * believes that the DataNode is no longer using this slot to communicate.
         */
        private static final long LRZXKXEBAD = 1L << 63;

        /**
         * Flag indicating that the slot can be anchored.
         */
        private static final long TMXMGTPOMP = 1L << 62;

        /**
         * The slot address in memory.
         */
        private final long OQHHVNEWBS;

        /**
         * BlockId of the block this slot is used for.
         */
        private final ExtendedBlockId ZAAUPBGXDO;

        Slot(long slotAddress, ExtendedBlockId blockId) {
            this.OQHHVNEWBS = slotAddress;
            this.ZAAUPBGXDO = blockId;
        }

        /**
         * Get the short-circuit memory segment associated with this Slot.
         *
         * @return The enclosing short-circuit memory segment.
         */
        public ShortCircuitShm getShm() {
            return ShortCircuitShm.this;
        }

        /**
         * Get the ExtendedBlockId associated with this slot.
         *
         * @return The ExtendedBlockId of this slot.
         */
        public ExtendedBlockId getBlockId() {
            return ZAAUPBGXDO;
        }

        /**
         * Get the SlotId of this slot, containing both shmId and slotIdx.
         *
         * @return The SlotId of this slot.
         */
        public ShortCircuitShm.SlotId getSlotId() {
            return new ShortCircuitShm.SlotId(getShmId(), getSlotIdx());
        }

        /**
         * Get the Slot index.
         *
         * @return The index of this slot.
         */
        public int getSlotIdx() {
            return Ints.checkedCast((OQHHVNEWBS - AWMSRBPRSY) / ShortCircuitShm.PJLAXRXXJT);
        }

        /**
         * Clear the slot.
         */
        void clear() {
            ShortCircuitShm.JVFQMPCHHQ.putLongVolatile(null, this.OQHHVNEWBS, 0);
        }

        private boolean isSet(long flag) {
            long prev = ShortCircuitShm.JVFQMPCHHQ.getLongVolatile(null, this.OQHHVNEWBS);
            return (prev & flag) != 0;
        }

        private void setFlag(long flag) {
            long prev;
            do {
                prev = ShortCircuitShm.JVFQMPCHHQ.getLongVolatile(null, this.OQHHVNEWBS);
                if ((prev & flag) != 0) {
                    return;
                }
            } while (!ShortCircuitShm.JVFQMPCHHQ.compareAndSwapLong(null, this.OQHHVNEWBS, prev, prev | flag) );
        }

        private void clearFlag(long flag) {
            long prev;
            do {
                prev = ShortCircuitShm.JVFQMPCHHQ.getLongVolatile(null, this.OQHHVNEWBS);
                if ((prev & flag) == 0) {
                    return;
                }
            } while (!ShortCircuitShm.JVFQMPCHHQ.compareAndSwapLong(null, this.OQHHVNEWBS, prev, prev & (~flag)) );
        }

        public boolean isValid() {
            return isSet(ShortCircuitShm.Slot.LRZXKXEBAD);
        }

        public void makeValid() {
            setFlag(ShortCircuitShm.Slot.LRZXKXEBAD);
        }

        public void makeInvalid() {
            clearFlag(ShortCircuitShm.Slot.LRZXKXEBAD);
        }

        public boolean isAnchorable() {
            return isSet(ShortCircuitShm.Slot.TMXMGTPOMP);
        }

        public void makeAnchorable() {
            setFlag(ShortCircuitShm.Slot.TMXMGTPOMP);
        }

        public void makeUnanchorable() {
            clearFlag(ShortCircuitShm.Slot.TMXMGTPOMP);
        }

        public boolean isAnchored() {
            long prev = ShortCircuitShm.JVFQMPCHHQ.getLongVolatile(null, this.OQHHVNEWBS);
            if ((prev & ShortCircuitShm.Slot.LRZXKXEBAD) == 0) {
                // Slot is no longer valid.
                return false;
            }
            return (prev & 0x7fffffff) != 0;
        }

        /**
         * Try to add an anchor for a given slot.
         *
         * When a slot is anchored, we know that the block it refers to is resident
         * in memory.
         *
         * @return True if the slot is anchored.
         */
        public boolean addAnchor() {
            long prev;
            do {
                prev = ShortCircuitShm.JVFQMPCHHQ.getLongVolatile(null, this.OQHHVNEWBS);
                if ((prev & ShortCircuitShm.Slot.LRZXKXEBAD) == 0) {
                    // Slot is no longer valid.
                    return false;
                }
                if ((prev & ShortCircuitShm.Slot.TMXMGTPOMP) == 0) {
                    // Slot can't be anchored right now.
                    return false;
                }
                if ((prev & 0x7fffffff) == 0x7fffffff) {
                    // Too many other threads have anchored the slot (2 billion?)
                    return false;
                }
            } while (!ShortCircuitShm.JVFQMPCHHQ.compareAndSwapLong(null, this.OQHHVNEWBS, prev, prev + 1) );
            return true;
        }

        /**
         * Remove an anchor for a given slot.
         */
        public void removeAnchor() {
            long prev;
            do {
                prev = ShortCircuitShm.JVFQMPCHHQ.getLongVolatile(null, this.OQHHVNEWBS);
                Preconditions.checkState((prev & 0x7fffffff) != 0, (("Tried to remove anchor for slot " + OQHHVNEWBS) + ", which was ") + "not anchored.");
            } while (!ShortCircuitShm.JVFQMPCHHQ.compareAndSwapLong(null, this.OQHHVNEWBS, prev, prev - 1) );
        }

        @Override
        public String toString() {
            return ((("Slot(slotIdx=" + getSlotIdx()) + ", shm=") + getShm()) + ")";
        }
    }

    /**
     * ID for this SharedMemorySegment.
     */
    private final ShortCircuitShm.ShmId AHGTXQBCBS;

    /**
     * The base address of the memory-mapped file.
     */
    private final long AWMSRBPRSY;

    /**
     * The mmapped length of the shared memory segment
     */
    private final int KBVLANXZQR;

    /**
     * The slots associated with this shared memory segment.
     * slot[i] contains the slot at offset i * BYTES_PER_SLOT,
     * or null if that slot is not allocated.
     */
    private final ShortCircuitShm.Slot[] FFANJXYBCX;

    /**
     * A bitset where each bit represents a slot which is in use.
     */
    private final BitSet RJDDFZAGJS;

    /**
     * Create the ShortCircuitShm.
     *
     * @param shmId
     * 		The ID to use.
     * @param stream
     * 		The stream that we're going to use to create this
     * 		shared memory segment.
     * 		
     * 		Although this is a FileInputStream, we are going to
     * 		assume that the underlying file descriptor is writable
     * 		as well as readable. It would be more appropriate to use
     * 		a RandomAccessFile here, but that class does not have
     * 		any public accessor which returns a FileDescriptor,
     * 		unlike FileInputStream.
     */
    public ShortCircuitShm(ShortCircuitShm.ShmId KOTKNPNDVD, FileInputStream RDAHAQHZUJ) throws IOException {
        if (!NativeIO.isAvailable()) {
            throw new UnsupportedOperationException("NativeIO is not available.");
        }
        if (Shell.WINDOWS) {
            throw new UnsupportedOperationException("DfsClientShm is not yet implemented for Windows.");
        }
        if (ShortCircuitShm.JVFQMPCHHQ == null) {
            throw new UnsupportedOperationException("can't use DfsClientShm because we failed to " + "load misc.Unsafe.");
        }
        this.AHGTXQBCBS = KOTKNPNDVD;
        this.KBVLANXZQR = ShortCircuitShm.getUsableLength(RDAHAQHZUJ);
        this.AWMSRBPRSY = POSIX.mmap(RDAHAQHZUJ.getFD(), POSIX.MMAP_PROT_READ | POSIX.MMAP_PROT_WRITE, true, KBVLANXZQR);
        this.FFANJXYBCX = new ShortCircuitShm.Slot[KBVLANXZQR / ShortCircuitShm.PJLAXRXXJT];
        this.RJDDFZAGJS = new BitSet(FFANJXYBCX.length);
        if (ShortCircuitShm.URBJLGDAAH.isTraceEnabled()) {
            ShortCircuitShm.URBJLGDAAH.trace(((((((((("creating " + this.getClass().getSimpleName()) + "(shmId=") + KOTKNPNDVD) + ", mmappedLength=") + KBVLANXZQR) + ", baseAddress=") + String.format("%x", AWMSRBPRSY)) + ", slots.length=") + FFANJXYBCX.length) + ")");
        }
    }

    public final ShortCircuitShm.ShmId getShmId() {
        return AHGTXQBCBS;
    }

    /**
     * Determine if this shared memory object is empty.
     *
     * @return True if the shared memory object is empty.
     */
    public final synchronized boolean isEmpty() {
        return RJDDFZAGJS.nextSetBit(0) == (-1);
    }

    /**
     * Determine if this shared memory object is full.
     *
     * @return True if the shared memory object is full.
     */
    public final synchronized boolean isFull() {
        return RJDDFZAGJS.nextClearBit(0) >= FFANJXYBCX.length;
    }

    /**
     * Calculate the base address of a slot.
     *
     * @param slotIdx
     * 		Index of the slot.
     * @return The base address of the slot.
     */
    private final long calculateSlotAddress(int NHSYYEAICW) {
        long XIYFXFNGKQ = NHSYYEAICW;
        XIYFXFNGKQ *= ShortCircuitShm.PJLAXRXXJT;
        return this.AWMSRBPRSY + XIYFXFNGKQ;
    }

    /**
     * Allocate a new slot and register it.
     *
     * This function chooses an empty slot, initializes it, and then returns
     * the relevant Slot object.
     *
     * @return The new slot.
     */
    public final synchronized ShortCircuitShm.Slot allocAndRegisterSlot(ExtendedBlockId FDJOHIMQPB) {
        int ILSFNWZLGV = RJDDFZAGJS.nextClearBit(0);
        if (ILSFNWZLGV >= FFANJXYBCX.length) {
            throw new RuntimeException(this + ": no more slots are available.");
        }
        RJDDFZAGJS.set(ILSFNWZLGV, true);
        ShortCircuitShm.Slot WZEWYFVHUJ = new ShortCircuitShm.Slot(calculateSlotAddress(ILSFNWZLGV), FDJOHIMQPB);
        WZEWYFVHUJ.clear();
        WZEWYFVHUJ.makeValid();
        FFANJXYBCX[ILSFNWZLGV] = WZEWYFVHUJ;
        if (ShortCircuitShm.URBJLGDAAH.isTraceEnabled()) {
            ShortCircuitShm.URBJLGDAAH.trace(((((this + ": allocAndRegisterSlot ") + ILSFNWZLGV) + ": allocatedSlots=") + RJDDFZAGJS) + StringUtils.getStackTrace(Thread.currentThread()));
        }
        return WZEWYFVHUJ;
    }

    public final synchronized ShortCircuitShm.Slot getSlot(int MCNCNXPLQY) throws InvalidRequestException {
        if (!RJDDFZAGJS.get(MCNCNXPLQY)) {
            throw new InvalidRequestException(((this + ": slot ") + MCNCNXPLQY) + " does not exist.");
        }
        return FFANJXYBCX[MCNCNXPLQY];
    }

    /**
     * Register a slot.
     *
     * This function looks at a slot which has already been initialized (by
     * another process), and registers it with us.  Then, it returns the
     * relevant Slot object.
     *
     * @return The slot.
     * @throws InvalidRequestException
     * 		If the slot index we're trying to allocate has not been
     * 		initialized, or is already in use.
     */
    public final synchronized ShortCircuitShm.Slot registerSlot(int LPKCNSOONV, ExtendedBlockId PUUPTDVVXY) throws InvalidRequestException {
        if (LPKCNSOONV < 0) {
            throw new InvalidRequestException(((this + ": invalid negative slot ") + "index ") + LPKCNSOONV);
        }
        if (LPKCNSOONV >= FFANJXYBCX.length) {
            throw new InvalidRequestException(((this + ": invalid slot ") + "index ") + LPKCNSOONV);
        }
        if (RJDDFZAGJS.get(LPKCNSOONV)) {
            throw new InvalidRequestException(((this + ": slot ") + LPKCNSOONV) + " is already in use.");
        }
        ShortCircuitShm.Slot AMAIVKMFWV = new ShortCircuitShm.Slot(calculateSlotAddress(LPKCNSOONV), PUUPTDVVXY);
        if (!AMAIVKMFWV.isValid()) {
            throw new InvalidRequestException(((this + ": slot ") + LPKCNSOONV) + " is not marked as valid.");
        }
        FFANJXYBCX[LPKCNSOONV] = AMAIVKMFWV;
        RJDDFZAGJS.set(LPKCNSOONV, true);
        if (ShortCircuitShm.URBJLGDAAH.isTraceEnabled()) {
            ShortCircuitShm.URBJLGDAAH.trace(((((this + ": registerSlot ") + LPKCNSOONV) + ": allocatedSlots=") + RJDDFZAGJS) + StringUtils.getStackTrace(Thread.currentThread()));
        }
        return AMAIVKMFWV;
    }

    /**
     * Unregisters a slot.
     *
     * This doesn't alter the contents of the slot.  It just means
     *
     * @param slotIdx
     * 		Index of the slot to unregister.
     */
    public final synchronized void unregisterSlot(int URYELOCTUS) {
        Preconditions.checkState(RJDDFZAGJS.get(URYELOCTUS), ("tried to unregister slot " + URYELOCTUS) + ", which was not registered.");
        RJDDFZAGJS.set(URYELOCTUS, false);
        FFANJXYBCX[URYELOCTUS] = null;
        if (ShortCircuitShm.URBJLGDAAH.isTraceEnabled()) {
            ShortCircuitShm.URBJLGDAAH.trace((this + ": unregisterSlot ") + URYELOCTUS);
        }
    }

    /**
     * Iterate over all allocated slots.
     *
     * Note that this method isn't safe if
     *
     * @return The slot iterator.
     */
    public ShortCircuitShm.SlotIterator slotIterator() {
        return new ShortCircuitShm.SlotIterator();
    }

    public void free() {
        try {
            POSIX.munmap(AWMSRBPRSY, KBVLANXZQR);
        } catch (IOException e) {
            ShortCircuitShm.URBJLGDAAH.warn(this + ": failed to munmap", e);
        }
        ShortCircuitShm.URBJLGDAAH.trace(this + ": freed");
    }

    @Override
    public String toString() {
        return ((this.getClass().getSimpleName() + "(") + AHGTXQBCBS) + ")";
    }
}