public class TestJavaSerialization extends TestCase {
    private static String FLGNJNGVAS = new File(System.getProperty("test.build.data", "/tmp")).toURI().toString().replace(' ', '+');

    private final Path QLCJEEZJRT = new Path(TestJavaSerialization.FLGNJNGVAS + "/input");

    private final Path JAZEALSPJF = new Path(TestJavaSerialization.FLGNJNGVAS + "/out");

    private final Path GMMKKTQEUW = new Path(QLCJEEZJRT, "inp");

    static class WordCountMapper extends MapReduceBase implements Mapper<LongWritable, Text, String, Long> {
        public void map(LongWritable key, Text value, OutputCollector<String, Long> output, Reporter reporter) throws IOException {
            StringTokenizer st = new StringTokenizer(value.toString());
            while (st.hasMoreTokens()) {
                output.collect(st.nextToken(), 1L);
            } 
        }
    }

    static class SumReducer<K> extends MapReduceBase implements Reducer<K, Long, K, Long> {
        public void reduce(K key, Iterator<Long> values, OutputCollector<K, Long> output, Reporter reporter) throws IOException {
            long sum = 0;
            while (values.hasNext()) {
                sum += values.next();
            } 
            output.collect(key, sum);
        }
    }

    private void cleanAndCreateInput(FileSystem EIICNANRLT) throws IOException {
        EIICNANRLT.delete(GMMKKTQEUW, true);
        EIICNANRLT.delete(JAZEALSPJF, true);
        OutputStream RTUIIQDQRS = EIICNANRLT.create(GMMKKTQEUW);
        Writer VPRKVOCLIQ = new OutputStreamWriter(RTUIIQDQRS);
        VPRKVOCLIQ.write("b a\n");
        VPRKVOCLIQ.close();
    }

    public void testMapReduceJob() throws Exception {
        JobConf ARJUXQUWNH = new JobConf(TestJavaSerialization.class);
        ARJUXQUWNH.setJobName("JavaSerialization");
        FileSystem KBDHIZVWIG = FileSystem.get(ARJUXQUWNH);
        cleanAndCreateInput(KBDHIZVWIG);
        ARJUXQUWNH.set("io.serializations", "org.apache.hadoop.io.serializer.JavaSerialization," + "org.apache.hadoop.io.serializer.WritableSerialization");
        ARJUXQUWNH.setInputFormat(TextInputFormat.class);
        ARJUXQUWNH.setOutputKeyClass(String.class);
        ARJUXQUWNH.setOutputValueClass(Long.class);
        ARJUXQUWNH.setOutputKeyComparatorClass(JavaSerializationComparator.class);
        ARJUXQUWNH.setMapperClass(TestJavaSerialization.WordCountMapper.class);
        ARJUXQUWNH.setReducerClass(TestJavaSerialization.SumReducer.class);
        ARJUXQUWNH.set(FRAMEWORK_NAME, LOCAL_FRAMEWORK_NAME);
        FileInputFormat.setInputPaths(ARJUXQUWNH, QLCJEEZJRT);
        FileOutputFormat.setOutputPath(ARJUXQUWNH, JAZEALSPJF);
        JobClient.runJob(ARJUXQUWNH);
        Path[] HEWDKTFKKS = FileUtil.stat2Paths(KBDHIZVWIG.listStatus(JAZEALSPJF, new Utils.OutputFileUtils.OutputFilesFilter()));
        assertEquals(1, HEWDKTFKKS.length);
        InputStream PAZVZPMXVM = KBDHIZVWIG.open(HEWDKTFKKS[0]);
        BufferedReader NNCHZYZNUV = new BufferedReader(new InputStreamReader(PAZVZPMXVM));
        assertEquals("a\t1", NNCHZYZNUV.readLine());
        assertEquals("b\t1", NNCHZYZNUV.readLine());
        assertNull(NNCHZYZNUV.readLine());
        NNCHZYZNUV.close();
    }

    /**
     * HADOOP-4466:
     * This test verifies the JavSerialization impl can write to
     * SequenceFiles. by virtue other SequenceFileOutputFormat is not
     * coupled to Writable types, if so, the job will fail.
     */
    public void testWriteToSequencefile() throws Exception {
        JobConf PQEFKRJNRD = new JobConf(TestJavaSerialization.class);
        PQEFKRJNRD.setJobName("JavaSerialization");
        FileSystem FEKTDMGGLA = FileSystem.get(PQEFKRJNRD);
        cleanAndCreateInput(FEKTDMGGLA);
        PQEFKRJNRD.set("io.serializations", "org.apache.hadoop.io.serializer.JavaSerialization," + "org.apache.hadoop.io.serializer.WritableSerialization");
        PQEFKRJNRD.setInputFormat(TextInputFormat.class);
        // test we can write to sequence files
        PQEFKRJNRD.setOutputFormat(SequenceFileOutputFormat.class);
        PQEFKRJNRD.setOutputKeyClass(String.class);
        PQEFKRJNRD.setOutputValueClass(Long.class);
        PQEFKRJNRD.setOutputKeyComparatorClass(JavaSerializationComparator.class);
        PQEFKRJNRD.setMapperClass(TestJavaSerialization.WordCountMapper.class);
        PQEFKRJNRD.setReducerClass(TestJavaSerialization.SumReducer.class);
        PQEFKRJNRD.set(FRAMEWORK_NAME, LOCAL_FRAMEWORK_NAME);
        FileInputFormat.setInputPaths(PQEFKRJNRD, QLCJEEZJRT);
        FileOutputFormat.setOutputPath(PQEFKRJNRD, JAZEALSPJF);
        JobClient.runJob(PQEFKRJNRD);
        Path[] ZVSJZUVPLQ = FileUtil.stat2Paths(FEKTDMGGLA.listStatus(JAZEALSPJF, new Utils.OutputFileUtils.OutputFilesFilter()));
        assertEquals(1, ZVSJZUVPLQ.length);
    }
}