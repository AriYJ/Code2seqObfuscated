@Private
public class AdminACLsManager {
    /**
     * Log object for this class
     */
    static Log SAPELGTJTY = LogFactory.getLog(AdminACLsManager.class);

    /**
     * The current user at the time of object creation
     */
    private final UserGroupInformation HEIHIXEQZV;

    /**
     * Holds list of administrator users
     */
    private final AccessControlList KTJAWBVIJR;

    /**
     * True if ACLs are enabled
     *
     * @see YarnConfiguration#YARN_ACL_ENABLE
     * @see YarnConfiguration#DEFAULT_YARN_ACL_ENABLE
     */
    private final boolean MOUPIXJIXC;

    /**
     * Constructs and initializes this AdminACLsManager
     *
     * @param conf
     * 		configuration for this object to use
     */
    public AdminACLsManager(Configuration VRGJMJFQUU) {
        this.KTJAWBVIJR = new AccessControlList(VRGJMJFQUU.get(YARN_ADMIN_ACL, DEFAULT_YARN_ADMIN_ACL));
        try {
            HEIHIXEQZV = UserGroupInformation.getCurrentUser();
            KTJAWBVIJR.addUser(HEIHIXEQZV.getShortUserName());
        } catch (IOException e) {
            AdminACLsManager.SAPELGTJTY.warn("Could not add current user to admin:" + e);
            throw new YarnRuntimeException(e);
        }
        MOUPIXJIXC = VRGJMJFQUU.getBoolean(YARN_ACL_ENABLE, DEFAULT_YARN_ACL_ENABLE);
    }

    /**
     * Returns the owner
     *
     * @return Current user at the time of object creation
     */
    public UserGroupInformation getOwner() {
        return HEIHIXEQZV;
    }

    /**
     * Returns whether ACLs are enabled
     *
     * @see YarnConfiguration#YARN_ACL_ENABLE
     * @see YarnConfiguration#DEFAULT_YARN_ACL_ENABLE
     * @return <tt>true</tt> if ACLs are enabled
     */
    public boolean areACLsEnabled() {
        return MOUPIXJIXC;
    }

    /**
     * Returns the internal structure used to maintain administrator ACLs
     *
     * @return Structure used to maintain administrator access
     */
    public AccessControlList getAdminAcl() {
        return KTJAWBVIJR;
    }

    /**
     * Returns whether the specified user/group is an administrator
     *
     * @param callerUGI
     * 		user/group to to check
     * @return <tt>true</tt> if the UserGroupInformation specified
    is a member of the access control list for administrators
     */
    public boolean isAdmin(UserGroupInformation YDGRNXDJDA) {
        return KTJAWBVIJR.isUserAllowed(YDGRNXDJDA);
    }

    /**
     * Returns whether the specified user/group has administrator access
     *
     * @param callerUGI
     * 		user/group to to check
     * @return <tt>true</tt> if the UserGroupInformation specified
    is a member of the access control list for administrators
    and ACLs are enabled for this cluster
     * @see #getAdminAcl
     * @see #areACLsEnabled
     */
    public boolean checkAccess(UserGroupInformation XUYSBELITK) {
        // Any user may perform this operation if authorization is not enabled
        if (!areACLsEnabled()) {
            return true;
        }
        // Administrators may perform any operation
        return isAdmin(XUYSBELITK);
    }
}