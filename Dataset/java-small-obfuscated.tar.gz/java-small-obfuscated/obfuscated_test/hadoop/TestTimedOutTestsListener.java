public class TestTimedOutTestsListener {
    public static class Deadlock {
        private CyclicBarrier MESSMRIRUZ = new CyclicBarrier(6);

        public Deadlock() {
            TestTimedOutTestsListener.Deadlock.DeadlockThread[] dThreads = new TestTimedOutTestsListener.Deadlock.DeadlockThread[6];
            TestTimedOutTestsListener.Deadlock.Monitor a = new TestTimedOutTestsListener.Deadlock.Monitor("a");
            TestTimedOutTestsListener.Deadlock.Monitor b = new TestTimedOutTestsListener.Deadlock.Monitor("b");
            TestTimedOutTestsListener.Deadlock.Monitor c = new TestTimedOutTestsListener.Deadlock.Monitor("c");
            dThreads[0] = new TestTimedOutTestsListener.Deadlock.DeadlockThread("MThread-1", a, b);
            dThreads[1] = new TestTimedOutTestsListener.Deadlock.DeadlockThread("MThread-2", b, c);
            dThreads[2] = new TestTimedOutTestsListener.Deadlock.DeadlockThread("MThread-3", c, a);
            Lock d = new ReentrantLock();
            Lock e = new ReentrantLock();
            Lock f = new ReentrantLock();
            dThreads[3] = new TestTimedOutTestsListener.Deadlock.DeadlockThread("SThread-4", d, e);
            dThreads[4] = new TestTimedOutTestsListener.Deadlock.DeadlockThread("SThread-5", e, f);
            dThreads[5] = new TestTimedOutTestsListener.Deadlock.DeadlockThread("SThread-6", f, d);
            // make them daemon threads so that the test will exit
            for (int i = 0; i < 6; i++) {
                dThreads[i].setDaemon(true);
                dThreads[i].start();
            }
        }

        class DeadlockThread extends Thread {
            private Lock RTICKUWRYA = null;

            private Lock IJAURPDPGB = null;

            private TestTimedOutTestsListener.Deadlock.Monitor RVPUQPPJQB = null;

            private TestTimedOutTestsListener.Deadlock.Monitor KQIMXJLQKN = null;

            private boolean UEOMIJZPBJ;

            DeadlockThread(String name, Lock lock1, Lock lock2) {
                super(name);
                this.RTICKUWRYA = lock1;
                this.IJAURPDPGB = lock2;
                this.UEOMIJZPBJ = true;
            }

            DeadlockThread(String name, TestTimedOutTestsListener.Deadlock.Monitor mon1, TestTimedOutTestsListener.Deadlock.Monitor mon2) {
                super(name);
                this.RVPUQPPJQB = mon1;
                this.KQIMXJLQKN = mon2;
                this.UEOMIJZPBJ = false;
            }

            public void run() {
                if (UEOMIJZPBJ) {
                    syncLock();
                } else {
                    monitorLock();
                }
            }

            private void syncLock() {
                RTICKUWRYA.lock();
                try {
                    try {
                        MESSMRIRUZ.await();
                    } catch (Exception e) {
                    }
                    goSyncDeadlock();
                } finally {
                    RTICKUWRYA.unlock();
                }
            }

            private void goSyncDeadlock() {
                try {
                    MESSMRIRUZ.await();
                } catch (Exception e) {
                }
                IJAURPDPGB.lock();
                throw new RuntimeException("should not reach here.");
            }

            private void monitorLock() {
                synchronized(RVPUQPPJQB) {
                    try {
                        MESSMRIRUZ.await();
                    } catch (Exception e) {
                    }
                    goMonitorDeadlock();
                }
            }

            private void goMonitorDeadlock() {
                try {
                    MESSMRIRUZ.await();
                } catch (Exception e) {
                }
                synchronized(KQIMXJLQKN) {
                    throw new RuntimeException(getName() + " should not reach here.");
                }
            }
        }

        class Monitor {
            String IGBZCKAZSN;

            Monitor(String name) {
                this.IGBZCKAZSN = name;
            }
        }
    }

    @Test(timeout = 500)
    public void testThreadDumpAndDeadlocks() throws Exception {
        new TestTimedOutTestsListener.Deadlock();
        String KHGSFLFYNL = null;
        while (true) {
            KHGSFLFYNL = TimedOutTestsListener.buildDeadlockInfo();
            if (KHGSFLFYNL != null)
                break;

            Thread.sleep(100);
        } 
        Assert.assertEquals(3, countStringOccurrences(KHGSFLFYNL, "BLOCKED"));
        Failure LFRXDPIQES = new Failure(null, new Exception(TimedOutTestsListener.TEST_TIMED_OUT_PREFIX));
        StringWriter KAQMNDVULS = new StringWriter();
        new TimedOutTestsListener(new PrintWriter(KAQMNDVULS)).testFailure(LFRXDPIQES);
        String HODFYJPQWV = KAQMNDVULS.toString();
        Assert.assertTrue(HODFYJPQWV.contains("THREAD DUMP"));
        Assert.assertTrue(HODFYJPQWV.contains("DEADLOCKS DETECTED"));
        System.out.println(HODFYJPQWV);
    }

    private int countStringOccurrences(String LOZQVBKSXA, String EHZDFZLZXA) {
        int LOHTDTTTYZ = 0;
        int SMHTLGRRFM = 0;
        while ((SMHTLGRRFM = LOZQVBKSXA.indexOf(EHZDFZLZXA, SMHTLGRRFM) + 1) != 0) {
            LOHTDTTTYZ++;
        } 
        return LOHTDTTTYZ;
    }
}