public class TestClientRMService {
    private static final Log FWAHKPOOAC = LogFactory.getLog(TestClientRMService.class);

    private RecordFactory BLAENYXREV = RecordFactoryProvider.getRecordFactory(null);

    private String HPBIGTPBNH = "MockApp";

    private static RMDelegationTokenSecretManager CLKCWQUBOO;

    private static final String OYPOZCLQYD = "Q-1";

    private static final String TCZRAYQYJY = "Q-2";

    private static final String HFVWEMGPUS = "RULE:[1:$1@$0](.*@EXAMPLE.COM)s/@.*//\nDEFAULT";

    static {
        KerberosName.setRules(TestClientRMService.HFVWEMGPUS);
    }

    @BeforeClass
    public static void setupSecretManager() throws IOException {
        RMContext MZWYHNEOPZ = mock(RMContext.class);
        when(MZWYHNEOPZ.getStateStore()).thenReturn(new NullRMStateStore());
        TestClientRMService.CLKCWQUBOO = new RMDelegationTokenSecretManager(60000, 60000, 60000, 60000, MZWYHNEOPZ);
        TestClientRMService.CLKCWQUBOO.startThreads();
    }

    @AfterClass
    public static void teardownSecretManager() {
        if (TestClientRMService.CLKCWQUBOO != null) {
            TestClientRMService.CLKCWQUBOO.stopThreads();
        }
    }

    @Test
    public void testGetClusterNodes() throws Exception {
        MockRM BKZMAXXIQQ = new MockRM() {
            protected ClientRMService createClientRMService() {
                return new ClientRMService(this.rmContext, scheduler, this.rmAppManager, this.applicationACLsManager, this.queueACLsManager, this.getRMContext().getRMDelegationTokenSecretManager());
            }
        };
        BKZMAXXIQQ.start();
        // Add a healthy node
        MockNM TNEKLVPEXG = BKZMAXXIQQ.registerNode("host1:1234", 1024);
        BKZMAXXIQQ.sendNodeStarted(TNEKLVPEXG);
        TNEKLVPEXG.nodeHeartbeat(true);
        // Add and lose a node
        MockNM CQZNHMRQQQ = BKZMAXXIQQ.registerNode("host2:1235", 1024);
        BKZMAXXIQQ.sendNodeStarted(CQZNHMRQQQ);
        CQZNHMRQQQ.nodeHeartbeat(true);
        BKZMAXXIQQ.NMwaitForState(CQZNHMRQQQ.getNodeId(), RUNNING);
        BKZMAXXIQQ.sendNodeLost(CQZNHMRQQQ);
        // Create a client.
        Configuration HYAXFEHMSE = new Configuration();
        YarnRPC BZWHVXEOOC = YarnRPC.create(HYAXFEHMSE);
        InetSocketAddress OBJZSVTUIE = BKZMAXXIQQ.getClientRMService().getBindAddress();
        TestClientRMService.FWAHKPOOAC.info("Connecting to ResourceManager at " + OBJZSVTUIE);
        ApplicationClientProtocol OKHEVVXKNM = ((ApplicationClientProtocol) (BZWHVXEOOC.getProxy(ApplicationClientProtocol.class, OBJZSVTUIE, HYAXFEHMSE)));
        // Make call
        GetClusterNodesRequest XNVZSDIOKX = GetClusterNodesRequest.newInstance(EnumSet.of(RUNNING));
        List<NodeReport> GHFLKKAWOQ = OKHEVVXKNM.getClusterNodes(XNVZSDIOKX).getNodeReports();
        Assert.assertEquals(1, GHFLKKAWOQ.size());
        Assert.assertNotSame("Node is expected to be healthy!", UNHEALTHY, GHFLKKAWOQ.get(0).getNodeState());
        // Now make the node unhealthy.
        TNEKLVPEXG.nodeHeartbeat(false);
        // Call again
        GHFLKKAWOQ = OKHEVVXKNM.getClusterNodes(XNVZSDIOKX).getNodeReports();
        Assert.assertEquals("Unhealthy nodes should not show up by default", 0, GHFLKKAWOQ.size());
        // Now query for UNHEALTHY nodes
        XNVZSDIOKX = GetClusterNodesRequest.newInstance(EnumSet.of(UNHEALTHY));
        GHFLKKAWOQ = OKHEVVXKNM.getClusterNodes(XNVZSDIOKX).getNodeReports();
        Assert.assertEquals(1, GHFLKKAWOQ.size());
        Assert.assertEquals("Node is expected to be unhealthy!", UNHEALTHY, GHFLKKAWOQ.get(0).getNodeState());
        // Query all states should return all nodes
        BKZMAXXIQQ.registerNode("host3:1236", 1024);
        XNVZSDIOKX = GetClusterNodesRequest.newInstance(EnumSet.allOf(NodeState.class));
        GHFLKKAWOQ = OKHEVVXKNM.getClusterNodes(XNVZSDIOKX).getNodeReports();
        Assert.assertEquals(3, GHFLKKAWOQ.size());
    }

    @Test
    public void testGetApplicationReport() throws YarnException {
        RMContext COUDJSXCFC = mock(RMContext.class);
        when(COUDJSXCFC.getRMApps()).thenReturn(new ConcurrentHashMap<ApplicationId, RMApp>());
        ClientRMService OGXXQAWHGA = new ClientRMService(COUDJSXCFC, null, null, null, null, null);
        RecordFactory JGMGSXEIVH = RecordFactoryProvider.getRecordFactory(null);
        GetApplicationReportRequest OUCMIPKTDU = JGMGSXEIVH.newRecordInstance(GetApplicationReportRequest.class);
        OUCMIPKTDU.setApplicationId(ApplicationId.newInstance(0, 0));
        try {
            OGXXQAWHGA.getApplicationReport(OUCMIPKTDU);
            Assert.fail();
        } catch (ApplicationNotFoundException ex) {
            Assert.assertEquals(ex.getMessage(), ("Application with id '" + OUCMIPKTDU.getApplicationId()) + "' doesn't exist in RM.");
        }
    }

    @Test
    public void testGetApplicationAttemptReport() throws IOException, YarnException {
        ClientRMService NSKCANUTQT = createRMService();
        RecordFactory KJVDZBPECL = RecordFactoryProvider.getRecordFactory(null);
        GetApplicationAttemptReportRequest SHFBDJSVKT = KJVDZBPECL.newRecordInstance(GetApplicationAttemptReportRequest.class);
        ApplicationAttemptId NDMBNSLCXJ = ApplicationAttemptId.newInstance(ApplicationId.newInstance(123456, 1), 1);
        SHFBDJSVKT.setApplicationAttemptId(NDMBNSLCXJ);
        try {
            GetApplicationAttemptReportResponse BDSOFPBGNG = NSKCANUTQT.getApplicationAttemptReport(SHFBDJSVKT);
            Assert.assertEquals(NDMBNSLCXJ, BDSOFPBGNG.getApplicationAttemptReport().getApplicationAttemptId());
        } catch (ApplicationNotFoundException ex) {
            Assert.fail(ex.getMessage());
        }
    }

    @Test
    public void testGetApplicationResourceUsageReportDummy() throws IOException, YarnException {
        ApplicationAttemptId WMGEZYVTFE = TestClientRMService.getApplicationAttemptId(1);
        YarnScheduler OXSVEXWRZC = TestClientRMService.mockYarnScheduler();
        RMContext UDZIOYHTSD = mock(RMContext.class);
        mockRMContext(OXSVEXWRZC, UDZIOYHTSD);
        when(UDZIOYHTSD.getDispatcher().getEventHandler()).thenReturn(new org.apache.hadoop.yarn.event.EventHandler<Event>() {
            public void handle(Event OYZVULAFTH) {
            }
        });
        ApplicationSubmissionContext AZFAHMEMAZ = mock(ApplicationSubmissionContext.class);
        YarnConfiguration MGGJEHPKPG = new YarnConfiguration();
        RMAppAttemptImpl TLGTTSQTAU = new RMAppAttemptImpl(WMGEZYVTFE, UDZIOYHTSD, OXSVEXWRZC, null, AZFAHMEMAZ, MGGJEHPKPG, false);
        ApplicationResourceUsageReport FDYWYJGMSP = TLGTTSQTAU.getApplicationResourceUsageReport();
        assertEquals(FDYWYJGMSP, RMServerUtils.DUMMY_APPLICATION_RESOURCE_USAGE_REPORT);
    }

    @Test
    public void testGetApplicationAttempts() throws IOException, YarnException {
        ClientRMService LTFEBPAQFN = createRMService();
        RecordFactory ZOZDFCPCWE = RecordFactoryProvider.getRecordFactory(null);
        GetApplicationAttemptsRequest SRINYSRNIN = ZOZDFCPCWE.newRecordInstance(GetApplicationAttemptsRequest.class);
        ApplicationAttemptId CLZVTMAFFM = ApplicationAttemptId.newInstance(ApplicationId.newInstance(123456, 1), 1);
        SRINYSRNIN.setApplicationId(ApplicationId.newInstance(123456, 1));
        try {
            GetApplicationAttemptsResponse GOVTBNGSHY = LTFEBPAQFN.getApplicationAttempts(SRINYSRNIN);
            Assert.assertEquals(1, GOVTBNGSHY.getApplicationAttemptList().size());
            Assert.assertEquals(CLZVTMAFFM, GOVTBNGSHY.getApplicationAttemptList().get(0).getApplicationAttemptId());
        } catch (ApplicationNotFoundException ex) {
            Assert.fail(ex.getMessage());
        }
    }

    @Test
    public void testGetContainerReport() throws IOException, YarnException {
        ClientRMService OMTELDWOQF = createRMService();
        RecordFactory KPHSXNGSTQ = RecordFactoryProvider.getRecordFactory(null);
        GetContainerReportRequest WDQGYLTXWG = KPHSXNGSTQ.newRecordInstance(GetContainerReportRequest.class);
        ApplicationAttemptId HILVAMPHKF = ApplicationAttemptId.newInstance(ApplicationId.newInstance(123456, 1), 1);
        ContainerId IEDUHXVTZI = ContainerId.newInstance(HILVAMPHKF, 1);
        WDQGYLTXWG.setContainerId(IEDUHXVTZI);
        try {
            GetContainerReportResponse VTXYDNOMHM = OMTELDWOQF.getContainerReport(WDQGYLTXWG);
            Assert.assertEquals(IEDUHXVTZI, VTXYDNOMHM.getContainerReport().getContainerId());
        } catch (ApplicationNotFoundException ex) {
            Assert.fail(ex.getMessage());
        }
    }

    @Test
    public void testGetContainers() throws IOException, YarnException {
        ClientRMService WCWKPXDIUB = createRMService();
        RecordFactory ADLVRTCGPN = RecordFactoryProvider.getRecordFactory(null);
        GetContainersRequest EJLEEWTZOL = ADLVRTCGPN.newRecordInstance(GetContainersRequest.class);
        ApplicationAttemptId HMAPCMHVPL = ApplicationAttemptId.newInstance(ApplicationId.newInstance(123456, 1), 1);
        ContainerId SVLWLMYVLY = ContainerId.newInstance(HMAPCMHVPL, 1);
        EJLEEWTZOL.setApplicationAttemptId(HMAPCMHVPL);
        try {
            GetContainersResponse QDWUJOLPIM = WCWKPXDIUB.getContainers(EJLEEWTZOL);
            Assert.assertEquals(SVLWLMYVLY, QDWUJOLPIM.getContainerList().get(0).getContainerId());
        } catch (ApplicationNotFoundException ex) {
            Assert.fail(ex.getMessage());
        }
    }

    public ClientRMService createRMService() throws IOException {
        YarnScheduler TICTKHZKKR = TestClientRMService.mockYarnScheduler();
        RMContext EQUZBQDYPA = mock(RMContext.class);
        mockRMContext(TICTKHZKKR, EQUZBQDYPA);
        ConcurrentHashMap<ApplicationId, RMApp> IMKIJXDIRF = getRMApps(EQUZBQDYPA, TICTKHZKKR);
        when(EQUZBQDYPA.getRMApps()).thenReturn(IMKIJXDIRF);
        RMAppManager XYMWTNXGEK = new RMAppManager(EQUZBQDYPA, TICTKHZKKR, null, mock(ApplicationACLsManager.class), new Configuration());
        when(EQUZBQDYPA.getDispatcher().getEventHandler()).thenReturn(new org.apache.hadoop.yarn.event.EventHandler<Event>() {
            public void handle(Event QMXDCFMOJM) {
            }
        });
        ApplicationACLsManager XKIPBGWXQF = mock(ApplicationACLsManager.class);
        QueueACLsManager LTAFPIEJLQ = mock(QueueACLsManager.class);
        when(LTAFPIEJLQ.checkAccess(any(UserGroupInformation.class), any(org.apache.hadoop.yarn.api.records.QueueACL.class), anyString())).thenReturn(true);
        return new ClientRMService(EQUZBQDYPA, TICTKHZKKR, XYMWTNXGEK, XKIPBGWXQF, LTAFPIEJLQ, null);
    }

    @Test
    public void testForceKillNonExistingApplication() throws YarnException {
        RMContext LVYTABLRGD = mock(RMContext.class);
        when(LVYTABLRGD.getRMApps()).thenReturn(new ConcurrentHashMap<ApplicationId, RMApp>());
        ClientRMService PWYRMXTNYA = new ClientRMService(LVYTABLRGD, null, null, null, null, null);
        ApplicationId EHTWGYOOSQ = BuilderUtils.newApplicationId(System.currentTimeMillis(), 0);
        KillApplicationRequest SWQOFGWFCW = KillApplicationRequest.newInstance(EHTWGYOOSQ);
        try {
            PWYRMXTNYA.forceKillApplication(SWQOFGWFCW);
            Assert.fail();
        } catch (ApplicationNotFoundException ex) {
            Assert.assertEquals(ex.getMessage(), ("Trying to kill an absent " + "application ") + SWQOFGWFCW.getApplicationId());
        }
    }

    @Test
    public void testForceKillApplication() throws Exception {
        YarnConfiguration NJHJVFMIQR = new YarnConfiguration();
        MockRM EXZDYTKNTG = new MockRM();
        EXZDYTKNTG.init(NJHJVFMIQR);
        EXZDYTKNTG.start();
        ClientRMService SGVAWMOZTJ = EXZDYTKNTG.getClientRMService();
        GetApplicationsRequest XDXYTKLPTS = GetApplicationsRequest.newInstance(EnumSet.of(KILLED));
        RMApp WKZDIWIBXC = EXZDYTKNTG.submitApp(1024);
        RMApp WKFNJMVEJL = EXZDYTKNTG.submitApp(1024, true);
        assertEquals("Incorrect number of apps in the RM", 0, SGVAWMOZTJ.getApplications(XDXYTKLPTS).getApplicationList().size());
        KillApplicationRequest IHROFSAROE = KillApplicationRequest.newInstance(WKZDIWIBXC.getApplicationId());
        KillApplicationRequest OXLCIETNQW = KillApplicationRequest.newInstance(WKFNJMVEJL.getApplicationId());
        int IGGEPURAPI = 0;
        for (int GTJDWHYQLI = 0; GTJDWHYQLI < 100; GTJDWHYQLI++) {
            KillApplicationResponse ZAVGSDYNXP = SGVAWMOZTJ.forceKillApplication(IHROFSAROE);
            IGGEPURAPI++;
            if (ZAVGSDYNXP.getIsKillCompleted()) {
                break;
            }
            Thread.sleep(10);
        }
        assertTrue("Kill attempt count should be greater than 1 for managed AMs", IGGEPURAPI > 1);
        assertEquals("Incorrect number of apps in the RM", 1, SGVAWMOZTJ.getApplications(XDXYTKLPTS).getApplicationList().size());
        KillApplicationResponse YCMLHZJLFX = SGVAWMOZTJ.forceKillApplication(OXLCIETNQW);
        assertTrue("Killing UnmanagedAM should falsely acknowledge true", YCMLHZJLFX.getIsKillCompleted());
        for (int THEHYAGHFO = 0; THEHYAGHFO < 100; THEHYAGHFO++) {
            if (2 == SGVAWMOZTJ.getApplications(XDXYTKLPTS).getApplicationList().size()) {
                break;
            }
            Thread.sleep(10);
        }
        assertEquals("Incorrect number of apps in the RM", 2, SGVAWMOZTJ.getApplications(XDXYTKLPTS).getApplicationList().size());
    }

    @Test(expected = ApplicationNotFoundException.class)
    public void testMoveAbsentApplication() throws YarnException {
        RMContext RJWQNWQARF = mock(RMContext.class);
        when(RJWQNWQARF.getRMApps()).thenReturn(new ConcurrentHashMap<ApplicationId, RMApp>());
        ClientRMService CHIHSHDEPI = new ClientRMService(RJWQNWQARF, null, null, null, null, null);
        ApplicationId KJCWQPLOYY = BuilderUtils.newApplicationId(System.currentTimeMillis(), 0);
        MoveApplicationAcrossQueuesRequest MOABEFKAEJ = MoveApplicationAcrossQueuesRequest.newInstance(KJCWQPLOYY, "newqueue");
        CHIHSHDEPI.moveApplicationAcrossQueues(MOABEFKAEJ);
    }

    @Test
    public void testGetQueueInfo() throws Exception {
        YarnScheduler ABEBETEWUK = mock(YarnScheduler.class);
        RMContext FJCRLMLGSD = mock(RMContext.class);
        mockRMContext(ABEBETEWUK, FJCRLMLGSD);
        ClientRMService IQFLSYHWYX = new ClientRMService(FJCRLMLGSD, ABEBETEWUK, null, null, null, null);
        GetQueueInfoRequest KODQYVKOUY = BLAENYXREV.newRecordInstance(GetQueueInfoRequest.class);
        KODQYVKOUY.setQueueName("testqueue");
        KODQYVKOUY.setIncludeApplications(true);
        GetQueueInfoResponse ZJMFSIEUGH = IQFLSYHWYX.getQueueInfo(KODQYVKOUY);
        List<ApplicationReport> JVIFXZJTXL = ZJMFSIEUGH.getQueueInfo().getApplications();
        Assert.assertEquals(2, JVIFXZJTXL.size());
        KODQYVKOUY.setQueueName("nonexistentqueue");
        KODQYVKOUY.setIncludeApplications(true);
        // should not throw exception on nonexistent queue
        ZJMFSIEUGH = IQFLSYHWYX.getQueueInfo(KODQYVKOUY);
    }

    private static final UserGroupInformation GSMMQRMQRO = UserGroupInformation.createRemoteUser("owner");

    private static final UserGroupInformation EVOGEEXILB = UserGroupInformation.createRemoteUser("other");

    private static final UserGroupInformation SUXVNRVOAI = UserGroupInformation.createRemoteUser("tester");

    private static final String ARVGHMNCJV = "tester@EXAMPLE.COM";

    private static final String VBKLVRFZDJ = "owner@EXAMPLE.COM";

    private static final String CNHDWPRUYA = "other@EXAMPLE.COM";

    private static final UserGroupInformation EJNEEDFMWI = UserGroupInformation.createRemoteUser(TestClientRMService.ARVGHMNCJV);

    private static final UserGroupInformation JZAEHXBWIY = UserGroupInformation.createRemoteUser(TestClientRMService.VBKLVRFZDJ);

    private static final UserGroupInformation VXTPBLNZRF = UserGroupInformation.createRemoteUser(TestClientRMService.CNHDWPRUYA);

    @Test
    public void testTokenRenewalByOwner() throws Exception {
        TestClientRMService.GSMMQRMQRO.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                checkTokenRenewal(TestClientRMService.GSMMQRMQRO, TestClientRMService.GSMMQRMQRO);
                return null;
            }
        });
    }

    @Test
    public void testTokenRenewalWrongUser() throws Exception {
        try {
            TestClientRMService.GSMMQRMQRO.doAs(new PrivilegedExceptionAction<Void>() {
                @Override
                public Void run() throws Exception {
                    try {
                        checkTokenRenewal(TestClientRMService.GSMMQRMQRO, TestClientRMService.EVOGEEXILB);
                        return null;
                    } catch (YarnException ex) {
                        Assert.assertTrue(ex.getMessage().contains((TestClientRMService.GSMMQRMQRO.getUserName() + " tries to renew a token with renewer ") + TestClientRMService.EVOGEEXILB.getUserName()));
                        throw ex;
                    }
                }
            });
        } catch (Exception e) {
            return;
        }
        Assert.fail("renew should have failed");
    }

    @Test
    public void testTokenRenewalByLoginUser() throws Exception {
        UserGroupInformation.getLoginUser().doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                checkTokenRenewal(TestClientRMService.GSMMQRMQRO, TestClientRMService.GSMMQRMQRO);
                checkTokenRenewal(TestClientRMService.GSMMQRMQRO, TestClientRMService.EVOGEEXILB);
                return null;
            }
        });
    }

    private void checkTokenRenewal(UserGroupInformation YDSWQGPVUS, UserGroupInformation QCKHDHCEVU) throws IOException, YarnException {
        RMDelegationTokenIdentifier ZCYZPQGDAB = new RMDelegationTokenIdentifier(new org.apache.hadoop.io.Text(YDSWQGPVUS.getUserName()), new org.apache.hadoop.io.Text(QCKHDHCEVU.getUserName()), null);
        Token<?> GFHBKVGTIG = new Token<RMDelegationTokenIdentifier>(ZCYZPQGDAB, TestClientRMService.CLKCWQUBOO);
        org.apache.hadoop.yarn.api.records.Token PQKYBNLOSC = BuilderUtils.newDelegationToken(GFHBKVGTIG.getIdentifier(), GFHBKVGTIG.getKind().toString(), GFHBKVGTIG.getPassword(), GFHBKVGTIG.getService().toString());
        RenewDelegationTokenRequest XEHQNBOBVS = Records.newRecord(RenewDelegationTokenRequest.class);
        XEHQNBOBVS.setDelegationToken(PQKYBNLOSC);
        RMContext RHGTGFFJGZ = mock(RMContext.class);
        ClientRMService PYLCHZPOFI = new ClientRMService(RHGTGFFJGZ, null, null, null, null, TestClientRMService.CLKCWQUBOO);
        PYLCHZPOFI.renewDelegationToken(XEHQNBOBVS);
    }

    @Test
    public void testTokenCancellationByOwner() throws Exception {
        // two tests required - one with a kerberos name
        // and with a short name
        RMContext YSLQBMTCJP = mock(RMContext.class);
        final ClientRMService GAXQHQZZUZ = new ClientRMService(YSLQBMTCJP, null, null, null, null, TestClientRMService.CLKCWQUBOO);
        TestClientRMService.EJNEEDFMWI.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                checkTokenCancellation(GAXQHQZZUZ, TestClientRMService.EJNEEDFMWI, TestClientRMService.EVOGEEXILB);
                return null;
            }
        });
        TestClientRMService.GSMMQRMQRO.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                checkTokenCancellation(TestClientRMService.GSMMQRMQRO, TestClientRMService.EVOGEEXILB);
                return null;
            }
        });
    }

    @Test
    public void testTokenCancellationByRenewer() throws Exception {
        // two tests required - one with a kerberos name
        // and with a short name
        RMContext SRKXUKTLIH = mock(RMContext.class);
        final ClientRMService JAKQUJJFSV = new ClientRMService(SRKXUKTLIH, null, null, null, null, TestClientRMService.CLKCWQUBOO);
        TestClientRMService.EJNEEDFMWI.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                checkTokenCancellation(JAKQUJJFSV, TestClientRMService.GSMMQRMQRO, TestClientRMService.EJNEEDFMWI);
                return null;
            }
        });
        TestClientRMService.EVOGEEXILB.doAs(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
                checkTokenCancellation(TestClientRMService.GSMMQRMQRO, TestClientRMService.EVOGEEXILB);
                return null;
            }
        });
    }

    @Test
    public void testTokenCancellationByWrongUser() {
        // two sets to test -
        // 1. try to cancel tokens of short and kerberos users as a kerberos UGI
        // 2. try to cancel tokens of short and kerberos users as a simple auth UGI
        RMContext DSGOOMEGHI = mock(RMContext.class);
        final ClientRMService LBHJNQJPMD = new ClientRMService(DSGOOMEGHI, null, null, null, null, TestClientRMService.CLKCWQUBOO);
        UserGroupInformation[] SNCWUDTBFC = new UserGroupInformation[]{ TestClientRMService.GSMMQRMQRO, TestClientRMService.EVOGEEXILB, TestClientRMService.SUXVNRVOAI, TestClientRMService.JZAEHXBWIY, TestClientRMService.VXTPBLNZRF };
        UserGroupInformation[] FRTCPRGDTS = new UserGroupInformation[]{ TestClientRMService.GSMMQRMQRO, TestClientRMService.EVOGEEXILB, TestClientRMService.JZAEHXBWIY, TestClientRMService.VXTPBLNZRF };
        for (final UserGroupInformation XXZXSVWOAZ : SNCWUDTBFC) {
            for (final UserGroupInformation UPKZASGIUK : FRTCPRGDTS) {
                try {
                    TestClientRMService.EJNEEDFMWI.doAs(new PrivilegedExceptionAction<Void>() {
                        @Override
                        public Void run() throws Exception {
                            try {
                                checkTokenCancellation(LBHJNQJPMD, XXZXSVWOAZ, UPKZASGIUK);
                                Assert.fail((("We should not reach here; token owner = " + XXZXSVWOAZ.getUserName()) + ", renewer = ") + UPKZASGIUK.getUserName());
                                return null;
                            } catch (YarnException e) {
                                Assert.assertTrue(e.getMessage().contains(TestClientRMService.EJNEEDFMWI.getUserName() + " is not authorized to cancel the token"));
                                return null;
                            }
                        }
                    });
                } catch (Exception e) {
                    Assert.fail("Unexpected exception; " + e.getMessage());
                }
            }
        }
        UserGroupInformation[] CXNUEBOCYW = new UserGroupInformation[]{ TestClientRMService.GSMMQRMQRO, TestClientRMService.EVOGEEXILB, TestClientRMService.JZAEHXBWIY, TestClientRMService.VXTPBLNZRF, TestClientRMService.EJNEEDFMWI };
        UserGroupInformation[] ZRVHXGZNMJ = new UserGroupInformation[]{ TestClientRMService.GSMMQRMQRO, TestClientRMService.EVOGEEXILB, TestClientRMService.JZAEHXBWIY, TestClientRMService.VXTPBLNZRF };
        for (final UserGroupInformation TUNYJSFNKW : CXNUEBOCYW) {
            for (final UserGroupInformation RIHKKEHVNF : ZRVHXGZNMJ) {
                try {
                    TestClientRMService.SUXVNRVOAI.doAs(new PrivilegedExceptionAction<Void>() {
                        @Override
                        public Void run() throws Exception {
                            try {
                                checkTokenCancellation(TUNYJSFNKW, RIHKKEHVNF);
                                Assert.fail((("We should not reach here; token owner = " + TUNYJSFNKW.getUserName()) + ", renewer = ") + RIHKKEHVNF.getUserName());
                                return null;
                            } catch (YarnException ex) {
                                Assert.assertTrue(ex.getMessage().contains(TestClientRMService.SUXVNRVOAI.getUserName() + " is not authorized to cancel the token"));
                                return null;
                            }
                        }
                    });
                } catch (Exception e) {
                    Assert.fail("Unexpected exception; " + e.getMessage());
                }
            }
        }
    }

    private void checkTokenCancellation(UserGroupInformation ZOOVLCLAWJ, UserGroupInformation AHESHVLGNO) throws IOException, YarnException {
        RMContext KHNHMSSNCG = mock(RMContext.class);
        final ClientRMService QLXPKSAPGS = new ClientRMService(KHNHMSSNCG, null, null, null, null, TestClientRMService.CLKCWQUBOO);
        checkTokenCancellation(QLXPKSAPGS, ZOOVLCLAWJ, AHESHVLGNO);
    }

    private void checkTokenCancellation(ClientRMService FKVDELQEJM, UserGroupInformation OPWNRTCZUA, UserGroupInformation YXSYNXRYMB) throws IOException, YarnException {
        RMDelegationTokenIdentifier ZEVBOCBEEK = new RMDelegationTokenIdentifier(new org.apache.hadoop.io.Text(OPWNRTCZUA.getUserName()), new org.apache.hadoop.io.Text(YXSYNXRYMB.getUserName()), null);
        Token<?> MBQKBOYFEO = new Token<RMDelegationTokenIdentifier>(ZEVBOCBEEK, TestClientRMService.CLKCWQUBOO);
        org.apache.hadoop.yarn.api.records.Token EQXXIICOYD = BuilderUtils.newDelegationToken(MBQKBOYFEO.getIdentifier(), MBQKBOYFEO.getKind().toString(), MBQKBOYFEO.getPassword(), MBQKBOYFEO.getService().toString());
        CancelDelegationTokenRequest YRJVPVRHFO = Records.newRecord(CancelDelegationTokenRequest.class);
        YRJVPVRHFO.setDelegationToken(EQXXIICOYD);
        FKVDELQEJM.cancelDelegationToken(YRJVPVRHFO);
    }

    @Test(timeout = 30000)
    @SuppressWarnings("rawtypes")
    public void testAppSubmit() throws Exception {
        YarnScheduler ZORBRNXXSY = TestClientRMService.mockYarnScheduler();
        RMContext IBGTIBXQJE = mock(RMContext.class);
        mockRMContext(ZORBRNXXSY, IBGTIBXQJE);
        RMStateStore DWDEZEBKRD = mock(RMStateStore.class);
        when(IBGTIBXQJE.getStateStore()).thenReturn(DWDEZEBKRD);
        RMAppManager BZDRRYLIDN = new RMAppManager(IBGTIBXQJE, ZORBRNXXSY, null, mock(ApplicationACLsManager.class), new Configuration());
        when(IBGTIBXQJE.getDispatcher().getEventHandler()).thenReturn(new org.apache.hadoop.yarn.event.EventHandler<Event>() {
            public void handle(Event CIIPLVDOUB) {
            }
        });
        ApplicationId JEHIHWIDTJ = TestClientRMService.getApplicationId(100);
        ApplicationACLsManager PXIMKLSXAT = mock(ApplicationACLsManager.class);
        when(PXIMKLSXAT.checkAccess(UserGroupInformation.getCurrentUser(), ApplicationAccessType.VIEW_APP, null, JEHIHWIDTJ)).thenReturn(true);
        QueueACLsManager THKMITRYVM = mock(QueueACLsManager.class);
        when(THKMITRYVM.checkAccess(any(UserGroupInformation.class), any(org.apache.hadoop.yarn.api.records.QueueACL.class), anyString())).thenReturn(true);
        ClientRMService ZKRRUKYZNZ = new ClientRMService(IBGTIBXQJE, ZORBRNXXSY, BZDRRYLIDN, PXIMKLSXAT, THKMITRYVM, null);
        // without name and queue
        SubmitApplicationRequest ICDQWTADHS = mockSubmitAppRequest(JEHIHWIDTJ, null, null);
        try {
            ZKRRUKYZNZ.submitApplication(ICDQWTADHS);
        } catch (YarnException e) {
            Assert.fail("Exception is not expected.");
        }
        RMApp TLLGRXVCXI = IBGTIBXQJE.getRMApps().get(JEHIHWIDTJ);
        Assert.assertNotNull("app doesn't exist", TLLGRXVCXI);
        Assert.assertEquals("app name doesn't match", DEFAULT_APPLICATION_NAME, TLLGRXVCXI.getName());
        Assert.assertEquals("app queue doesn't match", DEFAULT_QUEUE_NAME, TLLGRXVCXI.getQueue());
        // with name and queue
        String RAHQZAPPFQ = MockApps.newAppName();
        String KTCCOGRNZR = MockApps.newQueue();
        ApplicationId CZZEGHEKWM = TestClientRMService.getApplicationId(101);
        SubmitApplicationRequest CVSCIKHSKP = mockSubmitAppRequest(CZZEGHEKWM, RAHQZAPPFQ, KTCCOGRNZR);
        CVSCIKHSKP.getApplicationSubmissionContext().setApplicationType("matchType");
        try {
            ZKRRUKYZNZ.submitApplication(CVSCIKHSKP);
        } catch (YarnException e) {
            Assert.fail("Exception is not expected.");
        }
        RMApp JFTAYNPVGT = IBGTIBXQJE.getRMApps().get(CZZEGHEKWM);
        Assert.assertNotNull("app doesn't exist", JFTAYNPVGT);
        Assert.assertEquals("app name doesn't match", RAHQZAPPFQ, JFTAYNPVGT.getName());
        Assert.assertEquals("app queue doesn't match", KTCCOGRNZR, JFTAYNPVGT.getQueue());
        // duplicate appId
        try {
            ZKRRUKYZNZ.submitApplication(CVSCIKHSKP);
        } catch (YarnException e) {
            Assert.fail("Exception is not expected.");
        }
        GetApplicationsRequest HESHBGPPZO = GetApplicationsRequest.newInstance(new HashSet<String>());
        GetApplicationsResponse EESRBVDFXC = ZKRRUKYZNZ.getApplications(HESHBGPPZO);
        Assert.assertEquals(5, EESRBVDFXC.getApplicationList().size());
        Set<String> QISNROBHIF = new HashSet<String>();
        QISNROBHIF.add("matchType");
        HESHBGPPZO = GetApplicationsRequest.newInstance(QISNROBHIF);
        EESRBVDFXC = ZKRRUKYZNZ.getApplications(HESHBGPPZO);
        Assert.assertEquals(1, EESRBVDFXC.getApplicationList().size());
        Assert.assertEquals(CZZEGHEKWM, EESRBVDFXC.getApplicationList().get(0).getApplicationId());
    }

    @Test
    public void testGetApplications() throws IOException, YarnException {
        /**
         * 1. Submit 3 applications alternately in two queues
         * 2. Test each of the filters
         */
        // Basic setup
        YarnScheduler VGJKMQPMML = TestClientRMService.mockYarnScheduler();
        RMContext JKPFRCXXIB = mock(RMContext.class);
        mockRMContext(VGJKMQPMML, JKPFRCXXIB);
        RMStateStore STERIXMYON = mock(RMStateStore.class);
        when(JKPFRCXXIB.getStateStore()).thenReturn(STERIXMYON);
        RMAppManager KURQRPCVSX = new RMAppManager(JKPFRCXXIB, VGJKMQPMML, null, mock(ApplicationACLsManager.class), new Configuration());
        when(JKPFRCXXIB.getDispatcher().getEventHandler()).thenReturn(new org.apache.hadoop.yarn.event.EventHandler<Event>() {
            public void handle(Event GNQCZFCLEV) {
            }
        });
        ApplicationACLsManager IGMKTGCFQE = mock(ApplicationACLsManager.class);
        QueueACLsManager KMEGEBPWQO = mock(QueueACLsManager.class);
        when(KMEGEBPWQO.checkAccess(any(UserGroupInformation.class), any(org.apache.hadoop.yarn.api.records.QueueACL.class), anyString())).thenReturn(true);
        ClientRMService QKQVXQYDHS = new ClientRMService(JKPFRCXXIB, VGJKMQPMML, KURQRPCVSX, IGMKTGCFQE, KMEGEBPWQO, null);
        // Initialize appnames and queues
        String[] LMWKOLWJKH = new String[]{ TestClientRMService.OYPOZCLQYD, TestClientRMService.TCZRAYQYJY };
        String[] UBQHWMODYA = new String[]{ MockApps.newAppName(), MockApps.newAppName(), MockApps.newAppName() };
        ApplicationId[] LIJTOJGJXB = new ApplicationId[]{ TestClientRMService.getApplicationId(101), TestClientRMService.getApplicationId(102), TestClientRMService.getApplicationId(103) };
        List<String> JHCJMKDSCY = Arrays.asList("Tag1", "Tag2", "Tag3");
        long[] MFBPDOGNXS = new long[3];
        // Submit applications
        for (int KCAAWMCLXO = 0; KCAAWMCLXO < LIJTOJGJXB.length; KCAAWMCLXO++) {
            ApplicationId DJDEZFDUZM = LIJTOJGJXB[KCAAWMCLXO];
            when(IGMKTGCFQE.checkAccess(UserGroupInformation.getCurrentUser(), ApplicationAccessType.VIEW_APP, null, DJDEZFDUZM)).thenReturn(true);
            SubmitApplicationRequest JGFIGRCKOX = mockSubmitAppRequest(DJDEZFDUZM, UBQHWMODYA[KCAAWMCLXO], LMWKOLWJKH[KCAAWMCLXO % LMWKOLWJKH.length], new HashSet<String>(JHCJMKDSCY.subList(0, KCAAWMCLXO + 1)));
            QKQVXQYDHS.submitApplication(JGFIGRCKOX);
            MFBPDOGNXS[KCAAWMCLXO] = System.currentTimeMillis();
        }
        // Test different cases of ClientRMService#getApplications()
        GetApplicationsRequest TZYVZVGGDB = GetApplicationsRequest.newInstance();
        assertEquals("Incorrect total number of apps", 6, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        // Check limit
        TZYVZVGGDB.setLimit(1L);
        assertEquals("Failed to limit applications", 1, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        // Check start range
        TZYVZVGGDB = GetApplicationsRequest.newInstance();
        TZYVZVGGDB.setStartRange(MFBPDOGNXS[0], System.currentTimeMillis());
        // 2 applications are submitted after first timeMills
        assertEquals("Incorrect number of matching start range", 2, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        // 1 application is submitted after the second timeMills
        TZYVZVGGDB.setStartRange(MFBPDOGNXS[1], System.currentTimeMillis());
        assertEquals("Incorrect number of matching start range", 1, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        // no application is submitted after the third timeMills
        TZYVZVGGDB.setStartRange(MFBPDOGNXS[2], System.currentTimeMillis());
        assertEquals("Incorrect number of matching start range", 0, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        // Check queue
        TZYVZVGGDB = GetApplicationsRequest.newInstance();
        Set<String> BNQXAARBKU = new HashSet<String>();
        TZYVZVGGDB.setQueues(BNQXAARBKU);
        BNQXAARBKU.add(LMWKOLWJKH[0]);
        assertEquals("Incorrect number of applications in queue", 2, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        assertEquals("Incorrect number of applications in queue", 2, QKQVXQYDHS.getApplications(TZYVZVGGDB, false).getApplicationList().size());
        BNQXAARBKU.add(LMWKOLWJKH[1]);
        assertEquals("Incorrect number of applications in queue", 3, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        // Check user
        TZYVZVGGDB = GetApplicationsRequest.newInstance();
        Set<String> XXRBYBMKZP = new HashSet<String>();
        TZYVZVGGDB.setUsers(XXRBYBMKZP);
        XXRBYBMKZP.add("random-user-name");
        assertEquals("Incorrect number of applications for user", 0, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        XXRBYBMKZP.add(UserGroupInformation.getCurrentUser().getShortUserName());
        assertEquals("Incorrect number of applications for user", 3, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        // Check tags
        TZYVZVGGDB = GetApplicationsRequest.newInstance(ALL, null, null, null, null, null, null, null, null);
        Set<String> OQRKBGZFZJ = new HashSet<String>();
        TZYVZVGGDB.setApplicationTags(OQRKBGZFZJ);
        assertEquals("Incorrect number of matching tags", 6, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        OQRKBGZFZJ = Sets.newHashSet(JHCJMKDSCY.get(0));
        TZYVZVGGDB.setApplicationTags(OQRKBGZFZJ);
        assertEquals("Incorrect number of matching tags", 3, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        OQRKBGZFZJ = Sets.newHashSet(JHCJMKDSCY.get(1));
        TZYVZVGGDB.setApplicationTags(OQRKBGZFZJ);
        assertEquals("Incorrect number of matching tags", 2, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        OQRKBGZFZJ = Sets.newHashSet(JHCJMKDSCY.get(2));
        TZYVZVGGDB.setApplicationTags(OQRKBGZFZJ);
        assertEquals("Incorrect number of matching tags", 1, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        // Check scope
        TZYVZVGGDB = GetApplicationsRequest.newInstance(VIEWABLE);
        assertEquals("Incorrect number of applications for the scope", 6, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
        TZYVZVGGDB = GetApplicationsRequest.newInstance(OWN);
        assertEquals("Incorrect number of applications for the scope", 3, QKQVXQYDHS.getApplications(TZYVZVGGDB).getApplicationList().size());
    }

    @Test(timeout = 4000)
    public void testConcurrentAppSubmit() throws IOException, InterruptedException, BrokenBarrierException, YarnException {
        YarnScheduler PAMHQWJBNF = TestClientRMService.mockYarnScheduler();
        RMContext WOSQEXREQL = mock(RMContext.class);
        mockRMContext(PAMHQWJBNF, WOSQEXREQL);
        RMStateStore RSGVBYGFKZ = mock(RMStateStore.class);
        when(WOSQEXREQL.getStateStore()).thenReturn(RSGVBYGFKZ);
        RMAppManager TTCHQUDNKL = new RMAppManager(WOSQEXREQL, PAMHQWJBNF, null, mock(ApplicationACLsManager.class), new Configuration());
        final ApplicationId LOCXJIVTYQ = TestClientRMService.getApplicationId(100);
        final ApplicationId XVIZSPOSPB = TestClientRMService.getApplicationId(101);
        final SubmitApplicationRequest GVHZOUCBSF = mockSubmitAppRequest(LOCXJIVTYQ, null, null);
        final SubmitApplicationRequest DSQAIUCLIV = mockSubmitAppRequest(XVIZSPOSPB, null, null);
        final CyclicBarrier ENTWGSGRKH = new CyclicBarrier(2);
        final CyclicBarrier TQNMQUXKHP = new CyclicBarrier(2);
        @SuppressWarnings("rawtypes")
        org.apache.hadoop.yarn.event.EventHandler JGJDTHDLLE = new org.apache.hadoop.yarn.event.EventHandler() {
            @Override
            public void handle(Event PMMMOUBFJR) {
                if (PMMMOUBFJR instanceof RMAppEvent) {
                    RMAppEvent WMHZBLRING = ((RMAppEvent) (PMMMOUBFJR));
                    if (WMHZBLRING.getApplicationId().equals(LOCXJIVTYQ)) {
                        try {
                            ENTWGSGRKH.await();
                            TQNMQUXKHP.await();
                        } catch (BrokenBarrierException e) {
                            TestClientRMService.FWAHKPOOAC.warn("Broken Barrier", e);
                        } catch (InterruptedException e) {
                            TestClientRMService.FWAHKPOOAC.warn("Interrupted while awaiting barriers", e);
                        }
                    }
                }
            }
        };
        when(WOSQEXREQL.getDispatcher().getEventHandler()).thenReturn(JGJDTHDLLE);
        final ClientRMService YWIWGFTNTL = new ClientRMService(WOSQEXREQL, PAMHQWJBNF, TTCHQUDNKL, null, null, null);
        // submit an app and wait for it to block while in app submission
        Thread KOHVDDWDHN = new Thread() {
            @Override
            public void run() {
                try {
                    YWIWGFTNTL.submitApplication(GVHZOUCBSF);
                } catch (YarnException e) {
                }
            }
        };
        KOHVDDWDHN.start();
        // submit another app, so go through while the first app is blocked
        ENTWGSGRKH.await();
        YWIWGFTNTL.submitApplication(DSQAIUCLIV);
        TQNMQUXKHP.await();
        KOHVDDWDHN.join();
    }

    private SubmitApplicationRequest mockSubmitAppRequest(ApplicationId JRHAHYFANL, String GMRRXWHDCX, String GBCZIKWIQG) {
        return mockSubmitAppRequest(JRHAHYFANL, GMRRXWHDCX, GBCZIKWIQG, null);
    }

    private SubmitApplicationRequest mockSubmitAppRequest(ApplicationId NBFYMQICTY, String EYWPLVBKVP, String YPHLDVFJWB, Set<String> KICPJFTPUQ) {
        return mockSubmitAppRequest(NBFYMQICTY, EYWPLVBKVP, YPHLDVFJWB, KICPJFTPUQ, false);
    }

    private SubmitApplicationRequest mockSubmitAppRequest(ApplicationId RHRZFHBVCR, String GOPFQVOPFX, String GWEJDKWLNU, Set<String> DSKSDYFSHO, boolean HPVRYOJGAV) {
        ContainerLaunchContext ECHIGAOJSK = mock(ContainerLaunchContext.class);
        Resource VXQQXAZMKA = Resources.createResource(DEFAULT_RM_SCHEDULER_MINIMUM_ALLOCATION_MB);
        ApplicationSubmissionContext HOICDTJTRC = BLAENYXREV.newRecordInstance(ApplicationSubmissionContext.class);
        HOICDTJTRC.setAMContainerSpec(ECHIGAOJSK);
        HOICDTJTRC.setApplicationName(GOPFQVOPFX);
        HOICDTJTRC.setQueue(GWEJDKWLNU);
        HOICDTJTRC.setApplicationId(RHRZFHBVCR);
        HOICDTJTRC.setResource(VXQQXAZMKA);
        HOICDTJTRC.setApplicationType(HPBIGTPBNH);
        HOICDTJTRC.setApplicationTags(DSKSDYFSHO);
        HOICDTJTRC.setUnmanagedAM(HPVRYOJGAV);
        SubmitApplicationRequest RTCCLEAGNV = BLAENYXREV.newRecordInstance(SubmitApplicationRequest.class);
        RTCCLEAGNV.setApplicationSubmissionContext(HOICDTJTRC);
        return RTCCLEAGNV;
    }

    private void mockRMContext(YarnScheduler HIZTVXSSKY, RMContext QEUIFMADGQ) throws IOException {
        Dispatcher GZDEFWHOFO = mock(Dispatcher.class);
        when(QEUIFMADGQ.getDispatcher()).thenReturn(GZDEFWHOFO);
        org.apache.hadoop.yarn.event.EventHandler DSKKZQNBET = mock(org.apache.hadoop.yarn.event.EventHandler.class);
        when(GZDEFWHOFO.getEventHandler()).thenReturn(DSKKZQNBET);
        QueueInfo PBEYWQJVON = BLAENYXREV.newRecordInstance(QueueInfo.class);
        PBEYWQJVON.setQueueName("testqueue");
        when(HIZTVXSSKY.getQueueInfo(eq("testqueue"), anyBoolean(), anyBoolean())).thenReturn(PBEYWQJVON);
        when(HIZTVXSSKY.getQueueInfo(eq("nonexistentqueue"), anyBoolean(), anyBoolean())).thenThrow(new IOException("queue does not exist"));
        RMApplicationHistoryWriter UFGINAQMNQ = mock(RMApplicationHistoryWriter.class);
        when(QEUIFMADGQ.getRMApplicationHistoryWriter()).thenReturn(UFGINAQMNQ);
        ConcurrentHashMap<ApplicationId, RMApp> FLCRFBWJGM = getRMApps(QEUIFMADGQ, HIZTVXSSKY);
        when(QEUIFMADGQ.getRMApps()).thenReturn(FLCRFBWJGM);
        when(HIZTVXSSKY.getAppsInQueue(eq("testqueue"))).thenReturn(getSchedulerApps(FLCRFBWJGM));
        ResourceScheduler NSREHROJJL = mock(ResourceScheduler.class);
        when(QEUIFMADGQ.getScheduler()).thenReturn(NSREHROJJL);
    }

    private ConcurrentHashMap<ApplicationId, RMApp> getRMApps(RMContext LBGZSRWZQZ, YarnScheduler TEGFCYUHUJ) {
        ConcurrentHashMap<ApplicationId, RMApp> BPNNZIQBQV = new ConcurrentHashMap<ApplicationId, RMApp>();
        ApplicationId RHTVUNHNPT = TestClientRMService.getApplicationId(1);
        ApplicationId CJQDJEIAGL = TestClientRMService.getApplicationId(2);
        ApplicationId HQPLZNFGKQ = TestClientRMService.getApplicationId(3);
        YarnConfiguration VTZDLTEOWK = new YarnConfiguration();
        BPNNZIQBQV.put(RHTVUNHNPT, getRMApp(LBGZSRWZQZ, TEGFCYUHUJ, RHTVUNHNPT, VTZDLTEOWK, "testqueue"));
        BPNNZIQBQV.put(CJQDJEIAGL, getRMApp(LBGZSRWZQZ, TEGFCYUHUJ, CJQDJEIAGL, VTZDLTEOWK, "a"));
        BPNNZIQBQV.put(HQPLZNFGKQ, getRMApp(LBGZSRWZQZ, TEGFCYUHUJ, HQPLZNFGKQ, VTZDLTEOWK, "testqueue"));
        return BPNNZIQBQV;
    }

    private List<ApplicationAttemptId> getSchedulerApps(Map<ApplicationId, RMApp> YSKCZIEZJS) {
        List<ApplicationAttemptId> VOEGMZELSS = new ArrayList<ApplicationAttemptId>();
        // Return app IDs for the apps in testqueue (as defined in getRMApps)
        VOEGMZELSS.add(ApplicationAttemptId.newInstance(TestClientRMService.getApplicationId(1), 0));
        VOEGMZELSS.add(ApplicationAttemptId.newInstance(TestClientRMService.getApplicationId(3), 0));
        return VOEGMZELSS;
    }

    private static ApplicationId getApplicationId(int TMRIQLMBJF) {
        return ApplicationId.newInstance(123456, TMRIQLMBJF);
    }

    private static ApplicationAttemptId getApplicationAttemptId(int LNFJALTWCH) {
        return ApplicationAttemptId.newInstance(TestClientRMService.getApplicationId(LNFJALTWCH), 1);
    }

    private RMAppImpl getRMApp(RMContext DRQMIOVVHZ, YarnScheduler JEBANBPNRG, ApplicationId SDMIGZVHUW, YarnConfiguration YWYJVLCIGY, String AKJLAADIYU) {
        ApplicationSubmissionContext YLQKUIFODF = mock(ApplicationSubmissionContext.class);
        when(YLQKUIFODF.getMaxAppAttempts()).thenReturn(1);
        RMAppImpl LGFCSENOID = spy(new RMAppImpl(SDMIGZVHUW, DRQMIOVVHZ, YWYJVLCIGY, null, null, AKJLAADIYU, YLQKUIFODF, JEBANBPNRG, null, System.currentTimeMillis(), "YARN", null));
        ApplicationAttemptId RFZHAKGIKA = ApplicationAttemptId.newInstance(ApplicationId.newInstance(123456, 1), 1);
        RMAppAttemptImpl KNEIADXAWL = spy(new RMAppAttemptImpl(RFZHAKGIKA, DRQMIOVVHZ, JEBANBPNRG, null, YLQKUIFODF, YWYJVLCIGY, false));
        Container UEQLCBJHDF = Container.newInstance(ContainerId.newInstance(RFZHAKGIKA, 1), null, "", null, null, null);
        RMContainerImpl GGJPVCDLYL = spy(new RMContainerImpl(UEQLCBJHDF, RFZHAKGIKA, null, "", DRQMIOVVHZ));
        Map<ApplicationAttemptId, RMAppAttempt> WQEVSPUIZO = new HashMap<ApplicationAttemptId, RMAppAttempt>();
        WQEVSPUIZO.put(RFZHAKGIKA, KNEIADXAWL);
        when(LGFCSENOID.getCurrentAppAttempt()).thenReturn(KNEIADXAWL);
        when(LGFCSENOID.getAppAttempts()).thenReturn(WQEVSPUIZO);
        when(KNEIADXAWL.getMasterContainer()).thenReturn(UEQLCBJHDF);
        ResourceScheduler DXILUYVHGG = mock(ResourceScheduler.class);
        when(DRQMIOVVHZ.getScheduler()).thenReturn(DXILUYVHGG);
        when(DRQMIOVVHZ.getScheduler().getRMContainer(any(ContainerId.class))).thenReturn(GGJPVCDLYL);
        SchedulerAppReport ZBWLYPAWTO = mock(SchedulerAppReport.class);
        when(DRQMIOVVHZ.getScheduler().getSchedulerAppInfo(any(ApplicationAttemptId.class))).thenReturn(ZBWLYPAWTO);
        List<RMContainer> UECYUUWXZN = new ArrayList<RMContainer>();
        UECYUUWXZN.add(GGJPVCDLYL);
        when(DRQMIOVVHZ.getScheduler().getSchedulerAppInfo(RFZHAKGIKA).getLiveContainers()).thenReturn(UECYUUWXZN);
        ContainerStatus CHOHNBMSEG = mock(ContainerStatus.class);
        when(GGJPVCDLYL.getFinishedStatus()).thenReturn(CHOHNBMSEG);
        when(GGJPVCDLYL.getDiagnosticsInfo()).thenReturn("N/A");
        when(GGJPVCDLYL.getContainerExitStatus()).thenReturn(0);
        when(GGJPVCDLYL.getContainerState()).thenReturn(ContainerState.COMPLETE);
        return LGFCSENOID;
    }

    private static YarnScheduler mockYarnScheduler() {
        YarnScheduler EEOVHBHCUM = mock(YarnScheduler.class);
        when(EEOVHBHCUM.getMinimumResourceCapability()).thenReturn(Resources.createResource(DEFAULT_RM_SCHEDULER_MINIMUM_ALLOCATION_MB));
        when(EEOVHBHCUM.getMaximumResourceCapability()).thenReturn(Resources.createResource(DEFAULT_RM_SCHEDULER_MAXIMUM_ALLOCATION_MB));
        when(EEOVHBHCUM.getAppsInQueue(TestClientRMService.OYPOZCLQYD)).thenReturn(Arrays.asList(TestClientRMService.getApplicationAttemptId(101), TestClientRMService.getApplicationAttemptId(102)));
        when(EEOVHBHCUM.getAppsInQueue(TestClientRMService.TCZRAYQYJY)).thenReturn(Arrays.asList(TestClientRMService.getApplicationAttemptId(103)));
        ApplicationAttemptId TPAEHFFTBE = TestClientRMService.getApplicationAttemptId(1);
        when(EEOVHBHCUM.getAppResourceUsageReport(TPAEHFFTBE)).thenReturn(null);
        return EEOVHBHCUM;
    }
}