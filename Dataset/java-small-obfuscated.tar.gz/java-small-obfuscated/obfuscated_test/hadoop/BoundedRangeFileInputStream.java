/**
 * BoundedRangeFIleInputStream abstracts a contiguous region of a Hadoop
 * FSDataInputStream as a regular input stream. One can create multiple
 * BoundedRangeFileInputStream on top of the same FSDataInputStream and they
 * would not interfere with each other.
 */
class BoundedRangeFileInputStream extends InputStream {
    private FSDataInputStream PDCHNGXDEU;

    private long GUTHCGJYQE;

    private long BFGUPGPVGZ;

    private long KJEZZDOUSQ;

    private final byte[] DLFVOCNQCA = new byte[1];

    /**
     * Constructor
     *
     * @param in
     * 		The FSDataInputStream we connect to.
     * @param offset
     * 		Begining offset of the region.
     * @param length
     * 		Length of the region.
     * 		
     * 		The actual length of the region may be smaller if (off_begin +
     * 		length) goes beyond the end of FS input stream.
     */
    public BoundedRangeFileInputStream(FSDataInputStream GXSFKVCTUE, long AHBVPLRZRK, long MVIJYGXZWJ) {
        if ((AHBVPLRZRK < 0) || (MVIJYGXZWJ < 0)) {
            throw new IndexOutOfBoundsException((("Invalid offset/length: " + AHBVPLRZRK) + "/") + MVIJYGXZWJ);
        }
        this.PDCHNGXDEU = GXSFKVCTUE;
        this.GUTHCGJYQE = AHBVPLRZRK;
        this.BFGUPGPVGZ = AHBVPLRZRK + MVIJYGXZWJ;
        this.KJEZZDOUSQ = -1;
    }

    @Override
    public int available() throws IOException {
        int NQOZVDDIKS = PDCHNGXDEU.available();
        if ((GUTHCGJYQE + NQOZVDDIKS) > BFGUPGPVGZ) {
            NQOZVDDIKS = ((int) (BFGUPGPVGZ - GUTHCGJYQE));
        }
        return NQOZVDDIKS;
    }

    @Override
    public int read() throws IOException {
        int WBLITXILLP = read(DLFVOCNQCA);
        if (WBLITXILLP == 1)
            return DLFVOCNQCA[0] & 0xff;

        return -1;
    }

    @Override
    public int read(byte[] ONJISZJVBD) throws IOException {
        return read(ONJISZJVBD, 0, ONJISZJVBD.length);
    }

    @Override
    public int read(byte[] JQXBWWOAUE, int ONWXHRXAUK, int WPIVJJNLWK) throws IOException {
        if ((((ONWXHRXAUK | WPIVJJNLWK) | (ONWXHRXAUK + WPIVJJNLWK)) | (JQXBWWOAUE.length - (ONWXHRXAUK + WPIVJJNLWK))) < 0) {
            throw new IndexOutOfBoundsException();
        }
        int JKDADXFOXX = ((int) (Math.min(Integer.MAX_VALUE, Math.min(WPIVJJNLWK, BFGUPGPVGZ - GUTHCGJYQE))));
        if (JKDADXFOXX == 0)
            return -1;

        int OUWEXSRPJI = 0;
        synchronized(PDCHNGXDEU) {
            PDCHNGXDEU.seek(GUTHCGJYQE);
            OUWEXSRPJI = PDCHNGXDEU.read(JQXBWWOAUE, ONWXHRXAUK, JKDADXFOXX);
        }
        if (OUWEXSRPJI < 0) {
            BFGUPGPVGZ = GUTHCGJYQE;
            return -1;
        }
        GUTHCGJYQE += OUWEXSRPJI;
        return OUWEXSRPJI;
    }

    /* We may skip beyond the end of the file. */
    @Override
    public long skip(long HQWMLBRSYG) throws IOException {
        long NUWDZEWHMG = Math.min(HQWMLBRSYG, BFGUPGPVGZ - GUTHCGJYQE);
        GUTHCGJYQE += NUWDZEWHMG;
        return NUWDZEWHMG;
    }

    @Override
    public synchronized void mark(int QHHQYWCCMU) {
        KJEZZDOUSQ = GUTHCGJYQE;
    }

    @Override
    public synchronized void reset() throws IOException {
        if (KJEZZDOUSQ < 0)
            throw new IOException("Resetting to invalid mark");

        GUTHCGJYQE = KJEZZDOUSQ;
    }

    @Override
    public boolean markSupported() {
        return true;
    }

    @Override
    public void close() {
        // Invalidate the state of the stream.
        PDCHNGXDEU = null;
        GUTHCGJYQE = BFGUPGPVGZ;
        KJEZZDOUSQ = -1;
    }
}