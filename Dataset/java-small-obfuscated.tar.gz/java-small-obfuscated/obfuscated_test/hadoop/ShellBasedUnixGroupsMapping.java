/**
 * A simple shell-based implementation of {@link GroupMappingServiceProvider}
 * that exec's the <code>groups</code> shell command to fetch the group
 * memberships of a given user.
 */
@InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
@InterfaceStability.Evolving
public class ShellBasedUnixGroupsMapping implements GroupMappingServiceProvider {
    private static final Log ALHAEKSQLG = LogFactory.getLog(ShellBasedUnixGroupsMapping.class);

    /**
     * Returns list of groups for a user
     *
     * @param user
     * 		get groups for this user
     * @return list of groups for a given user
     */
    @Override
    public List<String> getGroups(String HOFPYHYNWG) throws IOException {
        return ShellBasedUnixGroupsMapping.getUnixGroups(HOFPYHYNWG);
    }

    /**
     * Caches groups, no need to do that for this provider
     */
    @Override
    public void cacheGroupsRefresh() throws IOException {
        // does nothing in this provider of user to groups mapping
    }

    /**
     * Adds groups to cache, no need to do that for this provider
     *
     * @param groups
     * 		unused
     */
    @Override
    public void cacheGroupsAdd(List<String> GGIUOCBHAT) throws IOException {
        // does nothing in this provider of user to groups mapping
    }

    /**
     * Get the current user's group list from Unix by running the command 'groups'
     * NOTE. For non-existing user it will return EMPTY list
     *
     * @param user
     * 		user name
     * @return the groups list that the <code>user</code> belongs to. The primary
    group is returned first.
     * @throws IOException
     * 		if encounter any error when running the command
     */
    private static List<String> getUnixGroups(final String AOSIEAZKCG) throws IOException {
        String DUAUDFUAUA = "";
        try {
            DUAUDFUAUA = Shell.execCommand(Shell.getGroupsForUserCommand(AOSIEAZKCG));
        } catch (ExitCodeException e) {
            // if we didn't get the group - just return empty list;
            ShellBasedUnixGroupsMapping.ALHAEKSQLG.warn((("got exception trying to get groups for user " + AOSIEAZKCG) + ": ") + e.getMessage());
            return new LinkedList<String>();
        }
        StringTokenizer OODDJFEAYX = new StringTokenizer(DUAUDFUAUA, Shell.TOKEN_SEPARATOR_REGEX);
        List<String> WHWMQZWWRP = new LinkedList<String>();
        while (OODDJFEAYX.hasMoreTokens()) {
            WHWMQZWWRP.add(OODDJFEAYX.nextToken());
        } 
        // remove duplicated primary group
        if (!Shell.WINDOWS) {
            for (int ZMHDDHQLYH = 1; ZMHDDHQLYH < WHWMQZWWRP.size(); ZMHDDHQLYH++) {
                if (WHWMQZWWRP.get(ZMHDDHQLYH).equals(WHWMQZWWRP.get(0))) {
                    WHWMQZWWRP.remove(ZMHDDHQLYH);
                    break;
                }
            }
        }
        return WHWMQZWWRP;
    }
}