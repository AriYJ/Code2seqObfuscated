@Singleton
@Path("/ws/v1/node")
public class NMWebServices {
    private Context HHIUXWZNQN;

    private ResourceView QBFUMEQYOJ;

    private WebApp NBDIWEUWTJ;

    private static RecordFactory EYMEHRWAMN = RecordFactoryProvider.getRecordFactory(null);

    @javax.ws.rs.core.Context
    private HttpServletRequest HMXUSCKIWD;

    @javax.ws.rs.core.Context
    private HttpServletResponse IGTGGRBMDA;

    @javax.ws.rs.core.Context
    UriInfo THAJDQFAIH;

    @Inject
    public NMWebServices(final Context HWDONDSLBK, final ResourceView BHMGHPUBBJ, final WebApp YDVXGHCHBJ) {
        this.HHIUXWZNQN = HWDONDSLBK;
        this.QBFUMEQYOJ = BHMGHPUBBJ;
        this.NBDIWEUWTJ = YDVXGHCHBJ;
    }

    private void init() {
        // clear content type
        IGTGGRBMDA.setContentType(null);
    }

    @GET
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public NodeInfo get() {
        return getNodeInfo();
    }

    @GET
    @Path("/info")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public NodeInfo getNodeInfo() {
        init();
        return new NodeInfo(this.HHIUXWZNQN, this.QBFUMEQYOJ);
    }

    @GET
    @Path("/apps")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public AppsInfo getNodeApps(@QueryParam("state")
    String QHYHCFFRCV, @QueryParam("user")
    String TOCHGRWJUG) {
        init();
        AppsInfo YZANDAZOTH = new AppsInfo();
        for (Map.Entry<ApplicationId, Application> IRSYUHKIME : this.HHIUXWZNQN.getApplications().entrySet()) {
            AppInfo ZAMSRHNMUP = new AppInfo(IRSYUHKIME.getValue());
            if ((QHYHCFFRCV != null) && (!QHYHCFFRCV.isEmpty())) {
                ApplicationState.valueOf(QHYHCFFRCV);
                if (!ZAMSRHNMUP.getState().equalsIgnoreCase(QHYHCFFRCV)) {
                    continue;
                }
            }
            if (TOCHGRWJUG != null) {
                if (TOCHGRWJUG.isEmpty()) {
                    String IPUHXVVHSH = "Error: You must specify a non-empty string for the user";
                    throw new BadRequestException(IPUHXVVHSH);
                }
                if (!ZAMSRHNMUP.getUser().toString().equals(TOCHGRWJUG)) {
                    continue;
                }
            }
            YZANDAZOTH.add(ZAMSRHNMUP);
        }
        return YZANDAZOTH;
    }

    @GET
    @Path("/apps/{appid}")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public AppInfo getNodeApp(@PathParam("appid")
    String RRBBUSSXSM) {
        init();
        ApplicationId UBZTCORHQB = ConverterUtils.toApplicationId(NMWebServices.EYMEHRWAMN, RRBBUSSXSM);
        if (UBZTCORHQB == null) {
            throw new NotFoundException(("app with id " + RRBBUSSXSM) + " not found");
        }
        Application DGYANNAZEX = this.HHIUXWZNQN.getApplications().get(UBZTCORHQB);
        if (DGYANNAZEX == null) {
            throw new NotFoundException(("app with id " + RRBBUSSXSM) + " not found");
        }
        return new AppInfo(DGYANNAZEX);
    }

    @GET
    @Path("/containers")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public ContainersInfo getNodeContainers() {
        init();
        ContainersInfo RUJJCZCZGA = new ContainersInfo();
        for (Map.Entry<ContainerId, Container> WKKJEVMCAV : this.HHIUXWZNQN.getContainers().entrySet()) {
            if (WKKJEVMCAV.getValue() == null) {
                // just skip it
                continue;
            }
            ContainerInfo IMDJFZZZCS = new ContainerInfo(this.HHIUXWZNQN, WKKJEVMCAV.getValue(), THAJDQFAIH.getBaseUri().toString(), NBDIWEUWTJ.name());
            RUJJCZCZGA.add(IMDJFZZZCS);
        }
        return RUJJCZCZGA;
    }

    @GET
    @Path("/containers/{containerid}")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public ContainerInfo getNodeContainer(@PathParam("containerid")
    String ZYNHNUQYGY) {
        ContainerId VDAHWNHDLH = null;
        init();
        try {
            VDAHWNHDLH = ConverterUtils.toContainerId(ZYNHNUQYGY);
        } catch (Exception e) {
            throw new BadRequestException("invalid container id, " + ZYNHNUQYGY);
        }
        Container MXGUMPUKMQ = HHIUXWZNQN.getContainers().get(VDAHWNHDLH);
        if (MXGUMPUKMQ == null) {
            throw new NotFoundException(("container with id, " + ZYNHNUQYGY) + ", not found");
        }
        return new ContainerInfo(this.HHIUXWZNQN, MXGUMPUKMQ, THAJDQFAIH.getBaseUri().toString(), NBDIWEUWTJ.name());
    }

    /**
     * Returns the contents of a container's log file in plain text.
     *
     * Only works for containers that are still in the NodeManager's memory, so
     * logs are no longer available after the corresponding application is no
     * longer running.
     *
     * @param containerIdStr
     * 		The container ID
     * @param filename
     * 		The name of the log file
     * @return The contents of the container's log file
     */
    @GET
    @Path("/containerlogs/{containerid}/{filename}")
    @Produces({ MediaType.TEXT_PLAIN })
    @Public
    @Unstable
    public Response getLogs(@PathParam("containerid")
    String XNGDJUKHPP, @PathParam("filename")
    String UJFAXPZGIU) {
        ContainerId HUISRRTHIF;
        try {
            HUISRRTHIF = ConverterUtils.toContainerId(XNGDJUKHPP);
        } catch (IllegalArgumentException ex) {
            return Response.status(Status.BAD_REQUEST).build();
        }
        File CZTZHDCPFK = null;
        try {
            CZTZHDCPFK = ContainerLogsUtils.getContainerLogFile(HUISRRTHIF, UJFAXPZGIU, HMXUSCKIWD.getRemoteUser(), HHIUXWZNQN);
        } catch (NotFoundException ex) {
            return Response.status(Status.NOT_FOUND).entity(ex.getMessage()).build();
        } catch (YarnException ex) {
            return Response.serverError().entity(ex.getMessage()).build();
        }
        try {
            final FileInputStream NDRFPFVXCA = ContainerLogsUtils.openLogFileForRead(XNGDJUKHPP, CZTZHDCPFK, HHIUXWZNQN);
            StreamingOutput OGQKRUCWNL = new StreamingOutput() {
                @Override
                public void write(OutputStream ITVVGFXSBI) throws IOException, WebApplicationException {
                    int QOQPBCEPUF = 65536;
                    byte[] RRVQOFQYIY = new byte[QOQPBCEPUF];
                    int DNJJNMOSVQ;
                    while ((DNJJNMOSVQ = NDRFPFVXCA.read(RRVQOFQYIY, 0, QOQPBCEPUF)) > 0) {
                        ITVVGFXSBI.write(RRVQOFQYIY, 0, DNJJNMOSVQ);
                    } 
                    ITVVGFXSBI.flush();
                }
            };
            return Response.ok(OGQKRUCWNL).build();
        } catch (IOException ex) {
            return Response.serverError().entity(ex.getMessage()).build();
        }
    }
}