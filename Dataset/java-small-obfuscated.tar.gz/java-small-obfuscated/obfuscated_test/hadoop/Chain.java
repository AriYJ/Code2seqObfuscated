/**
 * The Chain class provides all the common functionality for the
 * {@link ChainMapper} and the {@link ChainReducer} classes.
 */
class Chain extends org.apache.hadoop.mapreduce.lib.chain.Chain {
    private static final String KNQGJQOBXY = "chain.mapper.byValue";

    private static final String RPHXRROXFV = "chain.reducer.byValue";

    private JobConf GSDXCRHPVA;

    private List<Mapper> MIERRATWCY = new ArrayList<Mapper>();

    private Reducer BLPHGTKWUW;

    // to cache the key/value output class serializations for each chain element
    // to avoid everytime lookup.
    private List<Serialization> YTIWWZJFYB = new ArrayList<Serialization>();

    private List<Serialization> GXTZMWTEER = new ArrayList<Serialization>();

    private Serialization NUZGZGNSCP;

    private Serialization ADZEGWNZFE;

    /**
     * Creates a Chain instance configured for a Mapper or a Reducer.
     *
     * @param isMap
     * 		TRUE indicates the chain is for a Mapper, FALSE that is for a
     * 		Reducer.
     */
    Chain(boolean OPXENDUNVK) {
        super(OPXENDUNVK);
    }

    /**
     * Adds a Mapper class to the chain job's JobConf.
     * <p/>
     * The configuration properties of the chain job have precedence over the
     * configuration properties of the Mapper.
     *
     * @param isMap
     * 		indicates if the Chain is for a Mapper or for a
     * 		Reducer.
     * @param jobConf
     * 		chain job's JobConf to add the Mapper class.
     * @param klass
     * 		the Mapper class to add.
     * @param inputKeyClass
     * 		mapper input key class.
     * @param inputValueClass
     * 		mapper input value class.
     * @param outputKeyClass
     * 		mapper output key class.
     * @param outputValueClass
     * 		mapper output value class.
     * @param byValue
     * 		indicates if key/values should be passed by value
     * 		to the next Mapper in the chain, if any.
     * @param mapperConf
     * 		a JobConf with the configuration for the Mapper
     * 		class. It is recommended to use a JobConf without default values using the
     * 		<code>JobConf(boolean loadDefaults)</code> constructor with FALSE.
     */
    public static <K1, V1, K2, V2> void addMapper(boolean ULBVZKRPST, JobConf OXKQKGNPAC, Class<? extends Mapper<K1, V1, K2, V2>> RJTCBPGAUK, Class<? extends K1> SDARILHKHN, Class<? extends V1> BDSYBKSUVG, Class<? extends K2> GWANIIJAQP, Class<? extends V2> VKKPCBXHVY, boolean WIQQAOFGXU, JobConf SHATBDNYYC) {
        String DCRQMTVSLM = getPrefix(ULBVZKRPST);
        // if a reducer chain check the Reducer has been already set
        checkReducerAlreadySet(ULBVZKRPST, OXKQKGNPAC, DCRQMTVSLM, true);
        // set the mapper class
        int FZADJCPPFK = getIndex(OXKQKGNPAC, DCRQMTVSLM);
        OXKQKGNPAC.setClass((DCRQMTVSLM + CHAIN_MAPPER_CLASS) + FZADJCPPFK, RJTCBPGAUK, Mapper.class);
        validateKeyValueTypes(ULBVZKRPST, OXKQKGNPAC, SDARILHKHN, BDSYBKSUVG, GWANIIJAQP, VKKPCBXHVY, FZADJCPPFK, DCRQMTVSLM);
        // if the Mapper does not have a private JobConf create an empty one
        if (SHATBDNYYC == null) {
            // using a JobConf without defaults to make it lightweight.
            // still the chain JobConf may have all defaults and this conf is
            // overlapped to the chain JobConf one.
            SHATBDNYYC = new JobConf(true);
        }
        // store in the private mapper conf if it works by value or by reference
        SHATBDNYYC.setBoolean(Chain.KNQGJQOBXY, WIQQAOFGXU);
        setMapperConf(ULBVZKRPST, OXKQKGNPAC, SDARILHKHN, BDSYBKSUVG, GWANIIJAQP, VKKPCBXHVY, SHATBDNYYC, FZADJCPPFK, DCRQMTVSLM);
    }

    /**
     * Sets the Reducer class to the chain job's JobConf.
     * <p/>
     * The configuration properties of the chain job have precedence over the
     * configuration properties of the Reducer.
     *
     * @param jobConf
     * 		chain job's JobConf to add the Reducer class.
     * @param klass
     * 		the Reducer class to add.
     * @param inputKeyClass
     * 		reducer input key class.
     * @param inputValueClass
     * 		reducer input value class.
     * @param outputKeyClass
     * 		reducer output key class.
     * @param outputValueClass
     * 		reducer output value class.
     * @param byValue
     * 		indicates if key/values should be passed by value
     * 		to the next Mapper in the chain, if any.
     * @param reducerConf
     * 		a JobConf with the configuration for the Reducer
     * 		class. It is recommended to use a JobConf without default values using the
     * 		<code>JobConf(boolean loadDefaults)</code> constructor with FALSE.
     */
    public static <K1, V1, K2, V2> void setReducer(JobConf WLJMGVJNWK, Class<? extends Reducer<K1, V1, K2, V2>> CADLMASZBJ, Class<? extends K1> OYWTAXRDKS, Class<? extends V1> YFKZHMVVMI, Class<? extends K2> ZFIPRUZWBD, Class<? extends V2> TIDKCAFFVH, boolean TBLONLJLFP, JobConf YFRHUMEDRK) {
        String OGBFBHLDTW = getPrefix(false);
        checkReducerAlreadySet(false, WLJMGVJNWK, OGBFBHLDTW, false);
        WLJMGVJNWK.setClass(OGBFBHLDTW + CHAIN_REDUCER_CLASS, CADLMASZBJ, Reducer.class);
        // if the Reducer does not have a private JobConf create an empty one
        if (YFRHUMEDRK == null) {
            // using a JobConf without defaults to make it lightweight.
            // still the chain JobConf may have all defaults and this conf is
            // overlapped to the chain JobConf one.
            YFRHUMEDRK = new JobConf(false);
        }
        // store in the private reducer conf the input/output classes of the reducer
        // and if it works by value or by reference
        YFRHUMEDRK.setBoolean(Chain.RPHXRROXFV, TBLONLJLFP);
        setReducerConf(WLJMGVJNWK, OYWTAXRDKS, YFKZHMVVMI, ZFIPRUZWBD, TIDKCAFFVH, YFRHUMEDRK, OGBFBHLDTW);
    }

    /**
     * Configures all the chain elements for the task.
     *
     * @param jobConf
     * 		chain job's JobConf.
     */
    public void configure(JobConf KHGHYSNXPC) {
        String BRHVHFZIBY = getPrefix(isMap);
        GSDXCRHPVA = KHGHYSNXPC;
        SerializationFactory VBABHIZVOD = new SerializationFactory(GSDXCRHPVA);
        int NCCXANQCSN = KHGHYSNXPC.getInt(BRHVHFZIBY + CHAIN_MAPPER_SIZE, 0);
        for (int IHUSVBPOEX = 0; IHUSVBPOEX < NCCXANQCSN; IHUSVBPOEX++) {
            Class<? extends Mapper> ZTKEOPTGQF = KHGHYSNXPC.getClass((BRHVHFZIBY + CHAIN_MAPPER_CLASS) + IHUSVBPOEX, null, Mapper.class);
            JobConf GJEXBUHWWS = new JobConf(getChainElementConf(KHGHYSNXPC, (BRHVHFZIBY + CHAIN_MAPPER_CONFIG) + IHUSVBPOEX));
            Mapper PMZADXMPZB = ReflectionUtils.newInstance(ZTKEOPTGQF, GJEXBUHWWS);
            MIERRATWCY.add(PMZADXMPZB);
            if (GJEXBUHWWS.getBoolean(Chain.KNQGJQOBXY, true)) {
                YTIWWZJFYB.add(VBABHIZVOD.getSerialization(GJEXBUHWWS.getClass(MAPPER_OUTPUT_KEY_CLASS, null)));
                GXTZMWTEER.add(VBABHIZVOD.getSerialization(GJEXBUHWWS.getClass(MAPPER_OUTPUT_VALUE_CLASS, null)));
            } else {
                YTIWWZJFYB.add(null);
                GXTZMWTEER.add(null);
            }
        }
        Class<? extends Reducer> KGTYHKEPYU = KHGHYSNXPC.getClass(BRHVHFZIBY + CHAIN_REDUCER_CLASS, null, Reducer.class);
        if (KGTYHKEPYU != null) {
            JobConf WFFFLWIVCX = new JobConf(getChainElementConf(KHGHYSNXPC, BRHVHFZIBY + CHAIN_REDUCER_CONFIG));
            BLPHGTKWUW = ReflectionUtils.newInstance(KGTYHKEPYU, WFFFLWIVCX);
            if (WFFFLWIVCX.getBoolean(Chain.RPHXRROXFV, true)) {
                NUZGZGNSCP = VBABHIZVOD.getSerialization(WFFFLWIVCX.getClass(REDUCER_OUTPUT_KEY_CLASS, null));
                ADZEGWNZFE = VBABHIZVOD.getSerialization(WFFFLWIVCX.getClass(REDUCER_OUTPUT_VALUE_CLASS, null));
            } else {
                NUZGZGNSCP = null;
                ADZEGWNZFE = null;
            }
        }
    }

    /**
     * Returns the chain job conf.
     *
     * @return the chain job conf.
     */
    protected JobConf getChainJobConf() {
        return GSDXCRHPVA;
    }

    /**
     * Returns the first Mapper instance in the chain.
     *
     * @return the first Mapper instance in the chain or NULL if none.
     */
    public Mapper getFirstMap() {
        return MIERRATWCY.size() > 0 ? MIERRATWCY.get(0) : null;
    }

    /**
     * Returns the Reducer instance in the chain.
     *
     * @return the Reducer instance in the chain or NULL if none.
     */
    public Reducer getReducer() {
        return BLPHGTKWUW;
    }

    /**
     * Returns the OutputCollector to be used by a Mapper instance in the chain.
     *
     * @param mapperIndex
     * 		index of the Mapper instance to get the OutputCollector.
     * @param output
     * 		the original OutputCollector of the task.
     * @param reporter
     * 		the reporter of the task.
     * @return the OutputCollector to be used in the chain.
     */
    @SuppressWarnings({ "unchecked" })
    public OutputCollector getMapperCollector(int SILQXNTGEI, OutputCollector OTUAVSEMUF, Reporter FURNWXKWOC) {
        Serialization PFMQHHXBMG = YTIWWZJFYB.get(SILQXNTGEI);
        Serialization LQQHCTZOAN = GXTZMWTEER.get(SILQXNTGEI);
        return new Chain.ChainOutputCollector(SILQXNTGEI, PFMQHHXBMG, LQQHCTZOAN, OTUAVSEMUF, FURNWXKWOC);
    }

    /**
     * Returns the OutputCollector to be used by a Mapper instance in the chain.
     *
     * @param output
     * 		the original OutputCollector of the task.
     * @param reporter
     * 		the reporter of the task.
     * @return the OutputCollector to be used in the chain.
     */
    @SuppressWarnings({ "unchecked" })
    public OutputCollector getReducerCollector(OutputCollector LVNFEQPHNA, Reporter QAVUBGXLGZ) {
        return new Chain.ChainOutputCollector(NUZGZGNSCP, ADZEGWNZFE, LVNFEQPHNA, QAVUBGXLGZ);
    }

    /**
     * Closes all the chain elements.
     *
     * @throws IOException
     * 		thrown if any of the chain elements threw an
     * 		IOException exception.
     */
    public void close() throws IOException {
        for (Mapper DRPDNPLQWK : MIERRATWCY) {
            DRPDNPLQWK.close();
        }
        if (BLPHGTKWUW != null) {
            BLPHGTKWUW.close();
        }
    }

    // using a ThreadLocal to reuse the ByteArrayOutputStream used for ser/deser
    // it has to be a thread local because if not it would break if used from a
    // MultiThreadedMapRunner.
    private ThreadLocal<DataOutputBuffer> RNUXEGDIRB = new ThreadLocal<DataOutputBuffer>() {
        protected DataOutputBuffer initialValue() {
            return new DataOutputBuffer(1024);
        }
    };

    /**
     * OutputCollector implementation used by the chain tasks.
     * <p/>
     * If it is not the end of the chain, a {@link #collect} invocation invokes
     * the next Mapper in the chain. If it is the end of the chain the task
     * OutputCollector is called.
     */
    private class ChainOutputCollector<K, V> implements OutputCollector<K, V> {
        private int OEQSZFOFPW;

        private Serialization<K> WJOONYJWRJ;

        private Serialization<V> TRICMBDVQD;

        private OutputCollector AFYXZLYFWU;

        private Reporter CTWGRMCRPM;

        /* Constructor for Mappers */
        public ChainOutputCollector(int index, Serialization<K> keySerialization, Serialization<V> valueSerialization, OutputCollector output, Reporter reporter) {
            this.nextMapperIndex = index + 1;
            this.keySerialization = keySerialization;
            this.valueSerialization = valueSerialization;
            this.output = output;
            this.reporter = reporter;
        }

        /* Constructor for Reducer */
        public ChainOutputCollector(Serialization<K> keySerialization, Serialization<V> valueSerialization, OutputCollector output, Reporter reporter) {
            this.nextMapperIndex = 0;
            this.keySerialization = keySerialization;
            this.valueSerialization = valueSerialization;
            this.output = output;
            this.reporter = reporter;
        }

        @SuppressWarnings({ "unchecked" })
        public void collect(K key, V value) throws IOException {
            if (OEQSZFOFPW < MIERRATWCY.size()) {
                // there is a next mapper in chain
                // only need to ser/deser if there is next mapper in the chain
                if (WJOONYJWRJ != null) {
                    key = makeCopyForPassByValue(WJOONYJWRJ, key);
                    value = makeCopyForPassByValue(TRICMBDVQD, value);
                }
                // gets ser/deser and mapper of next in chain
                Serialization nextKeySerialization = YTIWWZJFYB.get(OEQSZFOFPW);
                Serialization nextValueSerialization = GXTZMWTEER.get(OEQSZFOFPW);
                Mapper nextMapper = MIERRATWCY.get(OEQSZFOFPW);
                // invokes next mapper in chain
                nextMapper.map(key, value, new Chain.ChainOutputCollector(OEQSZFOFPW, nextKeySerialization, nextValueSerialization, AFYXZLYFWU, CTWGRMCRPM), CTWGRMCRPM);
            } else {
                // end of chain, user real output collector
                AFYXZLYFWU.collect(key, value);
            }
        }

        private <E> E makeCopyForPassByValue(Serialization<E> serialization, E obj) throws IOException {
            Serializer<E> ser = serialization.getSerializer(GenericsUtil.getClass(obj));
            Deserializer<E> deser = serialization.getDeserializer(GenericsUtil.getClass(obj));
            DataOutputBuffer dof = RNUXEGDIRB.get();
            dof.reset();
            ser.open(dof);
            ser.serialize(obj);
            ser.close();
            obj = ReflectionUtils.newInstance(GenericsUtil.getClass(obj), getChainJobConf());
            ByteArrayInputStream bais = new ByteArrayInputStream(dof.getData(), 0, dof.getLength());
            deser.open(bais);
            deser.deserialize(obj);
            deser.close();
            return obj;
        }
    }
}