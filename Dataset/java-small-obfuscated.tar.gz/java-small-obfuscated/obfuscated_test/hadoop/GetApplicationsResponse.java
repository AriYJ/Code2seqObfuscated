/**
 * <p>The response sent by the <code>ResourceManager</code> to a client
 * requesting an {@link ApplicationReport} for applications.</p>
 *
 * <p>The <code>ApplicationReport</code> for each application includes details
 * such as user, queue, name, host on which the <code>ApplicationMaster</code>
 * is running, RPC port, tracking URL, diagnostics, start time etc.</p>
 *
 * @see ApplicationReport
 * @see ApplicationClientProtocol#getApplications(GetApplicationsRequest)
 */
@Public
@Stable
public abstract class GetApplicationsResponse {
    @Private
    @Unstable
    public static GetApplicationsResponse newInstance(List<ApplicationReport> PGJVWYGJEZ) {
        GetApplicationsResponse QJWYWXWJTV = Records.newRecord(GetApplicationsResponse.class);
        QJWYWXWJTV.setApplicationList(PGJVWYGJEZ);
        return QJWYWXWJTV;
    }

    /**
     * Get <code>ApplicationReport</code> for applications.
     *
     * @return <code>ApplicationReport</code> for applications
     */
    @Public
    @Stable
    public abstract List<ApplicationReport> getApplicationList();

    @Private
    @Unstable
    public abstract void setApplicationList(List<ApplicationReport> MOPOYUIUOD);
}