/**
 * Render the a table of tasks for a given type.
 */
public class HsTasksBlock extends HtmlBlock {
    final App OPNWKFNIXR;

    @Inject
    HsTasksBlock(App EPJYNRJTTF) {
        this.OPNWKFNIXR = EPJYNRJTTF;
    }

    /* (non-Javadoc)
    @see org.apache.hadoop.yarn.webapp.view.HtmlBlock#render(org.apache.hadoop.yarn.webapp.view.HtmlBlock.Block)
     */
    @Override
    protected void render(Block ECLLQIRKLG) {
        if (OPNWKFNIXR.getJob() == null) {
            ECLLQIRKLG.h2($(TITLE));
            return;
        }
        TaskType GSELBEIIEA = null;
        String KUPNEXTQPI = $(TASK_TYPE);
        if (!KUPNEXTQPI.isEmpty()) {
            GSELBEIIEA = MRApps.taskType(KUPNEXTQPI);
        }
        THEAD<TABLE<Hamlet>> ZSJAUSDRMG;
        if (GSELBEIIEA != null)
            ZSJAUSDRMG = ECLLQIRKLG.table(("#" + OPNWKFNIXR.getJob().getID()) + GSELBEIIEA).$class("dt-tasks").thead();
        else
            ZSJAUSDRMG = ECLLQIRKLG.table("#tasks").thead();

        // Create the spanning row
        int LCLBMFRGUZ = (GSELBEIIEA == TaskType.REDUCE) ? 8 : 3;
        ZSJAUSDRMG.tr().th().$colspan(5).$class("ui-state-default")._("Task")._().th().$colspan(LCLBMFRGUZ).$class("ui-state-default")._("Successful Attempt")._()._();
        TR<THEAD<TABLE<Hamlet>>> NHKWXGNCUT = ZSJAUSDRMG.tr().th("Name").th("State").th("Start Time").th("Finish Time").th("Elapsed Time").th("Start Time");// Attempt

        if (GSELBEIIEA == TaskType.REDUCE) {
            NHKWXGNCUT.th("Shuffle Finish Time");// Attempt

            NHKWXGNCUT.th("Merge Finish Time");// Attempt

        }
        NHKWXGNCUT.th("Finish Time");// Attempt

        if (GSELBEIIEA == TaskType.REDUCE) {
            NHKWXGNCUT.th("Elapsed Time Shuffle");// Attempt

            NHKWXGNCUT.th("Elapsed Time Merge");// Attempt

            NHKWXGNCUT.th("Elapsed Time Reduce");// Attempt

        }
        NHKWXGNCUT.th("Elapsed Time");// Attempt

        TBODY<TABLE<Hamlet>> TPCTPMASPC = NHKWXGNCUT._()._().tbody();
        // Write all the data into a JavaScript array of arrays for JQuery
        // DataTables to display
        StringBuilder YXSGRFSWTJ = new StringBuilder("[\n");
        for (Task EMIBGZQRCA : OPNWKFNIXR.getJob().getTasks().values()) {
            if ((GSELBEIIEA != null) && (EMIBGZQRCA.getType() != GSELBEIIEA)) {
                continue;
            }
            TaskInfo NSHTJWZMMY = new TaskInfo(EMIBGZQRCA);
            String FUFMHYVNZR = NSHTJWZMMY.getId();
            long VQLFDQOEVH = NSHTJWZMMY.getStartTime();
            long VUVJXBRSZS = NSHTJWZMMY.getFinishTime();
            long FJFUUUQEOM = NSHTJWZMMY.getElapsedTime();
            long BUMHIIMMIK = -1;
            long OELRUIHVFT = -1;
            long QHDQRZCZYI = -1;
            long KAPQDSHZFY = -1;
            long JRCDXLARDU = -1;
            long AYCUAFXOLB = -1;
            long EZOIPRMAPW = -1;
            long RAIVNYRLKQ = -1;
            TaskAttempt GCXAKJIAVL = NSHTJWZMMY.getSuccessful();
            if (GCXAKJIAVL != null) {
                TaskAttemptInfo AABWHIGERX;
                if (GSELBEIIEA == TaskType.REDUCE) {
                    ReduceTaskAttemptInfo UHOUNZJANO = new ReduceTaskAttemptInfo(GCXAKJIAVL, GSELBEIIEA);
                    OELRUIHVFT = UHOUNZJANO.getShuffleFinishTime();
                    QHDQRZCZYI = UHOUNZJANO.getMergeFinishTime();
                    JRCDXLARDU = UHOUNZJANO.getElapsedShuffleTime();
                    AYCUAFXOLB = UHOUNZJANO.getElapsedMergeTime();
                    EZOIPRMAPW = UHOUNZJANO.getElapsedReduceTime();
                    AABWHIGERX = UHOUNZJANO;
                } else {
                    AABWHIGERX = new TaskAttemptInfo(GCXAKJIAVL, GSELBEIIEA, false);
                }
                BUMHIIMMIK = AABWHIGERX.getStartTime();
                KAPQDSHZFY = AABWHIGERX.getFinishTime();
                RAIVNYRLKQ = AABWHIGERX.getElapsedTime();
            }
            YXSGRFSWTJ.append("[\"").append("<a href='" + url("task", FUFMHYVNZR)).append("'>").append(FUFMHYVNZR).append("</a>\",\"").append(NSHTJWZMMY.getState()).append("\",\"").append(VQLFDQOEVH).append("\",\"").append(VUVJXBRSZS).append("\",\"").append(FJFUUUQEOM).append("\",\"").append(BUMHIIMMIK).append("\",\"");
            if (GSELBEIIEA == TaskType.REDUCE) {
                YXSGRFSWTJ.append(OELRUIHVFT).append("\",\"").append(QHDQRZCZYI).append("\",\"");
            }
            YXSGRFSWTJ.append(KAPQDSHZFY).append("\",\"");
            if (GSELBEIIEA == TaskType.REDUCE) {
                YXSGRFSWTJ.append(JRCDXLARDU).append("\",\"").append(AYCUAFXOLB).append("\",\"").append(EZOIPRMAPW).append("\",\"");
            }
            YXSGRFSWTJ.append(RAIVNYRLKQ).append("\"],\n");
        }
        // Remove the last comma and close off the array of arrays
        if (YXSGRFSWTJ.charAt(YXSGRFSWTJ.length() - 2) == ',') {
            YXSGRFSWTJ.delete(YXSGRFSWTJ.length() - 2, YXSGRFSWTJ.length() - 1);
        }
        YXSGRFSWTJ.append("]");
        ECLLQIRKLG.script().$type("text/javascript")._("var tasksTableData=" + YXSGRFSWTJ)._();
        TR<TFOOT<TABLE<Hamlet>>> ZNXAKWMHOH = TPCTPMASPC._().tfoot().tr();
        ZNXAKWMHOH.th().input("search_init").$type(InputType.text).$name("task").$value("ID")._()._().th().input("search_init").$type(InputType.text).$name("state").$value("State")._()._().th().input("search_init").$type(InputType.text).$name("start_time").$value("Start Time")._()._().th().input("search_init").$type(InputType.text).$name("finish_time").$value("Finish Time")._()._().th().input("search_init").$type(InputType.text).$name("elapsed_time").$value("Elapsed Time")._()._().th().input("search_init").$type(InputType.text).$name("attempt_start_time").$value("Start Time")._()._();
        if (GSELBEIIEA == TaskType.REDUCE) {
            ZNXAKWMHOH.th().input("search_init").$type(InputType.text).$name("shuffle_time").$value("Shuffle Time")._()._();
            ZNXAKWMHOH.th().input("search_init").$type(InputType.text).$name("merge_time").$value("Merge Time")._()._();
        }
        ZNXAKWMHOH.th().input("search_init").$type(InputType.text).$name("attempt_finish").$value("Finish Time")._()._();
        if (GSELBEIIEA == TaskType.REDUCE) {
            ZNXAKWMHOH.th().input("search_init").$type(InputType.text).$name("elapsed_shuffle_time").$value("Elapsed Shuffle Time")._()._();
            ZNXAKWMHOH.th().input("search_init").$type(InputType.text).$name("elapsed_merge_time").$value("Elapsed Merge Time")._()._();
            ZNXAKWMHOH.th().input("search_init").$type(InputType.text).$name("elapsed_reduce_time").$value("Elapsed Reduce Time")._()._();
        }
        ZNXAKWMHOH.th().input("search_init").$type(InputType.text).$name("attempt_elapsed").$value("Elapsed Time")._()._();
        ZNXAKWMHOH._()._()._();
    }
}