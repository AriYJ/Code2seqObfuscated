public class TestPipeApplication {
    private static File GDXJSQXIVB = new File("target", TestPipeApplication.class.getName() + "-workSpace");

    private static String ARBLMFKGPB = "attempt_001_02_r03_04_05";

    /**
     * test PipesMapRunner    test the transfer data from reader
     *
     * @throws Exception
     * 		
     */
    @Test
    public void testRunner() throws Exception {
        // clean old password files
        File[] GXCIUPTLWT = cleanTokenPasswordFile();
        try {
            RecordReader<FloatWritable, NullWritable> ACQKNIMZJD = new TestPipeApplication.ReaderPipesMapRunner();
            JobConf QWRWBCVZEG = new JobConf();
            QWRWBCVZEG.set(IS_JAVA_RR, "true");
            // for stdour and stderror
            QWRWBCVZEG.set(TASK_ATTEMPT_ID, TestPipeApplication.ARBLMFKGPB);
            TestPipeApplication.CombineOutputCollector<IntWritable, Text> JSDYSRNFPG = new TestPipeApplication.CombineOutputCollector<IntWritable, Text>(new Counters.Counter(), new TestPipeApplication.Progress());
            FileSystem RXVOUDOINV = new RawLocalFileSystem();
            RXVOUDOINV.setConf(QWRWBCVZEG);
            Writer<IntWritable, Text> CVLHCMSXEK = new Writer<IntWritable, Text>(QWRWBCVZEG, RXVOUDOINV.create(new Path((TestPipeApplication.GDXJSQXIVB + File.separator) + "outfile")), IntWritable.class, Text.class, null, null, true);
            JSDYSRNFPG.setWriter(CVLHCMSXEK);
            // stub for client
            File YUJNZSOZWI = getFileCommand("org.apache.hadoop.mapred.pipes.PipeApplicationRunnableStub");
            QWRWBCVZEG.set(CACHE_LOCALFILES, YUJNZSOZWI.getAbsolutePath());
            // token for authorization
            Token<AMRMTokenIdentifier> CYMVIRDCFN = new Token<AMRMTokenIdentifier>("user".getBytes(), "password".getBytes(), new Text("kind"), new Text("service"));
            TokenCache.setJobToken(CYMVIRDCFN, QWRWBCVZEG.getCredentials());
            QWRWBCVZEG.setBoolean(SKIP_RECORDS, true);
            TestPipeApplication.TestTaskReporter YSCVYRQAUE = new TestPipeApplication.TestTaskReporter();
            PipesMapRunner<FloatWritable, NullWritable, IntWritable, Text> KCZHYOCQWK = new PipesMapRunner<FloatWritable, NullWritable, IntWritable, Text>();
            initStdOut(QWRWBCVZEG);
            KCZHYOCQWK.configure(QWRWBCVZEG);
            KCZHYOCQWK.run(ACQKNIMZJD, JSDYSRNFPG, YSCVYRQAUE);
            String GXOKWUEVZV = readStdOut(QWRWBCVZEG);
            // test part of translated data. As common file for client and test -
            // clients stdOut
            // check version
            assertTrue(GXOKWUEVZV.contains("CURRENT_PROTOCOL_VERSION:0"));
            // check key and value classes
            assertTrue(GXOKWUEVZV.contains("Key class:org.apache.hadoop.io.FloatWritable"));
            assertTrue(GXOKWUEVZV.contains("Value class:org.apache.hadoop.io.NullWritable"));
            // test have sent all data from reader
            assertTrue(GXOKWUEVZV.contains("value:0.0"));
            assertTrue(GXOKWUEVZV.contains("value:9.0"));
        } finally {
            if (GXCIUPTLWT != null) {
                // remove password files
                for (File GUBOYLZMAZ : GXCIUPTLWT) {
                    GUBOYLZMAZ.deleteOnExit();
                }
            }
        }
    }

    /**
     * test org.apache.hadoop.mapred.pipes.Application
     * test a internal functions: MessageType.REGISTER_COUNTER,  INCREMENT_COUNTER, STATUS, PROGRESS...
     *
     * @throws Throwable
     * 		
     */
    @Test
    public void testApplication() throws Throwable {
        JobConf DEUCAOAFWC = new JobConf();
        RecordReader<FloatWritable, NullWritable> RDHUKPRUAC = new TestPipeApplication.Reader();
        // client for test
        File ODFRRKRDIZ = getFileCommand("org.apache.hadoop.mapred.pipes.PipeApplicationStub");
        TestPipeApplication.TestTaskReporter YIFZTMYEAY = new TestPipeApplication.TestTaskReporter();
        File[] GLPFMOBHDY = cleanTokenPasswordFile();
        try {
            DEUCAOAFWC.set(TASK_ATTEMPT_ID, TestPipeApplication.ARBLMFKGPB);
            DEUCAOAFWC.set(CACHE_LOCALFILES, ODFRRKRDIZ.getAbsolutePath());
            // token for authorization
            Token<AMRMTokenIdentifier> HTWXKHHCUW = new Token<AMRMTokenIdentifier>("user".getBytes(), "password".getBytes(), new Text("kind"), new Text("service"));
            TokenCache.setJobToken(HTWXKHHCUW, DEUCAOAFWC.getCredentials());
            TestPipeApplication.FakeCollector LIBNVJZBHW = new TestPipeApplication.FakeCollector(new Counters.Counter(), new TestPipeApplication.Progress());
            FileSystem QWQLWRLMTE = new RawLocalFileSystem();
            QWQLWRLMTE.setConf(DEUCAOAFWC);
            Writer<IntWritable, Text> SZKHOWWYGG = new Writer<IntWritable, Text>(DEUCAOAFWC, QWQLWRLMTE.create(new Path((TestPipeApplication.GDXJSQXIVB.getAbsolutePath() + File.separator) + "outfile")), IntWritable.class, Text.class, null, null, true);
            LIBNVJZBHW.setWriter(SZKHOWWYGG);
            DEUCAOAFWC.set(PRESERVE_COMMANDFILE, "true");
            initStdOut(DEUCAOAFWC);
            Application<WritableComparable<IntWritable>, Writable, IntWritable, Text> JHVSMOPUQV = new Application<WritableComparable<IntWritable>, Writable, IntWritable, Text>(DEUCAOAFWC, RDHUKPRUAC, LIBNVJZBHW, YIFZTMYEAY, IntWritable.class, Text.class);
            JHVSMOPUQV.getDownlink().flush();
            JHVSMOPUQV.getDownlink().mapItem(new IntWritable(3), new Text("txt"));
            JHVSMOPUQV.getDownlink().flush();
            JHVSMOPUQV.waitForFinish();
            SZKHOWWYGG.close();
            // test getDownlink().mapItem();
            String QXCGEXAXSV = readStdOut(DEUCAOAFWC);
            assertTrue(QXCGEXAXSV.contains("key:3"));
            assertTrue(QXCGEXAXSV.contains("value:txt"));
            // reporter test counter, and status should be sended
            // test MessageType.REGISTER_COUNTER and INCREMENT_COUNTER
            assertEquals(1.0, YIFZTMYEAY.getProgress(), 0.01);
            assertNotNull(YIFZTMYEAY.getCounter("group", "name"));
            // test status MessageType.STATUS
            assertEquals(YIFZTMYEAY.getStatus(), "PROGRESS");
            QXCGEXAXSV = readFile(new File((TestPipeApplication.GDXJSQXIVB.getAbsolutePath() + File.separator) + "outfile"));
            // check MessageType.PROGRESS
            assertEquals(0.55F, RDHUKPRUAC.getProgress(), 0.001);
            JHVSMOPUQV.getDownlink().close();
            // test MessageType.OUTPUT
            Map.Entry<IntWritable, Text> GPKFCPMGOX = LIBNVJZBHW.getCollect().entrySet().iterator().next();
            assertEquals(123, GPKFCPMGOX.getKey().get());
            assertEquals("value", GPKFCPMGOX.getValue().toString());
            try {
                // try to abort
                JHVSMOPUQV.abort(new Throwable());
                fail();
            } catch (IOException e) {
                // abort works ?
                assertEquals("pipe child exception", e.getMessage());
            }
        } finally {
            if (GLPFMOBHDY != null) {
                // remove password files
                for (File JVMIVWDLWA : GLPFMOBHDY) {
                    JVMIVWDLWA.deleteOnExit();
                }
            }
        }
    }

    /**
     * test org.apache.hadoop.mapred.pipes.Submitter
     *
     * @throws Exception
     * 		
     */
    @Test
    public void testSubmitter() throws Exception {
        JobConf UOFJIOELUK = new JobConf();
        File[] AKKVMLZZOW = cleanTokenPasswordFile();
        System.setProperty("test.build.data", "target/tmp/build/TEST_SUBMITTER_MAPPER/data");
        UOFJIOELUK.set("hadoop.log.dir", "target/tmp");
        // prepare configuration
        Submitter.setIsJavaMapper(UOFJIOELUK, false);
        Submitter.setIsJavaReducer(UOFJIOELUK, false);
        Submitter.setKeepCommandFile(UOFJIOELUK, false);
        Submitter.setIsJavaRecordReader(UOFJIOELUK, false);
        Submitter.setIsJavaRecordWriter(UOFJIOELUK, false);
        PipesPartitioner<IntWritable, Text> YGXPIRXRTR = new PipesPartitioner<IntWritable, Text>();
        YGXPIRXRTR.configure(UOFJIOELUK);
        Submitter.setJavaPartitioner(UOFJIOELUK, YGXPIRXRTR.getClass());
        assertEquals(PipesPartitioner.class, Submitter.getJavaPartitioner(UOFJIOELUK));
        // test going to call main method with System.exit(). Change Security
        SecurityManager KBKWOEZHFV = System.getSecurityManager();
        // store System.out
        PrintStream BBJTLXZIGQ = System.out;
        ByteArrayOutputStream YJPFFKRVWX = new ByteArrayOutputStream();
        ExitUtil.disableSystemExit();
        // test without parameters
        try {
            System.setOut(new PrintStream(YJPFFKRVWX));
            Submitter.main(new String[0]);
            fail();
        } catch (ExitUtil e) {
            // System.exit prohibited! output message test
            assertTrue(YJPFFKRVWX.toString().contains(""));
            assertTrue(YJPFFKRVWX.toString().contains("bin/hadoop pipes"));
            assertTrue(YJPFFKRVWX.toString().contains("[-input <path>] // Input directory"));
            assertTrue(YJPFFKRVWX.toString().contains("[-output <path>] // Output directory"));
            assertTrue(YJPFFKRVWX.toString().contains("[-jar <jar file> // jar filename"));
            assertTrue(YJPFFKRVWX.toString().contains("[-inputformat <class>] // InputFormat class"));
            assertTrue(YJPFFKRVWX.toString().contains("[-map <class>] // Java Map class"));
            assertTrue(YJPFFKRVWX.toString().contains("[-partitioner <class>] // Java Partitioner"));
            assertTrue(YJPFFKRVWX.toString().contains("[-reduce <class>] // Java Reduce class"));
            assertTrue(YJPFFKRVWX.toString().contains("[-writer <class>] // Java RecordWriter"));
            assertTrue(YJPFFKRVWX.toString().contains("[-program <executable>] // executable URI"));
            assertTrue(YJPFFKRVWX.toString().contains("[-reduces <num>] // number of reduces"));
            assertTrue(YJPFFKRVWX.toString().contains("[-lazyOutput <true/false>] // createOutputLazily"));
            assertTrue(YJPFFKRVWX.toString().contains("-conf <configuration file>     specify an application configuration file"));
            assertTrue(YJPFFKRVWX.toString().contains("-D <property=value>            use value for given property"));
            assertTrue(YJPFFKRVWX.toString().contains("-fs <local|namenode:port>      specify a namenode"));
            assertTrue(YJPFFKRVWX.toString().contains("-jt <local|jobtracker:port>    specify a job tracker"));
            assertTrue(YJPFFKRVWX.toString().contains("-files <comma separated list of files>    specify comma separated files to be copied to the map reduce cluster"));
            assertTrue(YJPFFKRVWX.toString().contains("-libjars <comma separated list of jars>    specify comma separated jar files to include in the classpath."));
            assertTrue(YJPFFKRVWX.toString().contains("-archives <comma separated list of archives>    specify comma separated archives to be unarchived on the compute machines."));
        } finally {
            System.setOut(BBJTLXZIGQ);
            // restore
            System.setSecurityManager(KBKWOEZHFV);
            if (AKKVMLZZOW != null) {
                // remove password files
                for (File RKUCLFPPLC : AKKVMLZZOW) {
                    RKUCLFPPLC.deleteOnExit();
                }
            }
        }
        // test call Submitter form command line
        try {
            File WIORHTPRTS = getFileCommand(null);
            String[] BTLWZMYGEF = new String[22];
            File ENBJSBQFKO = new File((TestPipeApplication.GDXJSQXIVB + File.separator) + "input");
            if (!ENBJSBQFKO.exists()) {
                Assert.assertTrue(ENBJSBQFKO.createNewFile());
            }
            File BAFGZTDAOH = new File((TestPipeApplication.GDXJSQXIVB + File.separator) + "output");
            FileUtil.fullyDelete(BAFGZTDAOH);
            BTLWZMYGEF[0] = "-input";
            BTLWZMYGEF[1] = ENBJSBQFKO.getAbsolutePath();// "input";

            BTLWZMYGEF[2] = "-output";
            BTLWZMYGEF[3] = BAFGZTDAOH.getAbsolutePath();// "output";

            BTLWZMYGEF[4] = "-inputformat";
            BTLWZMYGEF[5] = "org.apache.hadoop.mapred.TextInputFormat";
            BTLWZMYGEF[6] = "-map";
            BTLWZMYGEF[7] = "org.apache.hadoop.mapred.lib.IdentityMapper";
            BTLWZMYGEF[8] = "-partitioner";
            BTLWZMYGEF[9] = "org.apache.hadoop.mapred.pipes.PipesPartitioner";
            BTLWZMYGEF[10] = "-reduce";
            BTLWZMYGEF[11] = "org.apache.hadoop.mapred.lib.IdentityReducer";
            BTLWZMYGEF[12] = "-writer";
            BTLWZMYGEF[13] = "org.apache.hadoop.mapred.TextOutputFormat";
            BTLWZMYGEF[14] = "-program";
            BTLWZMYGEF[15] = WIORHTPRTS.getAbsolutePath();// "program";

            BTLWZMYGEF[16] = "-reduces";
            BTLWZMYGEF[17] = "2";
            BTLWZMYGEF[18] = "-lazyOutput";
            BTLWZMYGEF[19] = "lazyOutput";
            BTLWZMYGEF[20] = "-jobconf";
            BTLWZMYGEF[21] = "mapreduce.pipes.isjavarecordwriter=false,mapreduce.pipes.isjavarecordreader=false";
            Submitter.main(BTLWZMYGEF);
            fail();
        } catch (ExitUtil e) {
            // status should be 0
            assertEquals(e.status, 0);
        } finally {
            System.setOut(BBJTLXZIGQ);
            System.setSecurityManager(KBKWOEZHFV);
        }
    }

    /**
     * test org.apache.hadoop.mapred.pipes.PipesReducer
     * test the transfer of data: key and value
     *
     * @throws Exception
     * 		
     */
    @Test
    public void testPipesReduser() throws Exception {
        File[] DPMUOYCPGT = cleanTokenPasswordFile();
        JobConf WOBAZWXHZO = new JobConf();
        try {
            Token<AMRMTokenIdentifier> RXZRQFFIKV = new Token<AMRMTokenIdentifier>("user".getBytes(), "password".getBytes(), new Text("kind"), new Text("service"));
            TokenCache.setJobToken(RXZRQFFIKV, WOBAZWXHZO.getCredentials());
            File HKXIZKTZAT = getFileCommand("org.apache.hadoop.mapred.pipes.PipeReducerStub");
            WOBAZWXHZO.set(CACHE_LOCALFILES, HKXIZKTZAT.getAbsolutePath());
            PipesReducer<BooleanWritable, Text, IntWritable, Text> XTEHYKIFDZ = new PipesReducer<BooleanWritable, Text, IntWritable, Text>();
            XTEHYKIFDZ.configure(WOBAZWXHZO);
            BooleanWritable GLHWGZBOUV = new BooleanWritable(true);
            WOBAZWXHZO.set(TASK_ATTEMPT_ID, TestPipeApplication.ARBLMFKGPB);
            initStdOut(WOBAZWXHZO);
            WOBAZWXHZO.setBoolean(SKIP_RECORDS, true);
            TestPipeApplication.CombineOutputCollector<IntWritable, Text> TWBQCDXNVI = new TestPipeApplication.CombineOutputCollector<IntWritable, Text>(new Counters.Counter(), new TestPipeApplication.Progress());
            Reporter GXQKZVFYSU = new TestPipeApplication.TestTaskReporter();
            List<Text> UNKCNBNSBT = new ArrayList<Text>();
            UNKCNBNSBT.add(new Text("first"));
            UNKCNBNSBT.add(new Text("second"));
            UNKCNBNSBT.add(new Text("third"));
            XTEHYKIFDZ.reduce(GLHWGZBOUV, UNKCNBNSBT.iterator(), TWBQCDXNVI, GXQKZVFYSU);
            XTEHYKIFDZ.close();
            String FOHERJFKCJ = readStdOut(WOBAZWXHZO);
            // test data: key
            assertTrue(FOHERJFKCJ.contains("reducer key :true"));
            // and values
            assertTrue(FOHERJFKCJ.contains("reduce value  :first"));
            assertTrue(FOHERJFKCJ.contains("reduce value  :second"));
            assertTrue(FOHERJFKCJ.contains("reduce value  :third"));
        } finally {
            if (DPMUOYCPGT != null) {
                // remove password files
                for (File NIVQYKDPQX : DPMUOYCPGT) {
                    NIVQYKDPQX.deleteOnExit();
                }
            }
        }
    }

    /**
     * test PipesPartitioner
     * test set and get data from  PipesPartitioner
     */
    @Test
    public void testPipesPartitioner() {
        PipesPartitioner<IntWritable, Text> WKPNCHPMNL = new PipesPartitioner<IntWritable, Text>();
        JobConf HYEQSYWTQG = new JobConf();
        Submitter.getJavaPartitioner(HYEQSYWTQG);
        WKPNCHPMNL.configure(new JobConf());
        IntWritable UYMBAIKKMK = new IntWritable(4);
        // the cache empty
        assertEquals(0, WKPNCHPMNL.getPartition(UYMBAIKKMK, new Text("test"), 2));
        // set data into cache
        PipesPartitioner.setNextPartition(3);
        // get data from cache
        assertEquals(3, WKPNCHPMNL.getPartition(UYMBAIKKMK, new Text("test"), 2));
    }

    /**
     * clean previous std error and outs
     */
    private void initStdOut(JobConf RODWEACGER) {
        TaskAttemptID WFCQQYIWJZ = TaskAttemptID.forName(RODWEACGER.get(TASK_ATTEMPT_ID));
        File RDXZYWHZTQ = TaskLog.getTaskLogFile(WFCQQYIWJZ, false, STDOUT);
        File JBJQYSPVVV = TaskLog.getTaskLogFile(WFCQQYIWJZ, false, STDERR);
        // prepare folder
        if (!RDXZYWHZTQ.getParentFile().exists()) {
            RDXZYWHZTQ.getParentFile().mkdirs();
        } else {
            // clean logs
            RDXZYWHZTQ.deleteOnExit();
            JBJQYSPVVV.deleteOnExit();
        }
    }

    private String readStdOut(JobConf FCAJURTOEH) throws Exception {
        TaskAttemptID LCEFNBCSLJ = TaskAttemptID.forName(FCAJURTOEH.get(TASK_ATTEMPT_ID));
        File ADBDXZZZGC = TaskLog.getTaskLogFile(LCEFNBCSLJ, false, STDOUT);
        return readFile(ADBDXZZZGC);
    }

    private String readFile(File ECMGJCOPHU) throws Exception {
        ByteArrayOutputStream HBCIGKDMSU = new ByteArrayOutputStream();
        InputStream WXIWRSUVRA = new FileInputStream(ECMGJCOPHU);
        byte[] PBYLBHLOMF = new byte[1024];
        int EKTUVPJUHY = 0;
        while ((EKTUVPJUHY = WXIWRSUVRA.read(PBYLBHLOMF)) >= 0) {
            HBCIGKDMSU.write(PBYLBHLOMF, 0, EKTUVPJUHY);
        } 
        WXIWRSUVRA.close();
        return HBCIGKDMSU.toString();
    }

    private class Progress implements Progressable {
        @Override
        public void progress() {
        }
    }

    private File[] cleanTokenPasswordFile() throws Exception {
        File[] GTUEXSUYNE = new File[2];
        GTUEXSUYNE[0] = new File("./jobTokenPassword");
        if (GTUEXSUYNE[0].exists()) {
            FileUtil.chmod(GTUEXSUYNE[0].getAbsolutePath(), "700");
            assertTrue(GTUEXSUYNE[0].delete());
        }
        GTUEXSUYNE[1] = new File("./.jobTokenPassword.crc");
        if (GTUEXSUYNE[1].exists()) {
            FileUtil.chmod(GTUEXSUYNE[1].getAbsolutePath(), "700");
            GTUEXSUYNE[1].delete();
        }
        return GTUEXSUYNE;
    }

    private File getFileCommand(String HBTILHQCEJ) throws Exception {
        String RUELGNQVGS = System.getProperty("java.class.path");
        File KTIDOQMDGD = new File((TestPipeApplication.GDXJSQXIVB + File.separator) + "cache.sh");
        KTIDOQMDGD.deleteOnExit();
        if (!KTIDOQMDGD.getParentFile().exists()) {
            KTIDOQMDGD.getParentFile().mkdirs();
        }
        KTIDOQMDGD.createNewFile();
        OutputStream NOXZMLMFXN = new FileOutputStream(KTIDOQMDGD);
        NOXZMLMFXN.write("#!/bin/sh \n".getBytes());
        if (HBTILHQCEJ == null) {
            NOXZMLMFXN.write("ls ".getBytes());
        } else {
            NOXZMLMFXN.write(((("java -cp " + RUELGNQVGS) + " ") + HBTILHQCEJ).getBytes());
        }
        NOXZMLMFXN.flush();
        NOXZMLMFXN.close();
        FileUtil.chmod(KTIDOQMDGD.getAbsolutePath(), "700");
        return KTIDOQMDGD;
    }

    private class CombineOutputCollector<K, V extends Object> implements OutputCollector<K, V> {
        private Writer<K, V> OFREUBVBUP;

        private Counter LCPBQQZVEJ;

        private Progressable ZKKYCFYMDG;

        public CombineOutputCollector(Counters.Counter outCounter, Progressable progressable) {
            this.outCounter = outCounter;
            this.progressable = progressable;
        }

        public synchronized void setWriter(Writer<K, V> writer) {
            this.writer = writer;
        }

        public synchronized void collect(K key, V value) throws IOException {
            LCPBQQZVEJ.increment(1);
            OFREUBVBUP.append(key, value);
            ZKKYCFYMDG.progress();
        }
    }

    public static class FakeSplit implements InputSplit {
        public void write(DataOutput out) throws IOException {
        }

        public void readFields(DataInput in) throws IOException {
        }

        public long getLength() {
            return 0L;
        }

        public String[] getLocations() {
            return new String[0];
        }
    }

    private class TestTaskReporter implements Reporter {
        private int ZBGVEOEXCQ = 0;// number of records processed


        private String GNXCNBAMPC = null;

        private Counters RMBHMSPMRQ = new Counters();

        private InputSplit MPPFHDKIVA = new TestPipeApplication.FakeSplit();

        @Override
        public void progress() {
            ZBGVEOEXCQ++;
        }

        @Override
        public void setStatus(String status) {
            this.GNXCNBAMPC = status;
        }

        public String getStatus() {
            return this.GNXCNBAMPC;
        }

        public Counter getCounter(String group, String name) {
            Counters.Counter counter = null;
            if (RMBHMSPMRQ != null) {
                counter = RMBHMSPMRQ.findCounter(group, name);
                if (counter == null) {
                    Group grp = RMBHMSPMRQ.addGroup(group, group);
                    counter = grp.addCounter(name, name, 10);
                }
            }
            return counter;
        }

        public Counter getCounter(Enum<?> name) {
            return RMBHMSPMRQ == null ? null : RMBHMSPMRQ.findCounter(name);
        }

        public void incrCounter(Enum<?> key, long amount) {
            if (RMBHMSPMRQ != null) {
                RMBHMSPMRQ.incrCounter(key, amount);
            }
        }

        public void incrCounter(String group, String counter, long amount) {
            if (RMBHMSPMRQ != null) {
                RMBHMSPMRQ.incrCounter(group, counter, amount);
            }
        }

        @Override
        public InputSplit getInputSplit() throws UnsupportedOperationException {
            return MPPFHDKIVA;
        }

        @Override
        public float getProgress() {
            return ZBGVEOEXCQ;
        }
    }

    private class Reader implements RecordReader<FloatWritable, NullWritable> {
        private int HJWRXKVTWD = 0;

        private FloatWritable JYADRPTDCB;

        @Override
        public boolean next(FloatWritable key, NullWritable value) throws IOException {
            JYADRPTDCB = key;
            HJWRXKVTWD++;
            return HJWRXKVTWD <= 10;
        }

        @Override
        public float getProgress() throws IOException {
            return JYADRPTDCB.get();
        }

        @Override
        public long getPos() throws IOException {
            return HJWRXKVTWD;
        }

        @Override
        public NullWritable createValue() {
            return NullWritable.get();
        }

        @Override
        public FloatWritable createKey() {
            FloatWritable result = new FloatWritable(HJWRXKVTWD);
            return result;
        }

        @Override
        public void close() throws IOException {
        }
    }

    private class ReaderPipesMapRunner implements RecordReader<FloatWritable, NullWritable> {
        private int JWBHNDUUCV = 0;

        @Override
        public boolean next(FloatWritable key, NullWritable value) throws IOException {
            key.set(JWBHNDUUCV++);
            return JWBHNDUUCV <= 10;
        }

        @Override
        public float getProgress() throws IOException {
            return JWBHNDUUCV;
        }

        @Override
        public long getPos() throws IOException {
            return JWBHNDUUCV;
        }

        @Override
        public NullWritable createValue() {
            return NullWritable.get();
        }

        @Override
        public FloatWritable createKey() {
            FloatWritable result = new FloatWritable(JWBHNDUUCV);
            return result;
        }

        @Override
        public void close() throws IOException {
        }
    }

    private class FakeCollector extends TestPipeApplication.CombineOutputCollector<IntWritable, Text> {
        private final Map<IntWritable, Text> DBXNPSSQQY = new HashMap<IntWritable, Text>();

        public FakeCollector(Counter outCounter, Progressable progressable) {
            super(outCounter, progressable);
        }

        @Override
        public synchronized void collect(IntWritable key, Text value) throws IOException {
            DBXNPSSQQY.put(key, value);
            super.collect(key, value);
        }

        public Map<IntWritable, Text> getCollect() {
            return DBXNPSSQQY;
        }
    }
}