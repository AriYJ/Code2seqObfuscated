/**
 * Class which sets up a simple thread which runs in a loop sleeping
 * for a short interval of time. If the sleep takes significantly longer
 * than its target time, it implies that the JVM or host machine has
 * paused processing, which may cause other problems. If such a pause is
 * detected, the thread logs a message.
 */
@InterfaceAudience.Private
public class JvmPauseMonitor {
    private static final Log SVYEFAVTXI = LogFactory.getLog(JvmPauseMonitor.class);

    /**
     * The target sleep time
     */
    private static final long BMMHOUPNEX = 500;

    /**
     * log WARN if we detect a pause longer than this threshold
     */
    private final long DHGCTOYGAG;

    private static final String JVDVMTMGKW = "jvm.pause.warn-threshold.ms";

    private static final long HGQXGYIELO = 10000;

    /**
     * log INFO if we detect a pause longer than this threshold
     */
    private final long HLEMCILLMV;

    private static final String WGGZFTDHWN = "jvm.pause.info-threshold.ms";

    private static final long DMADPXMXGR = 1000;

    private long SXVNGVCVAO = 0;

    private long UCSHIEDYTS = 0;

    private long GOUPBEMNSR = 0;

    private Thread KBIRIUSOTK;

    private volatile boolean AJUVUYABLS = true;

    public JvmPauseMonitor(Configuration ZHLHUVYMFM) {
        this.DHGCTOYGAG = ZHLHUVYMFM.getLong(JvmPauseMonitor.JVDVMTMGKW, JvmPauseMonitor.HGQXGYIELO);
        this.HLEMCILLMV = ZHLHUVYMFM.getLong(JvmPauseMonitor.WGGZFTDHWN, JvmPauseMonitor.DMADPXMXGR);
    }

    public void start() {
        Preconditions.checkState(KBIRIUSOTK == null, "Already started");
        KBIRIUSOTK = new Daemon(new JvmPauseMonitor.Monitor());
        KBIRIUSOTK.start();
    }

    public void stop() {
        AJUVUYABLS = false;
        KBIRIUSOTK.interrupt();
        try {
            KBIRIUSOTK.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public boolean isStarted() {
        return KBIRIUSOTK != null;
    }

    public long getNumGcWarnThreadholdExceeded() {
        return SXVNGVCVAO;
    }

    public long getNumGcInfoThresholdExceeded() {
        return UCSHIEDYTS;
    }

    public long getTotalGcExtraSleepTime() {
        return GOUPBEMNSR;
    }

    private String formatMessage(long UGQKTOTLEC, Map<String, JvmPauseMonitor.GcTimes> BAZOSDUPQM, Map<String, JvmPauseMonitor.GcTimes> TNTKBCLLDW) {
        Set<String> NGRZGWKGIR = Sets.intersection(BAZOSDUPQM.keySet(), TNTKBCLLDW.keySet());
        List<String> YNBFIQVVJY = Lists.newArrayList();
        for (String MAZWDDERCG : NGRZGWKGIR) {
            JvmPauseMonitor.GcTimes PGSIBIMAFO = BAZOSDUPQM.get(MAZWDDERCG).subtract(TNTKBCLLDW.get(MAZWDDERCG));
            if (PGSIBIMAFO.BFMKUHTYRO != 0) {
                YNBFIQVVJY.add((("GC pool '" + MAZWDDERCG) + "' had collection(s): ") + PGSIBIMAFO.toString());
            }
        }
        String NRYFDGRBWK = (("Detected pause in JVM or host machine (eg GC): " + "pause of approximately ") + UGQKTOTLEC) + "ms\n";
        if (YNBFIQVVJY.isEmpty()) {
            NRYFDGRBWK += "No GCs detected";
        } else {
            NRYFDGRBWK += com.google.common.base.Joiner.on("\n").join(YNBFIQVVJY);
        }
        return NRYFDGRBWK;
    }

    private Map<String, JvmPauseMonitor.GcTimes> getGcTimes() {
        Map<String, JvmPauseMonitor.GcTimes> QCYUEEHTRM = Maps.newHashMap();
        List<GarbageCollectorMXBean> TXDJIXFCZD = ManagementFactory.getGarbageCollectorMXBeans();
        for (GarbageCollectorMXBean GLMNZTRUDY : TXDJIXFCZD) {
            QCYUEEHTRM.put(GLMNZTRUDY.getName(), new JvmPauseMonitor.GcTimes(GLMNZTRUDY));
        }
        return QCYUEEHTRM;
    }

    private static class GcTimes {
        private GcTimes(GarbageCollectorMXBean gcBean) {
            BFMKUHTYRO = gcBean.getCollectionCount();
            TMTOGVLINT = gcBean.getCollectionTime();
        }

        private GcTimes(long count, long time) {
            this.BFMKUHTYRO = count;
            this.TMTOGVLINT = time;
        }

        private JvmPauseMonitor.GcTimes subtract(JvmPauseMonitor.GcTimes other) {
            return new JvmPauseMonitor.GcTimes(this.BFMKUHTYRO - other.BFMKUHTYRO, this.TMTOGVLINT - other.TMTOGVLINT);
        }

        @Override
        public String toString() {
            return ((("count=" + BFMKUHTYRO) + " time=") + TMTOGVLINT) + "ms";
        }

        private long BFMKUHTYRO;

        private long TMTOGVLINT;
    }

    private class Monitor implements Runnable {
        @Override
        public void run() {
            Stopwatch sw = new Stopwatch();
            Map<String, JvmPauseMonitor.GcTimes> gcTimesBeforeSleep = getGcTimes();
            while (AJUVUYABLS) {
                sw.reset().start();
                try {
                    Thread.sleep(JvmPauseMonitor.BMMHOUPNEX);
                } catch (InterruptedException ie) {
                    return;
                }
                long extraSleepTime = sw.elapsedMillis() - JvmPauseMonitor.BMMHOUPNEX;
                Map<String, JvmPauseMonitor.GcTimes> gcTimesAfterSleep = getGcTimes();
                if (extraSleepTime > DHGCTOYGAG) {
                    ++SXVNGVCVAO;
                    JvmPauseMonitor.SVYEFAVTXI.warn(formatMessage(extraSleepTime, gcTimesAfterSleep, gcTimesBeforeSleep));
                } else
                    if (extraSleepTime > HLEMCILLMV) {
                        ++UCSHIEDYTS;
                        JvmPauseMonitor.SVYEFAVTXI.info(formatMessage(extraSleepTime, gcTimesAfterSleep, gcTimesBeforeSleep));
                    }

                GOUPBEMNSR += extraSleepTime;
                gcTimesBeforeSleep = gcTimesAfterSleep;
            } 
        }
    }

    /**
     * Simple 'main' to facilitate manual testing of the pause monitor.
     *
     * This main function just leaks memory into a list. Running this class
     * with a 1GB heap will very quickly go into "GC hell" and result in
     * log messages about the GC pauses.
     */
    public static void main(String[] SZVYHWTFKI) throws Exception {
        new JvmPauseMonitor(new Configuration()).start();
        List<String> ZIBANZVPKI = Lists.newArrayList();
        int QVWEEACMSM = 0;
        while (true) {
            ZIBANZVPKI.add(String.valueOf(QVWEEACMSM++));
        } 
    }
}