public class LogHandlerContainerFinishedEvent extends LogHandlerEvent {
    private final ContainerId EILCJVFACM;

    private final int JQHRHCQRHL;

    public LogHandlerContainerFinishedEvent(ContainerId KUOWIUJKAZ, int EZYRMPZROI) {
        super(CONTAINER_FINISHED);
        this.EILCJVFACM = KUOWIUJKAZ;
        this.JQHRHCQRHL = EZYRMPZROI;
    }

    public ContainerId getContainerId() {
        return this.EILCJVFACM;
    }

    public int getExitCode() {
        return this.JQHRHCQRHL;
    }
}