/**
 * A JUnit test to test Mini Map-Reduce Cluster with Mini-DFS.
 */
public class TestMiniMRWithDFSWithDistinctUsers {
    static final UserGroupInformation BNUXREQWRA = TestMiniMRWithDFSWithDistinctUsers.createUGI("dfs", true);

    static final UserGroupInformation ZTVNYPDAVF = TestMiniMRWithDFSWithDistinctUsers.createUGI("alice", false);

    static final UserGroupInformation PQKCMVKNNF = TestMiniMRWithDFSWithDistinctUsers.createUGI("bob", false);

    MiniMRCluster HHEEZFMIYK = null;

    MiniDFSCluster TJLQOEITHZ = null;

    FileSystem QFYFEARFSN = null;

    Configuration HTSFVAMHAQ = new Configuration();

    static UserGroupInformation createUGI(String ZKNMRMXYAA, boolean VCWNBTEXEZ) {
        String ILQRBDXTCQ = (VCWNBTEXEZ) ? "supergroup" : ZKNMRMXYAA;
        return UserGroupInformation.createUserForTesting(ZKNMRMXYAA, new String[]{ ILQRBDXTCQ });
    }

    static void mkdir(FileSystem CWDDPKEJKA, String LHYATIEAVV, String LOYRJXEJCL, String VEZAJHLOIR, short LPRTECSXQV) throws IOException {
        Path RDGBUVRFTK = new Path(LHYATIEAVV);
        CWDDPKEJKA.mkdirs(RDGBUVRFTK);
        CWDDPKEJKA.setPermission(RDGBUVRFTK, new FsPermission(LPRTECSXQV));
        CWDDPKEJKA.setOwner(RDGBUVRFTK, LOYRJXEJCL, VEZAJHLOIR);
    }

    // runs a sample job as a user (ugi)
    void runJobAsUser(final JobConf LHPZBYZGQT, UserGroupInformation OVMPYDULLZ) throws Exception {
        RunningJob AFJZOFLKZN = OVMPYDULLZ.doAs(new PrivilegedExceptionAction<RunningJob>() {
            public RunningJob run() throws IOException {
                return JobClient.runJob(LHPZBYZGQT);
            }
        });
        AFJZOFLKZN.waitForCompletion();
        Assert.assertEquals("SUCCEEDED", JobStatus.getJobRunState(AFJZOFLKZN.getJobState()));
    }

    @Before
    public void setUp() throws Exception {
        TJLQOEITHZ = new MiniDFSCluster.Builder(HTSFVAMHAQ).numDataNodes(4).build();
        QFYFEARFSN = TestMiniMRWithDFSWithDistinctUsers.BNUXREQWRA.doAs(new PrivilegedExceptionAction<FileSystem>() {
            public FileSystem run() throws IOException {
                return TJLQOEITHZ.getFileSystem();
            }
        });
        // Home directories for users
        TestMiniMRWithDFSWithDistinctUsers.mkdir(QFYFEARFSN, "/user", "nobody", "nogroup", ((short) (01777)));
        TestMiniMRWithDFSWithDistinctUsers.mkdir(QFYFEARFSN, "/user/alice", "alice", "nogroup", ((short) (0755)));
        TestMiniMRWithDFSWithDistinctUsers.mkdir(QFYFEARFSN, "/user/bob", "bob", "nogroup", ((short) (0755)));
        // staging directory root with sticky bit
        UserGroupInformation DPBMWAKEEJ = UserGroupInformation.getLoginUser();
        TestMiniMRWithDFSWithDistinctUsers.mkdir(QFYFEARFSN, "/staging", DPBMWAKEEJ.getShortUserName(), "nogroup", ((short) (01777)));
        JobConf CRGTWBKZVP = new JobConf();
        CRGTWBKZVP.set(JT_STAGING_AREA_ROOT, "/staging");
        HHEEZFMIYK = new MiniMRCluster(0, 0, 4, TJLQOEITHZ.getFileSystem().getUri().toString(), 1, null, null, DPBMWAKEEJ, CRGTWBKZVP);
    }

    @After
    public void tearDown() throws Exception {
        if (HHEEZFMIYK != null) {
            HHEEZFMIYK.shutdown();
        }
        if (TJLQOEITHZ != null) {
            TJLQOEITHZ.shutdown();
        }
    }

    @Test
    public void testDistinctUsers() throws Exception {
        JobConf UKGAPMWFTZ = HHEEZFMIYK.createJobConf();
        String BNUYIQDZKE = "The quick brown fox\nhas many silly\n" + "red fox sox\n";
        Path ZWZDCYPLVD = new Path("/testing/distinct/input");
        Path TTEOWHHJJH = new Path("/user/alice/output");
        TestMiniMRClasspath.configureWordCount(QFYFEARFSN, UKGAPMWFTZ, BNUYIQDZKE, 2, 1, ZWZDCYPLVD, TTEOWHHJJH);
        runJobAsUser(UKGAPMWFTZ, TestMiniMRWithDFSWithDistinctUsers.ZTVNYPDAVF);
        JobConf GJACRVSMXR = HHEEZFMIYK.createJobConf();
        Path AZLPZXMZHF = new Path("/testing/distinct/input2");
        Path FBELATSXSC = new Path("/user/bob/output2");
        TestMiniMRClasspath.configureWordCount(QFYFEARFSN, GJACRVSMXR, BNUYIQDZKE, 2, 1, AZLPZXMZHF, FBELATSXSC);
        runJobAsUser(GJACRVSMXR, TestMiniMRWithDFSWithDistinctUsers.PQKCMVKNNF);
    }

    /**
     * Regression test for MAPREDUCE-2327. Verifies that, even if a map
     * task makes lots of spills (more than fit in the spill index cache)
     * that it will succeed.
     */
    @Test
    public void testMultipleSpills() throws Exception {
        JobConf DIYHNBKEMJ = HHEEZFMIYK.createJobConf();
        // Make sure it spills twice
        DIYHNBKEMJ.setFloat(MAP_SORT_SPILL_PERCENT, 1.0E-4F);
        DIYHNBKEMJ.setInt(IO_SORT_MB, 1);
        // Make sure the spill records don't fit in index cache
        DIYHNBKEMJ.setInt(INDEX_CACHE_MEMORY_LIMIT, 0);
        String AWOTCGTFIG = "The quick brown fox\nhas many silly\n" + "red fox sox\n";
        Path KUYUWMVAQM = new Path("/testing/distinct/input");
        Path JHVSWGBDEW = new Path("/user/alice/output");
        TestMiniMRClasspath.configureWordCount(QFYFEARFSN, DIYHNBKEMJ, AWOTCGTFIG, 2, 1, KUYUWMVAQM, JHVSWGBDEW);
        runJobAsUser(DIYHNBKEMJ, TestMiniMRWithDFSWithDistinctUsers.ZTVNYPDAVF);
    }
}