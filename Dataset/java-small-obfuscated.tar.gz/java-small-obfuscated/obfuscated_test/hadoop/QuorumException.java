/**
 * Exception thrown when too many exceptions occur while gathering
 * responses to a quorum call.
 */
class QuorumException extends IOException {
    /**
     * Create a QuorumException instance with a descriptive message detailing
     * the underlying exceptions, as well as any successful responses which
     * were returned.
     *
     * @param <K>
     * 		the keys for the quorum calls
     * @param <V>
     * 		the success response type
     * @param successes
     * 		any successful responses returned
     * @param exceptions
     * 		the exceptions returned
     */
    public static <K, V> QuorumException create(String KVSIPNLSQS, Map<K, V> QOZAPIUZBR, Map<K, Throwable> ENZTVVFJMU) {
        Preconditions.checkArgument(!ENZTVVFJMU.isEmpty(), "Must pass exceptions");
        StringBuilder GNHIGRKKYB = new StringBuilder();
        GNHIGRKKYB.append(KVSIPNLSQS).append(". ");
        if (!QOZAPIUZBR.isEmpty()) {
            GNHIGRKKYB.append(QOZAPIUZBR.size()).append(" successful responses:\n");
            com.google.common.base.Joiner.on("\n").useForNull("null [success]").withKeyValueSeparator(": ").appendTo(GNHIGRKKYB, QOZAPIUZBR);
            GNHIGRKKYB.append("\n");
        }
        GNHIGRKKYB.append(ENZTVVFJMU.size() + " exceptions thrown:\n");
        boolean DBUKPWTYNE = true;
        for (Map.Entry<K, Throwable> UKXICMGQFJ : ENZTVVFJMU.entrySet()) {
            if (!DBUKPWTYNE) {
                GNHIGRKKYB.append("\n");
            }
            DBUKPWTYNE = false;
            GNHIGRKKYB.append(UKXICMGQFJ.getKey()).append(": ");
            if (UKXICMGQFJ.getValue() instanceof RuntimeException) {
                GNHIGRKKYB.append(StringUtils.stringifyException(UKXICMGQFJ.getValue()));
            } else
                if (UKXICMGQFJ.getValue().getLocalizedMessage() != null) {
                    GNHIGRKKYB.append(UKXICMGQFJ.getValue().getLocalizedMessage());
                } else {
                    GNHIGRKKYB.append(StringUtils.stringifyException(UKXICMGQFJ.getValue()));
                }

        }
        return new QuorumException(GNHIGRKKYB.toString());
    }

    private QuorumException(String WFBHXDNORY) {
        super(WFBHXDNORY);
    }

    private static final long PQQLGPHXJQ = 1L;
}