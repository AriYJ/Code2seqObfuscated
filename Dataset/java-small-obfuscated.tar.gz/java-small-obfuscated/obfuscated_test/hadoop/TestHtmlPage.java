public class TestHtmlPage {
    public static class TestView extends HtmlPage {
        @Override
        public void render(Page.HTML<_> html) {
            html.title("test").p("#testid")._("test note")._()._();
        }
    }

    public static class ShortView extends HtmlPage {
        @Override
        public void render(Page.HTML<_> html) {
            html.title("short test").p()._("should throw");
        }
    }

    @Test
    public void testUsual() {
        Injector NAEHNHFKHJ = WebAppTests.testPage(TestHtmlPage.TestView.class);
        PrintWriter OYZFTQONLT = NAEHNHFKHJ.getInstance(PrintWriter.class);
        // Verify the HTML page has correct meta tags in the header
        verify(OYZFTQONLT).print(" http-equiv=\"X-UA-Compatible\"");
        verify(OYZFTQONLT).print(" content=\"IE=8\"");
        verify(OYZFTQONLT).print(" http-equiv=\"Content-type\"");
        verify(OYZFTQONLT).print(String.format(" content=\"%s\"", HTML));
        verify(OYZFTQONLT).print("test");
        verify(OYZFTQONLT).print(" id=\"testid\"");
        verify(OYZFTQONLT).print("test note");
    }

    @Test(expected = WebAppException.class)
    public void testShort() {
        WebAppTests.testPage(TestHtmlPage.ShortView.class);
    }
}