/**
 * Utilities to generate fake test apps
 */
public class MockApps {
    static final Iterator<String> TRWFKMAHRD = Iterators.cycle("SleepJob", "RandomWriter", "TeraSort", "TeraGen", "PigLatin", "WordCount", "I18nApp<☯>");

    static final Iterator<String> UHCFHKICPL = Iterators.cycle("dorothy", "tinman", "scarecrow", "glinda", "nikko", "toto", "winkie", "zeke", "gulch");

    static final Iterator<YarnApplicationState> WIJEIMXSZR = Iterators.cycle(YarnApplicationState.values());

    static final Iterator<String> SGPIMAHVNF = Iterators.cycle("a.a1", "a.a2", "b.b1", "b.b2", "b.b3", "c.c1.c11", "c.c1.c12", "c.c1.c13", "c.c2", "c.c3", "c.c4");

    static final long UPPSKUXWEY = System.currentTimeMillis();

    public static String newAppName() {
        synchronized(MockApps.TRWFKMAHRD) {
            return MockApps.TRWFKMAHRD.next();
        }
    }

    public static String newUserName() {
        synchronized(MockApps.UHCFHKICPL) {
            return MockApps.UHCFHKICPL.next();
        }
    }

    public static String newQueue() {
        synchronized(MockApps.SGPIMAHVNF) {
            return MockApps.SGPIMAHVNF.next();
        }
    }

    public static ApplicationId newAppID(int LHENLJXTAX) {
        return ApplicationId.newInstance(MockApps.UPPSKUXWEY, LHENLJXTAX);
    }

    public static YarnApplicationState newAppState() {
        synchronized(MockApps.WIJEIMXSZR) {
            return MockApps.WIJEIMXSZR.next();
        }
    }
}