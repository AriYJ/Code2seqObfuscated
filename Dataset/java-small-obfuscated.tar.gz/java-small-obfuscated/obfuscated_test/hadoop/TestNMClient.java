public class TestNMClient {
    Configuration PCOWHUXSYI = null;

    MiniYARNCluster XUTEWMBASV = null;

    YarnClientImpl LLTFNKTIZN = null;

    AMRMClientImpl<ContainerRequest> RGAGOPGDTQ = null;

    NMClientImpl LNKTMCMWWR = null;

    List<NodeReport> SMOTTSWZSO = null;

    ApplicationAttemptId RNLPYHXMUQ = null;

    int WNIVWQGGMT = 3;

    NMTokenCache NWOMNGSAEZ = null;

    @Before
    public void setup() throws IOException, YarnException {
        // start minicluster
        PCOWHUXSYI = new YarnConfiguration();
        XUTEWMBASV = new MiniYARNCluster(TestAMRMClient.class.getName(), WNIVWQGGMT, 1, 1);
        XUTEWMBASV.init(PCOWHUXSYI);
        XUTEWMBASV.start();
        assertNotNull(XUTEWMBASV);
        assertEquals(STATE.STARTED, XUTEWMBASV.getServiceState());
        // start rm client
        LLTFNKTIZN = ((YarnClientImpl) (YarnClient.createYarnClient()));
        LLTFNKTIZN.init(PCOWHUXSYI);
        LLTFNKTIZN.start();
        assertNotNull(LLTFNKTIZN);
        assertEquals(STATE.STARTED, LLTFNKTIZN.getServiceState());
        // get node info
        SMOTTSWZSO = LLTFNKTIZN.getNodeReports(RUNNING);
        // submit new app
        ApplicationSubmissionContext JRIBQFAIGJ = LLTFNKTIZN.createApplication().getApplicationSubmissionContext();
        ApplicationId XKNKJXNYZM = JRIBQFAIGJ.getApplicationId();
        // set the application name
        JRIBQFAIGJ.setApplicationName("Test");
        // Set the priority for the application master
        Priority KFZIOPVWGN = Priority.newInstance(0);
        JRIBQFAIGJ.setPriority(KFZIOPVWGN);
        // Set the queue to which this application is to be submitted in the RM
        JRIBQFAIGJ.setQueue("default");
        // Set up the container launch context for the application master
        ContainerLaunchContext GWKELRUEFQ = Records.newRecord(ContainerLaunchContext.class);
        JRIBQFAIGJ.setAMContainerSpec(GWKELRUEFQ);
        // unmanaged AM
        JRIBQFAIGJ.setUnmanagedAM(true);
        // Create the request to send to the applications manager
        SubmitApplicationRequest JFKEVZNZEN = Records.newRecord(SubmitApplicationRequest.class);
        JFKEVZNZEN.setApplicationSubmissionContext(JRIBQFAIGJ);
        // Submit the application to the applications manager
        LLTFNKTIZN.submitApplication(JRIBQFAIGJ);
        // wait for app to start
        int LJOYKGXHOX = 30;
        RMAppAttempt ONWBYXBIPW = null;
        while (LJOYKGXHOX > 0) {
            ApplicationReport ZZVPSZVNNP = LLTFNKTIZN.getApplicationReport(XKNKJXNYZM);
            if (ZZVPSZVNNP.getYarnApplicationState() == YarnApplicationState.ACCEPTED) {
                RNLPYHXMUQ = ZZVPSZVNNP.getCurrentApplicationAttemptId();
                ONWBYXBIPW = XUTEWMBASV.getResourceManager().getRMContext().getRMApps().get(RNLPYHXMUQ.getApplicationId()).getCurrentAppAttempt();
                while (true) {
                    if (ONWBYXBIPW.getAppAttemptState() == RMAppAttemptState.LAUNCHED) {
                        break;
                    }
                } 
                break;
            }
            sleep(1000);
            --LJOYKGXHOX;
        } 
        if (LJOYKGXHOX == 0) {
            fail("Application hasn't bee started");
        }
        // Just dig into the ResourceManager and get the AMRMToken just for the sake
        // of testing.
        UserGroupInformation.setLoginUser(UserGroupInformation.createRemoteUser(UserGroupInformation.getCurrentUser().getUserName()));
        UserGroupInformation.getCurrentUser().addToken(ONWBYXBIPW.getAMRMToken());
        // creating an instance NMTokenCase
        NWOMNGSAEZ = new NMTokenCache();
        // start am rm client
        RGAGOPGDTQ = ((AMRMClientImpl<ContainerRequest>) (AMRMClient.<ContainerRequest>createAMRMClient()));
        // setting an instance NMTokenCase
        RGAGOPGDTQ.setNMTokenCache(NWOMNGSAEZ);
        RGAGOPGDTQ.init(PCOWHUXSYI);
        RGAGOPGDTQ.start();
        assertNotNull(RGAGOPGDTQ);
        assertEquals(STATE.STARTED, RGAGOPGDTQ.getServiceState());
        // start am nm client
        LNKTMCMWWR = ((NMClientImpl) (NMClient.createNMClient()));
        // propagating the AMRMClient NMTokenCache instance
        LNKTMCMWWR.setNMTokenCache(RGAGOPGDTQ.getNMTokenCache());
        LNKTMCMWWR.init(PCOWHUXSYI);
        LNKTMCMWWR.start();
        assertNotNull(LNKTMCMWWR);
        assertEquals(STATE.STARTED, LNKTMCMWWR.getServiceState());
    }

    @After
    public void tearDown() {
        RGAGOPGDTQ.stop();
        LLTFNKTIZN.stop();
        XUTEWMBASV.stop();
    }

    private void stopNmClient(boolean WTRWHTHZES) {
        assertNotNull("Null nmClient", LNKTMCMWWR);
        // leave one unclosed
        assertEquals(1, LNKTMCMWWR.startedContainers.size());
        // default true
        assertTrue(LNKTMCMWWR.getCleanupRunningContainers().get());
        LNKTMCMWWR.cleanupRunningContainersOnStop(WTRWHTHZES);
        assertEquals(WTRWHTHZES, LNKTMCMWWR.getCleanupRunningContainers().get());
        LNKTMCMWWR.stop();
    }

    @Test(timeout = 180000)
    public void testNMClientNoCleanupOnStop() throws IOException, YarnException {
        RGAGOPGDTQ.registerApplicationMaster("Host", 10000, "");
        testContainerManagement(LNKTMCMWWR, allocateContainers(RGAGOPGDTQ, 5));
        RGAGOPGDTQ.unregisterApplicationMaster(SUCCEEDED, null, null);
        // don't stop the running containers
        stopNmClient(false);
        assertFalse(LNKTMCMWWR.startedContainers.isEmpty());
        // now cleanup
        LNKTMCMWWR.cleanupRunningContainers();
        assertEquals(0, LNKTMCMWWR.startedContainers.size());
    }

    @Test(timeout = 200000)
    public void testNMClient() throws IOException, YarnException {
        RGAGOPGDTQ.registerApplicationMaster("Host", 10000, "");
        testContainerManagement(LNKTMCMWWR, allocateContainers(RGAGOPGDTQ, 5));
        RGAGOPGDTQ.unregisterApplicationMaster(SUCCEEDED, null, null);
        // stop the running containers on close
        assertFalse(LNKTMCMWWR.startedContainers.isEmpty());
        LNKTMCMWWR.cleanupRunningContainersOnStop(true);
        assertTrue(LNKTMCMWWR.getCleanupRunningContainers().get());
        LNKTMCMWWR.stop();
    }

    private Set<Container> allocateContainers(AMRMClientImpl<ContainerRequest> NBLBVNQLRF, int FCRGAKAFKT) throws IOException, YarnException {
        // setup container request
        Resource QKRMPWVXWM = Resource.newInstance(1024, 0);
        Priority LAEDBUAWND = Priority.newInstance(0);
        String ZKBFRPUHZD = SMOTTSWZSO.get(0).getNodeId().getHost();
        String MODACOAMIN = SMOTTSWZSO.get(0).getRackName();
        String[] VNKHUZHBWG = new String[]{ ZKBFRPUHZD };
        String[] WYDYEHTIDG = new String[]{ MODACOAMIN };
        for (int CDNHYXDHFT = 0; CDNHYXDHFT < FCRGAKAFKT; ++CDNHYXDHFT) {
            NBLBVNQLRF.addContainerRequest(new ContainerRequest(QKRMPWVXWM, VNKHUZHBWG, WYDYEHTIDG, LAEDBUAWND));
        }
        int WPPDIDZFNR = NBLBVNQLRF.remoteRequestsTable.get(LAEDBUAWND).get(ResourceRequest.ANY).get(QKRMPWVXWM).remoteRequest.getNumContainers();
        // RM should allocate container within 2 calls to allocate()
        int RHGWKYACDW = 0;
        int QAKUBOKZKU = 2;
        Set<Container> MCVLNAOBKM = new TreeSet<Container>();
        while ((RHGWKYACDW < WPPDIDZFNR) && (QAKUBOKZKU > 0)) {
            AllocateResponse GWBGLGAEIJ = NBLBVNQLRF.allocate(0.1F);
            RHGWKYACDW += GWBGLGAEIJ.getAllocatedContainers().size();
            for (Container ERYIAZNHPT : GWBGLGAEIJ.getAllocatedContainers()) {
                MCVLNAOBKM.add(ERYIAZNHPT);
            }
            if (!GWBGLGAEIJ.getNMTokens().isEmpty()) {
                for (NMToken ISVORKIXFH : GWBGLGAEIJ.getNMTokens()) {
                    NBLBVNQLRF.getNMTokenCache().setToken(ISVORKIXFH.getNodeId().toString(), ISVORKIXFH.getToken());
                }
            }
            if (RHGWKYACDW < WPPDIDZFNR) {
                // sleep to let NM's heartbeat to RM and trigger allocations
                sleep(1000);
            }
            --QAKUBOKZKU;
        } 
        return MCVLNAOBKM;
    }

    private void testContainerManagement(NMClientImpl ZQITSHZUPW, Set<Container> YNRHNHISDJ) throws IOException, YarnException {
        int EPBEEFXUDV = YNRHNHISDJ.size();
        int TRSHXYWSSW = 0;
        for (Container KRIQIIWURF : YNRHNHISDJ) {
            // getContainerStatus shouldn't be called before startContainer,
            // otherwise, NodeManager cannot find the container
            try {
                ZQITSHZUPW.getContainerStatus(KRIQIIWURF.getId(), KRIQIIWURF.getNodeId());
                fail("Exception is expected");
            } catch (YarnException e) {
                assertTrue("The thrown exception is not expected", e.getMessage().contains("is not handled by this NodeManager"));
            }
            // stopContainer shouldn't be called before startContainer,
            // otherwise, an exception will be thrown
            try {
                ZQITSHZUPW.stopContainer(KRIQIIWURF.getId(), KRIQIIWURF.getNodeId());
                fail("Exception is expected");
            } catch (YarnException e) {
                if (!e.getMessage().contains("is not handled by this NodeManager")) {
                    throw ((AssertionError) (new AssertionError("Exception is not expected: " + e).initCause(e)));
                }
            }
            Credentials EGGTAGTLMR = new Credentials();
            DataOutputBuffer VYXBEVQEZC = new DataOutputBuffer();
            EGGTAGTLMR.writeTokenStorageToStream(VYXBEVQEZC);
            ByteBuffer VRHWXYDEIK = ByteBuffer.wrap(VYXBEVQEZC.getData(), 0, VYXBEVQEZC.getLength());
            ContainerLaunchContext BKWADWGAYM = Records.newRecord(ContainerLaunchContext.class);
            BKWADWGAYM.setTokens(VRHWXYDEIK);
            try {
                ZQITSHZUPW.startContainer(KRIQIIWURF, BKWADWGAYM);
            } catch (YarnException e) {
                throw ((AssertionError) (new AssertionError("Exception is not expected: " + e).initCause(e)));
            }
            // leave one container unclosed
            if ((++TRSHXYWSSW) < EPBEEFXUDV) {
                // NodeManager may still need some time to make the container started
                testGetContainerStatus(KRIQIIWURF, TRSHXYWSSW, ContainerState.RUNNING, "", Arrays.asList(new Integer[]{ -1000 }));
                try {
                    ZQITSHZUPW.stopContainer(KRIQIIWURF.getId(), KRIQIIWURF.getNodeId());
                } catch (YarnException e) {
                    throw ((AssertionError) (new AssertionError("Exception is not expected: " + e).initCause(e)));
                }
                // getContainerStatus can be called after stopContainer
                try {
                    // O is possible if CLEANUP_CONTAINER is executed too late
                    // 137 is possible if the container is not terminated but killed
                    testGetContainerStatus(KRIQIIWURF, TRSHXYWSSW, COMPLETE, "Container killed by the ApplicationMaster.", Arrays.asList(new Integer[]{ ContainerExitStatus.KILLED_BY_APPMASTER }));
                } catch (YarnException e) {
                    // The exception is possible because, after the container is stopped,
                    // it may be removed from NM's context.
                    if (!e.getMessage().contains("was recently stopped on node manager")) {
                        throw ((AssertionError) (new AssertionError("Exception is not expected: " + e).initCause(e)));
                    }
                }
            }
        }
    }

    private void sleep(int IECBAWIQYP) {
        try {
            Thread.sleep(IECBAWIQYP);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void testGetContainerStatus(Container QRPQYXGDFG, int FRXTZAUKXY, ContainerState HYKMCSIUVZ, String AGDHHPIMMJ, List<Integer> PPYZHGDZJL) throws IOException, YarnException {
        while (true) {
            try {
                ContainerStatus LURQEDZADD = LNKTMCMWWR.getContainerStatus(QRPQYXGDFG.getId(), QRPQYXGDFG.getNodeId());
                // NodeManager may still need some time to get the stable
                // container status
                if (LURQEDZADD.getState() == HYKMCSIUVZ) {
                    assertEquals(QRPQYXGDFG.getId(), LURQEDZADD.getContainerId());
                    assertTrue((("" + FRXTZAUKXY) + ": ") + LURQEDZADD.getDiagnostics(), LURQEDZADD.getDiagnostics().contains(AGDHHPIMMJ));
                    assertTrue(PPYZHGDZJL.contains(LURQEDZADD.getExitStatus()));
                    break;
                }
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } 
    }
}