public class TestJsonUtil {
    static FileStatus toFileStatus(HdfsFileStatus JVMQQDJROH, String ULPOCZZHMT) {
        return new FileStatus(JVMQQDJROH.getLen(), JVMQQDJROH.isDir(), JVMQQDJROH.getReplication(), JVMQQDJROH.getBlockSize(), JVMQQDJROH.getModificationTime(), JVMQQDJROH.getAccessTime(), JVMQQDJROH.getPermission(), JVMQQDJROH.getOwner(), JVMQQDJROH.getGroup(), JVMQQDJROH.isSymlink() ? new org.apache.hadoop.fs.Path(JVMQQDJROH.getSymlink()) : null, new org.apache.hadoop.fs.Path(JVMQQDJROH.getFullName(ULPOCZZHMT)));
    }

    @Test
    public void testHdfsFileStatus() {
        final long TRWNQAFPJM = Time.now();
        final String EQEBLKIWQO = "/dir";
        final HdfsFileStatus XAQDVOVALQ = new HdfsFileStatus(1001L, false, 3, 1L << 26, TRWNQAFPJM, TRWNQAFPJM + 10, new FsPermission(((short) (0644))), "user", "group", DFSUtil.string2Bytes("bar"), DFSUtil.string2Bytes("foo"), INodeId.GRANDFATHER_INODE_ID, 0, null);
        final FileStatus FMIMUAMTJT = TestJsonUtil.toFileStatus(XAQDVOVALQ, EQEBLKIWQO);
        System.out.println("status  = " + XAQDVOVALQ);
        System.out.println("fstatus = " + FMIMUAMTJT);
        final String WJACVIQXTT = JsonUtil.toJsonString(XAQDVOVALQ, true);
        System.out.println("json    = " + WJACVIQXTT.replace(",", ",\n  "));
        final HdfsFileStatus ZYIYHENRUS = JsonUtil.toFileStatus(((Map<?, ?>) (JSON.parse(WJACVIQXTT))), true);
        final FileStatus VTYODPJTER = TestJsonUtil.toFileStatus(ZYIYHENRUS, EQEBLKIWQO);
        System.out.println("s2      = " + ZYIYHENRUS);
        System.out.println("fs2     = " + VTYODPJTER);
        Assert.assertEquals(FMIMUAMTJT, VTYODPJTER);
    }

    @Test
    public void testToDatanodeInfoWithoutSecurePort() throws Exception {
        Map<String, Object> XECMXLYMAJ = new HashMap<String, Object>();
        XECMXLYMAJ.put("ipAddr", "127.0.0.1");
        XECMXLYMAJ.put("hostName", "localhost");
        XECMXLYMAJ.put("storageID", "fake-id");
        XECMXLYMAJ.put("xferPort", 1337L);
        XECMXLYMAJ.put("infoPort", 1338L);
        // deliberately don't include an entry for "infoSecurePort"
        XECMXLYMAJ.put("ipcPort", 1339L);
        XECMXLYMAJ.put("capacity", 1024L);
        XECMXLYMAJ.put("dfsUsed", 512L);
        XECMXLYMAJ.put("remaining", 512L);
        XECMXLYMAJ.put("blockPoolUsed", 512L);
        XECMXLYMAJ.put("lastUpdate", 0L);
        XECMXLYMAJ.put("xceiverCount", 4096L);
        XECMXLYMAJ.put("networkLocation", "foo.bar.baz");
        XECMXLYMAJ.put("adminState", "NORMAL");
        XECMXLYMAJ.put("cacheCapacity", 123L);
        XECMXLYMAJ.put("cacheUsed", 321L);
        JsonUtil.toDatanodeInfo(XECMXLYMAJ);
    }

    @Test
    public void testToDatanodeInfoWithName() throws Exception {
        Map<String, Object> CYCBDEPQBV = new HashMap<String, Object>();
        // Older servers (1.x, 0.23, etc.) sends 'name' instead of ipAddr
        // and xferPort.
        String CBHRCQPNFL = "127.0.0.1:1004";
        CYCBDEPQBV.put("name", CBHRCQPNFL);
        CYCBDEPQBV.put("hostName", "localhost");
        CYCBDEPQBV.put("storageID", "fake-id");
        CYCBDEPQBV.put("infoPort", 1338L);
        CYCBDEPQBV.put("ipcPort", 1339L);
        CYCBDEPQBV.put("capacity", 1024L);
        CYCBDEPQBV.put("dfsUsed", 512L);
        CYCBDEPQBV.put("remaining", 512L);
        CYCBDEPQBV.put("blockPoolUsed", 512L);
        CYCBDEPQBV.put("lastUpdate", 0L);
        CYCBDEPQBV.put("xceiverCount", 4096L);
        CYCBDEPQBV.put("networkLocation", "foo.bar.baz");
        CYCBDEPQBV.put("adminState", "NORMAL");
        CYCBDEPQBV.put("cacheCapacity", 123L);
        CYCBDEPQBV.put("cacheUsed", 321L);
        DatanodeInfo ERVEIJJILF = JsonUtil.toDatanodeInfo(CYCBDEPQBV);
        Assert.assertEquals(CBHRCQPNFL, ERVEIJJILF.getXferAddr());
        // The encoded result should contain name, ipAddr and xferPort.
        Map<String, Object> NIJVWPAOET = JsonUtil.toJsonMap(ERVEIJJILF);
        Assert.assertEquals(CBHRCQPNFL, NIJVWPAOET.get("name"));
        Assert.assertEquals("127.0.0.1", NIJVWPAOET.get("ipAddr"));
        // In this test, it is Integer instead of Long since json was not actually
        // involved in constructing the map.
        Assert.assertEquals(1004, ((int) ((Integer) (NIJVWPAOET.get("xferPort")))));
        // Invalid names
        String[] MBKOIOYDZA = new String[]{ "127.0.0.1", "127.0.0.1:", ":", "127.0.0.1:sweet", ":123" };
        for (String OTIZQYIMIC : MBKOIOYDZA) {
            CYCBDEPQBV.put("name", OTIZQYIMIC);
            checkDecodeFailure(CYCBDEPQBV);
        }
        // Missing both name and ipAddr
        CYCBDEPQBV.remove("name");
        checkDecodeFailure(CYCBDEPQBV);
        // Only missing xferPort
        CYCBDEPQBV.put("ipAddr", "127.0.0.1");
        checkDecodeFailure(CYCBDEPQBV);
    }

    @Test
    public void testToAclStatus() {
        String FXSWICYMNT = "{\"AclStatus\":{\"entries\":[\"user::rwx\",\"user:user1:rw-\",\"group::rw-\",\"other::r-x\"],\"group\":\"supergroup\",\"owner\":\"testuser\",\"stickyBit\":false}}";
        Map<?, ?> OFHJEGDOWF = ((Map<?, ?>) (JSON.parse(FXSWICYMNT)));
        List<AclEntry> KWTDZIYDEM = Lists.newArrayList(aclEntry(ACCESS, USER, ALL), aclEntry(ACCESS, USER, "user1", READ_WRITE), aclEntry(ACCESS, GROUP, READ_WRITE), aclEntry(ACCESS, OTHER, READ_EXECUTE));
        AclStatus.Builder TEZQBHJOYF = new AclStatus.Builder();
        TEZQBHJOYF.owner("testuser");
        TEZQBHJOYF.group("supergroup");
        TEZQBHJOYF.addEntries(KWTDZIYDEM);
        TEZQBHJOYF.stickyBit(false);
        Assert.assertEquals("Should be equal", TEZQBHJOYF.build(), JsonUtil.toAclStatus(OFHJEGDOWF));
    }

    @Test
    public void testToJsonFromAclStatus() {
        String ZXMWAEZOIJ = "{\"AclStatus\":{\"entries\":[\"user:user1:rwx\",\"group::rw-\"],\"group\":\"supergroup\",\"owner\":\"testuser\",\"stickyBit\":false}}";
        AclStatus.Builder ASFFKDPAJU = new AclStatus.Builder();
        ASFFKDPAJU.owner("testuser");
        ASFFKDPAJU.group("supergroup");
        ASFFKDPAJU.stickyBit(false);
        List<AclEntry> AVPVYHOROW = Lists.newArrayList(aclEntry(ACCESS, USER, "user1", ALL), aclEntry(ACCESS, GROUP, READ_WRITE));
        ASFFKDPAJU.addEntries(AVPVYHOROW);
        Assert.assertEquals(ZXMWAEZOIJ, JsonUtil.toJsonString(ASFFKDPAJU.build()));
    }

    @Test
    public void testToJsonFromXAttrs() throws IOException {
        String XYIKAAMVVS = "{\"XAttrs\":[{\"name\":\"user.a1\",\"value\":\"0x313233\"}," + "{\"name\":\"user.a2\",\"value\":\"0x313131\"}]}";
        XAttr NFXNUZFXTL = new XAttr.Builder().setNameSpace(XAttr.NameSpace.USER).setName("a1").setValue(XAttrCodec.decodeValue("0x313233")).build();
        XAttr TAKKTBFRGE = new XAttr.Builder().setNameSpace(XAttr.NameSpace.USER).setName("a2").setValue(XAttrCodec.decodeValue("0x313131")).build();
        List<XAttr> LPGKHSKGHE = Lists.newArrayList();
        LPGKHSKGHE.add(NFXNUZFXTL);
        LPGKHSKGHE.add(TAKKTBFRGE);
        Assert.assertEquals(XYIKAAMVVS, JsonUtil.toJsonString(LPGKHSKGHE, HEX));
    }

    @Test
    public void testToXAttrMap() throws IOException {
        String FBZYJUQUTR = "{\"XAttrs\":[{\"name\":\"user.a1\",\"value\":\"0x313233\"}," + "{\"name\":\"user.a2\",\"value\":\"0x313131\"}]}";
        Map<?, ?> TGGTWRNONG = ((Map<?, ?>) (JSON.parse(FBZYJUQUTR)));
        XAttr HEOXBEUCCB = new XAttr.Builder().setNameSpace(XAttr.NameSpace.USER).setName("a1").setValue(XAttrCodec.decodeValue("0x313233")).build();
        XAttr KFOJIAZPZN = new XAttr.Builder().setNameSpace(XAttr.NameSpace.USER).setName("a2").setValue(XAttrCodec.decodeValue("0x313131")).build();
        List<XAttr> BTWECNCINN = Lists.newArrayList();
        BTWECNCINN.add(HEOXBEUCCB);
        BTWECNCINN.add(KFOJIAZPZN);
        Map<String, byte[]> OFYPAEINYO = XAttrHelper.buildXAttrMap(BTWECNCINN);
        Map<String, byte[]> TCQHMRVWTY = JsonUtil.toXAttrs(TGGTWRNONG);
        Assert.assertEquals(OFYPAEINYO.size(), TCQHMRVWTY.size());
        Iterator<Map.Entry<String, byte[]>> PIZLPTZGKU = OFYPAEINYO.entrySet().iterator();
        while (PIZLPTZGKU.hasNext()) {
            Map.Entry<String, byte[]> AMYKVSLXDS = PIZLPTZGKU.next();
            Assert.assertArrayEquals(AMYKVSLXDS.getValue(), TCQHMRVWTY.get(AMYKVSLXDS.getKey()));
        } 
    }

    @Test
    public void testGetXAttrFromJson() throws IOException {
        String BQHHGWVZNB = "{\"XAttrs\":[{\"name\":\"user.a1\",\"value\":\"0x313233\"}," + "{\"name\":\"user.a2\",\"value\":\"0x313131\"}]}";
        Map<?, ?> BQUPVTAJAC = ((Map<?, ?>) (JSON.parse(BQHHGWVZNB)));
        // Get xattr: user.a2
        byte[] CDVPAAJEGC = JsonUtil.getXAttr(BQUPVTAJAC, "user.a2");
        Assert.assertArrayEquals(XAttrCodec.decodeValue("0x313131"), CDVPAAJEGC);
    }

    private void checkDecodeFailure(Map<String, Object> HXKDQSDOEW) {
        try {
            JsonUtil.toDatanodeInfo(HXKDQSDOEW);
            Assert.fail("Exception not thrown against bad input.");
        } catch (Exception e) {
            // expected
        }
    }
}