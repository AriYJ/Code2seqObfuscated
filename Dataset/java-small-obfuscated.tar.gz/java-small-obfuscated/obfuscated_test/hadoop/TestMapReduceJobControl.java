/**
 * This class performs unit test for Job/JobControl classes.
 */
public class TestMapReduceJobControl extends HadoopTestCase {
    public static final Log PVJFDUQXKT = LogFactory.getLog(TestMapReduceJobControl.class.getName());

    static Path RPLBJLOWWC = new Path(System.getProperty("test.build.data", "."), "TestData");

    static Path FROZJOMJGM = new Path(TestMapReduceJobControl.RPLBJLOWWC, "indir");

    static Path GITVOBEVJE = new Path(TestMapReduceJobControl.RPLBJLOWWC, "outdir_1");

    static Path QGPSJTSWSQ = new Path(TestMapReduceJobControl.RPLBJLOWWC, "outdir_2");

    static Path KBYVUINTEA = new Path(TestMapReduceJobControl.RPLBJLOWWC, "outdir_3");

    static Path LGIWABVXQM = new Path(TestMapReduceJobControl.RPLBJLOWWC, "outdir_4");

    static ControlledJob UKXJJLAWMW = null;

    static ControlledJob PGEGRRDJII = null;

    static ControlledJob MJKTWTXLRL = null;

    static ControlledJob SVBAYHJIOS = null;

    public TestMapReduceJobControl() throws IOException {
        super(LOCAL_MR, LOCAL_FS, 2, 2);
    }

    private void cleanupData(Configuration ZSZIQJXIQL) throws Exception {
        FileSystem QQOQOJFWKJ = FileSystem.get(ZSZIQJXIQL);
        MapReduceTestUtil.cleanData(QQOQOJFWKJ, TestMapReduceJobControl.FROZJOMJGM);
        MapReduceTestUtil.generateData(QQOQOJFWKJ, TestMapReduceJobControl.FROZJOMJGM);
        MapReduceTestUtil.cleanData(QQOQOJFWKJ, TestMapReduceJobControl.GITVOBEVJE);
        MapReduceTestUtil.cleanData(QQOQOJFWKJ, TestMapReduceJobControl.QGPSJTSWSQ);
        MapReduceTestUtil.cleanData(QQOQOJFWKJ, TestMapReduceJobControl.KBYVUINTEA);
        MapReduceTestUtil.cleanData(QQOQOJFWKJ, TestMapReduceJobControl.LGIWABVXQM);
    }

    /**
     * This is a main function for testing JobControl class.
     * It requires 4 jobs:
     *      Job 1: passed as parameter. input:indir  output:outdir_1
     *      Job 2: copy data from indir to outdir_2
     *      Job 3: copy data from outdir_1 and outdir_2 to outdir_3
     *      Job 4: copy data from outdir to outdir_4
     * The jobs 1 and 2 have no dependency. The job 3 depends on jobs 1 and 2.
     * The job 4 depends on job 3.
     *
     * Then it creates a JobControl object and add the 4 jobs to
     * the JobControl object.
     * Finally, it creates a thread to run the JobControl object
     */
    private JobControl createDependencies(Configuration SOMNRDMFTU, Job ZLFGMEERJO) throws Exception {
        List<ControlledJob> JNZBRAERNR = null;
        TestMapReduceJobControl.UKXJJLAWMW = new ControlledJob(ZLFGMEERJO, JNZBRAERNR);
        Job YOICPVHOTX = MapReduceTestUtil.createCopyJob(SOMNRDMFTU, TestMapReduceJobControl.QGPSJTSWSQ, TestMapReduceJobControl.FROZJOMJGM);
        TestMapReduceJobControl.PGEGRRDJII = new ControlledJob(YOICPVHOTX, JNZBRAERNR);
        Job UNGXFNFYET = MapReduceTestUtil.createCopyJob(SOMNRDMFTU, TestMapReduceJobControl.KBYVUINTEA, TestMapReduceJobControl.GITVOBEVJE, TestMapReduceJobControl.QGPSJTSWSQ);
        JNZBRAERNR = new ArrayList<ControlledJob>();
        JNZBRAERNR.add(TestMapReduceJobControl.UKXJJLAWMW);
        JNZBRAERNR.add(TestMapReduceJobControl.PGEGRRDJII);
        TestMapReduceJobControl.MJKTWTXLRL = new ControlledJob(UNGXFNFYET, JNZBRAERNR);
        Job DKDINMCBQA = MapReduceTestUtil.createCopyJob(SOMNRDMFTU, TestMapReduceJobControl.LGIWABVXQM, TestMapReduceJobControl.KBYVUINTEA);
        JNZBRAERNR = new ArrayList<ControlledJob>();
        JNZBRAERNR.add(TestMapReduceJobControl.MJKTWTXLRL);
        TestMapReduceJobControl.SVBAYHJIOS = new ControlledJob(DKDINMCBQA, JNZBRAERNR);
        JobControl LINXOZIFRB = new JobControl("Test");
        LINXOZIFRB.addJob(TestMapReduceJobControl.UKXJJLAWMW);
        LINXOZIFRB.addJob(TestMapReduceJobControl.PGEGRRDJII);
        LINXOZIFRB.addJob(TestMapReduceJobControl.MJKTWTXLRL);
        LINXOZIFRB.addJob(TestMapReduceJobControl.SVBAYHJIOS);
        Thread PZLUOGESJR = new Thread(LINXOZIFRB);
        PZLUOGESJR.start();
        return LINXOZIFRB;
    }

    private void waitTillAllFinished(JobControl FDADFXJQRJ) {
        while (!FDADFXJQRJ.allFinished()) {
            try {
                Thread.sleep(100);
            } catch (Exception e) {
            }
        } 
    }

    public void testJobControlWithFailJob() throws Exception {
        TestMapReduceJobControl.PVJFDUQXKT.info("Starting testJobControlWithFailJob");
        Configuration YJEVJSAQYX = createJobConf();
        cleanupData(YJEVJSAQYX);
        // create a Fail job
        Job ALERWGBEMR = MapReduceTestUtil.createFailJob(YJEVJSAQYX, TestMapReduceJobControl.GITVOBEVJE, TestMapReduceJobControl.FROZJOMJGM);
        // create job dependencies
        JobControl CTNFMNHRLS = createDependencies(YJEVJSAQYX, ALERWGBEMR);
        // wait till all the jobs complete
        waitTillAllFinished(CTNFMNHRLS);
        assertTrue(TestMapReduceJobControl.UKXJJLAWMW.getJobState() == State.FAILED);
        assertTrue(TestMapReduceJobControl.PGEGRRDJII.getJobState() == State.SUCCESS);
        assertTrue(TestMapReduceJobControl.MJKTWTXLRL.getJobState() == State.DEPENDENT_FAILED);
        assertTrue(TestMapReduceJobControl.SVBAYHJIOS.getJobState() == State.DEPENDENT_FAILED);
        CTNFMNHRLS.stop();
    }

    public void testJobControlWithKillJob() throws Exception {
        TestMapReduceJobControl.PVJFDUQXKT.info("Starting testJobControlWithKillJob");
        Configuration DHNPEXVPFS = createJobConf();
        cleanupData(DHNPEXVPFS);
        Job IYOKGSOPCI = MapReduceTestUtil.createKillJob(DHNPEXVPFS, TestMapReduceJobControl.GITVOBEVJE, TestMapReduceJobControl.FROZJOMJGM);
        JobControl KKJGPIOCSE = createDependencies(DHNPEXVPFS, IYOKGSOPCI);
        while (TestMapReduceJobControl.UKXJJLAWMW.getJobState() != State.RUNNING) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                break;
            }
        } 
        // verify adding dependingJo to RUNNING job fails.
        assertFalse(TestMapReduceJobControl.UKXJJLAWMW.addDependingJob(TestMapReduceJobControl.PGEGRRDJII));
        // suspend jobcontrol and resume it again
        KKJGPIOCSE.suspend();
        assertTrue(KKJGPIOCSE.getThreadState() == ThreadState.SUSPENDED);
        KKJGPIOCSE.resume();
        // kill the first job.
        TestMapReduceJobControl.UKXJJLAWMW.killJob();
        // wait till all the jobs complete
        waitTillAllFinished(KKJGPIOCSE);
        assertTrue(TestMapReduceJobControl.UKXJJLAWMW.getJobState() == State.FAILED);
        assertTrue(TestMapReduceJobControl.PGEGRRDJII.getJobState() == State.SUCCESS);
        assertTrue(TestMapReduceJobControl.MJKTWTXLRL.getJobState() == State.DEPENDENT_FAILED);
        assertTrue(TestMapReduceJobControl.SVBAYHJIOS.getJobState() == State.DEPENDENT_FAILED);
        KKJGPIOCSE.stop();
    }

    public void testJobControl() throws Exception {
        TestMapReduceJobControl.PVJFDUQXKT.info("Starting testJobControl");
        Configuration BZKKLFXQMM = createJobConf();
        cleanupData(BZKKLFXQMM);
        Job NRWWDOIGRX = MapReduceTestUtil.createCopyJob(BZKKLFXQMM, TestMapReduceJobControl.GITVOBEVJE, TestMapReduceJobControl.FROZJOMJGM);
        JobControl DWJEZHHQEY = createDependencies(BZKKLFXQMM, NRWWDOIGRX);
        // wait till all the jobs complete
        waitTillAllFinished(DWJEZHHQEY);
        assertEquals("Some jobs failed", 0, DWJEZHHQEY.getFailedJobList().size());
        DWJEZHHQEY.stop();
    }

    @Test(timeout = 30000)
    public void testControlledJob() throws Exception {
        TestMapReduceJobControl.PVJFDUQXKT.info("Starting testControlledJob");
        Configuration HPBXVTICKS = createJobConf();
        cleanupData(HPBXVTICKS);
        Job PQTYKZFEMO = MapReduceTestUtil.createCopyJob(HPBXVTICKS, TestMapReduceJobControl.GITVOBEVJE, TestMapReduceJobControl.FROZJOMJGM);
        JobControl CIYMCRZHII = createDependencies(HPBXVTICKS, PQTYKZFEMO);
        while (TestMapReduceJobControl.UKXJJLAWMW.getJobState() != State.RUNNING) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                break;
            }
        } 
        Assert.assertNotNull(TestMapReduceJobControl.UKXJJLAWMW.getMapredJobId());
        // wait till all the jobs complete
        waitTillAllFinished(CIYMCRZHII);
        assertEquals("Some jobs failed", 0, CIYMCRZHII.getFailedJobList().size());
        CIYMCRZHII.stop();
    }
}