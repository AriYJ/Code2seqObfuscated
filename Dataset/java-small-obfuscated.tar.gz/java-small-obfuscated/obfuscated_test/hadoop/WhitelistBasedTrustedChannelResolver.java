public class WhitelistBasedTrustedChannelResolver extends TrustedChannelResolver {
    private CombinedIPWhiteList MERTTBNUCN;

    private CombinedIPWhiteList TLIFZXRCWS;

    private static final String PGSZDHAKKA = "/etc/hadoop/fixedwhitelist";

    private static final String DXUHWBFGJG = "/etc/hadoop/whitelist";

    /**
     * Path to the file to containing subnets and ip addresses to form fixed whitelist.
     */
    public static final String DIYKJQSQKV = "dfs.datatransfer.server.fixedwhitelist.file";

    /**
     * Enables/Disables variable whitelist
     */
    public static final String BWHLCVSAJI = "dfs.datatransfer.server.variablewhitelist.enable";

    /**
     * Path to the file to containing subnets and ip addresses to form variable whitelist.
     */
    public static final String WJTWBJESEJ = "dfs.datatransfer.server.variablewhitelist.file";

    /**
     * time in seconds by which the variable whitelist file is checked for updates
     */
    public static final String APAPEXTRFM = "dfs.datatransfer.server.variablewhitelist.cache.secs";

    /**
     * Path to the file to containing subnets and ip addresses to form fixed whitelist.
     */
    public static final String CAXYACEHZH = "dfs.datatransfer.client.fixedwhitelist.file";

    /**
     * Enables/Disables variable whitelist
     */
    public static final String WEBAMMOXHX = "dfs.datatransfer.client.variablewhitelist.enable";

    /**
     * Path to the file to containing subnets and ip addresses to form variable whitelist.
     */
    public static final String IRZJYGHKKT = "dfs.datatransfer.client.variablewhitelist.file";

    /**
     * time in seconds by which the variable whitelist file is checked for updates
     */
    public static final String ZSPLBOAHSW = "dfs.datatransfer.client.variablewhitelist.cache.secs";

    @Override
    public void setConf(Configuration ILPZPKNSBP) {
        super.setConf(ILPZPKNSBP);
        String LBLYCQZXHX = ILPZPKNSBP.get(WhitelistBasedTrustedChannelResolver.DIYKJQSQKV, WhitelistBasedTrustedChannelResolver.PGSZDHAKKA);
        String SBRAVFMDCV = null;
        long XALUJAIZEQ = 0;
        if (ILPZPKNSBP.getBoolean(WhitelistBasedTrustedChannelResolver.BWHLCVSAJI, false)) {
            SBRAVFMDCV = ILPZPKNSBP.get(WhitelistBasedTrustedChannelResolver.WJTWBJESEJ, WhitelistBasedTrustedChannelResolver.DXUHWBFGJG);
            XALUJAIZEQ = ILPZPKNSBP.getLong(WhitelistBasedTrustedChannelResolver.APAPEXTRFM, 3600) * 1000;
        }
        MERTTBNUCN = new CombinedIPWhiteList(LBLYCQZXHX, SBRAVFMDCV, XALUJAIZEQ);
        LBLYCQZXHX = ILPZPKNSBP.get(WhitelistBasedTrustedChannelResolver.CAXYACEHZH, LBLYCQZXHX);
        XALUJAIZEQ = 0;
        if (ILPZPKNSBP.getBoolean(WhitelistBasedTrustedChannelResolver.WEBAMMOXHX, false)) {
            SBRAVFMDCV = ILPZPKNSBP.get(WhitelistBasedTrustedChannelResolver.IRZJYGHKKT, SBRAVFMDCV);
            XALUJAIZEQ = ILPZPKNSBP.getLong(WhitelistBasedTrustedChannelResolver.ZSPLBOAHSW, 3600) * 1000;
        }
        TLIFZXRCWS = new CombinedIPWhiteList(LBLYCQZXHX, SBRAVFMDCV, XALUJAIZEQ);
    }

    public boolean isTrusted() {
        try {
            return TLIFZXRCWS.isIn(InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e) {
            return false;
        }
    }

    public boolean isTrusted(InetAddress ISOLKQFXNN) {
        return MERTTBNUCN.isIn(ISOLKQFXNN.getHostAddress());
    }
}