/**
 * The mutable counter (monotonically increasing) metric interface
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public abstract class MutableCounter extends MutableMetric {
    private final MetricsInfo YWBFVPNEYX;

    protected MutableCounter(MetricsInfo GWPFWBMTMB) {
        this.YWBFVPNEYX = checkNotNull(GWPFWBMTMB, "counter info");
    }

    protected MetricsInfo info() {
        return YWBFVPNEYX;
    }

    /**
     * Increment the metric value by 1.
     */
    public abstract void incr();
}