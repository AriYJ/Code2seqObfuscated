@RunWith(Parameterized.class)
public class TestAMAuthorization {
    private static final Log ZLQHDYFVDP = LogFactory.getLog(TestAMAuthorization.class);

    private final Configuration HDIJJGIVKP;

    private MockRM WJNRLWUADW;

    @Parameters
    public static Collection<Object[]> configs() {
        Configuration FQGEGKMIGU = new Configuration();
        Configuration JUDRFEPGXH = new Configuration();
        JUDRFEPGXH.set(HADOOP_SECURITY_AUTHENTICATION, KERBEROS.toString());
        return Arrays.asList(new Object[][]{ new Object[]{ FQGEGKMIGU }, new Object[]{ JUDRFEPGXH } });
    }

    public TestAMAuthorization(Configuration WHBVNHMOOR) {
        this.HDIJJGIVKP = WHBVNHMOOR;
        UserGroupInformation.setConfiguration(WHBVNHMOOR);
    }

    @After
    public void tearDown() {
        if (WJNRLWUADW != null) {
            WJNRLWUADW.stop();
        }
    }

    public static final class MyContainerManager implements ContainerManagementProtocol {
        public ByteBuffer VWCOUXXGZM;

        public MyContainerManager() {
        }

        @Override
        public StartContainersResponse startContainers(StartContainersRequest request) throws YarnException {
            VWCOUXXGZM = request.getStartContainerRequests().get(0).getContainerLaunchContext().getTokens();
            return StartContainersResponse.newInstance(null, null, null);
        }

        @Override
        public StopContainersResponse stopContainers(StopContainersRequest request) throws YarnException {
            return StopContainersResponse.newInstance(null, null);
        }

        @Override
        public GetContainerStatusesResponse getContainerStatuses(GetContainerStatusesRequest request) throws YarnException {
            return GetContainerStatusesResponse.newInstance(null, null);
        }

        public Credentials getContainerCredentials() throws IOException {
            Credentials credentials = new Credentials();
            DataInputByteBuffer buf = new DataInputByteBuffer();
            VWCOUXXGZM.rewind();
            buf.reset(VWCOUXXGZM);
            credentials.readTokenStorageStream(buf);
            return credentials;
        }
    }

    public static class MockRMWithAMS extends MockRMWithCustomAMLauncher {
        public MockRMWithAMS(Configuration conf, ContainerManagementProtocol containerManager) {
            super(conf, containerManager);
        }

        @Override
        protected void doSecureLogin() throws IOException {
            // Skip the login.
        }

        @Override
        protected ApplicationMasterService createApplicationMasterService() {
            return new ApplicationMasterService(getRMContext(), this.scheduler);
        }

        @SuppressWarnings("unchecked")
        public static Token<? extends TokenIdentifier> setupAndReturnAMRMToken(InetSocketAddress rmBindAddress, Collection<Token<? extends TokenIdentifier>> allTokens) {
            for (Token<? extends TokenIdentifier> token : allTokens) {
                if (token.getKind().equals(KIND_NAME)) {
                    SecurityUtil.setTokenService(token, rmBindAddress);
                    return ((Token<AMRMTokenIdentifier>) (token));
                }
            }
            return null;
        }
    }

    @Test
    public void testAuthorizedAccess() throws Exception {
        TestAMAuthorization.MyContainerManager NTKFWDLAVJ = new TestAMAuthorization.MyContainerManager();
        WJNRLWUADW = new TestAMAuthorization.MockRMWithAMS(HDIJJGIVKP, NTKFWDLAVJ);
        WJNRLWUADW.start();
        MockNM NWHGDTYVSC = WJNRLWUADW.registerNode("localhost:1234", 5120);
        Map<ApplicationAccessType, String> SXFIFTTIRY = new HashMap<ApplicationAccessType, String>(2);
        SXFIFTTIRY.put(VIEW_APP, "*");
        RMApp YUYLCZLDBH = WJNRLWUADW.submitApp(1024, "appname", "appuser", SXFIFTTIRY);
        NWHGDTYVSC.nodeHeartbeat(true);
        int IYIWAQBCAE = 0;
        while ((NTKFWDLAVJ.VWCOUXXGZM == null) && ((IYIWAQBCAE++) < 20)) {
            TestAMAuthorization.ZLQHDYFVDP.info("Waiting for AM Launch to happen..");
            Thread.sleep(1000);
        } 
        Assert.assertNotNull(NTKFWDLAVJ.VWCOUXXGZM);
        RMAppAttempt BYNCXVLINH = YUYLCZLDBH.getCurrentAppAttempt();
        ApplicationAttemptId MGAXHMGFBI = BYNCXVLINH.getAppAttemptId();
        waitForLaunchedState(BYNCXVLINH);
        // Create a client to the RM.
        final Configuration UDQMYZTGXS = WJNRLWUADW.getConfig();
        final YarnRPC IJMPBMSBEI = YarnRPC.create(UDQMYZTGXS);
        UserGroupInformation MMBTFRSAIG = UserGroupInformation.createRemoteUser(MGAXHMGFBI.toString());
        Credentials NQRDKAWSAZ = NTKFWDLAVJ.getContainerCredentials();
        final InetSocketAddress KVWJLLBFYN = WJNRLWUADW.getApplicationMasterService().getBindAddress();
        Token<? extends TokenIdentifier> NSPQHAASLQ = TestAMAuthorization.MockRMWithAMS.setupAndReturnAMRMToken(KVWJLLBFYN, NQRDKAWSAZ.getAllTokens());
        MMBTFRSAIG.addToken(NSPQHAASLQ);
        ApplicationMasterProtocol SAUGRYRSRG = MMBTFRSAIG.doAs(new PrivilegedAction<ApplicationMasterProtocol>() {
            @Override
            public ApplicationMasterProtocol run() {
                return ((ApplicationMasterProtocol) (IJMPBMSBEI.getProxy(ApplicationMasterProtocol.class, WJNRLWUADW.getApplicationMasterService().getBindAddress(), UDQMYZTGXS)));
            }
        });
        RegisterApplicationMasterRequest YUGVVTVPES = Records.newRecord(RegisterApplicationMasterRequest.class);
        RegisterApplicationMasterResponse DHDLFLPKGJ = SAUGRYRSRG.registerApplicationMaster(YUGVVTVPES);
        Assert.assertNotNull(DHDLFLPKGJ.getClientToAMTokenMasterKey());
        if (UserGroupInformation.isSecurityEnabled()) {
            Assert.assertTrue(DHDLFLPKGJ.getClientToAMTokenMasterKey().array().length > 0);
        }
        Assert.assertEquals("Register response has bad ACLs", "*", DHDLFLPKGJ.getApplicationACLs().get(VIEW_APP));
    }

    @Test
    public void testUnauthorizedAccess() throws Exception {
        TestAMAuthorization.MyContainerManager IRBNXQYFNA = new TestAMAuthorization.MyContainerManager();
        WJNRLWUADW = new TestAMAuthorization.MockRMWithAMS(HDIJJGIVKP, IRBNXQYFNA);
        WJNRLWUADW.start();
        MockNM BVJRXZLPZH = WJNRLWUADW.registerNode("localhost:1234", 5120);
        RMApp PNROJRMOPI = WJNRLWUADW.submitApp(1024);
        BVJRXZLPZH.nodeHeartbeat(true);
        int JTZJYKBTYS = 0;
        while ((IRBNXQYFNA.VWCOUXXGZM == null) && ((JTZJYKBTYS++) < 40)) {
            TestAMAuthorization.ZLQHDYFVDP.info("Waiting for AM Launch to happen..");
            Thread.sleep(1000);
        } 
        Assert.assertNotNull(IRBNXQYFNA.VWCOUXXGZM);
        RMAppAttempt SQOHGWWHAJ = PNROJRMOPI.getCurrentAppAttempt();
        ApplicationAttemptId BBSBUPRXYT = SQOHGWWHAJ.getAppAttemptId();
        waitForLaunchedState(SQOHGWWHAJ);
        final Configuration HIJQUTYGAU = WJNRLWUADW.getConfig();
        final YarnRPC GURIZWMBVU = YarnRPC.create(HIJQUTYGAU);
        final InetSocketAddress MHITSYPMOP = HIJQUTYGAU.getSocketAddr(RM_SCHEDULER_ADDRESS, DEFAULT_RM_SCHEDULER_ADDRESS, DEFAULT_RM_SCHEDULER_PORT);
        UserGroupInformation NAIARTTDQL = UserGroupInformation.createRemoteUser(BBSBUPRXYT.toString());
        // First try contacting NM without tokens
        ApplicationMasterProtocol WLJCVQXLQA = NAIARTTDQL.doAs(new PrivilegedAction<ApplicationMasterProtocol>() {
            @Override
            public ApplicationMasterProtocol run() {
                return ((ApplicationMasterProtocol) (GURIZWMBVU.getProxy(ApplicationMasterProtocol.class, MHITSYPMOP, HIJQUTYGAU)));
            }
        });
        RegisterApplicationMasterRequest IZORQBLLTH = Records.newRecord(RegisterApplicationMasterRequest.class);
        try {
            WLJCVQXLQA.registerApplicationMaster(IZORQBLLTH);
            Assert.fail("Should fail with authorization error");
        } catch (Exception e) {
            if (TestAMAuthorization.isCause(AccessControlException.class, e)) {
                // Because there are no tokens, the request should be rejected as the
                // server side will assume we are trying simple auth.
                String USYPFGCBNN = "";
                if (UserGroupInformation.isSecurityEnabled()) {
                    USYPFGCBNN = "Client cannot authenticate via:[TOKEN]";
                } else {
                    USYPFGCBNN = "SIMPLE authentication is not enabled.  Available:[TOKEN]";
                }
                Assert.assertTrue(e.getCause().getMessage().contains(USYPFGCBNN));
            } else {
                throw e;
            }
        }
        // TODO: Add validation of invalid authorization when there's more data in
        // the AMRMToken
    }

    /**
     * Identify if an expected throwable included in an exception stack. We use
     * this because sometimes, an exception will be wrapped to another exception
     * before thrown. Like,
     *
     * <pre>
     * {@code void methodA() throws IOException {
     *   try {
     *     // something} catch (AccessControlException e) {
     *     // do process
     *     throw new IOException(e)
     *   }
     * }
     * </pre>
     *
     * So we cannot simply catch AccessControlException by using
     * <pre>
     * {@code try {
     *   methodA()} catch (AccessControlException e) {
     *   // do something
     * }
     * </pre>
     *
     * This method is useful in such cases.
     */
    private static boolean isCause(Class<? extends Throwable> PXQCSNQWRR, Throwable VMZYSDSOIC) {
        return (VMZYSDSOIC != null) && (PXQCSNQWRR.isInstance(VMZYSDSOIC) || TestAMAuthorization.isCause(PXQCSNQWRR, VMZYSDSOIC.getCause()));
    }

    private void waitForLaunchedState(RMAppAttempt NTZBYYSTSL) throws InterruptedException {
        int XTOUNOZFXD = 0;
        while ((NTZBYYSTSL.getAppAttemptState() != RMAppAttemptState.LAUNCHED) && ((XTOUNOZFXD++) < 40)) {
            TestAMAuthorization.ZLQHDYFVDP.info(("Waiting for AppAttempt to reach LAUNCHED state. " + "Current state is ") + NTZBYYSTSL.getAppAttemptState());
            Thread.sleep(1000);
        } 
        Assert.assertEquals(NTZBYYSTSL.getAppAttemptState(), LAUNCHED);
    }
}