/**
 * Encapsulate a list of {@link IOException} into an {@link IOException}
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class MultipleIOException extends IOException {
    /**
     * Require by {@link java.io.Serializable}
     */
    private static final long PXYIZIXIRE = 1L;

    private final List<IOException> TFIYWYIZPE;

    /**
     * Constructor is private, use {@link #createIOException(List)}.
     */
    private MultipleIOException(List<IOException> HFYDQSVBXQ) {
        super((HFYDQSVBXQ.size() + " exceptions ") + HFYDQSVBXQ);
        this.TFIYWYIZPE = HFYDQSVBXQ;
    }

    /**
     *
     *
     * @return the underlying exceptions
     */
    public List<IOException> getExceptions() {
        return TFIYWYIZPE;
    }

    /**
     * A convenient method to create an {@link IOException}.
     */
    public static IOException createIOException(List<IOException> ZECTGQQFLK) {
        if ((ZECTGQQFLK == null) || ZECTGQQFLK.isEmpty()) {
            return null;
        }
        if (ZECTGQQFLK.size() == 1) {
            return ZECTGQQFLK.get(0);
        }
        return new MultipleIOException(ZECTGQQFLK);
    }
}