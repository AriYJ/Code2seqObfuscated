public class Allocation {
    final List<Container> AMHMOBRYOO;

    final Resource OUIMVXTFNP;

    final Set<ContainerId> AJMSOVJVCG;

    final Set<ContainerId> EWQJABMJLW;

    final List<ResourceRequest> YOTTXEKJTA;

    final List<NMToken> ALVTHQDTNR;

    public Allocation(List<Container> VOHXEDNHYQ, Resource QUNNOZSQOD, Set<ContainerId> CKJLKLAOOX, Set<ContainerId> FDYLOKUEOO, List<ResourceRequest> GLHORJADDL) {
        this(VOHXEDNHYQ, QUNNOZSQOD, CKJLKLAOOX, FDYLOKUEOO, GLHORJADDL, null);
    }

    public Allocation(List<Container> CZKRRFSIWK, Resource OFPLPOOZVV, Set<ContainerId> YTKDJKHFGZ, Set<ContainerId> SUTQMLVZOY, List<ResourceRequest> CLBMRNDBXV, List<NMToken> XMRCWTFVDR) {
        this.AMHMOBRYOO = CZKRRFSIWK;
        this.OUIMVXTFNP = OFPLPOOZVV;
        this.AJMSOVJVCG = YTKDJKHFGZ;
        this.EWQJABMJLW = SUTQMLVZOY;
        this.YOTTXEKJTA = CLBMRNDBXV;
        this.ALVTHQDTNR = XMRCWTFVDR;
    }

    public List<Container> getContainers() {
        return AMHMOBRYOO;
    }

    public Resource getResourceLimit() {
        return OUIMVXTFNP;
    }

    public Set<ContainerId> getStrictContainerPreemptions() {
        return AJMSOVJVCG;
    }

    public Set<ContainerId> getContainerPreemptions() {
        return EWQJABMJLW;
    }

    public List<ResourceRequest> getResourcePreemptions() {
        return YOTTXEKJTA;
    }

    public List<NMToken> getNMTokens() {
        return ALVTHQDTNR;
    }
}