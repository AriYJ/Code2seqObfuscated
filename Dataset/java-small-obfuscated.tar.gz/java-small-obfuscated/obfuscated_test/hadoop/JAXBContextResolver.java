@Singleton
@Provider
public class JAXBContextResolver implements ContextResolver<JAXBContext> {
    private JAXBContext NPSLDUKRLW;

    private final Set<Class> HIBPBWMBQS;

    // you have to specify all the dao classes here
    private final Class[] BCYWAAIJCT = new Class[]{ AppInfo.class, AppAttemptInfo.class, AppAttemptsInfo.class, ClusterInfo.class, CapacitySchedulerQueueInfo.class, FifoSchedulerInfo.class, SchedulerTypeInfo.class, NodeInfo.class, UserMetricsInfo.class, CapacitySchedulerInfo.class, ClusterMetricsInfo.class, SchedulerInfo.class, AppsInfo.class, NodesInfo.class, RemoteExceptionData.class, CapacitySchedulerQueueInfoList.class, ResourceInfo.class, UsersInfo.class, UserInfo.class, ApplicationStatisticsInfo.class, StatisticsItemInfo.class };

    public JAXBContextResolver() throws Exception {
        this.HIBPBWMBQS = new HashSet<Class>(Arrays.asList(BCYWAAIJCT));
        this.NPSLDUKRLW = new com.sun.jersey.api.json.JSONJAXBContext(com.sun.jersey.api.json.JSONConfiguration.natural().rootUnwrapping(false).build(), BCYWAAIJCT);
    }

    @Override
    public JAXBContext getContext(Class<?> TXQKJGNIHG) {
        return HIBPBWMBQS.contains(TXQKJGNIHG) ? NPSLDUKRLW : null;
    }
}