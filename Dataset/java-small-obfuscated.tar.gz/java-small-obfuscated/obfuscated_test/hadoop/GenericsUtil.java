/**
 * Contains utility methods for dealing with Java Generics.
 */
@InterfaceAudience.Private
@InterfaceStability.Unstable
public class GenericsUtil {
    /**
     * Returns the Class object (of type <code>Class&lt;T&gt;</code>) of the
     * argument of type <code>T</code>.
     *
     * @param <T>
     * 		The type of the argument
     * @param t
     * 		the object to get it class
     * @return <code>Class&lt;T&gt;</code>
     */
    public static <T> Class<T> getClass(T QZNFMFRYHU) {
        @SuppressWarnings("unchecked")
        Class<T> NDVRNZVGOF = ((Class<T>) (QZNFMFRYHU.getClass()));
        return NDVRNZVGOF;
    }

    /**
     * Converts the given <code>List&lt;T&gt;</code> to a an array of
     * <code>T[]</code>.
     *
     * @param c
     * 		the Class object of the items in the list
     * @param list
     * 		the list to convert
     */
    public static <T> T[] toArray(Class<T> GMKDIUUYGU, List<T> EOVXPVURME) {
        @SuppressWarnings("unchecked")
        T[] ANXUSDAMCT = ((T[]) (Array.newInstance(GMKDIUUYGU, EOVXPVURME.size())));
        for (int AJHXPHGQZN = 0; AJHXPHGQZN < EOVXPVURME.size(); AJHXPHGQZN++)
            ANXUSDAMCT[AJHXPHGQZN] = EOVXPVURME.get(AJHXPHGQZN);

        return ANXUSDAMCT;
    }

    /**
     * Converts the given <code>List&lt;T&gt;</code> to a an array of
     * <code>T[]</code>.
     *
     * @param list
     * 		the list to convert
     * @throws ArrayIndexOutOfBoundsException
     * 		if the list is empty.
     * 		Use {@link #toArray(Class, List)} if the list may be empty.
     */
    public static <T> T[] toArray(List<T> HRLXLIVHZT) {
        return GenericsUtil.toArray(GenericsUtil.getClass(HRLXLIVHZT.get(0)), HRLXLIVHZT);
    }
}