/**
 * Balancing policy.
 * Since a datanode may contain multiple block pools,
 * {@link Pool} implies {@link Node}
 * but NOT the other way around
 */
@InterfaceAudience.Private
abstract class BalancingPolicy {
    final EnumCounters<StorageType> UTQKRVOVSJ = new EnumCounters<StorageType>(StorageType.class);

    final EnumCounters<StorageType> TAEMMJGAJX = new EnumCounters<StorageType>(StorageType.class);

    final EnumDoubles<StorageType> YJCVPOZBWI = new EnumDoubles<StorageType>(StorageType.class);

    void reset() {
        UTQKRVOVSJ.reset();
        TAEMMJGAJX.reset();
        YJCVPOZBWI.reset();
    }

    /**
     * Get the policy name.
     */
    abstract String getName();

    /**
     * Accumulate used space and capacity.
     */
    abstract void accumulateSpaces(DatanodeStorageReport WZWGBQQPAG);

    void initAvgUtilization() {
        for (StorageType LCILIVBGKM : StorageType.asList()) {
            final long RQHKAHHORS = UTQKRVOVSJ.get(LCILIVBGKM);
            if (RQHKAHHORS > 0L) {
                final double BDAEESCRKS = (TAEMMJGAJX.get(LCILIVBGKM) * 100.0) / RQHKAHHORS;
                YJCVPOZBWI.set(LCILIVBGKM, BDAEESCRKS);
            }
        }
    }

    double getAvgUtilization(StorageType URROWPEZXN) {
        return YJCVPOZBWI.get(URROWPEZXN);
    }

    /**
     *
     *
     * @return the utilization of a particular storage type of a datanode;
    or return null if the datanode does not have such storage type.
     */
    abstract Double getUtilization(DatanodeStorageReport BMBXSATVBO, StorageType HDVRRAZFAH);

    @Override
    public String toString() {
        return (BalancingPolicy.class.getSimpleName() + ".") + getClass().getSimpleName();
    }

    /**
     * Get all {@link BalancingPolicy} instances
     */
    static BalancingPolicy parse(String VUCPBSLYLR) {
        final BalancingPolicy[] OBTSMFODUN = new BalancingPolicy[]{ BalancingPolicy.Node.WYNRCXHMUA, BalancingPolicy.Pool.GSEGMHSNIB };
        for (BalancingPolicy XKPLIRVNDI : OBTSMFODUN) {
            if (XKPLIRVNDI.getName().equalsIgnoreCase(VUCPBSLYLR))
                return XKPLIRVNDI;

        }
        throw new IllegalArgumentException(("Cannot parse string \"" + VUCPBSLYLR) + "\"");
    }

    /**
     * Cluster is balanced if each node is balanced.
     */
    static class Node extends BalancingPolicy {
        static final BalancingPolicy.Node WYNRCXHMUA = new BalancingPolicy.Node();

        private Node() {
        }

        @Override
        String getName() {
            return "datanode";
        }

        @Override
        void accumulateSpaces(DatanodeStorageReport r) {
            for (StorageReport s : r.getStorageReports()) {
                final StorageType t = s.getStorage().getStorageType();
                UTQKRVOVSJ.add(t, s.getCapacity());
                TAEMMJGAJX.add(t, s.getDfsUsed());
            }
        }

        @Override
        Double getUtilization(DatanodeStorageReport r, final StorageType t) {
            long capacity = 0L;
            long dfsUsed = 0L;
            for (StorageReport s : r.getStorageReports()) {
                if (s.getStorage().getStorageType() == t) {
                    capacity += s.getCapacity();
                    dfsUsed += s.getDfsUsed();
                }
            }
            return capacity == 0L ? null : (dfsUsed * 100.0) / capacity;
        }
    }

    /**
     * Cluster is balanced if each pool in each node is balanced.
     */
    static class Pool extends BalancingPolicy {
        static final BalancingPolicy.Pool GSEGMHSNIB = new BalancingPolicy.Pool();

        private Pool() {
        }

        @Override
        String getName() {
            return "blockpool";
        }

        @Override
        void accumulateSpaces(DatanodeStorageReport r) {
            for (StorageReport s : r.getStorageReports()) {
                final StorageType t = s.getStorage().getStorageType();
                UTQKRVOVSJ.add(t, s.getCapacity());
                TAEMMJGAJX.add(t, s.getBlockPoolUsed());
            }
        }

        @Override
        Double getUtilization(DatanodeStorageReport r, final StorageType t) {
            long capacity = 0L;
            long blockPoolUsed = 0L;
            for (StorageReport s : r.getStorageReports()) {
                if (s.getStorage().getStorageType() == t) {
                    capacity += s.getCapacity();
                    blockPoolUsed += s.getBlockPoolUsed();
                }
            }
            return capacity == 0L ? null : (blockPoolUsed * 100.0) / capacity;
        }
    }
}