/**
 * <p>Partition {@link BinaryComparable} keys using a configurable part of
 * the bytes array returned by {@link BinaryComparable#getBytes()}.</p>
 *
 * <p>The subarray to be used for the partitioning can be defined by means
 * of the following properties:
 * <ul>
 *   <li>
 *     <i>mapreduce.partition.binarypartitioner.left.offset</i>:
 *     left offset in array (0 by default)
 *   </li>
 *   <li>
 *     <i>mapreduce.partition.binarypartitioner.right.offset</i>:
 *     right offset in array (-1 by default)
 *   </li>
 * </ul>
 * Like in Python, both negative and positive offsets are allowed, but
 * the meaning is slightly different. In case of an array of length 5,
 * for instance, the possible offsets are:
 * <pre><code>
 *  +---+---+---+---+---+
 *  | B | B | B | B | B |
 *  +---+---+---+---+---+
 *    0   1   2   3   4
 *   -5  -4  -3  -2  -1
 * </code></pre>
 * The first row of numbers gives the position of the offsets 0...5 in
 * the array; the second row gives the corresponding negative offsets.
 * Contrary to Python, the specified subarray has byte <code>i</code>
 * and <code>j</code> as first and last element, repectively, when
 * <code>i</code> and <code>j</code> are the left and right offset.
 *
 * <p>For Hadoop programs written in Java, it is advisable to use one of
 * the following static convenience methods for setting the offsets:
 * <ul>
 *   <li>{@link #setOffsets}</li>
 *   <li>{@link #setLeftOffset}</li>
 *   <li>{@link #setRightOffset}</li>
 * </ul></p>
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class BinaryPartitioner<V> extends Partitioner<BinaryComparable, V> implements Configurable {
    public static final String WXYFNIIIUJ = "mapreduce.partition.binarypartitioner.left.offset";

    public static final String YOAINSRAYJ = "mapreduce.partition.binarypartitioner.right.offset";

    /**
     * Set the subarray to be used for partitioning to
     * <code>bytes[left:(right+1)]</code> in Python syntax.
     *
     * @param conf
     * 		configuration object
     * @param left
     * 		left Python-style offset
     * @param right
     * 		right Python-style offset
     */
    public static void setOffsets(Configuration KMCZOCSLUS, int EVKVMVPNUE, int KRPYSYFMNF) {
        KMCZOCSLUS.setInt(BinaryPartitioner.WXYFNIIIUJ, EVKVMVPNUE);
        KMCZOCSLUS.setInt(BinaryPartitioner.YOAINSRAYJ, KRPYSYFMNF);
    }

    /**
     * Set the subarray to be used for partitioning to
     * <code>bytes[offset:]</code> in Python syntax.
     *
     * @param conf
     * 		configuration object
     * @param offset
     * 		left Python-style offset
     */
    public static void setLeftOffset(Configuration LCYMGZAFSH, int BGSPUZYOKK) {
        LCYMGZAFSH.setInt(BinaryPartitioner.WXYFNIIIUJ, BGSPUZYOKK);
    }

    /**
     * Set the subarray to be used for partitioning to
     * <code>bytes[:(offset+1)]</code> in Python syntax.
     *
     * @param conf
     * 		configuration object
     * @param offset
     * 		right Python-style offset
     */
    public static void setRightOffset(Configuration HLMOVEAFBA, int CFYTPTTCSC) {
        HLMOVEAFBA.setInt(BinaryPartitioner.YOAINSRAYJ, CFYTPTTCSC);
    }

    private Configuration HONBXUUJFU;

    private int QGIHTLDMOV;

    private int AJUANGWJCW;

    public void setConf(Configuration OVPUCYPMDM) {
        this.conf = OVPUCYPMDM;
        QGIHTLDMOV = OVPUCYPMDM.getInt(BinaryPartitioner.WXYFNIIIUJ, 0);
        AJUANGWJCW = OVPUCYPMDM.getInt(BinaryPartitioner.YOAINSRAYJ, -1);
    }

    public Configuration getConf() {
        return HONBXUUJFU;
    }

    /**
     * Use (the specified slice of the array returned by)
     * {@link BinaryComparable#getBytes()} to partition.
     */
    @Override
    public int getPartition(BinaryComparable LUJOBEMDML, V OQFDXWRMSL, int PEOZZSNQGE) {
        int JNNMNVNLJB = LUJOBEMDML.getLength();
        int SMEDTTKKPZ = (QGIHTLDMOV + JNNMNVNLJB) % JNNMNVNLJB;
        int XNSVEPMXII = (AJUANGWJCW + JNNMNVNLJB) % JNNMNVNLJB;
        int ABHVWIWYYS = WritableComparator.hashBytes(LUJOBEMDML.getBytes(), SMEDTTKKPZ, (XNSVEPMXII - SMEDTTKKPZ) + 1);
        return (ABHVWIWYYS & Integer.MAX_VALUE) % PEOZZSNQGE;
    }
}