public class WritingApplicationHistoryEvent extends AbstractEvent<WritingHistoryEventType> {
    public WritingApplicationHistoryEvent(WritingHistoryEventType LLVOKDHFFV) {
        super(LLVOKDHFFV);
    }
}