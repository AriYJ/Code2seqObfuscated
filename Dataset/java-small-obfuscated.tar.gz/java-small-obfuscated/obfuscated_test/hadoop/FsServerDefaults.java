/**
 * **************************************************
 * Provides server default configuration values to clients.
 *
 * **************************************************
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class FsServerDefaults implements Writable {
    static {
        // register a ctor
        WritableFactories.setFactory(FsServerDefaults.class, new WritableFactory() {
            @Override
            public Writable newInstance() {
                return new FsServerDefaults();
            }
        });
    }

    private long LZSXMYPZGL;

    private int KFPHJMDLEY;

    private int BXXBMJQGTM;

    private short XBLBQQZWPU;

    private int BXXAACQIRO;

    private boolean CYROPYQUJM;

    private long BZTOEEZKWW;

    private Type XTMGATEVQU;

    public FsServerDefaults() {
    }

    public FsServerDefaults(long CAXMTIROWX, int YBPIKZWFQA, int XPGTYCQHXQ, short VNPHPYHPHY, int SLEXZOFUQB, boolean FNHDLUIPON, long JJUXSFBPCB, DataChecksum.Type IFLEADMYNU) {
        this.LZSXMYPZGL = CAXMTIROWX;
        this.KFPHJMDLEY = YBPIKZWFQA;
        this.BXXBMJQGTM = XPGTYCQHXQ;
        this.XBLBQQZWPU = VNPHPYHPHY;
        this.BXXAACQIRO = SLEXZOFUQB;
        this.CYROPYQUJM = FNHDLUIPON;
        this.BZTOEEZKWW = JJUXSFBPCB;
        this.XTMGATEVQU = IFLEADMYNU;
    }

    public long getBlockSize() {
        return LZSXMYPZGL;
    }

    public int getBytesPerChecksum() {
        return KFPHJMDLEY;
    }

    public int getWritePacketSize() {
        return BXXBMJQGTM;
    }

    public short getReplication() {
        return XBLBQQZWPU;
    }

    public int getFileBufferSize() {
        return BXXAACQIRO;
    }

    public boolean getEncryptDataTransfer() {
        return CYROPYQUJM;
    }

    public long getTrashInterval() {
        return BZTOEEZKWW;
    }

    public Type getChecksumType() {
        return XTMGATEVQU;
    }

    // /////////////////////////////////////////
    // Writable
    // /////////////////////////////////////////
    @Override
    @InterfaceAudience.Private
    public void write(DataOutput LMSWSXOQHX) throws IOException {
        LMSWSXOQHX.writeLong(LZSXMYPZGL);
        LMSWSXOQHX.writeInt(KFPHJMDLEY);
        LMSWSXOQHX.writeInt(BXXBMJQGTM);
        LMSWSXOQHX.writeShort(XBLBQQZWPU);
        LMSWSXOQHX.writeInt(BXXAACQIRO);
        WritableUtils.writeEnum(LMSWSXOQHX, XTMGATEVQU);
    }

    @Override
    @InterfaceAudience.Private
    public void readFields(DataInput AEFLWJDJXR) throws IOException {
        LZSXMYPZGL = AEFLWJDJXR.readLong();
        KFPHJMDLEY = AEFLWJDJXR.readInt();
        BXXBMJQGTM = AEFLWJDJXR.readInt();
        XBLBQQZWPU = AEFLWJDJXR.readShort();
        BXXAACQIRO = AEFLWJDJXR.readInt();
        XTMGATEVQU = WritableUtils.readEnum(AEFLWJDJXR, Type.class);
    }
}