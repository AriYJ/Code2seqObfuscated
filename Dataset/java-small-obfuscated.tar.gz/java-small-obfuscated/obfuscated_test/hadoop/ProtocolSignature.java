public class ProtocolSignature implements Writable {
    static {
        // register a ctor
        WritableFactories.setFactory(ProtocolSignature.class, new WritableFactory() {
            @Override
            public Writable newInstance() {
                return new ProtocolSignature();
            }
        });
    }

    private long QWGBTJBHYR;

    private int[] AFQQJXOUQY = null;// an array of method hash codes


    /**
     * default constructor
     */
    public ProtocolSignature() {
    }

    /**
     * Constructor
     *
     * @param version
     * 		server version
     * @param methodHashcodes
     * 		hash codes of the methods supported by server
     */
    public ProtocolSignature(long KMUACQNMEQ, int[] BCVYURGHMX) {
        this.QWGBTJBHYR = KMUACQNMEQ;
        this.AFQQJXOUQY = BCVYURGHMX;
    }

    public long getVersion() {
        return QWGBTJBHYR;
    }

    public int[] getMethods() {
        return AFQQJXOUQY;
    }

    @Override
    public void readFields(DataInput QHMNNYLZJA) throws IOException {
        QWGBTJBHYR = QHMNNYLZJA.readLong();
        boolean KHAHYVFKRI = QHMNNYLZJA.readBoolean();
        if (KHAHYVFKRI) {
            int EYQWGXBFUA = QHMNNYLZJA.readInt();
            AFQQJXOUQY = new int[EYQWGXBFUA];
            for (int OWIVLIWVOV = 0; OWIVLIWVOV < EYQWGXBFUA; OWIVLIWVOV++) {
                AFQQJXOUQY[OWIVLIWVOV] = QHMNNYLZJA.readInt();
            }
        }
    }

    @Override
    public void write(DataOutput YNLDGZXVBC) throws IOException {
        YNLDGZXVBC.writeLong(QWGBTJBHYR);
        if (AFQQJXOUQY == null) {
            YNLDGZXVBC.writeBoolean(false);
        } else {
            YNLDGZXVBC.writeBoolean(true);
            YNLDGZXVBC.writeInt(AFQQJXOUQY.length);
            for (int ZJHMLLITJK : AFQQJXOUQY) {
                YNLDGZXVBC.writeInt(ZJHMLLITJK);
            }
        }
    }

    /**
     * Calculate a method's hash code considering its method
     * name, returning type, and its parameter types
     *
     * @param method
     * 		a method
     * @return its hash code
     */
    static int getFingerprint(Method UMLNDLTYTX) {
        int BGBHEDFKAU = UMLNDLTYTX.getName().hashCode();
        BGBHEDFKAU = BGBHEDFKAU + (31 * UMLNDLTYTX.getReturnType().getName().hashCode());
        for (Class<?> VUEVUULPYX : UMLNDLTYTX.getParameterTypes()) {
            BGBHEDFKAU = (31 * BGBHEDFKAU) ^ VUEVUULPYX.getName().hashCode();
        }
        return BGBHEDFKAU;
    }

    /**
     * Convert an array of Method into an array of hash codes
     *
     * @param methods
     * 		
     * @return array of hash codes
     */
    private static int[] getFingerprints(Method[] IUNORQDPJM) {
        if (IUNORQDPJM == null) {
            return null;
        }
        int[] BPOFWCYRVM = new int[IUNORQDPJM.length];
        for (int UXHALYJPOR = 0; UXHALYJPOR < IUNORQDPJM.length; UXHALYJPOR++) {
            BPOFWCYRVM[UXHALYJPOR] = ProtocolSignature.getFingerprint(IUNORQDPJM[UXHALYJPOR]);
        }
        return BPOFWCYRVM;
    }

    /**
     * Get the hash code of an array of methods
     * Methods are sorted before hashcode is calculated.
     * So the returned value is irrelevant of the method order in the array.
     *
     * @param methods
     * 		an array of methods
     * @return the hash code
     */
    static int getFingerprint(Method[] FXWVTDPYZO) {
        return ProtocolSignature.getFingerprint(ProtocolSignature.getFingerprints(FXWVTDPYZO));
    }

    /**
     * Get the hash code of an array of hashcodes
     * Hashcodes are sorted before hashcode is calculated.
     * So the returned value is irrelevant of the hashcode order in the array.
     *
     * @param methods
     * 		an array of methods
     * @return the hash code
     */
    static int getFingerprint(int[] GTURZMTMJA) {
        Arrays.sort(GTURZMTMJA);
        return Arrays.hashCode(GTURZMTMJA);
    }

    private static class ProtocolSigFingerprint {
        private ProtocolSignature BHHCYUQHVO;

        private int AIZLOWZSCS;

        ProtocolSigFingerprint(ProtocolSignature sig, int fingerprint) {
            this.BHHCYUQHVO = sig;
            this.AIZLOWZSCS = fingerprint;
        }
    }

    /**
     * A cache that maps a protocol's name to its signature & finger print
     */
    private static final HashMap<String, ProtocolSignature.ProtocolSigFingerprint> SUYFRHLTYS = new HashMap<String, ProtocolSignature.ProtocolSigFingerprint>();

    @VisibleForTesting
    public static void resetCache() {
        ProtocolSignature.SUYFRHLTYS.clear();
    }

    /**
     * Return a protocol's signature and finger print from cache
     *
     * @param protocol
     * 		a protocol class
     * @param serverVersion
     * 		protocol version
     * @return its signature and finger print
     */
    private static ProtocolSignature.ProtocolSigFingerprint getSigFingerprint(Class<?> PVAQNDITPA, long HGOASSVJAN) {
        String AXVGXRXXXZ = RPC.getProtocolName(PVAQNDITPA);
        synchronized(ProtocolSignature.SUYFRHLTYS) {
            ProtocolSignature.ProtocolSigFingerprint WMRQVFVTRM = ProtocolSignature.SUYFRHLTYS.get(AXVGXRXXXZ);
            if (WMRQVFVTRM == null) {
                int[] DNQEIGVSWW = ProtocolSignature.getFingerprints(PVAQNDITPA.getMethods());
                WMRQVFVTRM = new ProtocolSignature.ProtocolSigFingerprint(new ProtocolSignature(HGOASSVJAN, DNQEIGVSWW), ProtocolSignature.getFingerprint(DNQEIGVSWW));
                ProtocolSignature.SUYFRHLTYS.put(AXVGXRXXXZ, WMRQVFVTRM);
            }
            return WMRQVFVTRM;
        }
    }

    /**
     * Get a server protocol's signature
     *
     * @param clientMethodsHashCode
     * 		client protocol methods hashcode
     * @param serverVersion
     * 		server protocol version
     * @param protocol
     * 		protocol
     * @return the server's protocol signature
     */
    public static ProtocolSignature getProtocolSignature(int RIWBNZYNGQ, long LLXQCNXDIT, Class<? extends VersionedProtocol> BFOSBWCDXP) {
        // try to get the finger print & signature from the cache
        ProtocolSignature.ProtocolSigFingerprint WQLDBUSRDR = ProtocolSignature.getSigFingerprint(BFOSBWCDXP, LLXQCNXDIT);
        // check if the client side protocol matches the one on the server side
        if (RIWBNZYNGQ == WQLDBUSRDR.AIZLOWZSCS) {
            return new ProtocolSignature(LLXQCNXDIT, null);// null indicates a match

        }
        return WQLDBUSRDR.BHHCYUQHVO;
    }

    public static ProtocolSignature getProtocolSignature(String UHMKVQRUNO, long RRXGHLUEPW) throws ClassNotFoundException {
        Class<?> UEEHVJPRKZ = Class.forName(UHMKVQRUNO);
        return ProtocolSignature.getSigFingerprint(UEEHVJPRKZ, RRXGHLUEPW).BHHCYUQHVO;
    }

    /**
     * Get a server protocol's signature
     *
     * @param server
     * 		server implementation
     * @param protocol
     * 		server protocol
     * @param clientVersion
     * 		client's version
     * @param clientMethodsHash
     * 		client's protocol's hash code
     * @return the server protocol's signature
     * @throws IOException
     * 		if any error occurs
     */
    @SuppressWarnings("unchecked")
    public static ProtocolSignature getProtocolSignature(VersionedProtocol OQGQXRXXJH, String JUOONYQXPJ, long QXEEHDTDOU, int HPVGZTZSEI) throws IOException {
        Class<? extends VersionedProtocol> RUSTNRDZQQ;
        try {
            RUSTNRDZQQ = ((Class<? extends VersionedProtocol>) (Class.forName(JUOONYQXPJ)));
        } catch (Exception e) {
            throw new IOException(e);
        }
        long VXAPYMHIDO = OQGQXRXXJH.getProtocolVersion(JUOONYQXPJ, QXEEHDTDOU);
        return ProtocolSignature.getProtocolSignature(HPVGZTZSEI, VXAPYMHIDO, RUSTNRDZQQ);
    }
}