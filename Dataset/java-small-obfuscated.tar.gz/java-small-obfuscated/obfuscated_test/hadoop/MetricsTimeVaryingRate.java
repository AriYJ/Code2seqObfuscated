/**
 * The MetricsTimeVaryingRate class is for a rate based metric that
 * naturally varies over time (e.g. time taken to create a file).
 * The rate is averaged at each interval heart beat (the interval
 * is set in the metrics config file).
 * This class also keeps track of the min and max rates along with
 * a method to reset the min-max.
 */
@InterfaceAudience.LimitedPrivate({ "HDFS", "MapReduce" })
public class MetricsTimeVaryingRate extends MetricsBase {
    private static final Log IOQLPXNGGS = LogFactory.getLog("org.apache.hadoop.metrics.util");

    static class Metrics {
        int NQPERBADIQ = 0;

        long OQAHJEEOQE = 0;// total time or average time


        void set(final MetricsTimeVaryingRate.Metrics resetTo) {
            NQPERBADIQ = resetTo.NQPERBADIQ;
            OQAHJEEOQE = resetTo.OQAHJEEOQE;
        }

        void reset() {
            NQPERBADIQ = 0;
            OQAHJEEOQE = 0;
        }
    }

    static class MinMax {
        long OXGKUWJWNB = -1;

        long SWSKXWKDKQ = 0;

        void set(final MetricsTimeVaryingRate.MinMax newVal) {
            OXGKUWJWNB = newVal.OXGKUWJWNB;
            SWSKXWKDKQ = newVal.SWSKXWKDKQ;
        }

        void reset() {
            OXGKUWJWNB = -1;
            SWSKXWKDKQ = 0;
        }

        void update(final long time) {
            // update min max
            OXGKUWJWNB = (OXGKUWJWNB == (-1)) ? time : Math.min(OXGKUWJWNB, time);
            OXGKUWJWNB = Math.min(OXGKUWJWNB, time);
            SWSKXWKDKQ = Math.max(SWSKXWKDKQ, time);
        }
    }

    private MetricsTimeVaryingRate.Metrics SLKNFKNIGZ;

    private MetricsTimeVaryingRate.Metrics BRHPUBHYEK;

    private MetricsTimeVaryingRate.MinMax MSOLSANKTS;

    /**
     * Constructor - create a new metric
     *
     * @param nam
     * 		the name of the metrics to be used to publish the metric
     * @param registry
     * 		- where the metrics object will be registered
     */
    public MetricsTimeVaryingRate(final String RGMOYOTIPH, final MetricsRegistry MKQXDNRLSE, final String UBXWXIBPLX) {
        super(RGMOYOTIPH, UBXWXIBPLX);
        SLKNFKNIGZ = new MetricsTimeVaryingRate.Metrics();
        BRHPUBHYEK = new MetricsTimeVaryingRate.Metrics();
        MSOLSANKTS = new MetricsTimeVaryingRate.MinMax();
        MKQXDNRLSE.add(RGMOYOTIPH, this);
    }

    /**
     * Constructor - create a new metric
     *
     * @param nam
     * 		the name of the metrics to be used to publish the metric
     * @param registry
     * 		- where the metrics object will be registered
     * 		A description of {@link #NO_DESCRIPTION} is used
     */
    public MetricsTimeVaryingRate(final String HZSWEXSMHR, MetricsRegistry YGZURMVQHP) {
        this(HZSWEXSMHR, YGZURMVQHP, NO_DESCRIPTION);
    }

    /**
     * Increment the metrics for numOps operations
     *
     * @param numOps
     * 		- number of operations
     * @param time
     * 		- time for numOps operations
     */
    public synchronized void inc(final int XRQQEIGFYN, final long AQNTJLSCBO) {
        SLKNFKNIGZ.NQPERBADIQ += XRQQEIGFYN;
        SLKNFKNIGZ.OQAHJEEOQE += AQNTJLSCBO;
        long AJBAOBJMUZ = AQNTJLSCBO / XRQQEIGFYN;
        MSOLSANKTS.update(AJBAOBJMUZ);
    }

    /**
     * Increment the metrics for one operation
     *
     * @param time
     * 		for one operation
     */
    public synchronized void inc(final long NQXFAIRTDZ) {
        SLKNFKNIGZ.NQPERBADIQ++;
        SLKNFKNIGZ.OQAHJEEOQE += NQXFAIRTDZ;
        MSOLSANKTS.update(NQXFAIRTDZ);
    }

    private synchronized void intervalHeartBeat() {
        BRHPUBHYEK.NQPERBADIQ = SLKNFKNIGZ.NQPERBADIQ;
        BRHPUBHYEK.OQAHJEEOQE = (SLKNFKNIGZ.NQPERBADIQ == 0) ? 0 : SLKNFKNIGZ.OQAHJEEOQE / SLKNFKNIGZ.NQPERBADIQ;
        SLKNFKNIGZ.reset();
    }

    /**
     * Push the delta  metrics to the mr.
     * The delta is since the last push/interval.
     *
     * Note this does NOT push to JMX
     * (JMX gets the info via {@link #getPreviousIntervalAverageTime()} and
     * {@link #getPreviousIntervalNumOps()}
     *
     * @param mr
     * 		
     */
    @Override
    public synchronized void pushMetric(final MetricsRecord LCPFLJJGWO) {
        intervalHeartBeat();
        try {
            LCPFLJJGWO.incrMetric(getName() + "_num_ops", getPreviousIntervalNumOps());
            LCPFLJJGWO.setMetric(getName() + "_avg_time", getPreviousIntervalAverageTime());
        } catch (Exception e) {
            MetricsTimeVaryingRate.IOQLPXNGGS.info(("pushMetric failed for " + getName()) + "\n", e);
        }
    }

    /**
     * The number of operations in the previous interval
     *
     * @return - ops in prev interval
     */
    public synchronized int getPreviousIntervalNumOps() {
        return BRHPUBHYEK.NQPERBADIQ;
    }

    /**
     * The average rate of an operation in the previous interval
     *
     * @return - the average rate.
     */
    public synchronized long getPreviousIntervalAverageTime() {
        return BRHPUBHYEK.OQAHJEEOQE;
    }

    /**
     * The min time for a single operation since the last reset
     *  {@link #resetMinMax()}
     *
     * @return min time for an operation
     */
    public synchronized long getMinTime() {
        return MSOLSANKTS.OXGKUWJWNB;
    }

    /**
     * The max time for a single operation since the last reset
     *  {@link #resetMinMax()}
     *
     * @return max time for an operation
     */
    public synchronized long getMaxTime() {
        return MSOLSANKTS.SWSKXWKDKQ;
    }

    /**
     * Reset the min max values
     */
    public synchronized void resetMinMax() {
        MSOLSANKTS.reset();
    }
}