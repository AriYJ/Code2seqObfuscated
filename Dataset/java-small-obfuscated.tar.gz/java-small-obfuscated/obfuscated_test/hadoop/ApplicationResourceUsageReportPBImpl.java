@Private
@Unstable
public class ApplicationResourceUsageReportPBImpl extends ApplicationResourceUsageReport {
    ApplicationResourceUsageReportProto WCWREVHFKN = ApplicationResourceUsageReportProto.getDefaultInstance();

    Builder RDKBKNCBAP = null;

    boolean VEODFNKNHZ = false;

    Resource RENUUIYACM;

    Resource TBCBNPAXAZ;

    Resource HULBODTAHL;

    public ApplicationResourceUsageReportPBImpl() {
        RDKBKNCBAP = ApplicationResourceUsageReportProto.newBuilder();
    }

    public ApplicationResourceUsageReportPBImpl(ApplicationResourceUsageReportProto XIYAOJASRO) {
        this.WCWREVHFKN = XIYAOJASRO;
        VEODFNKNHZ = true;
    }

    public synchronized ApplicationResourceUsageReportProto getProto() {
        mergeLocalToProto();
        WCWREVHFKN = (VEODFNKNHZ) ? WCWREVHFKN : RDKBKNCBAP.build();
        VEODFNKNHZ = true;
        return WCWREVHFKN;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object QECRVEHHNG) {
        if (QECRVEHHNG == null)
            return false;

        if (QECRVEHHNG.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(QECRVEHHNG).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }

    private void mergeLocalToBuilder() {
        if ((this.RENUUIYACM != null) && (!((ResourcePBImpl) (this.RENUUIYACM)).getProto().equals(RDKBKNCBAP.getUsedResources()))) {
            RDKBKNCBAP.setUsedResources(convertToProtoFormat(this.RENUUIYACM));
        }
        if ((this.TBCBNPAXAZ != null) && (!((ResourcePBImpl) (this.TBCBNPAXAZ)).getProto().equals(RDKBKNCBAP.getReservedResources()))) {
            RDKBKNCBAP.setReservedResources(convertToProtoFormat(this.TBCBNPAXAZ));
        }
        if ((this.HULBODTAHL != null) && (!((ResourcePBImpl) (this.HULBODTAHL)).getProto().equals(RDKBKNCBAP.getNeededResources()))) {
            RDKBKNCBAP.setNeededResources(convertToProtoFormat(this.HULBODTAHL));
        }
    }

    private void mergeLocalToProto() {
        if (VEODFNKNHZ)
            maybeInitBuilder();

        mergeLocalToBuilder();
        WCWREVHFKN = RDKBKNCBAP.build();
        VEODFNKNHZ = true;
    }

    private synchronized void maybeInitBuilder() {
        if (VEODFNKNHZ || (RDKBKNCBAP == null)) {
            RDKBKNCBAP = ApplicationResourceUsageReportProto.newBuilder(WCWREVHFKN);
        }
        VEODFNKNHZ = false;
    }

    @Override
    public synchronized int getNumUsedContainers() {
        ApplicationResourceUsageReportProtoOrBuilder PADTIFENZI = (VEODFNKNHZ) ? WCWREVHFKN : RDKBKNCBAP;
        return PADTIFENZI.getNumUsedContainers();
    }

    @Override
    public synchronized void setNumUsedContainers(int VESYCWTZVR) {
        maybeInitBuilder();
        RDKBKNCBAP.setNumUsedContainers(VESYCWTZVR);
    }

    @Override
    public synchronized int getNumReservedContainers() {
        ApplicationResourceUsageReportProtoOrBuilder LFLLLXWBAR = (VEODFNKNHZ) ? WCWREVHFKN : RDKBKNCBAP;
        return LFLLLXWBAR.getNumReservedContainers();
    }

    @Override
    public synchronized void setNumReservedContainers(int RUJSLZJZKH) {
        maybeInitBuilder();
        RDKBKNCBAP.setNumReservedContainers(RUJSLZJZKH);
    }

    @Override
    public synchronized Resource getUsedResources() {
        ApplicationResourceUsageReportProtoOrBuilder QHQSTHZZGB = (VEODFNKNHZ) ? WCWREVHFKN : RDKBKNCBAP;
        if (this.RENUUIYACM != null) {
            return this.RENUUIYACM;
        }
        if (!QHQSTHZZGB.hasUsedResources()) {
            return null;
        }
        this.RENUUIYACM = convertFromProtoFormat(QHQSTHZZGB.getUsedResources());
        return this.RENUUIYACM;
    }

    @Override
    public synchronized void setUsedResources(Resource XXLVEFOGCE) {
        maybeInitBuilder();
        if (XXLVEFOGCE == null)
            RDKBKNCBAP.clearUsedResources();

        this.RENUUIYACM = XXLVEFOGCE;
    }

    @Override
    public synchronized Resource getReservedResources() {
        ApplicationResourceUsageReportProtoOrBuilder WATNPJBKGA = (VEODFNKNHZ) ? WCWREVHFKN : RDKBKNCBAP;
        if (this.TBCBNPAXAZ != null) {
            return this.TBCBNPAXAZ;
        }
        if (!WATNPJBKGA.hasReservedResources()) {
            return null;
        }
        this.TBCBNPAXAZ = convertFromProtoFormat(WATNPJBKGA.getReservedResources());
        return this.TBCBNPAXAZ;
    }

    @Override
    public synchronized void setReservedResources(Resource LEGTAYFZSI) {
        maybeInitBuilder();
        if (LEGTAYFZSI == null)
            RDKBKNCBAP.clearReservedResources();

        this.TBCBNPAXAZ = LEGTAYFZSI;
    }

    @Override
    public synchronized Resource getNeededResources() {
        ApplicationResourceUsageReportProtoOrBuilder LVCBAOERUV = (VEODFNKNHZ) ? WCWREVHFKN : RDKBKNCBAP;
        if (this.HULBODTAHL != null) {
            return this.HULBODTAHL;
        }
        if (!LVCBAOERUV.hasNeededResources()) {
            return null;
        }
        this.HULBODTAHL = convertFromProtoFormat(LVCBAOERUV.getNeededResources());
        return this.HULBODTAHL;
    }

    @Override
    public synchronized void setNeededResources(Resource CMBUFFAZSM) {
        maybeInitBuilder();
        if (CMBUFFAZSM == null)
            RDKBKNCBAP.clearNeededResources();

        this.HULBODTAHL = CMBUFFAZSM;
    }

    private ResourcePBImpl convertFromProtoFormat(ResourceProto VITYTFNPSO) {
        return new ResourcePBImpl(VITYTFNPSO);
    }

    private ResourceProto convertToProtoFormat(Resource CUZOKNGAOT) {
        return ((ResourcePBImpl) (CUZOKNGAOT)).getProto();
    }
}