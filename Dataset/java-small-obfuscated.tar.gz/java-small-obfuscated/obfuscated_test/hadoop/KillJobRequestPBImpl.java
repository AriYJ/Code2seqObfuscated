public class KillJobRequestPBImpl extends ProtoBase<KillJobRequestProto> implements KillJobRequest {
    KillJobRequestProto JTPEBUEBQU = KillJobRequestProto.getDefaultInstance();

    Builder DPCKHDSUIY = null;

    boolean VEZJSQWWJM = false;

    private JobId YXOJDBIFNF = null;

    public KillJobRequestPBImpl() {
        DPCKHDSUIY = KillJobRequestProto.newBuilder();
    }

    public KillJobRequestPBImpl(KillJobRequestProto RXXJUFPVCP) {
        this.JTPEBUEBQU = RXXJUFPVCP;
        VEZJSQWWJM = true;
    }

    public KillJobRequestProto getProto() {
        mergeLocalToProto();
        JTPEBUEBQU = (VEZJSQWWJM) ? JTPEBUEBQU : DPCKHDSUIY.build();
        VEZJSQWWJM = true;
        return JTPEBUEBQU;
    }

    private void mergeLocalToBuilder() {
        if (this.YXOJDBIFNF != null) {
            DPCKHDSUIY.setJobId(convertToProtoFormat(this.YXOJDBIFNF));
        }
    }

    private void mergeLocalToProto() {
        if (VEZJSQWWJM)
            maybeInitBuilder();

        mergeLocalToBuilder();
        JTPEBUEBQU = DPCKHDSUIY.build();
        VEZJSQWWJM = true;
    }

    private void maybeInitBuilder() {
        if (VEZJSQWWJM || (DPCKHDSUIY == null)) {
            DPCKHDSUIY = KillJobRequestProto.newBuilder(JTPEBUEBQU);
        }
        VEZJSQWWJM = false;
    }

    @Override
    public JobId getJobId() {
        KillJobRequestProtoOrBuilder WRLELWTLVE = (VEZJSQWWJM) ? JTPEBUEBQU : DPCKHDSUIY;
        if (this.YXOJDBIFNF != null) {
            return this.YXOJDBIFNF;
        }
        if (!WRLELWTLVE.hasJobId()) {
            return null;
        }
        this.YXOJDBIFNF = convertFromProtoFormat(WRLELWTLVE.getJobId());
        return this.YXOJDBIFNF;
    }

    @Override
    public void setJobId(JobId KBORHXOISC) {
        maybeInitBuilder();
        if (KBORHXOISC == null)
            DPCKHDSUIY.clearJobId();

        this.YXOJDBIFNF = KBORHXOISC;
    }

    private JobIdPBImpl convertFromProtoFormat(JobIdProto SNPOONCUAW) {
        return new JobIdPBImpl(SNPOONCUAW);
    }

    private JobIdProto convertToProtoFormat(JobId AGZDEFURXZ) {
        return ((JobIdPBImpl) (AGZDEFURXZ)).getProto();
    }
}