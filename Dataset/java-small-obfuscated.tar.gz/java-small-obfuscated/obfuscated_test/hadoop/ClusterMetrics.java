/**
 * Status information on the current state of the Map-Reduce cluster.
 *
 * <p><code>ClusterMetrics</code> provides clients with information such as:
 * <ol>
 *   <li>
 *   Size of the cluster.
 *   </li>
 *   <li>
 *   Number of blacklisted and decommissioned trackers.
 *   </li>
 *   <li>
 *   Slot capacity of the cluster.
 *   </li>
 *   <li>
 *   The number of currently occupied/reserved map & reduce slots.
 *   </li>
 *   <li>
 *   The number of currently running map & reduce tasks.
 *   </li>
 *   <li>
 *   The number of job submissions.
 *   </li>
 * </ol></p>
 *
 * <p>Clients can query for the latest <code>ClusterMetrics</code>, via
 * {@link Cluster#getClusterStatus()}.</p>
 *
 * @see Cluster
 */
@InterfaceAudience.Public
@InterfaceStability.Evolving
public class ClusterMetrics implements Writable {
    private int KYPJIETSIC;

    private int ZTVEUXDEOH;

    private int IUPEYCTGVS;

    private int ATNJHGBOQW;

    private int JCBBKESRKR;

    private int EKKIZRELNP;

    private int ILSZNBCWFG;

    private int TFCGRWBWFJ;

    private int XGLEDCBEBN;

    private int MIWLJJYSFQ;

    private int NCUWWMLLMJ;

    private int RFUKLEIDPI;

    private int SHEOSTFNIQ;

    public ClusterMetrics() {
    }

    public ClusterMetrics(int TNLHKXLCNR, int YREKGCOQOY, int FFGYILJAHX, int GIYIQMLLLL, int IYZCXAWZOK, int ZZJHQCGWQC, int MONEZXYVIZ, int WKOJTOYVMU, int BUFSADCVOG, int XORPRRXUKN, int NUWGJEHTZC, int OAUVTOEUHJ) {
        this(TNLHKXLCNR, YREKGCOQOY, FFGYILJAHX, GIYIQMLLLL, IYZCXAWZOK, ZZJHQCGWQC, MONEZXYVIZ, WKOJTOYVMU, BUFSADCVOG, XORPRRXUKN, NUWGJEHTZC, 0, OAUVTOEUHJ);
    }

    public ClusterMetrics(int YPWMLJTOTF, int XOMVWTBKPP, int QSDVSWMGZW, int CRKVEYULEL, int ZCJOSTSQQA, int ADTLWGWIHK, int WNOPLIPYBJ, int BQJNECCCIB, int VVBNDSLQTP, int EICFYWXTIN, int KEREPIWANA, int NPLCHGHDCG, int XJOGHWGXRD) {
        this.KYPJIETSIC = YPWMLJTOTF;
        this.ZTVEUXDEOH = XOMVWTBKPP;
        this.IUPEYCTGVS = QSDVSWMGZW;
        this.ATNJHGBOQW = CRKVEYULEL;
        this.JCBBKESRKR = ZCJOSTSQQA;
        this.EKKIZRELNP = ADTLWGWIHK;
        this.ILSZNBCWFG = WNOPLIPYBJ;
        this.TFCGRWBWFJ = BQJNECCCIB;
        this.XGLEDCBEBN = VVBNDSLQTP;
        this.MIWLJJYSFQ = EICFYWXTIN;
        this.NCUWWMLLMJ = KEREPIWANA;
        this.RFUKLEIDPI = NPLCHGHDCG;
        this.SHEOSTFNIQ = XJOGHWGXRD;
    }

    /**
     * Get the number of running map tasks in the cluster.
     *
     * @return running maps
     */
    public int getRunningMaps() {
        return KYPJIETSIC;
    }

    /**
     * Get the number of running reduce tasks in the cluster.
     *
     * @return running reduces
     */
    public int getRunningReduces() {
        return ZTVEUXDEOH;
    }

    /**
     * Get number of occupied map slots in the cluster.
     *
     * @return occupied map slot count
     */
    public int getOccupiedMapSlots() {
        return IUPEYCTGVS;
    }

    /**
     * Get the number of occupied reduce slots in the cluster.
     *
     * @return occupied reduce slot count
     */
    public int getOccupiedReduceSlots() {
        return ATNJHGBOQW;
    }

    /**
     * Get number of reserved map slots in the cluster.
     *
     * @return reserved map slot count
     */
    public int getReservedMapSlots() {
        return JCBBKESRKR;
    }

    /**
     * Get the number of reserved reduce slots in the cluster.
     *
     * @return reserved reduce slot count
     */
    public int getReservedReduceSlots() {
        return EKKIZRELNP;
    }

    /**
     * Get the total number of map slots in the cluster.
     *
     * @return map slot capacity
     */
    public int getMapSlotCapacity() {
        return ILSZNBCWFG;
    }

    /**
     * Get the total number of reduce slots in the cluster.
     *
     * @return reduce slot capacity
     */
    public int getReduceSlotCapacity() {
        return TFCGRWBWFJ;
    }

    /**
     * Get the total number of job submissions in the cluster.
     *
     * @return total number of job submissions
     */
    public int getTotalJobSubmissions() {
        return XGLEDCBEBN;
    }

    /**
     * Get the number of active trackers in the cluster.
     *
     * @return active tracker count.
     */
    public int getTaskTrackerCount() {
        return MIWLJJYSFQ;
    }

    /**
     * Get the number of blacklisted trackers in the cluster.
     *
     * @return blacklisted tracker count
     */
    public int getBlackListedTaskTrackerCount() {
        return NCUWWMLLMJ;
    }

    /**
     * Get the number of graylisted trackers in the cluster.
     *
     * @return graylisted tracker count
     */
    public int getGrayListedTaskTrackerCount() {
        return RFUKLEIDPI;
    }

    /**
     * Get the number of decommissioned trackers in the cluster.
     *
     * @return decommissioned tracker count
     */
    public int getDecommissionedTaskTrackerCount() {
        return SHEOSTFNIQ;
    }

    @Override
    public void readFields(DataInput CXTDHSCPJR) throws IOException {
        KYPJIETSIC = CXTDHSCPJR.readInt();
        ZTVEUXDEOH = CXTDHSCPJR.readInt();
        IUPEYCTGVS = CXTDHSCPJR.readInt();
        ATNJHGBOQW = CXTDHSCPJR.readInt();
        JCBBKESRKR = CXTDHSCPJR.readInt();
        EKKIZRELNP = CXTDHSCPJR.readInt();
        ILSZNBCWFG = CXTDHSCPJR.readInt();
        TFCGRWBWFJ = CXTDHSCPJR.readInt();
        XGLEDCBEBN = CXTDHSCPJR.readInt();
        MIWLJJYSFQ = CXTDHSCPJR.readInt();
        NCUWWMLLMJ = CXTDHSCPJR.readInt();
        RFUKLEIDPI = CXTDHSCPJR.readInt();
        SHEOSTFNIQ = CXTDHSCPJR.readInt();
    }

    @Override
    public void write(DataOutput UKRHXDLTDV) throws IOException {
        UKRHXDLTDV.writeInt(KYPJIETSIC);
        UKRHXDLTDV.writeInt(ZTVEUXDEOH);
        UKRHXDLTDV.writeInt(IUPEYCTGVS);
        UKRHXDLTDV.writeInt(ATNJHGBOQW);
        UKRHXDLTDV.writeInt(JCBBKESRKR);
        UKRHXDLTDV.writeInt(EKKIZRELNP);
        UKRHXDLTDV.writeInt(ILSZNBCWFG);
        UKRHXDLTDV.writeInt(TFCGRWBWFJ);
        UKRHXDLTDV.writeInt(XGLEDCBEBN);
        UKRHXDLTDV.writeInt(MIWLJJYSFQ);
        UKRHXDLTDV.writeInt(NCUWWMLLMJ);
        UKRHXDLTDV.writeInt(RFUKLEIDPI);
        UKRHXDLTDV.writeInt(SHEOSTFNIQ);
    }
}