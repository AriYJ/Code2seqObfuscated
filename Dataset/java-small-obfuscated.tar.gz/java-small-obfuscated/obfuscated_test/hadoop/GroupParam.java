/**
 * Group parameter.
 */
public class GroupParam extends StringParam {
    /**
     * Parameter name.
     */
    public static final String HYCFDCZAPA = "group";

    /**
     * Default parameter value.
     */
    public static final String XYKCOLFTFZ = "";

    private static final Domain CEGXJGGVYG = new Domain(GroupParam.HYCFDCZAPA, null);

    /**
     * Constructor.
     *
     * @param str
     * 		a string representation of the parameter value.
     */
    public GroupParam(final String ZPRBXYVSKL) {
        super(GroupParam.CEGXJGGVYG, (ZPRBXYVSKL == null) || ZPRBXYVSKL.equals(GroupParam.XYKCOLFTFZ) ? null : ZPRBXYVSKL);
    }

    @Override
    public String getName() {
        return GroupParam.HYCFDCZAPA;
    }
}