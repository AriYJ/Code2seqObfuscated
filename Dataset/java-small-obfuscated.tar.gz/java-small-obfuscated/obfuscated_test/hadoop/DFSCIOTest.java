/**
 * Distributed i/o benchmark.
 * <p>
 * This test writes into or reads from a specified number of files.
 * File size is specified as a parameter to the test.
 * Each file is accessed in a separate map task.
 * <p>
 * The reducer collects the following statistics:
 * <ul>
 * <li>number of tasks completed</li>
 * <li>number of bytes written/read</li>
 * <li>execution time</li>
 * <li>io rate</li>
 * <li>io rate squared</li>
 * </ul>
 *
 * Finally, the following information is appended to a local file
 * <ul>
 * <li>read or write test</li>
 * <li>date and time the test finished</li>
 * <li>number of files</li>
 * <li>total number of bytes processed</li>
 * <li>throughput in mb/sec (total number of bytes / sum of processing times)</li>
 * <li>average i/o rate in mb/sec per file</li>
 * <li>standard i/o rate deviation</li>
 * </ul>
 */
@Ignore
public class DFSCIOTest extends TestCase {
    // Constants
    private static final Log UKEVHBKXWQ = LogFactory.getLog(DFSCIOTest.class);

    private static final int XZNEYKKRFU = 0;

    private static final int PCLOGOIHCD = 1;

    private static final int JIXCMAQKLM = 2;

    private static final int FIVDXHLTBD = 1000000;

    private static final String BMLSAPHAOH = "test_io_";

    private static final String SZMWEPSONX = "DFSCIOTest_results.log";

    private static Configuration GOZMLNYKZV = new Configuration();

    private static final long IBUFRHLRJN = 0x100000;

    private static String ECSZQWWGSJ = System.getProperty("test.build.data", "/benchmarks/DFSCIOTest");

    private static Path OIKIOOVOCZ = new Path(DFSCIOTest.ECSZQWWGSJ, "io_control");

    private static Path KYGWOZHWKY = new Path(DFSCIOTest.ECSZQWWGSJ, "io_write");

    private static Path ZODUCPAOWE = new Path(DFSCIOTest.ECSZQWWGSJ, "io_read");

    private static Path IGMADRVJXA = new Path(DFSCIOTest.ECSZQWWGSJ, "io_data");

    private static Path FJWUBDPKCX = new Path("/tmp/DFSCIOTest");

    private static String TCHCDRGTAM = System.getProperty("libhdfs.version", "1");

    private static String CTPRWMCPHT = new String("chmod");

    private static Path SIDDJIVBTA = new Path((DFSCIOTest.FJWUBDPKCX + "/libhdfs.so.") + DFSCIOTest.TCHCDRGTAM);

    private static Path RITQTEAUMX = new Path(DFSCIOTest.FJWUBDPKCX + "/hdfs_read");

    private static Path XHACPHKHHX = new Path(DFSCIOTest.FJWUBDPKCX + "/hdfs_write");

    /**
     * Run the test with default parameters.
     *
     * @throws Exception
     * 		
     */
    public void testIOs() throws Exception {
        DFSCIOTest.testIOs(10, 10);
    }

    /**
     * Run the test with the specified parameters.
     *
     * @param fileSize
     * 		file size
     * @param nrFiles
     * 		number of files
     * @throws IOException
     * 		
     */
    public static void testIOs(int KQHWXRYRGE, int QTFLEPBXYI) throws IOException {
        FileSystem HOSOHFNKUK = FileSystem.get(DFSCIOTest.GOZMLNYKZV);
        DFSCIOTest.createControlFile(HOSOHFNKUK, KQHWXRYRGE, QTFLEPBXYI);
        DFSCIOTest.writeTest(HOSOHFNKUK);
        DFSCIOTest.readTest(HOSOHFNKUK);
    }

    private static void createControlFile(FileSystem PQUVJKPYSU, int XFVQWKPYKF, // in MB
    int XZMHXABXMQ) throws IOException {
        DFSCIOTest.UKEVHBKXWQ.info(((("creating control file: " + XFVQWKPYKF) + " mega bytes, ") + XZMHXABXMQ) + " files");
        PQUVJKPYSU.delete(DFSCIOTest.OIKIOOVOCZ, true);
        for (int UXPZSLVPZE = 0; UXPZSLVPZE < XZMHXABXMQ; UXPZSLVPZE++) {
            String IKVDZLZGRF = DFSCIOTest.getFileName(UXPZSLVPZE);
            Path LFQJADNXQA = new Path(DFSCIOTest.OIKIOOVOCZ, "in_file_" + IKVDZLZGRF);
            SequenceFile.Writer LBRBQBWQCF = null;
            try {
                LBRBQBWQCF = SequenceFile.createWriter(PQUVJKPYSU, DFSCIOTest.GOZMLNYKZV, LFQJADNXQA, Text.class, LongWritable.class, NONE);
                LBRBQBWQCF.append(new Text(IKVDZLZGRF), new LongWritable(XFVQWKPYKF));
            } catch (Exception e) {
                throw new IOException(e.getLocalizedMessage());
            } finally {
                if (LBRBQBWQCF != null)
                    LBRBQBWQCF.close();

                LBRBQBWQCF = null;
            }
        }
        DFSCIOTest.UKEVHBKXWQ.info(("created control files for: " + XZMHXABXMQ) + " files");
    }

    private static String getFileName(int THYXVKNFMJ) {
        return DFSCIOTest.BMLSAPHAOH + Integer.toString(THYXVKNFMJ);
    }

    /**
     * Write/Read mapper base class.
     * <p>
     * Collects the following statistics per task:
     * <ul>
     * <li>number of tasks completed</li>
     * <li>number of bytes written/read</li>
     * <li>execution time</li>
     * <li>i/o rate</li>
     * <li>i/o rate squared</li>
     * </ul>
     */
    private static abstract class IOStatMapper extends IOMapperBase<Long> {
        IOStatMapper() {
        }

        void collectStats(OutputCollector<Text, Text> output, String name, long execTime, Long objSize) throws IOException {
            long totalSize = objSize.longValue();
            float ioRateMbSec = (((float) (totalSize)) * 1000) / (execTime * DFSCIOTest.IBUFRHLRJN);
            DFSCIOTest.UKEVHBKXWQ.info("Number of bytes processed = " + totalSize);
            DFSCIOTest.UKEVHBKXWQ.info("Exec time = " + execTime);
            DFSCIOTest.UKEVHBKXWQ.info("IO rate = " + ioRateMbSec);
            output.collect(new Text(AccumulatingReducer.VALUE_TYPE_LONG + "tasks"), new Text(String.valueOf(1)));
            output.collect(new Text(AccumulatingReducer.VALUE_TYPE_LONG + "size"), new Text(String.valueOf(totalSize)));
            output.collect(new Text(AccumulatingReducer.VALUE_TYPE_LONG + "time"), new Text(String.valueOf(execTime)));
            output.collect(new Text(AccumulatingReducer.VALUE_TYPE_FLOAT + "rate"), new Text(String.valueOf(ioRateMbSec * 1000)));
            output.collect(new Text(AccumulatingReducer.VALUE_TYPE_FLOAT + "sqrate"), new Text(String.valueOf((ioRateMbSec * ioRateMbSec) * 1000)));
        }
    }

    /**
     * Write mapper class.
     */
    public static class WriteMapper extends DFSCIOTest.IOStatMapper {
        public WriteMapper() {
            super();
            for (int i = 0; i < bufferSize; i++)
                buffer[i] = ((byte) ('0' + (i % 50)));

        }

        public Long doIO(Reporter reporter, String name, long totalSize) throws IOException {
            // create file
            totalSize *= DFSCIOTest.IBUFRHLRJN;
            // create instance of local filesystem
            FileSystem localFS = FileSystem.getLocal(DFSCIOTest.GOZMLNYKZV);
            try {
                // native runtime
                Runtime runTime = Runtime.getRuntime();
                // copy the dso and executable from dfs and chmod them
                synchronized(this) {
                    localFS.delete(DFSCIOTest.FJWUBDPKCX, true);
                    if (!localFS.mkdirs(DFSCIOTest.FJWUBDPKCX)) {
                        throw new IOException(("Failed to create " + DFSCIOTest.FJWUBDPKCX) + " on local filesystem");
                    }
                }
                synchronized(this) {
                    if (!localFS.exists(DFSCIOTest.SIDDJIVBTA)) {
                        FileUtil.copy(fs, DFSCIOTest.SIDDJIVBTA, localFS, DFSCIOTest.SIDDJIVBTA, false, DFSCIOTest.GOZMLNYKZV);
                        String chmodCmd = new String((DFSCIOTest.CTPRWMCPHT + " a+x ") + DFSCIOTest.SIDDJIVBTA);
                        Process process = runTime.exec(chmodCmd);
                        int exitStatus = process.waitFor();
                        if (exitStatus != 0) {
                            throw new IOException((chmodCmd + ": Failed with exitStatus: ") + exitStatus);
                        }
                    }
                }
                synchronized(this) {
                    if (!localFS.exists(DFSCIOTest.XHACPHKHHX)) {
                        FileUtil.copy(fs, DFSCIOTest.XHACPHKHHX, localFS, DFSCIOTest.XHACPHKHHX, false, DFSCIOTest.GOZMLNYKZV);
                        String chmodCmd = new String((DFSCIOTest.CTPRWMCPHT + " a+x ") + DFSCIOTest.XHACPHKHHX);
                        Process process = runTime.exec(chmodCmd);
                        int exitStatus = process.waitFor();
                        if (exitStatus != 0) {
                            throw new IOException((chmodCmd + ": Failed with exitStatus: ") + exitStatus);
                        }
                    }
                }
                // exec the C program
                Path outFile = new Path(DFSCIOTest.IGMADRVJXA, name);
                String writeCmd = new String((((((DFSCIOTest.XHACPHKHHX + " ") + outFile) + " ") + totalSize) + " ") + bufferSize);
                Process process = runTime.exec(writeCmd, null, new File(DFSCIOTest.FJWUBDPKCX.toString()));
                int exitStatus = process.waitFor();
                if (exitStatus != 0) {
                    throw new IOException((writeCmd + ": Failed with exitStatus: ") + exitStatus);
                }
            } catch (InterruptedException interruptedException) {
                reporter.setStatus(interruptedException.toString());
            } finally {
                localFS.close();
            }
            return new Long(totalSize);
        }
    }

    private static void writeTest(FileSystem DHZGZDDNRY) throws IOException {
        DHZGZDDNRY.delete(DFSCIOTest.IGMADRVJXA, true);
        DHZGZDDNRY.delete(DFSCIOTest.KYGWOZHWKY, true);
        DFSCIOTest.runIOTest(DFSCIOTest.WriteMapper.class, DFSCIOTest.KYGWOZHWKY);
    }

    private static void runIOTest(Class<? extends Mapper> FNRHZZEYOP, Path WZMNSBLKGH) throws IOException {
        JobConf FPORWSPUXN = new JobConf(DFSCIOTest.GOZMLNYKZV, DFSCIOTest.class);
        FileInputFormat.setInputPaths(FPORWSPUXN, DFSCIOTest.OIKIOOVOCZ);
        FPORWSPUXN.setInputFormat(SequenceFileInputFormat.class);
        FPORWSPUXN.setMapperClass(FNRHZZEYOP);
        FPORWSPUXN.setReducerClass(AccumulatingReducer.class);
        FileOutputFormat.setOutputPath(FPORWSPUXN, WZMNSBLKGH);
        FPORWSPUXN.setOutputKeyClass(Text.class);
        FPORWSPUXN.setOutputValueClass(Text.class);
        FPORWSPUXN.setNumReduceTasks(1);
        JobClient.runJob(FPORWSPUXN);
    }

    /**
     * Read mapper class.
     */
    public static class ReadMapper extends DFSCIOTest.IOStatMapper {
        public ReadMapper() {
            super();
        }

        public Long doIO(Reporter reporter, String name, long totalSize) throws IOException {
            totalSize *= DFSCIOTest.IBUFRHLRJN;
            // create instance of local filesystem
            FileSystem localFS = FileSystem.getLocal(DFSCIOTest.GOZMLNYKZV);
            try {
                // native runtime
                Runtime runTime = Runtime.getRuntime();
                // copy the dso and executable from dfs
                synchronized(this) {
                    localFS.delete(DFSCIOTest.FJWUBDPKCX, true);
                    if (!localFS.mkdirs(DFSCIOTest.FJWUBDPKCX)) {
                        throw new IOException(("Failed to create " + DFSCIOTest.FJWUBDPKCX) + " on local filesystem");
                    }
                }
                synchronized(this) {
                    if (!localFS.exists(DFSCIOTest.SIDDJIVBTA)) {
                        if (!FileUtil.copy(fs, DFSCIOTest.SIDDJIVBTA, localFS, DFSCIOTest.SIDDJIVBTA, false, DFSCIOTest.GOZMLNYKZV)) {
                            throw new IOException(("Failed to copy " + DFSCIOTest.SIDDJIVBTA) + " to local filesystem");
                        }
                        String chmodCmd = new String((DFSCIOTest.CTPRWMCPHT + " a+x ") + DFSCIOTest.SIDDJIVBTA);
                        Process process = runTime.exec(chmodCmd);
                        int exitStatus = process.waitFor();
                        if (exitStatus != 0) {
                            throw new IOException((chmodCmd + ": Failed with exitStatus: ") + exitStatus);
                        }
                    }
                }
                synchronized(this) {
                    if (!localFS.exists(DFSCIOTest.RITQTEAUMX)) {
                        if (!FileUtil.copy(fs, DFSCIOTest.RITQTEAUMX, localFS, DFSCIOTest.RITQTEAUMX, false, DFSCIOTest.GOZMLNYKZV)) {
                            throw new IOException(("Failed to copy " + DFSCIOTest.RITQTEAUMX) + " to local filesystem");
                        }
                        String chmodCmd = new String((DFSCIOTest.CTPRWMCPHT + " a+x ") + DFSCIOTest.RITQTEAUMX);
                        Process process = runTime.exec(chmodCmd);
                        int exitStatus = process.waitFor();
                        if (exitStatus != 0) {
                            throw new IOException((chmodCmd + ": Failed with exitStatus: ") + exitStatus);
                        }
                    }
                }
                // exec the C program
                Path inFile = new Path(DFSCIOTest.IGMADRVJXA, name);
                String readCmd = new String((((((DFSCIOTest.RITQTEAUMX + " ") + inFile) + " ") + totalSize) + " ") + bufferSize);
                Process process = runTime.exec(readCmd, null, new File(DFSCIOTest.FJWUBDPKCX.toString()));
                int exitStatus = process.waitFor();
                if (exitStatus != 0) {
                    throw new IOException((DFSCIOTest.RITQTEAUMX + ": Failed with exitStatus: ") + exitStatus);
                }
            } catch (InterruptedException interruptedException) {
                reporter.setStatus(interruptedException.toString());
            } finally {
                localFS.close();
            }
            return new Long(totalSize);
        }
    }

    private static void readTest(FileSystem AOBDXSWIFX) throws IOException {
        AOBDXSWIFX.delete(DFSCIOTest.ZODUCPAOWE, true);
        DFSCIOTest.runIOTest(DFSCIOTest.ReadMapper.class, DFSCIOTest.ZODUCPAOWE);
    }

    private static void sequentialTest(FileSystem PSUWKPONFU, int XXCYKYOXPE, int ZNNTZDSQUE, int JHVHZKFLLO) throws Exception {
        DFSCIOTest.IOStatMapper SYXCAQSJLZ = null;
        if (XXCYKYOXPE == DFSCIOTest.XZNEYKKRFU)
            SYXCAQSJLZ = new DFSCIOTest.ReadMapper();
        else
            if (XXCYKYOXPE == DFSCIOTest.PCLOGOIHCD)
                SYXCAQSJLZ = new DFSCIOTest.WriteMapper();
            else
                return;


        for (int QIABSRWXWP = 0; QIABSRWXWP < JHVHZKFLLO; QIABSRWXWP++)
            SYXCAQSJLZ.doIO(NULL, DFSCIOTest.BMLSAPHAOH + Integer.toString(QIABSRWXWP), DFSCIOTest.IBUFRHLRJN * ZNNTZDSQUE);

    }

    public static void main(String[] LTTQBSCRYV) {
        int TKKEMQYARR = DFSCIOTest.XZNEYKKRFU;
        int AAFHDPITVP = DFSCIOTest.FIVDXHLTBD;
        int FDUCYMNDKU = 1;
        int GCTQFUOUPZ = 1;
        String YXPPTTNQJU = DFSCIOTest.SZMWEPSONX;
        boolean ESMOJFFMQO = false;
        String IZHKAANHPW = "DFSCIOTest.0.0.1";
        String ZGTUOBEUKB = "Usage: DFSCIOTest -read | -write | -clean [-nrFiles N] [-fileSize MB] [-resFile resultFileName] [-bufferSize Bytes] ";
        System.out.println(IZHKAANHPW);
        if (LTTQBSCRYV.length == 0) {
            System.err.println(ZGTUOBEUKB);
            System.exit(-1);
        }
        for (int NVYWXCZXAU = 0; NVYWXCZXAU < LTTQBSCRYV.length; NVYWXCZXAU++) {
            // parse command line
            if (LTTQBSCRYV[NVYWXCZXAU].startsWith("-r")) {
                TKKEMQYARR = DFSCIOTest.XZNEYKKRFU;
            } else
                if (LTTQBSCRYV[NVYWXCZXAU].startsWith("-w")) {
                    TKKEMQYARR = DFSCIOTest.PCLOGOIHCD;
                } else
                    if (LTTQBSCRYV[NVYWXCZXAU].startsWith("-clean")) {
                        TKKEMQYARR = DFSCIOTest.JIXCMAQKLM;
                    } else
                        if (LTTQBSCRYV[NVYWXCZXAU].startsWith("-seq")) {
                            ESMOJFFMQO = true;
                        } else
                            if (LTTQBSCRYV[NVYWXCZXAU].equals("-nrFiles")) {
                                GCTQFUOUPZ = Integer.parseInt(LTTQBSCRYV[++NVYWXCZXAU]);
                            } else
                                if (LTTQBSCRYV[NVYWXCZXAU].equals("-fileSize")) {
                                    FDUCYMNDKU = Integer.parseInt(LTTQBSCRYV[++NVYWXCZXAU]);
                                } else
                                    if (LTTQBSCRYV[NVYWXCZXAU].equals("-bufferSize")) {
                                        AAFHDPITVP = Integer.parseInt(LTTQBSCRYV[++NVYWXCZXAU]);
                                    } else
                                        if (LTTQBSCRYV[NVYWXCZXAU].equals("-resFile")) {
                                            YXPPTTNQJU = LTTQBSCRYV[++NVYWXCZXAU];
                                        }







        }
        DFSCIOTest.UKEVHBKXWQ.info("nrFiles = " + GCTQFUOUPZ);
        DFSCIOTest.UKEVHBKXWQ.info("fileSize (MB) = " + FDUCYMNDKU);
        DFSCIOTest.UKEVHBKXWQ.info("bufferSize = " + AAFHDPITVP);
        try {
            DFSCIOTest.GOZMLNYKZV.setInt("test.io.file.buffer.size", AAFHDPITVP);
            FileSystem LBXXWYNKJR = FileSystem.get(DFSCIOTest.GOZMLNYKZV);
            if (TKKEMQYARR != DFSCIOTest.JIXCMAQKLM) {
                LBXXWYNKJR.delete(DFSCIOTest.FJWUBDPKCX, true);
                if (!LBXXWYNKJR.mkdirs(DFSCIOTest.FJWUBDPKCX)) {
                    throw new IOException("Mkdirs failed to create " + DFSCIOTest.FJWUBDPKCX.toString());
                }
                // Copy the executables over to the remote filesystem
                String ATMDNKFFTD = System.getenv("HADOOP_PREFIX");
                LBXXWYNKJR.copyFromLocalFile(new Path((ATMDNKFFTD + "/libhdfs/libhdfs.so.") + DFSCIOTest.TCHCDRGTAM), DFSCIOTest.SIDDJIVBTA);
                LBXXWYNKJR.copyFromLocalFile(new Path(ATMDNKFFTD + "/libhdfs/hdfs_read"), DFSCIOTest.RITQTEAUMX);
                LBXXWYNKJR.copyFromLocalFile(new Path(ATMDNKFFTD + "/libhdfs/hdfs_write"), DFSCIOTest.XHACPHKHHX);
            }
            if (ESMOJFFMQO) {
                long XQOZNNQTNA = System.currentTimeMillis();
                DFSCIOTest.sequentialTest(LBXXWYNKJR, TKKEMQYARR, FDUCYMNDKU, GCTQFUOUPZ);
                long RYZVLIOKFO = System.currentTimeMillis() - XQOZNNQTNA;
                String ULRPIZMUMD = "Seq Test exec time sec: " + (((float) (RYZVLIOKFO)) / 1000);
                DFSCIOTest.UKEVHBKXWQ.info(ULRPIZMUMD);
                return;
            }
            if (TKKEMQYARR == DFSCIOTest.JIXCMAQKLM) {
                DFSCIOTest.cleanup(LBXXWYNKJR);
                return;
            }
            DFSCIOTest.createControlFile(LBXXWYNKJR, FDUCYMNDKU, GCTQFUOUPZ);
            long WRYLAQTONI = System.currentTimeMillis();
            if (TKKEMQYARR == DFSCIOTest.PCLOGOIHCD)
                DFSCIOTest.writeTest(LBXXWYNKJR);

            if (TKKEMQYARR == DFSCIOTest.XZNEYKKRFU)
                DFSCIOTest.readTest(LBXXWYNKJR);

            long XELZXCZALM = System.currentTimeMillis() - WRYLAQTONI;
            DFSCIOTest.analyzeResult(LBXXWYNKJR, TKKEMQYARR, XELZXCZALM, YXPPTTNQJU);
        } catch (Exception e) {
            System.err.print(e.getLocalizedMessage());
            System.exit(-1);
        }
    }

    private static void analyzeResult(FileSystem OPYYDQNDLD, int EYXGHQTGRU, long QIOCVEAXFR, String XGHSQYTEMS) throws IOException {
        Path QWJTGCYZZH;
        if (EYXGHQTGRU == DFSCIOTest.PCLOGOIHCD)
            QWJTGCYZZH = new Path(DFSCIOTest.KYGWOZHWKY, "part-00000");
        else
            QWJTGCYZZH = new Path(DFSCIOTest.ZODUCPAOWE, "part-00000");

        DataInputStream NKPUAAZOPQ;
        NKPUAAZOPQ = new DataInputStream(OPYYDQNDLD.open(QWJTGCYZZH));
        BufferedReader AAXAARRPEG;
        AAXAARRPEG = new BufferedReader(new InputStreamReader(NKPUAAZOPQ));
        long QRULEMWNAU = 0;
        long JSYRHMRKGV = 0;
        long BVRLKFMBNG = 0;
        float FZYPRNSDIE = 0;
        float UFKYOKZHNQ = 0;
        String DNJVNHZICN;
        while ((DNJVNHZICN = AAXAARRPEG.readLine()) != null) {
            StringTokenizer FYVODCRZGO = new StringTokenizer(DNJVNHZICN, " \t\n\r\f%");
            String MCSKQQRPOG = FYVODCRZGO.nextToken();
            if (MCSKQQRPOG.endsWith(":tasks"))
                QRULEMWNAU = Long.parseLong(FYVODCRZGO.nextToken());
            else
                if (MCSKQQRPOG.endsWith(":size"))
                    JSYRHMRKGV = Long.parseLong(FYVODCRZGO.nextToken());
                else
                    if (MCSKQQRPOG.endsWith(":time"))
                        BVRLKFMBNG = Long.parseLong(FYVODCRZGO.nextToken());
                    else
                        if (MCSKQQRPOG.endsWith(":rate"))
                            FZYPRNSDIE = Float.parseFloat(FYVODCRZGO.nextToken());
                        else
                            if (MCSKQQRPOG.endsWith(":sqrate"))
                                UFKYOKZHNQ = Float.parseFloat(FYVODCRZGO.nextToken());





        } 
        double NUEBKDOSGK = (FZYPRNSDIE / 1000) / QRULEMWNAU;
        double AYUYZXLSZD = Math.sqrt(Math.abs(((UFKYOKZHNQ / 1000) / QRULEMWNAU) - (NUEBKDOSGK * NUEBKDOSGK)));
        String[] YWLIKIHMEF = new String[]{ "----- DFSCIOTest ----- : " + (EYXGHQTGRU == DFSCIOTest.PCLOGOIHCD ? "write" : EYXGHQTGRU == DFSCIOTest.XZNEYKKRFU ? "read" : "unknown"), "           Date & time: " + new Date(System.currentTimeMillis()), "       Number of files: " + QRULEMWNAU, "Total MBytes processed: " + (JSYRHMRKGV / DFSCIOTest.IBUFRHLRJN), "     Throughput mb/sec: " + ((JSYRHMRKGV * 1000.0) / (BVRLKFMBNG * DFSCIOTest.IBUFRHLRJN)), "Average IO rate mb/sec: " + NUEBKDOSGK, " Std IO rate deviation: " + AYUYZXLSZD, "    Test exec time sec: " + (((float) (QIOCVEAXFR)) / 1000), "" };
        PrintStream MVSWZFAHEZ = new PrintStream(new FileOutputStream(new File(XGHSQYTEMS), true));
        for (int FFITRJMZZV = 0; FFITRJMZZV < YWLIKIHMEF.length; FFITRJMZZV++) {
            DFSCIOTest.UKEVHBKXWQ.info(YWLIKIHMEF[FFITRJMZZV]);
            MVSWZFAHEZ.println(YWLIKIHMEF[FFITRJMZZV]);
        }
    }

    private static void cleanup(FileSystem MMQSZCJKKA) throws Exception {
        DFSCIOTest.UKEVHBKXWQ.info("Cleaning up test files");
        MMQSZCJKKA.delete(new Path(DFSCIOTest.ECSZQWWGSJ), true);
        MMQSZCJKKA.delete(DFSCIOTest.FJWUBDPKCX, true);
    }
}