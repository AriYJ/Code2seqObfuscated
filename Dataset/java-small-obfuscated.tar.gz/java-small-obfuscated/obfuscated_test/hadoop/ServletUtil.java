@InterfaceAudience.Private
@InterfaceStability.Unstable
public class ServletUtil {
    /**
     * Initial HTML header
     */
    public static PrintWriter initHTML(ServletResponse LGQEYJCPZB, String BBWMLORBUE) throws IOException {
        LGQEYJCPZB.setContentType("text/html");
        PrintWriter NVEAZGCTIE = LGQEYJCPZB.getWriter();
        NVEAZGCTIE.println((((((("<html>\n" + ("<link rel=\'stylesheet\' type=\'text/css\' href=\'/static/hadoop.css\'>\n" + "<title>")) + BBWMLORBUE) + "</title>\n") + "<body>\n") + "<h1>") + BBWMLORBUE) + "</h1>\n");
        return NVEAZGCTIE;
    }

    /**
     * Get a parameter from a ServletRequest.
     * Return null if the parameter contains only white spaces.
     */
    public static String getParameter(ServletRequest QEGSQTUPVS, String IYPFTCFBPO) {
        String PBJYEXYSYY = QEGSQTUPVS.getParameter(IYPFTCFBPO);
        if (PBJYEXYSYY == null) {
            return null;
        }
        PBJYEXYSYY = PBJYEXYSYY.trim();
        return PBJYEXYSYY.length() == 0 ? null : PBJYEXYSYY;
    }

    /**
     *
     *
     * @return a long value as passed in the given parameter, throwing
    an exception if it is not present or if it is not a valid number.
     */
    public static long parseLongParam(ServletRequest PTOMSLNWGV, String CPKEUTCFBZ) throws IOException {
        String TTJGPWJWPU = PTOMSLNWGV.getParameter(CPKEUTCFBZ);
        if (TTJGPWJWPU == null) {
            throw new IOException(("Invalid request has no " + CPKEUTCFBZ) + " parameter");
        }
        return Long.valueOf(TTJGPWJWPU);
    }

    public static final String YIRYSRWJFS = ((("<hr />\n" + "<a href='http://hadoop.apache.org/core'>Hadoop</a>, ") + Calendar.getInstance().get(Calendar.YEAR)) + ".\n") + "</body></html>";

    /**
     * HTML footer to be added in the jsps.
     *
     * @return the HTML footer.
     */
    public static String htmlFooter() {
        return ServletUtil.YIRYSRWJFS;
    }

    /**
     * Generate the percentage graph and returns HTML representation string
     * of the same.
     *
     * @param perc
     * 		The percentage value for which graph is to be generated
     * @param width
     * 		The width of the display table
     * @return HTML String representation of the percentage graph
     * @throws IOException
     * 		
     */
    public static String percentageGraph(int RUYVTAEQUW, int TQQWUMSUUU) throws IOException {
        assert RUYVTAEQUW >= 0;
        assert RUYVTAEQUW <= 100;
        StringBuilder CJTUGCJQDR = new StringBuilder();
        CJTUGCJQDR.append("<table border=\"1px\" width=\"");
        CJTUGCJQDR.append(TQQWUMSUUU);
        CJTUGCJQDR.append("px\"><tr>");
        if (RUYVTAEQUW > 0) {
            CJTUGCJQDR.append("<td cellspacing=\"0\" class=\"perc_filled\" width=\"");
            CJTUGCJQDR.append(RUYVTAEQUW);
            CJTUGCJQDR.append("%\"></td>");
        }
        if (RUYVTAEQUW < 100) {
            CJTUGCJQDR.append("<td cellspacing=\"0\" class=\"perc_nonfilled\" width=\"");
            CJTUGCJQDR.append(100 - RUYVTAEQUW);
            CJTUGCJQDR.append("%\"></td>");
        }
        CJTUGCJQDR.append("</tr></table>");
        return CJTUGCJQDR.toString();
    }

    /**
     * Generate the percentage graph and returns HTML representation string
     * of the same.
     *
     * @param perc
     * 		The percentage value for which graph is to be generated
     * @param width
     * 		The width of the display table
     * @return HTML String representation of the percentage graph
     * @throws IOException
     * 		
     */
    public static String percentageGraph(float ZTZSTCYULY, int HLDCGOLLHU) throws IOException {
        return ServletUtil.percentageGraph(((int) (ZTZSTCYULY)), HLDCGOLLHU);
    }

    /**
     * Escape and encode a string regarded as within the query component of an URI.
     *
     * @param value
     * 		the value to encode
     * @return encoded query, null if the default charset is not supported
     */
    public static String encodeQueryValue(final String TDLXOMFBVJ) {
        try {
            return URIUtil.encodeWithinQuery(TDLXOMFBVJ, "UTF-8");
        } catch (URIException e) {
            throw new AssertionError("JVM does not support UTF-8");// should never happen!

        }
    }

    /**
     * Escape and encode a string regarded as the path component of an URI.
     *
     * @param path
     * 		the path component to encode
     * @return encoded path, null if UTF-8 is not supported
     */
    public static String encodePath(final String OAMUCALAVT) {
        try {
            return URIUtil.encodePath(OAMUCALAVT, "UTF-8");
        } catch (URIException e) {
            throw new AssertionError("JVM does not support UTF-8");// should never happen!

        }
    }

    /**
     * Parse and decode the path component from the given request.
     *
     * @param request
     * 		Http request to parse
     * @param servletName
     * 		the name of servlet that precedes the path
     * @return decoded path component, null if UTF-8 is not supported
     */
    public static String getDecodedPath(final HttpServletRequest WHMHPBDSRE, String JHPRGXFZME) {
        try {
            return URIUtil.decode(ServletUtil.getRawPath(WHMHPBDSRE, JHPRGXFZME), "UTF-8");
        } catch (URIException e) {
            throw new AssertionError("JVM does not support UTF-8");// should never happen!

        }
    }

    /**
     * Parse the path component from the given request and return w/o decoding.
     *
     * @param request
     * 		Http request to parse
     * @param servletName
     * 		the name of servlet that precedes the path
     * @return path component, null if the default charset is not supported
     */
    public static String getRawPath(final HttpServletRequest CDXZIOWGPO, String NVQOXBCAZH) {
        Preconditions.checkArgument(CDXZIOWGPO.getRequestURI().startsWith(NVQOXBCAZH + "/"));
        return CDXZIOWGPO.getRequestURI().substring(NVQOXBCAZH.length());
    }
}