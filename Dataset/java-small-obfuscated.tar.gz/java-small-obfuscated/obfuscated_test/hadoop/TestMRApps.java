public class TestMRApps {
    private static File JRFRLTGKKO = null;

    @BeforeClass
    public static void setupTestDirs() throws IOException {
        TestMRApps.JRFRLTGKKO = new File("target", TestMRApps.class.getCanonicalName());
        TestMRApps.delete(TestMRApps.JRFRLTGKKO);
        TestMRApps.JRFRLTGKKO.mkdirs();
        TestMRApps.JRFRLTGKKO = TestMRApps.JRFRLTGKKO.getAbsoluteFile();
    }

    @AfterClass
    public static void cleanupTestDirs() throws IOException {
        if (TestMRApps.JRFRLTGKKO != null) {
            TestMRApps.delete(TestMRApps.JRFRLTGKKO);
        }
    }

    private static void delete(File JNLEPACPUT) throws IOException {
        Configuration IWXUICHUSK = new Configuration();
        FileSystem BOGZPTGFLZ = FileSystem.getLocal(IWXUICHUSK);
        Path OTOFVDUVWW = BOGZPTGFLZ.makeQualified(new Path(JNLEPACPUT.getAbsolutePath()));
        BOGZPTGFLZ.delete(OTOFVDUVWW, true);
    }

    @Test(timeout = 120000)
    public void testJobIDtoString() {
        JobId PDMWZAVJZV = org.apache.hadoop.yarn.factory.providers.RecordFactoryProvider.getRecordFactory(null).newRecordInstance(JobId.class);
        PDMWZAVJZV.setAppId(ApplicationId.newInstance(0, 0));
        assertEquals("job_0_0000", MRApps.toString(PDMWZAVJZV));
    }

    @Test(timeout = 120000)
    public void testToJobID() {
        JobId XVAYYQBVPA = MRApps.toJobID("job_1_1");
        assertEquals(1, XVAYYQBVPA.getAppId().getClusterTimestamp());
        assertEquals(1, XVAYYQBVPA.getAppId().getId());
        assertEquals(1, XVAYYQBVPA.getId());// tests against some proto.id and not a job.id field

    }

    @Test(timeout = 120000, expected = IllegalArgumentException.class)
    public void testJobIDShort() {
        MRApps.toJobID("job_0_0_0");
    }

    // TODO_get.set
    @Test(timeout = 120000)
    public void testTaskIDtoString() {
        TaskId WJCJUITHCZ = org.apache.hadoop.yarn.factory.providers.RecordFactoryProvider.getRecordFactory(null).newRecordInstance(TaskId.class);
        WJCJUITHCZ.setJobId(org.apache.hadoop.yarn.factory.providers.RecordFactoryProvider.getRecordFactory(null).newRecordInstance(JobId.class));
        WJCJUITHCZ.getJobId().setAppId(ApplicationId.newInstance(0, 0));
        WJCJUITHCZ.setTaskType(MAP);
        TaskType OJCUHYROIH = WJCJUITHCZ.getTaskType();
        System.err.println(OJCUHYROIH);
        OJCUHYROIH = TaskType.REDUCE;
        System.err.println(OJCUHYROIH);
        System.err.println(WJCJUITHCZ.getTaskType());
        assertEquals("task_0_0000_m_000000", MRApps.toString(WJCJUITHCZ));
        WJCJUITHCZ.setTaskType(REDUCE);
        assertEquals("task_0_0000_r_000000", MRApps.toString(WJCJUITHCZ));
    }

    @Test(timeout = 120000)
    public void testToTaskID() {
        TaskId QOFPLZMPLC = MRApps.toTaskID("task_1_2_r_3");
        assertEquals(1, QOFPLZMPLC.getJobId().getAppId().getClusterTimestamp());
        assertEquals(2, QOFPLZMPLC.getJobId().getAppId().getId());
        assertEquals(2, QOFPLZMPLC.getJobId().getId());
        assertEquals(REDUCE, QOFPLZMPLC.getTaskType());
        assertEquals(3, QOFPLZMPLC.getId());
        QOFPLZMPLC = MRApps.toTaskID("task_1_2_m_3");
        assertEquals(MAP, QOFPLZMPLC.getTaskType());
    }

    @Test(timeout = 120000, expected = IllegalArgumentException.class)
    public void testTaskIDShort() {
        MRApps.toTaskID("task_0_0000_m");
    }

    @Test(timeout = 120000, expected = IllegalArgumentException.class)
    public void testTaskIDBadType() {
        MRApps.toTaskID("task_0_0000_x_000000");
    }

    // TODO_get.set
    @Test(timeout = 120000)
    public void testTaskAttemptIDtoString() {
        TaskAttemptId YFYSUEMFYB = org.apache.hadoop.yarn.factory.providers.RecordFactoryProvider.getRecordFactory(null).newRecordInstance(TaskAttemptId.class);
        YFYSUEMFYB.setTaskId(org.apache.hadoop.yarn.factory.providers.RecordFactoryProvider.getRecordFactory(null).newRecordInstance(TaskId.class));
        YFYSUEMFYB.getTaskId().setTaskType(MAP);
        YFYSUEMFYB.getTaskId().setJobId(org.apache.hadoop.yarn.factory.providers.RecordFactoryProvider.getRecordFactory(null).newRecordInstance(JobId.class));
        YFYSUEMFYB.getTaskId().getJobId().setAppId(ApplicationId.newInstance(0, 0));
        assertEquals("attempt_0_0000_m_000000_0", MRApps.toString(YFYSUEMFYB));
    }

    @Test(timeout = 120000)
    public void testToTaskAttemptID() {
        TaskAttemptId DVMPREVUQB = MRApps.toTaskAttemptID("attempt_0_1_m_2_3");
        assertEquals(0, DVMPREVUQB.getTaskId().getJobId().getAppId().getClusterTimestamp());
        assertEquals(1, DVMPREVUQB.getTaskId().getJobId().getAppId().getId());
        assertEquals(1, DVMPREVUQB.getTaskId().getJobId().getId());
        assertEquals(2, DVMPREVUQB.getTaskId().getId());
        assertEquals(3, DVMPREVUQB.getId());
    }

    @Test(timeout = 120000, expected = IllegalArgumentException.class)
    public void testTaskAttemptIDShort() {
        MRApps.toTaskAttemptID("attempt_0_0_0_m_0");
    }

    @Test(timeout = 120000)
    public void testGetJobFileWithUser() {
        Configuration HZDWIPHOCY = new Configuration();
        HZDWIPHOCY.set(MR_AM_STAGING_DIR, "/my/path/to/staging");
        String USWQAQODNB = MRApps.getJobFile(HZDWIPHOCY, "dummy-user", new JobID("dummy-job", 12345));
        assertNotNull("getJobFile results in null.", USWQAQODNB);
        assertEquals("jobFile with specified user is not as expected.", "/my/path/to/staging/dummy-user/.staging/job_dummy-job_12345/job.xml", USWQAQODNB);
    }

    @Test(timeout = 120000)
    public void testSetClasspath() throws IOException {
        Configuration YSRISEXURJ = new Configuration();
        YSRISEXURJ.setBoolean(MAPREDUCE_APP_SUBMISSION_CROSS_PLATFORM, true);
        Job MGRLNBUBIX = Job.getInstance(YSRISEXURJ);
        Map<String, String> OAYBERZOLW = new HashMap<String, String>();
        MRApps.setClasspath(OAYBERZOLW, MGRLNBUBIX.getConfiguration());
        assertTrue(OAYBERZOLW.get("CLASSPATH").startsWith(PWD.$$() + ApplicationConstants.CLASS_PATH_SEPARATOR));
        String ARNHTLDGAE = MGRLNBUBIX.getConfiguration().get(YarnConfiguration.YARN_APPLICATION_CLASSPATH, StringUtils.join(",", DEFAULT_YARN_CROSS_PLATFORM_APPLICATION_CLASSPATH));
        if (ARNHTLDGAE != null) {
            ARNHTLDGAE = ARNHTLDGAE.replaceAll(",\\s*", CLASS_PATH_SEPARATOR).trim();
        }
        assertTrue(OAYBERZOLW.get("CLASSPATH").contains(ARNHTLDGAE));
        String WVYNVLOFJE = MGRLNBUBIX.getConfiguration().get(MAPREDUCE_APPLICATION_CLASSPATH, MRJobConfig.DEFAULT_MAPREDUCE_CROSS_PLATFORM_APPLICATION_CLASSPATH);
        if (WVYNVLOFJE != null) {
            WVYNVLOFJE = WVYNVLOFJE.replaceAll(",\\s*", CLASS_PATH_SEPARATOR).trim();
        }
        assertTrue(OAYBERZOLW.get("CLASSPATH").contains(WVYNVLOFJE));
    }

    @Test(timeout = 120000)
    public void testSetClasspathWithArchives() throws IOException {
        File SIWRJEIKMF = new File(TestMRApps.JRFRLTGKKO, "test.tgz");
        FileOutputStream DGMSIKRCVX = new FileOutputStream(SIWRJEIKMF);
        DGMSIKRCVX.write(0);
        DGMSIKRCVX.close();
        Configuration PTWNRFISWJ = new Configuration();
        PTWNRFISWJ.setBoolean(MAPREDUCE_APP_SUBMISSION_CROSS_PLATFORM, true);
        Job BHGDSDVAHS = Job.getInstance(PTWNRFISWJ);
        PTWNRFISWJ = BHGDSDVAHS.getConfiguration();
        String HWAIUIWBHM = FileSystem.getLocal(PTWNRFISWJ).makeQualified(new Path(SIWRJEIKMF.getAbsolutePath())).toString();
        PTWNRFISWJ.set(CLASSPATH_ARCHIVES, HWAIUIWBHM);
        PTWNRFISWJ.set(CACHE_ARCHIVES, HWAIUIWBHM + "#testTGZ");
        Map<String, String> FDHMOGSSMB = new HashMap<String, String>();
        MRApps.setClasspath(FDHMOGSSMB, PTWNRFISWJ);
        assertTrue(FDHMOGSSMB.get("CLASSPATH").startsWith(PWD.$$() + ApplicationConstants.CLASS_PATH_SEPARATOR));
        String YDQXXFNTTS = BHGDSDVAHS.getConfiguration().get(YarnConfiguration.YARN_APPLICATION_CLASSPATH, StringUtils.join(",", DEFAULT_YARN_CROSS_PLATFORM_APPLICATION_CLASSPATH));
        if (YDQXXFNTTS != null) {
            YDQXXFNTTS = YDQXXFNTTS.replaceAll(",\\s*", CLASS_PATH_SEPARATOR).trim();
        }
        assertTrue(FDHMOGSSMB.get("CLASSPATH").contains(YDQXXFNTTS));
        assertTrue(FDHMOGSSMB.get("CLASSPATH").contains("testTGZ"));
    }

    @Test(timeout = 120000)
    public void testSetClasspathWithUserPrecendence() {
        Configuration FVPEGJCHZQ = new Configuration();
        FVPEGJCHZQ.setBoolean(MAPREDUCE_APP_SUBMISSION_CROSS_PLATFORM, true);
        FVPEGJCHZQ.setBoolean(MAPREDUCE_JOB_USER_CLASSPATH_FIRST, true);
        Map<String, String> JEDICUBBTW = new HashMap<String, String>();
        try {
            MRApps.setClasspath(JEDICUBBTW, FVPEGJCHZQ);
        } catch (Exception e) {
            fail("Got exception while setting classpath");
        }
        String ZEBRCLVNSJ = JEDICUBBTW.get("CLASSPATH");
        String YJBTXYHBQT = StringUtils.join(CLASS_PATH_SEPARATOR, Arrays.asList(PWD.$$(), "job.jar/job.jar", "job.jar/classes/", "job.jar/lib/*", PWD.$$() + "/*"));
        assertTrue("MAPREDUCE_JOB_USER_CLASSPATH_FIRST set, but not taking effect!", ZEBRCLVNSJ.startsWith(YJBTXYHBQT));
    }

    @Test(timeout = 120000)
    public void testSetClasspathWithNoUserPrecendence() {
        Configuration BPGGMCPUFT = new Configuration();
        BPGGMCPUFT.setBoolean(MAPREDUCE_APP_SUBMISSION_CROSS_PLATFORM, true);
        BPGGMCPUFT.setBoolean(MAPREDUCE_JOB_USER_CLASSPATH_FIRST, false);
        Map<String, String> FTPAJDSDNH = new HashMap<String, String>();
        try {
            MRApps.setClasspath(FTPAJDSDNH, BPGGMCPUFT);
        } catch (Exception e) {
            fail("Got exception while setting classpath");
        }
        String RQUDMFHNGH = FTPAJDSDNH.get("CLASSPATH");
        String FJUFKDIONR = StringUtils.join(CLASS_PATH_SEPARATOR, Arrays.asList("job.jar/job.jar", "job.jar/classes/", "job.jar/lib/*", PWD.$$() + "/*"));
        assertTrue("MAPREDUCE_JOB_USER_CLASSPATH_FIRST false, and job.jar is not in" + " the classpath!", RQUDMFHNGH.contains(FJUFKDIONR));
        assertFalse("MAPREDUCE_JOB_USER_CLASSPATH_FIRST false, but taking effect!", RQUDMFHNGH.startsWith(FJUFKDIONR));
    }

    @Test(timeout = 120000)
    public void testSetClasspathWithJobClassloader() throws IOException {
        Configuration ODYAWDFXBC = new Configuration();
        ODYAWDFXBC.setBoolean(MAPREDUCE_APP_SUBMISSION_CROSS_PLATFORM, true);
        ODYAWDFXBC.setBoolean(MAPREDUCE_JOB_CLASSLOADER, true);
        Map<String, String> RQGUZRXQRL = new HashMap<String, String>();
        MRApps.setClasspath(RQGUZRXQRL, ODYAWDFXBC);
        String RENHESVTIS = RQGUZRXQRL.get("CLASSPATH");
        String TIFEWCLAYG = RQGUZRXQRL.get("APP_CLASSPATH");
        assertFalse("MAPREDUCE_JOB_CLASSLOADER true, but job.jar is in the" + " classpath!", RENHESVTIS.contains(("jar" + ApplicationConstants.CLASS_PATH_SEPARATOR) + "job"));
        assertFalse("MAPREDUCE_JOB_CLASSLOADER true, but PWD is in the classpath!", RENHESVTIS.contains("PWD"));
        String DSKDPFLGIM = StringUtils.join(CLASS_PATH_SEPARATOR, Arrays.asList(PWD.$$(), "job.jar/job.jar", "job.jar/classes/", "job.jar/lib/*", PWD.$$() + "/*"));
        assertEquals("MAPREDUCE_JOB_CLASSLOADER true, but job.jar is not in the app" + " classpath!", DSKDPFLGIM, TIFEWCLAYG);
    }

    @Test(timeout = 3000000)
    public void testSetClasspathWithFramework() throws IOException {
        final String XWLURBOOXX = "some-framework-name";
        final String IOEJREAQRA = "some-framework-path#" + XWLURBOOXX;
        Configuration YZDJYAKXQA = new Configuration();
        YZDJYAKXQA.setBoolean(MAPREDUCE_APP_SUBMISSION_CROSS_PLATFORM, true);
        YZDJYAKXQA.set(MAPREDUCE_APPLICATION_FRAMEWORK_PATH, IOEJREAQRA);
        Map<String, String> CJZZIOUFKL = new HashMap<String, String>();
        try {
            MRApps.setClasspath(CJZZIOUFKL, YZDJYAKXQA);
            fail("Failed to catch framework path set without classpath change");
        } catch (IllegalArgumentException e) {
            assertTrue("Unexpected IllegalArgumentException", e.getMessage().contains(("Could not locate MapReduce framework name '" + XWLURBOOXX) + "'"));
        }
        CJZZIOUFKL.clear();
        final String RSPMLSANYH = XWLURBOOXX + "/*.jar";
        YZDJYAKXQA.set(MAPREDUCE_APPLICATION_CLASSPATH, RSPMLSANYH);
        MRApps.setClasspath(CJZZIOUFKL, YZDJYAKXQA);
        final String ODKBVVAJRP = StringUtils.join(CLASS_PATH_SEPARATOR, Arrays.asList("job.jar/job.jar", "job.jar/classes/", "job.jar/lib/*", PWD.$$() + "/*"));
        String FZBTKQNNJC = StringUtils.join(CLASS_PATH_SEPARATOR, Arrays.asList(PWD.$$(), RSPMLSANYH, ODKBVVAJRP));
        assertEquals("Incorrect classpath with framework and no user precedence", FZBTKQNNJC, CJZZIOUFKL.get("CLASSPATH"));
        CJZZIOUFKL.clear();
        YZDJYAKXQA.setBoolean(MAPREDUCE_JOB_USER_CLASSPATH_FIRST, true);
        MRApps.setClasspath(CJZZIOUFKL, YZDJYAKXQA);
        FZBTKQNNJC = StringUtils.join(CLASS_PATH_SEPARATOR, Arrays.asList(PWD.$$(), ODKBVVAJRP, RSPMLSANYH));
        assertEquals("Incorrect classpath with framework and user precedence", FZBTKQNNJC, CJZZIOUFKL.get("CLASSPATH"));
    }

    @Test(timeout = 30000)
    public void testSetupDistributedCacheEmpty() throws IOException {
        Configuration UJNOLENMYE = new Configuration();
        Map<String, LocalResource> FFWIRPQYHT = new HashMap<String, LocalResource>();
        MRApps.setupDistributedCache(UJNOLENMYE, FFWIRPQYHT);
        assertTrue("Empty Config did not produce an empty list of resources", FFWIRPQYHT.isEmpty());
    }

    @SuppressWarnings("deprecation")
    @Test(timeout = 120000, expected = InvalidJobConfException.class)
    public void testSetupDistributedCacheConflicts() throws Exception {
        Configuration USZDYZYRSN = new Configuration();
        USZDYZYRSN.setClass("fs.mockfs.impl", TestMRApps.MockFileSystem.class, FileSystem.class);
        URI BRAJGEWFEO = URI.create("mockfs://mock/");
        FileSystem XQDJJGZHAU = ((FilterFileSystem) (FileSystem.get(BRAJGEWFEO, USZDYZYRSN))).getRawFileSystem();
        URI VIAQYLMMPP = new URI("mockfs://mock/tmp/something.zip#something");
        Path QQNQJSUTCP = new Path(VIAQYLMMPP);
        URI ELPRZQTEUM = new URI("mockfs://mock/tmp/something.txt#something");
        Path AFJQTCMXIV = new Path(ELPRZQTEUM);
        when(XQDJJGZHAU.resolvePath(QQNQJSUTCP)).thenReturn(QQNQJSUTCP);
        when(XQDJJGZHAU.resolvePath(AFJQTCMXIV)).thenReturn(AFJQTCMXIV);
        DistributedCache.addCacheArchive(VIAQYLMMPP, USZDYZYRSN);
        USZDYZYRSN.set(CACHE_ARCHIVES_TIMESTAMPS, "10");
        USZDYZYRSN.set(CACHE_ARCHIVES_SIZES, "10");
        USZDYZYRSN.set(CACHE_ARCHIVES_VISIBILITIES, "true");
        DistributedCache.addCacheFile(ELPRZQTEUM, USZDYZYRSN);
        USZDYZYRSN.set(CACHE_FILE_TIMESTAMPS, "11");
        USZDYZYRSN.set(CACHE_FILES_SIZES, "11");
        USZDYZYRSN.set(CACHE_FILE_VISIBILITIES, "true");
        Map<String, LocalResource> CPUCOBEJEN = new HashMap<String, LocalResource>();
        MRApps.setupDistributedCache(USZDYZYRSN, CPUCOBEJEN);
    }

    @SuppressWarnings("deprecation")
    @Test(timeout = 120000, expected = InvalidJobConfException.class)
    public void testSetupDistributedCacheConflictsFiles() throws Exception {
        Configuration EDHUGPLRGA = new Configuration();
        EDHUGPLRGA.setClass("fs.mockfs.impl", TestMRApps.MockFileSystem.class, FileSystem.class);
        URI EKXDSDLPGX = URI.create("mockfs://mock/");
        FileSystem KZRCTBOFXP = ((FilterFileSystem) (FileSystem.get(EKXDSDLPGX, EDHUGPLRGA))).getRawFileSystem();
        URI JMPIYINYEM = new URI("mockfs://mock/tmp/something.zip#something");
        Path ZBPMMONBFN = new Path(JMPIYINYEM);
        URI IGBQCTHYSR = new URI("mockfs://mock/tmp/something.txt#something");
        Path YKJLJOXGFM = new Path(IGBQCTHYSR);
        when(KZRCTBOFXP.resolvePath(ZBPMMONBFN)).thenReturn(ZBPMMONBFN);
        when(KZRCTBOFXP.resolvePath(YKJLJOXGFM)).thenReturn(YKJLJOXGFM);
        DistributedCache.addCacheFile(JMPIYINYEM, EDHUGPLRGA);
        DistributedCache.addCacheFile(IGBQCTHYSR, EDHUGPLRGA);
        EDHUGPLRGA.set(CACHE_FILE_TIMESTAMPS, "10,11");
        EDHUGPLRGA.set(CACHE_FILES_SIZES, "10,11");
        EDHUGPLRGA.set(CACHE_FILE_VISIBILITIES, "true,true");
        Map<String, LocalResource> EOWEEZDDBG = new HashMap<String, LocalResource>();
        MRApps.setupDistributedCache(EDHUGPLRGA, EOWEEZDDBG);
    }

    @SuppressWarnings("deprecation")
    @Test(timeout = 30000)
    public void testSetupDistributedCache() throws Exception {
        Configuration RHBKRLVDDG = new Configuration();
        RHBKRLVDDG.setClass("fs.mockfs.impl", TestMRApps.MockFileSystem.class, FileSystem.class);
        URI HFCUCDGWSZ = URI.create("mockfs://mock/");
        FileSystem WQWMMPVHFL = ((FilterFileSystem) (FileSystem.get(HFCUCDGWSZ, RHBKRLVDDG))).getRawFileSystem();
        URI DVBRGGUDJS = new URI("mockfs://mock/tmp/something.zip");
        Path ORLEUPAKKS = new Path(DVBRGGUDJS);
        URI MEEZHOCBBO = new URI("mockfs://mock/tmp/something.txt#something");
        Path TKJKJQHKRO = new Path(MEEZHOCBBO);
        when(WQWMMPVHFL.resolvePath(ORLEUPAKKS)).thenReturn(ORLEUPAKKS);
        when(WQWMMPVHFL.resolvePath(TKJKJQHKRO)).thenReturn(TKJKJQHKRO);
        DistributedCache.addCacheArchive(DVBRGGUDJS, RHBKRLVDDG);
        RHBKRLVDDG.set(CACHE_ARCHIVES_TIMESTAMPS, "10");
        RHBKRLVDDG.set(CACHE_ARCHIVES_SIZES, "10");
        RHBKRLVDDG.set(CACHE_ARCHIVES_VISIBILITIES, "true");
        DistributedCache.addCacheFile(MEEZHOCBBO, RHBKRLVDDG);
        RHBKRLVDDG.set(CACHE_FILE_TIMESTAMPS, "11");
        RHBKRLVDDG.set(CACHE_FILES_SIZES, "11");
        RHBKRLVDDG.set(CACHE_FILE_VISIBILITIES, "true");
        Map<String, LocalResource> IBOBUHHXAR = new HashMap<String, LocalResource>();
        MRApps.setupDistributedCache(RHBKRLVDDG, IBOBUHHXAR);
        assertEquals(2, IBOBUHHXAR.size());
        LocalResource KAHUVWYYVQ = IBOBUHHXAR.get("something.zip");
        assertNotNull(KAHUVWYYVQ);
        assertEquals(10L, KAHUVWYYVQ.getSize());
        assertEquals(10L, KAHUVWYYVQ.getTimestamp());
        assertEquals(LocalResourceType.ARCHIVE, KAHUVWYYVQ.getType());
        KAHUVWYYVQ = IBOBUHHXAR.get("something");
        assertNotNull(KAHUVWYYVQ);
        assertEquals(11L, KAHUVWYYVQ.getSize());
        assertEquals(11L, KAHUVWYYVQ.getTimestamp());
        assertEquals(LocalResourceType.FILE, KAHUVWYYVQ.getType());
    }

    static class MockFileSystem extends FilterFileSystem {
        MockFileSystem() {
            super(mock(FileSystem.class));
        }

        public void initialize(URI name, Configuration conf) throws IOException {
        }
    }

    @Test
    public void testLogSystemProperties() throws Exception {
        Configuration JSGNQTWTFC = new Configuration();
        // test no logging
        JSGNQTWTFC.set(MAPREDUCE_JVM_SYSTEM_PROPERTIES_TO_LOG, " ");
        String VULKNUUAJA = MRApps.getSystemPropertiesToLog(JSGNQTWTFC);
        assertNull(VULKNUUAJA);
        // test logging of selected keys
        String IJKSGXZNIQ = "java.class.path";
        String YBYQOKQEMK = "os.name";
        String COQRERTNXM = "java.version";
        JSGNQTWTFC.set(MAPREDUCE_JVM_SYSTEM_PROPERTIES_TO_LOG, (IJKSGXZNIQ + ", ") + YBYQOKQEMK);
        VULKNUUAJA = MRApps.getSystemPropertiesToLog(JSGNQTWTFC);
        assertNotNull(VULKNUUAJA);
        assertTrue(VULKNUUAJA.contains(IJKSGXZNIQ));
        assertTrue(VULKNUUAJA.contains(YBYQOKQEMK));
        assertFalse(VULKNUUAJA.contains(COQRERTNXM));
    }

    @Test
    public void testTaskStateUI() {
        assertTrue(PENDING.correspondsTo(SCHEDULED));
        assertTrue(COMPLETED.correspondsTo(SUCCEEDED));
        assertTrue(COMPLETED.correspondsTo(FAILED));
        assertTrue(COMPLETED.correspondsTo(KILLED));
        assertTrue(RUNNING.correspondsTo(TaskState.RUNNING));
    }

    private static final String[] PGRVLDHGCA = new String[]{ "/java/fake/Klass", "/javax/fake/Klass", "/org/apache/commons/logging/fake/Klass", "/org/apache/log4j/fake/Klass", "/org/apache/hadoop/fake/Klass" };

    private static final String[] WQCKBWJNGB = new String[]{ "core-default.xml", "mapred-default.xml", "hdfs-default.xml", "yarn-default.xml" };

    @Test
    public void testSystemClasses() {
        final List<String> TEFCNVUKSC = Arrays.asList(StringUtils.getTrimmedStrings(DEFAULT_SYSTEM_CLASSES));
        for (String OSBTFGGGEA : TestMRApps.WQCKBWJNGB) {
            assertTrue(OSBTFGGGEA + " must be system resource", ApplicationClassLoader.isSystemClass(OSBTFGGGEA, TEFCNVUKSC));
        }
        for (String FYTIFNQHFW : TestMRApps.PGRVLDHGCA) {
            assertTrue(FYTIFNQHFW + " must be system class", ApplicationClassLoader.isSystemClass(FYTIFNQHFW, TEFCNVUKSC));
        }
        assertFalse("/fake/Klass must not be a system class", ApplicationClassLoader.isSystemClass("/fake/Klass", TEFCNVUKSC));
    }
}