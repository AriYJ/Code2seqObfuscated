public class TestClusterId {
    private static final Log ACCRJPUYZA = LogFactory.getLog(TestClusterId.class);

    File UOWAJMVIUO;

    Configuration RIGEBYCQKH;

    private String getClusterId(Configuration EDRYCKOWCT) throws IOException {
        // see if cluster id not empty.
        Collection<URI> FUKASSIRJK = FSNamesystem.getNamespaceDirs(EDRYCKOWCT);
        List<URI> AFLDWUSQWZ = FSNamesystem.getNamespaceEditsDirs(EDRYCKOWCT);
        FSImage QFMQJPVOIN = new FSImage(EDRYCKOWCT, FUKASSIRJK, AFLDWUSQWZ);
        Iterator<StorageDirectory> VOWOWIXXWC = QFMQJPVOIN.getStorage().dirIterator(NNStorage.NameNodeDirType.IMAGE);
        StorageDirectory ODAFSKPBOK = VOWOWIXXWC.next();
        Properties NSLXKCTAXN = Storage.readPropertiesFile(ODAFSKPBOK.getVersionFile());
        String MFTCLKWVKV = NSLXKCTAXN.getProperty("clusterID");
        TestClusterId.ACCRJPUYZA.info((("successfully formated : sd=" + ODAFSKPBOK.getCurrentDir()) + ";cid=") + MFTCLKWVKV);
        return MFTCLKWVKV;
    }

    @Before
    public void setUp() throws IOException {
        ExitUtil.disableSystemExit();
        String UVPARVQKVZ = PathUtils.getTestDirName(getClass());
        UOWAJMVIUO = new File(UVPARVQKVZ, "dfs/name");
        if (UOWAJMVIUO.exists() && (!FileUtil.fullyDelete(UOWAJMVIUO))) {
            throw new IOException(("Could not delete test directory '" + UOWAJMVIUO) + "'");
        }
        TestClusterId.ACCRJPUYZA.info("hdfsdir is " + UOWAJMVIUO.getAbsolutePath());
        // as some tests might change these values we reset them to defaults before
        // every test
        FORMAT.setForceFormat(false);
        FORMAT.setInteractiveFormat(true);
        RIGEBYCQKH = new Configuration();
        RIGEBYCQKH.set(DFSConfigKeys.DFS_NAMENODE_NAME_DIR_KEY, UOWAJMVIUO.getPath());
    }

    @After
    public void tearDown() throws IOException {
        if (UOWAJMVIUO.exists() && (!FileUtil.fullyDelete(UOWAJMVIUO))) {
            throw new IOException(("Could not tearDown test directory '" + UOWAJMVIUO) + "'");
        }
    }

    @Test
    public void testFormatClusterIdOption() throws IOException {
        // 1. should format without cluster id
        // StartupOption.FORMAT.setClusterId("");
        NameNode.format(RIGEBYCQKH);
        // see if cluster id not empty.
        String DPUQKNKJEN = getClusterId(RIGEBYCQKH);
        assertTrue("Didn't get new ClusterId", (DPUQKNKJEN != null) && (!DPUQKNKJEN.equals("")));
        // 2. successful format with given clusterid
        FORMAT.setClusterId("mycluster");
        NameNode.format(RIGEBYCQKH);
        // see if cluster id matches with given clusterid.
        DPUQKNKJEN = getClusterId(RIGEBYCQKH);
        assertTrue("ClusterId didn't match", DPUQKNKJEN.equals("mycluster"));
        // 3. format without any clusterid again. It should generate new
        // clusterid.
        FORMAT.setClusterId("");
        NameNode.format(RIGEBYCQKH);
        String TCCZRMYVGV = getClusterId(RIGEBYCQKH);
        assertFalse("ClusterId should not be the same", TCCZRMYVGV.equals(DPUQKNKJEN));
    }

    /**
     * Test namenode format with -format option. Format should succeed.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormat() throws IOException {
        String[] ZYVPDIJLLA = new String[]{ "-format" };
        try {
            NameNode.createNameNode(ZYVPDIJLLA, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should have succeeded", 0, e.status);
        }
        String JTGXXVCGJQ = getClusterId(RIGEBYCQKH);
        assertTrue("Didn't get new ClusterId", (JTGXXVCGJQ != null) && (!JTGXXVCGJQ.equals("")));
    }

    /**
     * Test namenode format with -format option when an empty name directory
     * exists. Format should succeed.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithEmptyDir() throws IOException {
        if (!UOWAJMVIUO.mkdirs()) {
            fail("Failed to create dir " + UOWAJMVIUO.getPath());
        }
        String[] VIKCMZSLZB = new String[]{ "-format" };
        try {
            NameNode.createNameNode(VIKCMZSLZB, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should have succeeded", 0, e.status);
        }
        String KZFRVVVCVL = getClusterId(RIGEBYCQKH);
        assertTrue("Didn't get new ClusterId", (KZFRVVVCVL != null) && (!KZFRVVVCVL.equals("")));
    }

    /**
     * Test namenode format with -format -force options when name directory
     * exists. Format should succeed.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithForce() throws IOException {
        if (!UOWAJMVIUO.mkdirs()) {
            fail("Failed to create dir " + UOWAJMVIUO.getPath());
        }
        String[] YPSATOGYPX = new String[]{ "-format", "-force" };
        try {
            NameNode.createNameNode(YPSATOGYPX, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should have succeeded", 0, e.status);
        }
        String QDXSPOOPKO = getClusterId(RIGEBYCQKH);
        assertTrue("Didn't get new ClusterId", (QDXSPOOPKO != null) && (!QDXSPOOPKO.equals("")));
    }

    /**
     * Test namenode format with -format -force -clusterid option when name
     * directory exists. Format should succeed.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithForceAndClusterId() throws IOException {
        if (!UOWAJMVIUO.mkdirs()) {
            fail("Failed to create dir " + UOWAJMVIUO.getPath());
        }
        String ZMHGZHTVDL = "testFormatWithForceAndClusterId";
        String[] JQSLBSBFDN = new String[]{ "-format", "-force", "-clusterid", ZMHGZHTVDL };
        try {
            NameNode.createNameNode(JQSLBSBFDN, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should have succeeded", 0, e.status);
        }
        String HUDNWNIXYJ = getClusterId(RIGEBYCQKH);
        assertEquals("ClusterIds do not match", ZMHGZHTVDL, HUDNWNIXYJ);
    }

    /**
     * Test namenode format with -clusterid -force option. Format command should
     * fail as no cluster id was provided.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithInvalidClusterIdOption() throws IOException {
        String[] HCEQDYXBHF = new String[]{ "-format", "-clusterid", "-force" };
        PrintStream VJQFZVKKFT = System.err;
        ByteArrayOutputStream JUIHGLJBOV = new ByteArrayOutputStream();
        PrintStream ISTPVYGHKY = new PrintStream(JUIHGLJBOV);
        System.setErr(ISTPVYGHKY);
        NameNode.createNameNode(HCEQDYXBHF, RIGEBYCQKH);
        // Check if usage is printed
        assertTrue(JUIHGLJBOV.toString("UTF-8").contains("Usage: java NameNode"));
        System.setErr(VJQFZVKKFT);
        // check if the version file does not exists.
        File DZBIFFIVRK = new File(UOWAJMVIUO, "current/VERSION");
        assertFalse("Check version should not exist", DZBIFFIVRK.exists());
    }

    /**
     * Test namenode format with -format -clusterid options. Format should fail
     * was no clusterid was sent.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithNoClusterIdOption() throws IOException {
        String[] NZJAPEYFRU = new String[]{ "-format", "-clusterid" };
        PrintStream GGUFLJZQWR = System.err;
        ByteArrayOutputStream TXAVMUKNPI = new ByteArrayOutputStream();
        PrintStream MVZOEDIVJI = new PrintStream(TXAVMUKNPI);
        System.setErr(MVZOEDIVJI);
        NameNode.createNameNode(NZJAPEYFRU, RIGEBYCQKH);
        // Check if usage is printed
        assertTrue(TXAVMUKNPI.toString("UTF-8").contains("Usage: java NameNode"));
        System.setErr(GGUFLJZQWR);
        // check if the version file does not exists.
        File VCVVNQFKEK = new File(UOWAJMVIUO, "current/VERSION");
        assertFalse("Check version should not exist", VCVVNQFKEK.exists());
    }

    /**
     * Test namenode format with -format -clusterid and empty clusterid. Format
     * should fail as no valid if was provided.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithEmptyClusterIdOption() throws IOException {
        String[] NUJJISADLM = new String[]{ "-format", "-clusterid", "" };
        PrintStream MJSGMFKXFV = System.err;
        ByteArrayOutputStream VHNOLUJRZY = new ByteArrayOutputStream();
        PrintStream PRQTPCGUGR = new PrintStream(VHNOLUJRZY);
        System.setErr(PRQTPCGUGR);
        NameNode.createNameNode(NUJJISADLM, RIGEBYCQKH);
        // Check if usage is printed
        assertTrue(VHNOLUJRZY.toString("UTF-8").contains("Usage: java NameNode"));
        System.setErr(MJSGMFKXFV);
        // check if the version file does not exists.
        File QTHVAJHCQB = new File(UOWAJMVIUO, "current/VERSION");
        assertFalse("Check version should not exist", QTHVAJHCQB.exists());
    }

    /**
     * Test namenode format with -format -nonInteractive options when a non empty
     * name directory exists. Format should not succeed.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithNonInteractive() throws IOException {
        // we check for a non empty dir, so create a child path
        File ZHAWTTEQVQ = new File(UOWAJMVIUO, "file");
        if (!ZHAWTTEQVQ.mkdirs()) {
            fail("Failed to create dir " + ZHAWTTEQVQ.getPath());
        }
        String[] UQOVFXTUFQ = new String[]{ "-format", "-nonInteractive" };
        try {
            NameNode.createNameNode(UQOVFXTUFQ, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should have been aborted with exit code 1", 1, e.status);
        }
        // check if the version file does not exists.
        File BIHZNBOJIY = new File(UOWAJMVIUO, "current/VERSION");
        assertFalse("Check version should not exist", BIHZNBOJIY.exists());
    }

    /**
     * Test namenode format with -format -nonInteractive options when name
     * directory does not exist. Format should succeed.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithNonInteractiveNameDirDoesNotExit() throws IOException {
        String[] GTXGTLGMQW = new String[]{ "-format", "-nonInteractive" };
        try {
            NameNode.createNameNode(GTXGTLGMQW, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should have succeeded", 0, e.status);
        }
        String ZVAILQSJXQ = getClusterId(RIGEBYCQKH);
        assertTrue("Didn't get new ClusterId", (ZVAILQSJXQ != null) && (!ZVAILQSJXQ.equals("")));
    }

    /**
     * Test namenode format with -force -nonInteractive -force option. Format
     * should succeed.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testFormatWithNonInteractiveAndForce() throws IOException {
        if (!UOWAJMVIUO.mkdirs()) {
            fail("Failed to create dir " + UOWAJMVIUO.getPath());
        }
        String[] KAVVAPTMYR = new String[]{ "-format", "-nonInteractive", "-force" };
        try {
            NameNode.createNameNode(KAVVAPTMYR, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should have succeeded", 0, e.status);
        }
        String UWPOODEOKT = getClusterId(RIGEBYCQKH);
        assertTrue("Didn't get new ClusterId", (UWPOODEOKT != null) && (!UWPOODEOKT.equals("")));
    }

    /**
     * Test namenode format with -format option when a non empty name directory
     * exists. Enter Y when prompted and the format should succeed.
     *
     * @throws IOException
     * 		
     * @throws InterruptedException
     * 		
     */
    @Test
    public void testFormatWithoutForceEnterYes() throws IOException, InterruptedException {
        // we check for a non empty dir, so create a child path
        File EBBKUGCUKD = new File(UOWAJMVIUO, "file");
        if (!EBBKUGCUKD.mkdirs()) {
            fail("Failed to create dir " + EBBKUGCUKD.getPath());
        }
        // capture the input stream
        InputStream NNJHCWAARU = System.in;
        ByteArrayInputStream RBSWSWMSBX = new ByteArrayInputStream("Y\n".getBytes());
        System.setIn(RBSWSWMSBX);
        String[] LMZYAHWSQY = new String[]{ "-format" };
        try {
            NameNode.createNameNode(LMZYAHWSQY, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should have succeeded", 0, e.status);
        }
        System.setIn(NNJHCWAARU);
        String QGZYPCSMNX = getClusterId(RIGEBYCQKH);
        assertTrue("Didn't get new ClusterId", (QGZYPCSMNX != null) && (!QGZYPCSMNX.equals("")));
    }

    /**
     * Test namenode format with -format option when a non empty name directory
     * exists. Enter N when prompted and format should be aborted.
     *
     * @throws IOException
     * 		
     * @throws InterruptedException
     * 		
     */
    @Test
    public void testFormatWithoutForceEnterNo() throws IOException, InterruptedException {
        // we check for a non empty dir, so create a child path
        File QHOMWJFTWX = new File(UOWAJMVIUO, "file");
        if (!QHOMWJFTWX.mkdirs()) {
            fail("Failed to create dir " + QHOMWJFTWX.getPath());
        }
        // capture the input stream
        InputStream NSRCNCEPPB = System.in;
        ByteArrayInputStream KMTWHINWOI = new ByteArrayInputStream("N\n".getBytes());
        System.setIn(KMTWHINWOI);
        String[] MXWRDSNKPC = new String[]{ "-format" };
        try {
            NameNode.createNameNode(MXWRDSNKPC, RIGEBYCQKH);
            fail("createNameNode() did not call System.exit()");
        } catch (ExitException e) {
            assertEquals("Format should not have succeeded", 1, e.status);
        }
        System.setIn(NSRCNCEPPB);
        // check if the version file does not exists.
        File GVKZYQVTDR = new File(UOWAJMVIUO, "current/VERSION");
        assertFalse("Check version should not exist", GVKZYQVTDR.exists());
    }
}