public final class AzureMetricsTestUtil {
    public static long getLongGaugeValue(AzureFileSystemInstrumentation RIHHNFHOCK, String FULCSPYKQB) {
        return getLongGauge(FULCSPYKQB, getMetrics(RIHHNFHOCK));
    }

    /**
     * Gets the current value of the given counter.
     */
    public static long getLongCounterValue(AzureFileSystemInstrumentation JXLFEGIVEF, String JSFZGSIUVX) {
        return getLongCounter(JSFZGSIUVX, getMetrics(JXLFEGIVEF));
    }

    /**
     * Gets the current value of the wasb_bytes_written_last_second counter.
     */
    public static long getCurrentBytesWritten(AzureFileSystemInstrumentation MVQZRIRRLS) {
        return AzureMetricsTestUtil.getLongGaugeValue(MVQZRIRRLS, AzureFileSystemInstrumentation.WASB_BYTES_WRITTEN);
    }

    /**
     * Gets the current value of the wasb_bytes_read_last_second counter.
     */
    public static long getCurrentBytesRead(AzureFileSystemInstrumentation XCWKHPPAUO) {
        return AzureMetricsTestUtil.getLongGaugeValue(XCWKHPPAUO, AzureFileSystemInstrumentation.WASB_BYTES_READ);
    }

    /**
     * Gets the current value of the wasb_raw_bytes_uploaded counter.
     */
    public static long getCurrentTotalBytesWritten(AzureFileSystemInstrumentation UZUTLANMJM) {
        return AzureMetricsTestUtil.getLongCounterValue(UZUTLANMJM, AzureFileSystemInstrumentation.WASB_RAW_BYTES_UPLOADED);
    }

    /**
     * Gets the current value of the wasb_raw_bytes_downloaded counter.
     */
    public static long getCurrentTotalBytesRead(AzureFileSystemInstrumentation QGOBNNQNON) {
        return AzureMetricsTestUtil.getLongCounterValue(QGOBNNQNON, AzureFileSystemInstrumentation.WASB_RAW_BYTES_DOWNLOADED);
    }

    /**
     * Gets the current value of the asv_web_responses counter.
     */
    public static long getCurrentWebResponses(AzureFileSystemInstrumentation OQXSYRLCVZ) {
        return getLongCounter(AzureFileSystemInstrumentation.WASB_WEB_RESPONSES, getMetrics(OQXSYRLCVZ));
    }
}