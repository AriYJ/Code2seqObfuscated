public class ContainerEvent extends AbstractEvent<ContainerEventType> {
    private final ContainerId CGIWFNZRVT;

    public ContainerEvent(ContainerId YOHHOJEMXX, ContainerEventType NNGADDCWGU) {
        super(NNGADDCWGU);
        this.CGIWFNZRVT = YOHHOJEMXX;
    }

    public ContainerId getContainerID() {
        return CGIWFNZRVT;
    }
}