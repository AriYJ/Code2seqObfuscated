@Private
@Unstable
public class RefreshSuperUserGroupsConfigurationRequestPBImpl extends RefreshSuperUserGroupsConfigurationRequest {
    RefreshSuperUserGroupsConfigurationRequestProto FSEVSTHGGU = RefreshSuperUserGroupsConfigurationRequestProto.getDefaultInstance();

    Builder RELKRHWSBF = null;

    boolean UNIHVVXXDO = false;

    public RefreshSuperUserGroupsConfigurationRequestPBImpl() {
        RELKRHWSBF = RefreshSuperUserGroupsConfigurationRequestProto.newBuilder();
    }

    public RefreshSuperUserGroupsConfigurationRequestPBImpl(RefreshSuperUserGroupsConfigurationRequestProto PHWIWYRXGK) {
        this.FSEVSTHGGU = PHWIWYRXGK;
        UNIHVVXXDO = true;
    }

    public RefreshSuperUserGroupsConfigurationRequestProto getProto() {
        FSEVSTHGGU = (UNIHVVXXDO) ? FSEVSTHGGU : RELKRHWSBF.build();
        UNIHVVXXDO = true;
        return FSEVSTHGGU;
    }

    @Override
    public int hashCode() {
        return getProto().hashCode();
    }

    @Override
    public boolean equals(Object LRZBNWTJIA) {
        if (LRZBNWTJIA == null)
            return false;

        if (LRZBNWTJIA.getClass().isAssignableFrom(this.getClass())) {
            return this.getProto().equals(this.getClass().cast(LRZBNWTJIA).getProto());
        }
        return false;
    }

    @Override
    public String toString() {
        return TextFormat.shortDebugString(getProto());
    }
}