/**
 * The event signifying that a container has been reserved.
 *
 * The event encapsulates information on the amount of reservation
 * and the node on which the reservation is in effect.
 */
public class RMContainerReservedEvent extends RMContainerEvent {
    private final Resource GGOMJGVISX;

    private final NodeId EXWTRFZEHR;

    private final Priority SHWYFQEZYO;

    public RMContainerReservedEvent(ContainerId JFQYWGHQCU, Resource NKNQOGHUYB, NodeId FLTMXIBXVV, Priority MAJNGFQEQO) {
        super(JFQYWGHQCU, RESERVED);
        this.GGOMJGVISX = NKNQOGHUYB;
        this.EXWTRFZEHR = FLTMXIBXVV;
        this.SHWYFQEZYO = MAJNGFQEQO;
    }

    public Resource getReservedResource() {
        return GGOMJGVISX;
    }

    public NodeId getReservedNode() {
        return EXWTRFZEHR;
    }

    public Priority getReservedPriority() {
        return SHWYFQEZYO;
    }
}