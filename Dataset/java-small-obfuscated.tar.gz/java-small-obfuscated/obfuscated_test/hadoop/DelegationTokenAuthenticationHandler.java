/**
 * An {@link AuthenticationHandler} that implements Kerberos SPNEGO mechanism
 * for HTTP and supports Delegation Token functionality.
 * <p/>
 * In addition to the wrapped {@link AuthenticationHandler} configuration
 * properties, this handler supports the following properties prefixed
 * with the type of the wrapped <code>AuthenticationHandler</code>:
 * <ul>
 * <li>delegation-token.token-kind: the token kind for generated tokens
 * (no default, required property).</li>
 * <li>delegation-token.update-interval.sec: secret manager master key
 * update interval in seconds (default 1 day).</li>
 * <li>delegation-token.max-lifetime.sec: maximum life of a delegation
 * token in seconds (default 7 days).</li>
 * <li>delegation-token.renewal-interval.sec: renewal interval for
 * delegation tokens in seconds (default 1 day).</li>
 * <li>delegation-token.removal-scan-interval.sec: delegation tokens
 * removal scan interval in seconds (default 1 hour).</li>
 * </ul>
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public abstract class DelegationTokenAuthenticationHandler implements AuthenticationHandler {
    protected static final String SSLRSQGGNZ = "-dt";

    public static final String LUSTYAMEUS = "delegation-token.";

    public static final String XIAXSBSDEY = DelegationTokenAuthenticationHandler.LUSTYAMEUS + "token-kind";

    public static final String VDGMXHQEPS = DelegationTokenAuthenticationHandler.LUSTYAMEUS + "update-interval.sec";

    public static final long EYJJCKUBDX = (24 * 60) * 60;

    public static final String QQVQFSXOVD = DelegationTokenAuthenticationHandler.LUSTYAMEUS + "max-lifetime.sec";

    public static final long KXZZQCLMGW = ((7 * 24) * 60) * 60;

    public static final String XULKRGPRBV = DelegationTokenAuthenticationHandler.LUSTYAMEUS + "renew-interval.sec";

    public static final long VUJXVSLZGY = (24 * 60) * 60;

    public static final String UQCYOCWCXR = DelegationTokenAuthenticationHandler.LUSTYAMEUS + "removal-scan-interval.sec";

    public static final long CKONSZBZWH = 60 * 60;

    private static final Set<String> RIQLDXYQVA = new HashSet<String>();

    static final String MQOWJZFXJF = "hadoop.security.delegation-token.ugi";

    static {
        DelegationTokenAuthenticationHandler.RIQLDXYQVA.add(GETDELEGATIONTOKEN.toString());
        DelegationTokenAuthenticationHandler.RIQLDXYQVA.add(RENEWDELEGATIONTOKEN.toString());
        DelegationTokenAuthenticationHandler.RIQLDXYQVA.add(CANCELDELEGATIONTOKEN.toString());
    }

    private AuthenticationHandler DWGYMDMPIA;

    private DelegationTokenManager XZETHWYLAM;

    private String UHKHFUNOYC;

    public DelegationTokenAuthenticationHandler(AuthenticationHandler OCIAAFMJUP) {
        DWGYMDMPIA = OCIAAFMJUP;
        UHKHFUNOYC = OCIAAFMJUP.getType();
    }

    @VisibleForTesting
    DelegationTokenManager getTokenManager() {
        return XZETHWYLAM;
    }

    @Override
    public void init(Properties EGZGBHGJQP) throws ServletException {
        DWGYMDMPIA.init(EGZGBHGJQP);
        initTokenManager(EGZGBHGJQP);
    }

    /**
     * Sets an external <code>DelegationTokenSecretManager</code> instance to
     * manage creation and verification of Delegation Tokens.
     * <p/>
     * This is useful for use cases where secrets must be shared across multiple
     * services.
     *
     * @param secretManager
     * 		a <code>DelegationTokenSecretManager</code> instance
     */
    public void setExternalDelegationTokenSecretManager(AbstractDelegationTokenSecretManager YBRHGCJJXB) {
        XZETHWYLAM.setExternalDelegationTokenSecretManager(YBRHGCJJXB);
    }

    @VisibleForTesting
    @SuppressWarnings("unchecked")
    public void initTokenManager(Properties LEXUJMNUAQ) {
        String AMRRAXBLTM = DWGYMDMPIA.getType() + ".";
        Configuration NAKYJOGIEB = new Configuration(false);
        for (Map.Entry PQKSUQCGLT : LEXUJMNUAQ.entrySet()) {
            NAKYJOGIEB.set(((String) (PQKSUQCGLT.getKey())), ((String) (PQKSUQCGLT.getValue())));
        }
        String QIRONOQDMQ = NAKYJOGIEB.get(DelegationTokenAuthenticationHandler.XIAXSBSDEY);
        if (QIRONOQDMQ == null) {
            throw new IllegalArgumentException("The configuration does not define the token kind");
        }
        QIRONOQDMQ = QIRONOQDMQ.trim();
        long HFBZIPELUZ = NAKYJOGIEB.getLong(AMRRAXBLTM + DelegationTokenAuthenticationHandler.VDGMXHQEPS, DelegationTokenAuthenticationHandler.EYJJCKUBDX);
        long QHVLKLVBOO = NAKYJOGIEB.getLong(AMRRAXBLTM + DelegationTokenAuthenticationHandler.QQVQFSXOVD, DelegationTokenAuthenticationHandler.KXZZQCLMGW);
        long GMGRMNYRFW = NAKYJOGIEB.getLong(AMRRAXBLTM + DelegationTokenAuthenticationHandler.XULKRGPRBV, DelegationTokenAuthenticationHandler.VUJXVSLZGY);
        long HZEDQIWUFV = NAKYJOGIEB.getLong(AMRRAXBLTM + DelegationTokenAuthenticationHandler.UQCYOCWCXR, DelegationTokenAuthenticationHandler.CKONSZBZWH);
        XZETHWYLAM = new DelegationTokenManager(new Text(QIRONOQDMQ), HFBZIPELUZ * 1000, QHVLKLVBOO * 1000, GMGRMNYRFW * 1000, HZEDQIWUFV * 1000);
        XZETHWYLAM.init();
    }

    @Override
    public void destroy() {
        XZETHWYLAM.destroy();
        DWGYMDMPIA.destroy();
    }

    @Override
    public String getType() {
        return UHKHFUNOYC;
    }

    private static final String XZRVCSMTZW = System.getProperty("line.separator");

    @Override
    @SuppressWarnings("unchecked")
    public boolean managementOperation(AuthenticationToken QGDHLZCXRU, HttpServletRequest QGZVPXMHSH, HttpServletResponse YEYJFARBCH) throws IOException, AuthenticationException {
        boolean LDFICNAORZ = true;
        String SXURKBIBVL = ServletUtils.getParameter(QGZVPXMHSH, OP_PARAM);
        SXURKBIBVL = (SXURKBIBVL != null) ? SXURKBIBVL.toUpperCase() : null;
        if (DelegationTokenAuthenticationHandler.RIQLDXYQVA.contains(SXURKBIBVL) && (!QGZVPXMHSH.getMethod().equals("OPTIONS"))) {
            KerberosDelegationTokenAuthenticator.DelegationTokenOperation NKTQMWFIKO = DelegationTokenOperation.valueOf(SXURKBIBVL);
            if (NKTQMWFIKO.getHttpMethod().equals(QGZVPXMHSH.getMethod())) {
                boolean SLVOEKIJID;
                if (NKTQMWFIKO.requiresKerberosCredentials() && (QGDHLZCXRU == null)) {
                    QGDHLZCXRU = authenticate(QGZVPXMHSH, YEYJFARBCH);
                    if (QGDHLZCXRU == null) {
                        LDFICNAORZ = false;
                        SLVOEKIJID = false;
                    } else {
                        SLVOEKIJID = true;
                    }
                } else {
                    SLVOEKIJID = true;
                }
                if (SLVOEKIJID) {
                    UserGroupInformation BDTKBOYDOJ = (QGDHLZCXRU != null) ? UserGroupInformation.createRemoteUser(QGDHLZCXRU.getUserName()) : null;
                    Map XYGENMBYLO = null;
                    switch (NKTQMWFIKO) {
                        case GETDELEGATIONTOKEN :
                            if (BDTKBOYDOJ == null) {
                                throw new IllegalStateException("request UGI cannot be NULL");
                            }
                            String RGMBOAYZXO = ServletUtils.getParameter(QGZVPXMHSH, RENEWER_PARAM);
                            try {
                                Token<?> HVJHKDCVAY = XZETHWYLAM.createToken(BDTKBOYDOJ, RGMBOAYZXO);
                                XYGENMBYLO = DelegationTokenAuthenticationHandler.delegationTokenToJSON(HVJHKDCVAY);
                            } catch (IOException ex) {
                                throw new AuthenticationException(ex.toString(), ex);
                            }
                            break;
                        case RENEWDELEGATIONTOKEN :
                            if (BDTKBOYDOJ == null) {
                                throw new IllegalStateException("request UGI cannot be NULL");
                            }
                            String PLZSKXWNGN = ServletUtils.getParameter(QGZVPXMHSH, TOKEN_PARAM);
                            if (PLZSKXWNGN == null) {
                                YEYJFARBCH.sendError(SC_BAD_REQUEST, MessageFormat.format("Operation [{0}] requires the parameter [{1}]", NKTQMWFIKO, TOKEN_PARAM));
                                LDFICNAORZ = false;
                            } else {
                                Token<DelegationTokenIdentifier> HUFCIIJBYG = new Token<DelegationTokenIdentifier>();
                                try {
                                    HUFCIIJBYG.decodeFromUrlString(PLZSKXWNGN);
                                    long DMHXKEGEKD = XZETHWYLAM.renewToken(HUFCIIJBYG, BDTKBOYDOJ.getShortUserName());
                                    XYGENMBYLO = new HashMap();
                                    XYGENMBYLO.put("long", DMHXKEGEKD);
                                } catch (IOException ex) {
                                    throw new AuthenticationException(ex.toString(), ex);
                                }
                            }
                            break;
                        case CANCELDELEGATIONTOKEN :
                            String PYYLUTQDTU = ServletUtils.getParameter(QGZVPXMHSH, TOKEN_PARAM);
                            if (PYYLUTQDTU == null) {
                                YEYJFARBCH.sendError(SC_BAD_REQUEST, MessageFormat.format("Operation [{0}] requires the parameter [{1}]", NKTQMWFIKO, TOKEN_PARAM));
                                LDFICNAORZ = false;
                            } else {
                                Token<DelegationTokenIdentifier> ITNPBLMACO = new Token<DelegationTokenIdentifier>();
                                try {
                                    ITNPBLMACO.decodeFromUrlString(PYYLUTQDTU);
                                    XZETHWYLAM.cancelToken(ITNPBLMACO, BDTKBOYDOJ != null ? BDTKBOYDOJ.getShortUserName() : null);
                                } catch (IOException ex) {
                                    YEYJFARBCH.sendError(SC_NOT_FOUND, "Invalid delegation token, cannot cancel");
                                    LDFICNAORZ = false;
                                }
                            }
                            break;
                    }
                    if (LDFICNAORZ) {
                        YEYJFARBCH.setStatus(SC_OK);
                        if (XYGENMBYLO != null) {
                            YEYJFARBCH.setContentType(APPLICATION_JSON);
                            Writer XQUBQMYDQC = YEYJFARBCH.getWriter();
                            ObjectMapper CFADQMMJUX = new ObjectMapper();
                            CFADQMMJUX.writeValue(XQUBQMYDQC, XYGENMBYLO);
                            XQUBQMYDQC.write(DelegationTokenAuthenticationHandler.XZRVCSMTZW);
                            XQUBQMYDQC.flush();
                        }
                        LDFICNAORZ = false;
                    }
                }
            } else {
                YEYJFARBCH.sendError(SC_BAD_REQUEST, MessageFormat.format("Wrong HTTP method [{0}] for operation [{1}], it should be " + "[{2}]", QGZVPXMHSH.getMethod(), NKTQMWFIKO, NKTQMWFIKO.getHttpMethod()));
                LDFICNAORZ = false;
            }
        }
        return LDFICNAORZ;
    }

    @SuppressWarnings("unchecked")
    private static Map delegationTokenToJSON(Token WJINZFVSKH) throws IOException {
        Map MMQKIKKPUW = new LinkedHashMap();
        MMQKIKKPUW.put(DELEGATION_TOKEN_URL_STRING_JSON, WJINZFVSKH.encodeToUrlString());
        Map VZUBKFISIV = new LinkedHashMap();
        VZUBKFISIV.put(DELEGATION_TOKEN_JSON, MMQKIKKPUW);
        return VZUBKFISIV;
    }

    /**
     * Authenticates a request looking for the <code>delegation</code>
     * query-string parameter and verifying it is a valid token. If there is not
     * <code>delegation</code> query-string parameter, it delegates the
     * authentication to the {@link KerberosAuthenticationHandler} unless it is
     * disabled.
     *
     * @param request
     * 		the HTTP client request.
     * @param response
     * 		the HTTP client response.
     * @return the authentication token for the authenticated request.
     * @throws IOException
     * 		thrown if an IO error occurred.
     * @throws AuthenticationException
     * 		thrown if the authentication failed.
     */
    @Override
    public AuthenticationToken authenticate(HttpServletRequest RGIAMCHOWU, HttpServletResponse HRCSXJIKTZ) throws IOException, AuthenticationException {
        AuthenticationToken PODPGSQIYK;
        String BFSWIPOYZW = ServletUtils.getParameter(RGIAMCHOWU, DELEGATION_PARAM);
        if (BFSWIPOYZW != null) {
            try {
                Token<DelegationTokenIdentifier> KUELVVCXMG = new Token<DelegationTokenIdentifier>();
                KUELVVCXMG.decodeFromUrlString(BFSWIPOYZW);
                UserGroupInformation XTYNOFQRVR = XZETHWYLAM.verifyToken(KUELVVCXMG);
                final String AAOPNPOEOV = XTYNOFQRVR.getShortUserName();
                // creating a ephemeral token
                PODPGSQIYK = new AuthenticationToken(AAOPNPOEOV, XTYNOFQRVR.getUserName(), getType());
                PODPGSQIYK.setExpires(0);
                RGIAMCHOWU.setAttribute(DelegationTokenAuthenticationHandler.MQOWJZFXJF, XTYNOFQRVR);
            } catch (Throwable ex) {
                throw new AuthenticationException("Could not verify DelegationToken, " + ex.toString(), ex);
            }
        } else {
            PODPGSQIYK = DWGYMDMPIA.authenticate(RGIAMCHOWU, HRCSXJIKTZ);
        }
        return PODPGSQIYK;
    }
}