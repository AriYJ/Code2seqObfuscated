/**
 * Handles the upward (C++ to Java) messages from the application.
 */
class OutputHandler<K extends WritableComparable, V extends Writable> implements UpwardProtocol<K, V> {
    private Reporter YHLNCJGHCT;

    private OutputCollector<K, V> PZIBKWDJUX;

    private float AAILQOAJUS = 0.0F;

    private boolean RYKMTGEQXS = false;

    private Throwable LNVAZAJTGW = null;

    RecordReader<FloatWritable, NullWritable> WMCVJDOHPV = null;

    private Map<Integer, Counters.Counter> EKAKXTAAYZ = new HashMap<Integer, Counters.Counter>();

    private String CMMUYWCFDS = null;

    private boolean BYBEPSKVRC = false;

    /**
     * Create a handler that will handle any records output from the application.
     *
     * @param collector
     * 		the "real" collector that takes the output
     * @param reporter
     * 		the reporter for reporting progress
     */
    public OutputHandler(OutputCollector<K, V> MLKXOANBKP, Reporter JGTXJFXDPO, RecordReader<FloatWritable, NullWritable> QEEWPGJPRF, String IQNNIYQWUQ) {
        this.reporter = JGTXJFXDPO;
        this.collector = MLKXOANBKP;
        this.recordReader = QEEWPGJPRF;
        this.expectedDigest = IQNNIYQWUQ;
    }

    /**
     * The task output a normal record.
     */
    public void output(K BUHALUFSCX, V EMYGHHDEUX) throws IOException {
        PZIBKWDJUX.collect(BUHALUFSCX, EMYGHHDEUX);
    }

    /**
     * The task output a record with a partition number attached.
     */
    public void partitionedOutput(int EGEMYELUIR, K YHVACQTDAM, V ZOWGNKBXTD) throws IOException {
        PipesPartitioner.setNextPartition(EGEMYELUIR);
        PZIBKWDJUX.collect(YHVACQTDAM, ZOWGNKBXTD);
    }

    /**
     * Update the status message for the task.
     */
    public void status(String NOTLMTAMCU) {
        YHLNCJGHCT.setStatus(NOTLMTAMCU);
    }

    private FloatWritable RCZZTLMDOA = new FloatWritable(0.0F);

    private NullWritable OYJLZBVINV = NullWritable.get();

    /**
     * Update the amount done and call progress on the reporter.
     */
    public void progress(float GYURMKJMJB) throws IOException {
        AAILQOAJUS = GYURMKJMJB;
        YHLNCJGHCT.progress();
        if (WMCVJDOHPV != null) {
            RCZZTLMDOA.set(GYURMKJMJB);
            WMCVJDOHPV.next(RCZZTLMDOA, OYJLZBVINV);
        }
    }

    /**
     * The task finished successfully.
     */
    public void done() throws IOException {
        synchronized(this) {
            RYKMTGEQXS = true;
            notify();
        }
    }

    /**
     * Get the current amount done.
     *
     * @return a float between 0.0 and 1.0
     */
    public float getProgress() {
        return AAILQOAJUS;
    }

    /**
     * The task failed with an exception.
     */
    public void failed(Throwable IJSEEIMACL) {
        synchronized(this) {
            LNVAZAJTGW = IJSEEIMACL;
            notify();
        }
    }

    /**
     * Wait for the task to finish or abort.
     *
     * @return did the task finish correctly?
     * @throws Throwable
     * 		
     */
    public synchronized boolean waitForFinish() throws Throwable {
        while ((!RYKMTGEQXS) && (LNVAZAJTGW == null)) {
            wait();
        } 
        if (LNVAZAJTGW != null) {
            throw LNVAZAJTGW;
        }
        return RYKMTGEQXS;
    }

    public void registerCounter(int TBCAMLKPSI, String VERRSJEXNR, String XHMDXXWWMJ) throws IOException {
        Counters.Counter FCJBXMZVSR = YHLNCJGHCT.getCounter(VERRSJEXNR, XHMDXXWWMJ);
        registeredCounters.put(TBCAMLKPSI, FCJBXMZVSR);
    }

    public void incrementCounter(int QORIKNWYGI, long JPFZEXSJFG) throws IOException {
        if (QORIKNWYGI < registeredCounters.size()) {
            Counters.Counter HYCUBZKLCC = registeredCounters.get(QORIKNWYGI);
            HYCUBZKLCC.increment(JPFZEXSJFG);
        } else {
            throw new IOException("Invalid counter with id: " + QORIKNWYGI);
        }
    }

    public synchronized boolean authenticate(String QLVFPKQUPH) throws IOException {
        boolean PQWFTMOUUZ = true;
        if (!CMMUYWCFDS.equals(QLVFPKQUPH)) {
            LNVAZAJTGW = new IOException((("Authentication Failed: Expected digest=" + CMMUYWCFDS) + ", received=") + BYBEPSKVRC);
            PQWFTMOUUZ = false;
        }
        BYBEPSKVRC = true;
        notify();
        return PQWFTMOUUZ;
    }

    /**
     * This is called by Application and blocks the thread until
     * authentication response is received.
     *
     * @throws IOException
     * 		
     * @throws InterruptedException
     * 		
     */
    synchronized void waitForAuthentication() throws IOException, InterruptedException {
        while ((BYBEPSKVRC == false) && (LNVAZAJTGW == null)) {
            wait();
        } 
        if (LNVAZAJTGW != null) {
            throw new IOException(LNVAZAJTGW.getMessage());
        }
    }
}