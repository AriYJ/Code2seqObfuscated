/**
 * This class describes a replica that has been finalized.
 */
public class FinalizedReplica extends ReplicaInfo {
    private boolean KYCMRPTXZI;// copy-on-write done for block


    /**
     * Constructor
     *
     * @param blockId
     * 		block id
     * @param len
     * 		replica length
     * @param genStamp
     * 		replica generation stamp
     * @param vol
     * 		volume where replica is located
     * @param dir
     * 		directory path where block and meta files are located
     */
    public FinalizedReplica(long IPKWSWORGW, long EXQOJFDOKR, long IJDLRNKBBE, FsVolumeSpi CUBFULBATS, File QZBRAHHTWO) {
        super(IPKWSWORGW, EXQOJFDOKR, IJDLRNKBBE, CUBFULBATS, QZBRAHHTWO);
    }

    /**
     * Constructor
     *
     * @param block
     * 		a block
     * @param vol
     * 		volume where replica is located
     * @param dir
     * 		directory path where block and meta files are located
     */
    public FinalizedReplica(Block TCRBIHYQVG, FsVolumeSpi TCKGSEDBNN, File VULRZPAMGO) {
        super(TCRBIHYQVG, TCKGSEDBNN, VULRZPAMGO);
    }

    /**
     * Copy constructor.
     *
     * @param from
     * 		where to copy construct from
     */
    public FinalizedReplica(FinalizedReplica ZPEZDBKKAT) {
        super(ZPEZDBKKAT);
        this.KYCMRPTXZI = ZPEZDBKKAT.isUnlinked();
    }

    // ReplicaInfo
    @Override
    public ReplicaState getState() {
        return ReplicaState.FINALIZED;
    }

    // ReplicaInfo
    @Override
    public boolean isUnlinked() {
        return KYCMRPTXZI;
    }

    // ReplicaInfo
    @Override
    public void setUnlinked() {
        KYCMRPTXZI = true;
    }

    @Override
    public long getVisibleLength() {
        return getNumBytes();// all bytes are visible

    }

    @Override
    public long getBytesOnDisk() {
        return getNumBytes();
    }

    // Object
    @Override
    public boolean equals(Object VJELTRJHBK) {
        return super.equals(VJELTRJHBK);
    }

    // Object
    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public String toString() {
        return (super.toString() + "\n  unlinked          =") + KYCMRPTXZI;
    }
}