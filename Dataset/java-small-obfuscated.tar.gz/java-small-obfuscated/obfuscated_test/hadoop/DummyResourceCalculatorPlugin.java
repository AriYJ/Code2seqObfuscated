/**
 * Plugin class to test resource information reported by NM. Use configuration
 * items {@link #MAXVMEM_TESTING_PROPERTY} and {@link #MAXPMEM_TESTING_PROPERTY}
 * to tell NM the total vmem and the total pmem. Use configuration items
 * {@link #NUM_PROCESSORS}, {@link #CPU_FREQUENCY}, {@link #CUMULATIVE_CPU_TIME}
 * and {@link #CPU_USAGE} to tell TT the CPU information.
 */
@InterfaceAudience.Private
public class DummyResourceCalculatorPlugin extends ResourceCalculatorPlugin {
    /**
     * max vmem on the TT
     */
    public static final String DOXGGJJIUP = "mapred.tasktracker.maxvmem.testing";

    /**
     * max pmem on the TT
     */
    public static final String NPSMZVMEZQ = "mapred.tasktracker.maxpmem.testing";

    /**
     * number of processors for testing
     */
    public static final String QHFHZINKAB = "mapred.tasktracker.numprocessors.testing";

    /**
     * CPU frequency for testing
     */
    public static final String NHKTBPCSOV = "mapred.tasktracker.cpufrequency.testing";

    /**
     * cumulative CPU usage time for testing
     */
    public static final String XXMQNGGTCT = "mapred.tasktracker.cumulativecputime.testing";

    /**
     * CPU usage percentage for testing
     */
    public static final String UAEPDADZVL = "mapred.tasktracker.cpuusage.testing";

    /**
     * process cumulative CPU usage time for testing
     */
    public static final String RIVYZGNVYE = "mapred.tasktracker.proccumulativecputime.testing";

    /**
     * process pmem for testing
     */
    public static final String BKFOXRYDSX = "mapred.tasktracker.procpmem.testing";

    /**
     * process vmem for testing
     */
    public static final String GSKJTMOSZD = "mapred.tasktracker.procvmem.testing";

    /**
     * {@inheritDoc }
     */
    @Override
    public long getVirtualMemorySize() {
        return getConf().getLong(DummyResourceCalculatorPlugin.DOXGGJJIUP, -1);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public long getPhysicalMemorySize() {
        return getConf().getLong(DummyResourceCalculatorPlugin.NPSMZVMEZQ, -1);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public long getAvailableVirtualMemorySize() {
        return getConf().getLong(DummyResourceCalculatorPlugin.DOXGGJJIUP, -1);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public long getAvailablePhysicalMemorySize() {
        return getConf().getLong(DummyResourceCalculatorPlugin.NPSMZVMEZQ, -1);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public int getNumProcessors() {
        return getConf().getInt(DummyResourceCalculatorPlugin.QHFHZINKAB, -1);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public long getCpuFrequency() {
        return getConf().getLong(DummyResourceCalculatorPlugin.NHKTBPCSOV, -1);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public long getCumulativeCpuTime() {
        return getConf().getLong(DummyResourceCalculatorPlugin.XXMQNGGTCT, -1);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public float getCpuUsage() {
        return getConf().getFloat(DummyResourceCalculatorPlugin.UAEPDADZVL, -1);
    }
}