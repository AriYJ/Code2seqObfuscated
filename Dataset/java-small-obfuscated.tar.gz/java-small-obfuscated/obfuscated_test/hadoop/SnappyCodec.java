/**
 * This class creates snappy compressors/decompressors.
 */
public class SnappyCodec implements Configurable , CompressionCodec , DirectDecompressionCodec {
    Configuration TEYRRWZYUB;

    /**
     * Set the configuration to be used by this object.
     *
     * @param conf
     * 		the configuration object.
     */
    @Override
    public void setConf(Configuration EZIUTMDAJG) {
        this.TEYRRWZYUB = EZIUTMDAJG;
    }

    /**
     * Return the configuration used by this object.
     *
     * @return the configuration object used by this objec.
     */
    @Override
    public Configuration getConf() {
        return TEYRRWZYUB;
    }

    /**
     * Are the native snappy libraries loaded & initialized?
     */
    public static void checkNativeCodeLoaded() {
        if (!NativeCodeLoader.buildSupportsSnappy()) {
            throw new RuntimeException("native snappy library not available: " + ("this version of libhadoop was built without " + "snappy support."));
        }
        if (!SnappyCompressor.isNativeCodeLoaded()) {
            throw new RuntimeException("native snappy library not available: " + "SnappyCompressor has not been loaded.");
        }
        if (!SnappyDecompressor.isNativeCodeLoaded()) {
            throw new RuntimeException("native snappy library not available: " + "SnappyDecompressor has not been loaded.");
        }
    }

    public static boolean isNativeCodeLoaded() {
        return SnappyCompressor.isNativeCodeLoaded() && SnappyDecompressor.isNativeCodeLoaded();
    }

    public static String getLibraryName() {
        return SnappyCompressor.getLibraryName();
    }

    /**
     * Create a {@link CompressionOutputStream} that will write to the given
     * {@link OutputStream}.
     *
     * @param out
     * 		the location for the final output stream
     * @return a stream the user can write uncompressed data to have it compressed
     * @throws IOException
     * 		
     */
    @Override
    public CompressionOutputStream createOutputStream(OutputStream NVOFWALRAW) throws IOException {
        return Util.createOutputStreamWithCodecPool(this, TEYRRWZYUB, NVOFWALRAW);
    }

    /**
     * Create a {@link CompressionOutputStream} that will write to the given
     * {@link OutputStream} with the given {@link Compressor}.
     *
     * @param out
     * 		the location for the final output stream
     * @param compressor
     * 		compressor to use
     * @return a stream the user can write uncompressed data to have it compressed
     * @throws IOException
     * 		
     */
    @Override
    public CompressionOutputStream createOutputStream(OutputStream QKOYMSMTYQ, Compressor XXIRRGAGFJ) throws IOException {
        SnappyCodec.checkNativeCodeLoaded();
        int NMQRJGSUZA = TEYRRWZYUB.getInt(IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_KEY, IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_DEFAULT);
        int NPSYGDJAMF = (NMQRJGSUZA / 6) + 32;
        return new BlockCompressorStream(QKOYMSMTYQ, XXIRRGAGFJ, NMQRJGSUZA, NPSYGDJAMF);
    }

    /**
     * Get the type of {@link Compressor} needed by this {@link CompressionCodec}.
     *
     * @return the type of compressor needed by this codec.
     */
    @Override
    public Class<? extends Compressor> getCompressorType() {
        SnappyCodec.checkNativeCodeLoaded();
        return SnappyCompressor.class;
    }

    /**
     * Create a new {@link Compressor} for use by this {@link CompressionCodec}.
     *
     * @return a new compressor for use by this codec
     */
    @Override
    public Compressor createCompressor() {
        SnappyCodec.checkNativeCodeLoaded();
        int CQRHKSJLER = TEYRRWZYUB.getInt(IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_KEY, IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_DEFAULT);
        return new SnappyCompressor(CQRHKSJLER);
    }

    /**
     * Create a {@link CompressionInputStream} that will read from the given
     * input stream.
     *
     * @param in
     * 		the stream to read compressed bytes from
     * @return a stream to read uncompressed bytes from
     * @throws IOException
     * 		
     */
    @Override
    public CompressionInputStream createInputStream(InputStream KEXSWCEIZL) throws IOException {
        return Util.createInputStreamWithCodecPool(this, TEYRRWZYUB, KEXSWCEIZL);
    }

    /**
     * Create a {@link CompressionInputStream} that will read from the given
     * {@link InputStream} with the given {@link Decompressor}.
     *
     * @param in
     * 		the stream to read compressed bytes from
     * @param decompressor
     * 		decompressor to use
     * @return a stream to read uncompressed bytes from
     * @throws IOException
     * 		
     */
    @Override
    public CompressionInputStream createInputStream(InputStream XETVQYTADE, Decompressor ULHFTNPAUW) throws IOException {
        SnappyCodec.checkNativeCodeLoaded();
        return new BlockDecompressorStream(XETVQYTADE, ULHFTNPAUW, TEYRRWZYUB.getInt(IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_KEY, IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_DEFAULT));
    }

    /**
     * Get the type of {@link Decompressor} needed by this {@link CompressionCodec}.
     *
     * @return the type of decompressor needed by this codec.
     */
    @Override
    public Class<? extends Decompressor> getDecompressorType() {
        SnappyCodec.checkNativeCodeLoaded();
        return SnappyDecompressor.class;
    }

    /**
     * Create a new {@link Decompressor} for use by this {@link CompressionCodec}.
     *
     * @return a new decompressor for use by this codec
     */
    @Override
    public Decompressor createDecompressor() {
        SnappyCodec.checkNativeCodeLoaded();
        int YSBYOKTBGC = TEYRRWZYUB.getInt(IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_KEY, IO_COMPRESSION_CODEC_SNAPPY_BUFFERSIZE_DEFAULT);
        return new SnappyDecompressor(YSBYOKTBGC);
    }

    /**
     * {@inheritDoc }
     */
    @Override
    public DirectDecompressor createDirectDecompressor() {
        return SnappyCodec.isNativeCodeLoaded() ? new SnappyDirectDecompressor() : null;
    }

    /**
     * Get the default filename extension for this kind of compression.
     *
     * @return <code>.snappy</code>.
     */
    @Override
    public String getDefaultExtension() {
        return ".snappy";
    }
}