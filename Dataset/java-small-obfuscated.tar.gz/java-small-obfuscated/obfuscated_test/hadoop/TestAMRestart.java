public class TestAMRestart {
    @Test(timeout = 30000)
    public void testAMRestartWithExistingContainers() throws Exception {
        YarnConfiguration LRBLFRRFGB = new YarnConfiguration();
        LRBLFRRFGB.setInt(RM_AM_MAX_ATTEMPTS, 2);
        MockRM NRVJAHJVBL = new MockRM(LRBLFRRFGB);
        NRVJAHJVBL.start();
        RMApp WSRGFIAPZJ = NRVJAHJVBL.submitApp(200, "name", "user", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", -1, null, "MAPREDUCE", false, true);
        MockNM ZOXDYBPCRP = new MockNM("127.0.0.1:1234", 10240, NRVJAHJVBL.getResourceTrackerService());
        ZOXDYBPCRP.registerNode();
        MockNM YQCYSZXRHZ = new MockNM("127.0.0.1:2351", 4089, NRVJAHJVBL.getResourceTrackerService());
        YQCYSZXRHZ.registerNode();
        MockAM YPCKCMQDJR = MockRM.launchAndRegisterAM(WSRGFIAPZJ, NRVJAHJVBL, ZOXDYBPCRP);
        int QAIKZVSUFS = 3;
        // allocate NUM_CONTAINERS containers
        YPCKCMQDJR.allocate("127.0.0.1", 1024, QAIKZVSUFS, new ArrayList<ContainerId>());
        ZOXDYBPCRP.nodeHeartbeat(true);
        // wait for containers to be allocated.
        List<Container> EWRHGNXRCM = YPCKCMQDJR.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers();
        while (EWRHGNXRCM.size() != QAIKZVSUFS) {
            ZOXDYBPCRP.nodeHeartbeat(true);
            EWRHGNXRCM.addAll(YPCKCMQDJR.allocate(new ArrayList<org.apache.hadoop.yarn.api.records.ResourceRequest>(), new ArrayList<ContainerId>()).getAllocatedContainers());
            Thread.sleep(200);
        } 
        // launch the 2nd container, for testing running container transferred.
        ZOXDYBPCRP.nodeHeartbeat(YPCKCMQDJR.getApplicationAttemptId(), 2, RUNNING);
        ContainerId WVPTTYAJKK = ContainerId.newInstance(YPCKCMQDJR.getApplicationAttemptId(), 2);
        NRVJAHJVBL.waitForState(ZOXDYBPCRP, WVPTTYAJKK, RMContainerState.RUNNING);
        // launch the 3rd container, for testing container allocated by previous
        // attempt is completed by the next new attempt/
        ZOXDYBPCRP.nodeHeartbeat(YPCKCMQDJR.getApplicationAttemptId(), 3, RUNNING);
        ContainerId RFKEDSOBUU = ContainerId.newInstance(YPCKCMQDJR.getApplicationAttemptId(), 3);
        NRVJAHJVBL.waitForState(ZOXDYBPCRP, RFKEDSOBUU, RMContainerState.RUNNING);
        // 4th container still in AQUIRED state. for testing Acquired container is
        // always killed.
        ContainerId DYDWQTTIDZ = ContainerId.newInstance(YPCKCMQDJR.getApplicationAttemptId(), 4);
        NRVJAHJVBL.waitForState(ZOXDYBPCRP, DYDWQTTIDZ, ACQUIRED);
        // 5th container is in Allocated state. for testing allocated container is
        // always killed.
        YPCKCMQDJR.allocate("127.0.0.1", 1024, 1, new ArrayList<ContainerId>());
        ZOXDYBPCRP.nodeHeartbeat(true);
        ContainerId CYJACQHZFO = ContainerId.newInstance(YPCKCMQDJR.getApplicationAttemptId(), 5);
        NRVJAHJVBL.waitForContainerAllocated(ZOXDYBPCRP, CYJACQHZFO);
        NRVJAHJVBL.waitForState(ZOXDYBPCRP, CYJACQHZFO, ALLOCATED);
        // 6th container is in Reserved state.
        YPCKCMQDJR.allocate("127.0.0.1", 6000, 1, new ArrayList<ContainerId>());
        ContainerId RKTVLCFFLP = ContainerId.newInstance(YPCKCMQDJR.getApplicationAttemptId(), 6);
        ZOXDYBPCRP.nodeHeartbeat(true);
        SchedulerApplicationAttempt PVGEJGATMS = ((AbstractYarnScheduler) (NRVJAHJVBL.getResourceScheduler())).getCurrentAttemptForContainer(RKTVLCFFLP);
        while (PVGEJGATMS.getReservedContainers().isEmpty()) {
            System.out.println(("Waiting for container " + RKTVLCFFLP) + " to be reserved.");
            ZOXDYBPCRP.nodeHeartbeat(true);
            Thread.sleep(200);
        } 
        // assert containerId6 is reserved.
        Assert.assertEquals(RKTVLCFFLP, PVGEJGATMS.getReservedContainers().get(0).getContainerId());
        // fail the AM by sending CONTAINER_FINISHED event without registering.
        ZOXDYBPCRP.nodeHeartbeat(YPCKCMQDJR.getApplicationAttemptId(), 1, COMPLETE);
        YPCKCMQDJR.waitForState(FAILED);
        // wait for some time. previous AM's running containers should still remain
        // in scheduler even though am failed
        Thread.sleep(3000);
        NRVJAHJVBL.waitForState(ZOXDYBPCRP, WVPTTYAJKK, RMContainerState.RUNNING);
        // acquired/allocated containers are cleaned up.
        Assert.assertNull(NRVJAHJVBL.getResourceScheduler().getRMContainer(DYDWQTTIDZ));
        Assert.assertNull(NRVJAHJVBL.getResourceScheduler().getRMContainer(CYJACQHZFO));
        // wait for app to start a new attempt.
        NRVJAHJVBL.waitForState(WSRGFIAPZJ.getApplicationId(), ACCEPTED);
        // assert this is a new AM.
        ApplicationAttemptId VECCNMRJEW = WSRGFIAPZJ.getCurrentAppAttempt().getAppAttemptId();
        Assert.assertFalse(VECCNMRJEW.equals(YPCKCMQDJR.getApplicationAttemptId()));
        // launch the new AM
        RMAppAttempt KVYOFMKAVE = WSRGFIAPZJ.getCurrentAppAttempt();
        ZOXDYBPCRP.nodeHeartbeat(true);
        MockAM RYBQACAPHZ = NRVJAHJVBL.sendAMLaunched(KVYOFMKAVE.getAppAttemptId());
        RegisterApplicationMasterResponse DVNKVKDDNN = RYBQACAPHZ.registerAppAttempt();
        // Assert two containers are running: container2 and container3;
        Assert.assertEquals(2, DVNKVKDDNN.getContainersFromPreviousAttempts().size());
        boolean MJLJJZYEWJ = false;
        boolean GYVSDTUXKN = false;
        for (Container ELIEJNUTOY : DVNKVKDDNN.getContainersFromPreviousAttempts()) {
            if (ELIEJNUTOY.getId().equals(WVPTTYAJKK)) {
                MJLJJZYEWJ = true;
            }
            if (ELIEJNUTOY.getId().equals(RFKEDSOBUU)) {
                GYVSDTUXKN = true;
            }
        }
        Assert.assertTrue(MJLJJZYEWJ && GYVSDTUXKN);
        NRVJAHJVBL.waitForState(WSRGFIAPZJ.getApplicationId(), RMAppState.RUNNING);
        // complete container by sending the container complete event which has earlier
        // attempt's attemptId
        ZOXDYBPCRP.nodeHeartbeat(YPCKCMQDJR.getApplicationAttemptId(), 3, COMPLETE);
        // Even though the completed container containerId3 event was sent to the
        // earlier failed attempt, new RMAppAttempt can also capture this container
        // info.
        // completed containerId4 is also transferred to the new attempt.
        RMAppAttempt KPPRQTGHOH = WSRGFIAPZJ.getRMAppAttempt(RYBQACAPHZ.getApplicationAttemptId());
        // 4 containers finished, acquired/allocated/reserved/completed.
        waitForContainersToFinish(4, KPPRQTGHOH);
        boolean UWNNVFXOZV = false;
        boolean FZOTTINTPQ = false;
        boolean RDYOFPTUNU = false;
        boolean KZMHLIBOOI = false;
        for (ContainerStatus PSRUPTOWQY : KPPRQTGHOH.getJustFinishedContainers()) {
            if (PSRUPTOWQY.getContainerId().equals(RFKEDSOBUU)) {
                // containerId3 is the container ran by previous attempt but finished by the
                // new attempt.
                UWNNVFXOZV = true;
            }
            if (PSRUPTOWQY.getContainerId().equals(DYDWQTTIDZ)) {
                // containerId4 is the Acquired Container killed by the previous attempt,
                // it's now inside new attempt's finished container list.
                FZOTTINTPQ = true;
            }
            if (PSRUPTOWQY.getContainerId().equals(CYJACQHZFO)) {
                // containerId5 is the Allocated container killed by previous failed attempt.
                RDYOFPTUNU = true;
            }
            if (PSRUPTOWQY.getContainerId().equals(RKTVLCFFLP)) {
                // containerId6 is the reserved container killed by previous failed attempt.
                KZMHLIBOOI = true;
            }
        }
        Assert.assertTrue(((UWNNVFXOZV && FZOTTINTPQ) && RDYOFPTUNU) && KZMHLIBOOI);
        // New SchedulerApplicationAttempt also has the containers info.
        NRVJAHJVBL.waitForState(ZOXDYBPCRP, WVPTTYAJKK, RMContainerState.RUNNING);
        // record the scheduler attempt for testing.
        SchedulerApplicationAttempt SUPVKUXIFN = ((AbstractYarnScheduler) (NRVJAHJVBL.getResourceScheduler())).getCurrentAttemptForContainer(WVPTTYAJKK);
        // finish this application
        MockRM.finishAMAndVerifyAppState(WSRGFIAPZJ, NRVJAHJVBL, ZOXDYBPCRP, RYBQACAPHZ);
        // the 2nd attempt released the 1st attempt's running container, when the
        // 2nd attempt finishes.
        Assert.assertFalse(SUPVKUXIFN.getLiveContainers().contains(WVPTTYAJKK));
        // all 4 normal containers finished.
        System.out.println("New attempt's just finished containers: " + KPPRQTGHOH.getJustFinishedContainers());
        waitForContainersToFinish(5, KPPRQTGHOH);
        NRVJAHJVBL.stop();
    }

    private void waitForContainersToFinish(int UKFRDNRXKI, RMAppAttempt WYLSIUAWJU) throws InterruptedException {
        int MXZGDCWIDF = 0;
        while ((WYLSIUAWJU.getJustFinishedContainers().size() != UKFRDNRXKI) && (MXZGDCWIDF < 500)) {
            Thread.sleep(100);
            MXZGDCWIDF++;
        } 
    }

    @Test(timeout = 30000)
    public void testNMTokensRebindOnAMRestart() throws Exception {
        YarnConfiguration DVKXEVCZFA = new YarnConfiguration();
        DVKXEVCZFA.setInt(RM_AM_MAX_ATTEMPTS, 3);
        MockRM VKBDJJIZID = new MockRM(DVKXEVCZFA);
        VKBDJJIZID.start();
        RMApp QREVNYALCH = VKBDJJIZID.submitApp(200, "myname", "myuser", new HashMap<org.apache.hadoop.yarn.api.records.ApplicationAccessType, String>(), false, "default", -1, null, "MAPREDUCE", false, true);
        MockNM NNUNVIITWZ = new MockNM("127.0.0.1:1234", 8000, VKBDJJIZID.getResourceTrackerService());
        NNUNVIITWZ.registerNode();
        MockNM AJMYPXJIXK = new MockNM("127.1.1.1:4321", 8000, VKBDJJIZID.getResourceTrackerService());
        AJMYPXJIXK.registerNode();
        MockAM ONWHXPPJIW = MockRM.launchAndRegisterAM(QREVNYALCH, VKBDJJIZID, NNUNVIITWZ);
        List<Container> NCWUXOUHPO = new ArrayList<Container>();
        // nmTokens keeps track of all the nmTokens issued in the allocate call.
        List<NMToken> ECNHPPBEGP = new ArrayList<NMToken>();
        // am1 allocate 2 container on nm1.
        // first container
        while (true) {
            AllocateResponse WPRVUTMRBC = ONWHXPPJIW.allocate("127.0.0.1", 2000, 2, new ArrayList<ContainerId>());
            NNUNVIITWZ.nodeHeartbeat(true);
            NCWUXOUHPO.addAll(WPRVUTMRBC.getAllocatedContainers());
            ECNHPPBEGP.addAll(WPRVUTMRBC.getNMTokens());
            if (NCWUXOUHPO.size() == 2) {
                break;
            }
            Thread.sleep(200);
            System.out.println("Waiting for container to be allocated.");
        } 
        // launch the container-2
        NNUNVIITWZ.nodeHeartbeat(ONWHXPPJIW.getApplicationAttemptId(), 2, RUNNING);
        ContainerId WSSAPGSIHD = ContainerId.newInstance(ONWHXPPJIW.getApplicationAttemptId(), 2);
        VKBDJJIZID.waitForState(NNUNVIITWZ, WSSAPGSIHD, RMContainerState.RUNNING);
        // launch the container-3
        NNUNVIITWZ.nodeHeartbeat(ONWHXPPJIW.getApplicationAttemptId(), 3, RUNNING);
        ContainerId NMGXHLODKQ = ContainerId.newInstance(ONWHXPPJIW.getApplicationAttemptId(), 3);
        VKBDJJIZID.waitForState(NNUNVIITWZ, NMGXHLODKQ, RMContainerState.RUNNING);
        // fail am1
        NNUNVIITWZ.nodeHeartbeat(ONWHXPPJIW.getApplicationAttemptId(), 1, COMPLETE);
        ONWHXPPJIW.waitForState(FAILED);
        VKBDJJIZID.waitForState(QREVNYALCH.getApplicationId(), ACCEPTED);
        // restart the am
        MockAM UZMZPERWYI = MockRM.launchAM(QREVNYALCH, VKBDJJIZID, NNUNVIITWZ);
        RegisterApplicationMasterResponse CXQFKJMXOC = UZMZPERWYI.registerAppAttempt();
        VKBDJJIZID.waitForState(QREVNYALCH.getApplicationId(), RMAppState.RUNNING);
        // check am2 get the nm token from am1.
        Assert.assertEquals(ECNHPPBEGP, CXQFKJMXOC.getNMTokensFromPreviousAttempts());
        // am2 allocate 1 container on nm2
        NCWUXOUHPO = new ArrayList<Container>();
        while (true) {
            AllocateResponse TPRKNHMTNT = UZMZPERWYI.allocate("127.1.1.1", 4000, 1, new ArrayList<ContainerId>());
            AJMYPXJIXK.nodeHeartbeat(true);
            NCWUXOUHPO.addAll(TPRKNHMTNT.getAllocatedContainers());
            ECNHPPBEGP.addAll(TPRKNHMTNT.getNMTokens());
            if (NCWUXOUHPO.size() == 1) {
                break;
            }
            Thread.sleep(200);
            System.out.println("Waiting for container to be allocated.");
        } 
        NNUNVIITWZ.nodeHeartbeat(UZMZPERWYI.getApplicationAttemptId(), 2, RUNNING);
        ContainerId GOUEKXLAGO = ContainerId.newInstance(UZMZPERWYI.getApplicationAttemptId(), 2);
        VKBDJJIZID.waitForState(NNUNVIITWZ, GOUEKXLAGO, RMContainerState.RUNNING);
        // fail am2.
        NNUNVIITWZ.nodeHeartbeat(UZMZPERWYI.getApplicationAttemptId(), 1, COMPLETE);
        UZMZPERWYI.waitForState(FAILED);
        VKBDJJIZID.waitForState(QREVNYALCH.getApplicationId(), ACCEPTED);
        // restart am
        MockAM CXNWAWKBBI = MockRM.launchAM(QREVNYALCH, VKBDJJIZID, NNUNVIITWZ);
        CXQFKJMXOC = CXNWAWKBBI.registerAppAttempt();
        VKBDJJIZID.waitForState(QREVNYALCH.getApplicationId(), RMAppState.RUNNING);
        // check am3 get the NM token from both am1 and am2;
        List<NMToken> JTEGSYMPAU = CXQFKJMXOC.getNMTokensFromPreviousAttempts();
        Assert.assertEquals(2, JTEGSYMPAU.size());
        Assert.assertTrue(JTEGSYMPAU.containsAll(ECNHPPBEGP));
        VKBDJJIZID.stop();
    }

    // AM container preempted, nm disk failure
    // should not be counted towards AM max retry count.
    @Test(timeout = 100000)
    public void testShouldNotCountFailureToMaxAttemptRetry() throws Exception {
        YarnConfiguration YCLPWKIICJ = new YarnConfiguration();
        YCLPWKIICJ.setClass(RM_SCHEDULER, CapacityScheduler.class, ResourceScheduler.class);
        // explicitly set max-am-retry count as 1.
        YCLPWKIICJ.setInt(RM_AM_MAX_ATTEMPTS, 1);
        YCLPWKIICJ.setBoolean(RECOVERY_ENABLED, true);
        YCLPWKIICJ.set(RM_STORE, MemoryRMStateStore.class.getName());
        MemoryRMStateStore HVQZPLUYUX = new MemoryRMStateStore();
        HVQZPLUYUX.init(YCLPWKIICJ);
        MockRM LHEIGTFJIK = new MockRM(YCLPWKIICJ, HVQZPLUYUX);
        LHEIGTFJIK.start();
        MockNM TMZHLJRITM = new MockNM("127.0.0.1:1234", 8000, LHEIGTFJIK.getResourceTrackerService());
        TMZHLJRITM.registerNode();
        RMApp MNPCMIQXBG = LHEIGTFJIK.submitApp(200);
        RMAppAttempt VZSNHXWBTA = MNPCMIQXBG.getCurrentAppAttempt();
        MockAM VEXLBMDNJH = MockRM.launchAndRegisterAM(MNPCMIQXBG, LHEIGTFJIK, TMZHLJRITM);
        CapacityScheduler QCXMMBRVWZ = ((CapacityScheduler) (LHEIGTFJIK.getResourceScheduler()));
        ContainerId LCKJMORGPN = ContainerId.newInstance(VEXLBMDNJH.getApplicationAttemptId(), 1);
        // Preempt the first attempt;
        QCXMMBRVWZ.killContainer(QCXMMBRVWZ.getRMContainer(LCKJMORGPN));
        VEXLBMDNJH.waitForState(FAILED);
        Assert.assertTrue(!VZSNHXWBTA.shouldCountTowardsMaxAttemptRetry());
        LHEIGTFJIK.waitForState(MNPCMIQXBG.getApplicationId(), ACCEPTED);
        ApplicationState MGSNKVKFMI = HVQZPLUYUX.getState().getApplicationState().get(MNPCMIQXBG.getApplicationId());
        // AM should be restarted even though max-am-attempt is 1.
        MockAM WSCQBHAINP = LHEIGTFJIK.waitForNewAMToLaunchAndRegister(MNPCMIQXBG.getApplicationId(), 2, TMZHLJRITM);
        RMAppAttempt FYYHSKXBFA = MNPCMIQXBG.getCurrentAppAttempt();
        Assert.assertTrue(((org.apache.hadoop.yarn.server.resourcemanager.rmapp.attempt.RMAppAttemptImpl) (FYYHSKXBFA)).mayBeLastAttempt());
        // Preempt the second attempt.
        ContainerId FSGFAINDOU = ContainerId.newInstance(WSCQBHAINP.getApplicationAttemptId(), 1);
        QCXMMBRVWZ.killContainer(QCXMMBRVWZ.getRMContainer(FSGFAINDOU));
        WSCQBHAINP.waitForState(FAILED);
        Assert.assertTrue(!FYYHSKXBFA.shouldCountTowardsMaxAttemptRetry());
        LHEIGTFJIK.waitForState(MNPCMIQXBG.getApplicationId(), ACCEPTED);
        MockAM WOYZHTQQBR = LHEIGTFJIK.waitForNewAMToLaunchAndRegister(MNPCMIQXBG.getApplicationId(), 3, TMZHLJRITM);
        RMAppAttempt YRDGTDCWWU = MNPCMIQXBG.getCurrentAppAttempt();
        Assert.assertTrue(((org.apache.hadoop.yarn.server.resourcemanager.rmapp.attempt.RMAppAttemptImpl) (YRDGTDCWWU)).mayBeLastAttempt());
        // mimic NM disk_failure
        ContainerStatus LXCZXQPLYD = Records.newRecord(ContainerStatus.class);
        LXCZXQPLYD.setContainerId(YRDGTDCWWU.getMasterContainer().getId());
        LXCZXQPLYD.setDiagnostics("mimic NM disk_failure");
        LXCZXQPLYD.setState(COMPLETE);
        LXCZXQPLYD.setExitStatus(DISKS_FAILED);
        Map<ApplicationId, List<ContainerStatus>> CMPUVXZGKI = new HashMap<ApplicationId, List<ContainerStatus>>();
        CMPUVXZGKI.put(MNPCMIQXBG.getApplicationId(), Collections.singletonList(LXCZXQPLYD));
        TMZHLJRITM.nodeHeartbeat(CMPUVXZGKI, true);
        WOYZHTQQBR.waitForState(FAILED);
        Assert.assertTrue(!YRDGTDCWWU.shouldCountTowardsMaxAttemptRetry());
        Assert.assertEquals(DISKS_FAILED, MGSNKVKFMI.getAttempt(WOYZHTQQBR.getApplicationAttemptId()).getAMContainerExitStatus());
        LHEIGTFJIK.waitForState(MNPCMIQXBG.getApplicationId(), ACCEPTED);
        MockAM KZKUDXQPSW = LHEIGTFJIK.waitForNewAMToLaunchAndRegister(MNPCMIQXBG.getApplicationId(), 4, TMZHLJRITM);
        RMAppAttempt UXSFDEFUPQ = MNPCMIQXBG.getCurrentAppAttempt();
        Assert.assertTrue(((org.apache.hadoop.yarn.server.resourcemanager.rmapp.attempt.RMAppAttemptImpl) (UXSFDEFUPQ)).mayBeLastAttempt());
        // create second NM, and register to rm1
        MockNM BGXTBKZUBH = new MockNM("127.0.0.1:2234", 8000, LHEIGTFJIK.getResourceTrackerService());
        BGXTBKZUBH.registerNode();
        // nm1 heartbeats to report unhealthy
        // This will mimic ContainerExitStatus.ABORT
        TMZHLJRITM.nodeHeartbeat(false);
        KZKUDXQPSW.waitForState(FAILED);
        Assert.assertTrue(!UXSFDEFUPQ.shouldCountTowardsMaxAttemptRetry());
        Assert.assertEquals(ABORTED, MGSNKVKFMI.getAttempt(KZKUDXQPSW.getApplicationAttemptId()).getAMContainerExitStatus());
        // launch next AM in nm2
        BGXTBKZUBH.nodeHeartbeat(true);
        MockAM ADOCCCKCRC = LHEIGTFJIK.waitForNewAMToLaunchAndRegister(MNPCMIQXBG.getApplicationId(), 5, BGXTBKZUBH);
        RMAppAttempt CQWCAZYOWB = MNPCMIQXBG.getCurrentAppAttempt();
        Assert.assertTrue(((org.apache.hadoop.yarn.server.resourcemanager.rmapp.attempt.RMAppAttemptImpl) (CQWCAZYOWB)).mayBeLastAttempt());
        // fail the AM normally
        BGXTBKZUBH.nodeHeartbeat(ADOCCCKCRC.getApplicationAttemptId(), 1, COMPLETE);
        ADOCCCKCRC.waitForState(FAILED);
        Assert.assertTrue(CQWCAZYOWB.shouldCountTowardsMaxAttemptRetry());
        // AM should not be restarted.
        LHEIGTFJIK.waitForState(MNPCMIQXBG.getApplicationId(), RMAppState.FAILED);
        Assert.assertEquals(5, MNPCMIQXBG.getAppAttempts().size());
        LHEIGTFJIK.stop();
    }

    // Test RM restarts after AM container is preempted, new RM should not count
    // AM preemption failure towards the max-retry-account and should be able to
    // re-launch the AM.
    @Test(timeout = 20000)
    public void testPreemptedAMRestartOnRMRestart() throws Exception {
        YarnConfiguration SNPPDAXNKC = new YarnConfiguration();
        SNPPDAXNKC.setClass(RM_SCHEDULER, CapacityScheduler.class, ResourceScheduler.class);
        SNPPDAXNKC.setBoolean(RECOVERY_ENABLED, true);
        SNPPDAXNKC.set(RM_STORE, MemoryRMStateStore.class.getName());
        // explicitly set max-am-retry count as 1.
        SNPPDAXNKC.setInt(RM_AM_MAX_ATTEMPTS, 1);
        MemoryRMStateStore KDKDVMGAVW = new MemoryRMStateStore();
        KDKDVMGAVW.init(SNPPDAXNKC);
        MockRM DJOKLNXWQX = new MockRM(SNPPDAXNKC, KDKDVMGAVW);
        DJOKLNXWQX.start();
        MockNM YFPGPXLSRS = new MockNM("127.0.0.1:1234", 8000, DJOKLNXWQX.getResourceTrackerService());
        YFPGPXLSRS.registerNode();
        RMApp LTVLNLLSZF = DJOKLNXWQX.submitApp(200);
        RMAppAttempt UADJEXDCSL = LTVLNLLSZF.getCurrentAppAttempt();
        MockAM SVMXAGHJRG = MockRM.launchAndRegisterAM(LTVLNLLSZF, DJOKLNXWQX, YFPGPXLSRS);
        CapacityScheduler XDYZRJAVIR = ((CapacityScheduler) (DJOKLNXWQX.getResourceScheduler()));
        ContainerId BAOMCVLUSL = ContainerId.newInstance(SVMXAGHJRG.getApplicationAttemptId(), 1);
        // Forcibly preempt the am container;
        XDYZRJAVIR.killContainer(XDYZRJAVIR.getRMContainer(BAOMCVLUSL));
        SVMXAGHJRG.waitForState(FAILED);
        Assert.assertTrue(!UADJEXDCSL.shouldCountTowardsMaxAttemptRetry());
        DJOKLNXWQX.waitForState(LTVLNLLSZF.getApplicationId(), ACCEPTED);
        // state store has 1 attempt stored.
        ApplicationState UMFTABTTWE = KDKDVMGAVW.getState().getApplicationState().get(LTVLNLLSZF.getApplicationId());
        Assert.assertEquals(1, UMFTABTTWE.getAttemptCount());
        // attempt stored has the preempted container exit status.
        Assert.assertEquals(PREEMPTED, UMFTABTTWE.getAttempt(SVMXAGHJRG.getApplicationAttemptId()).getAMContainerExitStatus());
        // Restart rm.
        MockRM MNCDBOLLUD = new MockRM(SNPPDAXNKC, KDKDVMGAVW);
        YFPGPXLSRS.setResourceTrackerService(MNCDBOLLUD.getResourceTrackerService());
        YFPGPXLSRS.registerNode();
        MNCDBOLLUD.start();
        // Restarted RM should re-launch the am.
        MockAM WYUAZGLYVH = MNCDBOLLUD.waitForNewAMToLaunchAndRegister(LTVLNLLSZF.getApplicationId(), 2, YFPGPXLSRS);
        MockRM.finishAMAndVerifyAppState(LTVLNLLSZF, MNCDBOLLUD, YFPGPXLSRS, WYUAZGLYVH);
        RMAppAttempt YTLNXKBFYD = MNCDBOLLUD.getRMContext().getRMApps().get(LTVLNLLSZF.getApplicationId()).getCurrentAppAttempt();
        Assert.assertTrue(YTLNXKBFYD.shouldCountTowardsMaxAttemptRetry());
        Assert.assertEquals(INVALID, UMFTABTTWE.getAttempt(WYUAZGLYVH.getApplicationAttemptId()).getAMContainerExitStatus());
        DJOKLNXWQX.stop();
        MNCDBOLLUD.stop();
    }

    // Test regular RM restart/failover, new RM should not count
    // AM failure towards the max-retry-account and should be able to
    // re-launch the AM.
    @Test(timeout = 50000)
    public void testRMRestartOrFailoverNotCountedForAMFailures() throws Exception {
        YarnConfiguration CHIQYNRWAX = new YarnConfiguration();
        CHIQYNRWAX.setClass(RM_SCHEDULER, CapacityScheduler.class, ResourceScheduler.class);
        CHIQYNRWAX.setBoolean(RECOVERY_ENABLED, true);
        CHIQYNRWAX.set(RM_STORE, MemoryRMStateStore.class.getName());
        // explicitly set max-am-retry count as 1.
        CHIQYNRWAX.setInt(RM_AM_MAX_ATTEMPTS, 1);
        MemoryRMStateStore EKOGINYNPG = new MemoryRMStateStore();
        EKOGINYNPG.init(CHIQYNRWAX);
        MockRM OLAWWYKKWU = new MockRM(CHIQYNRWAX, EKOGINYNPG);
        OLAWWYKKWU.start();
        MockNM YLKEHCPTBD = new MockNM("127.0.0.1:1234", 8000, OLAWWYKKWU.getResourceTrackerService());
        YLKEHCPTBD.registerNode();
        RMApp WZZRBBDIXY = OLAWWYKKWU.submitApp(200);
        // AM should be restarted even though max-am-attempt is 1.
        MockAM MXQFOGPGPZ = MockRM.launchAndRegisterAM(WZZRBBDIXY, OLAWWYKKWU, YLKEHCPTBD);
        RMAppAttempt JIVGJXAKYV = WZZRBBDIXY.getCurrentAppAttempt();
        Assert.assertTrue(((org.apache.hadoop.yarn.server.resourcemanager.rmapp.attempt.RMAppAttemptImpl) (JIVGJXAKYV)).mayBeLastAttempt());
        // Restart rm.
        MockRM JQDXXJPJNW = new MockRM(CHIQYNRWAX, EKOGINYNPG);
        JQDXXJPJNW.start();
        ApplicationState EAIRFQTAPE = EKOGINYNPG.getState().getApplicationState().get(WZZRBBDIXY.getApplicationId());
        // re-register the NM
        YLKEHCPTBD.setResourceTrackerService(JQDXXJPJNW.getResourceTrackerService());
        NMContainerStatus WJVIGUYBGO = Records.newRecord(NMContainerStatus.class);
        WJVIGUYBGO.setContainerExitStatus(KILLED_BY_RESOURCEMANAGER);
        WJVIGUYBGO.setContainerId(JIVGJXAKYV.getMasterContainer().getId());
        WJVIGUYBGO.setContainerState(COMPLETE);
        WJVIGUYBGO.setDiagnostics("");
        YLKEHCPTBD.registerNode(Collections.singletonList(WJVIGUYBGO), null);
        JQDXXJPJNW.waitForState(JIVGJXAKYV.getAppAttemptId(), FAILED);
        Assert.assertEquals(KILLED_BY_RESOURCEMANAGER, EAIRFQTAPE.getAttempt(MXQFOGPGPZ.getApplicationAttemptId()).getAMContainerExitStatus());
        // Will automatically start a new AppAttempt in rm2
        JQDXXJPJNW.waitForState(WZZRBBDIXY.getApplicationId(), ACCEPTED);
        MockAM PJRHSVERLP = JQDXXJPJNW.waitForNewAMToLaunchAndRegister(WZZRBBDIXY.getApplicationId(), 2, YLKEHCPTBD);
        MockRM.finishAMAndVerifyAppState(WZZRBBDIXY, JQDXXJPJNW, YLKEHCPTBD, PJRHSVERLP);
        RMAppAttempt VEBKXPQXFU = JQDXXJPJNW.getRMContext().getRMApps().get(WZZRBBDIXY.getApplicationId()).getCurrentAppAttempt();
        Assert.assertTrue(VEBKXPQXFU.shouldCountTowardsMaxAttemptRetry());
        Assert.assertEquals(INVALID, EAIRFQTAPE.getAttempt(PJRHSVERLP.getApplicationAttemptId()).getAMContainerExitStatus());
        OLAWWYKKWU.stop();
        JQDXXJPJNW.stop();
    }
}