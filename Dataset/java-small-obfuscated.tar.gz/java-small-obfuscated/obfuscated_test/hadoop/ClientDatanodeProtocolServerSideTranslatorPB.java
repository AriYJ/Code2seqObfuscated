/**
 * Implementation for protobuf service that forwards requests
 * received on {@link ClientDatanodeProtocolPB} to the
 * {@link ClientDatanodeProtocol} server implementation.
 */
@InterfaceAudience.Private
public class ClientDatanodeProtocolServerSideTranslatorPB implements ClientDatanodeProtocolPB {
    private static final RefreshNamenodesResponseProto WWWXTFZUPX = RefreshNamenodesResponseProto.newBuilder().build();

    private static final DeleteBlockPoolResponseProto VDYZCMJIPZ = DeleteBlockPoolResponseProto.newBuilder().build();

    private static final ShutdownDatanodeResponseProto YYASQMCHIC = ShutdownDatanodeResponseProto.newBuilder().build();

    private final ClientDatanodeProtocol UVTIARIBIL;

    public ClientDatanodeProtocolServerSideTranslatorPB(ClientDatanodeProtocol LUMFDVFYLG) {
        this.UVTIARIBIL = LUMFDVFYLG;
    }

    @Override
    public GetReplicaVisibleLengthResponseProto getReplicaVisibleLength(RpcController SWRAFYKPKF, GetReplicaVisibleLengthRequestProto ZJKEOHWRHU) throws ServiceException {
        long HWBCEMOQFK;
        try {
            HWBCEMOQFK = UVTIARIBIL.getReplicaVisibleLength(PBHelper.convert(ZJKEOHWRHU.getBlock()));
        } catch (IOException e) {
            throw new ServiceException(e);
        }
        return GetReplicaVisibleLengthResponseProto.newBuilder().setLength(HWBCEMOQFK).build();
    }

    @Override
    public RefreshNamenodesResponseProto refreshNamenodes(RpcController FVOKKBONEG, RefreshNamenodesRequestProto PUWALKRUWA) throws ServiceException {
        try {
            UVTIARIBIL.refreshNamenodes();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
        return ClientDatanodeProtocolServerSideTranslatorPB.WWWXTFZUPX;
    }

    @Override
    public DeleteBlockPoolResponseProto deleteBlockPool(RpcController JPJMQIMMXW, DeleteBlockPoolRequestProto HOONGZMVRI) throws ServiceException {
        try {
            UVTIARIBIL.deleteBlockPool(HOONGZMVRI.getBlockPool(), HOONGZMVRI.getForce());
        } catch (IOException e) {
            throw new ServiceException(e);
        }
        return ClientDatanodeProtocolServerSideTranslatorPB.VDYZCMJIPZ;
    }

    @Override
    public GetBlockLocalPathInfoResponseProto getBlockLocalPathInfo(RpcController KKLBLLLGDG, GetBlockLocalPathInfoRequestProto GFTCSRFCVC) throws ServiceException {
        BlockLocalPathInfo WAFWBCHRRQ;
        try {
            WAFWBCHRRQ = UVTIARIBIL.getBlockLocalPathInfo(PBHelper.convert(GFTCSRFCVC.getBlock()), PBHelper.convert(GFTCSRFCVC.getToken()));
        } catch (IOException e) {
            throw new ServiceException(e);
        }
        return GetBlockLocalPathInfoResponseProto.newBuilder().setBlock(PBHelper.convert(WAFWBCHRRQ.getBlock())).setLocalPath(WAFWBCHRRQ.getBlockPath()).setLocalMetaPath(WAFWBCHRRQ.getMetaPath()).build();
    }

    @Override
    public GetHdfsBlockLocationsResponseProto getHdfsBlockLocations(RpcController ATDBPZDKYO, GetHdfsBlockLocationsRequestProto JLQGGMEZNY) throws ServiceException {
        HdfsBlocksMetadata XNDTXQDKGP;
        try {
            String TJCKEFVMXZ = JLQGGMEZNY.getBlockPoolId();
            List<Token<BlockTokenIdentifier>> PTWGCCLOUK = new ArrayList<Token<BlockTokenIdentifier>>(JLQGGMEZNY.getTokensCount());
            for (TokenProto DPHCOVIHQX : JLQGGMEZNY.getTokensList()) {
                PTWGCCLOUK.add(PBHelper.convert(DPHCOVIHQX));
            }
            long[] WZQKMWNEFO = Longs.toArray(JLQGGMEZNY.getBlockIdsList());
            // Call the real implementation
            XNDTXQDKGP = UVTIARIBIL.getHdfsBlocksMetadata(TJCKEFVMXZ, WZQKMWNEFO, PTWGCCLOUK);
        } catch (IOException e) {
            throw new ServiceException(e);
        }
        List<ByteString> TGINBENXIB = new ArrayList<ByteString>(XNDTXQDKGP.getVolumeIds().size());
        for (byte[] ORYPOHUGHY : XNDTXQDKGP.getVolumeIds()) {
            TGINBENXIB.add(ByteString.copyFrom(ORYPOHUGHY));
        }
        // Build and return the response
        Builder LRNOBMBXQF = GetHdfsBlockLocationsResponseProto.newBuilder();
        LRNOBMBXQF.addAllVolumeIds(TGINBENXIB);
        LRNOBMBXQF.addAllVolumeIndexes(XNDTXQDKGP.getVolumeIndexes());
        return LRNOBMBXQF.build();
    }

    @Override
    public ShutdownDatanodeResponseProto shutdownDatanode(RpcController WQNWQWLAYZ, ShutdownDatanodeRequestProto YOCTFWWXID) throws ServiceException {
        try {
            UVTIARIBIL.shutdownDatanode(YOCTFWWXID.getForUpgrade());
        } catch (IOException e) {
            throw new ServiceException(e);
        }
        return ClientDatanodeProtocolServerSideTranslatorPB.YYASQMCHIC;
    }

    public GetDatanodeInfoResponseProto getDatanodeInfo(RpcController DAJQJTGXPY, GetDatanodeInfoRequestProto VDIXRBYUDH) throws ServiceException {
        GetDatanodeInfoResponseProto GKLBQVEORE;
        try {
            GKLBQVEORE = GetDatanodeInfoResponseProto.newBuilder().setLocalInfo(PBHelper.convert(UVTIARIBIL.getDatanodeInfo())).build();
        } catch (IOException e) {
            throw new ServiceException(e);
        }
        return GKLBQVEORE;
    }
}