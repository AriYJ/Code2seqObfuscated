/**
 * A simple wrapper for increasing the visibility.
 */
public class WrappedJvmID extends JVMId {
    public WrappedJvmID(JobID KNFCLERWVR, boolean DAVYDEEPDO, int YAQCRWKTRQ) {
        super(KNFCLERWVR, DAVYDEEPDO, YAQCRWKTRQ);
    }
}