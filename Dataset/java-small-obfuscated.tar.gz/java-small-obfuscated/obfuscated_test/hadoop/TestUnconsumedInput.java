public class TestUnconsumedInput {
    protected final int WCVVTBFKUQ = 10000;

    protected File JTRWEWFONL = new File("stream_uncinput_input.txt");

    protected File WTIPPRPSZV = new File("stream_uncinput_out");

    // map parses input lines and generates count entries for each word.
    protected String RFXKDQIXWW = "roses.are.red\nviolets.are.blue\nbunnies.are.pink\n";

    protected String SYICSZDUGZ = UtilTest.makeJavaCommand(OutputOnlyApp.class, new String[]{ Integer.toString(WCVVTBFKUQ) });

    private StreamJob MUUINEWATZ;

    public TestUnconsumedInput() throws IOException {
        UtilTest IWOAFLFWJQ = new UtilTest(getClass().getName());
        IWOAFLFWJQ.checkUserDir();
        IWOAFLFWJQ.redirectIfAntJunit();
    }

    protected void createInput() throws IOException {
        DataOutputStream RXOQKNYHWD = new DataOutputStream(new FileOutputStream(JTRWEWFONL.getAbsoluteFile()));
        for (int FFWQRNHTSM = 0; FFWQRNHTSM < 10000; ++FFWQRNHTSM) {
            RXOQKNYHWD.write(RFXKDQIXWW.getBytes("UTF-8"));
        }
        RXOQKNYHWD.close();
    }

    protected String[] genArgs() {
        return new String[]{ "-input", JTRWEWFONL.getAbsolutePath(), "-output", WTIPPRPSZV.getAbsolutePath(), "-mapper", SYICSZDUGZ, "-reducer", "org.apache.hadoop.mapred.lib.IdentityReducer", "-numReduceTasks", "0", "-jobconf", "mapreduce.task.files.preserve.failedtasks=true", "-jobconf", "stream.tmpdir=" + System.getProperty("test.build.data", "/tmp") };
    }

    @Test
    public void testUnconsumedInput() throws Exception {
        String FCTIJDTRUQ = "part-00000";
        File SBXUQEHYSF = null;
        try {
            try {
                FileUtil.fullyDelete(WTIPPRPSZV.getAbsoluteFile());
            } catch (Exception e) {
            }
            createInput();
            // setup config to ignore unconsumed input
            Configuration HBOTIQSDRG = new Configuration();
            HBOTIQSDRG.set("stream.minRecWrittenToEnableSkip_", "0");
            MUUINEWATZ = new StreamJob();
            MUUINEWATZ.setConf(HBOTIQSDRG);
            int EBLMTOFBUM = MUUINEWATZ.run(genArgs());
            assertEquals("Job failed", 0, EBLMTOFBUM);
            SBXUQEHYSF = new File(WTIPPRPSZV, FCTIJDTRUQ).getAbsoluteFile();
            String WOKIPRRWFC = StreamUtil.slurp(SBXUQEHYSF);
            assertEquals("Output was truncated", WCVVTBFKUQ, StringUtils.countMatches(WOKIPRRWFC, "\t"));
        } finally {
            JTRWEWFONL.delete();
            FileUtil.fullyDelete(WTIPPRPSZV.getAbsoluteFile());
        }
    }
}