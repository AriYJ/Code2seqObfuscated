/**
 * The LocalFs implementation of ChecksumFs.
 */
/* Evolving for a release,to be changed to Stable */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public class LocalFs extends ChecksumFs {
    LocalFs(final Configuration ZVNDHYFUQS) throws IOException, URISyntaxException {
        super(new RawLocalFs(ZVNDHYFUQS));
    }

    /**
     * This constructor has the signature needed by
     * {@link AbstractFileSystem#createFileSystem(URI, Configuration)}.
     *
     * @param theUri
     * 		which must be that of localFs
     * @param conf
     * 		
     * @throws IOException
     * 		
     * @throws URISyntaxException
     * 		
     */
    LocalFs(final URI NFRTYUSPGN, final Configuration OKBWTWMTFM) throws IOException, URISyntaxException {
        this(OKBWTWMTFM);
    }
}