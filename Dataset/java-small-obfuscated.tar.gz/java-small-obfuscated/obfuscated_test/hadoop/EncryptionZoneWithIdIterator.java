/**
 * Used on the client-side to iterate over the list of encryption zones
 * stored on the namenode.
 */
@InterfaceAudience.Private
@InterfaceStability.Evolving
public class EncryptionZoneWithIdIterator extends BatchedRemoteIterator<Long, EncryptionZoneWithId> {
    private final ClientProtocol WMYOZBNUMX;

    EncryptionZoneWithIdIterator(ClientProtocol JXBJIUGBAI) {
        super(Long.valueOf(0));
        this.WMYOZBNUMX = JXBJIUGBAI;
    }

    @Override
    public BatchedEntries<EncryptionZoneWithId> makeRequest(Long CEKXOUTICR) throws IOException {
        return WMYOZBNUMX.listEncryptionZones(CEKXOUTICR);
    }

    @Override
    public Long elementToPrevKey(EncryptionZoneWithId HTEWGWDVQX) {
        return HTEWGWDVQX.getId();
    }
}