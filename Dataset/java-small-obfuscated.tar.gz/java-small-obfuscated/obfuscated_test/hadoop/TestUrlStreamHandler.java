/**
 * Test of the URL stream handler.
 */
public class TestUrlStreamHandler {
    private static final File CMTTTQUIHQ = PathUtils.getTestDir(TestUrlStreamHandler.class);

    /**
     * Test opening and reading from an InputStream through a hdfs:// URL.
     * <p>
     * First generate a file with some content through the FileSystem API, then
     * try to open and read the file through the URL stream API.
     *
     * @throws IOException
     * 		
     */
    @Test
    public void testDfsUrls() throws IOException {
        Configuration NSDXOGAFNG = new HdfsConfiguration();
        MiniDFSCluster RBLASXDRHP = new MiniDFSCluster.Builder(NSDXOGAFNG).numDataNodes(2).build();
        FileSystem QBEYINFNVV = RBLASXDRHP.getFileSystem();
        // Setup our own factory
        // setURLSteramHandlerFactor is can be set at most once in the JVM
        // the new URLStreamHandler is valid for all tests cases
        // in TestStreamHandler
        FsUrlStreamHandlerFactory SFVFJPRBCP = new org.apache.hadoop.fs.FsUrlStreamHandlerFactory();
        URL.setURLStreamHandlerFactory(SFVFJPRBCP);
        Path LCEAWFEJMY = new Path("/thefile");
        try {
            byte[] BDPAUFSGFG = new byte[1024];
            for (int ROSMTOPDXG = 0; ROSMTOPDXG < BDPAUFSGFG.length; ++ROSMTOPDXG)
                BDPAUFSGFG[ROSMTOPDXG] = ((byte) (ROSMTOPDXG));

            // First create the file through the FileSystem API
            OutputStream UZETUFPRIY = QBEYINFNVV.create(LCEAWFEJMY);
            UZETUFPRIY.write(BDPAUFSGFG);
            UZETUFPRIY.close();
            // Second, open and read the file content through the URL API
            URI QMMCMNCNUF = QBEYINFNVV.getUri();
            URL YZVQOXNHBM = new URL(QMMCMNCNUF.getScheme(), QMMCMNCNUF.getHost(), QMMCMNCNUF.getPort(), LCEAWFEJMY.toString());
            InputStream PGPELCFPOP = YZVQOXNHBM.openStream();
            assertNotNull(PGPELCFPOP);
            byte[] MCXPLXTUNE = new byte[4096];
            assertEquals(1024, PGPELCFPOP.read(MCXPLXTUNE));
            PGPELCFPOP.close();
            for (int HGDYJRSVVZ = 0; HGDYJRSVVZ < BDPAUFSGFG.length; ++HGDYJRSVVZ)
                assertEquals(BDPAUFSGFG[HGDYJRSVVZ], MCXPLXTUNE[HGDYJRSVVZ]);

            // Cleanup: delete the file
            QBEYINFNVV.delete(LCEAWFEJMY, false);
        } finally {
            QBEYINFNVV.close();
            RBLASXDRHP.shutdown();
        }
    }

    /**
     * Test opening and reading from an InputStream through a file:// URL.
     *
     * @throws IOException
     * 		
     * @throws URISyntaxException
     * 		
     */
    @Test
    public void testFileUrls() throws IOException, URISyntaxException {
        // URLStreamHandler is already set in JVM by testDfsUrls()
        Configuration ADHMIVDUXV = new HdfsConfiguration();
        // Locate the test temporary directory.
        if (!TestUrlStreamHandler.CMTTTQUIHQ.exists()) {
            if (!TestUrlStreamHandler.CMTTTQUIHQ.mkdirs())
                throw new IOException("Cannot create temporary directory: " + TestUrlStreamHandler.CMTTTQUIHQ);

        }
        File FDHXGEYWJL = new File(TestUrlStreamHandler.CMTTTQUIHQ, "thefile");
        URI QGLGKOSGSY = FDHXGEYWJL.toURI();
        FileSystem SIPBAIMHKP = FileSystem.get(QGLGKOSGSY, ADHMIVDUXV);
        try {
            byte[] RHRQQPATGI = new byte[1024];
            for (int MSSDHDTOPJ = 0; MSSDHDTOPJ < RHRQQPATGI.length; ++MSSDHDTOPJ)
                RHRQQPATGI[MSSDHDTOPJ] = ((byte) (MSSDHDTOPJ));

            // First create the file through the FileSystem API
            OutputStream ZAOJYVKNSA = SIPBAIMHKP.create(new Path(QGLGKOSGSY.getPath()));
            ZAOJYVKNSA.write(RHRQQPATGI);
            ZAOJYVKNSA.close();
            // Second, open and read the file content through the URL API.
            URL GOOLWEPKHA = QGLGKOSGSY.toURL();
            InputStream EBLAFNGORI = GOOLWEPKHA.openStream();
            assertNotNull(EBLAFNGORI);
            byte[] VYETFDYGEV = new byte[4096];
            assertEquals(1024, EBLAFNGORI.read(VYETFDYGEV));
            EBLAFNGORI.close();
            for (int OWJVTDFZXQ = 0; OWJVTDFZXQ < RHRQQPATGI.length; ++OWJVTDFZXQ)
                assertEquals(RHRQQPATGI[OWJVTDFZXQ], VYETFDYGEV[OWJVTDFZXQ]);

            // Cleanup: delete the file
            SIPBAIMHKP.delete(new Path(QGLGKOSGSY.getPath()), false);
        } finally {
            SIPBAIMHKP.close();
        }
    }
}