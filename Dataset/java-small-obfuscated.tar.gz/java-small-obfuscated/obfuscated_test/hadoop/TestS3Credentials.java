public class TestS3Credentials extends TestCase {
    public void testInvalidHostnameWithUnderscores() throws Exception {
        S3Credentials UHQBKNKMGH = new S3Credentials();
        try {
            UHQBKNKMGH.initialize(new URI("s3://a:b@c_d"), new Configuration());
            fail("Should throw IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid hostname in URI s3://a:b@c_d", e.getMessage());
        }
    }
}