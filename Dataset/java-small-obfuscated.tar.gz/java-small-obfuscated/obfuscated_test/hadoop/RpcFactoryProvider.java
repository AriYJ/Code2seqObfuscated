/**
 * A public static get() method must be present in the Client/Server Factory implementation.
 */
@InterfaceAudience.LimitedPrivate({ "MapReduce", "YARN" })
public class RpcFactoryProvider {
    private RpcFactoryProvider() {
    }

    public static RpcServerFactory getServerFactory(Configuration OGOKYSIWVC) {
        if (OGOKYSIWVC == null) {
            OGOKYSIWVC = new Configuration();
        }
        String TPSQNQVTFW = OGOKYSIWVC.get(IPC_SERVER_FACTORY_CLASS, DEFAULT_IPC_SERVER_FACTORY_CLASS);
        return ((RpcServerFactory) (RpcFactoryProvider.getFactoryClassInstance(TPSQNQVTFW)));
    }

    public static RpcClientFactory getClientFactory(Configuration CIMQPBURBB) {
        String QXZIEARBVI = CIMQPBURBB.get(IPC_CLIENT_FACTORY_CLASS, DEFAULT_IPC_CLIENT_FACTORY_CLASS);
        return ((RpcClientFactory) (RpcFactoryProvider.getFactoryClassInstance(QXZIEARBVI)));
    }

    private static Object getFactoryClassInstance(String XWZGWUKHHT) {
        try {
            Class<?> GVEXYBBNUQ = Class.forName(XWZGWUKHHT);
            Method TSTAGPJAAF = GVEXYBBNUQ.getMethod("get", null);
            TSTAGPJAAF.setAccessible(true);
            return TSTAGPJAAF.invoke(null, null);
        } catch (ClassNotFoundException e) {
            throw new YarnRuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new YarnRuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new YarnRuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new YarnRuntimeException(e);
        }
    }
}