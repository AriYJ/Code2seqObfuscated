package models;

public class Player {

  private char type;

  private int id;
  
  public Player(char type, int id) {
	  this.type = type;
	  this.id = id;
  }
}
