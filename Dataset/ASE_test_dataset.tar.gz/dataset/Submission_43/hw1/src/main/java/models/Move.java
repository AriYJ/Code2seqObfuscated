package models;

public class Move {

  private Player player;

  private int moveX;

  private int moveY;

}
