package models;

public class Message {

  private boolean moveValidity;

  private int code;

  private String message;

}
