package models;

public class Player {

  private char type;

  private int id;

}
