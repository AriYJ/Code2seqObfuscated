package models;

public class Player {

  private char type;

  private int id;

  public void setType(char type) {
    this.type = type;
  }

  public void setId(int id) {
    this.id = id;
  }

  public char getType() {
    return type;
  }

  public int getId() {
    return id;
  }

}
