# Individual Assignment for COMS W4156

Developed a two-player tic-tac-toe game with the MVC model and RESTful APIs.

Finished testing using JUnit.

Added SQLite database to avoid application crashes.

Performed style checks (CheckStyle) and static analysis (SpotBugs) to identify and fix potential bugs.
